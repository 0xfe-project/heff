// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_renEv 309756614
#define LBL_renEvTy 1323365525
#define LBL_renFlex 1323386232
#define LBL_renTy 309757082
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_solve 310977625
#define LBL_span 10032145
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_mel__mty__msp[] = {LBL_mel, LBL_mty, LBL_msp};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
static uint32_t shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex[] = {LBL_uty, LBL_uel, LBL_ubare, LBL_solve, LBL_ren, LBL_renEv, LBL_renTy, LBL_renEvTy, LBL_renFlex};
V g_co_2eop_24s1532701784x592895222(V, V, V);
V g_co_2eop_24s1532701784x592895222_entry(V self, V *a);
extern Clo g_co_2eop_24s1532701784x592895222_clo;
V g_co_2eop_24s1802027244x918867378(V, V, V);
V g_co_2eop_24s1802027244x918867378_entry(V self, V *a);
extern Clo g_co_2eop_24s1802027244x918867378_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2emetasTypeF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTypeF_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
V g_heff_2eelab_2eunify_2enth(V, V);
V g_heff_2eelab_2eunify_2enth_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enth_clo;
V g_heff_2eelab_2eunify_2epatSpine(V, V, V);
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatSpine_clo;
V g_heff_2eelab_2eunify_2epatStep(V, V, V);
V g_heff_2eelab_2eunify_2epatStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatStep_clo;
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo;
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_clo;
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V, V);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo;
V g_heff_2eelab_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eelab_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          v_t_2411 = heff_intEq(heff_dup(v_l_248), heff_dup(v_l_27_249));
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eeqPatArgs(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, (g_heff_2eelab_2eunify_2epatVarsOf(v_rest_242))});
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf(a[0]);
}
V g_heff_2eelab_2eunify_2edistinct_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eelab_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_244 = (g_list_2eany(heff_clo_n(g_heff_2eelab_2eunify_2edistinct_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2edistinct(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2edistinct_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_x_241, v_b_243);
}
Clo g_heff_2eelab_2eunify_2epatStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatStep_entry, 3, 0};

V g_heff_2eelab_2eunify_2epatStep(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_v1_244 = heff_field(v_v_241, 0);
      V v_v2_245 = heff_field(v_v_241, 1);
      switch (heff_tag_of(v_v1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_v1_244, 0);
        heff_drop(v_selfKey_240);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){heff_dup(v_l_249)}), v_rest_243});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
        }
        case TAG_SpApp: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_v2_245);
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_v1_244, 0);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_rest_243);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            heff_take_n(v_selfKey_240, 1ULL, 1);
            if (heff_strEq_c(v_sk_2419, heff_dup(v_k_2418))) {
              V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
            } else {
              heff_drop(v_rest_243);
              heff_drop_cell(v_ru_24x3_242_24Just, 1);
              return NTAG(TAG_Nothing);
            }
          }
          default: return heff_nomatch(v_selfKey_240);
          }
        }
        case TAG_SpApp: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_v2_245);
        }
      }
      case TAG_HMeta: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_v1_244);
      }
    }
    case TAG_VCode: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_v_241);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2epatStep_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2epatStep(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eelab_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop(v_selfKey_240);
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, heff_dup(v_v_244)));
    V v_t_246 = (g_heff_2eelab_2eunify_2epatSpine(heff_dup(v_selfKey_240), v_mc_241, v_s_243));
    return ({ V a_0 = v_selfKey_240; V a_1 = v_t_245; V a_2 = v_t_246; V r_ = (g_heff_2eelab_2eunify_2epatStep(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_SpProj: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eunify_2epatSpine(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2eunify_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enth_entry, 2, 0};

V g_heff_2eelab_2eunify_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2enth_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2enth(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eelab_2eunify_2emapWithIndexL(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eelab_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eelab_2eunify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eelab_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eelab_2eunify_2ecatMaybes(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes(a[0]);
}
Clo g_heff_2eelab_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2eanyL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2eunify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eelab_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2econcatMapL(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_entry, 7, 0};

V g_heff_2eelab_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    heff_drop(v_z_245);
    return heff_tail(v_z_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_call(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2eforU_lam0, 1, 7, (V[]){heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244, v_z_245, v_z_246})});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2eforU(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2410);
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_depth_242), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_it_246 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_246)) {
    case TAG_VNeu: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_sp_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 5);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HMeta: {
        V v_m_2414 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248}));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_m_2414, v_t_2415});
      }
      case TAG_HError: {
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    case TAG_VCode: {
      V v_t_2416 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2416});
    }
    case TAG_VLam: {
      V v_d_2417 = heff_field(v_it_246, 0);
      V v_c_2418 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      V v_x1_2439;
      switch (heff_tag_of(v_c_2418)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_c_2418, 1);
        V v_body_2421 = heff_field(v_c_2418, 2);
        heff_take_n(v_c_2418, 6ULL, 3);
        v_x1_2439 = heff_tr(heff_call(v_body_2421, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2417, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2438 = heff_field(v_c_2418, 0);
        heff_take_n(v_c_2418, 1ULL, 1);
        heff_drop(v_d_2417);
        v_x1_2439 = v_body_2438;
        break;
      }
      default: heff_nomatch(v_c_2418);
      }
      V v_t_2443;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_Nom: {
        V v_x_2440 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2440;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2439, 0ULL, 1);
        v_t_2443 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2442 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2442;
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2443});
    }
    case TAG_VCons: {
      V v_d_2444 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      V v_t_2445 = heff_arrayToList(heff_get_n(v_d_2444, 2, 3));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_r_240, v_depth_242, v_len_243}); V a_1 = v_t_2445; V r_ = (g_heff_2eelab_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2445); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  V v_a_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return v_a_2436;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2417 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_call(v_d_2417, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2423)));
  V v_a_2436;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2427 = heff_field(v_t_2424, 1);
    heff_take_n(v_t_2424, 2ULL, 4);
    heff_drop(v_t_2423);
    v_a_2436 = v_dom_2427;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2424, 0ULL, 3);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeInt: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeString: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeRune: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_NoRules: {
    v_a_2436 = v_t_2423;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2436}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2446 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  V f_ = heff_get_n(v_r_240, 0, 3);
  heff_room[0] = heff_intSub(v_depth_242, MK_INT(1LL));
  heff_room[1] = v_len_243;
  heff_room[2] = v_t_2450;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_depth_242), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_t_246 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 16ULL, 5);
      V v_t_2413 = heff_tr(heff_call(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 5);
      V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2426;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2421 = heff_field(v_cod_2416, 1);
        V v_body_2422 = heff_field(v_cod_2416, 2);
        heff_take_n(v_cod_2416, 6ULL, 3);
        v_x1_2426 = heff_tr(heff_call(v_body_2422, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2421, heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2425 = heff_field(v_cod_2416, 0);
        heff_take_n(v_cod_2416, 1ULL, 1);
        heff_drop(v_dom_2415);
        v_x1_2426 = v_body_2425;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2430;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_Nom: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2427;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2426, 0ULL, 1);
        v_t_2430 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2429 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2429;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_t_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2430}));
      return (g_heff_2eelab_2eunify_2eappendL(v_t_2419, v_t_2431));
    }
    case TAG_VRecord: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimRune: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2437 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2437});
    }
    case TAG_VFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2emetasTypeF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_2415;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2423);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eunify_2emetasSpF(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eelab_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec_n(3, shape_mel__mty__msp, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2emetasK(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eelab_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eelab_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eelab_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_entry, 6, 0};

V g_heff_2eelab_2eunify_2epoisonMany(V v_w_240, V v_ms_241, V v_uf_242, V v_ms_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam0, 1, 1, (V[]){heff_dup(v_ms_243)})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_248, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam1, 1, 4, (V[]){v_ms_241, v_w_240, v_z_244, v_z_245})));
}
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2eunify_2epoisonMany(a[0], a[1], a2, a3, a[4], a[5]); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ms_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_247 = ({ V a_0 = heff_take_field(v_c_246, 2); V a_1 = v_ms_243; V r_ = (g_list_2efoldl_24s895450532x1092988905(a_0, a_1)); heff_drop(v_ms_243); r_; });
  return ({ V rv_2 = v_ps_247; V rr_ = heff_rec_reuse_n(v_c_246, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(v_ms_241, 1, (V[]){v_t_2410}));
  return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2411, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_intLt_c(heff_dup(v_i_244), heff_dup(v_d_242))) {
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    } else {
      V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      V v_t_248 = (g_heff_2eelab_2eunify_2enth(v_idxs_241, v_t_247));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_242);
        return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
      }
      case TAG_Just: {
        V v_j_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        heff_drop(v_i_244);
        return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_249, v_d_242)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2411}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_t_243, 0);
    V v_a_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_2413}));
    V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2414}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_dd_2417 = heff_field(v_t_243, 0);
    V v_t2_2418 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2418)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_t2_2418, 0);
      V v_b_2420 = heff_field(v_t2_2418, 1);
      heff_take_n(v_t2_2418, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2420}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2419, v_t_2422})});
    }
    case TAG_AbsConst: {
      V v_b_2423 = heff_field(v_t2_2418, 0);
      heff_take_n(v_t2_2418, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2423}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2425})});
    }
    default: return heff_nomatch(v_t2_2418);
    }
  }
  case TAG_SCons: {
    V v_dct_2426 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2428 = heff_take_field(v_dct_2426, 2);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    V v_t_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_n(v_dct_2426, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2432});
  }
  case TAG_SProj: {
    V v_e_2433 = heff_field(v_t_243, 0);
    V v_l_2434 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2433}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2435, v_l_2434});
  }
  case TAG_STag: {
    V v_x_2436 = heff_field(v_t_243, 0);
    V v_as_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2437)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_as_2437, v_f_2438}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2436, v_t_2441});
  }
  case TAG_SMatch: {
    V v_e_2442 = heff_field(v_t_243, 0);
    V v_cs_2443 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2442}));
    V v_xs_2445 = heff_take_field(v_cs_2443, 2);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2445)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2445, v_d_242, v_r_240}));
    V v_t_2453 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_n(v_cs_2443, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e_2454 = heff_field(v_t_243, 0);
    V v_l_2455 = heff_field(v_t_243, 1);
    V v_v_2456 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2454}));
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2456}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2461 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2461}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_dd_2463 = heff_field(v_t_243, 0);
    V v_t2_2464 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2464)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_t2_2464, 0);
      V v_b_2466 = heff_field(v_t2_2464, 1);
      heff_take_n(v_t2_2464, 3ULL, 2);
      V v_t_2467 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2466}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2467, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2468})});
    }
    case TAG_AbsConst: {
      V v_b_2469 = heff_field(v_t2_2464, 0);
      heff_take_n(v_t2_2464, 1ULL, 1);
      V v_t_2470 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2469}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2471})});
    }
    default: return heff_nomatch(v_t2_2464);
    }
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_t_243, 0);
    V v_e_2473 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2473}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_t_243, 0);
    V v_ix_2477 = heff_field(v_t_243, 1);
    V v_ty_2478 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2486 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_ix_2477)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2477, heff_dup(v_d_242), heff_dup(v_idxs_241)}));
    V v_t_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2478}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_t_2486, v_t_2487});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTermF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  V f_ = v_f_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2439 = args[0];
  V v_as_2437 = heff_env(self)[0];
  V v_f_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_as_2437, v_i_2439);
  V f_ = v_f_2438;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2448)));
    V v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_t_2450, v_b_2449}));
    return heff_tag_at_n(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2479 = args[0];
  V v_ix_2477 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_idxs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_i_2480 = heff_arrayIndex(v_ix_2477, v_i_2479);
  if (heff_intLt_c(heff_dup(v_i_2480), heff_dup(v_d_242))) {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    return v_i_2480;
  } else {
    V v_t_2482 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
    V v_t_2483 = heff_intSub(heff_intSub(v_t_2482, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2480), heff_dup(v_d_242)));
    V v_t_2484 = ({ V a_0 = v_idxs_241; V a_1 = v_t_2483; V r_ = (g_heff_2eelab_2eunify_2enth(a_0, a_1)); heff_drop(v_idxs_241); r_; });
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      heff_drop(v_d_242);
      return v_i_2480;
    }
    case TAG_Just: {
      V v_j_2485 = heff_field(v_t_2484, 0);
      heff_take_n(v_t_2484, 1ULL, 1);
      heff_drop(v_i_2480);
      return heff_intAdd(v_j_2485, v_d_242);
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245))});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2422 = heff_arrayToList(heff_take_field(v_ft_2420, 2));
    V v_t_2423 = (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2422));
    V v_t_2424 = ({ V rv_2 = heff_arrayFromList(v_t_2423); V rr_ = heff_rec_reuse_n(v_ft_2420, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2424, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2427 = heff_take_field(v_vs_2425, 2);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam0, 1, 2, (V[]){v_xs_2427, v_f_2426}));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_n(v_vs_2425, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2433});
  }
  case TAG_SIsTy: {
    V v_a_2434 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2434}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2435});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2esubstTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = v_f_2426;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2429)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2429, v_f_2426}));
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam1, 2, 1, (V[]){heff_dup(v_idxs_240)})});
}
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2esubstOf(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_243; V a_1 = v_idxs_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eelab_2eunify_2esubstTermF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
Clo g_heff_2eelab_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eelab_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return v_t_241;
  } else {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take_n(v_it2_249, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take_n(v_it2_249, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitRune: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFixed: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat32: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
}
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estripLams(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_245}));
    return heff_tag_at_n(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_248}));
    return heff_tag_at_n(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get_n(v_r_240, 0, 2);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at_n(v_ru_24t_242_24SLam, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse_n(v_b_2412, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SLam, 2);
      V v_t_2419 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2422 = heff_take_field(v_d_2421, 2);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2422, v_r_240}));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_n(v_d_2421, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e_2427 = heff_field(v_t_242, 0);
    V v_l_2428 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2427}));
    return heff_tag_at_n(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_x_2430 = heff_field(v_t_242, 0);
    V v_as_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2431)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_as_2431, v_r_240}));
    return heff_tag_at_n(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2430, v_t_2434});
  }
  case TAG_SMatch: {
    V v_e_2435 = heff_field(v_t_242, 0);
    V v_cs_2436 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2435}));
    V v_xs_2438 = heff_take_field(v_cs_2436, 2);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2438, v_r_240}));
    V v_t_2445 = ({ V rv_2 = v_t_2444; V rr_ = heff_rec_reuse_n(v_cs_2436, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2437, v_t_2445});
  }
  case TAG_SSpecialize: {
    V v_e_2446 = heff_field(v_t_242, 0);
    V v_l_2447 = heff_field(v_t_242, 1);
    V v_v_2448 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2446}));
    V v_t_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_2448}));
    return heff_tag_at_n(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2449, v_l_2447, v_t_2450});
  }
  case TAG_SIs: {
    V v_e_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2451}));
    return heff_tag_at_n(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2452});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2453 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2453}));
    return heff_tag_at_n(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2454});
  }
  case TAG_SFix: {
    V v_d_2455 = heff_field(v_t_242, 0);
    V v_b_2456 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2455}));
    V v_f_2458 = heff_get_n(v_r_240, 0, 2);
    V v_t_2464;
    switch (heff_tag_of(v_b_2456)) {
    case TAG_MkAbs: {
      V v_x_2459 = heff_field(v_b_2456, 0);
      V v_b_2460 = heff_field(v_b_2456, 1);
      heff_take_n(v_b_2456, 3ULL, 2);
      V v_t_2461 = heff_tr(heff_call(v_f_2458, 1, (V[]){v_b_2460}));
      v_t_2464 = heff_tag_at_n(v_ru_24t_242_24SFix, TAG_MkAbs, 2, (V[]){v_x_2459, v_t_2461});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2462 = heff_field(v_b_2456, 0);
      V v_ru_24b_2456_24AbsConst = heff_take_reuse_n(v_b_2456, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SFix, 2);
      V v_t_2463 = heff_tr(heff_call(v_f_2458, 1, (V[]){v_b_2462}));
      v_t_2464 = heff_tag_at_n(v_ru_24b_2456_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2463});
      break;
    }
    default: heff_nomatch(v_b_2456);
    }
    return heff_tag_n(TAG_SFix, 2, (V[]){v_t_2457, v_t_2464});
  }
  case TAG_SImplicit: {
    V v_x_2465 = heff_field(v_t_242, 0);
    V v_e_2466 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2466}));
    return heff_tag_at_n(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2465, v_t_2467});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2469 = heff_field(v_t_242, 0);
    V v_idxs_2470 = heff_field(v_t_242, 1);
    V v_ty_2471 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2472 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_2469), v_mc_241));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_Nothing: {
      V v_t_2473 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2471}));
      return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2473});
    }
    case TAG_Just: {
      V v_e_2474 = heff_field(v_t_2472, 0);
      heff_take_n(v_t_2472, 1ULL, 1);
      V v_t_2475 = heff_get_n(v_e_2474, 2, 6);
      switch (heff_tag_of(v_t_2475)) {
      case TAG_Nothing: {
        V v_t_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2471}));
        return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2476});
      }
      case TAG_Just: {
        V v_sol_2477 = heff_field(v_t_2475, 0);
        heff_take_n(v_t_2475, 1ULL, 1);
        heff_drop(v_m_2469);
        heff_drop(v_ty_2471);
        heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
        V v_idxs_2478 = heff_arrayToList(v_idxs_2470);
        V v_t_2479 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_2478));
        V v_t_2480 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_idxs_2478; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_idxs_2478); r_; });
        V v_t_2481 = (g_heff_2eelab_2eunify_2estripLams(v_t_2480, v_sol_2477));
        V v_t_2482 = heff_tr(heff_call(heff_get_n(v_t_2479, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2481}));
        return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2482});
      }
      default: return heff_nomatch(v_t_2475);
      }
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_as_2431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_as_2431, v_i_2432);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_xs_2441 = heff_field(v_p_2440, 0);
    V v_b_2442 = heff_field(v_p_2440, 1);
    V v_ru_24p_2440_24MkPair = heff_take_reuse_n(v_p_2440, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_2442}));
    return heff_tag_at_n(v_ru_24p_2440_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_p_2440);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_dom_247}));
    V v_f_2412 = heff_take_field(v_r_240, 1);
    V v_t_2418;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_248, 0);
      V v_b_2414 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2414}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_b_2416}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2421;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2419}));
      v_t_2421 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_246, v_t_2411, v_t_2418, v_implicit_249, v_t_2421});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_t_242, 0);
    V v_ft_2423 = heff_field(v_t_242, 1);
    V v_ds_2424 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2425 = heff_take_field(v_ft_2423, 2);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2425)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2425, heff_dup(v_r_240)}));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_n(v_ft_2423, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_xs_2430 = heff_take_field(v_ds_2424, 2);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_r_240}));
    V v_t_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_n(v_ds_2424, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2422, v_t_2429, v_t_2434});
  }
  case TAG_SSum: {
    V v_vs_2435 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2436 = heff_take_field(v_vs_2435, 2);
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2436)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2436, v_r_240}));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_n(v_vs_2435, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2442});
  }
  case TAG_SIsTy: {
    V v_a_2443 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_a_2443}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2444});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2438, v_r_240}));
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eelab_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2ezonker(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eelab_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
Clo g_heff_2eelab_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eelab_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
    heff_drop(v_i_240);
    return v_rr_241;
  } else {
    V v_t_243 = heff_intAdd(heff_dup(heff_rfield(v_rr_241, 0)), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_rr_241, 1)), MK_INT(1LL));
    V v_t_245 = (g_map_2einsert_24s1689409319x1710080871(heff_take_field(v_rr_241, 0), heff_take_field(v_rr_241, 1), heff_get_n(v_rr_241, 2, 3)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_243, v_t_244, v_t_245});
    v_i_240 = t_0;
    v_rr_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2elamsU_str0, 1, "x");
Clo g_heff_2eelab_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eelab_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return v_body_241;
  } else {
    V v_t_243 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_244 = heff_tag_n(TAG_SLam, 2, (V[]){v_t_243, heff_tag_n(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eelab_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_244;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eelab_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = ({ V rv_0 = v_ty_242; V rv_1 = NTAG(TAG_Nothing); V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_arity_241; V rr_ = heff_rec_reuse_n(v_entry_240, 48ULL, 6, shape_ty__sol__solStx__arity__name__span); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_mc_245 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_c_243, 4)), v_t_244, heff_take_field(v_c_243, 3)));
  V v_t_246 = heff_intAdd(heff_take_field(v_c_243, 4), MK_INT(1LL));
  return ({ V rv_3 = v_mc_245; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_n(v_c_243, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          v_t_249 = heff_intEq(v_a_246, v_a_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euElRigid_str0, 1, "x");
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_entry, 12, 0};

V g_heff_2eelab_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_x4_246, V v_cb_247, V v_a_248, V v_b_249, V v_z_2410, V v_z_2411) {
top: ;
  switch (heff_tag_of(v_x4_246)) {
  case TAG_VNeu: {
    V v_h_2412 = heff_field(v_x4_246, 0);
    V v_sp_2413 = heff_field(v_x4_246, 1);
    heff_take_n(v_x4_246, 3ULL, 5);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2417 = heff_field(v_cb_247, 0);
      V v_sp_27_2418 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get_n(v_r_243, 2, 9), 8, (V[]){v_g_244, v_cs_245, v_h_2412, v_sp_2413, v_h_27_2417, v_sp_27_2418, v_z_2410, v_z_2411});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2423 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2424 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2423}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2424, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2427 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2428 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2427}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2428, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2430 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2431 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2430}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2431, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2412);
      heff_drop(v_sp_2413);
      V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2433 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2432}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2433, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2434 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCode = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2440 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2441 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2440}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2441, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      V v_t_27_2442 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCode, 1);
      return heff_tail(heff_get_n(v_r_243, 0, 9), 6, (V[]){v_g_244, v_cs_245, v_t_2434, v_t_27_2442, v_z_2410, v_z_2411});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2445 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2446 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2445}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2446, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2448 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2449 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2448}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2449, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2434);
      V v_t_2450 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2451 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2450}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2451, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2452 = heff_field(v_x4_246, 0);
    V v_c_2453 = heff_field(v_x4_246, 1);
    V v_ru_24x4_246_24VLam = heff_take_reuse_n(v_x4_246, 3ULL, 2);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2459 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2460 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2459}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2460, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2462 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2463 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_2462}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2463, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      V v_c_27_2465 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 2ULL, 2);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_2466 = heff_tr(heff_call(v_d_2452, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2467 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2466)));
      V v_a_2479;
      switch (heff_tag_of(v_t_2467)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_2470 = heff_field(v_t_2467, 1);
        heff_take_n(v_t_2467, 2ULL, 4);
        heff_drop(v_t_2466);
        v_a_2479 = v_dom_2470;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2467, 0ULL, 3);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeInt: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFloat: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeString: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeRune: {
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2467, 0ULL, 1);
        v_a_2479 = v_t_2466;
        break;
      }
      case TAG_NoRules: {
        v_a_2479 = v_t_2466;
        break;
      }
      default: heff_nomatch(v_t_2467);
      }
      V v_t_2480 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_245, 0))});
      V v_v_2482 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2480, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam0, 1, 1, (V[]){v_a_2479}), NTAG(TAG_Nothing)));
      V v_x_2487;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_MkClo: {
        V v_n_2483 = heff_dup(heff_field(v_c_2453, 0));
        v_x_2487 = v_n_2483;
        break;
      }
      case TAG_CloConst: {
        v_x_2487 = ((V)&g_heff_2eelab_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      V v_t_2488 = heff_intAdd(heff_take_field(v_cs_245, 0), MK_INT(1LL));
      V v_t_2489 = heff_tag_at_n(v_ru_24x4_246_24VLam, TAG_Cons, 2, (V[]){v_x_2487, heff_get_n(v_cs_245, 1, 2)});
      V v_x1_2495;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_MkClo: {
        V v_vs_2491 = heff_field(v_c_2453, 1);
        V v_body_2492 = heff_field(v_c_2453, 2);
        heff_take_n(v_c_2453, 6ULL, 3);
        v_x1_2495 = heff_tr(heff_call(v_body_2492, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2491, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_v_2482)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2494 = heff_field(v_c_2453, 0);
        heff_take_n(v_c_2453, 1ULL, 1);
        v_x1_2495 = v_body_2494;
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      V v_t_2499;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_Nom: {
        V v_x_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        v_t_2499 = v_x_2496;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2495, 0ULL, 1);
        v_t_2499 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2498 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        v_t_2499 = v_x_2498;
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_x1_24105;
      switch (heff_tag_of(v_c_27_2465)) {
      case TAG_MkClo: {
        V v_vs_24101 = heff_field(v_c_27_2465, 1);
        V v_body_24102 = heff_field(v_c_27_2465, 2);
        heff_take_n(v_c_27_2465, 6ULL, 3);
        v_x1_24105 = heff_tr(heff_call(v_body_24102, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24101, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam2, 1, 1, (V[]){v_v_2482})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24104 = heff_field(v_c_27_2465, 0);
        heff_take_n(v_c_27_2465, 1ULL, 1);
        heff_drop(v_v_2482);
        v_x1_24105 = v_body_24104;
        break;
      }
      default: heff_nomatch(v_c_27_2465);
      }
      V v_t_24109;
      switch (heff_tag_of(v_x1_24105)) {
      case TAG_Nom: {
        V v_x_24106 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        v_t_24109 = v_x_24106;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24105, 0ULL, 1);
        v_t_24109 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24108 = heff_field(v_x1_24105, 0);
        heff_take_n(v_x1_24105, 1ULL, 1);
        v_t_24109 = v_x_24108;
        break;
      }
      default: heff_nomatch(v_x1_24105);
      }
      return heff_tail(heff_get_n(v_r_243, 1, 9), 6, (V[]){v_g_244, heff_rec_n(2, shape_len__names, (V[]){v_t_2488, v_t_2489}), v_t_2499, v_t_24109, v_z_2410, v_z_2411});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24111 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24112 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24111}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24112, v_z_2410, v_z_2411));
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2452);
      heff_drop(v_c_2453);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24113 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24114 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24113}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24114, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24115 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCons = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24121 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24122 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24121}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24122, v_z_2410, v_z_2411));
    }
    case TAG_VCode: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24124 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24125 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24124}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24125, v_z_2410, v_z_2411));
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24128 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24129 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24128}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24129, v_z_2410, v_z_2411));
    }
    case TAG_VCons: {
      V v_d_27_24130 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCons, 1);
      V v_t_24131 = heff_arrayToList(heff_get_n(v_d_24115, 2, 3));
      V v_t_24132 = heff_arrayToList(heff_get_n(v_d_27_24130, 2, 3));
      V v_t_24133 = (g_heff_2eelab_2eunify_2ezipL(v_t_24131, v_t_24132));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24133; V a_4 = heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam3, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V a_5 = v_z_2410; V a_6 = v_z_2411; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24133); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24115, 3);
      V v_t_24145 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24146 = heff_tr(heff_call(v_uf_242, 1, (V[]){v_t_24145}));
      return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_24146, v_z_2410, v_z_2411));
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    heff_drop_rec(v_cs_245, 2);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    heff_drop(v_z_2410);
    return heff_tail(v_z_2411, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x4_246);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2euElRigid(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_u_2481 = args[0];
  V v_a_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2481);
  return v_a_2479;
}
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_w_2493 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_2493);
  return v_v_2482;
}
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_w_24103 = args[0];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24103);
  return v_v_2482;
}
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_p_24134 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  V v_cs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_p_24134, 0);
    V v_y_24136 = heff_field(v_p_24134, 1);
    heff_take_n(v_p_24134, 3ULL, 2);
    V v_t_24140;
    switch (heff_tag_of(v_x_24135)) {
    case TAG_Nom: {
      V v_x_24137 = heff_field(v_x_24135, 0);
      heff_take_n(v_x_24135, 1ULL, 1);
      v_t_24140 = v_x_24137;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24135, 0ULL, 1);
      v_t_24140 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24139 = heff_field(v_x_24135, 0);
      heff_take_n(v_x_24135, 1ULL, 1);
      v_t_24140 = v_x_24139;
      break;
    }
    default: heff_nomatch(v_x_24135);
    }
    V v_t_24144;
    switch (heff_tag_of(v_y_24136)) {
    case TAG_Nom: {
      V v_x_24141 = heff_field(v_y_24136, 0);
      heff_take_n(v_y_24136, 1ULL, 1);
      v_t_24144 = v_x_24141;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24136, 0ULL, 1);
      v_t_24144 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24143 = heff_field(v_y_24136, 0);
      heff_take_n(v_y_24136, 1ULL, 1);
      v_t_24144 = v_x_24143;
      break;
    }
    default: heff_nomatch(v_y_24136);
    }
    V f_ = heff_get_n(v_r_243, 1, 9);
    heff_room[0] = v_g_244;
    heff_room[1] = v_cs_245;
    heff_room[2] = v_t_24140;
    heff_room[3] = v_t_24144;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_p_24134);
  }
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam5, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam8, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eelab_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_t_249 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  return heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam1, 2, 8, (V[]){v_w_240, v_t_249, v_ms_241, v_b0_247, v_cs_245, v_uf_242, v_r_243, v_g_244});
}
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_246; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args) {
  V v_c_2413 = args[0];
  V v_b0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2413, 3, 8); V a_1 = v_b0_247; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get_n(v_c_2418, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args) {
  V v_c_2424 = args[0];
  return heff_get_n(v_c_2424, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args) {
  V v_x_2426 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = ({ V a_0 = v_x_2426; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2426); r_; });
  V v_t_2428 = heff_tr(heff_call(heff_get_n(v_t_2427, 0, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_245, 0, 2), v_x_2415}));
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_2428; V a_4 = v_hd_2410; V a_5 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_uf_242); heff_drop(v_t_2428); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam8_clo)})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2425, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam9, 1, 7, (V[]){v_cs_245, v_x_2415, v_w_240, v_ms_241, v_uf_242, v_hd_2410, v_k_2411})));
}
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2420); r_; });
  V v_t_2422 = heff_tr(heff_call(heff_get_n(v_t_2421, 0, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_245, 0)), v_x_2412}));
  return ({ V a_0 = heff_dup(v_w_240); V a_1 = heff_dup(v_ms_241); V a_2 = v_uf_242; V a_3 = v_t_2422; V a_4 = heff_dup(v_hd_2410); V a_5 = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam7, 1, 7, (V[]){v_ms_241, v_w_240, v_hd_2410, v_cs_245, v_x_2415, v_uf_242, v_k_2411}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2422); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = (g_heff_2eelab_2evalue_2eisError(v_x_2412));
  V v_t_2417;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    v_t_2417 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_2417 = (g_heff_2eelab_2evalue_2eisError(v_x_2415));
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    V v_t_2419 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam5_clo)})}));
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2419, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam6, 1, 8, (V[]){v_cs_245, v_x_2412, v_w_240, v_ms_241, v_uf_242, v_hd_2410, v_x_2415, v_k_2411})));
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_it_2451;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_2439 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_2440 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_2439)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2439, 0ULL, 1);
            heff_drop(v_sp_2440);
            v_it_2451 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2439, 0ULL, 1);
            heff_drop(v_sp_2440);
            v_it_2451 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2446 = heff_field(v_v1_2439, 0);
            V v_ru_24v1_2439_24HMeta = heff_take_reuse_n(v_v1_2439, 1ULL, 1);
            v_it_2451 = heff_tag_at_n(v_ru_24v1_2439_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2446, v_sp_2440})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2440);
            v_it_2451 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2439);
          }
          break;
        }
        case TAG_VCode: {
          v_it_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_2451 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_2451)) {
        case TAG_Nothing: {
          V v_it_2464;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_2452 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_2453 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_2452)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2452, 0ULL, 1);
              heff_drop(v_sp_2453);
              v_it_2464 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2452, 0ULL, 1);
              heff_drop(v_sp_2453);
              v_it_2464 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2459 = heff_field(v_v1_2452, 0);
              V v_ru_24v1_2452_24HMeta = heff_take_reuse_n(v_v1_2452, 1ULL, 1);
              v_it_2464 = heff_tag_at_n(v_ru_24v1_2452_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2459, v_sp_2453})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2453);
              v_it_2464 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_2452);
            }
            break;
          }
          case TAG_VCode: {
            v_it_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_2464 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_2464)) {
          case TAG_Nothing: {
            V v_t_2477;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_2465 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_2465)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_2465);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_2490;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_2478 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_2478)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_2478);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_2477; V a_7 = v_t_2490; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_2491 = heff_field(v_it_2464, 0);
            heff_take_n(v_it_2464, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_2491)) {
            case TAG_MkPair: {
              V v_m_2492 = heff_field(v_it1_2491, 0);
              V v_sp_2493 = heff_field(v_it1_2491, 1);
              heff_take_n(v_it1_2491, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_2492, v_sp_2493, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_2491);
            }
          }
          default: return heff_nomatch(v_it_2464);
          }
        }
        case TAG_Just: {
          V v_it1_2494 = heff_field(v_it_2451, 0);
          heff_take_n(v_it_2451, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_2494)) {
          case TAG_MkPair: {
            V v_m_2495 = heff_field(v_it1_2494, 0);
            V v_sp_2496 = heff_field(v_it1_2494, 1);
            heff_take_n(v_it1_2494, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_2495, v_sp_2496, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_2494);
          }
        }
        default: return heff_nomatch(v_it_2451);
        }
      }
      case TAG_VCode: {
        V v_it_24110;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_2498 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_2499 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_2498)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2498, 0ULL, 1);
            heff_drop(v_sp_2499);
            v_it_24110 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2498, 0ULL, 1);
            heff_drop(v_sp_2499);
            v_it_24110 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24105 = heff_field(v_v1_2498, 0);
            V v_ru_24v1_2498_24HMeta = heff_take_reuse_n(v_v1_2498, 1ULL, 1);
            v_it_24110 = heff_tag_at_n(v_ru_24v1_2498_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24105, v_sp_2499})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2499);
            v_it_24110 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2498);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24110)) {
        case TAG_Nothing: {
          V v_it_24123;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24111 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24112 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24111)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24111, 0ULL, 1);
              heff_drop(v_sp_24112);
              v_it_24123 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24111, 0ULL, 1);
              heff_drop(v_sp_24112);
              v_it_24123 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24118 = heff_field(v_v1_24111, 0);
              V v_ru_24v1_24111_24HMeta = heff_take_reuse_n(v_v1_24111, 1ULL, 1);
              v_it_24123 = heff_tag_at_n(v_ru_24v1_24111_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24118, v_sp_24112})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24112);
              v_it_24123 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24111);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24123 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24123)) {
          case TAG_Nothing: {
            V v_t_24136;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24124 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24124)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24124);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24149;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24137 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24137)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24137);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24136; V a_7 = v_t_24149; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24150 = heff_field(v_it_24123, 0);
            heff_take_n(v_it_24123, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24150)) {
            case TAG_MkPair: {
              V v_m_24151 = heff_field(v_it1_24150, 0);
              V v_sp_24152 = heff_field(v_it1_24150, 1);
              heff_take_n(v_it1_24150, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24151, v_sp_24152, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24150);
            }
          }
          default: return heff_nomatch(v_it_24123);
          }
        }
        case TAG_Just: {
          V v_it1_24153 = heff_field(v_it_24110, 0);
          heff_take_n(v_it_24110, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24153)) {
          case TAG_MkPair: {
            V v_m_24154 = heff_field(v_it1_24153, 0);
            V v_sp_24155 = heff_field(v_it1_24153, 1);
            heff_take_n(v_it1_24153, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24154, v_sp_24155, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24153);
          }
        }
        default: return heff_nomatch(v_it_24110);
        }
      }
      case TAG_VLam: {
        V v_it_24170;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24158 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24159 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24158)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24158, 0ULL, 1);
            heff_drop(v_sp_24159);
            v_it_24170 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24158, 0ULL, 1);
            heff_drop(v_sp_24159);
            v_it_24170 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24165 = heff_field(v_v1_24158, 0);
            V v_ru_24v1_24158_24HMeta = heff_take_reuse_n(v_v1_24158, 1ULL, 1);
            v_it_24170 = heff_tag_at_n(v_ru_24v1_24158_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24165, v_sp_24159})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24159);
            v_it_24170 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24158);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24170 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24170)) {
        case TAG_Nothing: {
          V v_it_24183;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24171 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24172 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24171)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24171, 0ULL, 1);
              heff_drop(v_sp_24172);
              v_it_24183 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24171, 0ULL, 1);
              heff_drop(v_sp_24172);
              v_it_24183 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24178 = heff_field(v_v1_24171, 0);
              V v_ru_24v1_24171_24HMeta = heff_take_reuse_n(v_v1_24171, 1ULL, 1);
              v_it_24183 = heff_tag_at_n(v_ru_24v1_24171_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24178, v_sp_24172})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24172);
              v_it_24183 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24171);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24183 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24183)) {
          case TAG_Nothing: {
            V v_t_24196;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24184 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24184)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24184);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24209;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24197 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24197)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24197);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24196; V a_7 = v_t_24209; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24210 = heff_field(v_it_24183, 0);
            heff_take_n(v_it_24183, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24210)) {
            case TAG_MkPair: {
              V v_m_24211 = heff_field(v_it1_24210, 0);
              V v_sp_24212 = heff_field(v_it1_24210, 1);
              heff_take_n(v_it1_24210, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24211, v_sp_24212, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24210);
            }
          }
          default: return heff_nomatch(v_it_24183);
          }
        }
        case TAG_Just: {
          V v_it1_24213 = heff_field(v_it_24170, 0);
          heff_take_n(v_it_24170, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24213)) {
          case TAG_MkPair: {
            V v_m_24214 = heff_field(v_it1_24213, 0);
            V v_sp_24215 = heff_field(v_it1_24213, 1);
            heff_take_n(v_it1_24213, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24214, v_sp_24215, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24213);
          }
        }
        default: return heff_nomatch(v_it_24170);
        }
      }
      case TAG_VCons: {
        V v_it_24229;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24217 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24218 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24217)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24217, 0ULL, 1);
            heff_drop(v_sp_24218);
            v_it_24229 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24217, 0ULL, 1);
            heff_drop(v_sp_24218);
            v_it_24229 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24224 = heff_field(v_v1_24217, 0);
            V v_ru_24v1_24217_24HMeta = heff_take_reuse_n(v_v1_24217, 1ULL, 1);
            v_it_24229 = heff_tag_at_n(v_ru_24v1_24217_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24224, v_sp_24218})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24218);
            v_it_24229 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24217);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24229 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24229)) {
        case TAG_Nothing: {
          V v_it_24242;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24230 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24231 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24230)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24230, 0ULL, 1);
              heff_drop(v_sp_24231);
              v_it_24242 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24230, 0ULL, 1);
              heff_drop(v_sp_24231);
              v_it_24242 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24237 = heff_field(v_v1_24230, 0);
              V v_ru_24v1_24230_24HMeta = heff_take_reuse_n(v_v1_24230, 1ULL, 1);
              v_it_24242 = heff_tag_at_n(v_ru_24v1_24230_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24237, v_sp_24231})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24231);
              v_it_24242 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24230);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24242 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24242)) {
          case TAG_Nothing: {
            V v_t_24255;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24243 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24243)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24243);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24268;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24256 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24256)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24256);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24255; V a_7 = v_t_24268; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24269 = heff_field(v_it_24242, 0);
            heff_take_n(v_it_24242, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24269)) {
            case TAG_MkPair: {
              V v_m_24270 = heff_field(v_it1_24269, 0);
              V v_sp_24271 = heff_field(v_it1_24269, 1);
              heff_take_n(v_it1_24269, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24270, v_sp_24271, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24269);
            }
          }
          default: return heff_nomatch(v_it_24242);
          }
        }
        case TAG_Just: {
          V v_it1_24272 = heff_field(v_it_24229, 0);
          heff_take_n(v_it_24229, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24272)) {
          case TAG_MkPair: {
            V v_m_24273 = heff_field(v_it1_24272, 0);
            V v_sp_24274 = heff_field(v_it1_24272, 1);
            heff_take_n(v_it1_24272, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24273, v_sp_24274, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24272);
          }
        }
        default: return heff_nomatch(v_it_24229);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 5);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_it_24293;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24281 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24282 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24281)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24281, 0ULL, 1);
            heff_drop(v_sp_24282);
            v_it_24293 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24281, 0ULL, 1);
            heff_drop(v_sp_24282);
            v_it_24293 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24288 = heff_field(v_v1_24281, 0);
            V v_ru_24v1_24281_24HMeta = heff_take_reuse_n(v_v1_24281, 1ULL, 1);
            v_it_24293 = heff_tag_at_n(v_ru_24v1_24281_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24288, v_sp_24282})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24282);
            v_it_24293 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24281);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24293 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24293)) {
        case TAG_Nothing: {
          V v_it_24306;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24294 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24295 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24294)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24294, 0ULL, 1);
              heff_drop(v_sp_24295);
              v_it_24306 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24294, 0ULL, 1);
              heff_drop(v_sp_24295);
              v_it_24306 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24301 = heff_field(v_v1_24294, 0);
              V v_ru_24v1_24294_24HMeta = heff_take_reuse_n(v_v1_24294, 1ULL, 1);
              v_it_24306 = heff_tag_at_n(v_ru_24v1_24294_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24301, v_sp_24295})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24295);
              v_it_24306 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24294);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24306)) {
          case TAG_Nothing: {
            V v_t_24319;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24307 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24307)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24307);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24332;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24320 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24320)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24320);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24319; V a_7 = v_t_24332; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24333 = heff_field(v_it_24306, 0);
            heff_take_n(v_it_24306, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24333)) {
            case TAG_MkPair: {
              V v_m_24334 = heff_field(v_it1_24333, 0);
              V v_sp_24335 = heff_field(v_it1_24333, 1);
              heff_take_n(v_it1_24333, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24334, v_sp_24335, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24333);
            }
          }
          default: return heff_nomatch(v_it_24306);
          }
        }
        case TAG_Just: {
          V v_it1_24336 = heff_field(v_it_24293, 0);
          heff_take_n(v_it_24293, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24336)) {
          case TAG_MkPair: {
            V v_m_24337 = heff_field(v_it1_24336, 0);
            V v_sp_24338 = heff_field(v_it1_24336, 1);
            heff_take_n(v_it1_24336, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24337, v_sp_24338, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24336);
          }
        }
        default: return heff_nomatch(v_it_24293);
        }
      }
      case TAG_VCode: {
        V v_it_24352;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24340 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24341 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24340)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24340, 0ULL, 1);
            heff_drop(v_sp_24341);
            v_it_24352 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24340, 0ULL, 1);
            heff_drop(v_sp_24341);
            v_it_24352 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24347 = heff_field(v_v1_24340, 0);
            V v_ru_24v1_24340_24HMeta = heff_take_reuse_n(v_v1_24340, 1ULL, 1);
            v_it_24352 = heff_tag_at_n(v_ru_24v1_24340_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24347, v_sp_24341})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24341);
            v_it_24352 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24340);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24352 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24352)) {
        case TAG_Nothing: {
          V v_it_24365;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24353 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24354 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24353)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24353, 0ULL, 1);
              heff_drop(v_sp_24354);
              v_it_24365 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24353, 0ULL, 1);
              heff_drop(v_sp_24354);
              v_it_24365 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24360 = heff_field(v_v1_24353, 0);
              V v_ru_24v1_24353_24HMeta = heff_take_reuse_n(v_v1_24353, 1ULL, 1);
              v_it_24365 = heff_tag_at_n(v_ru_24v1_24353_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24360, v_sp_24354})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24354);
              v_it_24365 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24353);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24365 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24365)) {
          case TAG_Nothing: {
            V v_t_24378;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24366 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24366)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24366);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24391;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24379 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24379)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24379);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24378; V a_7 = v_t_24391; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24392 = heff_field(v_it_24365, 0);
            heff_take_n(v_it_24365, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24392)) {
            case TAG_MkPair: {
              V v_m_24393 = heff_field(v_it1_24392, 0);
              V v_sp_24394 = heff_field(v_it1_24392, 1);
              heff_take_n(v_it1_24392, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24393, v_sp_24394, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24392);
            }
          }
          default: return heff_nomatch(v_it_24365);
          }
        }
        case TAG_Just: {
          V v_it1_24395 = heff_field(v_it_24352, 0);
          heff_take_n(v_it_24352, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24395)) {
          case TAG_MkPair: {
            V v_m_24396 = heff_field(v_it1_24395, 0);
            V v_sp_24397 = heff_field(v_it1_24395, 1);
            heff_take_n(v_it1_24395, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24396, v_sp_24397, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24395);
          }
        }
        default: return heff_nomatch(v_it_24352);
        }
      }
      case TAG_VLam: {
        V v_it_24412;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24400 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24401 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24400)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24400, 0ULL, 1);
            heff_drop(v_sp_24401);
            v_it_24412 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24400, 0ULL, 1);
            heff_drop(v_sp_24401);
            v_it_24412 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24407 = heff_field(v_v1_24400, 0);
            V v_ru_24v1_24400_24HMeta = heff_take_reuse_n(v_v1_24400, 1ULL, 1);
            v_it_24412 = heff_tag_at_n(v_ru_24v1_24400_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24407, v_sp_24401})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24401);
            v_it_24412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24400);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24412 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24412)) {
        case TAG_Nothing: {
          V v_it_24425;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24413 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24414 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24413)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24413, 0ULL, 1);
              heff_drop(v_sp_24414);
              v_it_24425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24413, 0ULL, 1);
              heff_drop(v_sp_24414);
              v_it_24425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24420 = heff_field(v_v1_24413, 0);
              V v_ru_24v1_24413_24HMeta = heff_take_reuse_n(v_v1_24413, 1ULL, 1);
              v_it_24425 = heff_tag_at_n(v_ru_24v1_24413_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24420, v_sp_24414})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24414);
              v_it_24425 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24413);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24425 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24425)) {
          case TAG_Nothing: {
            V v_t_24438;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24426 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24426)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24426);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24451;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24439 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24439)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24439);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24438; V a_7 = v_t_24451; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24452 = heff_field(v_it_24425, 0);
            heff_take_n(v_it_24425, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24452)) {
            case TAG_MkPair: {
              V v_m_24453 = heff_field(v_it1_24452, 0);
              V v_sp_24454 = heff_field(v_it1_24452, 1);
              heff_take_n(v_it1_24452, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24453, v_sp_24454, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24452);
            }
          }
          default: return heff_nomatch(v_it_24425);
          }
        }
        case TAG_Just: {
          V v_it1_24455 = heff_field(v_it_24412, 0);
          heff_take_n(v_it_24412, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24455)) {
          case TAG_MkPair: {
            V v_m_24456 = heff_field(v_it1_24455, 0);
            V v_sp_24457 = heff_field(v_it1_24455, 1);
            heff_take_n(v_it1_24455, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24456, v_sp_24457, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24455);
          }
        }
        default: return heff_nomatch(v_it_24412);
        }
      }
      case TAG_VCons: {
        V v_it_24471;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24459 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24460 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24459)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24459, 0ULL, 1);
            heff_drop(v_sp_24460);
            v_it_24471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24459, 0ULL, 1);
            heff_drop(v_sp_24460);
            v_it_24471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24466 = heff_field(v_v1_24459, 0);
            V v_ru_24v1_24459_24HMeta = heff_take_reuse_n(v_v1_24459, 1ULL, 1);
            v_it_24471 = heff_tag_at_n(v_ru_24v1_24459_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24466, v_sp_24460})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24460);
            v_it_24471 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24459);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24471 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24471)) {
        case TAG_Nothing: {
          V v_it_24484;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24472 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24473 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24472)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24472, 0ULL, 1);
              heff_drop(v_sp_24473);
              v_it_24484 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24472, 0ULL, 1);
              heff_drop(v_sp_24473);
              v_it_24484 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24479 = heff_field(v_v1_24472, 0);
              V v_ru_24v1_24472_24HMeta = heff_take_reuse_n(v_v1_24472, 1ULL, 1);
              v_it_24484 = heff_tag_at_n(v_ru_24v1_24472_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24479, v_sp_24473})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24473);
              v_it_24484 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24472);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24484 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24484)) {
          case TAG_Nothing: {
            V v_t_24497;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24485 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24485)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24485);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24510;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24498 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24498)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24498);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24497; V a_7 = v_t_24510; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24511 = heff_field(v_it_24484, 0);
            heff_take_n(v_it_24484, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24511)) {
            case TAG_MkPair: {
              V v_m_24512 = heff_field(v_it1_24511, 0);
              V v_sp_24513 = heff_field(v_it1_24511, 1);
              heff_take_n(v_it1_24511, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24512, v_sp_24513, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24511);
            }
          }
          default: return heff_nomatch(v_it_24484);
          }
        }
        case TAG_Just: {
          V v_it1_24514 = heff_field(v_it_24471, 0);
          heff_take_n(v_it_24471, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24514)) {
          case TAG_MkPair: {
            V v_m_24515 = heff_field(v_it1_24514, 0);
            V v_sp_24516 = heff_field(v_it1_24514, 1);
            heff_take_n(v_it1_24514, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24515, v_sp_24516, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24514);
          }
        }
        default: return heff_nomatch(v_it_24471);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_it_24536;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24524 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24525 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24524)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24524, 0ULL, 1);
            heff_drop(v_sp_24525);
            v_it_24536 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24524, 0ULL, 1);
            heff_drop(v_sp_24525);
            v_it_24536 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24531 = heff_field(v_v1_24524, 0);
            V v_ru_24v1_24524_24HMeta = heff_take_reuse_n(v_v1_24524, 1ULL, 1);
            v_it_24536 = heff_tag_at_n(v_ru_24v1_24524_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24531, v_sp_24525})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24525);
            v_it_24536 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24524);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24536 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24536)) {
        case TAG_Nothing: {
          V v_it_24549;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24537 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24538 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24537)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24537, 0ULL, 1);
              heff_drop(v_sp_24538);
              v_it_24549 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24537, 0ULL, 1);
              heff_drop(v_sp_24538);
              v_it_24549 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24544 = heff_field(v_v1_24537, 0);
              V v_ru_24v1_24537_24HMeta = heff_take_reuse_n(v_v1_24537, 1ULL, 1);
              v_it_24549 = heff_tag_at_n(v_ru_24v1_24537_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24544, v_sp_24538})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24538);
              v_it_24549 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24537);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24549 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24549)) {
          case TAG_Nothing: {
            V v_t_24562;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24550 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24550)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24550);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24575;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24563 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24563)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24563);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24562; V a_7 = v_t_24575; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24576 = heff_field(v_it_24549, 0);
            heff_take_n(v_it_24549, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24576)) {
            case TAG_MkPair: {
              V v_m_24577 = heff_field(v_it1_24576, 0);
              V v_sp_24578 = heff_field(v_it1_24576, 1);
              heff_take_n(v_it1_24576, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24577, v_sp_24578, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24576);
            }
          }
          default: return heff_nomatch(v_it_24549);
          }
        }
        case TAG_Just: {
          V v_it1_24579 = heff_field(v_it_24536, 0);
          heff_take_n(v_it_24536, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24579)) {
          case TAG_MkPair: {
            V v_m_24580 = heff_field(v_it1_24579, 0);
            V v_sp_24581 = heff_field(v_it1_24579, 1);
            heff_take_n(v_it1_24579, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24580, v_sp_24581, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24579);
          }
        }
        default: return heff_nomatch(v_it_24536);
        }
      }
      case TAG_VCode: {
        V v_it_24595;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24583 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24584 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24583)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24583, 0ULL, 1);
            heff_drop(v_sp_24584);
            v_it_24595 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24583, 0ULL, 1);
            heff_drop(v_sp_24584);
            v_it_24595 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24590 = heff_field(v_v1_24583, 0);
            V v_ru_24v1_24583_24HMeta = heff_take_reuse_n(v_v1_24583, 1ULL, 1);
            v_it_24595 = heff_tag_at_n(v_ru_24v1_24583_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24590, v_sp_24584})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24584);
            v_it_24595 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24583);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24595 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24595)) {
        case TAG_Nothing: {
          V v_it_24608;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24596 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24597 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24596)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24596, 0ULL, 1);
              heff_drop(v_sp_24597);
              v_it_24608 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24596, 0ULL, 1);
              heff_drop(v_sp_24597);
              v_it_24608 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24603 = heff_field(v_v1_24596, 0);
              V v_ru_24v1_24596_24HMeta = heff_take_reuse_n(v_v1_24596, 1ULL, 1);
              v_it_24608 = heff_tag_at_n(v_ru_24v1_24596_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24603, v_sp_24597})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24597);
              v_it_24608 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24596);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24608 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24608)) {
          case TAG_Nothing: {
            V v_t_24621;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24609 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24609)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24609);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24634;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24622 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24622)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24622);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24621; V a_7 = v_t_24634; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24635 = heff_field(v_it_24608, 0);
            heff_take_n(v_it_24608, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24635)) {
            case TAG_MkPair: {
              V v_m_24636 = heff_field(v_it1_24635, 0);
              V v_sp_24637 = heff_field(v_it1_24635, 1);
              heff_take_n(v_it1_24635, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24636, v_sp_24637, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24635);
            }
          }
          default: return heff_nomatch(v_it_24608);
          }
        }
        case TAG_Just: {
          V v_it1_24638 = heff_field(v_it_24595, 0);
          heff_take_n(v_it_24595, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24638)) {
          case TAG_MkPair: {
            V v_m_24639 = heff_field(v_it1_24638, 0);
            V v_sp_24640 = heff_field(v_it1_24638, 1);
            heff_take_n(v_it1_24638, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24639, v_sp_24640, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24638);
          }
        }
        default: return heff_nomatch(v_it_24595);
        }
      }
      case TAG_VLam: {
        V v_it_24655;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24643 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24644 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24643)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24643, 0ULL, 1);
            heff_drop(v_sp_24644);
            v_it_24655 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24643, 0ULL, 1);
            heff_drop(v_sp_24644);
            v_it_24655 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24650 = heff_field(v_v1_24643, 0);
            V v_ru_24v1_24643_24HMeta = heff_take_reuse_n(v_v1_24643, 1ULL, 1);
            v_it_24655 = heff_tag_at_n(v_ru_24v1_24643_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24650, v_sp_24644})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24644);
            v_it_24655 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24643);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24655 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24655)) {
        case TAG_Nothing: {
          V v_it_24668;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24656 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24657 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24656)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24656, 0ULL, 1);
              heff_drop(v_sp_24657);
              v_it_24668 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24656, 0ULL, 1);
              heff_drop(v_sp_24657);
              v_it_24668 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24663 = heff_field(v_v1_24656, 0);
              V v_ru_24v1_24656_24HMeta = heff_take_reuse_n(v_v1_24656, 1ULL, 1);
              v_it_24668 = heff_tag_at_n(v_ru_24v1_24656_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24663, v_sp_24657})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24657);
              v_it_24668 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24656);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24668 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24668)) {
          case TAG_Nothing: {
            V v_t_24681;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24669 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24669)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24669);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24694;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24682 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24682)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24682);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24681; V a_7 = v_t_24694; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24695 = heff_field(v_it_24668, 0);
            heff_take_n(v_it_24668, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24695)) {
            case TAG_MkPair: {
              V v_m_24696 = heff_field(v_it1_24695, 0);
              V v_sp_24697 = heff_field(v_it1_24695, 1);
              heff_take_n(v_it1_24695, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24696, v_sp_24697, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24695);
            }
          }
          default: return heff_nomatch(v_it_24668);
          }
        }
        case TAG_Just: {
          V v_it1_24698 = heff_field(v_it_24655, 0);
          heff_take_n(v_it_24655, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24698)) {
          case TAG_MkPair: {
            V v_m_24699 = heff_field(v_it1_24698, 0);
            V v_sp_24700 = heff_field(v_it1_24698, 1);
            heff_take_n(v_it1_24698, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24699, v_sp_24700, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24698);
          }
        }
        default: return heff_nomatch(v_it_24655);
        }
      }
      case TAG_VCons: {
        V v_it_24714;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24702 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24703 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24702)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24702, 0ULL, 1);
            heff_drop(v_sp_24703);
            v_it_24714 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24702, 0ULL, 1);
            heff_drop(v_sp_24703);
            v_it_24714 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24709 = heff_field(v_v1_24702, 0);
            V v_ru_24v1_24702_24HMeta = heff_take_reuse_n(v_v1_24702, 1ULL, 1);
            v_it_24714 = heff_tag_at_n(v_ru_24v1_24702_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24709, v_sp_24703})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24703);
            v_it_24714 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24702);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24714 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24714)) {
        case TAG_Nothing: {
          V v_it_24727;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24715 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24716 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24715)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24715, 0ULL, 1);
              heff_drop(v_sp_24716);
              v_it_24727 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24715, 0ULL, 1);
              heff_drop(v_sp_24716);
              v_it_24727 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24722 = heff_field(v_v1_24715, 0);
              V v_ru_24v1_24715_24HMeta = heff_take_reuse_n(v_v1_24715, 1ULL, 1);
              v_it_24727 = heff_tag_at_n(v_ru_24v1_24715_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24722, v_sp_24716})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24716);
              v_it_24727 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24715);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24727 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24727)) {
          case TAG_Nothing: {
            V v_t_24740;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24728 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24728)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24728);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24753;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24741 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24741)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24741);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24740; V a_7 = v_t_24753; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24754 = heff_field(v_it_24727, 0);
            heff_take_n(v_it_24727, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24754)) {
            case TAG_MkPair: {
              V v_m_24755 = heff_field(v_it1_24754, 0);
              V v_sp_24756 = heff_field(v_it1_24754, 1);
              heff_take_n(v_it1_24754, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24755, v_sp_24756, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24754);
            }
          }
          default: return heff_nomatch(v_it_24727);
          }
        }
        case TAG_Just: {
          V v_it1_24757 = heff_field(v_it_24714, 0);
          heff_take_n(v_it_24714, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24757)) {
          case TAG_MkPair: {
            V v_m_24758 = heff_field(v_it1_24757, 0);
            V v_sp_24759 = heff_field(v_it1_24757, 1);
            heff_take_n(v_it1_24757, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24758, v_sp_24759, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24757);
          }
        }
        default: return heff_nomatch(v_it_24714);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 2);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_it_24778;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24766 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24767 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24766)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24766, 0ULL, 1);
            heff_drop(v_sp_24767);
            v_it_24778 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24766, 0ULL, 1);
            heff_drop(v_sp_24767);
            v_it_24778 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24773 = heff_field(v_v1_24766, 0);
            V v_ru_24v1_24766_24HMeta = heff_take_reuse_n(v_v1_24766, 1ULL, 1);
            v_it_24778 = heff_tag_at_n(v_ru_24v1_24766_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24773, v_sp_24767})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24767);
            v_it_24778 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24766);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24778 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24778)) {
        case TAG_Nothing: {
          V v_it_24791;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24779 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24780 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24779)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24779, 0ULL, 1);
              heff_drop(v_sp_24780);
              v_it_24791 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24779, 0ULL, 1);
              heff_drop(v_sp_24780);
              v_it_24791 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24786 = heff_field(v_v1_24779, 0);
              V v_ru_24v1_24779_24HMeta = heff_take_reuse_n(v_v1_24779, 1ULL, 1);
              v_it_24791 = heff_tag_at_n(v_ru_24v1_24779_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24786, v_sp_24780})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24780);
              v_it_24791 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24779);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24791 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24791)) {
          case TAG_Nothing: {
            V v_t_24804;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24792 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24792)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24792);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24817;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24805 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24805)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24805);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24804; V a_7 = v_t_24817; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24818 = heff_field(v_it_24791, 0);
            heff_take_n(v_it_24791, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24818)) {
            case TAG_MkPair: {
              V v_m_24819 = heff_field(v_it1_24818, 0);
              V v_sp_24820 = heff_field(v_it1_24818, 1);
              heff_take_n(v_it1_24818, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24819, v_sp_24820, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24818);
            }
          }
          default: return heff_nomatch(v_it_24791);
          }
        }
        case TAG_Just: {
          V v_it1_24821 = heff_field(v_it_24778, 0);
          heff_take_n(v_it_24778, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24821)) {
          case TAG_MkPair: {
            V v_m_24822 = heff_field(v_it1_24821, 0);
            V v_sp_24823 = heff_field(v_it1_24821, 1);
            heff_take_n(v_it1_24821, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24822, v_sp_24823, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24821);
          }
        }
        default: return heff_nomatch(v_it_24778);
        }
      }
      case TAG_VCode: {
        V v_it_24837;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24825 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24826 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24825)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24825, 0ULL, 1);
            heff_drop(v_sp_24826);
            v_it_24837 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24825, 0ULL, 1);
            heff_drop(v_sp_24826);
            v_it_24837 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24832 = heff_field(v_v1_24825, 0);
            V v_ru_24v1_24825_24HMeta = heff_take_reuse_n(v_v1_24825, 1ULL, 1);
            v_it_24837 = heff_tag_at_n(v_ru_24v1_24825_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24832, v_sp_24826})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24826);
            v_it_24837 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24825);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24837 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24837)) {
        case TAG_Nothing: {
          V v_it_24850;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24838 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24839 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24838)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24838, 0ULL, 1);
              heff_drop(v_sp_24839);
              v_it_24850 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24838, 0ULL, 1);
              heff_drop(v_sp_24839);
              v_it_24850 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24845 = heff_field(v_v1_24838, 0);
              V v_ru_24v1_24838_24HMeta = heff_take_reuse_n(v_v1_24838, 1ULL, 1);
              v_it_24850 = heff_tag_at_n(v_ru_24v1_24838_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24845, v_sp_24839})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24839);
              v_it_24850 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24838);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24850 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24850)) {
          case TAG_Nothing: {
            V v_t_24863;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24851 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24851)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24851);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24876;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24864 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24864)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24864);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24863; V a_7 = v_t_24876; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24877 = heff_field(v_it_24850, 0);
            heff_take_n(v_it_24850, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24877)) {
            case TAG_MkPair: {
              V v_m_24878 = heff_field(v_it1_24877, 0);
              V v_sp_24879 = heff_field(v_it1_24877, 1);
              heff_take_n(v_it1_24877, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24878, v_sp_24879, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24877);
            }
          }
          default: return heff_nomatch(v_it_24850);
          }
        }
        case TAG_Just: {
          V v_it1_24880 = heff_field(v_it_24837, 0);
          heff_take_n(v_it_24837, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24880)) {
          case TAG_MkPair: {
            V v_m_24881 = heff_field(v_it1_24880, 0);
            V v_sp_24882 = heff_field(v_it1_24880, 1);
            heff_take_n(v_it1_24880, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24881, v_sp_24882, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24880);
          }
        }
        default: return heff_nomatch(v_it_24837);
        }
      }
      case TAG_VLam: {
        V v_it_24897;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24885 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24886 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24885)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24885, 0ULL, 1);
            heff_drop(v_sp_24886);
            v_it_24897 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24885, 0ULL, 1);
            heff_drop(v_sp_24886);
            v_it_24897 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24892 = heff_field(v_v1_24885, 0);
            V v_ru_24v1_24885_24HMeta = heff_take_reuse_n(v_v1_24885, 1ULL, 1);
            v_it_24897 = heff_tag_at_n(v_ru_24v1_24885_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24892, v_sp_24886})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24886);
            v_it_24897 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24885);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24897 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24897)) {
        case TAG_Nothing: {
          V v_it_24910;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24898 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24899 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24898)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24898, 0ULL, 1);
              heff_drop(v_sp_24899);
              v_it_24910 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24898, 0ULL, 1);
              heff_drop(v_sp_24899);
              v_it_24910 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24905 = heff_field(v_v1_24898, 0);
              V v_ru_24v1_24898_24HMeta = heff_take_reuse_n(v_v1_24898, 1ULL, 1);
              v_it_24910 = heff_tag_at_n(v_ru_24v1_24898_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24905, v_sp_24899})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24899);
              v_it_24910 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24898);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24910 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24910)) {
          case TAG_Nothing: {
            V v_t_24923;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24911 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24911)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24911);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24936;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24924 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24924)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24924);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24923; V a_7 = v_t_24936; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24937 = heff_field(v_it_24910, 0);
            heff_take_n(v_it_24910, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24937)) {
            case TAG_MkPair: {
              V v_m_24938 = heff_field(v_it1_24937, 0);
              V v_sp_24939 = heff_field(v_it1_24937, 1);
              heff_take_n(v_it1_24937, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24938, v_sp_24939, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24937);
            }
          }
          default: return heff_nomatch(v_it_24910);
          }
        }
        case TAG_Just: {
          V v_it1_24940 = heff_field(v_it_24897, 0);
          heff_take_n(v_it_24897, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24940)) {
          case TAG_MkPair: {
            V v_m_24941 = heff_field(v_it1_24940, 0);
            V v_sp_24942 = heff_field(v_it1_24940, 1);
            heff_take_n(v_it1_24940, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24941, v_sp_24942, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24940);
          }
        }
        default: return heff_nomatch(v_it_24897);
        }
      }
      case TAG_VCons: {
        V v_it_24956;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24944 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24945 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24944)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24944, 0ULL, 1);
            heff_drop(v_sp_24945);
            v_it_24956 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24944, 0ULL, 1);
            heff_drop(v_sp_24945);
            v_it_24956 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24951 = heff_field(v_v1_24944, 0);
            V v_ru_24v1_24944_24HMeta = heff_take_reuse_n(v_v1_24944, 1ULL, 1);
            v_it_24956 = heff_tag_at_n(v_ru_24v1_24944_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24951, v_sp_24945})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24945);
            v_it_24956 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24944);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24956 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_it_24956)) {
        case TAG_Nothing: {
          V v_it_24969;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24957 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24958 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24957)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24957, 0ULL, 1);
              heff_drop(v_sp_24958);
              v_it_24969 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24957, 0ULL, 1);
              heff_drop(v_sp_24958);
              v_it_24969 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24964 = heff_field(v_v1_24957, 0);
              V v_ru_24v1_24957_24HMeta = heff_take_reuse_n(v_v1_24957, 1ULL, 1);
              v_it_24969 = heff_tag_at_n(v_ru_24v1_24957_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24964, v_sp_24958})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24958);
              v_it_24969 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24957);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24969 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_it_24969)) {
          case TAG_Nothing: {
            V v_t_24982;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24970 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24970)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24970);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24995;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24983 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24983)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24983);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24982; V a_7 = v_t_24995; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24996 = heff_field(v_it_24969, 0);
            heff_take_n(v_it_24969, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24996)) {
            case TAG_MkPair: {
              V v_m_24997 = heff_field(v_it1_24996, 0);
              V v_sp_24998 = heff_field(v_it1_24996, 1);
              heff_take_n(v_it1_24996, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24997, v_sp_24998, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24996);
            }
          }
          default: return heff_nomatch(v_it_24969);
          }
        }
        case TAG_Just: {
          V v_it1_24999 = heff_field(v_it_24956, 0);
          heff_take_n(v_it_24956, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24999)) {
          case TAG_MkPair: {
            V v_m_241000 = heff_field(v_it1_24999, 0);
            V v_sp_241001 = heff_field(v_it1_24999, 1);
            heff_take_n(v_it1_24999, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_241000, v_sp_241001, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24999);
          }
        }
        default: return heff_nomatch(v_it_24956);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2415);
      heff_drop(v_ms_241);
      heff_drop(v_w_240);
      heff_drop(v_hd_2410);
      heff_drop_rec(v_cs_245, 2);
      heff_drop(v_uf_242);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      V f_ = v_k_2411;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2412);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_b0_247 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam3, 1, 1, (V[]){v_b0_247})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2414, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam4, 1, 9, (V[]){v_x_2412, v_ms_241, v_w_240, v_hd_2410, v_cs_245, v_uf_242, v_k_2411, v_r_243, v_g_244})));
}
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_b0_247 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_r_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_249, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam2, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2410, v_cs_245, v_uf_242, v_k_2411, v_r_243, v_g_244})));
}
Clo g_heff_2eelab_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eelab_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eufEv(a[0]);
}
Clo g_heff_2eelab_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eelab_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at_n(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eelab_2eunify_2euH_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euH_st;
static V g_heff_2eelab_2eunify_2euH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2eunify_2euH_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euH_lam1_clo), ((V)&g_heff_2eelab_2eunify_2euAlg_clo)});
}
V g_heff_2eelab_2eunify_2euH_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euH_st)) return g_heff_2eelab_2eunify_2euH_val;
  return heff_global(&g_heff_2eelab_2eunify_2euH_val, &g_heff_2eelab_2eunify_2euH_st, g_heff_2eelab_2eunify_2euH_init);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_entry, 3, 0};

V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(V v_ms_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam0, 1, 1, (V[]){heff_dup(v_ms_240)})})});
  HEFF_LAST return g_co_2eop_24s1802027244x918867378(v_t_245, heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam1, 1, 2, (V[]){v_hd_241, v_k_242}));
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_ms_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_244 = ({ V a_0 = heff_take_field(v_c_243, 2); V a_1 = v_ms_240; V r_ = (g_list_2efoldl_24s895450532x1092988905(a_0, a_1)); heff_drop(v_ms_240); r_; });
  return ({ V rv_2 = v_ps_244; V rr_ = heff_rec_reuse_n(v_c_243, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_Put, 2, (V[]){v_x_246, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_247}), v_hd_241, v_k_242));
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry, 5, 0};

V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(V v_cs_240, V v_l_241, V v_r_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0, 1, 3, (V[]){v_cs_240, v_l_241, v_r_242})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_248, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec_n(4, shape_shape__left__right__failed, (V[]){v_cs_240, v_l_241, v_r_242, NTAG(TAG_False)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_take_field(v_c_245, 5)});
  return ({ V rv_5 = v_t_247; V rr_ = heff_rec_reuse_n(v_c_245, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2410}), v_hd_243, v_k_244));
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry, 2, 0};

V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24HLocal = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = (g_map_2elookup_24s567992785x1569911877(v_l_242, heff_rfield(v_r_240, 2)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 3);
      V v_t_244 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24HLocal, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_244})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){v_t_245});
    }
    case TAG_Just: {
      V v_l_27_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24HLocal, 1);
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam0, 2, 2, (V[]){v_r_240, v_l_27_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_HGlobal: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam1, 2, 1, (V[]){v_x_2411});
  }
  case TAG_HMeta: {
    V v_ru_24x2_241_24HMeta = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_2415 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){v_t_2416});
  }
  case TAG_HError: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2417 = heff_tag_n(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
    return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_l_27_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V v_t_249 = heff_intSub(heff_get_n(v_r_240, 1, 3), v_l_27_246);
  V v_t_2410 = heff_tag_n(TAG_SLocal, 1, (V[]){heff_intSub(v_t_249, MK_INT(1LL))});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1), heff_take_field(v_pr_242, 2)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nom: {
      V v_a_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2417}));
      break;
    }
    case TAG_Describe: {
      V v_a_2418 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2418}));
      break;
    }
    case TAG_Become: {
      V v_a_2419 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419});
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_a_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2428}));
      break;
    }
    case TAG_Describe: {
      V v_a_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2429}));
      break;
    }
    case TAG_Become: {
      V v_a_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_2411, v_a_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_a_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0, 2, 0};
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_call(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1, 2, 8, (V[]){v_g_240, v_m_241, v_pr_2413, v_ty_2411, v_pr_242, v_i_243, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3(V self, V *args) {
  V v_u_2418 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_v_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return v_v_2419;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2414 = heff_env(self)[7];
  V v_k_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2417 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  V v_v_2419 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2417}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2421 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4, 1, 1, (V[]){v_v_2419})}), v_rest_249));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5, 1, 2, (V[]){v_k_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2413 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_i_243 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411), heff_dup(v_hd_2414), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2414, v_k_2415})));
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0, 2, 0};
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry, 2, 0};

V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(v_f_240, v_xs_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0, 1, 1, (V[]){v_t0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})));
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  V f_ = v_c_2418;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2422));
  V f_ = v_c_2423;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2432 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2431));
  V f_ = v_c_2432;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2434 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_implicit_2437 = heff_env(self)[3];
  V v_dflt_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2434, v_x_2439, v_x_2441, v_implicit_2437, v_dflt_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2435 = heff_env(self)[3];
  V v_cod_2436 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2434 = heff_env(self)[7];
  V v_implicit_2437 = heff_env(self)[8];
  V v_dflt_2438 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2440 = (g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(v_g_240, v_m_241, v_pr_242, v_dom_2435, v_cod_2436));
  V f_ = v_c_2440;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10, 1, 5, (V[]){v_k_245, v_level_2434, v_x_2439, v_implicit_2437, v_dflt_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11(V self, V *args) {
  V v_x_2448 = args[0];
  V v_fieldTypes_2444 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2442 = heff_env(self)[2];
  V v_defaults_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = ({ V rv_2 = heff_arrayFromList(v_x_2448); V rr_ = heff_rec_reuse_n(v_fieldTypes_2444, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2442, v_t_2449, v_defaults_2445});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13(V self, V *args) {
  V v_a_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2458 = heff_tr(heff_call(v_a_2457, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2458;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_k_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2455, heff_arrayFromList(v_x_2462)});
  V f_ = v_k_2461;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2459;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15, 1, 2, (V[]){v_k_2455, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12(V self, V *args) {
  V v_p_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2454)) {
  case TAG_MkPair: {
    V v_k_2455 = heff_field(v_p_2454, 0);
    V v_args_2456 = heff_field(v_p_2454, 1);
    heff_take_n(v_p_2454, 3ULL, 2);
    V v_c_2459 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2456)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14, 2, 2, (V[]){v_c_2459, v_k_2455});
  }
  default: return heff_nomatch(v_p_2454);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2465)));
  V v_t_2467 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2465));
  V v_t_2468 = (g_list_2emap_24s1173914895x100384474(v_x_2465));
  V v_t_2469 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2466), v_t_2467, heff_arrayFromList(v_t_2468)});
  V v_x_2470 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2469});
  V f_ = v_k_245;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2472});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_VU: {
    V v_u_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_249});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2410 = heff_field(v_x_248, 0);
    V v_sp_2411 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2416;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2421 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2421;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2425 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_m_27_2425), heff_dup(v_m_241))) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2425);
        V v_t_2427 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2428 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
        return (g_co_2eop_24s1802027244x918867378(v_t_2428, v_hd_244, v_k_245));
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2425; V a_4 = v_sp_2411; V a_5 = v_hd_244; V a_6 = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6, 1, 1, (V[]){v_k_245}); V r_ = (g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2411); r_; });
      }
    }
    case TAG_HError: {
      V v_c_2430 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      V f_ = v_c_2430;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VFunction: {
    V v_level_2434 = heff_field(v_x_248, 0);
    V v_dom_2435 = heff_field(v_x_248, 1);
    V v_cod_2436 = heff_field(v_x_248, 2);
    V v_implicit_2437 = heff_field(v_x_248, 3);
    V v_dflt_2438 = heff_field(v_x_248, 4);
    heff_take_n(v_x_248, 31ULL, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2435), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2435, v_cod_2436, v_hd_244, v_k_245, v_level_2434, v_implicit_2437, v_dflt_2438})));
  }
  case TAG_VRecord: {
    V v_level_2442 = heff_field(v_x_248, 0);
    V v_capture_2443 = heff_field(v_x_248, 1);
    V v_fieldTypes_2444 = heff_field(v_x_248, 2);
    V v_defaults_2445 = heff_field(v_x_248, 3);
    heff_take_n(v_x_248, 15ULL, 4);
    V v_t_2446 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2444, 2)));
    V v_c_2447 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2443, v_t_2446));
    V f_ = v_c_2447;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11, 1, 4, (V[]){v_fieldTypes_2444, v_k_245, v_level_2442, v_defaults_2445});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_vs_2450 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2451 = heff_arrayToList(heff_take_field(v_vs_2450, 0));
    V v_t_2452 = heff_arrayToList(heff_get_n(v_vs_2450, 2, 3));
    V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
    V v_c_2464 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2453));
    V f_ = v_c_2464;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2471 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_a_2471, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2473 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2473});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0, 1, 0};
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry, 5, 0};

V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(V v_entry_240, V v_arity_241, V v_ty_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_246, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam1, 1, 5, (V[]){v_entry_240, v_arity_241, v_ty_242, v_hd_243, v_k_244})));
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0(V self, V *args) {
  V v_c_245 = args[0];
  return heff_get_n(v_c_245, 4, 8);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_244;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2411}), v_hd_243, heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam3, 1, 2, (V[]){v_k_244, v_x_247})));
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_entry_240 = heff_env(self)[0];
  V v_arity_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_240, v_arity_241, v_ty_242}));
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s1802027244x918867378(v_t_249, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_247})));
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry, 5, 0};

V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(V v_m_240, V v_sol_241, V v_stx_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2410, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam1, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_240), heff_rfield(v_c_245, 3)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_sol_241);
    heff_drop(v_stx_242);
    return v_c_245;
  }
  case TAG_Just: {
    V v_e_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_248 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_sol_241}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_stx_242}); V rr_ = heff_rec_reuse_n(v_e_247, 57ULL, 6, shape_ty__sol__solStx__arity__name__span); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_mc_249 = (g_map_2einsert_24s1689409319x1710080871(v_m_240, v_t_248, heff_take_field(v_c_245, 3)));
    return ({ V rv_3 = v_mc_249; V rr_ = heff_rec_reuse_n(v_c_245, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2412}), v_hd_243, v_k_244));
}
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str1, 1, "\?");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str3, 5, ") := ");
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry, 4, 0};

V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(V v_m_240, V v_stx_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam0, 1, 2, (V[]){v_m_240, v_stx_241})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  V v_m_240 = heff_env(self)[2];
  V v_e_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_247);
  V v_t_248 = ({ V b_0 = heff_get_n(v_c_244, 3, 8); V r_ = (g_heff_2eelab_2eunify_2ezonker(b_0)); heff_drop(b_0); r_; });
  V v_e_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 1, (V[]){v_stx_241}));
  V v_t_2410 = (g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_249));
  return heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str1), heff_strAppend(heff_intShow(v_m_240), heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str2), heff_strAppend(heff_get_n(v_e_246, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str3), v_t_2410)))));
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam0(V self, V *args) {
  V v_c_244 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_240), heff_rfield(v_c_244, 3)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_stx_241);
    return v_c_244;
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2411 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_246, 5)), ((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str0), heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam1, 1, 4, (V[]){heff_dup(v_c_244), v_stx_241, v_m_240, v_e_246})});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_take_field(v_c_244, 6)});
    return ({ V rv_6 = v_t_2412; V rr_ = heff_rec_reuse_n(v_c_244, 191ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2415}), v_hd_242, v_k_243));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_map_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2(V self, V *args) {
  V v_i_2417 = args[0];
  V v_n_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_244, v_i_2417), MK_INT(1LL));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V f_ = v_k_247;
  args[0] = v_v_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2420 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2425 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2426);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(v_storeM_242, v_t_2420, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam4, 1, 2, (V[]){v_k_247, v_v_2425})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2, 1, 1, (V[]){heff_dup(v_n_244)}), v_kept_245));
  V v_t_2419 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2416, heff_arrayFromList(v_t_2418), v_x_249});
  V v_t_2420 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2419));
  V v_x1_2421 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2420), NTAG(TAG_LNil)));
  V v_v_2425;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_x_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_v_2425 = v_x_2422;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2421, 0ULL, 1);
    v_v_2425 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    v_v_2425 = v_x_2424;
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(heff_dup(v_storeM_242), heff_dup(v_v_2425), heff_dup(v_t_2420), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3, 1, 5, (V[]){v_storeM_242, v_t_2420, v_hd_246, v_k_247, v_v_2425})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return (g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(v_entry_243, v_t_2410, v_t_2415, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_248, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam1, 1, 7, (V[]){v_hd_245, heff_dup(v_sp_244), v_k_246, v_pr_242, v_g_240, v_m_241, v_m_27_243})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam4(V self, V *args) {
  V v_a_2421 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425;
  switch (heff_tag_of(v_a_2421)) {
  case TAG_PVar: {
    V v_l_2422 = heff_field(v_a_2421, 0);
    heff_take_n(v_a_2421, 1ULL, 1);
    V v_x3_2423 = ({ V a_0 = v_l_2422; V b_1 = heff_get_n(v_pr_242, 2, 3); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2423)) {
    case TAG_Nothing: {
      v_x1_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2423, 0ULL, 1);
      v_x1_2425 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2423);
    }
    break;
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    v_x1_2425 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2421);
  }
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam6(V self, V *args) {
  V v_i_2429 = args[0];
  V v_a_2430 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2430)) {
  case TAG_PVar: {
    V v_l_2431 = heff_field(v_a_2430, 0);
    V v_ru_24a_2430_24PVar = heff_take_reuse_n(v_a_2430, 1ULL, 1);
    V v_x3_2432 = ({ V a_0 = v_l_2431; V b_1 = heff_get_n(v_pr_242, 2, 3); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2432)) {
    case TAG_Nothing: {
      heff_drop(v_i_2429);
      heff_drop_cell(v_ru_24a_2430_24PVar, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2432, 0ULL, 1);
      return heff_tag_at_n(v_ru_24a_2430_24PVar, TAG_Just, 1, (V[]){v_i_2429});
    }
    default: return heff_nomatch(v_x3_2432);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2429);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2430);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2438 = ({ V a_0 = v_x_2437; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2438, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_args_2420 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2428 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2420));
  V v_t_2434 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2420));
  V v_t_2435 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2434));
  V v_c_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo), 6, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2427, v_t_2428, v_t_2435}));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8(V self, V *args) {
  V v_c_2440 = args[0];
  return heff_get_n(v_c_2440, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = ({ V a_0 = v_m_27_243; V a_1 = v_x_2442; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2442); r_; });
  switch (heff_tag_of(v_t_2443)) {
  case TAG_Nothing: {
    V v_t_2444 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2445, v_hd_245, v_k_2439));
  }
  case TAG_Just: {
    V v_e_2446 = heff_field(v_t_2443, 0);
    heff_take_n(v_t_2443, 1ULL, 1);
    heff_drop(v_hd_245);
    V f_ = v_k_2439;
    args[0] = v_e_2446;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2443);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam13(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2455);
  V v_t_2457 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2454);
  V f_ = v_k_2456;
  args[0] = heff_intSub(v_t_2457, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam12(V self, V *args) {
  V v_a_2449 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2449)) {
  case TAG_PVar: {
    V v_l_2450 = heff_field(v_a_2449, 0);
    V v_ru_24a_2449_24PVar = heff_take_reuse_n(v_a_2449, 1ULL, 1);
    V v_t_2451 = (g_map_2elookup_24s567992785x1569911877(v_l_2450, heff_rfield(v_pr_242, 2)));
    switch (heff_tag_of(v_t_2451)) {
    case TAG_Nothing: {
      heff_drop_rec(v_pr_242, 3);
      V v_t_2452 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2453 = heff_tag_at_n(v_ru_24a_2449_24PVar, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
      V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
      args[0] = v_t_2453;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_l_27_2454 = heff_field(v_t_2451, 0);
      heff_take_n(v_t_2451, 1ULL, 1);
      heff_drop_cell(v_ru_24a_2449_24PVar, 1);
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2454});
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    V v_t_2458 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2459;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_2449);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam14(V self, V *args) {
  V v_x_2461 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2448 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2462 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2461), v_x_2448});
  V f_ = v_k_246;
  args[0] = v_t_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam11(V self, V *args) {
  V v_x_2448 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2420 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2460 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam12, 1, 1, (V[]){v_pr_242}), v_args_2420));
  V f_ = v_c_2460;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam14, 1, 3, (V[]){v_m_27_243, v_x_2448, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam10(V self, V *args) {
  V v_x_2447 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2420 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2447, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam11, 1, 5, (V[]){v_pr_242, v_args_2420, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15(V self, V *args) {
  V v_c_2464 = args[0];
  return heff_get_n(v_c_2464, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam16(V self, V *args) {
  V v_x_2466 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2467 = ({ V a_0 = v_m_27_243; V a_1 = v_x_2466; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2466); r_; });
  switch (heff_tag_of(v_t_2467)) {
  case TAG_Nothing: {
    V v_t_2468 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2469, v_hd_245, v_k_2463));
  }
  case TAG_Just: {
    V v_e_2470 = heff_field(v_t_2467, 0);
    heff_take_n(v_t_2467, 1ULL, 1);
    heff_drop(v_hd_245);
    V f_ = v_k_2463;
    args[0] = v_e_2470;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2467);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  V v_m_241 = heff_env(self)[6];
  V v_m_27_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = ({ V a_0 = v_x_2412; V a_1 = v_x_249; V a_2 = v_sp_244; V r_ = (g_heff_2eelab_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_249); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2417 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2414)));
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2415); r_; });
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_t_2417 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2414))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2414);
      heff_drop_cell(v_ru_24t_2413_24Just, 1);
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    heff_drop(v_sp_244);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_m_27_243);
    V v_t_2418 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2419, v_hd_245, v_k_246));
  }
  case TAG_Just: {
    V v_args_2420 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    V v_t_2426 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2420));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      V v_k_2439 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam5, 1, 8, (V[]){v_args_2420, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
      V v_t_2441 = heff_tag_at_n(v_ru_24t_2417_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8_clo)})});
      return (g_co_2eop_24s1802027244x918867378(v_t_2441, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam9, 1, 3, (V[]){v_m_27_243, v_hd_245, v_k_2439})));
    }
    case TAG_False: {
      heff_drop(v_sp_244);
      V v_k_2463 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2420, heff_dup(v_m_27_243), v_k_246});
      V v_t_2465 = heff_tag_at_n(v_ru_24t_2417_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15_clo)})});
      return (g_co_2eop_24s1802027244x918867378(v_t_2465, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam16, 1, 3, (V[]){v_m_27_243, v_hd_245, v_k_2463})));
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_m_241 = heff_env(self)[5];
  V v_m_27_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2411, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam3, 1, 8, (V[]){v_x_249, v_sp_244, v_hd_245, v_k_246, v_pr_242, v_g_240, v_m_241, v_m_27_243})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1), heff_take_field(v_pr_242, 2)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_v_2416)) {
    case TAG_Nom: {
      V v_v_2417 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2417}));
      break;
    }
    case TAG_Describe: {
      V v_v_2418 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2418}));
      break;
    }
    case TAG_Become: {
      V v_v_2419 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419});
      break;
    }
    default: heff_nomatch(v_v_2416);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_v_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2428}));
      break;
    }
    case TAG_Describe: {
      V v_v_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2429}));
      break;
    }
    case TAG_Become: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_2411, v_v_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0, 1, 1, (V[]){v_v0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})));
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2416));
  V f_ = v_t_2417;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2427));
  V f_ = v_t_2428;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2434, v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_fty_2431 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2432 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2435 = heff_tr(heff_call(v_fty_2431, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2436 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2435)));
  V v_t_2448;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2439 = heff_field(v_t_2436, 1);
    heff_take_n(v_t_2436, 2ULL, 4);
    heff_drop(v_t_2435);
    v_t_2448 = v_dom_2439;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2436, 0ULL, 3);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeInt: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeString: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeRune: {
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2436, 0ULL, 1);
    v_t_2448 = v_t_2435;
    break;
  }
  case TAG_NoRules: {
    v_t_2448 = v_t_2435;
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  V v_c_2449 = (g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(v_g_240, v_m_241, v_pr_242, v_t_2448, v_body_2432));
  V f_ = v_c_2449;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7, 1, 2, (V[]){v_k_245, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2462;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2460 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2460, v_hd_2461, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10, 1, 1, (V[]){v_k_2462})));
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_2466 = heff_env(self)[0];
  V v_k_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2456, v_x_2467});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_c_2464 = heff_env(self)[0];
  V v_k_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2464;
  args[0] = v_hd_2465;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12, 1, 2, (V[]){v_k_2466, v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8(V self, V *args) {
  V v_p_2455 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2455)) {
  case TAG_MkPair: {
    V v_k_2456 = heff_field(v_p_2455, 0);
    V v_x_2457 = heff_field(v_p_2455, 1);
    heff_take_n(v_p_2455, 3ULL, 2);
    V v_c_2464;
    switch (heff_tag_of(v_x_2457)) {
    case TAG_Nom: {
      V v_v_2458 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      v_c_2464 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2458}));
      break;
    }
    case TAG_Describe: {
      V v_v_2459 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      v_c_2464 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2459}));
      break;
    }
    case TAG_Become: {
      V v_v_2460 = heff_field(v_x_2457, 0);
      heff_take_n(v_x_2457, 1ULL, 1);
      v_c_2464 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2460});
      break;
    }
    default: heff_nomatch(v_x_2457);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11, 2, 2, (V[]){v_c_2464, v_k_2456});
  }
  default: return heff_nomatch(v_p_2455);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13(V self, V *args) {
  V v_x_2469 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2469)));
  V v_t_2471 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2469));
  V v_t_2472 = (g_list_2emap_24s1173914895x100384474(v_x_2469));
  V v_t_2473 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2470), v_t_2471, heff_arrayFromList(v_t_2472)});
  V v_x_2474 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2473});
  V f_ = v_k_245;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_VNeu: {
    V v_it1_249 = heff_field(v_x_248, 0);
    V v_sp_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 5);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_HLocal: {
      V v_c_2415 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      V f_ = v_c_2415;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2419 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      V f_ = v_c_2419;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2422 = heff_field(v_it1_249, 0);
      V v_ru_24it1_249_24HMeta = heff_take_reuse_n(v_it1_249, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_m_27_2422), heff_dup(v_m_241))) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2410);
        heff_drop(v_m_27_2422);
        V v_t_2424 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2425 = heff_tag_at_n(v_ru_24it1_249_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
        return (g_co_2eop_24s1802027244x918867378(v_t_2425, v_hd_244, v_k_245));
      } else {
        heff_drop_cell(v_ru_24it1_249_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2422; V a_4 = v_sp_2410; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2410); r_; });
      }
    }
    case TAG_HError: {
      V v_c_2426 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      V f_ = v_c_2426;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_VCode: {
    V v_t_2429 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_t_2429, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2431 = heff_field(v_x_248, 0);
    V v_body_2432 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2433 = heff_tr(heff_call(heff_dup(v_fty_2431), 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2433, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6, 1, 7, (V[]){v_fty_2431, v_g_240, v_m_241, v_pr_242, v_body_2432, v_hd_244, v_k_245})));
  }
  case TAG_VCons: {
    V v_d_2451 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2452 = heff_arrayToList(heff_take_field(v_d_2451, 0));
    V v_t_2453 = heff_arrayToList(heff_get_n(v_d_2451, 2, 3));
    V v_t_2454 = (g_heff_2eutil_2edict_2ezipKV(v_t_2452, v_t_2453));
    V v_c_2468 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2454));
    V f_ = v_c_2468;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam4(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam0, 2, 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244}), ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2431, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam4, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_pr_2410 = heff_env(self)[2];
  V v_rhs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_242, v_pr_2410, v_rhs_244, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam1, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2(V self, V *args) {
  V v_e_2414 = args[0];
  switch (heff_tag_of(v_e_2414)) {
  case TAG_UnequalTys: {
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_e_2414})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_UnequalEls: {
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_e_2414})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_UnequalNeus: {
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_e_2414})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2428;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_MentionsError: {
    return ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3_clo);
  }
  default: return heff_nomatch(v_e_2414);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam6(V self, V *args) {
  V v_c_2442 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2443 = ({ V a_0 = v_m_242; V b_1 = heff_get_n(v_c_2442, 2, 8); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2443)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2443, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2443);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9(V self, V *args) {
  V v_c_2449 = args[0];
  return heff_get_n(v_c_2449, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10(V self, V *args) {
  V v_x_2451 = args[0];
  V v_v_2440 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_k_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2452 = ({ V a_0 = v_x_2451; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2451); r_; });
  V v_t_2453 = heff_tr(heff_call(heff_get_n(v_t_2452, 0, 3), 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2440}));
  return ({ V a_0 = v_t_2453; V a_1 = v_hd_2447; V a_2 = v_k_2448; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam8(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_v_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2450, heff_dup(v_hd_2447), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10, 1, 3, (V[]){v_v_2440, v_hd_2447, v_k_2448})));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  heff_drop(v_hd_2454);
  V f_ = v_k_2455;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12(V self, V *args) {
  V v_x_2457 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2435 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2457);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(v_m_242, v_t_2435, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam7(V self, V *args) {
  V v_x_2446 = args[0];
  V v_v_2440 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2435 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2456;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_True: {
    v_c_2456 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam8, 2, 1, (V[]){v_v_2440});
    break;
  }
  case TAG_False: {
    heff_drop(v_v_2440);
    v_c_2456 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11_clo);
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  V f_ = v_c_2456;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12, 1, 4, (V[]){v_m_242, v_t_2435, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2440 = heff_env(self)[2];
  V v_t_2435 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2441);
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam6, 1, 1, (V[]){heff_dup(v_m_242)})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2445, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam7, 1, 5, (V[]){v_v_2440, v_z_245, v_m_242, v_t_2435, v_z_246})));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop(v_z_245);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2433 = heff_field(v_x_2432, 0);
    heff_take_n(v_x_2432, 1ULL, 1);
    V v_t_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2435 = (g_heff_2eelab_2eunify_2elamsU(v_t_2434, v_body_2433));
    V v_x1_2436 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2435), NTAG(TAG_LNil)));
    V v_v_2440;
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_Nom: {
      V v_x_2437 = heff_field(v_x1_2436, 0);
      heff_take_n(v_x1_2436, 1ULL, 1);
      v_v_2440 = v_x_2437;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2436, 0ULL, 1);
      v_v_2440 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2439 = heff_field(v_x1_2436, 0);
      heff_take_n(v_x1_2436, 1ULL, 1);
      v_v_2440 = v_x_2439;
      break;
    }
    default: heff_nomatch(v_x1_2436);
    }
    return (g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(heff_dup(v_m_242), heff_dup(v_v_2440), heff_dup(v_t_2435), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam5, 1, 5, (V[]){v_m_242, v_z_245, v_v_2440, v_t_2435, v_z_246})));
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_249, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam1, 1, 8, (V[]){v_hd_246, heff_dup(v_sp_243), v_cs_241, v_self_245, v_rhs_244, v_k_247, v_g_240, v_m_242})));
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam5(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2453);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam4(V self, V *args) {
  V v_x_2447 = args[0];
  V v_args_2419 = heff_env(self)[0];
  V v_args_27_2442 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2448 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2419));
  V v_t_2449 = (g_heff_2eelab_2eunify_2ezipL(v_args_2419, v_args_27_2442));
  V v_t_2450 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(MK_INT(0LL), v_t_2449));
  V v_t_2451 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2450));
  V v_c_2452 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo), 6, (V[]){v_g_240, heff_dup(v_m_242), v_m_242, v_x_2447, v_t_2448, v_t_2451}));
  V f_ = v_c_2452;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam5, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6(V self, V *args) {
  V v_c_2455 = args[0];
  return heff_get_n(v_c_2455, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam7(V self, V *args) {
  V v_x_2457 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2458 = ({ V a_0 = v_m_242; V a_1 = v_x_2457; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2457); r_; });
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Nothing: {
    V v_t_2459 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2460, v_hd_246, v_k_2454));
  }
  case TAG_Just: {
    V v_e_2461 = heff_field(v_t_2458, 0);
    heff_take_n(v_t_2458, 1ULL, 1);
    heff_drop(v_hd_246);
    V f_ = v_k_2454;
    args[0] = v_e_2461;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2458);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_g_240 = heff_env(self)[7];
  V v_m_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = ({ V a_0 = heff_dup(v_x_2413); V a_1 = v_x_2410; V a_2 = v_sp_243; V r_ = (g_heff_2eelab_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_sp_243); r_; });
  V v_t_2418;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2415 = heff_field(v_t_2414, 0);
    V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
    V v_t_2416 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2415)));
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2416); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_t_2418 = heff_tag_at_n(v_ru_24t_2414_24Just, TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2415))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2415);
      heff_drop_cell(v_ru_24t_2414_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nothing: {
    heff_drop(v_x_2413);
    heff_drop(v_x_2410);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    return (g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_args_2419 = heff_field(v_t_2418, 0);
    V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 1ULL, 1);
    V v_it_2432;
    switch (heff_tag_of(v_rhs_244)) {
    case TAG_VNeu: {
      V v_v1_2420 = heff_dup(heff_field(v_rhs_244, 0));
      V v_sp_2421 = heff_dup(heff_field(v_rhs_244, 1));
      switch (heff_tag_of(v_v1_2420)) {
      case TAG_HLocal: {
        heff_take_n(v_v1_2420, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2418_24Just, 1);
        heff_drop(v_sp_2421);
        v_it_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_v1_2420, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2418_24Just, 1);
        heff_drop(v_sp_2421);
        v_it_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2427 = heff_field(v_v1_2420, 0);
        heff_take_n(v_v1_2420, 1ULL, 1);
        v_it_2432 = heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2427, v_sp_2421})});
        break;
      }
      case TAG_HError: {
        heff_drop_cell(v_ru_24t_2418_24Just, 1);
        heff_drop(v_sp_2421);
        v_it_2432 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_v1_2420);
      }
      break;
    }
    case TAG_VCode: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VLam: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VCons: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VOpaque: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_rhs_244);
    }
    switch (heff_tag_of(v_it_2432)) {
    case TAG_Nothing: {
      heff_drop(v_x_2413);
      heff_drop(v_x_2410);
      heff_drop(v_self_245);
      return (g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(v_g_240, v_cs_241, v_m_242, v_args_2419, v_rhs_244, v_hd_246, v_k_247));
    }
    case TAG_Just: {
      V v_it1_2433 = heff_field(v_it_2432, 0);
      V v_ru_24it_2432_24Just = heff_take_reuse_n(v_it_2432, 1ULL, 1);
      switch (heff_tag_of(v_it1_2433)) {
      case TAG_MkPair: {
        V v_m_27_2434 = heff_field(v_it1_2433, 0);
        V v_sp_27_2435 = heff_field(v_it1_2433, 1);
        heff_take_n(v_it1_2433, 3ULL, 2);
        if (heff_intEq_c(v_m_27_2434, heff_dup(v_m_242))) {
          V v_t_2437 = ({ V a_0 = v_x_2413; V a_1 = v_x_2410; V a_2 = v_sp_27_2435; V r_ = (g_heff_2eelab_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2410); heff_drop(v_sp_27_2435); r_; });
          V v_t_2441;
          switch (heff_tag_of(v_t_2437)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24it_2432_24Just, 1);
            v_t_2441 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_items_2438 = heff_field(v_t_2437, 0);
            heff_take_n(v_t_2437, 1ULL, 1);
            V v_t_2439 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2438)));
            V v_t_2440 = ({ V a_0 = v_t_2439; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2439); r_; });
            switch (heff_tag_of(v_t_2440)) {
            case TAG_True: {
              v_t_2441 = heff_tag_at_n(v_ru_24it_2432_24Just, TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2438))});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2432_24Just, 1);
              heff_drop(v_items_2438);
              v_t_2441 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2440);
            }
            break;
          }
          default: heff_nomatch(v_t_2437);
          }
          switch (heff_tag_of(v_t_2441)) {
          case TAG_Nothing: {
            heff_drop(v_g_240);
            heff_drop(v_m_242);
            heff_drop(v_args_2419);
            return (g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_Just: {
            V v_args_27_2442 = heff_field(v_t_2441, 0);
            V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 1ULL, 1);
            V v_t_2443 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2442, v_args_2419));
            switch (heff_tag_of(v_t_2443)) {
            case TAG_True: {
              heff_drop(v_cs_241);
              heff_drop(v_self_245);
              heff_drop(v_rhs_244);
              heff_drop(v_hd_246);
              heff_drop(v_g_240);
              heff_drop(v_m_242);
              heff_drop(v_args_2419);
              heff_drop(v_args_27_2442);
              heff_drop_cell(v_ru_24t_2441_24Just, 1);
              V f_ = v_k_247;
              args[0] = NTAG(TAG_MkUnit);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_False: {
              V v_t_2444 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_27_2442));
              V v_t_2445 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2419));
              if (heff_intEq_c(v_t_2444, v_t_2445)) {
                heff_drop(v_cs_241);
                heff_drop(v_self_245);
                heff_drop(v_rhs_244);
                V v_k_2454 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam4, 1, 6, (V[]){v_args_2419, v_args_27_2442, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                V v_t_2456 = heff_tag_at_n(v_ru_24t_2441_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6_clo)})});
                return (g_co_2eop_24s1802027244x918867378(v_t_2456, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam7, 1, 3, (V[]){v_m_242, v_hd_246, v_k_2454})));
              } else {
                heff_drop(v_g_240);
                heff_drop(v_m_242);
                heff_drop(v_args_2419);
                heff_drop(v_args_27_2442);
                heff_drop_cell(v_ru_24t_2441_24Just, 1);
                return (g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
              }
            }
            default: return heff_nomatch(v_t_2443);
            }
          }
          default: return heff_nomatch(v_t_2441);
          }
        } else {
          heff_drop(v_x_2413);
          heff_drop(v_x_2410);
          heff_drop(v_self_245);
          heff_drop_cell(v_ru_24it_2432_24Just, 1);
          heff_drop(v_sp_27_2435);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(v_g_240, v_cs_241, v_m_242, v_args_2419, v_rhs_244, v_hd_246, v_k_247));
        }
      }
      default: return heff_nomatch(v_it1_2433);
      }
    }
    default: return heff_nomatch(v_it_2432);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_m_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2412, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam3, 1, 9, (V[]){v_x_2410, v_sp_243, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247, v_g_240, v_m_242})));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4, 4, 0};

static V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st;
static V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_init(void) {
  return heff_rec_n(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo), ((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_clo), ((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1_clo), ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4_clo), ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo)});
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st)) return g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val;
  return heff_global(&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val, &g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_init);
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0_clo);
  }
  case TAG_False: {
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1_clo);
        }
        case TAG_False: {
          V v_t_2424 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
          return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
        }
        default: return heff_nomatch(v_t_2421);
        }
      }
      case TAG_SpApp: {
        V v_t_2427 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      }
      case TAG_SpProj: {
        V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
      }
      case TAG_SpSpec: {
        V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2435 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2436 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2435);
        heff_drop(v_v_2436);
        V v_t_2437 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      }
      case TAG_SpApp: {
        V v_sq_27_2438 = heff_field(v_sp_27_245, 0);
        V v_v_27_2439 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2440 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2435, v_h_27_244, v_sq_27_2438));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam2, 2, 5, (V[]){v_c_2440, v_g_240, v_cs_241, v_v_2436, v_v_27_2439});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2435);
        heff_drop(v_v_2436);
        V v_t_2447 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2435);
        heff_drop(v_v_2436);
        V v_t_2451 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2452 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2453 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2452);
        heff_drop(v_x_2453);
        V v_t_2454 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2452);
        heff_drop(v_x_2453);
        V v_t_2457 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
      }
      case TAG_SpProj: {
        V v_sq_27_2458 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2459 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2460 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2452, heff_dup(v_h_27_244), v_sq_27_2458));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam4, 2, 8, (V[]){v_c_2460, v_x_2453, v_x_27_2459, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2452);
        heff_drop(v_x_2453);
        V v_t_2469 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_2470 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2471 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_2472 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2470);
        heff_drop(v_x_2471);
        heff_drop(v_v_2472);
        V v_t_2473 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2470);
        heff_drop(v_x_2471);
        heff_drop(v_v_2472);
        V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2470);
        heff_drop(v_x_2471);
        heff_drop(v_v_2472);
        V v_t_2479 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
      }
      case TAG_SpSpec: {
        V v_sq_27_2480 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2481 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_2482 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_2483 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2470, heff_dup(v_h_27_244), v_sq_27_2480));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam6, 2, 11, (V[]){v_c_2483, v_x_2471, v_x_27_2481, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_2472, v_v_27_2482});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2436 = heff_env(self)[2];
  V v_v_27_2439 = heff_env(self)[3];
  V v_hd_2441 = heff_env(self)[4];
  V v_k_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2443);
  V v_t_2444 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_v_2436, v_v_27_2439));
  V f_ = v_t_2444;
  heff_room[0] = v_hd_2441;
  heff_room[1] = v_k_2442;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam2(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2436 = heff_env(self)[3];
  V v_v_27_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam3, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2436, v_v_27_2439, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2453 = heff_env(self)[0];
  V v_x_27_2459 = heff_env(self)[1];
  V v_k_2462 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2461 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2463);
  if (heff_strEq_c(v_x_2453, v_x_27_2459)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop(v_hd_2461);
    V f_ = v_k_2462;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2465 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), v_hd_2461, v_k_2462));
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam4(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_c_2460 = heff_env(self)[0];
  V v_x_2453 = heff_env(self)[1];
  V v_x_27_2459 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2460;
  args[0] = heff_dup(v_hd_2461);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam5, 1, 9, (V[]){v_x_2453, v_x_27_2459, v_k_2462, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  heff_drop(v_hd_2488);
  V f_ = v_k_2489;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam9(V self, V *args) {
  V v_x_2492 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2472 = heff_env(self)[2];
  V v_v_27_2482 = heff_env(self)[3];
  V v_hd_2484 = heff_env(self)[4];
  V v_k_2485 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2492);
  V v_t_2493 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_v_2472, v_v_27_2482));
  V f_ = v_t_2493;
  heff_room[0] = v_hd_2484;
  heff_room[1] = v_k_2485;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam7(V self, V *args) {
  V v_x_2486 = args[0];
  V v_x_2471 = heff_env(self)[0];
  V v_x_27_2481 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_2484 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_2472 = heff_env(self)[9];
  V v_v_27_2482 = heff_env(self)[10];
  V v_k_2485 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2486);
  V v_c_2491;
  if (heff_strEq_c(v_x_2471, v_x_27_2481)) {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_c_2491 = ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8_clo);
  } else {
    V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    v_c_2491 = heff_tr(heff_call(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
  }
  V f_ = v_c_2491;
  heff_room[0] = heff_dup(v_hd_2484);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam9, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2472, v_v_27_2482, v_hd_2484, v_k_2485});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam6(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  V v_x_2471 = heff_env(self)[1];
  V v_x_27_2481 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_2472 = heff_env(self)[9];
  V v_v_27_2482 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2483;
  args[0] = heff_dup(v_hd_2484);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam7, 1, 12, (V[]){v_x_2471, v_x_27_2481, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2484, v_g_240, v_v_2472, v_v_27_2482, v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      V v_t_248;
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        case TAG_LargeU: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_u_27_247);
        }
        break;
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          v_t_248 = NTAG(TAG_False);
          break;
        }
        case TAG_LargeU: {
          v_t_248 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_u_27_247);
        }
        break;
      }
      default: heff_nomatch(v_u_246);
      }
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop_rec(v_cs_241, 2);
        heff_drop_tag(v_a_242, 1);
        heff_drop_tag(v_b_243, 1);
        heff_drop(v_z_244);
        return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_False: {
        V v_t_249 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), v_z_244, v_z_245));
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_246);
      V v_t_2415 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), v_z_244, v_z_245));
    }
    case TAG_VFunction: {
      heff_drop(v_u_246);
      V v_t_2421 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_z_244, v_z_245));
    }
    case TAG_VRecord: {
      heff_drop(v_u_246);
      V v_t_2426 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      heff_drop(v_u_246);
      V v_t_2428 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_246);
      V v_t_2429 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_z_244, v_z_245));
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_246);
      V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_z_244, v_z_245));
    }
    case TAG_VPrimString: {
      heff_drop(v_u_246);
      V v_t_2431 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_z_244, v_z_245));
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_246);
      V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_246);
      V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_z_244, v_z_245));
    }
    case TAG_VFixed: {
      heff_drop(v_u_246);
      V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2437 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2438 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2443 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_z_244, v_z_245));
    }
    case TAG_VDecode: {
      V v_h_27_2444 = heff_field(v_b_243, 0);
      V v_sp_27_2445 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2449 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(v_g_240, v_cs_241, v_h_2437, v_sp_2438, v_h_27_2444, v_sp_27_2445));
      return heff_tail(v_t_2449, 2, (V[]){v_z_244, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2455 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_z_244, v_z_245));
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2460 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2462 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2463 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), v_z_244, v_z_245));
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2464 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), v_z_244, v_z_245));
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2465 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), v_z_244, v_z_245));
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2466 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2468 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), v_z_244, v_z_245));
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2470 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2471 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2472 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2473 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2474 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_2477 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), v_z_244, v_z_245));
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_2483}), v_z_244, v_z_245));
    }
    case TAG_VFunction: {
      V v_level_27_2484 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_2485 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_2486 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_2487 = heff_dup(heff_field(v_b_243, 3));
      V v_t_2489 = ({ V a_0 = v_level_2471; V a_1 = v_level_27_2484; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2471); heff_drop(v_level_27_2484); r_; });
      V v_t_2490;
      switch (heff_tag_of(v_t_2489)) {
      case TAG_True: {
        switch (heff_tag_of(v_implicit_2474)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_2487)) {
          case TAG_Expl: {
            v_t_2490 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_2490 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2490 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2487);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_2487)) {
          case TAG_Expl: {
            v_t_2490 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2490 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_2490 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2487);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_2487)) {
          case TAG_Expl: {
            v_t_2490 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2490 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2490 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_2487);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2474);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_implicit_2474);
        heff_drop(v_implicit_27_2487);
        v_t_2490 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2489);
      }
      switch (heff_tag_of(v_t_2490)) {
      case TAG_True: {
        heff_drop_tag(v_a_242, 5);
        heff_drop_tag(v_b_243, 5);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2472), v_dom_27_2485, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0, 1, 7, (V[]){v_cs_241, v_dom_2472, v_cod_2473, v_cod_27_2486, v_g_240, v_z_244, v_z_245}));
      }
      case TAG_False: {
        heff_drop(v_g_240);
        heff_drop(v_dom_2472);
        heff_drop(v_cod_2473);
        heff_drop(v_dom_27_2485);
        heff_drop(v_cod_27_2486);
        V v_t_24122 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24122}), v_z_244, v_z_245));
      }
      default: return heff_nomatch(v_t_2490);
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24127 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24127}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24129 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24129}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24130 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24130}), v_z_244, v_z_245));
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24131 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24131}), v_z_244, v_z_245));
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24132 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24132}), v_z_244, v_z_245));
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24133 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24133}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24135 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24135}), v_z_244, v_z_245));
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2471);
      heff_drop(v_dom_2472);
      heff_drop(v_cod_2473);
      heff_drop(v_implicit_2474);
      V v_t_24137 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24137}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24142 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24142}), v_z_244, v_z_245));
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24144 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24144}), v_z_244, v_z_245));
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24146 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24146}), v_z_244, v_z_245));
    }
    case TAG_VDecode: {
      V v_t_24152 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24152}), v_z_244, v_z_245));
    }
    case TAG_VFunction: {
      V v_t_24158 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24158}), v_z_244, v_z_245));
    }
    case TAG_VRecord: {
      V v_t_24163 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24163}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      V v_t_24165 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24165}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimFloat: {
      V v_t_24166 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24166}), v_z_244, v_z_245));
    }
    case TAG_VPrimString: {
      V v_t_24167 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24167}), v_z_244, v_z_245));
    }
    case TAG_VPrimRune: {
      V v_t_24168 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24168}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      V v_t_24170 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24170}), v_z_244, v_z_245));
    }
    case TAG_VFixed: {
      V v_t_24172 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24172}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24174 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24174}), v_z_244, v_z_245));
    }
    case TAG_VDecode: {
      V v_t_24180 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24180}), v_z_244, v_z_245));
    }
    case TAG_VFunction: {
      V v_t_24186 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24186}), v_z_244, v_z_245));
    }
    case TAG_VRecord: {
      V v_t_24191 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24191}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      V v_t_24193 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24193}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      V v_t_24194 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24194}), v_z_244, v_z_245));
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimString: {
      V v_t_24195 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24195}), v_z_244, v_z_245));
    }
    case TAG_VPrimRune: {
      V v_t_24196 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24196}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      V v_t_24198 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24198}), v_z_244, v_z_245));
    }
    case TAG_VFixed: {
      V v_t_24200 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24200}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24202 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24202}), v_z_244, v_z_245));
    }
    case TAG_VDecode: {
      V v_t_24208 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24208}), v_z_244, v_z_245));
    }
    case TAG_VFunction: {
      V v_t_24214 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24214}), v_z_244, v_z_245));
    }
    case TAG_VRecord: {
      V v_t_24219 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24219}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      V v_t_24221 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24221}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      V v_t_24222 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24222}), v_z_244, v_z_245));
    }
    case TAG_VPrimFloat: {
      V v_t_24223 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24223}), v_z_244, v_z_245));
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimRune: {
      V v_t_24224 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24224}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      V v_t_24226 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24226}), v_z_244, v_z_245));
    }
    case TAG_VFixed: {
      V v_t_24228 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24228}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24247;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24247 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    switch (heff_tag_of(v_t_24247)) {
    case TAG_True: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_False: {
      V v_t_24248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24248}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_t_24247);
    }
  }
  case TAG_VPrimArray: {
    V v_x_24249 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24251 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24251}), v_z_244, v_z_245));
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24257 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24257}), v_z_244, v_z_245));
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24263 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24263}), v_z_244, v_z_245));
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24268 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24268}), v_z_244, v_z_245));
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24270 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24270}), v_z_244, v_z_245));
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24271 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24271}), v_z_244, v_z_245));
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24272 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24272}), v_z_244, v_z_245));
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24273 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24273}), v_z_244, v_z_245));
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24274 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24274}), v_z_244, v_z_245));
    }
    case TAG_VPrimArray: {
      V v_y_24275 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(v_g_240, v_cs_241, v_x_24249, v_y_24275, v_z_244, v_z_245);
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24249);
      V v_t_24277 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24277}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24278 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24279 = ({ V a_0 = v_w_24278; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24278); r_; });
    switch (heff_tag_of(v_t_24279)) {
    case TAG_True: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop(v_z_244);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_False: {
      V v_t_24280 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return (g_co_2eop_24s1532701784x592895222(heff_tag_n(TAG_InR, 1, (V[]){v_t_24280}), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_t_24279);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1(V self, V *args) {
  V v_u_2493 = args[0];
  V v_dom_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2493);
  return v_dom_2472;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2(V self, V *args) {
  V v_w_24103 = args[0];
  V v_v_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24103);
  return v_v_2494;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3(V self, V *args) {
  V v_w_24113 = args[0];
  V v_v_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24113);
  return v_v_2494;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0(V self, V *args) {
  V v_x_2491 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2472 = heff_env(self)[1];
  V v_cod_2473 = heff_env(self)[2];
  V v_cod_27_2486 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2491);
  V v_t_2492 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_2494 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2492, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1, 1, 1, (V[]){v_dom_2472}), NTAG(TAG_Nothing)));
  V v_x_2499;
  switch (heff_tag_of(v_cod_2473)) {
  case TAG_MkClo: {
    V v_n_2495 = heff_dup(heff_field(v_cod_2473, 0));
    v_x_2499 = v_n_2495;
    break;
  }
  case TAG_CloConst: {
    v_x_2499 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_str0);
    break;
  }
  default: heff_nomatch(v_cod_2473);
  }
  V v_x1_24105;
  switch (heff_tag_of(v_cod_2473)) {
  case TAG_MkClo: {
    V v_vs_24101 = heff_field(v_cod_2473, 1);
    V v_body_24102 = heff_field(v_cod_2473, 2);
    heff_take_n(v_cod_2473, 6ULL, 3);
    v_x1_24105 = heff_tr(heff_call(v_body_24102, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24101, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2, 1, 1, (V[]){heff_dup(v_v_2494)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24104 = heff_field(v_cod_2473, 0);
    heff_take_n(v_cod_2473, 1ULL, 1);
    v_x1_24105 = v_body_24104;
    break;
  }
  default: heff_nomatch(v_cod_2473);
  }
  V v_a_24109;
  switch (heff_tag_of(v_x1_24105)) {
  case TAG_Nom: {
    V v_x_24106 = heff_field(v_x1_24105, 0);
    heff_take_n(v_x1_24105, 1ULL, 1);
    v_a_24109 = v_x_24106;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24105, 0ULL, 1);
    v_a_24109 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24108 = heff_field(v_x1_24105, 0);
    heff_take_n(v_x1_24105, 1ULL, 1);
    v_a_24109 = v_x_24108;
    break;
  }
  default: heff_nomatch(v_x1_24105);
  }
  V v_x1_24115;
  switch (heff_tag_of(v_cod_27_2486)) {
  case TAG_MkClo: {
    V v_vs_24111 = heff_field(v_cod_27_2486, 1);
    V v_body_24112 = heff_field(v_cod_27_2486, 2);
    heff_take_n(v_cod_27_2486, 6ULL, 3);
    v_x1_24115 = heff_tr(heff_call(v_body_24112, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24111, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3, 1, 1, (V[]){v_v_2494})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24114 = heff_field(v_cod_27_2486, 0);
    heff_take_n(v_cod_27_2486, 1ULL, 1);
    heff_drop(v_v_2494);
    v_x1_24115 = v_body_24114;
    break;
  }
  default: heff_nomatch(v_cod_27_2486);
  }
  V v_b_24119;
  switch (heff_tag_of(v_x1_24115)) {
  case TAG_Nom: {
    V v_x_24116 = heff_field(v_x1_24115, 0);
    heff_take_n(v_x1_24115, 1ULL, 1);
    v_b_24119 = v_x_24116;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24115, 0ULL, 1);
    v_b_24119 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24118 = heff_field(v_x1_24115, 0);
    heff_take_n(v_x1_24115, 1ULL, 1);
    v_b_24119 = v_x_24118;
    break;
  }
  default: heff_nomatch(v_x1_24115);
  }
  V v_t_24120 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24121 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2499, heff_get_n(v_cs_241, 1, 2)});
  return (g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(v_g_240, heff_rec_n(2, shape_len__names, (V[]){v_t_24120, v_t_24121}), v_a_24109, v_b_24119, v_z_244, v_z_245));
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam0, 1, 1, (V[]){v_a0_242})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})));
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 8); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4(V self, V *args) {
  V v_c_2456 = args[0];
  return heff_get_n(v_c_2456, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7(V self, V *args) {
  V v_c_2462 = args[0];
  return heff_get_n(v_c_2462, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2465 = ({ V a_0 = v_x_2464; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2464); r_; });
  V v_t_2466 = heff_tr(heff_call(heff_get_n(v_t_2465, 1, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2411}));
  return ({ V a_0 = v_t_2466; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2461);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2463, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam8, 1, 4, (V[]){v_cs_241, v_x_2411, v_hd_244, v_k_245})));
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam5(V self, V *args) {
  V v_x_2458 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2459 = ({ V a_0 = v_x_2458; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2458); r_; });
  V v_t_2460 = heff_tr(heff_call(heff_get_n(v_t_2459, 1, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_248}));
  return ({ V a_0 = v_t_2460; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2411, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a_0, a_1, a_2)); heff_drop(v_t_2460); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433;
  switch (heff_tag_of(v_x_248)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2413 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_h_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_t_2455;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    v_t_2455 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2411)) {
    case TAG_VU: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2435 = heff_dup(heff_field(v_x_2411, 0));
      switch (heff_tag_of(v_h_2435)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2455 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2435);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  switch (heff_tag_of(v_t_2455)) {
  case TAG_True: {
    heff_drop(v_g_240);
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4_clo)})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2457, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam5, 1, 5, (V[]){v_cs_241, v_x_248, v_hd_244, v_x_2411, v_k_245})));
  }
  case TAG_False: {
    V v_it_2488;
    switch (heff_tag_of(v_x_248)) {
    case TAG_VU: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2468 = heff_dup(heff_field(v_x_248, 0));
      V v_sp_2469 = heff_dup(heff_field(v_x_248, 1));
      switch (heff_tag_of(v_t1_2468)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2468, 0ULL, 1);
        heff_drop(v_sp_2469);
        v_it_2488 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2468, 0ULL, 1);
        heff_drop(v_sp_2469);
        v_it_2488 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2475 = heff_field(v_t1_2468, 0);
        V v_ru_24t1_2468_24HMeta = heff_take_reuse_n(v_t1_2468, 1ULL, 1);
        v_it_2488 = heff_tag_at_n(v_ru_24t1_2468_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2475, v_sp_2469})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2469);
        v_it_2488 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2468);
      }
      break;
    }
    case TAG_VFunction: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    switch (heff_tag_of(v_it_2488)) {
    case TAG_Nothing: {
      V v_it_24110;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_VU: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2490 = heff_dup(heff_field(v_x_2411, 0));
        V v_sp_2491 = heff_dup(heff_field(v_x_2411, 1));
        switch (heff_tag_of(v_t1_2490)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2490, 0ULL, 1);
          heff_drop(v_sp_2491);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2490, 0ULL, 1);
          heff_drop(v_sp_2491);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_2497 = heff_field(v_t1_2490, 0);
          V v_ru_24t1_2490_24HMeta = heff_take_reuse_n(v_t1_2490, 1ULL, 1);
          v_it_24110 = heff_tag_at_n(v_ru_24t1_2490_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2497, v_sp_2491})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2491);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2490);
        }
        break;
      }
      case TAG_VFunction: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
      switch (heff_tag_of(v_it_24110)) {
      case TAG_Nothing: {
        return (g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(v_g_240, v_cs_241, v_x_248, v_x_2411, v_hd_244, v_k_245));
      }
      case TAG_Just: {
        V v_it1_24111 = heff_field(v_it_24110, 0);
        V v_ru_24it_24110_24Just = heff_take_reuse_n(v_it_24110, 1ULL, 1);
        switch (heff_tag_of(v_it1_24111)) {
        case TAG_MkPair: {
          V v_m_24112 = heff_field(v_it1_24111, 0);
          V v_sp_24113 = heff_field(v_it1_24111, 1);
          heff_take_n(v_it1_24111, 3ULL, 2);
          V v_rhs_24132;
          switch (heff_tag_of(v_x_248)) {
          case TAG_VU: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VDecode: {
            V v_el_24119 = heff_field(v_x_248, 4);
            heff_take_n(v_x_248, 16ULL, 5);
            heff_drop_cell(v_ru_24it_24110_24Just, 1);
            v_rhs_24132 = heff_tr(heff_call(v_el_24119, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VSum: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24132 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          default: heff_nomatch(v_x_248);
          }
          V v_self_24151;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_VU: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VDecode: {
            V v_el_24138 = heff_field(v_x_2411, 4);
            heff_take_n(v_x_2411, 16ULL, 5);
            v_self_24151 = heff_tr(heff_call(v_el_24138, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VRecord: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VSum: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimString: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VFixed: {
            v_self_24151 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
          return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24112; V a_3 = v_sp_24113; V a_4 = v_rhs_24132; V a_5 = v_self_24151; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24113); r_; });
        }
        default: return heff_nomatch(v_it1_24111);
        }
      }
      default: return heff_nomatch(v_it_24110);
      }
    }
    case TAG_Just: {
      V v_it1_24152 = heff_field(v_it_2488, 0);
      V v_ru_24it_2488_24Just = heff_take_reuse_n(v_it_2488, 1ULL, 1);
      switch (heff_tag_of(v_it1_24152)) {
      case TAG_MkPair: {
        V v_m_24153 = heff_field(v_it1_24152, 0);
        V v_sp_24154 = heff_field(v_it1_24152, 1);
        heff_take_n(v_it1_24152, 3ULL, 2);
        V v_rhs_24173;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_VU: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VDecode: {
          V v_el_24160 = heff_field(v_x_2411, 4);
          heff_take_n(v_x_2411, 16ULL, 5);
          heff_drop_cell(v_ru_24it_2488_24Just, 1);
          v_rhs_24173 = heff_tr(heff_call(v_el_24160, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VSum: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24173 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_self_24192;
        switch (heff_tag_of(v_x_248)) {
        case TAG_VU: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VDecode: {
          V v_el_24179 = heff_field(v_x_248, 4);
          heff_take_n(v_x_248, 16ULL, 5);
          v_self_24192 = heff_tr(heff_call(v_el_24179, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VRecord: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VSum: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimString: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VFixed: {
          v_self_24192 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24153; V a_3 = v_sp_24154; V a_4 = v_rhs_24173; V a_5 = v_self_24192; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24154); r_; });
      }
      default: return heff_nomatch(v_it1_24152);
      }
    }
    default: return heff_nomatch(v_it_2488);
    }
  }
  default: return heff_nomatch(v_t_2455);
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam2, 1, 1, (V[]){v_b0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2410, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam3, 1, 5, (V[]){v_x_248, v_hd_244, v_cs_241, v_k_245, v_g_240})));
}