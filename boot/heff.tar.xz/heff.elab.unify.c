// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_msp 317956
#define LBL_mty 317996
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_renEv 309756614
#define LBL_renEvTy 1323365525
#define LBL_renFlex 1323386232
#define LBL_renTy 309757082
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_solve 310977625
#define LBL_span 10032145
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_mel__mty__msp[] = {LBL_mel, LBL_mty, LBL_msp};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
static uint32_t shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex[] = {LBL_uty, LBL_uel, LBL_ubare, LBL_solve, LBL_ren, LBL_renEv, LBL_renTy, LBL_renEvTy, LBL_renFlex};
V g_co_2eop_24s1532701784x592895222(V, V, V);
V g_co_2eop_24s1532701784x592895222_entry(V self, V *a);
extern Clo g_co_2eop_24s1532701784x592895222_clo;
V g_co_2eop_24s1802027244x918867378(V, V, V);
V g_co_2eop_24s1802027244x918867378_entry(V self, V *a);
extern Clo g_co_2eop_24s1802027244x918867378_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2eappendL(V, V);
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eappendL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2econcatMapL(V, V);
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2econcatMapL_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2eforU(V, V, V, V, V);
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eforU_clo;
V g_heff_2eelab_2eunify_2eiterateLift(V, V);
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eiterateLift_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emetasSpF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasSpF_clo;
V g_heff_2eelab_2eunify_2emetasTermF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTermF_clo;
V g_heff_2eelab_2eunify_2emetasTypeF(V, V, V, V, V);
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasTypeF_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_clo;
V g_heff_2eelab_2eunify_2enewMetaIn(V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaIn_clo;
V g_heff_2eelab_2eunify_2enth(V, V);
V g_heff_2eelab_2eunify_2enth_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enth_clo;
V g_heff_2eelab_2eunify_2epatSpine(V, V, V);
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatSpine_clo;
V g_heff_2eelab_2eunify_2epatStep(V, V, V);
V g_heff_2eelab_2eunify_2epatStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatStep_clo;
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo;
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2esubstTermF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTermF_clo;
V g_heff_2eelab_2eunify_2esubstTyFields(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTyFields_clo;
V g_heff_2eelab_2eunify_2esubstTypeF(V, V, V, V);
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstTypeF_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_clo;
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V, V);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo;
V g_heff_2eelab_2eunify_2euAlg(V, V);
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euAlg_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo;
V g_heff_2eelab_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2eunify_2ezonkTypeF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2efoldl_24s895450532x1092988905(V, V);
V g_list_2efoldl_24s895450532x1092988905_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895450532x1092988905_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eeqPatArgs_entry, 2, 0};

V g_heff_2eelab_2eunify_2eeqPatArgs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_l_248 = heff_field(v_a_244, 0);
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          V v_l_27_249 = heff_field(v_b_246, 0);
          v_t_2411 = heff_intEq(heff_dup(v_l_248), heff_dup(v_l_27_249));
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_b_246)) {
        case TAG_PVar: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_b_246);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2eeqPatArgs(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, (g_heff_2eelab_2eunify_2epatVarsOf(v_rest_242))});
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf(a[0]);
}
V g_heff_2eelab_2eunify_2edistinct_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2edistinct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2edistinct_entry, 1, 0};

V g_heff_2eelab_2eunify_2edistinct(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_x1_244 = (g_list_2eany(heff_clo_n(g_heff_2eelab_2eunify_2edistinct_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2edistinct(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2eunify_2edistinct_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_x_241, v_b_243);
}
Clo g_heff_2eelab_2eunify_2epatStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatStep_entry, 3, 0};

V g_heff_2eelab_2eunify_2epatStep(V v_selfKey_240, V v_v_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_rest_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_v_241)) {
    case TAG_VNeu: {
      V v_v1_244 = heff_field(v_v_241, 0);
      V v_v2_245 = heff_field(v_v_241, 1);
      switch (heff_tag_of(v_v1_244)) {
      case TAG_HLocal: {
        V v_l_249 = heff_field(v_v1_244, 0);
        heff_drop(v_selfKey_240);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_PVar, 1, (V[]){heff_dup(v_l_249)}), v_rest_243});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
        }
        case TAG_SpApp: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_v2_245);
        }
      }
      case TAG_HGlobal: {
        V v_k_2418 = heff_field(v_v1_244, 0);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          switch (heff_tag_of(v_selfKey_240)) {
          case TAG_Nothing: {
            heff_drop(v_rest_243);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_sk_2419 = heff_field(v_selfKey_240, 0);
            heff_take_n(v_selfKey_240, 1ULL, 1);
            if (heff_strEq_c(v_sk_2419, heff_dup(v_k_2418))) {
              V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_PSelf), v_rest_243});
              return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
            } else {
              heff_drop(v_rest_243);
              heff_drop_cell(v_ru_24x3_242_24Just, 1);
              return NTAG(TAG_Nothing);
            }
          }
          default: return heff_nomatch(v_selfKey_240);
          }
        }
        case TAG_SpApp: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpProj: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_SpSpec: {
          heff_drop(v_selfKey_240);
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_v2_245);
        }
      }
      case TAG_HMeta: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_HError: {
        heff_drop(v_selfKey_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_v1_244);
      }
    }
    case TAG_VCode: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VLam: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VCons: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_VOpaque: {
      heff_drop(v_selfKey_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_v_241);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2epatStep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2epatStep(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2eunify_2epatSpine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatSpine_entry, 3, 0};

V g_heff_2eelab_2eunify_2epatSpine(V v_selfKey_240, V v_mc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SpId: {
    heff_drop(v_selfKey_240);
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_SpApp: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_v_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, heff_dup(v_v_244)));
    V v_t_246 = (g_heff_2eelab_2eunify_2epatSpine(heff_dup(v_selfKey_240), v_mc_241, v_s_243));
    return ({ V a_0 = v_selfKey_240; V a_1 = v_t_245; V a_2 = v_t_246; V r_ = (g_heff_2eelab_2eunify_2epatStep(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  case TAG_SpProj: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SpSpec: {
    heff_drop(v_selfKey_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2epatSpine_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2epatSpine(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
Clo g_heff_2eelab_2eunify_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enth_entry, 2, 0};

V g_heff_2eelab_2eunify_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2enth_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2enth(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL(V v_i_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(heff_dup(v_f_241), 2, (V[]){heff_dup(v_i_240), v_x_243}));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2eelab_2eunify_2emapWithIndexL(heff_intAdd(v_i_240, MK_INT(1LL)), v_f_241, v_xs_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eunify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezipL_entry, 2, 0};

V g_heff_2eelab_2eunify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eelab_2eunify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ezipL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2ecatMaybes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ecatMaybes_entry, 1, 0};

V g_heff_2eelab_2eunify_2ecatMaybes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eelab_2eunify_2ecatMaybes(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2ecatMaybes(a[0]);
}
Clo g_heff_2eelab_2eunify_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eanyL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2eanyL(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2eunify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eappendL_entry, 2, 0};

V g_heff_2eelab_2eunify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2eunify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eappendL(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2econcatMapL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2econcatMapL_entry, 2, 0};

V g_heff_2eelab_2eunify_2econcatMapL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eunify_2econcatMapL(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eunify_2eappendL(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2econcatMapL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2econcatMapL(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2eforU_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_lam0, 2, 0};
V g_heff_2eelab_2eunify_2eforU_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2eforU_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2eforU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eforU_entry, 5, 0};

V g_heff_2eelab_2eunify_2eforU(V v_w_240, V v_ms_241, V v_uf_242, V v_x1_243, V v_f_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    heff_drop(v_f_244);
    return ((V)&g_heff_2eelab_2eunify_2eforU_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_243, 0);
    V v_xs_248 = heff_field(v_x1_243, 1);
    V v_c_249 = heff_tr(heff_apply(heff_dup(v_f_244), 1, (V[]){heff_dup(v_x_247)}));
    return heff_clo_n(g_heff_2eelab_2eunify_2eforU_lam1, 2, 6, (V[]){v_c_249, heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242), heff_dup(v_xs_248), v_f_244});
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2eelab_2eunify_2eforU_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2eforU(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2eunify_2eforU_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2eforU_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_uf_242 = heff_env(self)[2];
  V v_xs_248 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_t_2413 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_xs_248; V a_4 = v_f_244; V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_ms_241); heff_drop(v_uf_242); heff_drop(v_xs_248); r_; });
  return heff_tail(v_t_2413, 2, (V[]){v_hd_2410, v_k_2411});
}
V g_heff_2eelab_2eunify_2eforU_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_uf_242 = heff_env(self)[3];
  V v_xs_248 = heff_env(self)[4];
  V v_f_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2eforU_lam2, 1, 7, (V[]){v_w_240, v_ms_241, v_uf_242, v_xs_248, v_f_244, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTermF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTermF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_v0_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_depth_242), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_v0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_it_246 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v0_244));
    switch (heff_tag_of(v_it_246)) {
    case TAG_VNeu: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_sp_248 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 5);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HGlobal: {
        heff_take_n(v_it1_247, 0ULL, 1);
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      case TAG_HMeta: {
        V v_m_2414 = heff_field(v_it1_247, 0);
        heff_take_n(v_it1_247, 1ULL, 1);
        V v_t_2415 = heff_tr(heff_apply(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248}));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_m_2414, v_t_2415});
      }
      case TAG_HError: {
        return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, v_sp_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    case TAG_VCode: {
      V v_t_2416 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2416});
    }
    case TAG_VLam: {
      V v_d_2417 = heff_field(v_it_246, 0);
      V v_c_2418 = heff_field(v_it_246, 1);
      heff_take_n(v_it_246, 3ULL, 2);
      V v_x1_2439;
      switch (heff_tag_of(v_c_2418)) {
      case TAG_MkClo: {
        V v_vs_2420 = heff_field(v_c_2418, 1);
        V v_body_2421 = heff_field(v_c_2418, 2);
        heff_take_n(v_c_2418, 6ULL, 3);
        v_x1_2439 = heff_tr(heff_apply(v_body_2421, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2420, heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam0, 1, 2, (V[]){v_d_2417, heff_dup(v_len_243)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2438 = heff_field(v_c_2418, 0);
        heff_take_n(v_c_2418, 1ULL, 1);
        heff_drop(v_d_2417);
        v_x1_2439 = v_body_2438;
        break;
      }
      default: heff_nomatch(v_c_2418);
      }
      V v_t_2443;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_Nom: {
        V v_x_2440 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2440;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2439, 0ULL, 1);
        v_t_2443 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2442 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2443 = v_x_2442;
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2443});
    }
    case TAG_VCons: {
      V v_d_2444 = heff_field(v_it_246, 0);
      heff_take_n(v_it_246, 1ULL, 1);
      V v_t_2445 = heff_arrayToList(heff_get_n(v_d_2444, 2, 3));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam2, 1, 3, (V[]){v_r_240, v_depth_242, v_len_243}); V a_1 = v_t_2445; V r_ = (g_heff_2eelab_2eunify_2econcatMapL(a_0, a_1)); heff_drop(v_t_2445); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_it_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2emetasTermF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  V v_a_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return v_a_2436;
}
V g_heff_2eelab_2eunify_2emetasTermF_lam0(V self, V *args) {
  V v_u_2422 = args[0];
  V v_d_2417 = heff_env(self)[0];
  V v_len_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2422);
  V v_t_2423 = heff_tr(heff_apply(v_d_2417, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2423)));
  V v_a_2436;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2427 = heff_field(v_t_2424, 1);
    heff_take_n(v_t_2424, 2ULL, 4);
    heff_drop(v_t_2423);
    v_a_2436 = v_dom_2427;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2424, 0ULL, 3);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeInt: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFloat: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeString: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeRune: {
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_a_2436 = v_t_2423;
    break;
  }
  case TAG_NoRules: {
    v_a_2436 = v_t_2423;
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTermF_lam1, 1, 1, (V[]){v_a_2436}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2eunify_2emetasTermF_lam2(V self, V *args) {
  V v_x_2446 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_depth_242 = heff_env(self)[1];
  V v_len_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450;
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Nom: {
    V v_x_2447 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2447;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x_2446, 0ULL, 1);
    v_t_2450 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2449 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x_2446);
  }
  return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_t_2450});
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasTypeF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasTypeF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_t0_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_depth_242), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    heff_drop(v_t0_244);
    return NTAG(TAG_Nil);
  } else {
    V v_t_246 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_t0_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_VU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VDecode: {
      V v_el_2412 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 16ULL, 5);
      V v_t_2413 = heff_tr(heff_apply(v_el_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
      return heff_tail(heff_get_n(v_r_240, 0, 3), 3, (V[]){v_depth_242, v_len_243, v_t_2413});
    }
    case TAG_VFunction: {
      V v_dom_2415 = heff_field(v_t_246, 1);
      V v_cod_2416 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 5);
      V v_t_2419 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_intSub(heff_dup(v_depth_242), MK_INT(1LL)), heff_dup(v_len_243), heff_dup(v_dom_2415)}));
      V v_x1_2426;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_vs_2421 = heff_field(v_cod_2416, 1);
        V v_body_2422 = heff_field(v_cod_2416, 2);
        heff_take_n(v_cod_2416, 6ULL, 3);
        v_x1_2426 = heff_tr(heff_apply(v_body_2422, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2421, heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam0, 1, 2, (V[]){heff_dup(v_len_243), v_dom_2415})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2425 = heff_field(v_cod_2416, 0);
        heff_take_n(v_cod_2416, 1ULL, 1);
        heff_drop(v_dom_2415);
        v_x1_2426 = v_body_2425;
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_2430;
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_Nom: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2427;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2426, 0ULL, 1);
        v_t_2430 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2429 = heff_field(v_x1_2426, 0);
        heff_take_n(v_x1_2426, 1ULL, 1);
        v_t_2430 = v_x_2429;
        break;
      }
      default: heff_nomatch(v_x1_2426);
      }
      V v_t_2431 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), heff_intAdd(v_len_243, MK_INT(1LL)), v_t_2430}));
      return (g_heff_2eelab_2eunify_2eappendL(v_t_2419, v_t_2431));
    }
    case TAG_VRecord: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimRune: {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    case TAG_VPrimArray: {
      V v_a_2437 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, v_a_2437});
    }
    case TAG_VFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_depth_242);
      heff_drop(v_len_243);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2eelab_2eunify_2emetasTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2emetasTypeF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_2415;
}
V g_heff_2eelab_2eunify_2emetasTypeF_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_len_243 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2423);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_len_243}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2emetasTypeF_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2eunify_2emetasSpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasSpF_entry, 5, 0};

V g_heff_2eelab_2eunify_2emetasSpF(V v_r_240, V v_mc_241, V v_depth_242, V v_len_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_depth_242);
    heff_drop(v_len_243);
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(heff_apply(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_245)}));
    V v_t_248 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_246)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_247, v_t_248));
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x5_244, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 3), 3, (V[]){v_depth_242, v_len_243, heff_dup(v_sp_249)});
  }
  case TAG_SpSpec: {
    V v_sp_2411 = heff_field(v_x5_244, 0);
    V v_a_2413 = heff_field(v_x5_244, 2);
    V v_t_2414 = heff_tr(heff_apply(heff_take_field(v_r_240, 2), 3, (V[]){heff_dup(v_depth_242), heff_dup(v_len_243), heff_dup(v_sp_2411)}));
    V v_t_2415 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 3), 3, (V[]){heff_intSub(v_depth_242, MK_INT(1LL)), v_len_243, heff_dup(v_a_2413)}));
    return (g_heff_2eelab_2eunify_2eappendL(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eunify_2emetasSpF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2emetasSpF(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); heff_drop(a[4]); return r;
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2emetasK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emetasK_entry, 1, 0};

V g_heff_2eelab_2eunify_2emetasK(V v_mc_240) {
top: ;
  return heff_rec_n(3, shape_mel__mty__msp, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam0, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam1, 3, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2emetasK_lam2, 3, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2emetasK(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2eunify_2emetasK_lam0(V self, V *args) {
  V v_depth_241 = args[0];
  V v_len_242 = args[1];
  V v_v_243 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_depth_241; V a_3 = v_len_242; V a_4 = v_v_243; V r_ = (g_heff_2eelab_2eunify_2emetasTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam1(V self, V *args) {
  V v_depth_245 = args[0];
  V v_len_246 = args[1];
  V v_t_247 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_248; V a_1 = v_mc_240; V a_2 = v_depth_245; V a_3 = v_len_246; V a_4 = v_t_247; V r_ = (g_heff_2eelab_2eunify_2emetasTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2emetasK_lam2(V self, V *args) {
  V v_depth_249 = args[0];
  V v_len_2410 = args[1];
  V v_sp_2411 = args[2];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2eelab_2eunify_2emetasK(v_mc_240));
  return ({ V a_0 = v_t_2412; V a_1 = v_mc_240; V a_2 = v_depth_249; V a_3 = v_len_2410; V a_4 = v_sp_2411; V r_ = (g_heff_2eelab_2eunify_2emetasSpF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_mc_240); heff_drop(v_sp_2411); r_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_entry, 4, 0};

V g_heff_2eelab_2eunify_2epoisonMany(V v_w_240, V v_ms_241, V v_uf_242, V v_ms_243) {
top: ;
  V v_t_246 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam0, 1, 1, (V[]){heff_dup(v_ms_243)})})}));
  V v_c_247 = heff_tr(heff_apply(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_w_240), v_t_246}));
  return heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam1, 2, 3, (V[]){v_c_247, v_ms_241, v_w_240});
}
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2epoisonMany(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_lam0(V self, V *args) {
  V v_c_244 = args[0];
  V v_ms_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_245 = ({ V a_0 = heff_take_field(v_c_244, 2); V a_1 = v_ms_243; V r_ = (g_list_2efoldl_24s895450532x1092988905(a_0, a_1)); heff_drop(v_ms_243); r_; });
  return ({ V rv_2 = v_ps_245; V rr_ = heff_rec_reuse_n(v_c_244, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tr(heff_apply(v_ms_241, 1, (V[]){v_t_2411}));
  return (g_co_2eop_24s310169282x2049378029(v_w_240, v_t_2412, v_hd_248, v_k_249));
}
V g_heff_2eelab_2eunify_2epoisonMany_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_lam2, 1, 4, (V[]){v_ms_241, v_w_240, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTermF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTermF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SLocal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_intLt_c(heff_dup(v_i_244), heff_dup(v_d_242))) {
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
    } else {
      V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
      V v_t_247 = heff_intSub(heff_intSub(v_t_246, MK_INT(1LL)), heff_intSub(heff_dup(v_i_244), heff_dup(v_d_242)));
      V v_t_248 = (g_heff_2eelab_2eunify_2enth(v_idxs_241, v_t_247));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_d_242);
        return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){v_i_244});
      }
      case TAG_Just: {
        V v_j_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        heff_drop(v_i_244);
        return heff_tag_at_n(v_ru_24t_243_24SLocal, TAG_SLocal, 1, (V[]){heff_intAdd(v_j_249, v_d_242)});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SCode: {
    V v_ty_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2411}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_t_243, 0);
    V v_a_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_2413}));
    V v_t_2416 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2414}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_dd_2417 = heff_field(v_t_243, 0);
    V v_t2_2418 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2418)) {
    case TAG_MkAbs: {
      V v_x_2419 = heff_field(v_t2_2418, 0);
      V v_b_2420 = heff_field(v_t2_2418, 1);
      heff_take_n(v_t2_2418, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2422 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2420}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2421, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2419, v_t_2422})});
    }
    case TAG_AbsConst: {
      V v_b_2423 = heff_field(v_t2_2418, 0);
      heff_take_n(v_t2_2418, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2417}));
      V v_t_2425 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2423}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2424, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2425})});
    }
    default: return heff_nomatch(v_t2_2418);
    }
  }
  case TAG_SCons: {
    V v_dct_2426 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2427 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2428 = heff_take_field(v_dct_2426, 2);
    V v_t_2431 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2428)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam0, 1, 2, (V[]){v_xs_2428, v_f_2427}));
    V v_t_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_n(v_dct_2426, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2432});
  }
  case TAG_SProj: {
    V v_e_2433 = heff_field(v_t_243, 0);
    V v_l_2434 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2435 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2433}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2435, v_l_2434});
  }
  case TAG_STag: {
    V v_x_2436 = heff_field(v_t_243, 0);
    V v_as_2437 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_f_2438 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2437)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam1, 1, 2, (V[]){v_as_2437, v_f_2438}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_x_2436, v_t_2441});
  }
  case TAG_SMatch: {
    V v_e_2442 = heff_field(v_t_243, 0);
    V v_cs_2443 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2442}));
    V v_xs_2445 = heff_take_field(v_cs_2443, 2);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2445)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam2, 1, 3, (V[]){v_xs_2445, v_d_242, v_r_240}));
    V v_t_2453 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_n(v_cs_2443, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e_2454 = heff_field(v_t_243, 0);
    V v_l_2455 = heff_field(v_t_243, 1);
    V v_v_2456 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2454}));
    V v_t_2458 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2456}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e_2459 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2459}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2461 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2462 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2461}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_dd_2463 = heff_field(v_t_243, 0);
    V v_t2_2464 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    switch (heff_tag_of(v_t2_2464)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_t2_2464, 0);
      V v_b_2466 = heff_field(v_t2_2464, 1);
      heff_take_n(v_t2_2464, 3ULL, 2);
      V v_t_2467 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2468 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2466}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2467, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2468})});
    }
    case TAG_AbsConst: {
      V v_b_2469 = heff_field(v_t2_2464, 0);
      heff_take_n(v_t2_2464, 1ULL, 1);
      V v_t_2470 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dd_2463}));
      V v_t_2471 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2469}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2470, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2471})});
    }
    default: return heff_nomatch(v_t2_2464);
    }
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_t_243, 0);
    V v_e_2473 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2473}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_t_243, 0);
    V v_ix_2477 = heff_field(v_t_243, 1);
    V v_ty_2478 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2486 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_ix_2477)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTermF_lam3, 1, 3, (V[]){v_ix_2477, heff_dup(v_d_242), heff_dup(v_idxs_241)}));
    V v_t_2487 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty_2478}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_t_2486, v_t_2487});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2esubstTermF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2esubstTermF_lam0(V self, V *args) {
  V v_i_2429 = args[0];
  V v_xs_2428 = heff_env(self)[0];
  V v_f_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_arrayIndex(v_xs_2428, v_i_2429);
  V f_ = v_f_2427;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam1(V self, V *args) {
  V v_i_2439 = args[0];
  V v_as_2437 = heff_env(self)[0];
  V v_f_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_as_2437, v_i_2439);
  V f_ = v_f_2438;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2448)));
    V v_t_2451 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_t_2450, v_b_2449}));
    return heff_tag_at_n(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
V g_heff_2eelab_2eunify_2esubstTermF_lam3(V self, V *args) {
  V v_i_2479 = args[0];
  V v_ix_2477 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_idxs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_i_2480 = heff_arrayIndex(v_ix_2477, v_i_2479);
  if (heff_intLt_c(heff_dup(v_i_2480), heff_dup(v_d_242))) {
    heff_drop(v_d_242);
    heff_drop(v_idxs_241);
    return v_i_2480;
  } else {
    V v_t_2482 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_idxs_241));
    V v_t_2483 = heff_intSub(heff_intSub(v_t_2482, MK_INT(1LL)), heff_intSub(heff_dup(v_i_2480), heff_dup(v_d_242)));
    V v_t_2484 = ({ V a_0 = v_idxs_241; V a_1 = v_t_2483; V r_ = (g_heff_2eelab_2eunify_2enth(a_0, a_1)); heff_drop(v_idxs_241); r_; });
    switch (heff_tag_of(v_t_2484)) {
    case TAG_Nothing: {
      heff_drop(v_d_242);
      return v_i_2480;
    }
    case TAG_Just: {
      V v_j_2485 = heff_field(v_t_2484, 0);
      heff_take_n(v_t_2484, 1ULL, 1);
      heff_drop(v_i_2480);
      return heff_intAdd(v_j_2485, v_d_242);
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
}
Clo g_heff_2eelab_2eunify_2esubstTyFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTyFields_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTyFields(V v_r_240, V v_d_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ty_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_intAdd(heff_dup(v_d_241), heff_dup(v_i_242)), v_ty_244}));
    return heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245))});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTyFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esubstTyFields(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstTypeF_entry, 4, 0};

V g_heff_2eelab_2eunify_2esubstTypeF(V v_r_240, V v_idxs_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_t_2422 = heff_arrayToList(heff_take_field(v_ft_2420, 2));
    V v_t_2423 = (g_heff_2eelab_2eunify_2esubstTyFields(v_r_240, v_d_242, MK_INT(0LL), v_t_2422));
    V v_t_2424 = ({ V rv_2 = heff_arrayFromList(v_t_2423); V rr_ = heff_rec_reuse_n(v_ft_2420, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2424, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2425 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2426 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_f_2430 = heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam0, 1, 1, (V[]){v_f_2426});
    V v_xs_2431 = heff_take_field(v_vs_2425, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2431)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam2, 1, 2, (V[]){v_xs_2431, v_f_2430}));
    V v_t_2435 = ({ V rv_2 = v_t_2434; V rr_ = heff_rec_reuse_n(v_vs_2425, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2435});
  }
  case TAG_SIsTy: {
    V v_a_2436 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2437 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2436}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2437});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eunify_2esubstTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2esubstTypeF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam1(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_f_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  V f_ = v_f_2426;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam0(V self, V *args) {
  V v_xs_2427 = args[0];
  V v_f_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo_n(g_heff_2eelab_2eunify_2esubstTypeF_lam1, 1, 2, (V[]){v_xs_2427, v_f_2426}));
}
V g_heff_2eelab_2eunify_2esubstTypeF_lam2(V self, V *args) {
  V v_i_2432 = args[0];
  V v_xs_2431 = heff_env(self)[0];
  V v_f_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_xs_2431, v_i_2432);
  V f_ = v_f_2430;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esubstOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esubstOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2esubstOf(V v_idxs_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam0, 2, 1, (V[]){heff_dup(v_idxs_240)}), heff_clo_n(g_heff_2eelab_2eunify_2esubstOf_lam1, 2, 1, (V[]){heff_dup(v_idxs_240)})});
}
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2esubstOf(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2eunify_2esubstOf_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_243; V a_1 = v_idxs_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eelab_2eunify_2esubstTermF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
V g_heff_2eelab_2eunify_2esubstOf_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_idxs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_240));
  return ({ V a_0 = v_t_246; V a_1 = v_idxs_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2eunify_2esubstTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_idxs_240); r_; });
}
Clo g_heff_2eelab_2eunify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estripLams_entry, 2, 0};

V g_heff_2eelab_2eunify_2estripLams(V v_n_240, V v_t_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return v_t_241;
  } else {
    switch (heff_tag_of(v_t_241)) {
    case TAG_SLocal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SGlobal: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SCode: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLam: {
      V v_it2_249 = heff_field(v_t_241, 1);
      heff_take_n(v_t_241, 2ULL, 2);
      switch (heff_tag_of(v_it2_249)) {
      case TAG_MkAbs: {
        V v_b_2411 = heff_field(v_it2_249, 1);
        heff_take_n(v_it2_249, 2ULL, 2);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2412 = heff_field(v_it2_249, 0);
        heff_take_n(v_it2_249, 1ULL, 1);
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_b_2412;
        v_n_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_it2_249);
      }
    }
    case TAG_SCons: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SProj: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_STag: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMatch: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SSpecialize: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SIs: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SOpaque: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SAbandon: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SRec: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SFix: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SImplicit: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SPrim: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SMetaApp: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitInt: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitString: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitRune: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFixed: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    case TAG_SLitFloat32: {
      heff_drop(v_n_240);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
}
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estripLams(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_245}));
    return heff_tag_at_n(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_248}));
    return heff_tag_at_n(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get_n(v_r_240, 0, 2);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at_n(v_ru_24t_242_24SLam, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse_n(v_b_2412, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SLam, 2);
      V v_t_2419 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2422 = heff_take_field(v_d_2421, 2);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2422)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2422, v_r_240}));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_n(v_d_2421, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e_2427 = heff_field(v_t_242, 0);
    V v_l_2428 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2427}));
    return heff_tag_at_n(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_x_2430 = heff_field(v_t_242, 0);
    V v_as_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2431)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_as_2431, v_r_240}));
    return heff_tag_at_n(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2430, v_t_2434});
  }
  case TAG_SMatch: {
    V v_e_2435 = heff_field(v_t_242, 0);
    V v_cs_2436 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2435}));
    V v_xs_2438 = heff_take_field(v_cs_2436, 2);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2438, v_r_240}));
    V v_t_2445 = ({ V rv_2 = v_t_2444; V rr_ = heff_rec_reuse_n(v_cs_2436, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2437, v_t_2445});
  }
  case TAG_SSpecialize: {
    V v_e_2446 = heff_field(v_t_242, 0);
    V v_l_2447 = heff_field(v_t_242, 1);
    V v_v_2448 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2449 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2446}));
    V v_t_2450 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_2448}));
    return heff_tag_at_n(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2449, v_l_2447, v_t_2450});
  }
  case TAG_SIs: {
    V v_e_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2452 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2451}));
    return heff_tag_at_n(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2452});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2453 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2454 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2453}));
    return heff_tag_at_n(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2454});
  }
  case TAG_SFix: {
    V v_d_2455 = heff_field(v_t_242, 0);
    V v_b_2456 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2455}));
    V v_f_2458 = heff_get_n(v_r_240, 0, 2);
    V v_t_2464;
    switch (heff_tag_of(v_b_2456)) {
    case TAG_MkAbs: {
      V v_x_2459 = heff_field(v_b_2456, 0);
      V v_b_2460 = heff_field(v_b_2456, 1);
      heff_take_n(v_b_2456, 3ULL, 2);
      V v_t_2461 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2460}));
      v_t_2464 = heff_tag_at_n(v_ru_24t_242_24SFix, TAG_MkAbs, 2, (V[]){v_x_2459, v_t_2461});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2462 = heff_field(v_b_2456, 0);
      V v_ru_24b_2456_24AbsConst = heff_take_reuse_n(v_b_2456, 1ULL, 1);
      heff_drop_cell(v_ru_24t_242_24SFix, 2);
      V v_t_2463 = heff_tr(heff_apply(v_f_2458, 1, (V[]){v_b_2462}));
      v_t_2464 = heff_tag_at_n(v_ru_24b_2456_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2463});
      break;
    }
    default: heff_nomatch(v_b_2456);
    }
    return heff_tag_n(TAG_SFix, 2, (V[]){v_t_2457, v_t_2464});
  }
  case TAG_SImplicit: {
    V v_x_2465 = heff_field(v_t_242, 0);
    V v_e_2466 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2466}));
    return heff_tag_at_n(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2465, v_t_2467});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2469 = heff_field(v_t_242, 0);
    V v_idxs_2470 = heff_field(v_t_242, 1);
    V v_ty_2471 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2472 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_2469), v_mc_241));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_Nothing: {
      V v_t_2473 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2471}));
      return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2473});
    }
    case TAG_Just: {
      V v_e_2474 = heff_field(v_t_2472, 0);
      heff_take_n(v_t_2472, 1ULL, 1);
      V v_t_2475 = heff_get_n(v_e_2474, 2, 6);
      switch (heff_tag_of(v_t_2475)) {
      case TAG_Nothing: {
        V v_t_2476 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2471}));
        return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2476});
      }
      case TAG_Just: {
        V v_sol_2477 = heff_field(v_t_2475, 0);
        heff_take_n(v_t_2475, 1ULL, 1);
        heff_drop(v_m_2469);
        heff_drop(v_ty_2471);
        heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
        V v_idxs_2478 = heff_arrayToList(v_idxs_2470);
        V v_t_2479 = (g_heff_2eelab_2eunify_2esubstOf(v_idxs_2478));
        V v_t_2480 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_idxs_2478; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_idxs_2478); r_; });
        V v_t_2481 = (g_heff_2eelab_2eunify_2estripLams(v_t_2480, v_sol_2477));
        V v_t_2482 = heff_tr(heff_apply(heff_get_n(v_t_2479, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2481}));
        return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2482});
      }
      default: return heff_nomatch(v_t_2475);
      }
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2ezonkTermF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_as_2431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_as_2431, v_i_2432);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_xs_2441 = heff_field(v_p_2440, 0);
    V v_b_2442 = heff_field(v_p_2440, 1);
    V v_ru_24p_2440_24MkPair = heff_take_reuse_n(v_p_2440, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_2442}));
    return heff_tag_at_n(v_ru_24p_2440_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_p_2440);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTypeF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTypeF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_dom_247}));
    V v_f_2412 = heff_take_field(v_r_240, 1);
    V v_t_2418;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2413 = heff_field(v_cod_248, 0);
      V v_b_2414 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_apply(v_f_2412, 1, (V[]){v_b_2414}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2413, v_t_2415});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_apply(v_f_2412, 1, (V[]){v_b_2416}));
      v_t_2418 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2421;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2419 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2419}));
      v_t_2421 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2420});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_246, v_t_2411, v_t_2418, v_implicit_249, v_t_2421});
  }
  case TAG_SRecord: {
    V v_level_2422 = heff_field(v_t_242, 0);
    V v_ft_2423 = heff_field(v_t_242, 1);
    V v_ds_2424 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2425 = heff_take_field(v_ft_2423, 2);
    V v_t_2428 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2425)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam0, 1, 2, (V[]){v_xs_2425, heff_dup(v_r_240)}));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_n(v_ft_2423, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_xs_2430 = heff_take_field(v_ds_2424, 2);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_r_240}));
    V v_t_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_n(v_ds_2424, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2422, v_t_2429, v_t_2434});
  }
  case TAG_SSum: {
    V v_vs_2435 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2436 = heff_take_field(v_vs_2435, 2);
    V v_t_2441 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2436)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam2, 1, 2, (V[]){v_xs_2436, v_r_240}));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_n(v_vs_2435, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2442});
  }
  case TAG_SIsTy: {
    V v_a_2443 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2444 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_a_2443}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2444});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2ezonkTypeF(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam0(V self, V *args) {
  V v_i_2426 = args[0];
  V v_xs_2425 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_arrayIndex(v_xs_2425, v_i_2426);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam3(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  V f_ = heff_get_n(v_r_240, 1, 2);
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTypeF_lam2(V self, V *args) {
  V v_i_2437 = args[0];
  V v_xs_2436 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2438 = heff_arrayIndex(v_xs_2436, v_i_2437);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2438)), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTypeF_lam3, 1, 2, (V[]){v_xs_2438, v_r_240}));
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonker_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonker_entry, 1, 0};

V g_heff_2eelab_2eunify_2ezonker(V v_mc_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2eunify_2ezonker_lam1, 1, 1, (V[]){heff_dup(v_mc_240)})});
}
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2ezonker(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2eunify_2ezonker_lam0(V self, V *args) {
  V v_t_241 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_242; V a_1 = v_mc_240; V a_2 = v_t_241; V r_ = (g_heff_2eelab_2eunify_2ezonkTermF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2eunify_2ezonker_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2eunify_2ezonker(v_mc_240));
  return ({ V a_0 = v_t_244; V a_1 = v_mc_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2eunify_2ezonkTypeF(a_0, a_1, a_2)); heff_drop(v_mc_240); r_; });
}
Clo g_heff_2eelab_2eunify_2eiterateLift_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eiterateLift_entry, 2, 0};

V g_heff_2eelab_2eunify_2eiterateLift(V v_i_240, V v_rr_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
    heff_drop(v_i_240);
    return v_rr_241;
  } else {
    V v_t_243 = heff_intAdd(heff_dup(heff_rfield(v_rr_241, 0)), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_dup(heff_rfield(v_rr_241, 1)), MK_INT(1LL));
    V v_t_245 = (g_map_2einsert_24s1689409319x1710080871(heff_take_field(v_rr_241, 0), heff_take_field(v_rr_241, 1), heff_get_n(v_rr_241, 2, 3)));
    V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
    V t_1 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_243, v_t_244, v_t_245});
    v_i_240 = t_0;
    v_rr_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2eiterateLift_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eiterateLift(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2elamsU_str0, 1, "x");
Clo g_heff_2eelab_2eunify_2elamsU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2elamsU_entry, 2, 0};

V g_heff_2eelab_2eunify_2elamsU(V v_k_240, V v_body_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return v_body_241;
  } else {
    V v_t_243 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
    V v_t_244 = heff_tag_n(TAG_SLam, 2, (V[]){v_t_243, heff_tag_n(TAG_MkAbs, 2, (V[]){((V)&g_heff_2eelab_2eunify_2elamsU_str0), v_body_241})});
    V t_0 = heff_intSub(v_k_240, MK_INT(1LL));
    V t_1 = v_t_244;
    v_k_240 = t_0;
    v_body_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2elamsU(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2enewMetaIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaIn_entry, 4, 0};

V g_heff_2eelab_2eunify_2enewMetaIn(V v_entry_240, V v_arity_241, V v_ty_242, V v_c_243) {
top: ;
  V v_t_244 = ({ V rv_0 = v_ty_242; V rv_1 = NTAG(TAG_Nothing); V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_arity_241; V rr_ = heff_rec_reuse_n(v_entry_240, 48ULL, 6, shape_ty__sol__solStx__arity__name__span); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_mc_245 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_c_243, 4)), v_t_244, heff_take_field(v_c_243, 3)));
  V v_t_246 = heff_intAdd(heff_take_field(v_c_243, 4), MK_INT(1LL));
  return ({ V rv_3 = v_mc_245; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_n(v_c_243, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2eunify_2enewMetaIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_249;
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          v_t_249 = heff_intEq(v_a_246, v_a_247);
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_249 = NTAG(TAG_False);
          break;
        }
        case TAG_PSelf: {
          v_t_249 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(a[0], a[1]);
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_i_240), v_x_242}), (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(heff_intAdd(v_i_240, MK_INT(1LL)), v_xs_243))});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euElRigid_str0, 1, "x");
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euElRigid_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euElRigid_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_lam4, 2, 0};
Clo g_heff_2eelab_2eunify_2euElRigid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euElRigid_entry, 10, 0};

V g_heff_2eelab_2eunify_2euElRigid(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_x4_246, V v_cb_247, V v_a_248, V v_b_249) {
top: ;
  switch (heff_tag_of(v_x4_246)) {
  case TAG_VNeu: {
    V v_h_2410 = heff_field(v_x4_246, 0);
    V v_sp_2411 = heff_field(v_x4_246, 1);
    heff_take_n(v_x4_246, 3ULL, 5);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      V v_h_27_2415 = heff_field(v_cb_247, 0);
      V v_sp_27_2416 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 3ULL, 5);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      return heff_tail(heff_get_n(v_r_243, 2, 9), 6, (V[]){v_g_244, v_cs_245, v_h_2410, v_sp_2411, v_h_27_2415, v_sp_27_2416});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2421 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2422 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2421}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2422});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2425 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2426 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2425}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2426});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2428 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2429 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2428}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2429});
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_h_2410);
      heff_drop(v_sp_2411);
      V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2431 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2430}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2431});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCode: {
    V v_t_2432 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCode = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2432);
      V v_t_2438 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2439 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2438}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2439});
    }
    case TAG_VCode: {
      V v_t_27_2440 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCode, 1);
      return heff_tail(heff_get_n(v_r_243, 0, 9), 4, (V[]){v_g_244, v_cs_245, v_t_2432, v_t_27_2440});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2432);
      V v_t_2443 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2444 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2443}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2444});
    }
    case TAG_VCons: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2432);
      V v_t_2446 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2447 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2446}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2447});
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_t_2432);
      V v_t_2448 = heff_tag_at_n(v_ru_24x4_246_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2449 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2448}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2449});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VLam: {
    V v_d_2450 = heff_field(v_x4_246, 0);
    V v_c_2451 = heff_field(v_x4_246, 1);
    V v_ru_24x4_246_24VLam = heff_take_reuse_n(v_x4_246, 3ULL, 2);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2450);
      heff_drop(v_c_2451);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2457 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2458 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2457}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2458});
    }
    case TAG_VCode: {
      V v_ru_24cb_247_24VCode = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2450);
      heff_drop(v_c_2451);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_2460 = heff_tag_at_n(v_ru_24cb_247_24VCode, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_2461 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_2460}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_2461});
    }
    case TAG_VLam: {
      V v_c_27_2463 = heff_field(v_cb_247, 1);
      heff_take_n(v_cb_247, 2ULL, 2);
      heff_drop(v_w_240);
      heff_drop(v_uf_242);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      V v_t_2464 = heff_tr(heff_apply(v_d_2450, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2465 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2464)));
      V v_a_2477;
      switch (heff_tag_of(v_t_2465)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2465, 0ULL, 1);
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeFunction: {
        V v_dom_2468 = heff_field(v_t_2465, 1);
        heff_take_n(v_t_2465, 2ULL, 4);
        heff_drop(v_t_2464);
        v_a_2477 = v_dom_2468;
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_2465, 0ULL, 3);
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2465, 0ULL, 1);
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeInt: {
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeFloat: {
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeString: {
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeRune: {
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2465, 0ULL, 1);
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2465, 0ULL, 1);
        v_a_2477 = v_t_2464;
        break;
      }
      case TAG_NoRules: {
        v_a_2477 = v_t_2464;
        break;
      }
      default: heff_nomatch(v_t_2465);
      }
      V v_t_2478 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_245, 0))});
      V v_v_2480 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2478, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam0, 1, 1, (V[]){v_a_2477}), NTAG(TAG_Nothing)));
      V v_x_2485;
      switch (heff_tag_of(v_c_2451)) {
      case TAG_MkClo: {
        V v_n_2481 = heff_dup(heff_field(v_c_2451, 0));
        v_x_2485 = v_n_2481;
        break;
      }
      case TAG_CloConst: {
        v_x_2485 = ((V)&g_heff_2eelab_2eunify_2euElRigid_str0);
        break;
      }
      default: heff_nomatch(v_c_2451);
      }
      V v_t_2486 = heff_intAdd(heff_take_field(v_cs_245, 0), MK_INT(1LL));
      V v_t_2487 = heff_tag_at_n(v_ru_24x4_246_24VLam, TAG_Cons, 2, (V[]){v_x_2485, heff_get_n(v_cs_245, 1, 2)});
      V v_x1_2493;
      switch (heff_tag_of(v_c_2451)) {
      case TAG_MkClo: {
        V v_vs_2489 = heff_field(v_c_2451, 1);
        V v_body_2490 = heff_field(v_c_2451, 2);
        heff_take_n(v_c_2451, 6ULL, 3);
        v_x1_2493 = heff_tr(heff_apply(v_body_2490, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2489, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam1, 1, 1, (V[]){heff_dup(v_v_2480)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2492 = heff_field(v_c_2451, 0);
        heff_take_n(v_c_2451, 1ULL, 1);
        v_x1_2493 = v_body_2492;
        break;
      }
      default: heff_nomatch(v_c_2451);
      }
      V v_t_2497;
      switch (heff_tag_of(v_x1_2493)) {
      case TAG_Nom: {
        V v_x_2494 = heff_field(v_x1_2493, 0);
        heff_take_n(v_x1_2493, 1ULL, 1);
        v_t_2497 = v_x_2494;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2493, 0ULL, 1);
        v_t_2497 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2496 = heff_field(v_x1_2493, 0);
        heff_take_n(v_x1_2493, 1ULL, 1);
        v_t_2497 = v_x_2496;
        break;
      }
      default: heff_nomatch(v_x1_2493);
      }
      V v_x1_24103;
      switch (heff_tag_of(v_c_27_2463)) {
      case TAG_MkClo: {
        V v_vs_2499 = heff_field(v_c_27_2463, 1);
        V v_body_24100 = heff_field(v_c_27_2463, 2);
        heff_take_n(v_c_27_2463, 6ULL, 3);
        v_x1_24103 = heff_tr(heff_apply(v_body_24100, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2499, heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam2, 1, 1, (V[]){v_v_2480})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_24102 = heff_field(v_c_27_2463, 0);
        heff_take_n(v_c_27_2463, 1ULL, 1);
        heff_drop(v_v_2480);
        v_x1_24103 = v_body_24102;
        break;
      }
      default: heff_nomatch(v_c_27_2463);
      }
      V v_t_24107;
      switch (heff_tag_of(v_x1_24103)) {
      case TAG_Nom: {
        V v_x_24104 = heff_field(v_x1_24103, 0);
        heff_take_n(v_x1_24103, 1ULL, 1);
        v_t_24107 = v_x_24104;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24103, 0ULL, 1);
        v_t_24107 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24106 = heff_field(v_x1_24103, 0);
        heff_take_n(v_x1_24103, 1ULL, 1);
        v_t_24107 = v_x_24106;
        break;
      }
      default: heff_nomatch(v_x1_24103);
      }
      return heff_tail(heff_get_n(v_r_243, 1, 9), 4, (V[]){v_g_244, heff_rec_n(2, shape_len__names, (V[]){v_t_2486, v_t_2487}), v_t_2497, v_t_24107});
    }
    case TAG_VCons: {
      V v_ru_24cb_247_24VCons = heff_take_reuse_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2450);
      heff_drop(v_c_2451);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24109 = heff_tag_at_n(v_ru_24cb_247_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24110 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24109}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_24110});
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop(v_d_2450);
      heff_drop(v_c_2451);
      heff_drop_cell(v_ru_24x4_246_24VLam, 2);
      V v_t_24111 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24112 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24111}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_24112});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VCons: {
    V v_d_24113 = heff_field(v_x4_246, 0);
    V v_ru_24x4_246_24VCons = heff_take_reuse_n(v_x4_246, 1ULL, 1);
    switch (heff_tag_of(v_cb_247)) {
    case TAG_VNeu: {
      heff_take_n(v_cb_247, 0ULL, 5);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24119 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24120 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24119}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_24120});
    }
    case TAG_VCode: {
      heff_take_n(v_cb_247, 0ULL, 1);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24122 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24123 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24122}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_24123});
    }
    case TAG_VLam: {
      heff_take_n(v_cb_247, 0ULL, 2);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24126 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24127 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24126}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_24127});
    }
    case TAG_VCons: {
      V v_d_27_24128 = heff_field(v_cb_247, 0);
      heff_take_n(v_cb_247, 1ULL, 1);
      heff_drop(v_a_248);
      heff_drop(v_b_249);
      heff_drop_cell(v_ru_24x4_246_24VCons, 1);
      V v_t_24129 = heff_arrayToList(heff_get_n(v_d_24113, 2, 3));
      V v_t_24130 = heff_arrayToList(heff_get_n(v_d_27_24128, 2, 3));
      V v_t_24131 = (g_heff_2eelab_2eunify_2ezipL(v_t_24129, v_t_24130));
      return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_24131; V a_4 = heff_clo_n(g_heff_2eelab_2eunify_2euElRigid_lam3, 1, 3, (V[]){v_r_243, v_g_244, v_cs_245}); V r_ = (g_heff_2eelab_2eunify_2eforU(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_w_240); heff_drop(v_uf_242); heff_drop(v_t_24131); r_; });
    }
    case TAG_VOpaque: {
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      heff_drop_rec(v_d_24113, 3);
      V v_t_24143 = heff_tag_at_n(v_ru_24x4_246_24VCons, TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalEls, 3, (V[]){v_cs_245, v_a_248, v_b_249})});
      V v_t_24144 = heff_tr(heff_apply(v_uf_242, 1, (V[]){v_t_24143}));
      return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_w_240, v_t_24144});
    }
    default: return heff_nomatch(v_cb_247);
    }
  }
  case TAG_VOpaque: {
    heff_drop(v_w_240);
    heff_drop(v_uf_242);
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    heff_drop_rec(v_cs_245, 2);
    heff_drop(v_cb_247);
    heff_drop(v_a_248);
    heff_drop(v_b_249);
    return ((V)&g_heff_2eelab_2eunify_2euElRigid_lam4_clo);
  }
  default: return heff_nomatch(v_x4_246);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2euElRigid(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2eunify_2euElRigid_lam0(V self, V *args) {
  V v_u_2479 = args[0];
  V v_a_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2479);
  return v_a_2477;
}
V g_heff_2eelab_2eunify_2euElRigid_lam1(V self, V *args) {
  V v_w_2491 = args[0];
  V v_v_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_2491);
  return v_v_2480;
}
V g_heff_2eelab_2eunify_2euElRigid_lam2(V self, V *args) {
  V v_w_24101 = args[0];
  V v_v_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24101);
  return v_v_2480;
}
V g_heff_2eelab_2eunify_2euElRigid_lam3(V self, V *args) {
  V v_p_24132 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  V v_cs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_p_24132, 0);
    V v_y_24134 = heff_field(v_p_24132, 1);
    heff_take_n(v_p_24132, 3ULL, 2);
    V v_t_24138;
    switch (heff_tag_of(v_x_24133)) {
    case TAG_Nom: {
      V v_x_24135 = heff_field(v_x_24133, 0);
      heff_take_n(v_x_24133, 1ULL, 1);
      v_t_24138 = v_x_24135;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x_24133, 0ULL, 1);
      v_t_24138 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24137 = heff_field(v_x_24133, 0);
      heff_take_n(v_x_24133, 1ULL, 1);
      v_t_24138 = v_x_24137;
      break;
    }
    default: heff_nomatch(v_x_24133);
    }
    V v_t_24142;
    switch (heff_tag_of(v_y_24134)) {
    case TAG_Nom: {
      V v_x_24139 = heff_field(v_y_24134, 0);
      heff_take_n(v_y_24134, 1ULL, 1);
      v_t_24142 = v_x_24139;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_y_24134, 0ULL, 1);
      v_t_24142 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24141 = heff_field(v_y_24134, 0);
      heff_take_n(v_y_24134, 1ULL, 1);
      v_t_24142 = v_x_24141;
      break;
    }
    default: heff_nomatch(v_y_24134);
    }
    return heff_tail(heff_get_n(v_r_243, 1, 9), 4, (V[]){v_g_244, v_cs_245, v_t_24138, v_t_24142});
  }
  default: return heff_nomatch(v_p_24132);
  }
}
V g_heff_2eelab_2eunify_2euElRigid_lam4(V self, V *args) {
  V v_hd_24145 = args[0];
  V v_k_24146 = args[1];
  heff_drop(v_hd_24145);
  V f_ = v_k_24146;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam5, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam9, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eelab_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_t_249 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  V v_c_2410 = heff_tr(heff_apply(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_w_240), v_t_249}));
  return heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam1, 2, 8, (V[]){v_c_2410, v_ms_241, v_b0_247, v_w_240, v_cs_245, v_uf_242, v_r_243, v_g_244});
}
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_246; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args) {
  V v_c_2414 = args[0];
  V v_b0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2414, 3, 8); V a_1 = v_b0_247; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2420 = args[0];
  return heff_get_n(v_c_2420, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2423 = heff_env(self)[5];
  V v_k_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = ({ V a_0 = v_x_2425; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2425); r_; });
  V v_t_2427 = heff_tr(heff_apply(heff_get_n(v_t_2426, 0, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_245, 0, 2), v_x_2413}));
  V v_t_2428 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_2427; V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3)); heff_drop(v_uf_242); heff_drop(v_t_2427); r_; });
  return heff_tail(v_t_2428, 2, (V[]){v_hd_2423, v_k_2424});
}
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_cs_245 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_ms_241 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam7, 1, 7, (V[]){v_cs_245, v_x_2413, v_w_240, v_ms_241, v_uf_242, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args) {
  V v_c_2431 = args[0];
  return heff_get_n(v_c_2431, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2435 = ({ V a_0 = v_x_2434; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2434); r_; });
  V v_t_2436 = heff_tr(heff_apply(heff_get_n(v_t_2435, 0, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_245, 0, 2), v_x_2417}));
  V v_t_2437 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_2436; V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3)); heff_drop(v_uf_242); heff_drop(v_t_2436); r_; });
  return heff_tail(v_t_2437, 2, (V[]){v_hd_2411, v_k_2412});
}
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2430);
  V v_t_2432 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam9_clo)})}));
  V v_c_2433 = heff_tr(heff_apply(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_w_240), v_t_2432}));
  return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam10, 1, 7, (V[]){v_cs_245, v_x_2417, v_w_240, v_ms_241, v_uf_242, v_hd_2411, v_k_2412})});
}
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2418 = (g_heff_2eelab_2evalue_2eisError(v_x_2413));
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    v_t_2419 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_2419 = (g_heff_2eelab_2evalue_2eisError(v_x_2417));
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    V v_t_2421 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam5_clo)})}));
    V v_c_2422 = heff_tr(heff_apply(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_w_240), v_t_2421}));
    V v_c_2429 = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam6, 2, 6, (V[]){v_c_2422, heff_dup(v_cs_245), v_x_2413, heff_dup(v_w_240), heff_dup(v_ms_241), heff_dup(v_uf_242)});
    return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam8, 1, 7, (V[]){v_ms_241, v_w_240, v_hd_2411, v_cs_245, v_x_2417, v_uf_242, v_k_2412})});
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2413)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2417)) {
      case TAG_VNeu: {
        V v_it_2460;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_2448 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_2449 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_2448)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_sp_2449);
            v_it_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2448, 0ULL, 1);
            heff_drop(v_sp_2449);
            v_it_2460 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2455 = heff_field(v_v1_2448, 0);
            V v_ru_24v1_2448_24HMeta = heff_take_reuse_n(v_v1_2448, 1ULL, 1);
            v_it_2460 = heff_tag_at_n(v_ru_24v1_2448_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2455, v_sp_2449})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2449);
            v_it_2460 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2448);
          }
          break;
        }
        case TAG_VCode: {
          v_it_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_2460 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_2460 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_2460)) {
        case TAG_Nothing: {
          V v_it_2473;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_2461 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_2462 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_2461)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2461, 0ULL, 1);
              heff_drop(v_sp_2462);
              v_it_2473 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2461, 0ULL, 1);
              heff_drop(v_sp_2462);
              v_it_2473 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2468 = heff_field(v_v1_2461, 0);
              V v_ru_24v1_2461_24HMeta = heff_take_reuse_n(v_v1_2461, 1ULL, 1);
              v_it_2473 = heff_tag_at_n(v_ru_24v1_2461_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2468, v_sp_2462})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2462);
              v_it_2473 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_2461);
            }
            break;
          }
          case TAG_VCode: {
            v_it_2473 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_2473 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_2473 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_2473 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_2473)) {
          case TAG_Nothing: {
            V v_t_2486;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_2474 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_2474)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2474, 0ULL, 1);
                v_t_2486 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_2474);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2486 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_2499;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_2487 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_2487)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_2487, 0ULL, 1);
                v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_2487, 0ULL, 1);
                v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2487, 0ULL, 1);
                v_t_2499 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_2487);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2499 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24100 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_2486; V a_7 = v_t_2499; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24100, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24101 = heff_field(v_it_2473, 0);
            heff_take_n(v_it_2473, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24101)) {
            case TAG_MkPair: {
              V v_m_24102 = heff_field(v_it1_24101, 0);
              V v_sp_24103 = heff_field(v_it1_24101, 1);
              heff_take_n(v_it1_24101, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24102, v_sp_24103, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24101);
            }
          }
          default: return heff_nomatch(v_it_2473);
          }
        }
        case TAG_Just: {
          V v_it1_24104 = heff_field(v_it_2460, 0);
          heff_take_n(v_it_2460, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24104)) {
          case TAG_MkPair: {
            V v_m_24105 = heff_field(v_it1_24104, 0);
            V v_sp_24106 = heff_field(v_it1_24104, 1);
            heff_take_n(v_it1_24104, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24105, v_sp_24106, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24104);
          }
        }
        default: return heff_nomatch(v_it_2460);
        }
      }
      case TAG_VCode: {
        V v_it_24120;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24108 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24109 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24108)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24108, 0ULL, 1);
            heff_drop(v_sp_24109);
            v_it_24120 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24108, 0ULL, 1);
            heff_drop(v_sp_24109);
            v_it_24120 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24115 = heff_field(v_v1_24108, 0);
            V v_ru_24v1_24108_24HMeta = heff_take_reuse_n(v_v1_24108, 1ULL, 1);
            v_it_24120 = heff_tag_at_n(v_ru_24v1_24108_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24115, v_sp_24109})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24109);
            v_it_24120 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24108);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24120 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24120 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24120 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24120 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24120)) {
        case TAG_Nothing: {
          V v_it_24133;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24121 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24122 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24121)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              v_it_24133 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              v_it_24133 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24128 = heff_field(v_v1_24121, 0);
              V v_ru_24v1_24121_24HMeta = heff_take_reuse_n(v_v1_24121, 1ULL, 1);
              v_it_24133 = heff_tag_at_n(v_ru_24v1_24121_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24128, v_sp_24122})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24122);
              v_it_24133 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24121);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24133 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24133 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24133)) {
          case TAG_Nothing: {
            V v_t_24146;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24134 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24134)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24134, 0ULL, 1);
                v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24134, 0ULL, 1);
                v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24134, 0ULL, 1);
                v_t_24146 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24134);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24146 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24159;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24147 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24147)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24147, 0ULL, 1);
                v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24147, 0ULL, 1);
                v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24147, 0ULL, 1);
                v_t_24159 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24147);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24159 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24160 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24146; V a_7 = v_t_24159; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24160, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24161 = heff_field(v_it_24133, 0);
            heff_take_n(v_it_24133, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24161)) {
            case TAG_MkPair: {
              V v_m_24162 = heff_field(v_it1_24161, 0);
              V v_sp_24163 = heff_field(v_it1_24161, 1);
              heff_take_n(v_it1_24161, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24162, v_sp_24163, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24161);
            }
          }
          default: return heff_nomatch(v_it_24133);
          }
        }
        case TAG_Just: {
          V v_it1_24164 = heff_field(v_it_24120, 0);
          heff_take_n(v_it_24120, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24164)) {
          case TAG_MkPair: {
            V v_m_24165 = heff_field(v_it1_24164, 0);
            V v_sp_24166 = heff_field(v_it1_24164, 1);
            heff_take_n(v_it1_24164, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24165, v_sp_24166, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24164);
          }
        }
        default: return heff_nomatch(v_it_24120);
        }
      }
      case TAG_VLam: {
        V v_it_24181;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24169 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24170 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24169)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24169, 0ULL, 1);
            heff_drop(v_sp_24170);
            v_it_24181 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24169, 0ULL, 1);
            heff_drop(v_sp_24170);
            v_it_24181 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24176 = heff_field(v_v1_24169, 0);
            V v_ru_24v1_24169_24HMeta = heff_take_reuse_n(v_v1_24169, 1ULL, 1);
            v_it_24181 = heff_tag_at_n(v_ru_24v1_24169_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24176, v_sp_24170})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24170);
            v_it_24181 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24169);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24181 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24181 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24181 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24181 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24181)) {
        case TAG_Nothing: {
          V v_it_24194;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24182 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24183 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24182)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24182, 0ULL, 1);
              heff_drop(v_sp_24183);
              v_it_24194 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24182, 0ULL, 1);
              heff_drop(v_sp_24183);
              v_it_24194 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24189 = heff_field(v_v1_24182, 0);
              V v_ru_24v1_24182_24HMeta = heff_take_reuse_n(v_v1_24182, 1ULL, 1);
              v_it_24194 = heff_tag_at_n(v_ru_24v1_24182_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24189, v_sp_24183})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24183);
              v_it_24194 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24182);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24194 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24194 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24194 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24194 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24194)) {
          case TAG_Nothing: {
            V v_t_24207;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24195 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24195)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24195, 0ULL, 1);
                v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24195, 0ULL, 1);
                v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24195, 0ULL, 1);
                v_t_24207 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24195);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24207 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24220;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24208 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24208)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24208, 0ULL, 1);
                v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24208, 0ULL, 1);
                v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24208, 0ULL, 1);
                v_t_24220 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24208);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24220 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24221 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24207; V a_7 = v_t_24220; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24221, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24222 = heff_field(v_it_24194, 0);
            heff_take_n(v_it_24194, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24222)) {
            case TAG_MkPair: {
              V v_m_24223 = heff_field(v_it1_24222, 0);
              V v_sp_24224 = heff_field(v_it1_24222, 1);
              heff_take_n(v_it1_24222, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24223, v_sp_24224, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24222);
            }
          }
          default: return heff_nomatch(v_it_24194);
          }
        }
        case TAG_Just: {
          V v_it1_24225 = heff_field(v_it_24181, 0);
          heff_take_n(v_it_24181, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24225)) {
          case TAG_MkPair: {
            V v_m_24226 = heff_field(v_it1_24225, 0);
            V v_sp_24227 = heff_field(v_it1_24225, 1);
            heff_take_n(v_it1_24225, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24226, v_sp_24227, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24225);
          }
        }
        default: return heff_nomatch(v_it_24181);
        }
      }
      case TAG_VCons: {
        V v_it_24241;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24229 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24230 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24229)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24229, 0ULL, 1);
            heff_drop(v_sp_24230);
            v_it_24241 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24229, 0ULL, 1);
            heff_drop(v_sp_24230);
            v_it_24241 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24236 = heff_field(v_v1_24229, 0);
            V v_ru_24v1_24229_24HMeta = heff_take_reuse_n(v_v1_24229, 1ULL, 1);
            v_it_24241 = heff_tag_at_n(v_ru_24v1_24229_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24236, v_sp_24230})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24230);
            v_it_24241 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24229);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24241 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24241 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24241 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24241 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24241)) {
        case TAG_Nothing: {
          V v_it_24254;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24242 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24243 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24242)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24242, 0ULL, 1);
              heff_drop(v_sp_24243);
              v_it_24254 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24242, 0ULL, 1);
              heff_drop(v_sp_24243);
              v_it_24254 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24249 = heff_field(v_v1_24242, 0);
              V v_ru_24v1_24242_24HMeta = heff_take_reuse_n(v_v1_24242, 1ULL, 1);
              v_it_24254 = heff_tag_at_n(v_ru_24v1_24242_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24249, v_sp_24243})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24243);
              v_it_24254 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24242);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24254 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24254 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24254 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24254 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24254)) {
          case TAG_Nothing: {
            V v_t_24267;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24255 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24255)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24255, 0ULL, 1);
                v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24255, 0ULL, 1);
                v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24255, 0ULL, 1);
                v_t_24267 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24255);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24267 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24280;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24268 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24268)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24268, 0ULL, 1);
                v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24268, 0ULL, 1);
                v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24268, 0ULL, 1);
                v_t_24280 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24268);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24280 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24281 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24267; V a_7 = v_t_24280; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24281, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24282 = heff_field(v_it_24254, 0);
            heff_take_n(v_it_24254, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24282)) {
            case TAG_MkPair: {
              V v_m_24283 = heff_field(v_it1_24282, 0);
              V v_sp_24284 = heff_field(v_it1_24282, 1);
              heff_take_n(v_it1_24282, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24283, v_sp_24284, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24282);
            }
          }
          default: return heff_nomatch(v_it_24254);
          }
        }
        case TAG_Just: {
          V v_it1_24285 = heff_field(v_it_24241, 0);
          heff_take_n(v_it_24241, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24285)) {
          case TAG_MkPair: {
            V v_m_24286 = heff_field(v_it1_24285, 0);
            V v_sp_24287 = heff_field(v_it1_24285, 1);
            heff_take_n(v_it1_24285, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24286, v_sp_24287, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24285);
          }
        }
        default: return heff_nomatch(v_it_24241);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2413, 5);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop(v_hd_2411);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2412;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2417);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2417)) {
      case TAG_VNeu: {
        V v_it_24306;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24294 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24295 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24294)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24294, 0ULL, 1);
            heff_drop(v_sp_24295);
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24294, 0ULL, 1);
            heff_drop(v_sp_24295);
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24301 = heff_field(v_v1_24294, 0);
            V v_ru_24v1_24294_24HMeta = heff_take_reuse_n(v_v1_24294, 1ULL, 1);
            v_it_24306 = heff_tag_at_n(v_ru_24v1_24294_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24301, v_sp_24295})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24295);
            v_it_24306 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24294);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24306 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24306 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24306 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24306 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24306)) {
        case TAG_Nothing: {
          V v_it_24319;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24307 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24308 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24307)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24307, 0ULL, 1);
              heff_drop(v_sp_24308);
              v_it_24319 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24307, 0ULL, 1);
              heff_drop(v_sp_24308);
              v_it_24319 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24314 = heff_field(v_v1_24307, 0);
              V v_ru_24v1_24307_24HMeta = heff_take_reuse_n(v_v1_24307, 1ULL, 1);
              v_it_24319 = heff_tag_at_n(v_ru_24v1_24307_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24314, v_sp_24308})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24308);
              v_it_24319 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24307);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24319 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24319 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24319 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24319 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24319)) {
          case TAG_Nothing: {
            V v_t_24332;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24320 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24320)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24320);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24345;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24333 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24333)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24333, 0ULL, 1);
                v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24333, 0ULL, 1);
                v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24333, 0ULL, 1);
                v_t_24345 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24333);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24345 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24346 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24332; V a_7 = v_t_24345; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24346, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24347 = heff_field(v_it_24319, 0);
            heff_take_n(v_it_24319, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24347)) {
            case TAG_MkPair: {
              V v_m_24348 = heff_field(v_it1_24347, 0);
              V v_sp_24349 = heff_field(v_it1_24347, 1);
              heff_take_n(v_it1_24347, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24348, v_sp_24349, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24347);
            }
          }
          default: return heff_nomatch(v_it_24319);
          }
        }
        case TAG_Just: {
          V v_it1_24350 = heff_field(v_it_24306, 0);
          heff_take_n(v_it_24306, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24350)) {
          case TAG_MkPair: {
            V v_m_24351 = heff_field(v_it1_24350, 0);
            V v_sp_24352 = heff_field(v_it1_24350, 1);
            heff_take_n(v_it1_24350, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24351, v_sp_24352, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24350);
          }
        }
        default: return heff_nomatch(v_it_24306);
        }
      }
      case TAG_VCode: {
        V v_it_24366;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24354 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24355 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24354)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24354, 0ULL, 1);
            heff_drop(v_sp_24355);
            v_it_24366 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24354, 0ULL, 1);
            heff_drop(v_sp_24355);
            v_it_24366 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24361 = heff_field(v_v1_24354, 0);
            V v_ru_24v1_24354_24HMeta = heff_take_reuse_n(v_v1_24354, 1ULL, 1);
            v_it_24366 = heff_tag_at_n(v_ru_24v1_24354_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24361, v_sp_24355})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24355);
            v_it_24366 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24354);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24366 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24366 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24366 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24366 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24366)) {
        case TAG_Nothing: {
          V v_it_24379;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24367 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24368 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24367)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24367, 0ULL, 1);
              heff_drop(v_sp_24368);
              v_it_24379 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24367, 0ULL, 1);
              heff_drop(v_sp_24368);
              v_it_24379 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24374 = heff_field(v_v1_24367, 0);
              V v_ru_24v1_24367_24HMeta = heff_take_reuse_n(v_v1_24367, 1ULL, 1);
              v_it_24379 = heff_tag_at_n(v_ru_24v1_24367_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24374, v_sp_24368})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24368);
              v_it_24379 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24367);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24379 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24379 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24379 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24379 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24379)) {
          case TAG_Nothing: {
            V v_t_24392;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24380 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24380)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24380, 0ULL, 1);
                v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24380, 0ULL, 1);
                v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24380, 0ULL, 1);
                v_t_24392 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24380);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24392 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24405;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24393 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24393)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24393, 0ULL, 1);
                v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24393, 0ULL, 1);
                v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24393, 0ULL, 1);
                v_t_24405 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24393);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24405 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24406 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24392; V a_7 = v_t_24405; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24406, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24407 = heff_field(v_it_24379, 0);
            heff_take_n(v_it_24379, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24407)) {
            case TAG_MkPair: {
              V v_m_24408 = heff_field(v_it1_24407, 0);
              V v_sp_24409 = heff_field(v_it1_24407, 1);
              heff_take_n(v_it1_24407, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24408, v_sp_24409, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24407);
            }
          }
          default: return heff_nomatch(v_it_24379);
          }
        }
        case TAG_Just: {
          V v_it1_24410 = heff_field(v_it_24366, 0);
          heff_take_n(v_it_24366, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24410)) {
          case TAG_MkPair: {
            V v_m_24411 = heff_field(v_it1_24410, 0);
            V v_sp_24412 = heff_field(v_it1_24410, 1);
            heff_take_n(v_it1_24410, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24411, v_sp_24412, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24410);
          }
        }
        default: return heff_nomatch(v_it_24366);
        }
      }
      case TAG_VLam: {
        V v_it_24427;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24415 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24416 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24415)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24415, 0ULL, 1);
            heff_drop(v_sp_24416);
            v_it_24427 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24415, 0ULL, 1);
            heff_drop(v_sp_24416);
            v_it_24427 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24422 = heff_field(v_v1_24415, 0);
            V v_ru_24v1_24415_24HMeta = heff_take_reuse_n(v_v1_24415, 1ULL, 1);
            v_it_24427 = heff_tag_at_n(v_ru_24v1_24415_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24422, v_sp_24416})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24416);
            v_it_24427 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24415);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24427 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24427)) {
        case TAG_Nothing: {
          V v_it_24440;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24428 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24429 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24428)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24428, 0ULL, 1);
              heff_drop(v_sp_24429);
              v_it_24440 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24428, 0ULL, 1);
              heff_drop(v_sp_24429);
              v_it_24440 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24435 = heff_field(v_v1_24428, 0);
              V v_ru_24v1_24428_24HMeta = heff_take_reuse_n(v_v1_24428, 1ULL, 1);
              v_it_24440 = heff_tag_at_n(v_ru_24v1_24428_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24435, v_sp_24429})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24429);
              v_it_24440 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24428);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24440 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24440 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24440)) {
          case TAG_Nothing: {
            V v_t_24453;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24441 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24441)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24441, 0ULL, 1);
                v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24441, 0ULL, 1);
                v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24441, 0ULL, 1);
                v_t_24453 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24441);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24453 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24466;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24454 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24454)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24454, 0ULL, 1);
                v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24454, 0ULL, 1);
                v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24454, 0ULL, 1);
                v_t_24466 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24454);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24466 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24467 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24453; V a_7 = v_t_24466; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24467, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24468 = heff_field(v_it_24440, 0);
            heff_take_n(v_it_24440, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24468)) {
            case TAG_MkPair: {
              V v_m_24469 = heff_field(v_it1_24468, 0);
              V v_sp_24470 = heff_field(v_it1_24468, 1);
              heff_take_n(v_it1_24468, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24469, v_sp_24470, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24468);
            }
          }
          default: return heff_nomatch(v_it_24440);
          }
        }
        case TAG_Just: {
          V v_it1_24471 = heff_field(v_it_24427, 0);
          heff_take_n(v_it_24427, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24471)) {
          case TAG_MkPair: {
            V v_m_24472 = heff_field(v_it1_24471, 0);
            V v_sp_24473 = heff_field(v_it1_24471, 1);
            heff_take_n(v_it1_24471, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24472, v_sp_24473, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24471);
          }
        }
        default: return heff_nomatch(v_it_24427);
        }
      }
      case TAG_VCons: {
        V v_it_24487;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24475 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24476 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24475)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24475, 0ULL, 1);
            heff_drop(v_sp_24476);
            v_it_24487 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24475, 0ULL, 1);
            heff_drop(v_sp_24476);
            v_it_24487 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24482 = heff_field(v_v1_24475, 0);
            V v_ru_24v1_24475_24HMeta = heff_take_reuse_n(v_v1_24475, 1ULL, 1);
            v_it_24487 = heff_tag_at_n(v_ru_24v1_24475_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24482, v_sp_24476})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24476);
            v_it_24487 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24475);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24487 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24487 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24487 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24487 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24487)) {
        case TAG_Nothing: {
          V v_it_24500;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24488 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24489 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24488)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24488, 0ULL, 1);
              heff_drop(v_sp_24489);
              v_it_24500 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24488, 0ULL, 1);
              heff_drop(v_sp_24489);
              v_it_24500 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24495 = heff_field(v_v1_24488, 0);
              V v_ru_24v1_24488_24HMeta = heff_take_reuse_n(v_v1_24488, 1ULL, 1);
              v_it_24500 = heff_tag_at_n(v_ru_24v1_24488_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24495, v_sp_24489})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24489);
              v_it_24500 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24488);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24500 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24500 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24500 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24500 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24500)) {
          case TAG_Nothing: {
            V v_t_24513;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24501 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24501)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24501, 0ULL, 1);
                v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24501, 0ULL, 1);
                v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24501, 0ULL, 1);
                v_t_24513 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24501);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24513 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24526;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24514 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24514)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24514, 0ULL, 1);
                v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24514, 0ULL, 1);
                v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24514, 0ULL, 1);
                v_t_24526 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24514);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24526 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24527 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24513; V a_7 = v_t_24526; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24527, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24528 = heff_field(v_it_24500, 0);
            heff_take_n(v_it_24500, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24528)) {
            case TAG_MkPair: {
              V v_m_24529 = heff_field(v_it1_24528, 0);
              V v_sp_24530 = heff_field(v_it1_24528, 1);
              heff_take_n(v_it1_24528, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24529, v_sp_24530, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24528);
            }
          }
          default: return heff_nomatch(v_it_24500);
          }
        }
        case TAG_Just: {
          V v_it1_24531 = heff_field(v_it_24487, 0);
          heff_take_n(v_it_24487, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24531)) {
          case TAG_MkPair: {
            V v_m_24532 = heff_field(v_it1_24531, 0);
            V v_sp_24533 = heff_field(v_it1_24531, 1);
            heff_take_n(v_it1_24531, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24532, v_sp_24533, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24531);
          }
        }
        default: return heff_nomatch(v_it_24487);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2413, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop(v_hd_2411);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2412;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2417);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2417)) {
      case TAG_VNeu: {
        V v_it_24553;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24541 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24542 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24541)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24541, 0ULL, 1);
            heff_drop(v_sp_24542);
            v_it_24553 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24541, 0ULL, 1);
            heff_drop(v_sp_24542);
            v_it_24553 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24548 = heff_field(v_v1_24541, 0);
            V v_ru_24v1_24541_24HMeta = heff_take_reuse_n(v_v1_24541, 1ULL, 1);
            v_it_24553 = heff_tag_at_n(v_ru_24v1_24541_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24548, v_sp_24542})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24542);
            v_it_24553 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24541);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24553 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24553 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24553 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24553 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24553)) {
        case TAG_Nothing: {
          V v_it_24566;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24554 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24555 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24554)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24554, 0ULL, 1);
              heff_drop(v_sp_24555);
              v_it_24566 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24554, 0ULL, 1);
              heff_drop(v_sp_24555);
              v_it_24566 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24561 = heff_field(v_v1_24554, 0);
              V v_ru_24v1_24554_24HMeta = heff_take_reuse_n(v_v1_24554, 1ULL, 1);
              v_it_24566 = heff_tag_at_n(v_ru_24v1_24554_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24561, v_sp_24555})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24555);
              v_it_24566 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24554);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24566 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24566 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24566 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24566 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24566)) {
          case TAG_Nothing: {
            V v_t_24579;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24567 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24567)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24567, 0ULL, 1);
                v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24567, 0ULL, 1);
                v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24567, 0ULL, 1);
                v_t_24579 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24567);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24579 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24592;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24580 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24580)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24580, 0ULL, 1);
                v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24580, 0ULL, 1);
                v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24580, 0ULL, 1);
                v_t_24592 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24580);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24592 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24593 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24579; V a_7 = v_t_24592; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24593, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24594 = heff_field(v_it_24566, 0);
            heff_take_n(v_it_24566, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24594)) {
            case TAG_MkPair: {
              V v_m_24595 = heff_field(v_it1_24594, 0);
              V v_sp_24596 = heff_field(v_it1_24594, 1);
              heff_take_n(v_it1_24594, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24595, v_sp_24596, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24594);
            }
          }
          default: return heff_nomatch(v_it_24566);
          }
        }
        case TAG_Just: {
          V v_it1_24597 = heff_field(v_it_24553, 0);
          heff_take_n(v_it_24553, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24597)) {
          case TAG_MkPair: {
            V v_m_24598 = heff_field(v_it1_24597, 0);
            V v_sp_24599 = heff_field(v_it1_24597, 1);
            heff_take_n(v_it1_24597, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24598, v_sp_24599, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24597);
          }
        }
        default: return heff_nomatch(v_it_24553);
        }
      }
      case TAG_VCode: {
        V v_it_24613;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24601 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24602 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24601)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24601, 0ULL, 1);
            heff_drop(v_sp_24602);
            v_it_24613 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24601, 0ULL, 1);
            heff_drop(v_sp_24602);
            v_it_24613 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24608 = heff_field(v_v1_24601, 0);
            V v_ru_24v1_24601_24HMeta = heff_take_reuse_n(v_v1_24601, 1ULL, 1);
            v_it_24613 = heff_tag_at_n(v_ru_24v1_24601_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24608, v_sp_24602})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24602);
            v_it_24613 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24601);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24613 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24613 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24613 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24613 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24613)) {
        case TAG_Nothing: {
          V v_it_24626;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24614 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24615 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24614)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24614, 0ULL, 1);
              heff_drop(v_sp_24615);
              v_it_24626 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24614, 0ULL, 1);
              heff_drop(v_sp_24615);
              v_it_24626 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24621 = heff_field(v_v1_24614, 0);
              V v_ru_24v1_24614_24HMeta = heff_take_reuse_n(v_v1_24614, 1ULL, 1);
              v_it_24626 = heff_tag_at_n(v_ru_24v1_24614_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24621, v_sp_24615})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24615);
              v_it_24626 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24614);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24626 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24626 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24626 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24626 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24626)) {
          case TAG_Nothing: {
            V v_t_24639;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24627 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24627)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24627, 0ULL, 1);
                v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24627, 0ULL, 1);
                v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24627, 0ULL, 1);
                v_t_24639 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24627);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24639 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24652;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24640 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24640)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24640, 0ULL, 1);
                v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24640, 0ULL, 1);
                v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24640, 0ULL, 1);
                v_t_24652 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24640);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24652 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24653 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24639; V a_7 = v_t_24652; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24653, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24654 = heff_field(v_it_24626, 0);
            heff_take_n(v_it_24626, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24654)) {
            case TAG_MkPair: {
              V v_m_24655 = heff_field(v_it1_24654, 0);
              V v_sp_24656 = heff_field(v_it1_24654, 1);
              heff_take_n(v_it1_24654, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24655, v_sp_24656, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24654);
            }
          }
          default: return heff_nomatch(v_it_24626);
          }
        }
        case TAG_Just: {
          V v_it1_24657 = heff_field(v_it_24613, 0);
          heff_take_n(v_it_24613, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24657)) {
          case TAG_MkPair: {
            V v_m_24658 = heff_field(v_it1_24657, 0);
            V v_sp_24659 = heff_field(v_it1_24657, 1);
            heff_take_n(v_it1_24657, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24658, v_sp_24659, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24657);
          }
        }
        default: return heff_nomatch(v_it_24613);
        }
      }
      case TAG_VLam: {
        V v_it_24674;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24662 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24663 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24662)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24662, 0ULL, 1);
            heff_drop(v_sp_24663);
            v_it_24674 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24662, 0ULL, 1);
            heff_drop(v_sp_24663);
            v_it_24674 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24669 = heff_field(v_v1_24662, 0);
            V v_ru_24v1_24662_24HMeta = heff_take_reuse_n(v_v1_24662, 1ULL, 1);
            v_it_24674 = heff_tag_at_n(v_ru_24v1_24662_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24669, v_sp_24663})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24663);
            v_it_24674 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24662);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24674 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24674 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24674 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24674 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24674)) {
        case TAG_Nothing: {
          V v_it_24687;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24675 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24676 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24675)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24675, 0ULL, 1);
              heff_drop(v_sp_24676);
              v_it_24687 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24675, 0ULL, 1);
              heff_drop(v_sp_24676);
              v_it_24687 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24682 = heff_field(v_v1_24675, 0);
              V v_ru_24v1_24675_24HMeta = heff_take_reuse_n(v_v1_24675, 1ULL, 1);
              v_it_24687 = heff_tag_at_n(v_ru_24v1_24675_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24682, v_sp_24676})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24676);
              v_it_24687 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24675);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24687 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24687 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24687 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24687 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24687)) {
          case TAG_Nothing: {
            V v_t_24700;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24688 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24688)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24688, 0ULL, 1);
                v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24688, 0ULL, 1);
                v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24688, 0ULL, 1);
                v_t_24700 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24688);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24700 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24713;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24701 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24701)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24701, 0ULL, 1);
                v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24701, 0ULL, 1);
                v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24701, 0ULL, 1);
                v_t_24713 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24701);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24713 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24714 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24700; V a_7 = v_t_24713; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24714, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24715 = heff_field(v_it_24687, 0);
            heff_take_n(v_it_24687, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24715)) {
            case TAG_MkPair: {
              V v_m_24716 = heff_field(v_it1_24715, 0);
              V v_sp_24717 = heff_field(v_it1_24715, 1);
              heff_take_n(v_it1_24715, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24716, v_sp_24717, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24715);
            }
          }
          default: return heff_nomatch(v_it_24687);
          }
        }
        case TAG_Just: {
          V v_it1_24718 = heff_field(v_it_24674, 0);
          heff_take_n(v_it_24674, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24718)) {
          case TAG_MkPair: {
            V v_m_24719 = heff_field(v_it1_24718, 0);
            V v_sp_24720 = heff_field(v_it1_24718, 1);
            heff_take_n(v_it1_24718, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24719, v_sp_24720, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24718);
          }
        }
        default: return heff_nomatch(v_it_24674);
        }
      }
      case TAG_VCons: {
        V v_it_24734;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24722 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24723 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24722)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24722, 0ULL, 1);
            heff_drop(v_sp_24723);
            v_it_24734 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24722, 0ULL, 1);
            heff_drop(v_sp_24723);
            v_it_24734 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24729 = heff_field(v_v1_24722, 0);
            V v_ru_24v1_24722_24HMeta = heff_take_reuse_n(v_v1_24722, 1ULL, 1);
            v_it_24734 = heff_tag_at_n(v_ru_24v1_24722_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24729, v_sp_24723})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24723);
            v_it_24734 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24722);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24734 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24734 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24734 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24734 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24734)) {
        case TAG_Nothing: {
          V v_it_24747;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24735 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24736 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24735)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24735, 0ULL, 1);
              heff_drop(v_sp_24736);
              v_it_24747 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24735, 0ULL, 1);
              heff_drop(v_sp_24736);
              v_it_24747 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24742 = heff_field(v_v1_24735, 0);
              V v_ru_24v1_24735_24HMeta = heff_take_reuse_n(v_v1_24735, 1ULL, 1);
              v_it_24747 = heff_tag_at_n(v_ru_24v1_24735_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24742, v_sp_24736})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24736);
              v_it_24747 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24735);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24747 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24747 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24747 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24747 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24747)) {
          case TAG_Nothing: {
            V v_t_24760;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24748 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24748)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24748, 0ULL, 1);
                v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24748, 0ULL, 1);
                v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24748, 0ULL, 1);
                v_t_24760 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24748);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24760 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24773;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24761 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24761)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24761, 0ULL, 1);
                v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24761, 0ULL, 1);
                v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24761, 0ULL, 1);
                v_t_24773 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24761);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24773 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24774 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24760; V a_7 = v_t_24773; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24774, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24775 = heff_field(v_it_24747, 0);
            heff_take_n(v_it_24747, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24775)) {
            case TAG_MkPair: {
              V v_m_24776 = heff_field(v_it1_24775, 0);
              V v_sp_24777 = heff_field(v_it1_24775, 1);
              heff_take_n(v_it1_24775, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24776, v_sp_24777, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24775);
            }
          }
          default: return heff_nomatch(v_it_24747);
          }
        }
        case TAG_Just: {
          V v_it1_24778 = heff_field(v_it_24734, 0);
          heff_take_n(v_it_24734, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24778)) {
          case TAG_MkPair: {
            V v_m_24779 = heff_field(v_it1_24778, 0);
            V v_sp_24780 = heff_field(v_it1_24778, 1);
            heff_take_n(v_it1_24778, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24779, v_sp_24780, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24778);
          }
        }
        default: return heff_nomatch(v_it_24734);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2413, 2);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop(v_hd_2411);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2412;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2417);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2417)) {
      case TAG_VNeu: {
        V v_it_24799;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24787 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24788 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24787)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24787, 0ULL, 1);
            heff_drop(v_sp_24788);
            v_it_24799 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24787, 0ULL, 1);
            heff_drop(v_sp_24788);
            v_it_24799 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24794 = heff_field(v_v1_24787, 0);
            V v_ru_24v1_24787_24HMeta = heff_take_reuse_n(v_v1_24787, 1ULL, 1);
            v_it_24799 = heff_tag_at_n(v_ru_24v1_24787_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24794, v_sp_24788})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24788);
            v_it_24799 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24787);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24799 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24799 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24799 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24799 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24799)) {
        case TAG_Nothing: {
          V v_it_24812;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24800 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24801 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24800)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24800, 0ULL, 1);
              heff_drop(v_sp_24801);
              v_it_24812 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24800, 0ULL, 1);
              heff_drop(v_sp_24801);
              v_it_24812 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24807 = heff_field(v_v1_24800, 0);
              V v_ru_24v1_24800_24HMeta = heff_take_reuse_n(v_v1_24800, 1ULL, 1);
              v_it_24812 = heff_tag_at_n(v_ru_24v1_24800_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24807, v_sp_24801})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24801);
              v_it_24812 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24800);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24812 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24812 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24812 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24812 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24812)) {
          case TAG_Nothing: {
            V v_t_24825;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24813 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24813)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24813, 0ULL, 1);
                v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24813, 0ULL, 1);
                v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24813, 0ULL, 1);
                v_t_24825 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24813);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24825 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24838;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24826 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24826)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24826, 0ULL, 1);
                v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24826, 0ULL, 1);
                v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24826, 0ULL, 1);
                v_t_24838 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24826);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24838 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24839 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24825; V a_7 = v_t_24838; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24839, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24840 = heff_field(v_it_24812, 0);
            heff_take_n(v_it_24812, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24840)) {
            case TAG_MkPair: {
              V v_m_24841 = heff_field(v_it1_24840, 0);
              V v_sp_24842 = heff_field(v_it1_24840, 1);
              heff_take_n(v_it1_24840, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24841, v_sp_24842, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24840);
            }
          }
          default: return heff_nomatch(v_it_24812);
          }
        }
        case TAG_Just: {
          V v_it1_24843 = heff_field(v_it_24799, 0);
          heff_take_n(v_it_24799, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24843)) {
          case TAG_MkPair: {
            V v_m_24844 = heff_field(v_it1_24843, 0);
            V v_sp_24845 = heff_field(v_it1_24843, 1);
            heff_take_n(v_it1_24843, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24844, v_sp_24845, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24843);
          }
        }
        default: return heff_nomatch(v_it_24799);
        }
      }
      case TAG_VCode: {
        V v_it_24859;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24847 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24848 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24847)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24847, 0ULL, 1);
            heff_drop(v_sp_24848);
            v_it_24859 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24847, 0ULL, 1);
            heff_drop(v_sp_24848);
            v_it_24859 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24854 = heff_field(v_v1_24847, 0);
            V v_ru_24v1_24847_24HMeta = heff_take_reuse_n(v_v1_24847, 1ULL, 1);
            v_it_24859 = heff_tag_at_n(v_ru_24v1_24847_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24854, v_sp_24848})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24848);
            v_it_24859 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24847);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24859 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24859 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24859 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24859 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24859)) {
        case TAG_Nothing: {
          V v_it_24872;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24860 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24861 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24860)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24860, 0ULL, 1);
              heff_drop(v_sp_24861);
              v_it_24872 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24860, 0ULL, 1);
              heff_drop(v_sp_24861);
              v_it_24872 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24867 = heff_field(v_v1_24860, 0);
              V v_ru_24v1_24860_24HMeta = heff_take_reuse_n(v_v1_24860, 1ULL, 1);
              v_it_24872 = heff_tag_at_n(v_ru_24v1_24860_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24867, v_sp_24861})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24861);
              v_it_24872 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24860);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24872 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24872 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24872 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24872 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24872)) {
          case TAG_Nothing: {
            V v_t_24885;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24873 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24873)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24873, 0ULL, 1);
                v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24873, 0ULL, 1);
                v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24873, 0ULL, 1);
                v_t_24885 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24873);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24885 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24898;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24886 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24886)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24886, 0ULL, 1);
                v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24886, 0ULL, 1);
                v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24886, 0ULL, 1);
                v_t_24898 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24886);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24898 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24899 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24885; V a_7 = v_t_24898; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24899, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24900 = heff_field(v_it_24872, 0);
            heff_take_n(v_it_24872, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24900)) {
            case TAG_MkPair: {
              V v_m_24901 = heff_field(v_it1_24900, 0);
              V v_sp_24902 = heff_field(v_it1_24900, 1);
              heff_take_n(v_it1_24900, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24901, v_sp_24902, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24900);
            }
          }
          default: return heff_nomatch(v_it_24872);
          }
        }
        case TAG_Just: {
          V v_it1_24903 = heff_field(v_it_24859, 0);
          heff_take_n(v_it_24859, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24903)) {
          case TAG_MkPair: {
            V v_m_24904 = heff_field(v_it1_24903, 0);
            V v_sp_24905 = heff_field(v_it1_24903, 1);
            heff_take_n(v_it1_24903, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24904, v_sp_24905, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24903);
          }
        }
        default: return heff_nomatch(v_it_24859);
        }
      }
      case TAG_VLam: {
        V v_it_24920;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24908 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24909 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24908)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24908, 0ULL, 1);
            heff_drop(v_sp_24909);
            v_it_24920 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24908, 0ULL, 1);
            heff_drop(v_sp_24909);
            v_it_24920 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24915 = heff_field(v_v1_24908, 0);
            V v_ru_24v1_24908_24HMeta = heff_take_reuse_n(v_v1_24908, 1ULL, 1);
            v_it_24920 = heff_tag_at_n(v_ru_24v1_24908_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24915, v_sp_24909})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24909);
            v_it_24920 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24908);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24920 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24920 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24920 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24920 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24920)) {
        case TAG_Nothing: {
          V v_it_24933;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24921 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24922 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24921)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24921, 0ULL, 1);
              heff_drop(v_sp_24922);
              v_it_24933 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24921, 0ULL, 1);
              heff_drop(v_sp_24922);
              v_it_24933 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24928 = heff_field(v_v1_24921, 0);
              V v_ru_24v1_24921_24HMeta = heff_take_reuse_n(v_v1_24921, 1ULL, 1);
              v_it_24933 = heff_tag_at_n(v_ru_24v1_24921_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24928, v_sp_24922})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24922);
              v_it_24933 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24921);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24933 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24933 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24933 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24933 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24933)) {
          case TAG_Nothing: {
            V v_t_24946;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24934 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24934)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24934, 0ULL, 1);
                v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24934, 0ULL, 1);
                v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24934, 0ULL, 1);
                v_t_24946 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24934);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24946 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_24959;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_24947 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_24947)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24947, 0ULL, 1);
                v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24947, 0ULL, 1);
                v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24947, 0ULL, 1);
                v_t_24959 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_24947);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24959 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_24960 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24946; V a_7 = v_t_24959; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_24960, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_24961 = heff_field(v_it_24933, 0);
            heff_take_n(v_it_24933, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24961)) {
            case TAG_MkPair: {
              V v_m_24962 = heff_field(v_it1_24961, 0);
              V v_sp_24963 = heff_field(v_it1_24961, 1);
              heff_take_n(v_it1_24961, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24962, v_sp_24963, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_24961);
            }
          }
          default: return heff_nomatch(v_it_24933);
          }
        }
        case TAG_Just: {
          V v_it1_24964 = heff_field(v_it_24920, 0);
          heff_take_n(v_it_24920, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24964)) {
          case TAG_MkPair: {
            V v_m_24965 = heff_field(v_it1_24964, 0);
            V v_sp_24966 = heff_field(v_it1_24964, 1);
            heff_take_n(v_it1_24964, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24965, v_sp_24966, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_24964);
          }
        }
        default: return heff_nomatch(v_it_24920);
        }
      }
      case TAG_VCons: {
        V v_it_24980;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_VNeu: {
          V v_v1_24968 = heff_dup(heff_field(v_x_2413, 0));
          V v_sp_24969 = heff_dup(heff_field(v_x_2413, 1));
          switch (heff_tag_of(v_v1_24968)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24968, 0ULL, 1);
            heff_drop(v_sp_24969);
            v_it_24980 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24968, 0ULL, 1);
            heff_drop(v_sp_24969);
            v_it_24980 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24975 = heff_field(v_v1_24968, 0);
            V v_ru_24v1_24968_24HMeta = heff_take_reuse_n(v_v1_24968, 1ULL, 1);
            v_it_24980 = heff_tag_at_n(v_ru_24v1_24968_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24975, v_sp_24969})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24969);
            v_it_24980 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24968);
          }
          break;
        }
        case TAG_VCode: {
          v_it_24980 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_it_24980 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_it_24980 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_it_24980 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        switch (heff_tag_of(v_it_24980)) {
        case TAG_Nothing: {
          V v_it_24993;
          switch (heff_tag_of(v_x_2417)) {
          case TAG_VNeu: {
            V v_v1_24981 = heff_dup(heff_field(v_x_2417, 0));
            V v_sp_24982 = heff_dup(heff_field(v_x_2417, 1));
            switch (heff_tag_of(v_v1_24981)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24981, 0ULL, 1);
              heff_drop(v_sp_24982);
              v_it_24993 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24981, 0ULL, 1);
              heff_drop(v_sp_24982);
              v_it_24993 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24988 = heff_field(v_v1_24981, 0);
              V v_ru_24v1_24981_24HMeta = heff_take_reuse_n(v_v1_24981, 1ULL, 1);
              v_it_24993 = heff_tag_at_n(v_ru_24v1_24981_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24988, v_sp_24982})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24982);
              v_it_24993 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24981);
            }
            break;
          }
          case TAG_VCode: {
            v_it_24993 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_it_24993 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_it_24993 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_it_24993 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2417);
          }
          switch (heff_tag_of(v_it_24993)) {
          case TAG_Nothing: {
            V v_t_241006;
            switch (heff_tag_of(v_x_2413)) {
            case TAG_VNeu: {
              V v_v1_24994 = heff_dup(heff_field(v_x_2413, 0));
              switch (heff_tag_of(v_v1_24994)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24994, 0ULL, 1);
                v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24994, 0ULL, 1);
                v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24994, 0ULL, 1);
                v_t_241006 = heff_dup(v_x_2413);
                break;
              }
              case TAG_HError: {
                v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
                break;
              }
              default: heff_nomatch(v_v1_24994);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VLam: {
              v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VCons: {
              v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241006 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2413)));
              break;
            }
            default: heff_nomatch(v_x_2413);
            }
            V v_t_241019;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_v1_241007 = heff_dup(heff_field(v_x_2417, 0));
              switch (heff_tag_of(v_v1_241007)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_241007, 0ULL, 1);
                v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_241007, 0ULL, 1);
                v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_241007, 0ULL, 1);
                v_t_241019 = heff_dup(v_x_2417);
                break;
              }
              case TAG_HError: {
                v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
                break;
              }
              default: heff_nomatch(v_v1_241007);
              }
              break;
            }
            case TAG_VCode: {
              v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VLam: {
              v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VCons: {
              v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            case TAG_VOpaque: {
              v_t_241019 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2417)));
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            V v_t_241020 = ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_241006; V a_7 = v_t_241019; V a_8 = v_x_2413; V a_9 = v_x_2417; V r_ = heff_tr(g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_ms_241); r_; });
            return heff_tail(v_t_241020, 2, (V[]){v_hd_2411, v_k_2412});
          }
          case TAG_Just: {
            V v_it1_241021 = heff_field(v_it_24993, 0);
            heff_take_n(v_it_24993, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_241021)) {
            case TAG_MkPair: {
              V v_m_241022 = heff_field(v_it1_241021, 0);
              V v_sp_241023 = heff_field(v_it1_241021, 1);
              heff_take_n(v_it1_241021, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_241022, v_sp_241023, v_x_2413, v_x_2417, v_hd_2411, v_k_2412});
            }
            default: return heff_nomatch(v_it1_241021);
            }
          }
          default: return heff_nomatch(v_it_24993);
          }
        }
        case TAG_Just: {
          V v_it1_241024 = heff_field(v_it_24980, 0);
          heff_take_n(v_it_24980, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_241024)) {
          case TAG_MkPair: {
            V v_m_241025 = heff_field(v_it1_241024, 0);
            V v_sp_241026 = heff_field(v_it1_241024, 1);
            heff_take_n(v_it1_241024, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_241025, v_sp_241026, v_x_2417, v_x_2413, v_hd_2411, v_k_2412});
          }
          default: return heff_nomatch(v_it1_241024);
          }
        }
        default: return heff_nomatch(v_it_24980);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2413, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop(v_hd_2411);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2412;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2417);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2417);
      heff_drop(v_ms_241);
      heff_drop(v_w_240);
      heff_drop_rec(v_cs_245, 2);
      heff_drop(v_uf_242);
      heff_drop(v_hd_2411);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      V f_ = v_k_2412;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2413);
    }
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_b0_247 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = heff_tr(heff_apply(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam3, 1, 1, (V[]){v_b0_247})})}));
  V v_c_2416 = heff_tr(heff_apply(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_w_240), v_t_2415}));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_2411), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam4, 1, 9, (V[]){v_x_2413, v_ms_241, v_w_240, v_cs_245, v_uf_242, v_hd_2411, v_k_2412, v_r_243, v_g_244})});
}
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_b0_247 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_r_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam2, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2411, v_cs_245, v_uf_242, v_k_2412, v_r_243, v_g_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2eunify_2emsEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emsEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2emsEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InL, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emsEv(a[0]);
}
Clo g_heff_2eelab_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eufEv(a[0]);
}
Clo g_heff_2eelab_2eunify_2euAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euAlg_entry, 2, 0};

V g_heff_2eelab_2eunify_2euAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_apply(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_c2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_c2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_err_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_err_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_m_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      V v_ru_24q_247_24Catch = heff_take_reuse_n(v_q_247, 3ULL, 2);
      V v_x2_2411 = heff_tr(heff_apply(v_m_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_x21_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_247_24Catch, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_e_2414, v_st_2413});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          heff_drop(v_h_2410);
          return heff_tag_at_n(v_ru_24q_247_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2415}), v_st_2413});
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2euAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euAlg(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euH_lam1, 3, 0};

static V g_heff_2eelab_2eunify_2euH_val;
static int g_heff_2eelab_2eunify_2euH_st;
static V g_heff_2eelab_2eunify_2euH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2eunify_2euH_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euH_lam1_clo), ((V)&g_heff_2eelab_2eunify_2euAlg_clo)});
}
V g_heff_2eelab_2eunify_2euH_get(void) {
  if (g_heff_2eelab_2eunify_2euH_st == 2) return g_heff_2eelab_2eunify_2euH_val;
  if (g_heff_2eelab_2eunify_2euH_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2eunify_2euH_st = 1;
  g_heff_2eelab_2eunify_2euH_val = heff_tr(g_heff_2eelab_2eunify_2euH_init());
  g_heff_2eelab_2eunify_2euH_st = 2;
  return g_heff_2eelab_2eunify_2euH_val;
}
V g_heff_2eelab_2eunify_2euH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_c_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_c_241});
}
V g_heff_2eelab_2eunify_2euH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_c_244 = args[2];
  V v_x1_245 = heff_tr(heff_apply(v_m_242, 1, (V[]){v_c_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_entry, 3, 0};

V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(V v_ms_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam0, 1, 1, (V[]){heff_dup(v_ms_240)})})});
  HEFF_LAST return g_co_2eop_24s1802027244x918867378(v_t_245, heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam1, 1, 2, (V[]){v_hd_241, v_k_242}));
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_ms_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_244 = ({ V a_0 = heff_take_field(v_c_243, 2); V a_1 = v_ms_240; V r_ = (g_list_2efoldl_24s895450532x1092988905(a_0, a_1)); heff_drop(v_ms_240); r_; });
  return ({ V rv_2 = v_ps_244; V rr_ = heff_rec_reuse_n(v_c_243, 251ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_Put, 2, (V[]){v_x_246, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_247}), v_hd_241, v_k_242));
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry, 5, 0};

V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(V v_cs_240, V v_l_241, V v_r_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0, 1, 3, (V[]){v_cs_240, v_l_241, v_r_242})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_248, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec_n(4, shape_shape__left__right__failed, (V[]){v_cs_240, v_l_241, v_r_242, NTAG(TAG_False)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_take_field(v_c_245, 5)});
  return ({ V rv_5 = v_t_247; V rr_ = heff_rec_reuse_n(v_c_245, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2410}), v_hd_243, v_k_244));
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry, 2, 0};

V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24HLocal = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_243 = (g_map_2elookup_24s567992785x1569911877(v_l_242, heff_rfield(v_r_240, 2)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 3);
      V v_t_244 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24HLocal, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_244})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){v_t_245});
    }
    case TAG_Just: {
      V v_l_27_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24HLocal, 1);
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam0, 2, 2, (V[]){v_r_240, v_l_27_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_HGlobal: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam1, 2, 1, (V[]){v_x_2411});
  }
  case TAG_HMeta: {
    V v_ru_24x2_241_24HMeta = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_2415 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){v_t_2416});
  }
  case TAG_HError: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2417 = heff_tag_n(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
    return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_l_27_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V v_t_249 = heff_intSub(heff_get_n(v_r_240, 1, 3), v_l_27_246);
  V v_t_2410 = heff_tag_n(TAG_SLocal, 1, (V[]){heff_intSub(v_t_249, MK_INT(1LL))});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1), heff_take_field(v_pr_242, 2)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nom: {
      V v_a_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2417}));
      break;
    }
    case TAG_Describe: {
      V v_a_2418 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2418}));
      break;
    }
    case TAG_Become: {
      V v_a_2419 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_c_2423 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419});
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_a_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2428}));
      break;
    }
    case TAG_Describe: {
      V v_a_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2429}));
      break;
    }
    case TAG_Become: {
      V v_a_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_2411, v_a_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_a_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0, 2, 0};
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(V v_g_240, V v_m_241, V v_pr_242, V v_i_243, V v_ls_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_i_243);
    heff_drop(v_ls_244);
    return ((V)&g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0_clo);
  }
  case TAG_Cons: {
    V v_fc_248 = heff_field(v_x7_245, 0);
    V v_rest_249 = heff_field(v_x7_245, 1);
    heff_take_n(v_x7_245, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(v_fc_248, 1, (V[]){heff_dup(v_ls_244)}));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkField: {
      V v_ty_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      V v_pr_2413 = (g_heff_2eelab_2eunify_2eiterateLift(heff_dup(v_i_243), heff_dup(v_pr_242)));
      V v_c_2414 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_pr_2413, heff_dup(v_ty_2411)}));
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1, 2, 8, (V[]){v_c_2414, v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3(V self, V *args) {
  V v_u_2419 = args[0];
  V v_ty_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2419);
  return v_ty_2411;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4(V self, V *args) {
  V v_u_2421 = args[0];
  V v_v_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  return v_v_2420;
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_i_243 = heff_env(self)[1];
  V v_ty_2411 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_ls_244 = heff_env(self)[5];
  V v_rest_249 = heff_env(self)[6];
  V v_hd_2415 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2418 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), heff_dup(v_i_243));
  V v_v_2420 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2418}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam3, 1, 1, (V[]){v_ty_2411}), NTAG(TAG_Nothing)));
  V v_c_2422 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(v_g_240, v_m_241, v_pr_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_tag_n(TAG_LSnoc, 2, (V[]){v_ls_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam4, 1, 1, (V[]){v_v_2420})}), v_rest_249));
  return heff_tail(v_c_2422, 2, (V[]){v_hd_2415, heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam5, 1, 2, (V[]){v_k_2416, v_x_2417})});
}
V g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_i_243 = heff_env(self)[2];
  V v_ty_2411 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_m_241 = heff_env(self)[5];
  V v_ls_244 = heff_env(self)[6];
  V v_rest_249 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602_lam2, 1, 9, (V[]){v_pr_242, v_i_243, v_ty_2411, v_g_240, v_m_241, v_ls_244, v_rest_249, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0, 2, 0};
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry, 2, 0};

V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0, 1, 1, (V[]){v_t0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})));
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2418 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2417));
  return heff_tail(v_c_2418, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam3, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2422));
  return heff_tail(v_c_2423, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam5, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2432 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2411, v_x_2431));
  return heff_tail(v_c_2432, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam8, 1, 1, (V[]){v_k_245})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2434 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_implicit_2437 = heff_env(self)[3];
  V v_dflt_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2434, v_x_2439, v_x_2441, v_implicit_2437, v_dflt_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2435 = heff_env(self)[3];
  V v_cod_2436 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2434 = heff_env(self)[7];
  V v_implicit_2437 = heff_env(self)[8];
  V v_dflt_2438 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2440 = (g_heff_2eelab_2eunify_2erenameCloTy_24s647007288x1781510010(v_g_240, v_m_241, v_pr_242, v_dom_2435, v_cod_2436));
  return heff_tail(v_c_2440, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam10, 1, 5, (V[]){v_k_245, v_level_2434, v_x_2439, v_implicit_2437, v_dflt_2438})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11(V self, V *args) {
  V v_x_2448 = args[0];
  V v_fieldTypes_2444 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2442 = heff_env(self)[2];
  V v_defaults_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = ({ V rv_2 = heff_arrayFromList(v_x_2448); V rr_ = heff_rec_reuse_n(v_fieldTypes_2444, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2442, v_t_2449, v_defaults_2445});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13(V self, V *args) {
  V v_a_2457 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2458 = heff_tr(heff_apply(v_a_2457, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_tail(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_t_2458});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15(V self, V *args) {
  V v_x_2462 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_k_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2455, heff_arrayFromList(v_x_2462)});
  V f_ = v_k_2461;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2459;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam15, 1, 2, (V[]){v_k_2455, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12(V self, V *args) {
  V v_p_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2454)) {
  case TAG_MkPair: {
    V v_k_2455 = heff_field(v_p_2454, 0);
    V v_args_2456 = heff_field(v_p_2454, 1);
    heff_take_n(v_p_2454, 3ULL, 2);
    V v_c_2459 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2456)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam14, 2, 2, (V[]){v_c_2459, v_k_2455});
  }
  default: return heff_nomatch(v_p_2454);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16(V self, V *args) {
  V v_x_2465 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2465)));
  V v_t_2467 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2465));
  V v_t_2468 = (g_list_2emap_24s1173914895x100384474(v_x_2465));
  V v_t_2469 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2466), v_t_2467, heff_arrayFromList(v_t_2468)});
  V v_x_2470 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2469});
  V f_ = v_k_245;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2472});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_VU: {
    V v_u_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_249});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2410 = heff_field(v_x_248, 0);
    V v_sp_2411 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 5);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_HLocal: {
      V v_c_2416 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2421 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2421, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2425 = heff_field(v_it1_2410, 0);
      V v_ru_24it1_2410_24HMeta = heff_take_reuse_n(v_it1_2410, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_m_27_2425), heff_dup(v_m_241))) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2411);
        heff_drop(v_m_27_2425);
        V v_t_2427 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2428 = heff_tag_at_n(v_ru_24it1_2410_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
        return (g_co_2eop_24s1802027244x918867378(v_t_2428, v_hd_244, v_k_245));
      } else {
        heff_drop_cell(v_ru_24it1_2410_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2425; V a_4 = v_sp_2411; V a_5 = v_hd_244; V a_6 = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam6, 1, 1, (V[]){v_k_245}); V r_ = (g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2411); r_; });
      }
    }
    case TAG_HError: {
      V v_c_2430 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_2410));
      return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2411, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  case TAG_VFunction: {
    V v_level_2434 = heff_field(v_x_248, 0);
    V v_dom_2435 = heff_field(v_x_248, 1);
    V v_cod_2436 = heff_field(v_x_248, 2);
    V v_implicit_2437 = heff_field(v_x_248, 3);
    V v_dflt_2438 = heff_field(v_x_248, 4);
    heff_take_n(v_x_248, 31ULL, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2435), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2435, v_cod_2436, v_hd_244, v_k_245, v_level_2434, v_implicit_2437, v_dflt_2438})));
  }
  case TAG_VRecord: {
    V v_level_2442 = heff_field(v_x_248, 0);
    V v_capture_2443 = heff_field(v_x_248, 1);
    V v_fieldTypes_2444 = heff_field(v_x_248, 2);
    V v_defaults_2445 = heff_field(v_x_248, 3);
    heff_take_n(v_x_248, 15ULL, 4);
    V v_t_2446 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2444, 2)));
    V v_c_2447 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s318234847x586639602(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2443, v_t_2446));
    return heff_tail(v_c_2447, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam11, 1, 4, (V[]){v_fieldTypes_2444, v_k_245, v_level_2442, v_defaults_2445})});
  }
  case TAG_VSum: {
    V v_vs_2450 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2451 = heff_arrayToList(heff_take_field(v_vs_2450, 0));
    V v_t_2452 = heff_arrayToList(heff_get_n(v_vs_2450, 2, 3));
    V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
    V v_c_2464 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2453));
    return heff_tail(v_c_2464, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam16, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2471 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_a_2471, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2473 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2473});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0, 1, 0};
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry, 5, 0};

V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(V v_entry_240, V v_arity_241, V v_ty_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_246, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam1, 1, 5, (V[]){v_entry_240, v_arity_241, v_ty_242, v_hd_243, v_k_244})));
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam0(V self, V *args) {
  V v_c_245 = args[0];
  return heff_get_n(v_c_245, 4, 8);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2414}), v_hd_2411, v_k_2412));
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam3, 1, 2, (V[]){v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V f_ = v_k_244;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_entry_240 = heff_env(self)[0];
  V v_arity_241 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2enewMetaIn_clo), 3, (V[]){v_entry_240, v_arity_241, v_ty_242}));
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){v_t_248})});
  V v_c_2410 = heff_tr(heff_apply(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){v_t_249}));
  V v_c_2415 = heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam2, 2, 1, (V[]){v_c_2410});
  return heff_tail(v_c_2415, 2, (V[]){v_hd_243, heff_clo_n(g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_lam4, 1, 2, (V[]){v_k_244, v_x_247})});
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry, 5, 0};

V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(V v_m_240, V v_sol_241, V v_stx_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam0, 1, 3, (V[]){v_m_240, v_sol_241, v_stx_242})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2410, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam1, 1, 2, (V[]){v_hd_243, v_k_244})));
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_sol_241 = heff_env(self)[1];
  V v_stx_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_240), heff_rfield(v_c_245, 3)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_sol_241);
    heff_drop(v_stx_242);
    return v_c_245;
  }
  case TAG_Just: {
    V v_e_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_248 = ({ V rv_1 = heff_tag_n(TAG_Just, 1, (V[]){v_sol_241}); V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_stx_242}); V rr_ = heff_rec_reuse_n(v_e_247, 57ULL, 6, shape_ty__sol__solStx__arity__name__span); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_mc_249 = (g_map_2einsert_24s1689409319x1710080871(v_m_240, v_t_248, heff_take_field(v_c_245, 3)));
    return ({ V rv_3 = v_mc_249; V rr_ = heff_rec_reuse_n(v_c_245, 247ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2412}), v_hd_243, v_k_244));
}
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str1, 1, "\?");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str3, 5, ") := ");
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry, 4, 0};

V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(V v_m_240, V v_stx_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam0, 1, 2, (V[]){v_m_240, v_stx_241})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2413, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  V v_m_240 = heff_env(self)[2];
  V v_e_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_247);
  V v_t_248 = ({ V b_0 = heff_get_n(v_c_244, 3, 8); V r_ = (g_heff_2eelab_2eunify_2ezonker(b_0)); heff_drop(b_0); r_; });
  V v_e_249 = heff_tr(heff_apply(heff_get_n(v_t_248, 0, 2), 1, (V[]){v_stx_241}));
  V v_t_2410 = (g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_249));
  return heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str1), heff_strAppend(heff_intShow(v_m_240), heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str2), heff_strAppend(heff_get_n(v_e_246, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str3), v_t_2410)))));
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam0(V self, V *args) {
  V v_c_244 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_stx_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_map_2elookup_24s567992785x1569911877(heff_dup(v_m_240), heff_rfield(v_c_244, 3)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_m_240);
    heff_drop(v_stx_241);
    return v_c_244;
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2411 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_246, 5)), ((V)&g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_str0), heff_clo_n(g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam1, 1, 4, (V[]){heff_dup(v_c_244), v_stx_241, v_m_240, v_e_246})});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_take_field(v_c_244, 6)});
    return ({ V rv_6 = v_t_2412; V rr_ = heff_rec_reuse_n(v_c_244, 191ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InL, 1, (V[]){v_t_2415}), v_hd_242, v_k_243));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_map_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2(V self, V *args) {
  V v_i_2418 = args[0];
  V v_n_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intSub(heff_intSub(v_n_244, v_i_2418), MK_INT(1LL));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V f_ = v_k_247;
  args[0] = v_v_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2421 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(v_storeM_242, v_t_2421, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam4, 1, 2, (V[]){v_k_247, v_v_2426})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam2, 1, 1, (V[]){heff_dup(v_n_244)}), v_kept_245));
  V v_t_2420 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2417, heff_arrayFromList(v_t_2419), v_x_249});
  V v_t_2421 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2420));
  V v_x1_2422 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2421), NTAG(TAG_LNil)));
  V v_v_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_v_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_v_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_v_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(heff_dup(v_storeM_242), heff_dup(v_v_2426), heff_dup(v_t_2421), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam3, 1, 5, (V[]){v_storeM_242, v_t_2421, v_hd_246, v_k_247, v_v_2426})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  V v_c_2416 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2enewMetaFrom_24s1501582329x1209620687_clo), 3, (V[]){v_entry_243, v_t_2410, v_t_2415}));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_248, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam1, 1, 7, (V[]){v_hd_245, heff_dup(v_sp_244), v_k_246, v_pr_242, v_g_240, v_m_241, v_m_27_243})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a[0], a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a[4]); return r;
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam4(V self, V *args) {
  V v_a_2421 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425;
  switch (heff_tag_of(v_a_2421)) {
  case TAG_PVar: {
    V v_l_2422 = heff_field(v_a_2421, 0);
    heff_take_n(v_a_2421, 1ULL, 1);
    V v_x3_2423 = ({ V a_0 = v_l_2422; V b_1 = heff_get_n(v_pr_242, 2, 3); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2423)) {
    case TAG_Nothing: {
      v_x1_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2423, 0ULL, 1);
      v_x1_2425 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2423);
    }
    break;
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    v_x1_2425 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_2421);
  }
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam6(V self, V *args) {
  V v_i_2429 = args[0];
  V v_a_2430 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2430)) {
  case TAG_PVar: {
    V v_l_2431 = heff_field(v_a_2430, 0);
    V v_ru_24a_2430_24PVar = heff_take_reuse_n(v_a_2430, 1ULL, 1);
    V v_x3_2432 = ({ V a_0 = v_l_2431; V b_1 = heff_get_n(v_pr_242, 2, 3); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_2432)) {
    case TAG_Nothing: {
      heff_drop(v_i_2429);
      heff_drop_cell(v_ru_24a_2430_24PVar, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2432, 0ULL, 1);
      return heff_tag_at_n(v_ru_24a_2430_24PVar, TAG_Just, 1, (V[]){v_i_2429});
    }
    default: return heff_nomatch(v_x3_2432);
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2429);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2430);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2438 = ({ V a_0 = v_x_2437; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2438, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_args_2420 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2428 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2420));
  V v_t_2434 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2420));
  V v_t_2435 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2434));
  V v_c_2436 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo), 6, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2427, v_t_2428, v_t_2435}));
  return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8(V self, V *args) {
  V v_c_2440 = args[0];
  return heff_get_n(v_c_2440, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_2439 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = ({ V a_0 = v_m_27_243; V a_1 = v_x_2442; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2442); r_; });
  switch (heff_tag_of(v_t_2443)) {
  case TAG_Nothing: {
    V v_t_2444 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2445, v_hd_245, v_k_2439));
  }
  case TAG_Just: {
    V v_e_2446 = heff_field(v_t_2443, 0);
    heff_take_n(v_t_2443, 1ULL, 1);
    heff_drop(v_hd_245);
    V f_ = v_k_2439;
    args[0] = v_e_2446;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2443);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam13(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2455);
  V v_t_2457 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2454);
  V f_ = v_k_2456;
  args[0] = heff_intSub(v_t_2457, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam12(V self, V *args) {
  V v_a_2449 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2449)) {
  case TAG_PVar: {
    V v_l_2450 = heff_field(v_a_2449, 0);
    V v_ru_24a_2449_24PVar = heff_take_reuse_n(v_a_2449, 1ULL, 1);
    V v_t_2451 = (g_map_2elookup_24s567992785x1569911877(v_l_2450, heff_rfield(v_pr_242, 2)));
    switch (heff_tag_of(v_t_2451)) {
    case TAG_Nothing: {
      heff_drop_rec(v_pr_242, 3);
      V v_t_2452 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2453 = heff_tag_at_n(v_ru_24a_2449_24PVar, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2452})});
      V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
      args[0] = v_t_2453;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_l_27_2454 = heff_field(v_t_2451, 0);
      heff_take_n(v_t_2451, 1ULL, 1);
      heff_drop_cell(v_ru_24a_2449_24PVar, 1);
      return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2454});
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    V v_t_2458 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2459;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_2449);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam14(V self, V *args) {
  V v_x_2461 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2448 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2462 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2461), v_x_2448});
  V f_ = v_k_246;
  args[0] = v_t_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam11(V self, V *args) {
  V v_x_2448 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2420 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2460 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam12, 1, 1, (V[]){v_pr_242}), v_args_2420));
  return heff_tail(v_c_2460, 2, (V[]){v_hd_245, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam14, 1, 3, (V[]){v_m_27_243, v_x_2448, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam10(V self, V *args) {
  V v_x_2447 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2420 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2447, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam11, 1, 5, (V[]){v_pr_242, v_args_2420, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15(V self, V *args) {
  V v_c_2464 = args[0];
  return heff_get_n(v_c_2464, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam16(V self, V *args) {
  V v_x_2466 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2467 = ({ V a_0 = v_m_27_243; V a_1 = v_x_2466; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2466); r_; });
  switch (heff_tag_of(v_t_2467)) {
  case TAG_Nothing: {
    V v_t_2468 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2469, v_hd_245, v_k_2463));
  }
  case TAG_Just: {
    V v_e_2470 = heff_field(v_t_2467, 0);
    heff_take_n(v_t_2467, 1ULL, 1);
    heff_drop(v_hd_245);
    V f_ = v_k_2463;
    args[0] = v_e_2470;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2467);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_pr_242 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  V v_m_241 = heff_env(self)[6];
  V v_m_27_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = ({ V a_0 = v_x_2412; V a_1 = v_x_249; V a_2 = v_sp_244; V r_ = (g_heff_2eelab_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_249); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2417 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2414)));
    V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2415); r_; });
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_t_2417 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2414))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2414);
      heff_drop_cell(v_ru_24t_2413_24Just, 1);
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    heff_drop(v_sp_244);
    heff_drop_rec(v_pr_242, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_m_27_243);
    V v_t_2418 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2419, v_hd_245, v_k_246));
  }
  case TAG_Just: {
    V v_args_2420 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    V v_t_2426 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2420));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      V v_k_2439 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam5, 1, 8, (V[]){v_args_2420, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
      V v_t_2441 = heff_tag_at_n(v_ru_24t_2417_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam8_clo)})});
      return (g_co_2eop_24s1802027244x918867378(v_t_2441, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam9, 1, 3, (V[]){v_m_27_243, v_hd_245, v_k_2439})));
    }
    case TAG_False: {
      heff_drop(v_sp_244);
      V v_k_2463 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2420, heff_dup(v_m_27_243), v_k_246});
      V v_t_2465 = heff_tag_at_n(v_ru_24t_2417_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam15_clo)})});
      return (g_co_2eop_24s1802027244x918867378(v_t_2465, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam16, 1, 3, (V[]){v_m_27_243, v_hd_245, v_k_2463})));
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_m_241 = heff_env(self)[5];
  V v_m_27_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam2_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2411, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_lam3, 1, 8, (V[]){v_x_249, v_sp_244, v_hd_245, v_k_246, v_pr_242, v_g_240, v_m_241, v_m_27_243})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1), heff_take_field(v_pr_242, 2)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_apply(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1, 1, 1, (V[]){v_v_2414})})}));
    V v_c_2423;
    switch (heff_tag_of(v_v_2416)) {
    case TAG_Nom: {
      V v_v_2417 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2417}));
      break;
    }
    case TAG_Describe: {
      V v_v_2418 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2418}));
      break;
    }
    case TAG_Become: {
      V v_v_2419 = heff_field(v_v_2416, 0);
      heff_take_n(v_v_2416, 1ULL, 1);
      v_c_2423 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419});
      break;
    }
    default: heff_nomatch(v_v_2416);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4, 2, 2, (V[]){v_c_2423, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    V v_c_2434;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nom: {
      V v_v_2428 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2428}));
      break;
    }
    case TAG_Describe: {
      V v_v_2429 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2429}));
      break;
    }
    case TAG_Become: {
      V v_v_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      v_c_2434 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430});
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8, 2, 1, (V[]){v_c_2434});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2419 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_2411, v_v_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam3, 1, 1, (V[]){v_k_2421})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam4(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam5, 1, 2, (V[]){v_k_2425, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam6(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2430, v_hd_2431, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514_lam9, 1, 1, (V[]){v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(V v_g_240, V v_m_241, V v_pr_242, V v_v0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0, 1, 1, (V[]){v_v0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1, 1, 5, (V[]){v_pr_242, v_hd_244, v_g_240, v_m_241, v_k_245})));
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_v0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_v0_243; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2416));
  return heff_tail(v_t_2417, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2420));
  return heff_tail(v_t_2421, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428 = (g_heff_2eelab_2eunify_2erenameSpine_24s557480943x433342268(v_g_240, v_m_241, v_pr_242, v_sp_2410, v_x_2427));
  return heff_tail(v_t_2428, 2, (V[]){v_hd_244, v_k_245});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SCode, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SLam, 2, (V[]){v_x_2435, v_x_2451});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_fty_2431 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_body_2432 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2436 = heff_tr(heff_apply(v_fty_2431, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2437 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2436)));
  V v_t_2449;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFunction: {
    V v_dom_2440 = heff_field(v_t_2437, 1);
    heff_take_n(v_t_2437, 2ULL, 4);
    heff_drop(v_t_2436);
    v_t_2449 = v_dom_2440;
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2437, 0ULL, 3);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeInt: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFloat: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeString: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeRune: {
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2449 = v_t_2436;
    break;
  }
  case TAG_NoRules: {
    v_t_2449 = v_t_2436;
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_c_2450 = (g_heff_2eelab_2eunify_2erenameClo_24s1103366045x944243514(v_g_240, v_m_241, v_pr_242, v_t_2449, v_body_2432));
  return heff_tail(v_c_2450, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam7, 1, 2, (V[]){v_k_245, v_x_2435})});
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2464});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2461 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_240, v_m_241, v_pr_242, v_v_2461, v_hd_2462, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam10, 1, 1, (V[]){v_k_2463})));
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2467 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2467;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2457, v_x_2468});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2465;
  args[0] = v_hd_2466;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam12, 1, 2, (V[]){v_k_2467, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_x_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    V v_c_2465;
    switch (heff_tag_of(v_x_2458)) {
    case TAG_Nom: {
      V v_v_2459 = heff_field(v_x_2458, 0);
      heff_take_n(v_x_2458, 1ULL, 1);
      v_c_2465 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2459}));
      break;
    }
    case TAG_Describe: {
      V v_v_2460 = heff_field(v_x_2458, 0);
      heff_take_n(v_x_2458, 1ULL, 1);
      v_c_2465 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2460}));
      break;
    }
    case TAG_Become: {
      V v_v_2461 = heff_field(v_x_2458, 0);
      heff_take_n(v_x_2458, 1ULL, 1);
      v_c_2465 = heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam9, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2461});
      break;
    }
    default: heff_nomatch(v_x_2458);
    }
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam11, 2, 2, (V[]){v_c_2465, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2470)));
  V v_t_2472 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2470));
  V v_t_2473 = (g_list_2emap_24s1173914895x100384474(v_x_2470));
  V v_t_2474 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2471), v_t_2472, heff_arrayFromList(v_t_2473)});
  V v_x_2475 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2474});
  V f_ = v_k_245;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_VNeu: {
    V v_it1_249 = heff_field(v_x_248, 0);
    V v_sp_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 5);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_HLocal: {
      V v_c_2415 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245})});
    }
    case TAG_HGlobal: {
      V v_c_2419 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam3, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245})});
    }
    case TAG_HMeta: {
      V v_m_27_2422 = heff_field(v_it1_249, 0);
      V v_ru_24it1_249_24HMeta = heff_take_reuse_n(v_it1_249, 1ULL, 1);
      if (heff_intEq_c(heff_dup(v_m_27_2422), heff_dup(v_m_241))) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2410);
        heff_drop(v_m_27_2422);
        V v_t_2424 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2425 = heff_tag_at_n(v_ru_24it1_249_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
        return (g_co_2eop_24s1802027244x918867378(v_t_2425, v_hd_244, v_k_245));
      } else {
        heff_drop_cell(v_ru_24it1_249_24HMeta, 1);
        return ({ V a_0 = v_g_240; V a_1 = v_m_241; V a_2 = v_pr_242; V a_3 = v_m_27_2422; V a_4 = v_sp_2410; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_sp_2410); r_; });
      }
    }
    case TAG_HError: {
      V v_c_2426 = heff_tr(g_heff_2eelab_2eunify_2erenameHead_24s663511427x468720917(heff_dup(v_pr_242), v_it1_249));
      return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2410, v_hd_244, v_k_245})});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_VCode: {
    V v_t_2429 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_240, v_m_241, v_pr_242, v_t_2429, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam5, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VLam: {
    V v_fty_2431 = heff_field(v_x_248, 0);
    V v_body_2432 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2433 = heff_tr(heff_apply(heff_dup(v_fty_2431), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_c_2434 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_t_2433}));
    return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam6, 1, 7, (V[]){v_fty_2431, v_g_240, v_m_241, v_pr_242, v_body_2432, v_hd_244, v_k_245})});
  }
  case TAG_VCons: {
    V v_d_2452 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_t_2453 = heff_arrayToList(heff_take_field(v_d_2452, 0));
    V v_t_2454 = heff_arrayToList(heff_get_n(v_d_2452, 2, 3));
    V v_t_2455 = (g_heff_2eutil_2edict_2ezipKV(v_t_2453, v_t_2454));
    V v_c_2469 = (g_heff_2eelab_2eunify_2etraverseU_24s132270497x402810186(heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam8, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    return heff_tail(v_c_2469, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_lam13, 1, 1, (V[]){v_k_245})});
  }
  case TAG_VOpaque: {
    heff_drop(v_pr_242);
    heff_drop(v_hd_244);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SOpaque);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam4(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_entry, 5, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_246 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_pr_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_245, v_t_247});
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_m_242), v_pr_248, v_rhs_244}));
  V v_m_2413 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam0, 2, 1, (V[]){v_c_249});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_m_2413, ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2_clo)})});
  V v_c_2432 = heff_tr(heff_apply(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){v_t_2431}));
  return heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam4, 2, 4, (V[]){v_c_2432, v_args_243, v_g_240, v_m_242});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam1, 1, 1, (V[]){v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam2(V self, V *args) {
  V v_e_2414 = args[0];
  switch (heff_tag_of(v_e_2414)) {
  case TAG_UnequalTys: {
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_e_2414})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_UnequalEls: {
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_e_2414})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_UnequalNeus: {
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_e_2414})});
    V f_ = ((V)&g_co_2eop_24s1532701784x592895222_clo);
    args[0] = v_t_2428;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_MentionsError: {
    return ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam3_clo);
  }
  default: return heff_nomatch(v_e_2414);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam7(V self, V *args) {
  V v_c_2445 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2446 = ({ V a_0 = v_m_242; V b_1 = heff_get_n(v_c_2445, 2, 8); V r_ = (g_map_2elookup_24s1338854231x236594845(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2446)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2446, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2446);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10(V self, V *args) {
  V v_c_2452 = args[0];
  return heff_get_n(v_c_2452, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11(V self, V *args) {
  V v_x_2454 = args[0];
  V v_v_2443 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2455 = ({ V a_0 = v_x_2454; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2454); r_; });
  V v_t_2456 = heff_tr(heff_apply(heff_get_n(v_t_2455, 0, 3), 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2443}));
  return ({ V a_0 = v_t_2456; V a_1 = v_hd_2450; V a_2 = v_k_2451; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a_0, a_1, a_2)); heff_drop(v_t_2456); r_; });
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_v_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam10_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2453, heff_dup(v_hd_2450), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam11, 1, 3, (V[]){v_v_2443, v_hd_2450, v_k_2451})));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  heff_drop(v_hd_2457);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam13(V self, V *args) {
  V v_x_2460 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2438 = heff_env(self)[1];
  V v_hd_2433 = heff_env(self)[2];
  V v_k_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2460);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s500720452x252477371(v_m_242, v_t_2438, v_hd_2433, v_k_2434));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_v_2443 = heff_env(self)[0];
  V v_hd_2433 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2438 = heff_env(self)[3];
  V v_k_2434 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2459;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_True: {
    v_c_2459 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam9, 2, 1, (V[]){v_v_2443});
    break;
  }
  case TAG_False: {
    heff_drop(v_v_2443);
    v_c_2459 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam12_clo);
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  return heff_tail(v_c_2459, 2, (V[]){heff_dup(v_hd_2433), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam13, 1, 4, (V[]){v_m_242, v_t_2438, v_hd_2433, v_k_2434})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_hd_2433 = heff_env(self)[1];
  V v_v_2443 = heff_env(self)[2];
  V v_t_2438 = heff_env(self)[3];
  V v_k_2434 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2444);
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam7, 1, 1, (V[]){heff_dup(v_m_242)})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2448, heff_dup(v_hd_2433), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam8, 1, 5, (V[]){v_v_2443, v_hd_2433, v_m_242, v_t_2438, v_k_2434})));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop(v_hd_2433);
    V f_ = v_k_2434;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2436 = heff_field(v_x_2435, 0);
    heff_take_n(v_x_2435, 1ULL, 1);
    V v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2438 = (g_heff_2eelab_2eunify_2elamsU(v_t_2437, v_body_2436));
    V v_x1_2439 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2438), NTAG(TAG_LNil)));
    V v_v_2443;
    switch (heff_tag_of(v_x1_2439)) {
    case TAG_Nom: {
      V v_x_2440 = heff_field(v_x1_2439, 0);
      heff_take_n(v_x1_2439, 1ULL, 1);
      v_v_2443 = v_x_2440;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2439, 0ULL, 1);
      v_v_2443 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2442 = heff_field(v_x1_2439, 0);
      heff_take_n(v_x1_2439, 1ULL, 1);
      v_v_2443 = v_x_2442;
      break;
    }
    default: heff_nomatch(v_x1_2439);
    }
    return (g_heff_2eelab_2eunify_2estoreSol_24s2041451543x1287687610(heff_dup(v_m_242), heff_dup(v_v_2443), heff_dup(v_t_2438), heff_dup(v_hd_2433), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam6, 1, 5, (V[]){v_m_242, v_hd_2433, v_v_2443, v_t_2438, v_k_2434})));
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2432;
  args[0] = heff_dup(v_hd_2433);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168_lam5, 1, 5, (V[]){v_k_2434, v_args_243, v_g_240, v_m_242, v_hd_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_249, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam1, 1, 8, (V[]){v_hd_246, heff_dup(v_sp_243), v_cs_241, v_self_245, v_rhs_244, v_k_247, v_g_240, v_m_242})));
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam5(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2454);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_args_2419 = heff_env(self)[0];
  V v_args_27_2443 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2449 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2419));
  V v_t_2450 = (g_heff_2eelab_2eunify_2ezipL(v_args_2419, v_args_27_2443));
  V v_t_2451 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s72861438x1377434747(MK_INT(0LL), v_t_2450));
  V v_t_2452 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2451));
  V v_c_2453 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eunify_2esolveWithPruned_24s1835210467x103612106_clo), 6, (V[]){v_g_240, heff_dup(v_m_242), v_m_242, v_x_2448, v_t_2449, v_t_2452}));
  return heff_tail(v_c_2453, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam5, 1, 1, (V[]){v_k_247})});
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6(V self, V *args) {
  V v_c_2456 = args[0];
  return heff_get_n(v_c_2456, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam7(V self, V *args) {
  V v_x_2458 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2459 = ({ V a_0 = v_m_242; V a_1 = v_x_2458; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2458); r_; });
  switch (heff_tag_of(v_t_2459)) {
  case TAG_Nothing: {
    V v_t_2460 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2460})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2461, v_hd_246, v_k_2455));
  }
  case TAG_Just: {
    V v_e_2462 = heff_field(v_t_2459, 0);
    heff_take_n(v_t_2459, 1ULL, 1);
    heff_drop(v_hd_246);
    V f_ = v_k_2455;
    args[0] = v_e_2462;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2459);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_g_240 = heff_env(self)[7];
  V v_m_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = ({ V a_0 = heff_dup(v_x_2413); V a_1 = v_x_2410; V a_2 = v_sp_243; V r_ = (g_heff_2eelab_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_sp_243); r_; });
  V v_t_2418;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_items_2415 = heff_field(v_t_2414, 0);
    V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
    V v_t_2416 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2415)));
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2416); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_t_2418 = heff_tag_at_n(v_ru_24t_2414_24Just, TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2415))});
      break;
    }
    case TAG_False: {
      heff_drop(v_items_2415);
      heff_drop_cell(v_ru_24t_2414_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nothing: {
    heff_drop(v_x_2413);
    heff_drop(v_x_2410);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    return (g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_args_2419 = heff_field(v_t_2418, 0);
    V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 1ULL, 1);
    V v_it_2432;
    switch (heff_tag_of(v_rhs_244)) {
    case TAG_VNeu: {
      V v_v1_2420 = heff_dup(heff_field(v_rhs_244, 0));
      V v_sp_2421 = heff_dup(heff_field(v_rhs_244, 1));
      switch (heff_tag_of(v_v1_2420)) {
      case TAG_HLocal: {
        heff_take_n(v_v1_2420, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2418_24Just, 1);
        heff_drop(v_sp_2421);
        v_it_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_v1_2420, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2418_24Just, 1);
        heff_drop(v_sp_2421);
        v_it_2432 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2427 = heff_field(v_v1_2420, 0);
        heff_take_n(v_v1_2420, 1ULL, 1);
        v_it_2432 = heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2427, v_sp_2421})});
        break;
      }
      case TAG_HError: {
        heff_drop_cell(v_ru_24t_2418_24Just, 1);
        heff_drop(v_sp_2421);
        v_it_2432 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_v1_2420);
      }
      break;
    }
    case TAG_VCode: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VLam: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VCons: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VOpaque: {
      heff_drop_cell(v_ru_24t_2418_24Just, 1);
      v_it_2432 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_rhs_244);
    }
    switch (heff_tag_of(v_it_2432)) {
    case TAG_Nothing: {
      heff_drop(v_x_2413);
      heff_drop(v_x_2410);
      heff_drop(v_self_245);
      V v_t_2433 = (g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(v_g_240, v_cs_241, v_m_242, v_args_2419, v_rhs_244));
      return heff_tail(v_t_2433, 2, (V[]){v_hd_246, v_k_247});
    }
    case TAG_Just: {
      V v_it1_2434 = heff_field(v_it_2432, 0);
      V v_ru_24it_2432_24Just = heff_take_reuse_n(v_it_2432, 1ULL, 1);
      switch (heff_tag_of(v_it1_2434)) {
      case TAG_MkPair: {
        V v_m_27_2435 = heff_field(v_it1_2434, 0);
        V v_sp_27_2436 = heff_field(v_it1_2434, 1);
        heff_take_n(v_it1_2434, 3ULL, 2);
        if (heff_intEq_c(v_m_27_2435, heff_dup(v_m_242))) {
          V v_t_2438 = ({ V a_0 = v_x_2413; V a_1 = v_x_2410; V a_2 = v_sp_27_2436; V r_ = (g_heff_2eelab_2eunify_2epatSpine(a_0, a_1, a_2)); heff_drop(v_x_2410); heff_drop(v_sp_27_2436); r_; });
          V v_t_2442;
          switch (heff_tag_of(v_t_2438)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24it_2432_24Just, 1);
            v_t_2442 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_items_2439 = heff_field(v_t_2438, 0);
            heff_take_n(v_t_2438, 1ULL, 1);
            V v_t_2440 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2439)));
            V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2440); r_; });
            switch (heff_tag_of(v_t_2441)) {
            case TAG_True: {
              v_t_2442 = heff_tag_at_n(v_ru_24it_2432_24Just, TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2439))});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2432_24Just, 1);
              heff_drop(v_items_2439);
              v_t_2442 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_t_2441);
            }
            break;
          }
          default: heff_nomatch(v_t_2438);
          }
          switch (heff_tag_of(v_t_2442)) {
          case TAG_Nothing: {
            heff_drop(v_g_240);
            heff_drop(v_m_242);
            heff_drop(v_args_2419);
            return (g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_Just: {
            V v_args_27_2443 = heff_field(v_t_2442, 0);
            V v_ru_24t_2442_24Just = heff_take_reuse_n(v_t_2442, 1ULL, 1);
            V v_t_2444 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2443, v_args_2419));
            switch (heff_tag_of(v_t_2444)) {
            case TAG_True: {
              heff_drop(v_cs_241);
              heff_drop(v_self_245);
              heff_drop(v_rhs_244);
              heff_drop(v_hd_246);
              heff_drop(v_g_240);
              heff_drop(v_m_242);
              heff_drop(v_args_2419);
              heff_drop(v_args_27_2443);
              heff_drop_cell(v_ru_24t_2442_24Just, 1);
              V f_ = v_k_247;
              args[0] = NTAG(TAG_MkUnit);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            }
            case TAG_False: {
              V v_t_2445 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_27_2443));
              V v_t_2446 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2419));
              if (heff_intEq_c(v_t_2445, v_t_2446)) {
                heff_drop(v_cs_241);
                heff_drop(v_self_245);
                heff_drop(v_rhs_244);
                V v_k_2455 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam4, 1, 6, (V[]){v_args_2419, v_args_27_2443, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                V v_t_2457 = heff_tag_at_n(v_ru_24t_2442_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam6_clo)})});
                return (g_co_2eop_24s1802027244x918867378(v_t_2457, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam7, 1, 3, (V[]){v_m_242, v_hd_246, v_k_2455})));
              } else {
                heff_drop(v_g_240);
                heff_drop(v_m_242);
                heff_drop(v_args_2419);
                heff_drop(v_args_27_2443);
                heff_drop_cell(v_ru_24t_2442_24Just, 1);
                return (g_heff_2eelab_2eunify_2epostponeU_24s1110454390x241513703(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
              }
            }
            default: return heff_nomatch(v_t_2444);
            }
          }
          default: return heff_nomatch(v_t_2442);
          }
        } else {
          heff_drop(v_x_2413);
          heff_drop(v_x_2410);
          heff_drop(v_self_245);
          heff_drop_cell(v_ru_24it_2432_24Just, 1);
          heff_drop(v_sp_27_2436);
          V v_t_2463 = (g_heff_2eelab_2eunify_2esolveRhs_24s1214063133x1808577168(v_g_240, v_cs_241, v_m_242, v_args_2419, v_rhs_244));
          return heff_tail(v_t_2463, 2, (V[]){v_hd_246, v_k_247});
        }
      }
      default: return heff_nomatch(v_it1_2434);
      }
    }
    default: return heff_nomatch(v_it_2432);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_self_245 = heff_env(self)[3];
  V v_rhs_244 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  V v_m_242 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam2_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2412, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_lam3, 1, 9, (V[]){v_x_2410, v_sp_243, v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247, v_g_240, v_m_242})));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4, 4, 0};

static V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val;
static int g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st;
static V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_init(void) {
  return heff_rec_n(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo), ((V)&g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135_clo), ((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1_clo), ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4_clo), ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s155420061x1171391962_clo)});
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void) {
  if (g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st == 2) return g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val;
  if (g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st = 1;
  g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val = heff_tr(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_init());
  g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_st = 2;
  return g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_val;
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s801930061x1099509052_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s2018865198x1593757741_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0_clo);
  }
  case TAG_False: {
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_True: {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1_clo);
        }
        case TAG_False: {
          V v_t_2424 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
          return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
        }
        default: return heff_nomatch(v_t_2421);
        }
      }
      case TAG_SpApp: {
        V v_t_2427 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      }
      case TAG_SpProj: {
        V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
      }
      case TAG_SpSpec: {
        V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2435 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2436 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2435);
        heff_drop(v_v_2436);
        V v_t_2437 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      }
      case TAG_SpApp: {
        V v_sq_27_2438 = heff_field(v_sp_27_245, 0);
        V v_v_27_2439 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2440 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2435, v_h_27_244, v_sq_27_2438));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam2, 2, 5, (V[]){v_c_2440, v_g_240, v_cs_241, v_v_2436, v_v_27_2439});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2435);
        heff_drop(v_v_2436);
        V v_t_2447 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2435);
        heff_drop(v_v_2436);
        V v_t_2451 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2452 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2453 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2452);
        heff_drop(v_x_2453);
        V v_t_2454 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2452);
        heff_drop(v_x_2453);
        V v_t_2457 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
      }
      case TAG_SpProj: {
        V v_sq_27_2458 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2459 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2460 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2452, heff_dup(v_h_27_244), v_sq_27_2458));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam4, 2, 8, (V[]){v_c_2460, v_x_2453, v_x_27_2459, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2452);
        heff_drop(v_x_2453);
        V v_t_2469 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_2470 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2471 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_2472 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2470);
        heff_drop(v_x_2471);
        heff_drop(v_v_2472);
        V v_t_2473 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2470);
        heff_drop(v_x_2471);
        heff_drop(v_v_2472);
        V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2470);
        heff_drop(v_x_2471);
        heff_drop(v_v_2472);
        V v_t_2479 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
      }
      case TAG_SpSpec: {
        V v_sq_27_2480 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2481 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_2482 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_2483 = heff_tr(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2470, heff_dup(v_h_27_244), v_sq_27_2480));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam6, 2, 11, (V[]){v_c_2483, v_x_2471, v_x_27_2481, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_2472, v_v_27_2482});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2436 = heff_env(self)[2];
  V v_v_27_2439 = heff_env(self)[3];
  V v_hd_2441 = heff_env(self)[4];
  V v_k_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2443);
  V v_t_2444 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_v_2436, v_v_27_2439));
  return heff_tail(v_t_2444, 2, (V[]){v_hd_2441, v_k_2442});
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam2(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2436 = heff_env(self)[3];
  V v_v_27_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam3, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2436, v_v_27_2439, v_hd_2441, v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2453 = heff_env(self)[0];
  V v_x_27_2459 = heff_env(self)[1];
  V v_k_2462 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2461 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2463);
  if (heff_strEq_c(v_x_2453, v_x_27_2459)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop(v_hd_2461);
    V f_ = v_k_2462;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2465 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    return (g_co_2eop_24s1802027244x918867378(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), v_hd_2461, v_k_2462));
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam4(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_c_2460 = heff_env(self)[0];
  V v_x_2453 = heff_env(self)[1];
  V v_x_27_2459 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2460;
  args[0] = heff_dup(v_hd_2461);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam5, 1, 9, (V[]){v_x_2453, v_x_27_2459, v_k_2462, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  heff_drop(v_hd_2488);
  V f_ = v_k_2489;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam9(V self, V *args) {
  V v_x_2492 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2472 = heff_env(self)[2];
  V v_v_27_2482 = heff_env(self)[3];
  V v_hd_2484 = heff_env(self)[4];
  V v_k_2485 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2492);
  V v_t_2493 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_v_2472, v_v_27_2482));
  return heff_tail(v_t_2493, 2, (V[]){v_hd_2484, v_k_2485});
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam7(V self, V *args) {
  V v_x_2486 = args[0];
  V v_x_2471 = heff_env(self)[0];
  V v_x_27_2481 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_2484 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_2472 = heff_env(self)[9];
  V v_v_27_2482 = heff_env(self)[10];
  V v_k_2485 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2486);
  V v_c_2491;
  if (heff_strEq_c(v_x_2471, v_x_27_2481)) {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_c_2491 = ((V)&g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam8_clo);
  } else {
    V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    v_c_2491 = heff_tr(heff_apply(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
  }
  return heff_tail(v_c_2491, 2, (V[]){heff_dup(v_hd_2484), heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam9, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2472, v_v_27_2482, v_hd_2484, v_k_2485})});
}
V g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam6(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  V v_x_2471 = heff_env(self)[1];
  V v_x_27_2481 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_2472 = heff_env(self)[9];
  V v_v_27_2482 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2483;
  args[0] = heff_dup(v_hd_2484);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672_lam7, 1, 12, (V[]){v_x_2471, v_x_27_2481, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2484, v_g_240, v_v_2472, v_v_27_2482, v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam6, 2, 0};
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam7, 2, 0};
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam8, 2, 0};
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam9(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam9, 2, 0};
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam10(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam10, 2, 0};
Clo g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry, 4, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(V v_g_240, V v_cs_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_244 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_245 = heff_dup(heff_field(v_b_243, 0));
      V v_t_246;
      switch (heff_tag_of(v_u_244)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_245)) {
        case TAG_SmallU: {
          v_t_246 = NTAG(TAG_True);
          break;
        }
        case TAG_LargeU: {
          v_t_246 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_u_27_245);
        }
        break;
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_245)) {
        case TAG_SmallU: {
          v_t_246 = NTAG(TAG_False);
          break;
        }
        case TAG_LargeU: {
          v_t_246 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_u_27_245);
        }
        break;
      }
      default: heff_nomatch(v_u_244);
      }
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop_rec(v_cs_241, 2);
        heff_drop_tag(v_a_242, 1);
        heff_drop_tag(v_b_243, 1);
        return ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0_clo);
      }
      case TAG_False: {
        V v_t_249 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_244);
      V v_t_2415 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    }
    case TAG_VFunction: {
      heff_drop(v_u_244);
      V v_t_2421 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    }
    case TAG_VRecord: {
      heff_drop(v_u_244);
      V v_t_2426 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    }
    case TAG_VSum: {
      heff_drop(v_u_244);
      V v_t_2428 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_244);
      V v_t_2429 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_244);
      V v_t_2430 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_244);
      V v_t_2431 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_244);
      V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_244);
      V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    }
    case TAG_VFixed: {
      heff_drop(v_u_244);
      V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2437 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2438 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2443 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    }
    case TAG_VDecode: {
      V v_h_27_2444 = heff_field(v_b_243, 0);
      V v_sp_27_2445 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      return (g_heff_2eelab_2eunify_2euBareF_24s1657196402x632170672(v_g_240, v_cs_241, v_h_2437, v_sp_2438, v_h_27_2444, v_sp_27_2445));
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2454 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2459 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2461 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2462 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2463 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2464 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2465 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2467 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2437);
      heff_drop(v_sp_2438);
      V v_t_2469 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2470 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2471 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2472 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2473 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_2482 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
    }
    case TAG_VFunction: {
      V v_level_27_2483 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_2484 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_2485 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_2486 = heff_dup(heff_field(v_b_243, 3));
      V v_t_2488 = ({ V a_0 = v_level_2470; V a_1 = v_level_27_2483; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2470); heff_drop(v_level_27_2483); r_; });
      V v_t_2489;
      switch (heff_tag_of(v_t_2488)) {
      case TAG_True: {
        switch (heff_tag_of(v_implicit_2473)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_2486)) {
          case TAG_Expl: {
            v_t_2489 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_2489 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2489 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2486);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_2486)) {
          case TAG_Expl: {
            v_t_2489 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2489 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_2489 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_2486);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_2486)) {
          case TAG_Expl: {
            v_t_2489 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_2489 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_2489 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_2486);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2473);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_implicit_2473);
        heff_drop(v_implicit_27_2486);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2488);
      }
      switch (heff_tag_of(v_t_2489)) {
      case TAG_True: {
        heff_drop_tag(v_a_242, 5);
        heff_drop_tag(v_b_243, 5);
        return heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1, 2, 6, (V[]){v_g_240, v_cs_241, v_dom_2471, v_dom_27_2484, v_cod_2472, v_cod_27_2485});
      }
      case TAG_False: {
        heff_drop(v_g_240);
        heff_drop(v_dom_2471);
        heff_drop(v_cod_2472);
        heff_drop(v_dom_27_2484);
        heff_drop(v_cod_27_2485);
        V v_t_24124 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
      }
      default: return heff_nomatch(v_t_2489);
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24129 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24129})});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24131 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24131})});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24132 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24133 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24134 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24135 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24137 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24137})});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2470);
      heff_drop(v_dom_2471);
      heff_drop(v_cod_2472);
      heff_drop(v_implicit_2473);
      V v_t_24139 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24144 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24144})});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24146 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24146})});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24148 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24148})});
    }
    case TAG_VDecode: {
      V v_t_24154 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24154})});
    }
    case TAG_VFunction: {
      V v_t_24160 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24160})});
    }
    case TAG_VRecord: {
      V v_t_24165 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24165})});
    }
    case TAG_VSum: {
      V v_t_24167 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24167})});
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      return ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam6_clo);
    }
    case TAG_VPrimFloat: {
      V v_t_24170 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24170})});
    }
    case TAG_VPrimString: {
      V v_t_24171 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24171})});
    }
    case TAG_VPrimRune: {
      V v_t_24172 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24172})});
    }
    case TAG_VPrimArray: {
      V v_t_24174 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24174})});
    }
    case TAG_VFixed: {
      V v_t_24176 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24176})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24178 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24178})});
    }
    case TAG_VDecode: {
      V v_t_24184 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24184})});
    }
    case TAG_VFunction: {
      V v_t_24190 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24190})});
    }
    case TAG_VRecord: {
      V v_t_24195 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24195})});
    }
    case TAG_VSum: {
      V v_t_24197 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24197})});
    }
    case TAG_VPrimInt: {
      V v_t_24198 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24198})});
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      return ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam7_clo);
    }
    case TAG_VPrimString: {
      V v_t_24201 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24201})});
    }
    case TAG_VPrimRune: {
      V v_t_24202 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24202})});
    }
    case TAG_VPrimArray: {
      V v_t_24204 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24204})});
    }
    case TAG_VFixed: {
      V v_t_24206 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24208 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24208})});
    }
    case TAG_VDecode: {
      V v_t_24214 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24214})});
    }
    case TAG_VFunction: {
      V v_t_24220 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24220})});
    }
    case TAG_VRecord: {
      V v_t_24225 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24225})});
    }
    case TAG_VSum: {
      V v_t_24227 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24227})});
    }
    case TAG_VPrimInt: {
      V v_t_24228 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24228})});
    }
    case TAG_VPrimFloat: {
      V v_t_24229 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24229})});
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      return ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam8_clo);
    }
    case TAG_VPrimRune: {
      V v_t_24232 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24232})});
    }
    case TAG_VPrimArray: {
      V v_t_24234 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24234})});
    }
    case TAG_VFixed: {
      V v_t_24236 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24236})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24255;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24255 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    switch (heff_tag_of(v_t_24255)) {
    case TAG_True: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      return ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam9_clo);
    }
    case TAG_False: {
      V v_t_24258 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24258})});
    }
    default: return heff_nomatch(v_t_24255);
    }
  }
  case TAG_VPrimArray: {
    V v_x_24259 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24261 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24261})});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24267 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24267})});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24273 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24273})});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24278 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24278})});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24280 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24280})});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24281 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24281})});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24282 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24282})});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24283 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24283})});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24284 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24284})});
    }
    case TAG_VPrimArray: {
      V v_y_24285 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      return heff_tail(((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo), 4, (V[]){v_g_240, v_cs_241, v_x_24259, v_y_24285});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24259);
      V v_t_24287 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24287})});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24288 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24289 = ({ V a_0 = v_w_24288; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24288); r_; });
    switch (heff_tag_of(v_t_24289)) {
    case TAG_True: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      return ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam10_clo);
    }
    case TAG_False: {
      V v_t_24292 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      return heff_tail(((V)&g_co_2eop_24s1532701784x592895222_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24292})});
    }
    default: return heff_nomatch(v_t_24289);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3(V self, V *args) {
  V v_u_2494 = args[0];
  V v_dom_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2494);
  return v_dom_2471;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam4(V self, V *args) {
  V v_w_24107 = args[0];
  V v_v_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24107);
  return v_v_2495;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam5(V self, V *args) {
  V v_w_24117 = args[0];
  V v_v_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24117);
  return v_v_2495;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2(V self, V *args) {
  V v_x_2492 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2471 = heff_env(self)[1];
  V v_cod_2472 = heff_env(self)[2];
  V v_cod_27_2485 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_hd_2490 = heff_env(self)[5];
  V v_k_2491 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2492);
  V v_t_2493 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_2495 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2493, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam3, 1, 1, (V[]){v_dom_2471}), NTAG(TAG_Nothing)));
  V v_x_24100;
  switch (heff_tag_of(v_cod_2472)) {
  case TAG_MkClo: {
    V v_n_2496 = heff_dup(heff_field(v_cod_2472, 0));
    v_x_24100 = v_n_2496;
    break;
  }
  case TAG_CloConst: {
    v_x_24100 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_str0);
    break;
  }
  default: heff_nomatch(v_cod_2472);
  }
  V v_t_24101 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24100, heff_get_n(v_cs_241, 1, 2)});
  V v_cs_24103 = heff_rec_n(2, shape_len__names, (V[]){v_t_24101, v_t_24102});
  V v_x1_24109;
  switch (heff_tag_of(v_cod_2472)) {
  case TAG_MkClo: {
    V v_vs_24105 = heff_field(v_cod_2472, 1);
    V v_body_24106 = heff_field(v_cod_2472, 2);
    heff_take_n(v_cod_2472, 6ULL, 3);
    v_x1_24109 = heff_tr(heff_apply(v_body_24106, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24105, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam4, 1, 1, (V[]){heff_dup(v_v_2495)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24108 = heff_field(v_cod_2472, 0);
    heff_take_n(v_cod_2472, 1ULL, 1);
    v_x1_24109 = v_body_24108;
    break;
  }
  default: heff_nomatch(v_cod_2472);
  }
  V v_a_24113;
  switch (heff_tag_of(v_x1_24109)) {
  case TAG_Nom: {
    V v_x_24110 = heff_field(v_x1_24109, 0);
    heff_take_n(v_x1_24109, 1ULL, 1);
    v_a_24113 = v_x_24110;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24109, 0ULL, 1);
    v_a_24113 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24112 = heff_field(v_x1_24109, 0);
    heff_take_n(v_x1_24109, 1ULL, 1);
    v_a_24113 = v_x_24112;
    break;
  }
  default: heff_nomatch(v_x1_24109);
  }
  V v_x1_24119;
  switch (heff_tag_of(v_cod_27_2485)) {
  case TAG_MkClo: {
    V v_vs_24115 = heff_field(v_cod_27_2485, 1);
    V v_body_24116 = heff_field(v_cod_27_2485, 2);
    heff_take_n(v_cod_27_2485, 6ULL, 3);
    v_x1_24119 = heff_tr(heff_apply(v_body_24116, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24115, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam5, 1, 1, (V[]){v_v_2495})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24118 = heff_field(v_cod_27_2485, 0);
    heff_take_n(v_cod_27_2485, 1ULL, 1);
    heff_drop(v_v_2495);
    v_x1_24119 = v_body_24118;
    break;
  }
  default: heff_nomatch(v_cod_27_2485);
  }
  V v_b_24123;
  switch (heff_tag_of(v_x1_24119)) {
  case TAG_Nom: {
    V v_x_24120 = heff_field(v_x1_24119, 0);
    heff_take_n(v_x1_24119, 1ULL, 1);
    v_b_24123 = v_x_24120;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24119, 0ULL, 1);
    v_b_24123 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24122 = heff_field(v_x1_24119, 0);
    heff_take_n(v_x1_24119, 1ULL, 1);
    v_b_24123 = v_x_24122;
    break;
  }
  default: heff_nomatch(v_x1_24119);
  }
  return (g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(v_g_240, v_cs_24103, v_a_24113, v_b_24123, v_hd_2490, v_k_2491));
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam1(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_dom_2471 = heff_env(self)[2];
  V v_dom_27_2484 = heff_env(self)[3];
  V v_cod_2472 = heff_env(self)[4];
  V v_cod_27_2485 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2471), v_dom_27_2484, heff_dup(v_hd_2490), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam2, 1, 7, (V[]){v_cs_241, v_dom_2471, v_cod_2472, v_cod_27_2485, v_g_240, v_hd_2490, v_k_2491})));
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam6(V self, V *args) {
  V v_hd_24168 = args[0];
  V v_k_24169 = args[1];
  heff_drop(v_hd_24168);
  V f_ = v_k_24169;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam7(V self, V *args) {
  V v_hd_24199 = args[0];
  V v_k_24200 = args[1];
  heff_drop(v_hd_24199);
  V f_ = v_k_24200;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam8(V self, V *args) {
  V v_hd_24230 = args[0];
  V v_k_24231 = args[1];
  heff_drop(v_hd_24230);
  V f_ = v_k_24231;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam9(V self, V *args) {
  V v_hd_24256 = args[0];
  V v_k_24257 = args[1];
  heff_drop(v_hd_24256);
  V f_ = v_k_24257;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784_lam10(V self, V *args) {
  V v_hd_24290 = args[0];
  V v_k_24291 = args[1];
  heff_drop(v_hd_24290);
  V f_ = v_k_24291;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7, 1, 0};
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(V v_g_240, V v_cs_241, V v_a0_242, V v_b0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam0, 1, 1, (V[]){v_a0_242})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_247, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam1, 1, 5, (V[]){v_b0_243, v_hd_244, v_cs_241, v_k_245, v_g_240})));
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_242; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_b0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 8); V a_1 = v_b0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4(V self, V *args) {
  V v_c_2456 = args[0];
  return heff_get_n(v_c_2456, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7(V self, V *args) {
  V v_c_2462 = args[0];
  return heff_get_n(v_c_2462, 3, 8);
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2465 = ({ V a_0 = v_x_2464; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2464); r_; });
  V v_t_2466 = heff_tr(heff_apply(heff_get_n(v_t_2465, 1, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_241, 0, 2), v_x_2411}));
  return ({ V a_0 = v_t_2466; V a_1 = v_hd_244; V a_2 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2461);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam7_clo)})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2463, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam8, 1, 4, (V[]){v_cs_241, v_x_2411, v_hd_244, v_k_245})));
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam5(V self, V *args) {
  V v_x_2458 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2459 = ({ V a_0 = v_x_2458; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2458); r_; });
  V v_t_2460 = heff_tr(heff_apply(heff_get_n(v_t_2459, 1, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_241, 0)), v_x_248}));
  return ({ V a_0 = v_t_2460; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam6, 1, 4, (V[]){v_hd_244, v_cs_241, v_x_2411, v_k_245}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s2118339362x1530810174(a_0, a_1, a_2)); heff_drop(v_t_2460); r_; });
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433;
  switch (heff_tag_of(v_x_248)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2413 = heff_dup(heff_field(v_x_248, 0));
    switch (heff_tag_of(v_h_2413)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2413, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2413);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_t_2455;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    v_t_2455 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_x_2411)) {
    case TAG_VU: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_h_2435 = heff_dup(heff_field(v_x_2411, 0));
      switch (heff_tag_of(v_h_2435)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2435, 0ULL, 1);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2455 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_h_2435);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  switch (heff_tag_of(v_t_2455)) {
  case TAG_True: {
    heff_drop(v_g_240);
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam4_clo)})});
    return (g_co_2eop_24s1802027244x918867378(v_t_2457, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam5, 1, 5, (V[]){v_cs_241, v_x_248, v_hd_244, v_x_2411, v_k_245})));
  }
  case TAG_False: {
    V v_it_2488;
    switch (heff_tag_of(v_x_248)) {
    case TAG_VU: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2468 = heff_dup(heff_field(v_x_248, 0));
      V v_sp_2469 = heff_dup(heff_field(v_x_248, 1));
      switch (heff_tag_of(v_t1_2468)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2468, 0ULL, 1);
        heff_drop(v_sp_2469);
        v_it_2488 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2468, 0ULL, 1);
        heff_drop(v_sp_2469);
        v_it_2488 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_HMeta: {
        V v_m_2475 = heff_field(v_t1_2468, 0);
        V v_ru_24t1_2468_24HMeta = heff_take_reuse_n(v_t1_2468, 1ULL, 1);
        v_it_2488 = heff_tag_at_n(v_ru_24t1_2468_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2475, v_sp_2469})});
        break;
      }
      case TAG_HError: {
        heff_drop(v_sp_2469);
        v_it_2488 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t1_2468);
      }
      break;
    }
    case TAG_VFunction: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VRecord: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_it_2488 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    switch (heff_tag_of(v_it_2488)) {
    case TAG_Nothing: {
      V v_it_24110;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_VU: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2490 = heff_dup(heff_field(v_x_2411, 0));
        V v_sp_2491 = heff_dup(heff_field(v_x_2411, 1));
        switch (heff_tag_of(v_t1_2490)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2490, 0ULL, 1);
          heff_drop(v_sp_2491);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2490, 0ULL, 1);
          heff_drop(v_sp_2491);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          V v_m_2497 = heff_field(v_t1_2490, 0);
          V v_ru_24t1_2490_24HMeta = heff_take_reuse_n(v_t1_2490, 1ULL, 1);
          v_it_24110 = heff_tag_at_n(v_ru_24t1_2490_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2497, v_sp_2491})});
          break;
        }
        case TAG_HError: {
          heff_drop(v_sp_2491);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2490);
        }
        break;
      }
      case TAG_VFunction: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
      switch (heff_tag_of(v_it_24110)) {
      case TAG_Nothing: {
        V v_t_24111 = heff_tr(g_heff_2eelab_2eunify_2euTyRigid_24s54310456x1683457784(v_g_240, v_cs_241, v_x_248, v_x_2411));
        return heff_tail(v_t_24111, 2, (V[]){v_hd_244, v_k_245});
      }
      case TAG_Just: {
        V v_it1_24112 = heff_field(v_it_24110, 0);
        V v_ru_24it_24110_24Just = heff_take_reuse_n(v_it_24110, 1ULL, 1);
        switch (heff_tag_of(v_it1_24112)) {
        case TAG_MkPair: {
          V v_m_24113 = heff_field(v_it1_24112, 0);
          V v_sp_24114 = heff_field(v_it1_24112, 1);
          heff_take_n(v_it1_24112, 3ULL, 2);
          V v_rhs_24133;
          switch (heff_tag_of(v_x_248)) {
          case TAG_VU: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VDecode: {
            V v_el_24120 = heff_field(v_x_248, 4);
            heff_take_n(v_x_248, 16ULL, 5);
            heff_drop_cell(v_ru_24it_24110_24Just, 1);
            v_rhs_24133 = heff_tr(heff_apply(v_el_24120, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VRecord: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VSum: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimInt: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimFloat: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimString: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimRune: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VPrimArray: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          case TAG_VFixed: {
            v_rhs_24133 = heff_tag_at_n(v_ru_24it_24110_24Just, TAG_VCode, 1, (V[]){v_x_248});
            break;
          }
          default: heff_nomatch(v_x_248);
          }
          V v_self_24152;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_VU: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VDecode: {
            V v_el_24139 = heff_field(v_x_2411, 4);
            heff_take_n(v_x_2411, 16ULL, 5);
            v_self_24152 = heff_tr(heff_apply(v_el_24139, 1, (V[]){NTAG(TAG_MkUnit)}));
            break;
          }
          case TAG_VFunction: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VRecord: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VSum: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimInt: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimFloat: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimString: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimRune: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VPrimArray: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          case TAG_VFixed: {
            v_self_24152 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_2411});
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
          return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24113; V a_3 = v_sp_24114; V a_4 = v_rhs_24133; V a_5 = v_self_24152; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24114); r_; });
        }
        default: return heff_nomatch(v_it1_24112);
        }
      }
      default: return heff_nomatch(v_it_24110);
      }
    }
    case TAG_Just: {
      V v_it1_24153 = heff_field(v_it_2488, 0);
      V v_ru_24it_2488_24Just = heff_take_reuse_n(v_it_2488, 1ULL, 1);
      switch (heff_tag_of(v_it1_24153)) {
      case TAG_MkPair: {
        V v_m_24154 = heff_field(v_it1_24153, 0);
        V v_sp_24155 = heff_field(v_it1_24153, 1);
        heff_take_n(v_it1_24153, 3ULL, 2);
        V v_rhs_24174;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_VU: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VDecode: {
          V v_el_24161 = heff_field(v_x_2411, 4);
          heff_take_n(v_x_2411, 16ULL, 5);
          heff_drop_cell(v_ru_24it_2488_24Just, 1);
          v_rhs_24174 = heff_tr(heff_apply(v_el_24161, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VRecord: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VSum: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimInt: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimFloat: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimString: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimRune: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VPrimArray: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        case TAG_VFixed: {
          v_rhs_24174 = heff_tag_at_n(v_ru_24it_2488_24Just, TAG_VCode, 1, (V[]){v_x_2411});
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_self_24193;
        switch (heff_tag_of(v_x_248)) {
        case TAG_VU: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VDecode: {
          V v_el_24180 = heff_field(v_x_248, 4);
          heff_take_n(v_x_248, 16ULL, 5);
          v_self_24193 = heff_tr(heff_apply(v_el_24180, 1, (V[]){NTAG(TAG_MkUnit)}));
          break;
        }
        case TAG_VFunction: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VRecord: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VSum: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimInt: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimFloat: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimString: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimRune: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VPrimArray: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        case TAG_VFixed: {
          v_self_24193 = heff_tag_n(TAG_VCode, 1, (V[]){v_x_248});
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        return ({ V a_0 = v_g_240; V a_1 = v_cs_241; V a_2 = v_m_24154; V a_3 = v_sp_24155; V a_4 = v_rhs_24174; V a_5 = v_self_24193; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2eunify_2esolveF_24s2024193209x2003352135(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_sp_24155); r_; });
      }
      default: return heff_nomatch(v_it1_24153);
      }
    }
    default: return heff_nomatch(v_it_2488);
    }
  }
  default: return heff_nomatch(v_t_2455);
  }
}
V g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_b0_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam2, 1, 1, (V[]){v_b0_243})})});
  return (g_co_2eop_24s1802027244x918867378(v_t_2410, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2euTypeF_24s118772062x301956543_lam3, 1, 5, (V[]){v_x_248, v_hd_244, v_cs_241, v_k_245, v_g_240})));
}