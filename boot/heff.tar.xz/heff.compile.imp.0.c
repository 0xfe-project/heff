// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_cond 9554921
#define LBL_full 9650006
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_setTo 310686359
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_val 326043
static uint32_t shape_full__simple__tail__bindTo__setTo__atom__op__pred[] = {LBL_full, LBL_simple, LBL_tail, LBL_bindTo, LBL_setTo, LBL_atom, LBL_op, LBL_pred};
static uint32_t shape_val__op__cond__sts__tl[] = {LBL_val, LBL_op, LBL_cond, LBL_sts, LBL_tl};
V g_heff_2ecompile_2eimp_2eallL(V, V);
V g_heff_2ecompile_2eimp_2eallL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eallL_clo;
V g_heff_2ecompile_2eimp_2earmNamed(V, V);
V g_heff_2ecompile_2eimp_2earmNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2earmNamed_clo;
V g_heff_2ecompile_2eimp_2eatomOf(V, V);
V g_heff_2ecompile_2eimp_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eatomOf_clo;
V g_heff_2ecompile_2eimp_2eatomsOf(V, V);
V g_heff_2ecompile_2eimp_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eatomsOf_clo;
V g_heff_2ecompile_2eimp_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimp_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2ecaseSet_clo;
V g_heff_2ecompile_2eimp_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimp_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2ecaseTail_clo;
V g_heff_2ecompile_2eimp_2econdIf(V, V, V);
V g_heff_2ecompile_2eimp_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2econdIf_clo;
V g_heff_2ecompile_2eimp_2econdIf_24dps(V, V, V, V);
V g_heff_2ecompile_2eimp_2econdIf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2econdIf_24dps_clo;
V g_heff_2ecompile_2eimp_2econdShaped(V);
V g_heff_2ecompile_2eimp_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2econdShaped_clo;
V g_heff_2ecompile_2eimp_2edeclBefore(V, V);
V g_heff_2ecompile_2eimp_2edeclBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2edeclBefore_clo;
V g_heff_2ecompile_2eimp_2edeclBefore_24dps(V, V, V);
V g_heff_2ecompile_2eimp_2edeclBefore_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2edeclBefore_24dps_clo;
V g_heff_2ecompile_2eimp_2egenOf(V);
V g_heff_2ecompile_2eimp_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2egenOf_clo;
V g_heff_2ecompile_2eimp_2eisRel(V);
V g_heff_2ecompile_2eimp_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eisRel_clo;
V g_heff_2ecompile_2eimp_2eisRelCall(V);
V g_heff_2ecompile_2eimp_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eisRelCall_clo;
V g_heff_2ecompile_2eimp_2eopOf(V, V);
V g_heff_2ecompile_2eimp_2eopOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2eopOf_clo;
V g_heff_2ecompile_2eimp_2epartsCond(V, V, V);
V g_heff_2ecompile_2eimp_2epartsCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsCond_clo;
V g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017(V, V);
V g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_clo;
V g_heff_2ecompile_2eimp_2epartsOp(V, V, V);
V g_heff_2ecompile_2eimp_2epartsOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsOp_clo;
V g_heff_2ecompile_2eimp_2epartsSt(V, V, V);
V g_heff_2ecompile_2eimp_2epartsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsSt_clo;
V g_heff_2ecompile_2eimp_2epartsTl(V, V, V);
V g_heff_2ecompile_2eimp_2epartsTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsTl_clo;
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(V, V);
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_clo;
V g_heff_2ecompile_2eimp_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimp_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_clo;
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(V, V);
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_clo;
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps(V, V, V);
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_clo;
V g_heff_2ecompile_2eimp_2epk_get(void);
V g_heff_2ecompile_2eimp_2epredAny(V, V);
V g_heff_2ecompile_2eimp_2epredAny_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epredAny_clo;
V g_heff_2ecompile_2eimp_2epredLets(V, V);
V g_heff_2ecompile_2eimp_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epredLets_clo;
V g_heff_2ecompile_2eimp_2erelPrims_get(void);
V g_heff_2ecompile_2eimp_2esimpleOf(V, V);
V g_heff_2ecompile_2eimp_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2esimpleOf_clo;
V g_heff_2ecompile_2eimp_2etailOf(V, V, V);
V g_heff_2ecompile_2eimp_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etailOf_clo;
V g_heff_2ecompile_2eimp_2etailSelf(V, V, V);
V g_heff_2ecompile_2eimp_2etailSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etailSelf_clo;
V g_heff_2ecompile_2eimp_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimp_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etestTail_clo;
V g_heff_2ecompile_2eimp_2etoDest(V, V, V);
V g_heff_2ecompile_2eimp_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etoDest_clo;
V g_heff_2ecompile_2eimp_2etraverseN(V, V);
V g_heff_2ecompile_2eimp_2etraverseN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2etraverseN_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1040186323x1541137667(V, V);
V g_list_2efoldl_24s1040186323x1541137667_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1040186323x1541137667_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2eimp_2etraverseN_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimp_2etraverseN_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etraverseN_lam0, 1, 0};
V g_heff_2ecompile_2eimp_2etraverseN_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimp_2etraverseN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etraverseN_entry, 2, 0};

V g_heff_2ecompile_2eimp_2etraverseN(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eimp_2etraverseN_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2etraverseN_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2etraverseN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2etraverseN(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2etraverseN_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2eimp_2etraverseN_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eimp_2etraverseN(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2eimp_2eallL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eallL_entry, 2, 0};

V g_heff_2ecompile_2eimp_2eallL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2eallL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2eallL(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimp_2eisRel_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2eisRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eisRel_entry, 1, 0};

V g_heff_2ecompile_2eimp_2eisRel(V v_p_240) {
top: ;
  V v_t_242 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2eisRel_lam0, 1, 1, (V[]){heff_dup(v_p_240)}); V b_1 = heff_dup(g_heff_2ecompile_2eimp_2erelPrims_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_p_240);
    heff_drop(v_t_242);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_242);
    V v_x3_243 = (g_heff_2eelab_2efixed_2efixedPrimOf(v_p_240));
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x3_243, 0);
      heff_take_n(v_x3_243, 1ULL, 1);
      V v_t_245 = heff_get_n(v_x_244, 1, 2);
      switch (heff_tag_of(v_t_245)) {
      case TAG_OpAdd: {
        return NTAG(TAG_False);
      }
      case TAG_OpSub: {
        return NTAG(TAG_False);
      }
      case TAG_OpMul: {
        return NTAG(TAG_False);
      }
      case TAG_OpDiv: {
        return NTAG(TAG_False);
      }
      case TAG_OpRem: {
        return NTAG(TAG_False);
      }
      case TAG_OpEq: {
        return NTAG(TAG_True);
      }
      case TAG_OpLt: {
        return NTAG(TAG_True);
      }
      case TAG_OpLe: {
        return NTAG(TAG_True);
      }
      case TAG_OpAnd: {
        return NTAG(TAG_False);
      }
      case TAG_OpOr: {
        return NTAG(TAG_False);
      }
      case TAG_OpXor: {
        return NTAG(TAG_False);
      }
      case TAG_OpShl: {
        return NTAG(TAG_False);
      }
      case TAG_OpShr: {
        return NTAG(TAG_False);
      }
      case TAG_OpShow: {
        return NTAG(TAG_False);
      }
      case TAG_OpFromInt: {
        return NTAG(TAG_False);
      }
      case TAG_OpToInt: {
        return NTAG(TAG_False);
      }
      case TAG_OpSqrt: {
        return NTAG(TAG_False);
      }
      case TAG_OpFromFloat: {
        return NTAG(TAG_False);
      }
      case TAG_OpToFloat: {
        return NTAG(TAG_False);
      }
      case TAG_OpFloor: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
}
V g_heff_2ecompile_2eimp_2eisRel_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2eisRel(a[0]);
}
V g_heff_2ecompile_2eimp_2eisRel_lam0(V self, V *args) {
  V v_q_241 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_p_240, v_q_241);
}
HEFF_LIT(g_heff_2ecompile_2eimp_2econdShaped_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2econdShaped_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimp_2econdShaped_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimp_2econdShaped_str3, 5, "False");
Clo g_heff_2ecompile_2eimp_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eimp_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    V v_e2_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_t_2416), ((V)&g_heff_2ecompile_2eimp_2econdShaped_str0))) {
        heff_drop(v_t_2416);
        return NTAG(TAG_True);
      } else {
        return heff_strEq(v_t_2416, ((V)&g_heff_2ecompile_2eimp_2econdShaped_str1));
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      heff_drop(v_t_2416);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 2ULL, 2);
    V v_t_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2422));
    V v_it_2429;
    if (heff_intEq_c(v_t_2423, MK_INT(2LL))) {
      V v_t_2425 = (g_heff_2ecompile_2eimp_2earmNamed(((V)&g_heff_2ecompile_2eimp_2econdShaped_str2), v_arms_2422));
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nothing: {
        heff_drop(v_arms_2422);
        heff_drop_cell(v_ru_24e_240_24EMatch, 2);
        v_it_2429 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2426 = heff_field(v_t_2425, 0);
        V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
        V v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eimp_2econdShaped_str3); V a_1 = v_arms_2422; V r_ = (g_heff_2ecompile_2eimp_2earmNamed(a_0, a_1)); heff_drop(v_arms_2422); r_; });
        switch (heff_tag_of(v_t_2427)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24e_240_24EMatch, 2);
          heff_drop(v_t_2426);
          heff_drop_cell(v_ru_24t_2425_24Just, 1);
          v_it_2429 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2428 = heff_field(v_t_2427, 0);
          heff_take_n(v_t_2427, 1ULL, 1);
          v_it_2429 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){v_t_2426, v_f_2428})});
          break;
        }
        default: heff_nomatch(v_t_2427);
        }
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
    } else {
      heff_drop(v_arms_2422);
      heff_drop_cell(v_ru_24e_240_24EMatch, 2);
      v_it_2429 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2429)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_it1_2430 = heff_field(v_it_2429, 0);
      heff_take_n(v_it_2429, 1ULL, 1);
      switch (heff_tag_of(v_it1_2430)) {
      case TAG_MkPair: {
        V v_t_2431 = heff_field(v_it1_2430, 0);
        V v_f_2432 = heff_field(v_it1_2430, 1);
        heff_take_n(v_it1_2430, 3ULL, 2);
        V v_t_2433 = (g_heff_2ecompile_2eimp_2econdShaped(v_t_2431));
        if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
          heff_drop(v_t_2433);
          V t_0 = v_f_2432;
          v_e_240 = t_0;
          goto top;
        } else {
          heff_drop(v_f_2432);
          heff_drop(v_t_2433);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_it1_2430);
      }
    }
    default: return heff_nomatch(v_it_2429);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2435 = heff_field(v_e_240, 0);
    V v_e2_2436 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_e2_2436)) {
    case TAG_Nil: {
      heff_drop(v_p_2435);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_e22_2438 = heff_field(v_e2_2436, 1);
      heff_take_n(v_e2_2436, 2ULL, 2);
      switch (heff_tag_of(v_e22_2438)) {
      case TAG_Nil: {
        heff_drop(v_p_2435);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_e222_2440 = heff_field(v_e22_2438, 1);
        heff_take_n(v_e22_2438, 2ULL, 2);
        switch (heff_tag_of(v_e222_2440)) {
        case TAG_Nil: {
          HEFF_LAST return g_heff_2ecompile_2eimp_2eisRel(v_p_2435);
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2440, 0ULL, 2);
          heff_drop(v_p_2435);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_e222_2440);
        }
      }
      default: return heff_nomatch(v_e22_2438);
      }
    }
    default: return heff_nomatch(v_e2_2436);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eimp_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2econdShaped(a[0]);
}
Clo g_heff_2ecompile_2eimp_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eimp_2econdIf(V v_c_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_c_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_c_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PBool: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_c_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_c_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c1_2473 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    V t_0 = v_c1_2473;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2474 = heff_field(v_c_240, 0);
    V v_b_2475 = heff_field(v_c_240, 1);
    V v_c3_2476 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PIf = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_t_2488;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop(v_t_2488);
      V v_t_24100;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_24100 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_24100 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24c_240_24PIf, 3);
        heff_drop(v_t_24100);
        V v_t_24101 = (g_heff_2ecompile_2eimp_2econdIf(v_b_2475, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_24102 = (g_heff_2ecompile_2eimp_2econdIf(v_c3_2476, v_t_241, v_e_242));
        V t_0 = v_a_2474;
        V t_1 = v_t_24101;
        V t_2 = v_t_24102;
        v_c_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_24100);
        return heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2474, v_b_2475, v_c3_2476}), v_t_241, v_e_242});
      }
    } else {
      heff_drop(v_t_2488);
      return heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2474, v_b_2475, v_c3_2476}), v_t_241, v_e_242});
    }
  }
  case TAG_PLet: {
    V v_x_24103 = heff_field(v_c_240, 0);
    V v_o_24104 = heff_field(v_c_240, 1);
    V v_c3_24105 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PLet = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_cell_24106 = heff_tag_at_n(v_ru_24c_240_24PLet, TAG_PLet, 3, (V[]){v_x_24103, v_o_24104, heff_hole()});
    V v_u_24107 = (g_heff_2ecompile_2eimp_2econdIf_24dps(v_c3_24105, v_t_241, v_e_242, heff_dup(v_cell_24106)));
    heff_drop(v_u_24107);
    return v_cell_24106;
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eimp_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2econdIf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimp_2econdIf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2econdIf_24dps_entry, 4, 0};

V g_heff_2ecompile_2eimp_2econdIf_24dps(V v_c_240, V v_t_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return heff_setField(v_d_243, MK_INT(2LL), v_t_241);
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return heff_setField(v_d_243, MK_INT(2LL), v_e_242);
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), v_c_240);
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PNot, 1, (V[]){v_c_240}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PBool: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PNot: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PIf: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PLet: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PBool: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), v_c_240);
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PNot, 1, (V[]){v_c_240}));
      }
      case TAG_PFalse: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PRel: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PBool: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PNot: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PIf: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      case TAG_PLet: {
        return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PBool: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PNot: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PIf: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    case TAG_PLet: {
      return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242}));
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c1_2474 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    V t_0 = v_c1_2474;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    V t_3 = v_d_243;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2475 = heff_field(v_c_240, 0);
    V v_b_2476 = heff_field(v_c_240, 1);
    V v_c3_2477 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PIf = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_t_2489;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2489 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
      heff_drop(v_t_2489);
      V v_t_24101;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_24101 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_24101 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_24101 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      if ((heff_dup(v_t_24101) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24c_240_24PIf, 3);
        heff_drop(v_t_24101);
        V v_t_24102 = (g_heff_2ecompile_2eimp_2econdIf(v_b_2476, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_24103 = (g_heff_2ecompile_2eimp_2econdIf(v_c3_2477, v_t_241, v_e_242));
        V t_0 = v_a_2475;
        V t_1 = v_t_24102;
        V t_2 = v_t_24103;
        V t_3 = v_d_243;
        v_c_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_24101);
        V v_t_24104 = heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2475, v_b_2476, v_c3_2477}), v_t_241, v_e_242});
        return heff_setField(v_d_243, MK_INT(2LL), v_t_24104);
      }
    } else {
      heff_drop(v_t_2489);
      V v_t_24105 = heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2475, v_b_2476, v_c3_2477}), v_t_241, v_e_242});
      return heff_setField(v_d_243, MK_INT(2LL), v_t_24105);
    }
  }
  case TAG_PLet: {
    V v_x_24106 = heff_field(v_c_240, 0);
    V v_o_24107 = heff_field(v_c_240, 1);
    V v_c3_24108 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PLet = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_cell_24109 = heff_tag_at_n(v_ru_24c_240_24PLet, TAG_PLet, 3, (V[]){v_x_24106, v_o_24107, heff_hole()});
    V v_u_24110 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_24109));
    heff_drop(v_u_24110);
    V t_0 = v_c3_24108;
    V t_1 = v_t_241;
    V t_2 = v_e_242;
    V t_3 = v_cell_24109;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eimp_2econdIf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2econdIf_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eimp_2epredLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epredLets_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epredLets(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_p_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLet: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_o_245 = heff_field(v_x11_242, 1);
      V v_x3_246 = (g_heff_2ecompile_2eimp_2epredLets(v_rest_243, v_p_241));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_q_247 = heff_field(v_x3_246, 0);
        V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_PLet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_o_245), v_q_247})});
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    case TAG_SDecl: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSet: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIf: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCase: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimp_2epredLets_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2epredLets(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eimp_2eatomsOf_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimp_2eatomsOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eatomsOf_lam0, 1, 0};
V g_heff_2ecompile_2eimp_2eatomsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimp_2eatomsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2eatomsOf_entry, 2, 0};

V g_heff_2ecompile_2eimp_2eatomsOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimp_2eatomsOf_lam0_clo);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x2_241, 0);
    V v_es_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_e_244}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2eatomsOf_lam1, 1, 3, (V[]){v_m_246, v_g_240, v_es_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2eatomsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2eatomsOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimp_2eatomsOf_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_n_242});
}
V g_heff_2ecompile_2eimp_2eatomsOf_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_es_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2eimp_2eatomsOf(v_g_240, v_es_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_t_2417;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_dup(heff_field(v_x_249, 0));
        v_t_2417 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_dup(heff_field(v_x_2413, 0));
        v_t_2420 = v_x_2418;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_y_2423 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2424 = v_y_2423;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_2413, 1);
        heff_take_n(v_x_2413, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_x_2428 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2427})});
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eimp_2ecaseSet_lam2(V self, V *args);
V g_heff_2ecompile_2eimp_2ecaseSet_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2ecaseSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2ecaseSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2ecaseSet_entry, 4, 0};

V g_heff_2ecompile_2eimp_2ecaseSet(V v_g_240, V v_x_241, V v_s_242, V v_arms_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimp_2ecaseSet_lam0, 1, 4, (V[]){v_m_244, v_g_240, v_x_241, v_arms_243});
}
V g_heff_2ecompile_2eimp_2ecaseSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2ecaseSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimp_2ecaseSet_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimp_2ecaseSet_lam1(V self, V *args) {
  V v_arm_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_arm_249, 0);
    V v_vs_2411 = heff_field(v_arm_249, 1);
    V v_b_2412 = heff_field(v_arm_249, 2);
    heff_take_n(v_arm_249, 7ULL, 3);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_x_241, v_b_2412}));
    return heff_clo_n(g_heff_2ecompile_2eimp_2ecaseSet_lam2, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_arm_249);
  }
}
V g_heff_2ecompile_2eimp_2ecaseSet_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimp_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimp_2ecaseSet_lam1, 1, 2, (V[]){v_g_240, v_x_241}), v_arms_243));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_t_2424;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_247, 0));
        v_t_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_247, 1);
        heff_take_n(v_x_247, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_t_2427, v_x_2420}), NTAG(TAG_Nil)});
      V v_x_2429 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2428));
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2429, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
Clo g_heff_2ecompile_2eimp_2edeclBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2edeclBefore_entry, 2, 0};

V g_heff_2ecompile_2eimp_2edeclBefore(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_st_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_242, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), v_t_244});
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_242, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2eimp_2edeclBefore_24dps(v_x_240, v_x22_243, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2edeclBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2edeclBefore(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimp_2edeclBefore_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2edeclBefore_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimp_2edeclBefore_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), NTAG(TAG_Nil)});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), v_t_246});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_247);
    }
    case TAG_Cons: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_x_240;
      V t_1 = v_x22_245;
      V t_2 = v_cell_2410;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2edeclBefore_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2edeclBefore_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimp_2etestTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2etestTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etestTail_entry, 6, 0};

V g_heff_2ecompile_2eimp_2etestTail(V v_g_240, V v_self_241, V v_s_242, V v_t_243, V v_f_244, V v_arms_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
  return heff_clo_n(g_heff_2ecompile_2eimp_2etestTail_lam0, 1, 7, (V[]){v_m_246, v_g_240, v_self_241, v_s_242, v_arms_245, v_t_243, v_f_244});
}
V g_heff_2ecompile_2eimp_2etestTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2etestTail(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eimp_2etestTail_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_245 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_f_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2411 = (g_heff_2ecompile_2eimp_2ecaseTail(v_g_240, v_self_241, v_s_242, v_arms_245));
      V f_ = v_t_2411;
      args[0] = v_n_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_245);
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 2)), 2, (V[]){heff_dup(v_self_241), v_t_243}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2410}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_n_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_f_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_n_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2412, v_x_2415, v_x_2419}), v_n_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eimp_2egenOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2egenOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimp_2egenOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimp_2egenOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimp_2egenOf_lam4(V self, V *args);
V g_heff_2ecompile_2eimp_2egenOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimp_2egenOf_lam7(V self, V *args); static Clo g_heff_2ecompile_2eimp_2egenOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2egenOf_lam7, 1, 0};
V g_heff_2ecompile_2eimp_2egenOf_lam6(V self, V *args);
Clo g_heff_2ecompile_2eimp_2egenOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2egenOf_entry, 1, 0};

V g_heff_2ecompile_2eimp_2egenOf(V v_full_240) {
top: ;
  return heff_rec_n(8, shape_full__simple__tail__bindTo__setTo__atom__op__pred, (V[]){heff_dup(v_full_240), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam0, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam1, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam2, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam3, 2, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam4, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam5, 1, 1, (V[]){heff_dup(v_full_240)}), heff_clo_n(g_heff_2ecompile_2eimp_2egenOf_lam6, 1, 1, (V[]){v_full_240})});
}
V g_heff_2ecompile_2eimp_2egenOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2egenOf(a[0]);
}
V g_heff_2ecompile_2eimp_2egenOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimp_2esimpleOf(v_t_242, v_e_241));
}
V g_heff_2ecompile_2eimp_2egenOf_lam1(V self, V *args) {
  V v_self_243 = args[0];
  V v_e_244 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimp_2etailOf(v_t_245, v_self_243, v_e_244));
}
V g_heff_2ecompile_2eimp_2egenOf_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_247 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  return ({ V a_0 = v_t_248; V b_1 = heff_tag_n(TAG_DLet, 1, (V[]){v_x_246}); V a_2 = v_e_247; V r_ = (g_heff_2ecompile_2eimp_2etoDest(a_0, b_1, a_2)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2eimp_2egenOf_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_2410 = args[1];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  return ({ V a_0 = v_t_2411; V b_1 = heff_tag_n(TAG_DSet, 1, (V[]){v_x_249}); V a_2 = v_e_2410; V r_ = (g_heff_2ecompile_2eimp_2etoDest(a_0, b_1, a_2)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2eimp_2egenOf_lam4(V self, V *args) {
  V v_e_2412 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimp_2eatomOf(v_t_2413, v_e_2412));
}
V g_heff_2ecompile_2eimp_2egenOf_lam5(V self, V *args) {
  V v_e_2414 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  return (g_heff_2ecompile_2eimp_2eopOf(v_t_2415, v_e_2414));
}
V g_heff_2ecompile_2eimp_2egenOf_lam7(V self, V *args) {
  V v_n_2420 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2420});
}
V g_heff_2ecompile_2eimp_2egenOf_lam6(V self, V *args) {
  V v_e_2416 = args[0];
  V v_full_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_2417 = (g_heff_2ecompile_2eimp_2egenOf(v_full_240));
  V v_t_2418 = heff_dup(heff_rfield(v_g_2417, 0));
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    return (g_heff_2ecompile_2eimp_2epredAny(v_g_2417, v_e_2416));
  } else {
    heff_drop(v_t_2418);
    V v_t_2419 = (g_heff_2ecompile_2eimp_2eisRelCall(v_e_2416));
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      return (g_heff_2ecompile_2eimp_2epredAny(v_g_2417, v_e_2416));
    } else {
      heff_drop(v_e_2416);
      heff_drop_rec(v_g_2417, 8);
      heff_drop(v_t_2419);
      return ((V)&g_heff_2ecompile_2eimp_2egenOf_lam7_clo);
    }
  }
}
V g_heff_2ecompile_2eimp_2etailSelf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimp_2etailSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2etailSelf_entry, 3, 0};

V g_heff_2ecompile_2eimp_2etailSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_242, 1);
    return (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimp_2etailSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2421));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_k_2430 = heff_field(v_e_242, 0);
    V v_as_2431 = heff_field(v_e_242, 1);
    if (heff_strEq_c(heff_dup(v_k_2430), v_key_240)) {
      V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2431));
      return heff_intEq(v_t_2433, v_n_241);
    } else {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimp_2etailSelf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eimp_2etailSelf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eimp_2etailSelf_lam0(V self, V *args) {
  V v_a_2422 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_a_2422)) {
  case TAG_MkArm: {
    V v_b_2425 = heff_field(v_a_2422, 2);
    heff_take_n(v_a_2422, 4ULL, 3);
    v_t_2426 = v_b_2425;
    break;
  }
  default: heff_nomatch(v_a_2422);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2426; V r_ = (g_heff_2ecompile_2eimp_2etailSelf(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
}
Clo g_heff_2ecompile_2eimp_2epartsCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsCond_entry, 3, 0};

V g_heff_2ecompile_2eimp_2epartsCond(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_PFalse: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_PRel: {
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_b_245 = heff_field(v_x2_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_b_245), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_a_244), v_t_246});
  }
  case TAG_PBool: {
    V v_v_247 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_247), v_acc_242});
  }
  case TAG_PNot: {
    V v_c_248 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_248), v_acc_242});
  }
  case TAG_PIf: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_b_2410 = heff_field(v_x2_241, 1);
    V v_c_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){heff_dup(v_c_2411), v_acc_242}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){heff_dup(v_b_2410), v_t_2412}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_a_249), v_t_2413});
  }
  case TAG_PLet: {
    V v_o_2415 = heff_field(v_x2_241, 1);
    V v_c_2416 = heff_field(v_x2_241, 2);
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 2, (V[]){heff_dup(v_c_2416), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_2415), v_t_2417});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2epartsCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2epartsCond(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimp_2epartsTl_lam0(V self, V *args);
V g_heff_2ecompile_2eimp_2epartsTl_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimp_2epartsTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsTl_entry, 3, 0};

V g_heff_2ecompile_2eimp_2epartsTl(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 2, (V[]){heff_dup(v_t_244), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 3, 5), 2, (V[]){heff_dup(v_ss_243), v_t_245});
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_246), v_acc_242});
  }
  case TAG_TLoop: {
    V v_vs_247 = heff_field(v_x2_241, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsTl_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  }
  case TAG_TIf: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    V v_t_2412 = heff_field(v_x2_241, 1);
    V v_e_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 2, (V[]){heff_dup(v_e_2413), v_acc_242}));
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 2, (V[]){heff_dup(v_t_2412), v_t_2414}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_2411), v_t_2415});
  }
  case TAG_TCase: {
    V v_v_2416 = heff_field(v_x2_241, 0);
    V v_arms_2417 = heff_field(v_x2_241, 1);
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2417)));
    V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epartsTl_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_acc_242; V a_2 = v_t_2418; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_2416), v_t_2424});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimp_2epartsTl_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimp_2epartsTl(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimp_2epartsTl_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2410;
  args[1] = v_acc_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimp_2epartsTl_lam1(V self, V *args) {
  V v_acc_2419 = args[0];
  V v_x_2420 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_MkArm: {
    V v_t_2423 = heff_field(v_x_2420, 2);
    heff_take_n(v_x_2420, 4ULL, 3);
    V f_ = heff_get_n(v_r_240, 4, 5);
    args[0] = v_t_2423;
    args[1] = v_acc_2419;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ecompile_2eimp_2epk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epk_lam0, 2, 0};
V g_heff_2ecompile_2eimp_2epk_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epk_lam1, 2, 0};
V g_heff_2ecompile_2eimp_2epk_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epk_lam2, 2, 0};
V g_heff_2ecompile_2eimp_2epk_lam4(V self, V *args);
V g_heff_2ecompile_2eimp_2epk_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epk_lam3, 2, 0};
V g_heff_2ecompile_2eimp_2epk_lam5(V self, V *args); static Clo g_heff_2ecompile_2eimp_2epk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epk_lam5, 2, 0};

static V g_heff_2ecompile_2eimp_2epk_val;
static HEFF_ONCE g_heff_2ecompile_2eimp_2epk_st;
static V g_heff_2ecompile_2eimp_2epk_init(void) {
  return heff_rec_n(5, shape_val__op__cond__sts__tl, (V[]){((V)&g_heff_2ecompile_2eimp_2epk_lam0_clo), ((V)&g_heff_2ecompile_2eimp_2epk_lam1_clo), ((V)&g_heff_2ecompile_2eimp_2epk_lam2_clo), ((V)&g_heff_2ecompile_2eimp_2epk_lam3_clo), ((V)&g_heff_2ecompile_2eimp_2epk_lam5_clo)});
}
V g_heff_2ecompile_2eimp_2epk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimp_2epk_st)) return g_heff_2ecompile_2eimp_2epk_val;
  return heff_global(&g_heff_2ecompile_2eimp_2epk_val, &g_heff_2ecompile_2eimp_2epk_st, g_heff_2ecompile_2eimp_2epk_init);
}
V g_heff_2ecompile_2eimp_2epk_lam0(V self, V *args) {
  V v_v_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2ecompile_2eimp_2epartsVal(heff_dup(g_heff_2ecompile_2eimp_2epk_get()), v_v_240, v_acc_241));
}
V g_heff_2ecompile_2eimp_2epk_lam1(V self, V *args) {
  V v_o_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2ecompile_2eimp_2epartsOp(heff_dup(g_heff_2ecompile_2eimp_2epk_get()), v_o_242, v_acc_243));
}
V g_heff_2ecompile_2eimp_2epk_lam2(V self, V *args) {
  V v_c_244 = args[0];
  V v_acc_245 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimp_2epk_get()); V a_1 = v_c_244; V a_2 = v_acc_245; V r_ = (g_heff_2ecompile_2eimp_2epartsCond(a_0, a_1, a_2)); heff_drop(v_c_244); r_; });
}
V g_heff_2ecompile_2eimp_2epk_lam4(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_248; V a_1 = v_x_2411; V a_2 = v_acc_2410; V r_ = (g_heff_2ecompile_2eimp_2epartsSt(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
}
V g_heff_2ecompile_2eimp_2epk_lam3(V self, V *args) {
  V v_ss_246 = args[0];
  V v_acc_247 = args[1];
  V v_r_248 = heff_dup(g_heff_2ecompile_2eimp_2epk_get());
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimp_2epk_lam4, 2, 1, (V[]){v_r_248}); V a_1 = v_acc_247; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2eimp_2epk_lam5(V self, V *args) {
  V v_t_2412 = args[0];
  V v_acc_2413 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimp_2epk_get()); V a_1 = v_t_2412; V a_2 = v_acc_2413; V r_ = (g_heff_2ecompile_2eimp_2epartsTl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
}
Clo g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps(V v_v_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
  }
  case TAG_SGlobal: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_SInt: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_SFloat: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
  }
  case TAG_SStr: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2412);
  }
  case TAG_SBytes: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
  }
  case TAG_SFixed: {
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2417);
  }
  case TAG_SFloat32: {
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2419);
  }
  case TAG_SPrimFn: {
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2421);
  }
  case TAG_SLam: {
    V v_v2_2423 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2423)) {
    case TAG_MkBlock: {
      V v_t_2424 = heff_field(v_v2_2423, 0);
      V v_ru_24v2_2423_24MkBlock = heff_take_reuse_n(v_v2_2423, 1ULL, 1);
      V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(a_0, a_1)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2423_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2425});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2426);
    }
    default: return heff_nomatch(v_v2_2423);
    }
  }
  case TAG_STag: {
    V v_as_2428 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2428));
    V v_t_2430 = ({ V a_0 = v_acc_241; V a_1 = v_t_2429; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2430});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2431);
  }
  case TAG_SRec: {
    V v_fs_2432 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2434 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2432));
    V v_t_2435 = ({ V a_0 = v_acc_241; V a_1 = v_t_2434; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2434); r_; });
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2435});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2436);
  }
  case TAG_SProj: {
    V v_w_2437 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2442 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2441));
    heff_drop(v_u_2442);
    V t_0 = v_w_2437;
    V t_1 = v_acc_241;
    V t_2 = v_cell_2441;
    v_v_240 = t_0;
    v_acc_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_as_2444 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2444));
    V v_t_2446 = ({ V a_0 = v_acc_241; V a_1 = v_t_2445; V r_ = (g_list_2efoldl_24s1040186323x1541137667(a_0, a_1)); heff_drop(v_t_2445); r_; });
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2446});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2447);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_entry, 2, 0};

V g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return v_acc_241;
  }
  case TAG_PFalse: {
    return v_acc_241;
  }
  case TAG_PRel: {
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    V v_acc_245 = (g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(heff_dup(v_b_244), v_acc_241));
    HEFF_LAST return g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(heff_dup(v_a_243), v_acc_245);
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimp_2epartsVal_24s1389916794x1790571990(heff_dup(v_v_246), v_acc_241);
  }
  case TAG_PNot: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V t_0 = v_c_247;
    V t_1 = v_acc_241;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_PIf: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_c_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2410), v_acc_241}));
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 2)), 2, (V[]){heff_dup(v_b_249), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 2)), 2, (V[]){heff_dup(v_a_248), v_t_2412});
  }
  case TAG_PLet: {
    V v_o_2414 = heff_field(v_x2_240, 1);
    V v_c_2415 = heff_field(v_x2_240, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2415), v_acc_241}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimp_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_2414), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimp_2epartsCond_24s361583419x1348357017(a0, a[1]); heff_drop(a0); return r;
}