// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CRel 55099
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_Kept 49931
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_plain 308106724
#define LBL_safe 10017876
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vers 10111479
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eafresh_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapartOf(V, V);
V g_heff_2ecompile_2esimplify_2eapartOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapartOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eapartOf_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2earmChosen_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2easkKept_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindArgs(V, V);
V g_heff_2ecompile_2esimplify_2ebindArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindArgs_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eetaArg(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaArg_clo;
V g_heff_2ecompile_2esimplify_2eetaKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaKept_clo;
V g_heff_2ecompile_2esimplify_2eetaMade(V, V);
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaMade_clo;
V g_heff_2ecompile_2esimplify_2eetaOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eetaOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaOne_clo;
V g_heff_2ecompile_2esimplify_2efoldPrim(V, V);
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshParams_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
HeffT2 g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ematchChosen_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf(V, V);
V g_heff_2ecompile_2esimplify_2emissingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emissingOf_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eoneDef_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eoneItem_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2ereplayed_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW(V, V, V);
V g_heff_2ecompile_2esimplify_2escrutW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2escrutW_clo;
V g_heff_2ecompile_2esimplify_2esettleCopy(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2esumOver(V, V, V);
V g_heff_2ecompile_2esimplify_2esumOver_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumOver_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etagApart(V, V, V);
V g_heff_2ecompile_2esimplify_2etagApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagApart_clo;
HeffT2 g_heff_2ecompile_2esimplify_2etouch_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V);
V g_heff_2ecompile_2esimplify_2ewaysOut(V);
V g_heff_2ecompile_2esimplify_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewaysOut_clo;
V g_heff_2ecompile_2esimplify_2ewordLiteral(V);
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo;
V g_heff_2ecompile_2esimplify_2ezipL_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
Clo g_heff_2ecompile_2esimplify_2ezipL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_24dps_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ezipL_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattemptBy_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eattemptBy(V v_more_240, V v_orig_241, V v_m_242, V v_s_243) {
top: ;
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){heff_dup(v_s_243)}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_orig_241), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_247));
    V v_lim_249 = heff_intAdd(v_t_248, v_more_240);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), NTAG(TAG_Nil)});
    V v_x_2411 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_249), MK_INT(0LL), v_t_2410));
    if (!heff_intLt_c_lent(v_lim_249, v_x_2411, 0)) {
      heff_drop(v_orig_241);
      heff_drop_rec(v_s_243, 9);
      heff_drop(v_lim_249);
      heff_drop(v_x_2411);
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_245, v_s_246});
    } else {
      heff_drop(v_x_245);
      heff_drop(v_lim_249);
      heff_drop(v_x_2411);
      V v_t_2412 = ({ V rv_2 = heff_take_field(v_s_243, 2); V rv_5 = heff_get_n(v_s_243, 5, 9); V rr_ = heff_rec_reuse_nf(v_s_246, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 259023u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_orig_241, v_t_2412});
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattemptBy(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2efoldPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efoldPrim_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efoldPrim(V v_p_240, V v_argv_241) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_argv_241)) {
  case TAG_Nil: {
    v_t_248 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_a_242 = heff_dup(heff_field(v_argv_241, 0));
    V v_x22_243 = heff_dup(heff_field(v_argv_241, 1));
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      v_t_248 = (g_heff_2ecompile_2esimplify_2eunOp(v_p_240, v_a_242));
      break;
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x22_243, 0);
      V v_x222_245 = heff_field(v_x22_243, 1);
      heff_take_n(v_x22_243, 3ULL, 2);
      switch (heff_tag_of(v_x222_245)) {
      case TAG_Nil: {
        v_t_248 = (g_heff_2ecompile_2esimplify_2ebinOp(v_p_240, v_a_242, v_b_244));
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x222_245, 0ULL, 2);
        heff_drop(v_a_242);
        heff_drop(v_b_244);
        v_t_248 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x222_245);
      }
      break;
    }
    default: heff_nomatch(v_x22_243);
    }
    break;
  }
  default: heff_nomatch(v_argv_241);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
    }
    case TAG_Cons: {
      V v_a_249 = heff_dup(heff_field(v_argv_241, 0));
      V v_it2_2410 = heff_dup(heff_field(v_argv_241, 1));
      switch (heff_tag_of(v_it2_2410)) {
      case TAG_Nil: {
        heff_drop(v_a_249);
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
      }
      case TAG_Cons: {
        V v_b_2411 = heff_field(v_it2_2410, 0);
        V v_it22_2412 = heff_field(v_it2_2410, 1);
        V v_ru_24it2_2410_24Cons = heff_take_reuse_n(v_it2_2410, 3ULL, 2);
        switch (heff_tag_of(v_it22_2412)) {
        case TAG_Nil: {
          V v_t_2413 = (g_heff_2ecompile_2eir_2eisRel(v_p_240));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop_tag(v_argv_241, 2);
            heff_drop_cell(v_ru_24it2_2410_24Cons, 2);
            heff_drop(v_t_2413);
            return heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_240, v_a_249, v_b_2411})});
          } else {
            heff_drop(v_a_249);
            heff_drop(v_b_2411);
            heff_drop(v_t_2413);
            return heff_tag_at_n(v_ru_24it2_2410_24Cons, TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2412, 0ULL, 2);
          heff_drop(v_a_249);
          heff_drop(v_b_2411);
          return heff_tag_at_n(v_ru_24it2_2410_24Cons, TAG_EPrimCall, 2, (V[]){v_p_240, v_argv_241});
        }
        default: return heff_nomatch(v_it22_2412);
        }
      }
      default: return heff_nomatch(v_it2_2410);
      }
    }
    default: return heff_nomatch(v_argv_241);
    }
  }
  case TAG_Just: {
    V v_v_2416 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_argv_241);
    return v_v_2416;
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecompile_2esimplify_2efoldPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efoldPrim(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eapartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapartOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eapartOf(V v_x_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2eapartOf_24cpr(v_x_240, v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapartOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eapartOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esumTakenApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esumTakenApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_a_241, 0ULL, 4);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_a_241, 0);
    V v_arms_2422 = heff_field(v_a_241, 1);
    V v_ru_24a_241_24EMatch = heff_take_reuse_n(v_a_241, 3ULL, 2);
    V v_x1_2423 = (g_heff_2ecompile_2esimplify_2ewaysOut(heff_tag_at_n(v_ru_24a_241_24EMatch, TAG_EMatch, 2, (V[]){heff_dup(v_s_2421), heff_dup(v_arms_2422)})));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_MkPair: {
      V v_ts_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 2);
      V v_x_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ts_2424; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ts_2424); r_; });
      v_t_2427 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2426, 1));
      heff_drop(v_x_2426);
      break;
    }
    default: heff_nomatch(v_x1_2423);
    }
    if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
      heff_drop(v_t_2427);
      V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
      V v_x_2429 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), v_t_2428));
      if (heff_intLt_c(MK_INT(0LL), v_x_2429)) {
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
        V v_t_2431 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), v_t_2430));
        V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
        V v_t_2433 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_2432));
        V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
        V v_t_2435 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2434));
        V v_t_2436 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2433, v_t_2435}), 0, 2);
        if (heff_intEq_c(v_t_2431, v_t_2436)) {
          V v_x1_2437 = (g_heff_2ecompile_2esimplify_2esumOver(v_x_240, heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2421, v_arms_2422}), v_b_242));
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2437) == NTAG(TAG_True)));
          heff_drop(v_x1_2437);
          return v_ret_24bool;
        } else {
          heff_drop(v_b_242);
          heff_drop(v_s_2421);
          heff_drop(v_arms_2422);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_b_242);
        heff_drop(v_s_2421);
        heff_drop(v_arms_2422);
        return NTAG(TAG_False);
      }
    } else {
      heff_drop(v_b_242);
      heff_drop(v_s_2421);
      heff_drop(v_arms_2422);
      heff_drop(v_t_2427);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_a_241, 0ULL, 3);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_a_241, 0ULL, 1);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_a_241, 0ULL, 2);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esumTakenApart(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2etagApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etagApart_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etagApart(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_argv_2419 = heff_field(v_a_241, 1);
    V v_t_2421 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_argv_2419)));
    V v_x1_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2421); r_; });
    if (!(heff_dup(v_x1_2422) == NTAG(TAG_True))) {
      heff_drop(v_x1_2422);
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_242, NTAG(TAG_Nil)});
      V v_x_2424 = (g_heff_2ecompile_2esimplify_2escrutW(v_x_240, MK_INT(0LL), v_t_2423));
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2424, 1));
      heff_drop(v_x_2424);
      return v_ret_24bool;
    } else {
      heff_drop(v_b_242);
      heff_drop(v_x1_2422);
      return NTAG(TAG_False);
    }
  }
  case TAG_EMatch: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2ecompile_2esimplify_2etagApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2etagApart(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ewordLiteral_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ewordLiteral_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ewordLiteral(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    V v_i_2426 = heff_field(v_e_240, 0);
    V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_i_2426, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_i_2426, 1)));
    return v_ret_24bool;
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2ewordLiteral_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ewordLiteral(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2esimplify_2ematchChosen_24cpr(V v_known_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_sc_2420 = heff_field(v_x2_241, 0);
    V v_arms_2421 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2461;
    switch (heff_tag_of(v_sc_2420)) {
    case TAG_EVar: {
      V v_x_2422 = heff_field(v_sc_2420, 0);
      V v_ru_24sc_2420_24EVar = heff_take_reuse_n(v_sc_2420, 1ULL, 1);
      v_t_2461 = ({ V a_0 = v_ru_24sc_2420_24EVar; V a_1 = v_known_240; V a_2 = v_x_2422; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_sc_2420, 0ULL, 3);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_sc_2420, 0ULL, 4);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_sc_2420, 0ULL, 3);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_sc_2420, 0ULL, 3);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_sc_2420, 0ULL, 1);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_sc_2420, 0ULL, 2);
      v_t_2461 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_sc_2420);
    }
    return ({ V a_0 = v_known_240; V a_1 = v_arms_2421; V a_2 = v_t_2461; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2earmChosen_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2461); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_known_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_243, v_e_240));
    if (heff_intEq_c(v_t_244, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_246 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_245, v_e_240));
      HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_246, v_p_241));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_x_2410 = v_field_248;
        V v_s_2411 = v_field_249;
        V v_t_2412 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2410), v_e_240));
        V v_x_2413 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2410, v_t_2412});
        return ((HeffT2){{v_x_2413, v_s_2411}});
      }
    }
  }
  case TAG_EGlobal: {
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2415, v_e_240));
    if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2418 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2417, v_e_240));
      HeffT2 v_t_2419 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2418, v_p_241));
      {
        V v_field_2420 = v_t_2419.f[0];
        V v_field_2421 = v_t_2419.f[1];
        V v_x_2422 = v_field_2420;
        V v_s_2423 = v_field_2421;
        V v_t_2424 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2422), v_e_240));
        V v_x_2425 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2422, v_t_2424});
        return ((HeffT2){{v_x_2425, v_s_2423}});
      }
    }
  }
  case TAG_ELam: {
    V v_xs_2426 = heff_field(v_e_240, 0);
    V v_b_2427 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2429 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2428, v_b_2427));
    if (heff_intEq_c(v_t_2429, MK_INT(0LL))) {
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_xs_2426, v_b_2427}), v_p_241}});
    } else {
      V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2431 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2430, v_b_2427));
      HeffT2 v_t_2432 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2431, v_p_241));
      {
        V v_field_2433 = v_t_2432.f[0];
        V v_field_2434 = v_t_2432.f[1];
        V v_x_2435 = v_field_2433;
        V v_s_2436 = v_field_2434;
        V v_t_2437 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_2426, heff_dup(v_x_2435)));
        V v_t_2438 = (g_heff_2ecompile_2esimplify_2estripLams(v_x_2435, v_b_2427));
        V v_x_2439 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2437, v_t_2438});
        return ((HeffT2){{v_x_2439, v_s_2436}});
      }
    }
  }
  case TAG_EApp: {
    V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2443 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2442, v_e_240));
    if (heff_intEq_c(v_t_2443, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2445 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2444, v_e_240));
      HeffT2 v_t_2446 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2445, v_p_241));
      {
        V v_field_2447 = v_t_2446.f[0];
        V v_field_2448 = v_t_2446.f[1];
        V v_x_2449 = v_field_2447;
        V v_s_2450 = v_field_2448;
        V v_t_2451 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2449), v_e_240));
        V v_x_2452 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2449, v_t_2451});
        return ((HeffT2){{v_x_2452, v_s_2450}});
      }
    }
  }
  case TAG_ELet: {
    V v_t_2456 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2457 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2456, v_e_240));
    if (heff_intEq_c(v_t_2457, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2459 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2458, v_e_240));
      HeffT2 v_t_2460 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2459, v_p_241));
      {
        V v_field_2461 = v_t_2460.f[0];
        V v_field_2462 = v_t_2460.f[1];
        V v_x_2463 = v_field_2461;
        V v_s_2464 = v_field_2462;
        V v_t_2465 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2463), v_e_240));
        V v_x_2466 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2463, v_t_2465});
        return ((HeffT2){{v_x_2466, v_s_2464}});
      }
    }
  }
  case TAG_ERecord: {
    V v_t_2469 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2470 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2469, v_e_240));
    if (heff_intEq_c(v_t_2470, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2471 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2472 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2471, v_e_240));
      HeffT2 v_t_2473 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2472, v_p_241));
      {
        V v_field_2474 = v_t_2473.f[0];
        V v_field_2475 = v_t_2473.f[1];
        V v_x_2476 = v_field_2474;
        V v_s_2477 = v_field_2475;
        V v_t_2478 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2476), v_e_240));
        V v_x_2479 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2476, v_t_2478});
        return ((HeffT2){{v_x_2479, v_s_2477}});
      }
    }
  }
  case TAG_EProj: {
    V v_t_2484 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2485 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2484, v_e_240));
    if (heff_intEq_c(v_t_2485, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_2486 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_2487 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2486, v_e_240));
      HeffT2 v_t_2488 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_2487, v_p_241));
      {
        V v_field_2489 = v_t_2488.f[0];
        V v_field_2490 = v_t_2488.f[1];
        V v_x_2491 = v_field_2489;
        V v_s_2492 = v_field_2490;
        V v_t_2493 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_2491), v_e_240));
        V v_x_2494 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2491, v_t_2493});
        return ((HeffT2){{v_x_2494, v_s_2492}});
      }
    }
  }
  case TAG_ETag: {
    V v_t_2498 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_2499 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_2498, v_e_240));
    if (heff_intEq_c(v_t_2499, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24100 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24101 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24100, v_e_240));
      HeffT2 v_t_24102 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24101, v_p_241));
      {
        V v_field_24103 = v_t_24102.f[0];
        V v_field_24104 = v_t_24102.f[1];
        V v_x_24105 = v_field_24103;
        V v_s_24106 = v_field_24104;
        V v_t_24107 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24105), v_e_240));
        V v_x_24108 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24105, v_t_24107});
        return ((HeffT2){{v_x_24108, v_s_24106}});
      }
    }
  }
  case TAG_EMatch: {
    V v_t_24111 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24112 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24111, v_e_240));
    if (heff_intEq_c(v_t_24112, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24113 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24114 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24113, v_e_240));
      HeffT2 v_t_24115 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24114, v_p_241));
      {
        V v_field_24116 = v_t_24115.f[0];
        V v_field_24117 = v_t_24115.f[1];
        V v_x_24118 = v_field_24116;
        V v_s_24119 = v_field_24117;
        V v_t_24120 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24118), v_e_240));
        V v_x_24121 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24118, v_t_24120});
        return ((HeffT2){{v_x_24121, v_s_24119}});
      }
    }
  }
  case TAG_EPrim: {
    V v_t_24123 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24124 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24123, v_e_240));
    if (heff_intEq_c(v_t_24124, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24125 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24126 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24125, v_e_240));
      HeffT2 v_t_24127 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24126, v_p_241));
      {
        V v_field_24128 = v_t_24127.f[0];
        V v_field_24129 = v_t_24127.f[1];
        V v_x_24130 = v_field_24128;
        V v_s_24131 = v_field_24129;
        V v_t_24132 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24130), v_e_240));
        V v_x_24133 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24130, v_t_24132});
        return ((HeffT2){{v_x_24133, v_s_24131}});
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_24136 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24137 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24136, v_e_240));
    if (heff_intEq_c(v_t_24137, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24138 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24139 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24138, v_e_240));
      HeffT2 v_t_24140 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24139, v_p_241));
      {
        V v_field_24141 = v_t_24140.f[0];
        V v_field_24142 = v_t_24140.f[1];
        V v_x_24143 = v_field_24141;
        V v_s_24144 = v_field_24142;
        V v_t_24145 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24143), v_e_240));
        V v_x_24146 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24143, v_t_24145});
        return ((HeffT2){{v_x_24146, v_s_24144}});
      }
    }
  }
  case TAG_ECall: {
    V v_t_24149 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24150 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24149, v_e_240));
    if (heff_intEq_c(v_t_24150, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24151 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24152 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24151, v_e_240));
      HeffT2 v_t_24153 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24152, v_p_241));
      {
        V v_field_24154 = v_t_24153.f[0];
        V v_field_24155 = v_t_24153.f[1];
        V v_x_24156 = v_field_24154;
        V v_s_24157 = v_field_24155;
        V v_t_24158 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24156), v_e_240));
        V v_x_24159 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24156, v_t_24158});
        return ((HeffT2){{v_x_24159, v_s_24157}});
      }
    }
  }
  case TAG_EInt: {
    V v_t_24161 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24162 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24161, v_e_240));
    if (heff_intEq_c(v_t_24162, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24163 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24164 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24163, v_e_240));
      HeffT2 v_t_24165 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24164, v_p_241));
      {
        V v_field_24166 = v_t_24165.f[0];
        V v_field_24167 = v_t_24165.f[1];
        V v_x_24168 = v_field_24166;
        V v_s_24169 = v_field_24167;
        V v_t_24170 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24168), v_e_240));
        V v_x_24171 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24168, v_t_24170});
        return ((HeffT2){{v_x_24171, v_s_24169}});
      }
    }
  }
  case TAG_EFloat: {
    V v_t_24173 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24174 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24173, v_e_240));
    if (heff_intEq_c(v_t_24174, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24175 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24176 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24175, v_e_240));
      HeffT2 v_t_24177 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24176, v_p_241));
      {
        V v_field_24178 = v_t_24177.f[0];
        V v_field_24179 = v_t_24177.f[1];
        V v_x_24180 = v_field_24178;
        V v_s_24181 = v_field_24179;
        V v_t_24182 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24180), v_e_240));
        V v_x_24183 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24180, v_t_24182});
        return ((HeffT2){{v_x_24183, v_s_24181}});
      }
    }
  }
  case TAG_EStr: {
    V v_t_24185 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24186 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24185, v_e_240));
    if (heff_intEq_c(v_t_24186, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24187 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24188 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24187, v_e_240));
      HeffT2 v_t_24189 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24188, v_p_241));
      {
        V v_field_24190 = v_t_24189.f[0];
        V v_field_24191 = v_t_24189.f[1];
        V v_x_24192 = v_field_24190;
        V v_s_24193 = v_field_24191;
        V v_t_24194 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24192), v_e_240));
        V v_x_24195 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24192, v_t_24194});
        return ((HeffT2){{v_x_24195, v_s_24193}});
      }
    }
  }
  case TAG_EBytes: {
    V v_t_24197 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24198 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24197, v_e_240));
    if (heff_intEq_c(v_t_24198, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24199 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24200 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24199, v_e_240));
      HeffT2 v_t_24201 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24200, v_p_241));
      {
        V v_field_24202 = v_t_24201.f[0];
        V v_field_24203 = v_t_24201.f[1];
        V v_x_24204 = v_field_24202;
        V v_s_24205 = v_field_24203;
        V v_t_24206 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24204), v_e_240));
        V v_x_24207 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24204, v_t_24206});
        return ((HeffT2){{v_x_24207, v_s_24205}});
      }
    }
  }
  case TAG_EFixed: {
    V v_t_24210 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24211 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24210, v_e_240));
    if (heff_intEq_c(v_t_24211, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24212 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24213 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24212, v_e_240));
      HeffT2 v_t_24214 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24213, v_p_241));
      {
        V v_field_24215 = v_t_24214.f[0];
        V v_field_24216 = v_t_24214.f[1];
        V v_x_24217 = v_field_24215;
        V v_s_24218 = v_field_24216;
        V v_t_24219 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24217), v_e_240));
        V v_x_24220 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24217, v_t_24219});
        return ((HeffT2){{v_x_24220, v_s_24218}});
      }
    }
  }
  case TAG_EFloat32: {
    V v_t_24222 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24223 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24222, v_e_240));
    if (heff_intEq_c(v_t_24223, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24224 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24225 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24224, v_e_240));
      HeffT2 v_t_24226 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24225, v_p_241));
      {
        V v_field_24227 = v_t_24226.f[0];
        V v_field_24228 = v_t_24226.f[1];
        V v_x_24229 = v_field_24227;
        V v_s_24230 = v_field_24228;
        V v_t_24231 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24229), v_e_240));
        V v_x_24232 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24229, v_t_24231});
        return ((HeffT2){{v_x_24232, v_s_24230}});
      }
    }
  }
  case TAG_EAbandon: {
    V v_t_24233 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24234 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24233, v_e_240));
    if (heff_intEq_c(v_t_24234, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24235 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24236 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24235, v_e_240));
      HeffT2 v_t_24237 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24236, v_p_241));
      {
        V v_field_24238 = v_t_24237.f[0];
        V v_field_24239 = v_t_24237.f[1];
        V v_x_24240 = v_field_24238;
        V v_s_24241 = v_field_24239;
        V v_t_24242 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24240), v_e_240));
        V v_x_24243 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24240, v_t_24242});
        return ((HeffT2){{v_x_24243, v_s_24241}});
      }
    }
  }
  case TAG_EBool: {
    V v_t_24245 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24246 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24245, v_e_240));
    if (heff_intEq_c(v_t_24246, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24247 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24248 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24247, v_e_240));
      HeffT2 v_t_24249 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24248, v_p_241));
      {
        V v_field_24250 = v_t_24249.f[0];
        V v_field_24251 = v_t_24249.f[1];
        V v_x_24252 = v_field_24250;
        V v_s_24253 = v_field_24251;
        V v_t_24254 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24252), v_e_240));
        V v_x_24255 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24252, v_t_24254});
        return ((HeffT2){{v_x_24255, v_s_24253}});
      }
    }
  }
  case TAG_ESet: {
    V v_t_24259 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24260 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24259, v_e_240));
    if (heff_intEq_c(v_t_24260, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24261 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24262 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24261, v_e_240));
      HeffT2 v_t_24263 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24262, v_p_241));
      {
        V v_field_24264 = v_t_24263.f[0];
        V v_field_24265 = v_t_24263.f[1];
        V v_x_24266 = v_field_24264;
        V v_s_24267 = v_field_24265;
        V v_t_24268 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24266), v_e_240));
        V v_x_24269 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24266, v_t_24268});
        return ((HeffT2){{v_x_24269, v_s_24267}});
      }
    }
  }
  case TAG_EValues: {
    V v_t_24271 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24272 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24271, v_e_240));
    if (heff_intEq_c(v_t_24272, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24273 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24274 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24273, v_e_240));
      HeffT2 v_t_24275 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24274, v_p_241));
      {
        V v_field_24276 = v_t_24275.f[0];
        V v_field_24277 = v_t_24275.f[1];
        V v_x_24278 = v_field_24276;
        V v_s_24279 = v_field_24277;
        V v_t_24280 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24278), v_e_240));
        V v_x_24281 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24278, v_t_24280});
        return ((HeffT2){{v_x_24281, v_s_24279}});
      }
    }
  }
  case TAG_EFix: {
    V v_t_24284 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
    V v_t_24285 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24284, v_e_240));
    if (heff_intEq_c(v_t_24285, MK_INT(0LL))) {
      return ((HeffT2){{v_e_240, v_p_241}});
    } else {
      V v_t_24286 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 0, 7);
      V v_t_24287 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_t_24286, v_e_240));
      HeffT2 v_t_24288 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_t_24287, v_p_241));
      {
        V v_field_24289 = v_t_24288.f[0];
        V v_field_24290 = v_t_24288.f[1];
        V v_x_24291 = v_field_24289;
        V v_s_24292 = v_field_24290;
        V v_t_24293 = (g_heff_2ecompile_2esimplify_2estripLams(heff_dup(v_x_24291), v_e_240));
        V v_x_24294 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_24291, v_t_24293});
        return ((HeffT2){{v_x_24294, v_s_24292}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2etouch_24cpr(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_kp_243 = heff_take_field(v_s_242, 8);
  V v_supply_244 = heff_take_field(v_s_242, 0);
  V v_fuel_245 = heff_take_field(v_s_242, 1);
  V v_defs_246 = heff_take_field(v_s_242, 2);
  V v_safe_247 = heff_take_field(v_s_242, 3);
  V v_base_248 = heff_take_field(v_s_242, 4);
  V v_total_249 = heff_take_field(v_s_242, 5);
  V v_plain_2410 = heff_take_field(v_s_242, 6);
  V v_sp_2411 = heff_get_n(v_s_242, 7, 9);
  V v_k_2412 = v_kp_243;
  V v_vers_2413 = heff_take_field(v_k_2412, 0);
  V v_kept_2414 = heff_take_field(v_k_2412, 1);
  V v_touched_2415 = heff_take_field(v_k_2412, 2);
  V v_fresh_2416 = heff_take_field(v_k_2412, 3);
  V v_madeFresh_2417 = heff_get_n(v_k_2412, 4, 5);
  V v_t_2418 = (g_std_2emap_2einsert_24s93785294x875597928(v_vers_2413, heff_dup(v_h_240), v_v_241));
  V v_t_2419 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_t_2418, v_kept_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_h_240, v_touched_2415}), v_fresh_2416, v_madeFresh_2417});
  V v_f_2420 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_supply_244, v_fuel_245, v_defs_246, v_safe_247, v_base_248, v_total_249, v_plain_2410, v_sp_2411, v_t_2419});
  return ((HeffT2){{NTAG(TAG_MkUnit), v_f_2420}});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eversAll_24cpr_str0, 0, "");

HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_v_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c_lent(v_v_243, ((V)&g_heff_2ecompile_2esimplify_2eversAll_24cpr_str0), 2)) {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_v_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2eversAll_24cpr(v_rest_242));
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_vs_247 = v_field_246;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_v_243, v_vs_247})}});
          } else {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_v_243);
            heff_drop(v_field_246);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2ecompile_2esimplify_2easkKept_24cpr(V v_h_240, V v_kc_241, V v_x3_242, V v_p_243) {
top: ;
  V v_depth_244 = heff_take_field(v_kc_241, 2);
  V v_safe_245 = heff_get_n(v_kc_241, 3, 5);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop(v_depth_244);
    heff_drop(v_safe_245);
    return ((HeffT2){{NTAG(TAG_False), v_p_243}});
  }
  case TAG_Just: {
    V v_b_246 = heff_field(v_x3_242, 0);
    HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_dup(v_b_246), v_p_243));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_x_2410 = v_field_248;
      V v_s_2411 = v_field_249;
      HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_240), v_x_2410, v_depth_244, v_s_2411));
      {
        V v_field_2413 = v_t_2412.f[0];
        V v_field_2414 = v_t_2412.f[1];
        V v_x_2415 = v_field_2413;
        heff_drop(v_x_2415);
        V v_s_2416 = v_field_2414;
        HeffT2 v_t_2417 = ({ V a_0 = v_safe_245; V a_1 = v_h_240; V a_2 = v_s_2416; HeffT2 r_ = (g_heff_2ecompile_2esimplify_2emarkSafeAs_24cpr(a_0, a_1, a_2)); heff_drop(v_safe_245); r_; });
        {
          V v_field_2418 = v_t_2417.f[0];
          V v_field_2419 = v_t_2417.f[1];
          V v_x_2420 = v_field_2418;
          heff_drop(v_x_2420);
          V v_s_2421 = v_field_2419;
          return ((HeffT2){{NTAG(TAG_True), v_s_2421}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eetaOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eetaOne(V v_r_240, V v_e_241, V v_k_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ELam: {
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EApp: {
    V v_h_248 = heff_field(v_e_241, 0);
    V v_bs_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_x2_2410 = heff_tr(g_heff_2ecompile_2esimplify_2ebindArgs(v_bs_249, heff_dup(v_p_243)));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      HeffT2 v_t_2413 = (g_heff_2ecompile_2esimplify_2efreshParams_24cpr(v_k_242, v_s_2412));
      {
        V v_field_2414 = v_t_2413.f[0];
        V v_field_2415 = v_t_2413.f[1];
        V v_x_2416 = v_field_2414;
        V v_s_2417 = v_field_2415;
        V v_t_2420;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_MkPair: {
          V v_y_2419 = heff_dup(heff_field(v_x_2411, 1));
          v_t_2420 = v_y_2419;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_t_2421 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24x2_2410_24MkPair, heff_dup(v_x_2416)));
        V v_t_2422 = (g_heff_2ecompile_2esimplify_2eappendL(v_t_2420, v_t_2421));
        V v_m_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_h_248, v_t_2422}));
        V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2417}));
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_s_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          HEFF_LAST return g_heff_2ecompile_2esimplify_2eetaKept(v_p_243, v_x_2411, heff_tag_at_n(v_ru_24e_241_24EApp, TAG_ELam, 2, (V[]){v_x_2416, v_x_2425}), v_s_2426);
        }
        default: return heff_nomatch(v_x2_2424);
        }
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ERecord: {
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EMatch: {
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EPrimCall: {
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ECall: {
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFixed: {
    V v_ru_24e_241_24EFixed = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  case TAG_EFix: {
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24e_241_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_243});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eetaArg_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eetaArg_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eetaArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaArg_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eetaArg(V v_r_240, V v_st_241, V v_a_242, V v_rest_243, V v_s_244) {
top: ;
  V v_k_245 = (g_heff_2ecompile_2esimplify_2emissingOf(heff_dup(v_s_244), v_a_242));
  return (g_heff_2ecompile_2esimplify_2ebind(heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArg_lam0, 1, 4, (V[]){heff_dup(v_st_241), v_k_245, v_r_240, heff_dup(v_a_242)}), heff_clo_n(g_heff_2ecompile_2esimplify_2eetaArg_lam1, 2, 2, (V[]){v_rest_243, v_a_242}), v_s_244));
}
V g_heff_2ecompile_2esimplify_2eetaArg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaArg(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eetaArg_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_a_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_st_241) == NTAG(TAG_True))) {
    heff_drop(v_st_241);
    if (heff_intLt_c_lent(MK_INT(0LL), v_k_245, 1)) {
      return (g_heff_2ecompile_2esimplify_2eetaOne(v_r_240, v_a_242, v_k_245, v_p_246));
    } else {
      heff_drop(v_k_245);
      heff_drop(v_r_240);
      heff_drop(v_a_242);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_246});
    }
  } else {
    heff_drop(v_st_241);
    heff_drop(v_k_245);
    heff_drop(v_r_240);
    heff_drop(v_a_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_246});
  }
}
V g_heff_2ecompile_2esimplify_2eetaArg_lam1(V self, V *args) {
  V v_e_247 = args[0];
  V v_z_248 = args[1];
  V v_rest_243 = heff_env(self)[0];
  V v_a_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417;
  switch (heff_tag_of(v_e_247)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_rest_243)) {
    case TAG_MkPair: {
      V v_rest_249 = heff_field(v_rest_243, 0);
      V v_argv_2410 = heff_field(v_rest_243, 1);
      V v_ru_24rest_243_24MkPair = heff_take_reuse_n(v_rest_243, 3ULL, 2);
      v_x_2417 = heff_tag_at_n(v_ru_24rest_243_24MkPair, TAG_MkPair, 2, (V[]){v_rest_249, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_argv_2410})});
      break;
    }
    default: heff_nomatch(v_rest_243);
    }
    break;
  }
  case TAG_Just: {
    V v_x21_2411 = heff_field(v_e_247, 0);
    heff_take_n(v_e_247, 1ULL, 1);
    heff_drop(v_a_242);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_bds_2412 = heff_field(v_x21_2411, 0);
      V v_lam1_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      switch (heff_tag_of(v_rest_243)) {
      case TAG_MkPair: {
        V v_rest_2414 = heff_field(v_rest_243, 0);
        V v_argv_2415 = heff_field(v_rest_243, 1);
        V v_ru_24rest_243_24MkPair = heff_take_reuse_n(v_rest_243, 3ULL, 2);
        V v_t_2416 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24rest_243_24MkPair, v_bds_2412, v_rest_2414));
        v_x_2417 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_lam1_2413, v_argv_2415})});
        break;
      }
      default: heff_nomatch(v_rest_243);
      }
      break;
    }
    default: heff_nomatch(v_x21_2411);
    }
    break;
  }
  default: heff_nomatch(v_e_247);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_z_248});
}
Clo g_heff_2ecompile_2esimplify_2eetaMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaMade_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eetaMade(V v_a_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_a_240));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_249 = v_field_247;
      heff_drop(v_x_249);
      V v_y_2410 = v_field_248;
      switch (heff_tag_of(v_y_2410)) {
      case TAG_EVar: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EGlobal: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_ELam: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_ELet: {
        heff_take_n(v_y_2410, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_ERecord: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EProj: {
        heff_take_n(v_y_2410, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_ETag: {
        heff_take_n(v_y_2410, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_EMatch: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EPrim: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_ECall: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EInt: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EFloat: {
        heff_take_na(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EStr: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EBytes: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EFixed: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      case TAG_EFloat32: {
        heff_take_na(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_True);
      }
      case TAG_EBool: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_ESet: {
        heff_take_n(v_y_2410, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_EValues: {
        heff_take_n(v_y_2410, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_EFix: {
        heff_take_n(v_y_2410, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_y_2410);
      }
    }
  }
  case TAG_EApp: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_a_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eetaMade_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eetaMade(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2esettleCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esettleCopy_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esettleCopy(V v_more_240, V v_n_241, V v_h_242, V v_b_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
  V v_t_246 = (g_heff_2ecompile_2eir_2enubI(v_t_245));
  V v_m_247 = heff_tr(heff_call(heff_dup(v_more_240), 1, (V[]){v_t_246}));
  V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){heff_dup(v_s_244)}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (heff_intLt_c_lent(MK_INT(0LL), v_n_241, 1)) {
      V v_t_2411 = (g_heff_2ecompile_2esimplify_2egrewIn(v_s_244, heff_dup(v_s_2410), heff_dup(v_b_243)));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2emakeAgain_24cpr(heff_dup(v_h_242), v_b_243, v_s_2410));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_s_2416 = v_field_2414;
          V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleCopy_clo), 4, (V[]){v_more_240, heff_intSub(v_n_241, MK_INT(1LL)), v_h_242, v_x_2415}));
          V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            V v_s_2420 = heff_field(v_x2_2418, 1);
            V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
            V v_t_2423;
            switch (heff_tag_of(v_x_2419)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_dup(heff_field(v_x_2419, 0));
              v_t_2423 = v_x_2421;
              break;
            }
            default: heff_nomatch(v_x_2419);
            }
            V v_t_2426;
            switch (heff_tag_of(v_x_2419)) {
            case TAG_MkPair: {
              V v_y_2425 = heff_field(v_x_2419, 1);
              heff_take_n(v_x_2419, 2ULL, 2);
              v_t_2426 = v_y_2425;
              break;
            }
            default: heff_nomatch(v_x_2419);
            }
            V v_t_2427 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_249, v_t_2426));
            V v_x_2428 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_t_2427});
            return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2420});
          }
          default: return heff_nomatch(v_x2_2418);
          }
        }
      } else {
        heff_drop(v_more_240);
        heff_drop(v_n_241);
        heff_drop(v_h_242);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_243, v_x_249}), v_s_2410});
      }
    } else {
      heff_drop(v_more_240);
      heff_drop(v_n_241);
      heff_drop(v_h_242);
      heff_drop(v_s_244);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_243, v_x_249}), v_s_2410});
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2esettleCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esettleCopy(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eoneItem_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef_24cpr(v_d_242, v_p_241);
  }
  case TAG_Kept: {
    V v_k_243 = heff_field(v_x1_240, 0);
    V v_redo_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Kept = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_243, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
    HeffT2 v_t_246 = (g_heff_2ecompile_2esimplify_2ereplayed_24cpr(v_k_243, v_t_245, heff_dup(v_p_241)));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_249 = v_field_247;
      V v_s_2410 = v_field_248;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Kept, 2);
        heff_drop(v_s_2410);
        V v_t_2411 = heff_tr(heff_call(v_redo_244, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))}));
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eafresh_24cpr(v_t_2411, v_p_241);
      }
      case TAG_Just: {
        V v_ds_2412 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 1);
        heff_drop_rec(v_p_241, 9);
        heff_drop(v_redo_244);
        V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24Kept, TAG_MkPair, 2, (V[]){v_ds_2412, NTAG(TAG_Nil)});
        return ((HeffT2){{v_t_2413, v_s_2410}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x_249)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}