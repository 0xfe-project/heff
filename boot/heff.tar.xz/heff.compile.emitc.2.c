// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CBytes 45123
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedBytes 24193
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_NoCustody 24110
#define TAG_Reading 19214
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define LBL_answered 245579351
#define LBL_args 9498020
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_defs 9574869
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_errors 652506774
#define LBL_facts 298546081
#define LBL_fun 311289
#define LBL_groups 709681407
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_leaf 9813029
#define LBL_lprotos 613175609
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_owner 307523277
#define LBL_pieces 958716528
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_result 1012715336
#define LBL_shapes 1043573789
#define LBL_simplified 1686448252
#define LBL_source 1050636102
#define LBL_strs 10036521
#define LBL_supply 1056026650
#define LBL_tag 324116
#define LBL_tags 10047712
#define LBL_ver 326173
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_pieces__errors__supply[] = {LBL_pieces, LBL_errors, LBL_supply};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_simplified__errors__groups__copies[] = {LBL_simplified, LBL_errors, LBL_groups, LBL_copies};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2eargLines(V, V);
V g_heff_2ecompile_2eemitc_2eargLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_clo;
V g_heff_2ecompile_2eemitc_2eassertLine(V, V);
V g_heff_2ecompile_2eemitc_2eassertLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eassertLine_clo;
V g_heff_2ecompile_2eemitc_2ecaseLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecaseLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecaseLines_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efunTypeName(V);
V g_heff_2ecompile_2eemitc_2efunTypeName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunTypeName_clo;
V g_heff_2ecompile_2eemitc_2ehashBelow(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2ehelperLines(V, V);
V g_heff_2ecompile_2eemitc_2ehelperLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehelperLines_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(V, V, V);
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eperformCode(V);
V g_heff_2ecompile_2eemitc_2eperformCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eperformCode_clo;
V g_heff_2ecompile_2eemitc_2epointerFnLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_clo;
V g_heff_2ecompile_2eemitc_2epointersGo(V, V);
V g_heff_2ecompile_2eemitc_2epointersGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointersGo_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2eresultDecl(V);
V g_heff_2ecompile_2eemitc_2eresultDecl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultDecl_clo;
V g_heff_2ecompile_2eemitc_2eresultLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eresultLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultLines_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2estringArgsGo(V, V);
V g_heff_2ecompile_2eemitc_2estringArgsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estringArgsGo_clo;
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estringArgsGo_24dps_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
V g_heff_2ecompile_2eemitc_2ewordAs(V, V);
V g_heff_2ecompile_2eemitc_2ewordAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewordAs_clo;
HeffT3 g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2edispatchDefs(V, V, V);
V g_heff_2ecompile_2elower_2edispatchDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2edispatchDefs_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584(V, V, V, V, V);
V g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584_clo;
V g_heff_2ecompile_2elower_2egroupGo(V);
V g_heff_2ecompile_2elower_2egroupGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupGo_clo;
V g_heff_2ecompile_2elower_2ereachedPieces(V);
V g_heff_2ecompile_2elower_2ereachedPieces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ereachedPieces_clo;
V g_heff_2ecompile_2elower_2erevOnto(V, V);
V g_heff_2ecompile_2elower_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2erevOnto_clo;
V g_heff_2ecompile_2elower_2eshapeSaid(V);
V g_heff_2ecompile_2elower_2eshapeSaid_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eshapeSaid_clo;
V g_heff_2ecompile_2elower_2eunitVers(V, V);
V g_heff_2ecompile_2elower_2eunitVers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eunitVers_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram_24rec0_get(void);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eany_24s1022483754x1154500907(V);
V g_list_2eany_24s1022483754x1154500907_entry(V self, V *a);
extern Clo g_list_2eany_24s1022483754x1154500907_clo;
V g_list_2eany_24s1362258228x1848434975(V);
V g_list_2eany_24s1362258228x1848434975_entry(V self, V *a);
extern Clo g_list_2eany_24s1362258228x1848434975_clo;
V g_list_2eany_24s1419545795x962553976(V, V, V);
V g_list_2eany_24s1419545795x962553976_entry(V self, V *a);
extern Clo g_list_2eany_24s1419545795x962553976_clo;
V g_list_2eany_24s1419619328x1805745269(V);
V g_list_2eany_24s1419619328x1805745269_entry(V self, V *a);
extern Clo g_list_2eany_24s1419619328x1805745269_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1484108573x1404267297(V, V, V, V);
V g_list_2efoldl_24s1484108573x1404267297_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1484108573x1404267297_clo;
V g_list_2efoldl_24s1499934538x170225690(V, V);
V g_list_2efoldl_24s1499934538x170225690_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1499934538x170225690_clo;
V g_list_2efoldl_24s1520027297x1040032870(V, V);
V g_list_2efoldl_24s1520027297x1040032870_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1520027297x1040032870_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s2070597502x591087275(V, V);
V g_list_2efoldl_24s2070597502x591087275_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2070597502x591087275_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s478006518x1380334353(V);
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1218298322x1569510752(V, V);
V g_list_2emap_24s1218298322x1569510752_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_clo;
V g_list_2emap_24s1418269708x2034621695(V, V);
V g_list_2emap_24s1418269708x2034621695_entry(V self, V *a);
extern Clo g_list_2emap_24s1418269708x2034621695_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1985010810x1780722131(V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_clo;
V g_list_2emap_24s420582357x1720502382(V);
V g_list_2emap_24s420582357x1720502382_entry(V self, V *a);
extern Clo g_list_2emap_24s420582357x1720502382_clo;
V g_list_2emap_24s509077117x607152875(V);
V g_list_2emap_24s509077117x607152875_entry(V self, V *a);
extern Clo g_list_2emap_24s509077117x607152875_clo;
V g_list_2emap_24s509077117x607152875_24tok1(V, V);
V g_list_2emap_24s509077117x607152875_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s509077117x607152875_24tok1_clo;
V g_list_2emap_24s510639937x1058700299(V);
V g_list_2emap_24s510639937x1058700299_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_clo;
V g_list_2emap_24s693155583x821663253(V, V, V);
V g_list_2emap_24s693155583x821663253_entry(V self, V *a);
extern Clo g_list_2emap_24s693155583x821663253_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(V v_lit_240, V v_lit_241, V v_go_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(heff_dup(v_go_242), 1, (V[]){v_lit_241}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_ts_244 = heff_field(v_x1_243, 0);
    V v_ls_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    V v_t_246 = (g_prelude_2e_2b_2b(v_ts_244, NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2e_2b_2b(v_ls_245, NTAG(TAG_Nil)));
    V v_x1_248 = heff_tr(heff_call(v_go_242, 1, (V[]){v_lit_240}));
    V v_z_2413;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_MkPair: {
      V v_ts_249 = heff_field(v_x1_248, 0);
      V v_ls_2410 = heff_field(v_x1_248, 1);
      V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
      V v_t_2411 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_248_24MkPair, v_ts_249, v_t_246));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_ls_2410, v_t_247));
      v_z_2413 = heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_t_2412});
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    return v_z_2413;
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2enamesIn_24s1133949433x26160283(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehashedGo_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ehashedGo(V v_base_240, V v_m_241, V v_x3_242, V v_names_243, V v_taken_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_base_240);
    heff_drop(v_m_241);
    heff_drop(v_taken_244);
    return v_names_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_names_243, v_x_245));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2410 = v_field_249;
        heff_drop(v_x_2410);
        V t_0 = v_base_240;
        V t_1 = v_m_241;
        V t_2 = v_xs_246;
        V t_3 = v_names_243;
        V t_4 = v_taken_244;
        v_base_240 = t_0;
        v_m_241 = t_1;
        v_x3_242 = t_2;
        v_names_243 = t_3;
        v_taken_244 = t_4;
        goto top;
      } else {
        heff_drop(v_field_249);
        V v_t_2411 = (g_heff_2ecompile_2eemitc_2ehashBelow(v_x_245, heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
        V v_t_2412 = (g_heff_2ecompile_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2411, v_taken_244));
        V v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_names_243, heff_dup(v_x_245), v_t_2412));
        V v_t_2414 = (g_heff_2ecompile_2eemitc_2ehashBelow(v_x_245, heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
        V v_t_2415 = (g_heff_2ecompile_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2414, v_taken_244));
        V v_t_2416 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_taken_244, v_t_2415, NTAG(TAG_MkUnit)));
        V t_0 = v_base_240;
        V t_1 = v_m_241;
        V t_2 = v_xs_246;
        V t_3 = v_t_2413;
        V t_4 = v_t_2416;
        v_base_240 = t_0;
        v_m_241 = t_1;
        v_x3_242 = t_2;
        v_names_243 = t_3;
        v_taken_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ehashedGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str1, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str3, 2, "__");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str4, 6, "shape_");

HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V v_ls_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s420582357x1720502382(heff_dup(v_ls_240)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_o_246 = heff_dup(heff_rfield(v_s_241, 0));
  V v_x2_247 = (g_list_2emap_24s420582357x1720502382(v_ls_240));
  V v_k_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_k_2410 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_k_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_ps_2411 = heff_take_field(v_s_241, 6);
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2eownHas(v_o_246, v_k_2410, v_ps_2411));
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_o_246);
    heff_drop(v_k_2410);
    heff_drop(v_t_2412);
    v_t_2413 = v_ps_2411;
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_o_246, v_k_2410}), v_ps_2411});
  }
  V v_f_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eshapeLit_24cpr_str4), v_t_245);
  V v_f_2415 = ({ V rv_6 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_241, 191ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  return ((HeffT2){{v_f_2414, v_f_2415}});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str0, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str1, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str3, 17, "heff_f64_of_word(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str5, 7, "INT_OF(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewordAs_str6, 1, ")");
Clo g_heff_2ecompile_2eemitc_2ewordAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewordAs_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ewordAs(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RepV: {
    return v_x2_241;
  }
  case TAG_RepFix: {
    V v_w_242 = heff_field(v_x1_240, 0);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_242));
    V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordAs_str0), v_t_243), ((V)&g_heff_2ecompile_2eemitc_2ewordAs_str1));
    return heff_strAppend(heff_strAppend(v_t_244, v_x2_241), ((V)&g_heff_2ecompile_2eemitc_2ewordAs_str2));
  }
  case TAG_RepF64: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordAs_str3), v_x2_241), ((V)&g_heff_2ecompile_2eemitc_2ewordAs_str4));
  }
  case TAG_RepInt: {
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewordAs_str5), v_x2_241), ((V)&g_heff_2ecompile_2eemitc_2ewordAs_str6));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ewordAs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2ewordAs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2epointersGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epointersGo_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2epointersGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_CInteger: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CDouble: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CBool: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CString: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CText: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_COwnedString: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CBytes: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_COwnedBytes: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CPointer: {
      V v_t_245 = heff_field(v_x21_242, 0);
      V v_r_246 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24CPointer = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_247 = (g_list_2eany_24s1419545795x962553976(v_t_245, v_r_246, v_acc_240));
      V v_t_248;
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_245);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x21_242_24CPointer, 2);
        heff_drop(v_t_247);
        v_t_248 = v_acc_240;
      } else {
        heff_drop(v_t_247);
        v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24CPointer, TAG_MkPair, 2, (V[]){v_t_245, v_r_246}), v_acc_240});
      }
      V t_0 = v_t_248;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_CVoid: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2epointersGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epointersGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2estringArgsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estringArgsGo_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estringArgsGo(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_t_242)) {
    case TAG_CInteger: {
      heff_take_n(v_t_242, 0ULL, 1);
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_CDouble: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_CBool: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_CString: {
      v_t_247 = NTAG(TAG_True);
      break;
    }
    case TAG_CText: {
      v_t_247 = NTAG(TAG_True);
      break;
    }
    case TAG_COwnedString: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_CBytes: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_COwnedBytes: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_CPointer: {
      heff_take_n(v_t_242, 0ULL, 2);
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_CVoid: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
      V v_u_249 = (g_heff_2ecompile_2eemitc_2estringArgsGo_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_rest_243, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_247);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estringArgsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estringArgsGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str6, 14, "size_t n = 0; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str7, 14, "size_t n = 0; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str10, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str11, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str12, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str13, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str14, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str15, 21, "const unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str16, 15, "unsigned char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str17, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str18, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultDecl_str19, 5, " c = ");
Clo g_heff_2ecompile_2eemitc_2eresultDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eresultDecl_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eresultDecl(V v_t_240) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_t_240)) {
  case TAG_CInteger: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str0);
    break;
  }
  case TAG_CDouble: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str1);
    break;
  }
  case TAG_CBool: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str2);
    break;
  }
  case TAG_CString: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str3);
    break;
  }
  case TAG_CText: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str4);
    break;
  }
  case TAG_COwnedString: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str5);
    break;
  }
  case TAG_CBytes: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str6);
    break;
  }
  case TAG_COwnedBytes: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str7);
    break;
  }
  case TAG_CPointer: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str8);
    break;
  }
  case TAG_CVoid: {
    v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str9);
    break;
  }
  default: heff_nomatch(v_t_240);
  }
  V v_t_248;
  switch (heff_tag_of(v_t_240)) {
  case TAG_CInteger: {
    V v_t_245 = heff_field(v_t_240, 0);
    v_t_248 = heff_dup(v_t_245);
    break;
  }
  case TAG_CDouble: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str10);
    break;
  }
  case TAG_CBool: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str11);
    break;
  }
  case TAG_CString: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str12);
    break;
  }
  case TAG_CText: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str13);
    break;
  }
  case TAG_COwnedString: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str14);
    break;
  }
  case TAG_CBytes: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str15);
    break;
  }
  case TAG_COwnedBytes: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str16);
    break;
  }
  case TAG_CPointer: {
    V v_t_246 = heff_field(v_t_240, 0);
    v_t_248 = heff_strAppend(heff_dup(v_t_246), ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str17));
    break;
  }
  case TAG_CVoid: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str18);
    break;
  }
  default: heff_nomatch(v_t_240);
  }
  return heff_strAppend(heff_strAppend(v_t_244, v_t_248), ((V)&g_heff_2ecompile_2eemitc_2eresultDecl_str19));
}
V g_heff_2ecompile_2eemitc_2eresultDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eresultDecl(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str1, 11, "  case TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str2, 3, ": {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str3, 2, "!a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str5, 4, " || ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str6, 8, "    if (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str7, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str8, 17, "      heff_fail(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str9, 3, ": `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str10, 43, "`: a string with a NUL in it, given to C\");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str11, 12, "      r = 0;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str12, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str13, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str14, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str15, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str16, 9, "(EINVAL);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str17, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str18, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str19, 10, "      r = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str20, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str21, 9, "(EINVAL);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str22, 10, "    free(a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str23, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str24, 5, "    }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str25, 12, "    } else {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str26, 33, "    V f = heff_dup(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str27, 31, "    return heff_tail(k, 1, &x);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str28, 17, "    heff_drop(p);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str29, 28, "    V x = heff_answer(f, r);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str30, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str31, 33, "    V x = heff_dup(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str32, 31, "    return heff_tail(k, 1, &x);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str33, 17, "    heff_drop(p);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str34, 12, "    (void)r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str35, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str36, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecaseLines_str37, 8, "    V r;");
Clo g_heff_2ecompile_2eemitc_2ecaseLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecaseLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2ecaseLines(V v_md_240, V v_leaf_241, V v_ptrs_242, V v_b_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_b_243, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str0)));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str1), v_t_244), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str2));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2eargLines(MK_INT(0LL), heff_dup(heff_rfield(v_b_243, 2))));
  V v_it_247 = (g_heff_2ecompile_2eemitc_2estringArgsGo(MK_INT(0LL), heff_dup(heff_rfield(v_b_243, 2))));
  V v_t_2438;
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nil: {
    V v_t_248 = (g_heff_2ecompile_2eemitc_2eresultLines(v_md_240, v_leaf_241, v_ptrs_242, heff_dup(v_b_243)));
    v_t_2438 = ({ V b_0 = MK_INT(2LL); V a_1 = v_t_248; V r_ = (g_list_2emap_24s1418269708x2034621695(b_0, a_1)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    V v_x2_2411 = (g_list_2emap_24s1218298322x1569510752(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str3), heff_dup(v_it_247)));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str5); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str6), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str7));
    V v_md_2416 = heff_dup(v_md_240);
    V v_leaf_2417 = heff_dup(v_leaf_241);
    V v_b_2418 = heff_dup(v_b_243);
    V v_result_2419 = heff_take_field(v_b_2418, 3);
    V v_tag_2420 = heff_get_n(v_b_2418, 0, 5);
    V v_t_2421 = v_result_2419;
    V v_t_2431;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Gives: {
      heff_take_n(v_t_2421, 0ULL, 1);
      heff_drop(v_leaf_2417);
      V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str8), v_md_2416), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str9));
      V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, v_tag_2420), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str10));
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str11), NTAG(TAG_Nil)});
      v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2425});
      break;
    }
    case TAG_GivesOrErrno: {
      heff_take_n(v_t_2421, 0ULL, 1);
      heff_drop(v_md_2416);
      heff_drop(v_tag_2420);
      V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str12), v_leaf_2417), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str13));
      V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str14), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str15)));
      v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str16)), NTAG(TAG_Nil)});
      break;
    }
    case TAG_DoneOrErrno: {
      heff_drop(v_md_2416);
      heff_drop(v_tag_2420);
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str17), v_leaf_2417), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str18));
      V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str19), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str20)));
      v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str21)), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_t_2432 = (g_heff_2ecompile_2eemitc_2eresultLines(v_md_240, v_leaf_241, v_ptrs_242, heff_dup(v_b_243)));
    V v_t_2433 = (g_list_2emap_24s693155583x821663253(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str22), ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str23), v_it_247));
    V v_ys_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str24), v_t_2433});
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2432, v_ys_2434));
    V v_ys_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str25), v_t_2435});
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2431, v_ys_2436));
    v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2437});
    break;
  }
  default: heff_nomatch(v_it_247);
  }
  V v_b_2439 = v_b_243;
  V v_answered_2440 = heff_take_field(v_b_2439, 4);
  V v_args_2441 = heff_get_n(v_b_2439, 2, 5);
  V v_t_2442 = v_answered_2440;
  V v_t_2451;
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    V v_t_2443 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2441; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2441); r_; });
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str26), heff_intShow(v_t_2443));
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str27), NTAG(TAG_Nil)});
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str28), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str29), v_t_2445})});
    v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str30)), v_t_2446});
  } else {
    heff_drop(v_t_2442);
    V v_t_2447 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2441; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2441); r_; });
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str31), heff_intShow(v_t_2447));
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str32), NTAG(TAG_Nil)});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str34), v_t_2449})});
    v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str35)), v_t_2450});
  }
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str36), NTAG(TAG_Nil)});
  V v_t_2453 = (g_prelude_2e_2b_2b(v_t_2451, v_t_2452));
  V v_ys_2454 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2453));
  V v_t_2455 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecaseLines_str37), v_ys_2454})));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2455});
}
V g_heff_2ecompile_2eemitc_2ecaseLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ecaseLines(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eassertLine_str0, 55, "_Static_assert(__builtin_types_compatible_p(__typeof__(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eassertLine_str1, 3, "), ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eassertLine_str2, 4, "), \"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eassertLine_str3, 12, " describes `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eassertLine_str4, 6, "` as `");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eassertLine_str5, 21, "`, which it is not\");");
Clo g_heff_2ecompile_2eemitc_2eassertLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eassertLine_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eassertLine(V v_md_240, V v_b_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2eemitc_2efunTypeName(heff_dup(v_b_241)));
  V v_t_243 = (g_heff_2ecompile_2eemitc_2efunTypeName(heff_dup(v_b_241)));
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eassertLine_str0), heff_dup(heff_rfield(v_b_241, 1)));
  V v_t_245 = heff_strAppend(heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemitc_2eassertLine_str1)), v_t_242);
  V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eassertLine_str2)), v_md_240);
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2eassertLine_str3)), heff_get_n(v_b_241, 1, 5));
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eassertLine_str4)), v_t_243);
  return heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eassertLine_str5));
}
V g_heff_2ecompile_2eemitc_2eassertLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eassertLine(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str0, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str2, 16, "static uint32_t ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str3, 5, "errno");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str4, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str5, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str6, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str7, 4, "left");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str8, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str9, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str10, 34, "(int err) { V e = heff_errno(err, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str11, 5, "errno");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str12, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str13, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str14, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str15, 5, "right");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str16, 44, "(V x) { return heff_tag(TAG_Right, 1, &x); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str17, 38, "); return heff_tag(TAG_Left, 1, &e); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str18, 42, "[3] = { LBL_code, LBL_name, LBL_message };");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str19, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str21, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str22, 5, "owned");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str23, 77, "(char *c) { V s = heff_str_bytes(c, (int64_t)strlen(c)); free(c); return s; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str24, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str25, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str26, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str27, 11, "owned_bytes");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str28, 87, "(unsigned char *c, size_t n) { V s = heff_bytes_in(c, (int64_t)n); free(c); return s; }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ehelperLines_str29, 7, "let_go_");
Clo g_heff_2ecompile_2eemitc_2ehelperLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehelperLines_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2ehelperLines(V v_gl_240, V v_ptrs_241) {
top: ;
  V v_ops_242 = heff_take_field(v_gl_240, 3);
  V v_leaf_243 = heff_get_n(v_gl_240, 1, 5);
  V v_t_244 = (g_list_2eany_24s1022483754x1154500907(v_ops_242));
  V v_t_2415;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str0), heff_dup(v_leaf_243)), ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str1));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str3)));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str4), heff_dup(v_leaf_243)), ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str5));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str6), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str7)));
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str8), heff_dup(v_leaf_243)), ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str9));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str10)), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str11)));
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str12), heff_dup(v_leaf_243)), ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str13));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str14), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str15)));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str16)), NTAG(TAG_Nil)});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str17)), v_t_2413});
    v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str18)), v_t_2414});
  } else {
    heff_drop(v_t_244);
    v_t_2415 = NTAG(TAG_Nil);
  }
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ops_242)));
  V v_t_2417 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_2416));
  V v_t_2418 = ({ V a_0 = v_t_2417; V r_ = (g_list_2eany_24s1362258228x1848434975(a_0)); heff_drop(v_t_2417); r_; });
  V v_t_2421;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str19), heff_dup(v_leaf_243)), ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str20));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str21), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str22)));
    v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str23)), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2418);
    v_t_2421 = NTAG(TAG_Nil);
  }
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ops_242));
  V v_t_2423 = (g_list_2efoldl_24s1520027297x1040032870(NTAG(TAG_Nil), v_t_2422));
  V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_list_2eany_24s1419619328x1805745269(a_0)); heff_drop(v_t_2423); r_; });
  V v_t_2427;
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_t_2424);
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str24), heff_dup(v_leaf_243)), ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str25));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str26), heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str27)));
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str28)), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_2424);
    v_t_2427 = NTAG(TAG_Nil);
  }
  V v_t_2428 = (g_heff_2ecompile_2eemitc_2epointerFnLines(v_leaf_243, ((V)&g_heff_2ecompile_2eemitc_2ehelperLines_str29), MK_INT(0LL), v_ptrs_241));
  V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2428));
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2429));
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_2415, v_t_2430);
}
V g_heff_2ecompile_2eemitc_2ehelperLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ehelperLines(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_240, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_seen_240;
        V t_1 = v_xs_244;
        V t_2 = v_d_242;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_240, heff_dup(v_x_243), NTAG(TAG_MkUnit)));
        V v_cell_2410 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
        V v_u_2411 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2410);
        V t_0 = v_t_249;
        V t_1 = v_xs_244;
        V t_2 = v_u_2411;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elastDotGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_k_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_243;
    if ((heff_unbox_word(heff_strByteAt_lent(v_k_240, v_i_241, 0)) == ((int64_t)46ULL))) {
      heff_drop(v_at_242);
      v_t_243 = heff_dup(v_i_241);
    } else {
      v_t_243 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = v_t_243;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2elastDotGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str1, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str5, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str6, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str7, 1, " ");
V g_heff_2ecompile_2eemitc_2enumbersOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2enumbersOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbersOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enumbersOf(V v_ce_240, V v_x2_241) {
top: ;
  V v_tags_242 = heff_take_field(v_ce_240, 0);
  V v_lbls_243 = heff_get_n(v_ce_240, 1, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_ts_244 = heff_field(v_x2_241, 0);
    V v_ls_245 = heff_field(v_x2_241, 1);
    V v_m_246 = (g_list_2efoldl_24s1614667250x430274379(heff_dup(g_std_2eordmap_2eempty_get()), v_ts_244));
    V v_t_247 = ({ V a_0 = v_m_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_246); r_; });
    V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
    V v_t_249 = (g_list_2ekeepIf_24s478006518x1380334353(v_t_248));
    V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2enumbersOf_lam0, 1, 1, (V[]){v_tags_242}), v_t_249));
    V v_m_2419 = (g_list_2efoldl_24s1614667250x430274379(heff_dup(g_std_2eordmap_2eempty_get()), v_ls_245));
    V v_t_2420 = ({ V a_0 = v_m_2419; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2419); r_; });
    V v_t_2421 = (g_list_2emap_24s1937570095x2110149801(v_t_2420));
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2enumbersOf_lam1, 1, 1, (V[]){v_lbls_243}), v_t_2421));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2418, v_t_2430);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbersOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2enumbersOf_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  V v_tags_242 = heff_env(self)[0];
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_2410, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str0)));
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = ({ V a_0 = v_tags_242; V a_1 = v_t_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_tags_242); heff_drop(v_t_2410); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    V v_t_2416;
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2414;
      v_t_2416 = v_x_2415;
    } else {
      heff_drop(v_field_2414);
      v_t_2416 = MK_INT(0LL);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str2), v_t_2411));
    return heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str3)), heff_intShow(v_t_2416));
  }
}
V g_heff_2ecompile_2eemitc_2enumbersOf_lam1(V self, V *args) {
  V v_l_2422 = args[0];
  V v_lbls_243 = heff_env(self)[0];
  V v_t_2423 = (g_heff_2ecompile_2eemitc_2emangleW(v_l_2422, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str4)));
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = ({ V a_0 = v_lbls_243; V a_1 = v_l_2422; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_lbls_243); heff_drop(v_l_2422); r_; });
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    V v_t_2428;
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2426;
      v_t_2428 = v_x_2427;
    } else {
      heff_drop(v_field_2426);
      v_t_2428 = MK_INT(0LL);
    }
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str5), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str6), v_t_2423));
    return heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str7)), heff_intShow(v_t_2428));
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eusedBy_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eusedBy_str1, 2, "g_");
V g_heff_2ecompile_2eemitc_2eusedBy_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eusedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eusedBy_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eusedBy(V v_m_240, V v_ps_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_241));
  V v_xs_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eusedBy_lam0, 2, 1, (V[]){heff_dup(v_m_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_m_2416 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2415; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2415); r_; });
  V v_t_2417 = ({ V a_0 = v_m_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2416); r_; });
  return (g_list_2emap_24s1937570095x2110149801(v_t_2417));
}
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eusedBy(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eusedBy_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_m_240 = heff_env(self)[0];
  V v_t_247;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_t_247 = heff_get_n(v_d_245, 0, 3);
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_248 = ({ V a_0 = v_t_247; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eusedBy_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  V v_o_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eusedBy_str1), v_t_248);
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V a_0 = v_m_240; V a_1 = v_o_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_o_249); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    V v_t_2414;
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2412;
      v_t_2414 = v_x_2413;
    } else {
      heff_drop(v_field_2412);
      v_t_2414 = NTAG(TAG_Nil);
    }
    return (g_prelude_2e_2b_2b(v_t_2414, v_acc_243));
  }
}
Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeyHashGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ekeyHashGo(V v_k_240, V v_box_24i_241, V v_box_24h_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_h_242 = heff_unbox_word(v_box_24h_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_k_240, 0)) <= v_i_241)) {
    return heff_box_word(v_h_242);
  } else {
    int64_t v_t_243 = ((v_h_242 * ((int64_t)31ULL)) + heff_unbox_word(heff_strByteAt_lent(v_k_240, heff_box_word(v_i_241), 2)));
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = heff_word_mod(v_t_243, ((int64_t)1000000007ULL));
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_h_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2ekeyHashGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ekeptOf(V v_v_240, V v_e_241, V v_s_242) {
top: ;
  V v_strs_243 = heff_take_field(v_s_242, 5);
  V v_protos_244 = heff_take_field(v_s_242, 3);
  V v_lams_245 = heff_take_field(v_s_242, 2);
  V v_shapes_246 = heff_take_field(v_s_242, 6);
  V v_prims_247 = heff_get_n(v_s_242, 7, 8);
  V v_protos_248 = heff_take_field(v_e_241, 0);
  V v_code_249 = heff_get_n(v_e_241, 1, 2);
  V v_t_2410 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_strs_243));
  V v_t_2411 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_protos_244));
  V v_t_2412 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_lams_245));
  V v_t_2413 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_shapes_246));
  V v_t_2414 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_prims_247));
  return heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_v_240, v_protos_248, v_code_249, v_t_2410, v_t_2411, v_t_2412, v_t_2413, v_t_2414});
}
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ekeptOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str1, 35, "static V heff_entry(void) { return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str4, 9, "_get(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str6, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str7, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str9, 1, ".");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str10, 9, "custodian");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str13, 6, "entry/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str14, 10, "entry-due/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str16, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecompileProgramC_str17, 0, "");
V g_heff_2ecompile_2eemitc_2ecompileProgramC_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecompileProgramC_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2ecompileProgramC(V v_fuel_240, V v_runtime_241, V v_provs_242, V v_g_243, V v_key_244, V v_eff_245) {
top: ;
  V v_runtime_246 = v_runtime_241;
  V v_provs_247 = heff_dup(v_provs_242);
  V v_t_248 = ({ V a_0 = v_provs_242; V r_ = (g_list_2eany_24s762674996x1009180162(a_0)); heff_drop(v_provs_242); r_; });
  V v_t_249;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_248);
    v_t_249 = NTAG(TAG_Nil);
  }
  V v_ending_2416 = heff_rec_n(2, shape_prefix__end, (V[]){v_t_249, heff_clo_n(g_heff_2ecompile_2eemitc_2ecompileProgramC_lam0, 1, 1, (V[]){heff_dup(v_eff_245)})});
  V v_t_2417 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_245));
  V v_ms_2418 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str6); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str7); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str8); V a_5 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str9); V a_6 = v_t_2417; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_2419 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str10); V a_1 = v_ms_2418; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); heff_drop(v_ms_2418); r_; });
  V v_due_2420;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    v_due_2420 = NTAG(TAG_Reading);
  } else {
    heff_drop(v_t_2419);
    v_due_2420 = NTAG(TAG_NoCustody);
  }
  V v_w_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_eff_245)});
  V v_g_2422 = v_g_243;
  V v_key_2423 = v_key_244;
  V v_vers_2424 = heff_dup(g_std_2eordmap_2eempty_get());
  V v_due_2425 = heff_dup(v_due_2420);
  V v_w_2426 = heff_dup(v_w_2421);
  HeffT2 v_t_2427 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_vers_2424, v_key_2423));
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    V v_t_2435;
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_v_2430 = v_field_2429;
      if (heff_strEq_c_lent(v_v_2430, ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str11), 2)) {
        heff_drop(v_due_2420);
        heff_drop_tag(v_w_2421, 1);
        heff_drop(v_v_2430);
        v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str12);
      } else {
        V v_t_2431;
        switch (heff_tag_of(v_due_2420)) {
        case TAG_NoCustody: {
          v_t_2431 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str13);
          break;
        }
        case TAG_Reading: {
          v_t_2431 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str14);
          break;
        }
        default: heff_nomatch(v_due_2420);
        }
        V v_t_2434;
        switch (heff_tag_of(v_w_2421)) {
        case TAG_Nothing: {
          v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str15);
          break;
        }
        case TAG_Just: {
          V v_w_2432 = heff_field(v_w_2421, 0);
          heff_take_n(v_w_2421, 1ULL, 1);
          V v_t_2433 = ({ V a_0 = v_w_2432; V r_ = (g_heff_2ecompile_2elower_2eshapeSaid(a_0)); heff_drop(v_w_2432); r_; });
          v_t_2434 = heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str16));
          break;
        }
        default: heff_nomatch(v_w_2421);
        }
        v_t_2435 = heff_strAppend(heff_strAppend(v_t_2431, v_t_2434), v_v_2430);
      }
    } else {
      heff_drop(v_due_2420);
      heff_drop_tag(v_w_2421, 1);
      heff_drop(v_field_2429);
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str17);
    }
    V v_vers_2436 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(v_vers_2424), heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), v_t_2435));
    V v_key_2437 = v_key_2423;
    V v_t_2444 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemitc_2ecompileProgramC_lam1, 2, 1, (V[]){heff_dup(v_g_2422)}), NTAG(TAG_Nil), heff_rfield(v_g_2422, 0)));
    V v_t_2445 = heff_rec_n(3, shape_pieces__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
    V v_acc_2446 = ({ V a_0 = v_g_2422; V a_1 = v_vers_2424; V a_2 = v_t_2445; V a_3 = v_t_2444; V r_ = (g_list_2efoldl_24s1484108573x1404267297(a_0, a_1, a_2, a_3)); heff_drop(v_vers_2424); heff_drop(v_t_2444); r_; });
    V v_errors_2447 = heff_take_field(v_acc_2446, 1);
    V v_supply_2448 = heff_take_field(v_acc_2446, 2);
    V v_pieces_2449 = heff_get_n(v_acc_2446, 0, 3);
    V v_errors_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_errors_2447));
    V v_t_2453;
    switch (heff_tag_of(v_w_2426)) {
    case TAG_Nothing: {
      v_t_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_w_2451 = heff_dup(heff_field(v_w_2426, 0));
      V v_t_2452 = (g_heff_2ecompile_2elower_2edispatchDefs(v_w_2451, MK_INT(0LL), MK_INT(0LL)));
      v_t_2453 = (g_list_2emap_24s509077117x607152875(v_t_2452));
      break;
    }
    default: heff_nomatch(v_w_2426);
    }
    V v_t_2454 = (g_heff_2ecompile_2elower_2eentryPieces_24s1048628892x614930584(v_due_2425, v_w_2426, v_vers_2436, v_key_2437, heff_dup(v_supply_2448)));
    V v_xs_2455 = (g_heff_2ecompile_2elower_2erevOnto(v_t_2454, v_pieces_2449));
    V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2455));
    V v_t_2457 = (g_prelude_2e_2b_2b(v_t_2453, v_t_2456));
    V v_ps_2458 = (g_heff_2ecompile_2elower_2ereachedPieces(v_t_2457));
    V v_errors_2459 = v_errors_2450;
    V v_vers_2460 = v_vers_2436;
    V v_n_2461 = heff_intAdd(v_supply_2448, MK_INT(16LL));
    V v_ps_2462 = heff_dup(v_ps_2458);
    V v_items_2463 = (g_list_2emap_24s510639937x1058700299(v_ps_2458));
    V v_sg_2464 = ({ V a_0 = heff_dup(g_heff_2ecompile_2esimplify_2esimplifyProgram_24rec0_get()); V a_1 = v_items_2463; V r_ = (g_list_2efoldl_24s2070597502x591087275(a_0, a_1)); heff_drop(v_items_2463); r_; });
    V v_t_2465 = (g_heff_2ecompile_2elower_2eunitVers(v_vers_2460, v_ps_2462));
    V v_t_2466 = (g_list_2emap_24s510639937x1058700299(heff_dup(v_ps_2462)));
    V v_si_2467 = (g_heff_2ecompile_2esimplify_2esimplifyItems(v_n_2461, heff_dup(v_sg_2464), v_t_2465, heff_dup(g_std_2eordmap_2eempty_get()), v_t_2466));
    V v_t_2468 = (g_list_2efoldl_24s1499934538x170225690(heff_dup(g_std_2eordmap_2eempty_get()), heff_rfield(v_si_2467, 2)));
    V v_t_2469 = (g_heff_2ecompile_2elower_2egroupGo(v_ps_2462));
    V v_t_2470 = ({ V a_0 = v_vers_2460; V a_1 = v_sg_2464; V a_2 = v_t_2468; V a_3 = v_t_2469; V r_ = (g_list_2emap_24s1985010810x1780722131(a_0, a_1, a_2, a_3)); heff_drop(v_vers_2460); heff_drop(v_t_2468); r_; });
    V v_t_2471 = (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2470));
    V v_t_2472 = heff_rec_n(4, shape_simplified__errors__groups__copies, (V[]){heff_dup(v_si_2467), v_errors_2459, v_t_2471, heff_get_n(v_si_2467, 3, 4)});
    HeffT3 v_t_2473 = ({ V a_0 = v_eff_245; V a_1 = v_fuel_240; V a_2 = v_t_2472; HeffT3 r_ = (g_heff_2ecompile_2elower_2ecKeptOf_24s358697340x1392296937_24cpr(a_0, a_1, a_2)); heff_drop(v_eff_245); r_; });
    {
      V v_field_2474 = v_t_2473.f[0];
      heff_drop(v_t_2473.f[1]);
      heff_drop(v_t_2473.f[2]);
      V v_l_2477 = v_field_2474;
      V v_defs_2478 = heff_take_field(v_l_2477, 0);
      V v_facts_2479 = heff_take_field(v_l_2477, 1);
      V v_errors_2480 = heff_get_n(v_l_2477, 2, 3);
      V v_defs_2481 = v_defs_2478;
      V v_t_2482 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), heff_dup(v_defs_2481)));
      V v_t_2483 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_names_2484 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2483, v_t_2482));
      V v_t_2485 = ({ V a_0 = heff_dup(v_provs_247); V a_1 = v_facts_2479; V a_2 = v_names_2484; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_2484); r_; });
      V v_t_2486 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_246, v_provs_247, v_ending_2416, v_defs_2481, v_t_2485));
      return heff_rec_n(2, shape_source__errors, (V[]){v_t_2486, v_errors_2480});
    }
  }
}
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecompileProgramC(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2ecompileProgramC_lam0(V self, V *args) {
  V v_ce_2410 = args[0];
  V v_eff_245 = heff_env(self)[0];
  heff_drop(v_ce_2410);
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eperformCode(v_eff_245));
  V v_t_2412 = ({ V b_0 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str2), v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str3), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str4)), v_t_2414});
  return (g_prelude_2e_2b_2b(v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2ecompileProgramC_str5), v_t_2415})));
}
V g_heff_2ecompile_2eemitc_2ecompileProgramC_lam1(V self, V *args) {
  V v_acc_2438 = args[0];
  V v_k_2439 = args[1];
  V v_g_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2440 = ({ V b_0 = heff_get_n(v_g_2422, 1, 8); V a_1 = v_k_2439; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2442 = v_t_2440.f[1];
    int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
    if ((v_tag_2441 == ((int64_t)0ULL))) {
      V v_e_2443 = v_field_2442;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2439, v_e_2443}), v_acc_2438});
    } else {
      heff_drop(v_k_2439);
      heff_drop(v_field_2442);
      return v_acc_2438;
    }
  }
}