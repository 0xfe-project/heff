// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_errors 652506774
#define LBL_groups 709681407
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lowered 588863906
#define LBL_lprotos 613175609
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_simplified 1686448252
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_ver 326173
static uint32_t shape_lowered__groups__copies[] = {LBL_lowered, LBL_groups, LBL_copies};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_heff_2ecompile_2eemitc_2efloat64U(V, V);
V g_heff_2ecompile_2eemitc_2efloat64U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat64U_clo;
V g_heff_2ecompile_2eemitc_2efloatSymbols_get(void);
V g_heff_2ecompile_2eemitc_2ehashBelow(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashBelow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashBelow_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2eisAlnum(V);
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2ekeptParts(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptParts_clo;
V g_heff_2ecompile_2eemitc_2ekeyHashGo(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo;
V g_heff_2ecompile_2eemitc_2elastDotGo(V, V, V);
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo;
V g_heff_2ecompile_2eemitc_2elibmNames_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758(V, V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_clo;
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
V g_heff_2ecompile_2eemitc_2evalDef(V, V, V);
V g_heff_2ecompile_2eemitc_2evalDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2evalDef_clo;
V g_heff_2ecompile_2elower_2ecFused(V, V, V);
V g_heff_2ecompile_2elower_2ecFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecFused_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
V g_heff_2ecompile_2elower_2elowerProgramKept(V, V, V, V);
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_strEq_get(void);
Clo g_heff_2ecompile_2eemitc_2eisAlnum_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eisAlnum_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eisAlnum(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eemitc_2eisAlnum_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eisAlnum(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ehashedGo_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ehashedGo(V v_base_240, V v_m_241, V v_x3_242, V v_names_243, V v_taken_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_base_240);
    heff_drop(v_m_241);
    heff_drop(v_taken_244);
    return v_names_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_xs_246 = heff_field(v_x3_242, 1);
    V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_245), v_names_243));
    V v_t_249;
    switch (heff_tag_of(v_x3_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_247, 0ULL, 1);
      v_t_249 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_247);
    }
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_xs_246;
      V t_3 = v_names_243;
      V t_4 = v_taken_244;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      v_names_243 = t_3;
      v_taken_244 = t_4;
      goto top;
    } else {
      heff_drop(v_t_249);
      V v_t_2410 = (g_heff_2ecompile_2eemitc_2ehashBelow(heff_dup(v_x_245), heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
      V v_t_2411 = (g_heff_2ecompile_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2410, v_taken_244));
      V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_245), v_t_2411, v_names_243));
      V v_t_2413 = (g_heff_2ecompile_2eemitc_2ehashBelow(heff_dup(v_x_245), heff_dup(v_m_241), MK_INT(0LL), MK_INT(7LL)));
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2eslotFrom(heff_dup(v_base_240), heff_dup(v_m_241), v_t_2413, v_taken_244));
      V v_t_2415 = (g_map_2einsert_24s1689409319x1710080871(v_t_2414, NTAG(TAG_MkUnit), v_taken_244));
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_xs_246;
      V t_3 = v_t_2412;
      V t_4 = v_t_2415;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      v_names_243 = t_3;
      v_taken_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ehashedGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str0, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str1, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str2, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str3, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str4, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str5, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str6, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str7, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str8, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str9, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str10, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str11, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str12, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloatSymbols_str13, 1, "+");

static V g_heff_2ecompile_2eemitc_2efloatSymbols_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2efloatSymbols_st;
static V g_heff_2ecompile_2eemitc_2efloatSymbols_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str0), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str2), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str4), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str5)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str6), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str7)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str8), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str9)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str10), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str11)}), v_t_244});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str12), ((V)&g_heff_2ecompile_2eemitc_2efloatSymbols_str13)}), v_t_245});
}
V g_heff_2ecompile_2eemitc_2efloatSymbols_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2efloatSymbols_st)) return g_heff_2ecompile_2eemitc_2efloatSymbols_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2efloatSymbols_val, &g_heff_2ecompile_2eemitc_2efloatSymbols_st, g_heff_2ecompile_2eemitc_2efloatSymbols_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str0, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str1, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str2, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str3, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str5, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str10, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str13, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str15, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str16, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str18, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str19, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str21, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str22, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat64U_str23, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efloat64U_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efloat64U_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efloat64U(V v_p_240, V v_vs_241) {
top: ;
  V v_t_244 = heff_bool((heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str0), 2) || (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str1), 2) || heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str2), 2))));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_x2_245 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = v_p_240; V b_2 = heff_dup(g_heff_2ecompile_2eemitc_2efloatSymbols_get()); V r_ = (g_list_2elookupBy(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_248;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_dup(heff_field(v_vs_241, 0));
      v_t_248 = v_x_246;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str4);
      break;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_t_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_x1_2411 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x1_2411, 0);
      heff_take_n(v_x1_2411, 1ULL, 2);
      v_t_2414 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x1_2411);
    }
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str6), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str7)));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str8), heff_strAppend(v_t_2410, v_t_2415));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str9), heff_strAppend(v_t_248, v_t_2416));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str10), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str11)));
  } else {
    heff_drop(v_t_244);
    V v_x2_2418 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = heff_dup(v_p_240); V b_2 = heff_dup(g_heff_2ecompile_2eemitc_2efloatSymbols_get()); V r_ = (g_list_2elookupBy(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2420;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nothing: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str12);
      break;
    }
    case TAG_Just: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      heff_take_n(v_x2_2418, 1ULL, 1);
      v_t_2420 = v_x_2419;
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_x_2421 = heff_strLength(v_t_2420);
    if (heff_intLt_c(MK_INT(0LL), v_x_2421)) {
      V v_x2_2423 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = v_p_240; V b_2 = heff_dup(g_heff_2ecompile_2eemitc_2efloatSymbols_get()); V r_ = (g_list_2elookupBy(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2426;
      switch (heff_tag_of(v_vs_241)) {
      case TAG_Nil: {
        v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2424 = heff_dup(heff_field(v_vs_241, 0));
        v_t_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_vs_241);
      }
      V v_t_2428;
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_Nothing: {
        v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str14);
        break;
      }
      case TAG_Just: {
        V v_x_2427 = heff_field(v_x2_2423, 0);
        heff_take_n(v_x2_2423, 1ULL, 1);
        v_t_2428 = v_x_2427;
        break;
      }
      default: heff_nomatch(v_x2_2423);
      }
      V v_x1_2429 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
      V v_t_2432;
      switch (heff_tag_of(v_x1_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 2);
        v_t_2432 = v_x_2430;
        break;
      }
      default: heff_nomatch(v_x1_2429);
      }
      V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str16), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str17)));
      V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str18), heff_strAppend(v_t_2428, v_t_2433));
      return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str19), heff_strAppend(v_t_2426, v_t_2434));
    } else {
      V v_x2_2435 = ({ V a_0 = heff_dup(g_strEq_get()); V a_1 = heff_dup(v_p_240); V b_2 = heff_dup(g_heff_2ecompile_2eemitc_2elibmNames_get()); V r_ = (g_list_2elookupBy(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2437;
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nothing: {
        v_t_2437 = v_p_240;
        break;
      }
      case TAG_Just: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        heff_take_n(v_x2_2435, 1ULL, 1);
        heff_drop(v_p_240);
        v_t_2437 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      V v_t_2440;
      switch (heff_tag_of(v_vs_241)) {
      case TAG_Nil: {
        v_t_2440 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2438 = heff_field(v_vs_241, 0);
        V v_xs_2439 = heff_field(v_vs_241, 1);
        heff_take_n(v_vs_241, 3ULL, 2);
        v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str21); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
        break;
      }
      default: heff_nomatch(v_vs_241);
      }
      V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat64U_str22), heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2eemitc_2efloat64U_str23)));
      return heff_strAppend(v_t_2437, v_t_2441);
    }
  }
}
V g_heff_2ecompile_2eemitc_2efloat64U_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efloat64U(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return ((V)&g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_m_246 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_x_244; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_x_244); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam1, 1, 4, (V[]){v_m_246, v_lit_240, v_lit_241, v_xs_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_243});
}
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_xs_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758(v_lit_240, v_lit_241, v_xs_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str2, 11, "_get(void);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str3, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str5, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str6, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str8, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str9, 4, "_st;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str12, 13, "_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str13, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str14, 17, "static HEFF_ONCE ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str15, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str16, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str18, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str19, 12, "_get(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str22, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str23, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str24, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str25, 13, "_st)) return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str27, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str29, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str30, 7, "_init);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str31, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str32, 5, "_st, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str33, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str34, 7, "_val, &");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str35, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str36, 22, "  return heff_global(&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str37, 16, "  if (HEFF_DONE(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str38, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str39, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_str40, 0, "");
V g_heff_2ecompile_2eemitc_2evalDef_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2evalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2evalDef_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2evalDef(V v_key_240, V v_body_241, V v_rs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_242));
  V v_m_244 = heff_tr(heff_call(heff_get_n(v_t_243, 1, 3), 1, (V[]){v_body_241}));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2evalDef_lam0, 1, 2, (V[]){v_m_244, v_key_240});
}
V g_heff_2ecompile_2eemitc_2evalDef_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2evalDef(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2evalDef_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str0)));
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str1), v_t_249), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str2));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str3), v_t_2410), NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str4)));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str5), v_t_2412), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str6));
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str7)));
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str8), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str9));
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str10)));
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str11), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str12));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str13), v_t_2417), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str14), v_t_2415), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str15), v_t_2413), v_t_2419});
    V v_t_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2evalDef_str16), v_x_247));
    V v_t_2422 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str17)));
    V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str18), v_t_2422), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str19));
    V v_t_2424 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str20)));
    V v_t_2425 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str21)));
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str22), v_t_2425), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str23));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str24), v_t_2424), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str25), v_t_2426));
    V v_t_2428 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str26)));
    V v_t_2429 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_key_240), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str27)));
    V v_t_2430 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str28)));
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str29), v_t_2430), ((V)&g_heff_2ecompile_2eemitc_2evalDef_str30));
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str31), v_t_2429), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str32), v_t_2431));
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str33), v_t_2428), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str34), v_t_2432));
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_str35), NTAG(TAG_Nil)});
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str36), v_t_2433), v_t_2434});
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str37), v_t_2427), v_t_2435});
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_str38), v_t_2423), v_t_2436});
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_str39), v_t_2437})));
    V v_t_2439 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_str40), v_t_2420}), v_t_2438));
    V v_x_2440 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2411, v_t_2439});
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2440, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
Clo g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_seen_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V v_t_248 = (g_map_2einsert_24s1341440536x470972936(v_x_243, NTAG(TAG_MkUnit), v_seen_240));
      V t_0 = v_t_248;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eonceInOrder_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eonceInOrder_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elastDotGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_k_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_245;
    if (heff_intEq_c(heff_strByteAt_lent(v_k_240, v_i_241, 0), MK_INT(46LL))) {
      heff_drop(v_at_242);
      v_t_245 = heff_dup(v_i_241);
    } else {
      v_t_245 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2elastDotGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elastDotGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str3, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str5, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str6, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2enumbersOf_str7, 8, "#define ");
V g_heff_2ecompile_2eemitc_2enumbersOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2enumbersOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbersOf_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2enumbersOf(V v_ce_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_ts_242 = heff_field(v_x2_241, 0);
    V v_ls_243 = heff_field(v_x2_241, 1);
    V v_m_244 = (g_list_2efoldl_24s657006386x1833506039(heff_dup(g_map_2eempty_get()), v_ts_242));
    V v_t_245 = ({ V a_0 = v_m_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_244); r_; });
    V v_t_246 = (g_list_2emap_24s1937570095x2110149801(v_t_245));
    V v_t_247 = (g_list_2efilter_24s1967523567x64647275(v_t_246));
    V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2enumbersOf_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), v_t_247));
    V v_m_2416 = (g_list_2efoldl_24s657006386x1833506039(heff_dup(g_map_2eempty_get()), v_ls_243));
    V v_t_2417 = ({ V a_0 = v_m_2416; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2416); r_; });
    V v_t_2418 = (g_list_2emap_24s1937570095x2110149801(v_t_2417));
    V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemitc_2enumbersOf_lam1, 1, 1, (V[]){v_ce_240}), v_t_2418));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2415, v_t_2426);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbersOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2enumbersOf_lam0(V self, V *args) {
  V v_t_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_t_248), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str0)));
  V v_x2_2410 = ({ V a_0 = v_t_248; V b_1 = heff_get_n(v_ce_240, 0, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str1), heff_intShow(v_t_2412));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str2), v_t_249), v_t_2413);
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str3), v_t_2414);
}
V g_heff_2ecompile_2eemitc_2enumbersOf_lam1(V self, V *args) {
  V v_l_2419 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(v_l_2419), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str4)));
  V v_x2_2421 = ({ V a_0 = v_l_2419; V b_1 = heff_get_n(v_ce_240, 1, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2423;
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nothing: {
    v_t_2423 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    heff_take_n(v_x2_2421, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x2_2421);
  }
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str5), heff_intShow(v_t_2423));
  V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str6), v_t_2420), v_t_2424);
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2enumbersOf_str7), v_t_2425);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eusedBy_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eusedBy_str1, 2, "g_");
V g_heff_2ecompile_2eemitc_2eusedBy_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eusedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eusedBy_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eusedBy(V v_m_240, V v_ps_241) {
top: ;
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_241));
  V v_xs_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2eusedBy_lam0, 2, 1, (V[]){heff_dup(v_m_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_m_2414 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2413; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2413); r_; });
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2414); r_; });
  return (g_list_2emap_24s1937570095x2110149801(v_t_2415));
}
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eusedBy(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eusedBy_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 2);
    v_t_247 = heff_get_n(v_d_245, 0, 3);
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_247, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eusedBy_str0)));
  V v_o_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eusedBy_str1), v_t_248);
  V v_x2_2410 = ({ V a_0 = v_o_249; V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return (g_prelude_2e_2b_2b(v_t_2412, v_acc_243));
}
Clo g_heff_2ecompile_2eemitc_2ekeyHashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeyHashGo_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ekeyHashGo(V v_k_240, V v_i_241, V v_h_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_k_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_h_242;
  } else {
    V v_t_244 = heff_intAdd(heff_intMul(v_h_242, MK_INT(31LL)), heff_strByteAt_lent(v_k_240, v_i_241, 0));
    V t_0 = v_k_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_intMod(v_t_244, MK_INT(1000000007LL));
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_h_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemitc_2ekeyHashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ekeyHashGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ekeptOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ekeptOf(V v_v_240, V v_e_241, V v_s_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_take_field(v_s_242, 5)));
  V v_t_244 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_take_field(v_s_242, 3)));
  V v_t_245 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_take_field(v_s_242, 2)));
  V v_t_246 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_take_field(v_s_242, 6)));
  V v_t_247 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), heff_get_n(v_s_242, 7, 8)));
  return heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_v_240, heff_dup(heff_rfield(v_e_241, 0)), heff_get_n(v_e_241, 1, 2), v_t_243, v_t_244, v_t_245, v_t_246, v_t_247});
}
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ekeptOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry, 8, 0};

V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V v_runtime_240, V v_provs_241, V v_g_242, V v_key_243, V v_eff_244, V v_vers_245, V v_ks_246, V v_kept_247) {
top: ;
  V v_sk_248 = (g_heff_2ecompile_2elower_2elowerProgramKept(v_g_242, v_key_243, v_vers_245, v_ks_246));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_2411 = (g_heff_2ecompile_2elower_2efusedOf(v_t_2410, heff_take_field(v_sk_248, 0)));
  V v_t_2412 = (g_heff_2ecompile_2elower_2ecFused(v_t_249, heff_take_field(v_sk_248, 1), v_t_2411));
  V v_t_2413 = heff_rec_n(3, shape_lowered__groups__copies, (V[]){v_t_2412, heff_take_field(v_sk_248, 2), heff_get_n(v_sk_248, 3, 4)});
  return (g_heff_2ecompile_2eemitc_2ekeptParts(v_runtime_240, v_provs_241, v_eff_244, v_kept_247, v_t_2413));
}
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7); heff_drop(a7); return r;
}