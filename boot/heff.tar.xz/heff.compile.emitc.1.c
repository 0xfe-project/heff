// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_MkDrop 35958
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_exp 310423
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
static uint32_t shape_exp__stmts__ctype[] = {LBL_exp, LBL_stmts, LBL_ctype};
V g_heff_2ecompile_2eemitc_2eagain(V, V, V);
V g_heff_2ecompile_2eemitc_2eagain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagain_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC_24s44291070x1575844925(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_24s44291070x1575844925_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_24s44291070x1575844925_clo;
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360_clo;
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758(V, V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_list_2eany_24s1182572632x117717553(V, V, V, V, V);
V g_list_2eany_24s1182572632x117717553_entry(V self, V *a);
extern Clo g_list_2eany_24s1182572632x117717553_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f966602123x1640556393(V, V);
V g_list_2emap_24f966602123x1640556393_entry(V self, V *a);
extern Clo g_list_2emap_24f966602123x1640556393_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s275211812x1381242052(V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s457513469x1891643252(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str0, 3, "InR");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str1, 6, "MkPair");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str2, 3, "InL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str3, 4, "Just");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str4, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str5, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str6, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str8, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str9, 4, "True");

static V g_heff_2ecompile_2eemitc_2eknownTags_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eknownTags_st;
static V g_heff_2ecompile_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eknownTags_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eknownTags_st)) return g_heff_2ecompile_2eemitc_2eknownTags_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eknownTags_val, &g_heff_2ecompile_2eemitc_2eknownTags_st, g_heff_2ecompile_2eemitc_2eknownTags_init);
}
Clo g_heff_2ecompile_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c_lent(v_o_240, v_o2_245, 0)) {
        if (heff_strEq_c_lent(v_k_241, v_k2_246, 0)) {
          heff_drop(v_o_240);
          heff_drop(v_k_241);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_o_240);
        heff_drop(v_k_241);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eownHas(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str21, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str22, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str24, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str26, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str28, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str29, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str30, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str31, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str32, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str34, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str35, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str36, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str37, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str38, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str39, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str42, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str44, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str45, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str49, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str50, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str51, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str52, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str53, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str54, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str55, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str56, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str57, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str58, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str59, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str60, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str61, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str62, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str63, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str64, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str65, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str66, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str67, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str68, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str69, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str70, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str71, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str72, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str73, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str74, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str75, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str76, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str77, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str78, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str79, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str80, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str81, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str82, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str83, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str84, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str85, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str86, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str87, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str88, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str89, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str90, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str91, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str92, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str93, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str94, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str95, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str96, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str97, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str98, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str99, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str100, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str101, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str102, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str103, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str104, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str105, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str106, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str107, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str108, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str109, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str110, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str111, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str112, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str113, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str114, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str115, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str116, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str117, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str118, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str119, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str120, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str121, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str122, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str123, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str124, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str125, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str126, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str127, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str128, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str129, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str130, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str131, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str132, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str133, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str134, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str135, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str136, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str138, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str139, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str140, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str141, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str142, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str143, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str144, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str145, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str146, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str147, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str148, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str149, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str150, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str151, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str152, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str153, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str154, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str155, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str156, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str157, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str158, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str159, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str160, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str161, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str162, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str163, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str164, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str165, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str166, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str167, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str168, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str169, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str170, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str171, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str172, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str173, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str174, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str175, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str176, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str177, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str178, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str179, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str180, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str181, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str182, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str183, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str184, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str185, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str186, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str187, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str188, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str189, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str190, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str191, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str192, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str193, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str194, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str195, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str196, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str197, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str198, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str199, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str200, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str201, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str202, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str203, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str204, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str205, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str206, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str207, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str208, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str209, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str210, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str211, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str212, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str213, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str214, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str215, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str216, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str217, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str218, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str219, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str220, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str221, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str222, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str223, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str224, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str225, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str226, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str227, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str228, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str229, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str230, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str231, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str232, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str233, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str234, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str235, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str236, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str238, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str239, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str240, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str241, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str242, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str243, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str244, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str245, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str246, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str247, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str248, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str249, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str250, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str251, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str252, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str253, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str254, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str255, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str256, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str257, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str258, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str259, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str260, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str261, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str262, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str263, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str264, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str265, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str266, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str267, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str268, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str269, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str270, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str271, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str272, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str273, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str274, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str275, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str276, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str277, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str278, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str279, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str280, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str281, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str282, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str283, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str284, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str285, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str286, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str287, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str288, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str289, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str290, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str291, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str292, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str293, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str294, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str295, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str296, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str297, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str298, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str299, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str300, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str301, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str302, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str303, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str304, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str305, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str306, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str307, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str308, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str309, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str310, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str311, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str312, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str313, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str314, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str315, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str316, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str317, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str318, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str319, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str320, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str321, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str322, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str323, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str324, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str325, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str326, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str327, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str328, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str329, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str330, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str331, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str332, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str333, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str334, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str335, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str336, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str337, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str338, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str339, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str340, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str341, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str342, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str343, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str344, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str345, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str346, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str347, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str348, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str349, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str350, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str351, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str352, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str353, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str354, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str355, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str356, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str357, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str358, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str359, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str360, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str361, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str362, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str363, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str364, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str365, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str366, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str367, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str368, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str369, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str370, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str371, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str372, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str373, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str374, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str375, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str376, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str377, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str378, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str379, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str380, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str381, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str382, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str383, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str384, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str385, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str386, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str387, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str388, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str389, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str390, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str391, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str392, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str393, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str394, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str395, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str396, 17, "heff_from_int_f32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str397, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str398, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str399, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str400, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str401, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str402, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str403, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str404, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str405, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str406, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str407, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str408, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str409, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str410, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str411, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str412, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str413, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str414, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str415, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str416, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str417, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str418, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str419, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str420, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str421, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str422, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str423, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str424, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str425, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str426, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str427, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str428, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str429, 5, "sqrtf");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str430, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str431, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str432, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str433, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str434, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str435, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str436, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str437, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str438, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str439, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str440, 14, "heff_floor_f32");
Clo g_heff_2ecompile_2eemitc_2efloat32U_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efloat32U_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efloat32U(V v_op_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    V v_t_244;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_242 = heff_dup(heff_field(v_vs_241, 0));
      v_t_244 = v_x_242;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_245;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str1);
      break;
    }
    case TAG_OpSub: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str2);
      break;
    }
    case TAG_OpMul: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str3);
      break;
    }
    case TAG_OpDiv: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str4);
      break;
    }
    case TAG_OpRem: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str5);
      break;
    }
    case TAG_OpEq: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str6);
      break;
    }
    case TAG_OpLt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str7);
      break;
    }
    case TAG_OpLe: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str8);
      break;
    }
    case TAG_OpAnd: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str9);
      break;
    }
    case TAG_OpOr: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str10);
      break;
    }
    case TAG_OpXor: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str11);
      break;
    }
    case TAG_OpShl: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str12);
      break;
    }
    case TAG_OpShr: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str13);
      break;
    }
    case TAG_OpShow: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str14);
      break;
    }
    case TAG_OpFromInt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str15);
      break;
    }
    case TAG_OpToInt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str16);
      break;
    }
    case TAG_OpSqrt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str17);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str18);
      break;
    }
    case TAG_OpToFloat: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str19);
      break;
    }
    case TAG_OpFloor: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str20);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_246 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_t_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str22), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str23)));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str24), heff_strAppend(v_t_245, v_t_2410));
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str25), heff_strAppend(v_t_244, v_t_2411));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str26), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str27)));
  }
  case TAG_OpSub: {
    V v_t_2415;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str28);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2415 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2416;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str29);
      break;
    }
    case TAG_OpSub: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str30);
      break;
    }
    case TAG_OpMul: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str31);
      break;
    }
    case TAG_OpDiv: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str32);
      break;
    }
    case TAG_OpRem: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str33);
      break;
    }
    case TAG_OpEq: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str34);
      break;
    }
    case TAG_OpLt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str35);
      break;
    }
    case TAG_OpLe: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str36);
      break;
    }
    case TAG_OpAnd: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str37);
      break;
    }
    case TAG_OpOr: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str38);
      break;
    }
    case TAG_OpXor: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str39);
      break;
    }
    case TAG_OpShl: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str40);
      break;
    }
    case TAG_OpShr: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str41);
      break;
    }
    case TAG_OpShow: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str42);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str43);
      break;
    }
    case TAG_OpToInt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str44);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str45);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str46);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str47);
      break;
    }
    case TAG_OpFloor: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str48);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2417 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2420;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str49);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 2);
      v_t_2420 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str50), heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str51)));
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str52), heff_strAppend(v_t_2416, v_t_2421));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str53), heff_strAppend(v_t_2415, v_t_2422));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str54), heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str55)));
  }
  case TAG_OpMul: {
    V v_t_2426;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str56);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2426 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2427;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str57);
      break;
    }
    case TAG_OpSub: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str58);
      break;
    }
    case TAG_OpMul: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str59);
      break;
    }
    case TAG_OpDiv: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str60);
      break;
    }
    case TAG_OpRem: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str61);
      break;
    }
    case TAG_OpEq: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str62);
      break;
    }
    case TAG_OpLt: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str63);
      break;
    }
    case TAG_OpLe: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str64);
      break;
    }
    case TAG_OpAnd: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str65);
      break;
    }
    case TAG_OpOr: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str66);
      break;
    }
    case TAG_OpXor: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str67);
      break;
    }
    case TAG_OpShl: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str68);
      break;
    }
    case TAG_OpShr: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str69);
      break;
    }
    case TAG_OpShow: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str70);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str71);
      break;
    }
    case TAG_OpToInt: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str72);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str73);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str74);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str75);
      break;
    }
    case TAG_OpFloor: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str76);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2428 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str77);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x1_2428, 0);
      heff_take_n(v_x1_2428, 1ULL, 2);
      v_t_2431 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_x1_2428);
    }
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str78), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str79)));
    V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str80), heff_strAppend(v_t_2427, v_t_2432));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str81), heff_strAppend(v_t_2426, v_t_2433));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str82), heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str83)));
  }
  case TAG_OpDiv: {
    V v_t_2437;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str84);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2437 = v_x_2435;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2438;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str85);
      break;
    }
    case TAG_OpSub: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str86);
      break;
    }
    case TAG_OpMul: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str87);
      break;
    }
    case TAG_OpDiv: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str88);
      break;
    }
    case TAG_OpRem: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str89);
      break;
    }
    case TAG_OpEq: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str90);
      break;
    }
    case TAG_OpLt: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str91);
      break;
    }
    case TAG_OpLe: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str92);
      break;
    }
    case TAG_OpAnd: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str93);
      break;
    }
    case TAG_OpOr: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str94);
      break;
    }
    case TAG_OpXor: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str95);
      break;
    }
    case TAG_OpShl: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str96);
      break;
    }
    case TAG_OpShr: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str97);
      break;
    }
    case TAG_OpShow: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str98);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str99);
      break;
    }
    case TAG_OpToInt: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str100);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str101);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str102);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str103);
      break;
    }
    case TAG_OpFloor: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str104);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2439 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2442;
    switch (heff_tag_of(v_x1_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str105);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x1_2439, 0);
      heff_take_n(v_x1_2439, 1ULL, 2);
      v_t_2442 = v_x_2440;
      break;
    }
    default: heff_nomatch(v_x1_2439);
    }
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str106), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str107)));
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str108), heff_strAppend(v_t_2438, v_t_2443));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str109), heff_strAppend(v_t_2437, v_t_2444));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str110), heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str111)));
  }
  case TAG_OpRem: {
    V v_t_2448;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str112);
      break;
    }
    case TAG_Cons: {
      V v_x_2446 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2448 = v_x_2446;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2449;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str113);
      break;
    }
    case TAG_OpSub: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str114);
      break;
    }
    case TAG_OpMul: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str115);
      break;
    }
    case TAG_OpDiv: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str116);
      break;
    }
    case TAG_OpRem: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str117);
      break;
    }
    case TAG_OpEq: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str118);
      break;
    }
    case TAG_OpLt: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str119);
      break;
    }
    case TAG_OpLe: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str120);
      break;
    }
    case TAG_OpAnd: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str121);
      break;
    }
    case TAG_OpOr: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str122);
      break;
    }
    case TAG_OpXor: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str123);
      break;
    }
    case TAG_OpShl: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str124);
      break;
    }
    case TAG_OpShr: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str125);
      break;
    }
    case TAG_OpShow: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str126);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str127);
      break;
    }
    case TAG_OpToInt: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str128);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str129);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str130);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str131);
      break;
    }
    case TAG_OpFloor: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str132);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2450 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2453;
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_Nil: {
      v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str133);
      break;
    }
    case TAG_Cons: {
      V v_x_2451 = heff_field(v_x1_2450, 0);
      heff_take_n(v_x1_2450, 1ULL, 2);
      v_t_2453 = v_x_2451;
      break;
    }
    default: heff_nomatch(v_x1_2450);
    }
    V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str134), heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str135)));
    V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str136), heff_strAppend(v_t_2449, v_t_2454));
    V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str137), heff_strAppend(v_t_2448, v_t_2455));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str138), heff_strAppend(v_t_2456, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str139)));
  }
  case TAG_OpEq: {
    V v_t_2459;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2459 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str140);
      break;
    }
    case TAG_Cons: {
      V v_x_2457 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2459 = v_x_2457;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2460;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str141);
      break;
    }
    case TAG_OpSub: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str142);
      break;
    }
    case TAG_OpMul: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str143);
      break;
    }
    case TAG_OpDiv: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str144);
      break;
    }
    case TAG_OpRem: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str145);
      break;
    }
    case TAG_OpEq: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str146);
      break;
    }
    case TAG_OpLt: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str147);
      break;
    }
    case TAG_OpLe: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str148);
      break;
    }
    case TAG_OpAnd: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str149);
      break;
    }
    case TAG_OpOr: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str150);
      break;
    }
    case TAG_OpXor: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str151);
      break;
    }
    case TAG_OpShl: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str152);
      break;
    }
    case TAG_OpShr: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str153);
      break;
    }
    case TAG_OpShow: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str154);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str155);
      break;
    }
    case TAG_OpToInt: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str156);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str157);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str158);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str159);
      break;
    }
    case TAG_OpFloor: {
      v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str160);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2461 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2464;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nil: {
      v_t_2464 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str161);
      break;
    }
    case TAG_Cons: {
      V v_x_2462 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 2);
      v_t_2464 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    V v_t_2465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str162), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str163)));
    V v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str164), heff_strAppend(v_t_2460, v_t_2465));
    V v_t_2467 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str165), heff_strAppend(v_t_2459, v_t_2466));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str166), heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str167)));
  }
  case TAG_OpLt: {
    V v_t_2470;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2470 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str168);
      break;
    }
    case TAG_Cons: {
      V v_x_2468 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2470 = v_x_2468;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2471;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str169);
      break;
    }
    case TAG_OpSub: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str170);
      break;
    }
    case TAG_OpMul: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str171);
      break;
    }
    case TAG_OpDiv: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str172);
      break;
    }
    case TAG_OpRem: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str173);
      break;
    }
    case TAG_OpEq: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str174);
      break;
    }
    case TAG_OpLt: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str175);
      break;
    }
    case TAG_OpLe: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str176);
      break;
    }
    case TAG_OpAnd: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str177);
      break;
    }
    case TAG_OpOr: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str178);
      break;
    }
    case TAG_OpXor: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str179);
      break;
    }
    case TAG_OpShl: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str180);
      break;
    }
    case TAG_OpShr: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str181);
      break;
    }
    case TAG_OpShow: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str182);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str183);
      break;
    }
    case TAG_OpToInt: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str184);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str185);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str186);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str187);
      break;
    }
    case TAG_OpFloor: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str188);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2472 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2475;
    switch (heff_tag_of(v_x1_2472)) {
    case TAG_Nil: {
      v_t_2475 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str189);
      break;
    }
    case TAG_Cons: {
      V v_x_2473 = heff_field(v_x1_2472, 0);
      heff_take_n(v_x1_2472, 1ULL, 2);
      v_t_2475 = v_x_2473;
      break;
    }
    default: heff_nomatch(v_x1_2472);
    }
    V v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str190), heff_strAppend(v_t_2475, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str191)));
    V v_t_2477 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str192), heff_strAppend(v_t_2471, v_t_2476));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str193), heff_strAppend(v_t_2470, v_t_2477));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str194), heff_strAppend(v_t_2478, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str195)));
  }
  case TAG_OpLe: {
    V v_t_2481;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2481 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str196);
      break;
    }
    case TAG_Cons: {
      V v_x_2479 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2481 = v_x_2479;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2482;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str197);
      break;
    }
    case TAG_OpSub: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str198);
      break;
    }
    case TAG_OpMul: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str199);
      break;
    }
    case TAG_OpDiv: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str200);
      break;
    }
    case TAG_OpRem: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str201);
      break;
    }
    case TAG_OpEq: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str202);
      break;
    }
    case TAG_OpLt: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str203);
      break;
    }
    case TAG_OpLe: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str204);
      break;
    }
    case TAG_OpAnd: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str205);
      break;
    }
    case TAG_OpOr: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str206);
      break;
    }
    case TAG_OpXor: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str207);
      break;
    }
    case TAG_OpShl: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str208);
      break;
    }
    case TAG_OpShr: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str209);
      break;
    }
    case TAG_OpShow: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str210);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str211);
      break;
    }
    case TAG_OpToInt: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str212);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str213);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str214);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str215);
      break;
    }
    case TAG_OpFloor: {
      v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str216);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2483 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2486;
    switch (heff_tag_of(v_x1_2483)) {
    case TAG_Nil: {
      v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str217);
      break;
    }
    case TAG_Cons: {
      V v_x_2484 = heff_field(v_x1_2483, 0);
      heff_take_n(v_x1_2483, 1ULL, 2);
      v_t_2486 = v_x_2484;
      break;
    }
    default: heff_nomatch(v_x1_2483);
    }
    V v_t_2487 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str218), heff_strAppend(v_t_2486, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str219)));
    V v_t_2488 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str220), heff_strAppend(v_t_2482, v_t_2487));
    V v_t_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str221), heff_strAppend(v_t_2481, v_t_2488));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str222), heff_strAppend(v_t_2489, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str223)));
  }
  case TAG_OpAnd: {
    V v_t_2492;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2492 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str224);
      break;
    }
    case TAG_Cons: {
      V v_x_2490 = heff_dup(heff_field(v_vs_241, 0));
      v_t_2492 = v_x_2490;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2493;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str225);
      break;
    }
    case TAG_OpSub: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str226);
      break;
    }
    case TAG_OpMul: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str227);
      break;
    }
    case TAG_OpDiv: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str228);
      break;
    }
    case TAG_OpRem: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str229);
      break;
    }
    case TAG_OpEq: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str230);
      break;
    }
    case TAG_OpLt: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str231);
      break;
    }
    case TAG_OpLe: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str232);
      break;
    }
    case TAG_OpAnd: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str233);
      break;
    }
    case TAG_OpOr: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str234);
      break;
    }
    case TAG_OpXor: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str235);
      break;
    }
    case TAG_OpShl: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str236);
      break;
    }
    case TAG_OpShr: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str237);
      break;
    }
    case TAG_OpShow: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str238);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str239);
      break;
    }
    case TAG_OpToInt: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str240);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str241);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str242);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str243);
      break;
    }
    case TAG_OpFloor: {
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str244);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_2494 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_2497;
    switch (heff_tag_of(v_x1_2494)) {
    case TAG_Nil: {
      v_t_2497 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str245);
      break;
    }
    case TAG_Cons: {
      V v_x_2495 = heff_field(v_x1_2494, 0);
      heff_take_n(v_x1_2494, 1ULL, 2);
      v_t_2497 = v_x_2495;
      break;
    }
    default: heff_nomatch(v_x1_2494);
    }
    V v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str246), heff_strAppend(v_t_2497, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str247)));
    V v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str248), heff_strAppend(v_t_2493, v_t_2498));
    V v_t_24100 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str249), heff_strAppend(v_t_2492, v_t_2499));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str250), heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str251)));
  }
  case TAG_OpOr: {
    V v_t_24103;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24103 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str252);
      break;
    }
    case TAG_Cons: {
      V v_x_24101 = heff_dup(heff_field(v_vs_241, 0));
      v_t_24103 = v_x_24101;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24104;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str253);
      break;
    }
    case TAG_OpSub: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str254);
      break;
    }
    case TAG_OpMul: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str255);
      break;
    }
    case TAG_OpDiv: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str256);
      break;
    }
    case TAG_OpRem: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str257);
      break;
    }
    case TAG_OpEq: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str258);
      break;
    }
    case TAG_OpLt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str259);
      break;
    }
    case TAG_OpLe: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str260);
      break;
    }
    case TAG_OpAnd: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str261);
      break;
    }
    case TAG_OpOr: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str262);
      break;
    }
    case TAG_OpXor: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str263);
      break;
    }
    case TAG_OpShl: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str264);
      break;
    }
    case TAG_OpShr: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str265);
      break;
    }
    case TAG_OpShow: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str266);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str267);
      break;
    }
    case TAG_OpToInt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str268);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str269);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str270);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str271);
      break;
    }
    case TAG_OpFloor: {
      v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str272);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_24105 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_24108;
    switch (heff_tag_of(v_x1_24105)) {
    case TAG_Nil: {
      v_t_24108 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str273);
      break;
    }
    case TAG_Cons: {
      V v_x_24106 = heff_field(v_x1_24105, 0);
      heff_take_n(v_x1_24105, 1ULL, 2);
      v_t_24108 = v_x_24106;
      break;
    }
    default: heff_nomatch(v_x1_24105);
    }
    V v_t_24109 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str274), heff_strAppend(v_t_24108, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str275)));
    V v_t_24110 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str276), heff_strAppend(v_t_24104, v_t_24109));
    V v_t_24111 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str277), heff_strAppend(v_t_24103, v_t_24110));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str278), heff_strAppend(v_t_24111, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str279)));
  }
  case TAG_OpXor: {
    V v_t_24114;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str280);
      break;
    }
    case TAG_Cons: {
      V v_x_24112 = heff_dup(heff_field(v_vs_241, 0));
      v_t_24114 = v_x_24112;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24115;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str281);
      break;
    }
    case TAG_OpSub: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str282);
      break;
    }
    case TAG_OpMul: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str283);
      break;
    }
    case TAG_OpDiv: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str284);
      break;
    }
    case TAG_OpRem: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str285);
      break;
    }
    case TAG_OpEq: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str286);
      break;
    }
    case TAG_OpLt: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str287);
      break;
    }
    case TAG_OpLe: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str288);
      break;
    }
    case TAG_OpAnd: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str289);
      break;
    }
    case TAG_OpOr: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str290);
      break;
    }
    case TAG_OpXor: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str291);
      break;
    }
    case TAG_OpShl: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str292);
      break;
    }
    case TAG_OpShr: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str293);
      break;
    }
    case TAG_OpShow: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str294);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str295);
      break;
    }
    case TAG_OpToInt: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str296);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str297);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str298);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str299);
      break;
    }
    case TAG_OpFloor: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str300);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_24116 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_24119;
    switch (heff_tag_of(v_x1_24116)) {
    case TAG_Nil: {
      v_t_24119 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str301);
      break;
    }
    case TAG_Cons: {
      V v_x_24117 = heff_field(v_x1_24116, 0);
      heff_take_n(v_x1_24116, 1ULL, 2);
      v_t_24119 = v_x_24117;
      break;
    }
    default: heff_nomatch(v_x1_24116);
    }
    V v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str302), heff_strAppend(v_t_24119, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str303)));
    V v_t_24121 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str304), heff_strAppend(v_t_24115, v_t_24120));
    V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str305), heff_strAppend(v_t_24114, v_t_24121));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str306), heff_strAppend(v_t_24122, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str307)));
  }
  case TAG_OpShl: {
    V v_t_24125;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str308);
      break;
    }
    case TAG_Cons: {
      V v_x_24123 = heff_dup(heff_field(v_vs_241, 0));
      v_t_24125 = v_x_24123;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24126;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str309);
      break;
    }
    case TAG_OpSub: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str310);
      break;
    }
    case TAG_OpMul: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str311);
      break;
    }
    case TAG_OpDiv: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str312);
      break;
    }
    case TAG_OpRem: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str313);
      break;
    }
    case TAG_OpEq: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str314);
      break;
    }
    case TAG_OpLt: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str315);
      break;
    }
    case TAG_OpLe: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str316);
      break;
    }
    case TAG_OpAnd: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str317);
      break;
    }
    case TAG_OpOr: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str318);
      break;
    }
    case TAG_OpXor: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str319);
      break;
    }
    case TAG_OpShl: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str320);
      break;
    }
    case TAG_OpShr: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str321);
      break;
    }
    case TAG_OpShow: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str322);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str323);
      break;
    }
    case TAG_OpToInt: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str324);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str325);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str326);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str327);
      break;
    }
    case TAG_OpFloor: {
      v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str328);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_24127 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_24130;
    switch (heff_tag_of(v_x1_24127)) {
    case TAG_Nil: {
      v_t_24130 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str329);
      break;
    }
    case TAG_Cons: {
      V v_x_24128 = heff_field(v_x1_24127, 0);
      heff_take_n(v_x1_24127, 1ULL, 2);
      v_t_24130 = v_x_24128;
      break;
    }
    default: heff_nomatch(v_x1_24127);
    }
    V v_t_24131 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str330), heff_strAppend(v_t_24130, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str331)));
    V v_t_24132 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str332), heff_strAppend(v_t_24126, v_t_24131));
    V v_t_24133 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str333), heff_strAppend(v_t_24125, v_t_24132));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str334), heff_strAppend(v_t_24133, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str335)));
  }
  case TAG_OpShr: {
    V v_t_24136;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24136 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str336);
      break;
    }
    case TAG_Cons: {
      V v_x_24134 = heff_dup(heff_field(v_vs_241, 0));
      v_t_24136 = v_x_24134;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24137;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str337);
      break;
    }
    case TAG_OpSub: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str338);
      break;
    }
    case TAG_OpMul: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str339);
      break;
    }
    case TAG_OpDiv: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str340);
      break;
    }
    case TAG_OpRem: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str341);
      break;
    }
    case TAG_OpEq: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str342);
      break;
    }
    case TAG_OpLt: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str343);
      break;
    }
    case TAG_OpLe: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str344);
      break;
    }
    case TAG_OpAnd: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str345);
      break;
    }
    case TAG_OpOr: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str346);
      break;
    }
    case TAG_OpXor: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str347);
      break;
    }
    case TAG_OpShl: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str348);
      break;
    }
    case TAG_OpShr: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str349);
      break;
    }
    case TAG_OpShow: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str350);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str351);
      break;
    }
    case TAG_OpToInt: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str352);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str353);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str354);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str355);
      break;
    }
    case TAG_OpFloor: {
      v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str356);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_24138 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_24141;
    switch (heff_tag_of(v_x1_24138)) {
    case TAG_Nil: {
      v_t_24141 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str357);
      break;
    }
    case TAG_Cons: {
      V v_x_24139 = heff_field(v_x1_24138, 0);
      heff_take_n(v_x1_24138, 1ULL, 2);
      v_t_24141 = v_x_24139;
      break;
    }
    default: heff_nomatch(v_x1_24138);
    }
    V v_t_24142 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str358), heff_strAppend(v_t_24141, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str359)));
    V v_t_24143 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str360), heff_strAppend(v_t_24137, v_t_24142));
    V v_t_24144 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str361), heff_strAppend(v_t_24136, v_t_24143));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str362), heff_strAppend(v_t_24144, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str363)));
  }
  case TAG_OpShow: {
    V v_t_24147;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24147 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str364);
      break;
    }
    case TAG_Cons: {
      V v_x_24145 = heff_dup(heff_field(v_vs_241, 0));
      v_t_24147 = v_x_24145;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24148;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str365);
      break;
    }
    case TAG_OpSub: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str366);
      break;
    }
    case TAG_OpMul: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str367);
      break;
    }
    case TAG_OpDiv: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str368);
      break;
    }
    case TAG_OpRem: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str369);
      break;
    }
    case TAG_OpEq: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str370);
      break;
    }
    case TAG_OpLt: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str371);
      break;
    }
    case TAG_OpLe: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str372);
      break;
    }
    case TAG_OpAnd: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str373);
      break;
    }
    case TAG_OpOr: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str374);
      break;
    }
    case TAG_OpXor: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str375);
      break;
    }
    case TAG_OpShl: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str376);
      break;
    }
    case TAG_OpShr: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str377);
      break;
    }
    case TAG_OpShow: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str378);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str379);
      break;
    }
    case TAG_OpToInt: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str380);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str381);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str382);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str383);
      break;
    }
    case TAG_OpFloor: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str384);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_24149 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_24152;
    switch (heff_tag_of(v_x1_24149)) {
    case TAG_Nil: {
      v_t_24152 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str385);
      break;
    }
    case TAG_Cons: {
      V v_x_24150 = heff_field(v_x1_24149, 0);
      heff_take_n(v_x1_24149, 1ULL, 2);
      v_t_24152 = v_x_24150;
      break;
    }
    default: heff_nomatch(v_x1_24149);
    }
    V v_t_24153 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str386), heff_strAppend(v_t_24152, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str387)));
    V v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str388), heff_strAppend(v_t_24148, v_t_24153));
    V v_t_24155 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str389), heff_strAppend(v_t_24147, v_t_24154));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str390), heff_strAppend(v_t_24155, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str391)));
  }
  case TAG_OpFromInt: {
    V v_t_24158;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24158 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str392);
      break;
    }
    case TAG_Cons: {
      V v_x_24156 = heff_field(v_vs_241, 0);
      V v_xs_24157 = heff_field(v_vs_241, 1);
      heff_take_n(v_vs_241, 3ULL, 2);
      v_t_24158 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str393); V a_1 = v_x_24156; V a_2 = v_xs_24157; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24157); r_; });
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24159 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str394), heff_strAppend(v_t_24158, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str395)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str396), v_t_24159);
  }
  case TAG_OpToInt: {
    V v_t_24162;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24162 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str397);
      break;
    }
    case TAG_Cons: {
      V v_x_24160 = heff_dup(heff_field(v_vs_241, 0));
      v_t_24162 = v_x_24160;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24163;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str398);
      break;
    }
    case TAG_OpSub: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str399);
      break;
    }
    case TAG_OpMul: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str400);
      break;
    }
    case TAG_OpDiv: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str401);
      break;
    }
    case TAG_OpRem: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str402);
      break;
    }
    case TAG_OpEq: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str403);
      break;
    }
    case TAG_OpLt: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str404);
      break;
    }
    case TAG_OpLe: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str405);
      break;
    }
    case TAG_OpAnd: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str406);
      break;
    }
    case TAG_OpOr: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str407);
      break;
    }
    case TAG_OpXor: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str408);
      break;
    }
    case TAG_OpShl: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str409);
      break;
    }
    case TAG_OpShr: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str410);
      break;
    }
    case TAG_OpShow: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str411);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str412);
      break;
    }
    case TAG_OpToInt: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str413);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str414);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str415);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str416);
      break;
    }
    case TAG_OpFloor: {
      v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str417);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_x1_24164 = (g_list_2edrop(MK_INT(1LL), v_vs_241));
    V v_t_24167;
    switch (heff_tag_of(v_x1_24164)) {
    case TAG_Nil: {
      v_t_24167 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str418);
      break;
    }
    case TAG_Cons: {
      V v_x_24165 = heff_field(v_x1_24164, 0);
      heff_take_n(v_x1_24164, 1ULL, 2);
      v_t_24167 = v_x_24165;
      break;
    }
    default: heff_nomatch(v_x1_24164);
    }
    V v_t_24168 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str419), heff_strAppend(v_t_24167, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str420)));
    V v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str421), heff_strAppend(v_t_24163, v_t_24168));
    V v_t_24170 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str422), heff_strAppend(v_t_24162, v_t_24169));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str423), heff_strAppend(v_t_24170, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str424)));
  }
  case TAG_OpSqrt: {
    V v_t_24173;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24173 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str425);
      break;
    }
    case TAG_Cons: {
      V v_x_24171 = heff_field(v_vs_241, 0);
      V v_xs_24172 = heff_field(v_vs_241, 1);
      heff_take_n(v_vs_241, 3ULL, 2);
      v_t_24173 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str426); V a_1 = v_x_24171; V a_2 = v_xs_24172; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24172); r_; });
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24174 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str427), heff_strAppend(v_t_24173, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str428)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str429), v_t_24174);
  }
  case TAG_OpFromFloat: {
    V v_t_24177;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24177 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str430);
      break;
    }
    case TAG_Cons: {
      V v_x_24175 = heff_field(v_vs_241, 0);
      heff_take_n(v_vs_241, 1ULL, 2);
      v_t_24177 = v_x_24175;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str431), heff_strAppend(v_t_24177, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str432)));
  }
  case TAG_OpToFloat: {
    V v_t_24180;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24180 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str433);
      break;
    }
    case TAG_Cons: {
      V v_x_24178 = heff_field(v_vs_241, 0);
      heff_take_n(v_vs_241, 1ULL, 2);
      v_t_24180 = v_x_24178;
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str434), heff_strAppend(v_t_24180, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str435)));
  }
  case TAG_OpFloor: {
    V v_t_24183;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24183 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str436);
      break;
    }
    case TAG_Cons: {
      V v_x_24181 = heff_field(v_vs_241, 0);
      V v_xs_24182 = heff_field(v_vs_241, 1);
      heff_take_n(v_vs_241, 3ULL, 2);
      v_t_24183 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str437); V a_1 = v_x_24181; V a_2 = v_xs_24182; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24182); r_; });
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24184 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str438), heff_strAppend(v_t_24183, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str439)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str440), v_t_24184);
  }
  default: return heff_nomatch(v_op_240);
  }
}
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efloat32U(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str0, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str1, 19, "(V self, V *args) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str2, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str5, 8, " = args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str6, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str7, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str8, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str10, 18, " = heff_env(self)[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str12, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str13, 22, "  heff_clo_take(self, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str14, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str15, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2elamLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_body_243) {
top: ;
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str0), heff_strAppend(v_k_240, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str1)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(1LL))));
  V v_t_248 = (g_list_2ezipWith_24s457513469x1891643252(((V)&g_heff_2ecompile_2eemitc_2elamLines_str2), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str4), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str5), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str6), v_xs_241, v_t_247));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fv_242));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
  V v_t_2411 = (g_list_2ezipWith_24s457513469x1891643252(((V)&g_heff_2ecompile_2eemitc_2elamLines_str7), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str8), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str9), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str10), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str11), heff_dup(v_fv_242), v_t_2410));
  V v_t_2416;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2415 = heff_strAppend(heff_intShow(v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str12));
    v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str13), v_t_2415), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elamLines_str14), NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str15), v_body_243));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2419));
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_248, v_t_2420));
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2421));
}
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str3, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str5, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str6, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str10, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str14, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str16, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str17, 15, "heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str18, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str19, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str21, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str23, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str24, 20, "switch (heff_tag_of(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str25, 4, ")) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str26, 29, "default: return heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str27, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str28, 22, "default: heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str29, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str30, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str31, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str32, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str33, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str34, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str37, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str38, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str39, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str40, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str41, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str42, 17, "return heff_tail(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str44, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str45, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str47, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str49, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str50, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str51, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str52, 17, "HEFF_LAST return ");
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2estmtF_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_lam4, 1, 0};
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estmtF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_248;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x12_244 = heff_field(v_d_242, 1);
      heff_take_n(v_d_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str0)));
        V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str1), v_t_245), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str2));
        v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str3), v_t_246);
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam0, 1, 1, (V[]){v_x_249});
  }
  case TAG_CLet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_e_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_k_240, 2), 1, (V[]){heff_dup(v_x_2411)}));
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2411, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str4)));
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str5), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str6));
    V v_pre_2416 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str7), v_t_2415));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2412}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam1, 1, 2, (V[]){v_m_2417, v_pre_2416});
  }
  case TAG_CDecl: {
    V v_x_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_2424)}));
    V v_t_2426 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2424, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str9)));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str10), v_t_2426), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str11));
    V v_t_2428 = heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str12), v_t_2427));
    V v_x_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam2, 1, 1, (V[]){v_x_2429});
  }
  case TAG_CSet: {
    V v_x_2431 = heff_field(v_x2_241, 0);
    V v_e_2432 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2431, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str13)));
    V v_pre_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str14), v_t_2433), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str15));
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2432}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam3, 1, 2, (V[]){v_m_2435, v_pre_2434});
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2estmtF_lam4_clo);
  }
  case TAG_CIf: {
    V v_c_2444 = heff_field(v_x2_241, 0);
    V v_yes_2445 = heff_field(v_x2_241, 1);
    V v_no_2446 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2447 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_2444));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam5, 1, 4, (V[]){v_m_2447, v_k_240, v_yes_2445, v_no_2446});
  }
  case TAG_CSwitch: {
    V v_e_2466 = heff_field(v_x2_241, 0);
    V v_arms_2467 = heff_field(v_x2_241, 1);
    V v_returns_2468 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_2466}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam6, 1, 4, (V[]){v_m_2469, v_k_240, v_arms_2467, v_returns_2468});
  }
  case TAG_CReturn: {
    V v_e_2486 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2487 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2486}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam7, 1, 1, (V[]){v_m_2487});
  }
  case TAG_CInPlace: {
    V v_f_2494 = heff_field(v_x2_241, 0);
    V v_es_2495 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CInPlace = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_2496 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24CInPlace, TAG_Cons, 2, (V[]){v_f_2494, v_es_2495})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam8, 1, 1, (V[]){v_m_2496});
  }
  case TAG_CRoomed: {
    V v_f_24102 = heff_field(v_x2_241, 0);
    V v_es_24103 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CRoomed = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24104 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24CRoomed, TAG_Cons, 2, (V[]){v_f_24102, v_es_24103})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam9, 1, 1, (V[]){v_m_24104});
  }
  case TAG_CTail: {
    V v_f_24110 = heff_field(v_x2_241, 0);
    V v_es_24111 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CTail = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24112 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24CTail, TAG_Cons, 2, (V[]){v_f_24110, heff_dup(v_es_24111)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam10, 1, 2, (V[]){v_m_24112, v_es_24111});
  }
  case TAG_CLoop: {
    V v_ps_24132 = heff_field(v_x2_241, 0);
    V v_es_24133 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24134 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_dup(heff_rfield(v_k_240, 0)), v_es_24133));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam11, 1, 3, (V[]){v_m_24134, v_k_240, v_ps_24132});
  }
  case TAG_CJump: {
    V v_g_24141 = heff_field(v_x2_241, 0);
    V v_w_24142 = heff_field(v_x2_241, 1);
    V v_es_24143 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24144 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_24143));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam12, 1, 3, (V[]){v_m_24144, v_w_24142, v_g_24141});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estmtF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_pre_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_strAppend(v_pre_2416, heff_strAppend(v_x_2420, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str8)));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_s_2430});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_pre_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440 = heff_strAppend(v_pre_2434, heff_strAppend(v_x_2438, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str16)));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){v_t_2441, v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args) {
  V v_s_2442 = args[0];
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str17), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2442});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args) {
  V v_s_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_yes_2445 = heff_env(self)[2];
  V v_no_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_s_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_s_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    V v_m_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_yes_2445}));
    V v_x2_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2451}));
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_MkPair: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_s_2455 = heff_field(v_x2_2453, 1);
      V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
      V v_m_2456 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 3), 1, (V[]){v_no_2446}));
      V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2455}));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str18), heff_strAppend(v_x_2450, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str19)));
        V v_t_2461 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2estmtF_str20), v_x_2454));
        V v_t_2462 = heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str21), NTAG(TAG_Nil)});
        V v_t_2463 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2462, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str22), v_x_2458));
        V v_t_2464 = (g_prelude_2e_2b_2b(v_t_2461, heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str23), v_t_2463})));
        V v_x_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2464});
        return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){v_x_2465, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
    default: return heff_nomatch(v_x2_2453);
    }
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_arms_2467 = heff_env(self)[2];
  V v_returns_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    V v_m_2474 = (g_heff_2ecompile_2eemitc_2etraverseC_24s710132368x2028283758(v_k_240, heff_dup(v_x_2472), v_arms_2467));
    V v_x2_2475 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2473}));
    switch (heff_tag_of(v_x2_2475)) {
    case TAG_MkPair: {
      V v_x_2476 = heff_field(v_x2_2475, 0);
      V v_s_2477 = heff_field(v_x2_2475, 1);
      V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
      V v_t_2478 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str24), heff_strAppend(heff_dup(v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str25)));
      V v_t_2479 = heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_Cons, 2, (V[]){v_t_2478, NTAG(TAG_Nil)});
      V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2476));
      V v_t_2481 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2480; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2480); r_; });
      V v_t_2482;
      if ((heff_dup(v_returns_2468) == NTAG(TAG_True))) {
        heff_drop(v_returns_2468);
        v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str26), heff_strAppend(v_x_2472, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str27)));
      } else {
        heff_drop(v_returns_2468);
        v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str28), heff_strAppend(v_x_2472, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str29)));
      }
      V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str30), NTAG(TAG_Nil)});
      V v_t_2484 = (g_prelude_2e_2b_2b(v_t_2481, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, v_t_2483})));
      V v_x_2485 = (g_prelude_2e_2b_2b(v_t_2479, v_t_2484));
      return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_x_2485, v_s_2477});
    }
    default: return heff_nomatch(v_x2_2475);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args) {
  V v_s_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_s_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_t_2492 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str31), heff_strAppend(v_x_2490, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str32)));
    V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2492, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){v_t_2493, v_s_2491});
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    V v_x_24101 = (g_heff_2ecompile_2eemitc_2einPlace(v_x_2499));
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){v_x_24101, v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    V v_x_24109 = (g_heff_2ecompile_2eemitc_2eroomed(v_x_24107));
    return heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){v_x_24109, v_s_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args) {
  V v_s_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_es_24111 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_s_24113}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_s_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    V v_t_24119;
    switch (heff_tag_of(v_x_24115)) {
    case TAG_Nil: {
      v_t_24119 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_24117 = heff_dup(heff_field(v_x_24115, 0));
      v_t_24119 = v_x_24117;
      break;
    }
    default: heff_nomatch(v_x_24115);
    }
    V v_t_24120 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24111; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24111); r_; });
    V v_vs_24121 = (g_list_2edrop(MK_INT(1LL), v_x_24115));
    V v_t_24127;
    switch (heff_tag_of(v_vs_24121)) {
    case TAG_Nil: {
      v_t_24127 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str34);
      break;
    }
    case TAG_Cons: {
      V v_t_24126;
      switch (heff_tag_of(v_vs_24121)) {
      case TAG_Nil: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str35);
        break;
      }
      case TAG_Cons: {
        V v_x_24124 = heff_field(v_vs_24121, 0);
        V v_xs_24125 = heff_field(v_vs_24121, 1);
        heff_take_n(v_vs_24121, 3ULL, 2);
        v_t_24126 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str36); V a_1 = v_x_24124; V a_2 = v_xs_24125; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24125); r_; });
        break;
      }
      default: heff_nomatch(v_vs_24121);
      }
      v_t_24127 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str37), heff_strAppend(v_t_24126, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str38)));
      break;
    }
    default: heff_nomatch(v_vs_24121);
    }
    V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str39), heff_strAppend(v_t_24127, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str40)));
    V v_t_24129 = heff_strAppend(heff_intShow(v_t_24120), v_t_24128);
    V v_t_24130 = heff_strAppend(v_t_24119, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str41), v_t_24129));
    V v_x_24131 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str42), v_t_24130), NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){v_x_24131, v_s_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args) {
  V v_s_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_ps_24132 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24135}));
  switch (heff_tag_of(v_x2_24136)) {
  case TAG_MkPair: {
    V v_x_24137 = heff_field(v_x2_24136, 0);
    V v_s_24138 = heff_field(v_x2_24136, 1);
    V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
    V v_t_24139 = (g_list_2emap(heff_get_n(v_k_240, 2, 3), heff_dup(v_ps_24132)));
    V v_x_24140 = (g_heff_2ecompile_2eemitc_2eagain(v_t_24139, v_ps_24132, v_x_24137));
    return heff_tag_at_n(v_ru_24x2_24136_24MkPair, TAG_MkPair, 2, (V[]){v_x_24140, v_s_24138});
  }
  default: return heff_nomatch(v_x2_24136);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  V v_w_24142 = heff_env(self)[1];
  V v_g_24141 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    V v_t_24151;
    if ((heff_dup(v_w_24142) == NTAG(TAG_True))) {
      heff_drop(v_w_24142);
      V v_t_24149 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_24141, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str43)));
      v_t_24151 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str44), v_t_24149), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str45));
    } else {
      heff_drop(v_w_24142);
      V v_t_24150 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_24141, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str46)));
      v_t_24151 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str47), v_t_24150);
    }
    V v_t_24154;
    switch (heff_tag_of(v_x_24147)) {
    case TAG_Nil: {
      v_t_24154 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_24152 = heff_field(v_x_24147, 0);
      V v_xs_24153 = heff_field(v_x_24147, 1);
      heff_take_n(v_x_24147, 3ULL, 2);
      v_t_24154 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str49); V a_1 = v_x_24152; V a_2 = v_xs_24153; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24153); r_; });
      break;
    }
    default: heff_nomatch(v_x_24147);
    }
    V v_t_24155 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str50), heff_strAppend(v_t_24154, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str51)));
    V v_t_24156 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str52), heff_strAppend(v_t_24151, v_t_24155));
    V v_x_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){v_x_24157, v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str1, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str2, 6, "double");
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eckOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eckOf(V v_rs_240) {
top: ;
  return heff_rec_n(3, shape_exp__stmts__ctype, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam0, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam1, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam3, 1, 1, (V[]){heff_dup(v_rs_240)})});
}
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eckOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = ({ V a_0 = v_rs_240; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0)); heff_drop(v_rs_240); r_; });
  return (g_heff_2ecompile_2eemitc_2eexpF(v_t_242, v_e_241));
}
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_248));
    V v_x_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2411, v_s_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args) {
  V v_ss_243 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_k_244 = ({ V a_0 = v_rs_240; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0)); heff_drop(v_rs_240); r_; });
  V v_m_245 = (g_heff_2ecompile_2eemitc_2etraverseC_24s605634323x852551360(v_k_244, v_ss_243));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam2, 1, 1, (V[]){v_m_245});
}
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2413 = ({ V a_0 = v_x_2412; V a_1 = v_rs_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_rs_240); r_; });
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str0);
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    switch (heff_tag_of(v_x_2414)) {
    case TAG_RepV: {
      return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str1);
    }
    case TAG_RepFix: {
      V v_w_2415 = heff_field(v_x_2414, 0);
      heff_take_n(v_x_2414, 1ULL, 1);
      return ({ V a_0 = v_w_2415; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2415); r_; });
    }
    case TAG_RepF64: {
      return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str2);
    }
    default: return heff_nomatch(v_x_2414);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str0, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str1, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str5, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str6, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str9, 32, "static V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str11, 1, "\012");
Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eemitc_2etraverseC_24s44291070x1575844925(heff_dup(v_ce_244), v_defs_243));
  V v_t_246 = heff_tr(heff_call(v_t_245, 1, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkPair: {
    V v_ems_247 = heff_field(v_t_246, 0);
    V v_s_248 = heff_field(v_t_246, 1);
    V v_ru_24t_246_24MkPair = heff_take_reuse_n(v_t_246, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24t_246_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str0), heff_dup(heff_rfield(v_ending_242, 0))});
    V v_t_2410 = (g_map_2etoListOnto(heff_rfield(v_ce_244, 0), NTAG(TAG_Nil)));
    V v_t_2411 = (g_list_2efilter_24s1018181017x1541469354(v_t_2410));
    V v_t_2412 = (g_list_2emap_24s275211812x1381242052(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str1), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str2), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str3), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str4), v_t_2411));
    V v_t_2413 = (g_map_2etoListOnto(heff_rfield(v_ce_244, 1), NTAG(TAG_Nil)));
    V v_t_2414 = (g_list_2emap_24s275211812x1381242052(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str5), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str6), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str7), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str8), v_t_2413));
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
    V v_t_2416 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str9), NTAG(TAG_Nil)});
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 5)));
    V v_t_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 6)));
    V v_t_2421 = (g_list_2emap_24s1173914895x100384474(v_t_2420));
    V v_t_2422 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_map_2eempty_get()), v_t_2421));
    V v_t_2423 = (g_list_2emap_24s2073083146x1445066245(v_t_2422));
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_247)));
    V v_t_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s292588827x1477362994(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 3)));
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474(v_t_2426));
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 7)));
    V v_t_2429 = (g_list_2emap_24s1173914895x100384474(v_t_2428));
    V v_t_2430 = (g_list_2efoldl_24f96178826x1085061806(NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), v_t_2429));
    V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_247));
    V v_t_2433 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s1028839125x1033007016(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_248, 2, 8)));
    V v_t_2435 = (g_list_2emap_24s1173914895x100384474(v_t_2434));
    V v_t_2436 = heff_tr(heff_call(heff_get_n(v_ending_242, 1, 2), 1, (V[]){v_ce_244}));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2436));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2437));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2438));
    V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2439));
    V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2440));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2447));
    V v_x2_2449 = (g_prelude_2e_2b_2b(v_t_249, v_t_2448));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str10);
    }
    case TAG_Cons: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_xs_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str11); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str0, 11, "static V g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str1, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str2, 22, "static V heff_perform(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str3, 7, "static ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str4, 3, " g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str5, 11, "_init(void)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str6, 22, "static V heff_perform(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str7, 7, "static ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str8, 3, " g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str9, 22, "static V heff_perform(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str10, 7, "static ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str11, 3, " g_");
Clo g_heff_2ecompile_2eemitc_2epubLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epubLine_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2epubLine(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(11LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str0))) {
    V v_t_242 = heff_intSub(heff_strLength_lent(v_l_240, 0), MK_INT(5LL));
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), v_t_242, heff_strLength_lent(v_l_240, 0));
    if (heff_strEq_c(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2epubLine_str1))) {
      if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str2))) {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      } else {
        V v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str3); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str4); V a_2 = heff_dup(v_l_240); V a_3 = MK_INT(0LL); V b_4 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany_24s1182572632x117717553(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
        } else {
          heff_drop(v_t_246);
          return v_l_240;
        }
      }
    } else {
      if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2epubLine_str5), v_l_240, MK_INT(0LL), 5))) {
        if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str6))) {
          return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
        } else {
          V v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str7); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str8); V a_2 = heff_dup(v_l_240); V a_3 = MK_INT(0LL); V b_4 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany_24s1182572632x117717553(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
          } else {
            heff_drop(v_t_249);
            return v_l_240;
          }
        }
      } else {
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      }
    }
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str9))) {
      return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
    } else {
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str10); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str11); V a_2 = heff_dup(v_l_240); V a_3 = MK_INT(0LL); V b_4 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany_24s1182572632x117717553(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      } else {
        heff_drop(v_t_2411);
        return v_l_240;
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epubLine(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str0)));
    V v_o_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str1), v_t_247);
    V v_x2_249 = (g_map_2elookup_24s1546226666x2146984184(v_o_248, v_strs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take_n(v_x2_249, 1ULL, 1);
      v_t_2411 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str2)));
    V v_o_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str3), v_t_2412);
    V v_x2_2414 = (g_map_2elookup_24s1546226666x2146984184(v_o_2413, v_protos_242));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nothing: {
      v_t_2416 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      heff_take_n(v_x2_2414, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2417 = (g_list_2emap_24s380834591x871125279(v_t_2416));
    V v_t_2418 = (g_list_2emap_24f966602123x1640556393(MK_INT(7LL), heff_dup(heff_rfield(v_e_246, 0))));
    V v_t_2419 = (g_list_2emap_24s380834591x871125279(heff_dup(heff_rfield(v_e_246, 1))));
    V v_t_2420 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str4)));
    V v_o_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str5), v_t_2420);
    V v_x2_2422 = (g_map_2elookup_24s1546226666x2146984184(v_o_2421, v_lams_243));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nothing: {
      v_t_2424 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      heff_take_n(v_x2_2422, 1ULL, 1);
      v_t_2424 = v_x_2423;
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2425 = (g_list_2emap_24s380834591x871125279(v_t_2424));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2425));
    V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2426));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2427));
    return (g_prelude_2e_2b_2b(v_t_2411, v_t_2428));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eownLines(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryPart_str0, 10, "run$main.c");

static V g_heff_2ecompile_2eemitc_2eentryPart_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eentryPart_st;
static V g_heff_2ecompile_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eentryPart_str0);
}
V g_heff_2ecompile_2eemitc_2eentryPart_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eentryPart_st)) return g_heff_2ecompile_2eemitc_2eentryPart_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eentryPart_val, &g_heff_2ecompile_2eemitc_2eentryPart_st, g_heff_2ecompile_2eemitc_2eentryPart_init);
}