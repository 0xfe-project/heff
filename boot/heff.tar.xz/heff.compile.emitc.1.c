// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_MkCArm 24694
#define TAG_MkDrop 35958
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_TakeKeep 54413
#define TAG_TakeN 37047
#define TAG_TakeNone 22612
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_exp 310423
#define LBL_inLam 301681229
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_ret 322331
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_tuples 1084651734
static uint32_t shape_exp__stmts__ctype__tuples__ret__inLam[] = {LBL_exp, LBL_stmts, LBL_ctype, LBL_tuples, LBL_ret, LBL_inLam};
V g_heff_2ecompile_2eemitc_2eagainTo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagainTo_clo;
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2eletType(V, V, V);
V g_heff_2ecompile_2eemitc_2eletType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletType_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enomatchLine(V, V, V);
V g_heff_2ecompile_2eemitc_2enomatchLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enomatchLine_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etupleArm(V, V, V);
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleArm_clo;
V g_heff_2ecompile_2eemitc_2etupleTake(V, V, V);
V g_heff_2ecompile_2eemitc_2etupleTake_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleTake_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2erefcount_2epow2(V);
V g_heff_2ecompile_2erefcount_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epow2_clo;
V g_list_2eany_24s1182572632x117717553(V, V, V, V, V);
V g_list_2eany_24s1182572632x117717553_entry(V self, V *a);
extern Clo g_list_2eany_24s1182572632x117717553_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1546297617x1475313215(V, V, V, V, V, V);
V g_list_2emap_24f1546297617x1475313215_entry(V self, V *a);
extern Clo g_list_2emap_24f1546297617x1475313215_clo;
V g_list_2emap_24f966602123x1640556393(V, V);
V g_list_2emap_24f966602123x1640556393_entry(V self, V *a);
extern Clo g_list_2emap_24f966602123x1640556393_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s275211812x1381242052(V, V, V, V, V, V, V);
V g_list_2emap_24s275211812x1381242052_entry(V self, V *a);
extern Clo g_list_2emap_24s275211812x1381242052_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s457513469x1891643252(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s457513469x1891643252_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s457513469x1891643252_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_prelude_2etraverse_24s1370495575x1780346529(V, V);
V g_prelude_2etraverse_24s1370495575x1780346529_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1370495575x1780346529_clo;
V g_prelude_2etraverse_24s428640578x580976168(V, V);
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s428640578x580976168_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str0, 3, "InR");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str1, 6, "MkPair");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str2, 3, "InL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str3, 4, "Just");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str4, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str5, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str6, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str8, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str9, 4, "True");

static V g_heff_2ecompile_2eemitc_2eknownTags_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eknownTags_st;
static V g_heff_2ecompile_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eknownTags_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eknownTags_st)) return g_heff_2ecompile_2eemitc_2eknownTags_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eknownTags_val, &g_heff_2ecompile_2eemitc_2eknownTags_st, g_heff_2ecompile_2eemitc_2eknownTags_init);
}
Clo g_heff_2ecompile_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c_lent(v_o_240, v_o2_245, 0)) {
        if (heff_strEq_c_lent(v_k_241, v_k2_246, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eownHas(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str2, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str3, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str4, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str6, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str7, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str8, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str9, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str10, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str11, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str21, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str22, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str23, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str24, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str25, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str26, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str28, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str29, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str30, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str31, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str32, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str34, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str35, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str36, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str37, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str38, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str39, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str42, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str44, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str45, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str49, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str50, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str51, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str52, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str53, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str54, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str55, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str56, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str57, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str58, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str59, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str60, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str61, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str62, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str63, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str64, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str65, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str66, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str67, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str68, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str69, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str70, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str71, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str72, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str73, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str74, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str75, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str76, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str77, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str78, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str79, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str80, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str81, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str82, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str83, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str84, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str85, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str86, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str87, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str88, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str89, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str90, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str91, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str92, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str93, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str94, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str95, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str96, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str97, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str98, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str99, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str100, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str101, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str102, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str103, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str104, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str105, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str106, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str107, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str108, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str109, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str110, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str111, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str112, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str113, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str114, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str115, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str116, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str117, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str118, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str119, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str120, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str121, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str122, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str123, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str124, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str125, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str126, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str127, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str128, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str129, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str130, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str131, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str132, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str133, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str134, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str135, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str136, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str138, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str139, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str140, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str141, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str142, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str143, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str144, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str145, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str146, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str147, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str148, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str149, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str150, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str151, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str152, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str153, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str154, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str155, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str156, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str157, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str158, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str159, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str160, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str161, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str162, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str163, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str164, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str165, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str166, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str167, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str168, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str169, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str170, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str171, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str172, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str173, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str174, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str175, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str176, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str177, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str178, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str179, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str180, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str181, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str182, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str183, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str184, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str185, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str186, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str187, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str188, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str189, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str190, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str191, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str192, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str193, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str194, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str195, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str196, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str197, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str198, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str199, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str200, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str201, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str202, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str203, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str204, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str205, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str206, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str207, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str208, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str209, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str210, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str211, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str212, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str213, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str214, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str215, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str216, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str217, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str218, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str219, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str220, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str221, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str222, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str223, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str224, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str225, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str226, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str227, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str228, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str229, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str230, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str231, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str232, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str233, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str234, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str235, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str236, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str238, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str239, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str240, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str241, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str242, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str243, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str244, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str245, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str246, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str247, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str248, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str249, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str250, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str251, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str252, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str253, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str254, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str255, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str256, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str257, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str258, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str259, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str260, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str261, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str262, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str263, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str264, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str265, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str266, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str267, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str268, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str269, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str270, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str271, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str272, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str273, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str274, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str275, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str276, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str277, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str278, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str279, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str280, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str281, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str282, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str283, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str284, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str285, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str286, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str287, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str288, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str289, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str290, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str291, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str292, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str293, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str294, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str295, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str296, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str297, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str298, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str299, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str300, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str301, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str302, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str303, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str304, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str305, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str306, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str307, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str308, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str309, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str310, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str311, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str312, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str313, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str314, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str315, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str316, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str317, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str318, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str319, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str320, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str321, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str322, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str323, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str324, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str325, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str326, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str327, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str328, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str329, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str330, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str331, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str332, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str333, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str334, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str335, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str336, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str337, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str338, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str339, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str340, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str341, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str342, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str343, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str344, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str345, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str346, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str347, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str348, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str349, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str350, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str351, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str352, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str353, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str354, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str355, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str356, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str357, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str358, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str359, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str360, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str361, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str362, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str363, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str364, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str365, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str366, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str367, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str368, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str369, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str370, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str371, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str372, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str373, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str374, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str375, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str376, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str377, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str378, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str379, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str380, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str381, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str382, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str383, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str384, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str385, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str386, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str387, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str388, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str389, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str390, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str391, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str392, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str393, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str394, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str395, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str396, 17, "heff_from_int_f32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str397, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str398, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str399, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str400, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str401, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str402, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str403, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str404, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str405, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str406, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str407, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str408, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str409, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str410, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str411, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str412, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str413, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str414, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str415, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str416, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str417, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str418, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str419, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str420, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str421, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str422, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str423, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str424, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str425, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str426, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str427, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str428, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str429, 5, "sqrtf");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str430, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str431, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str432, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str433, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str434, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str435, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str436, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str437, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str438, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str439, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str440, 14, "heff_floor_f32");
Clo g_heff_2ecompile_2eemitc_2efloat32U_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efloat32U_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efloat32U(V v_op_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    V v_t_244;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_242 = heff_field(v_vs_241, 0);
      v_t_244 = heff_dup(v_x_242);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_245;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str1);
      break;
    }
    case TAG_OpSub: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str2);
      break;
    }
    case TAG_OpMul: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str3);
      break;
    }
    case TAG_OpDiv: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str4);
      break;
    }
    case TAG_OpRem: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str5);
      break;
    }
    case TAG_OpEq: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str6);
      break;
    }
    case TAG_OpLt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str7);
      break;
    }
    case TAG_OpLe: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str8);
      break;
    }
    case TAG_OpAnd: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str9);
      break;
    }
    case TAG_OpOr: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str10);
      break;
    }
    case TAG_OpXor: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str11);
      break;
    }
    case TAG_OpShl: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str12);
      break;
    }
    case TAG_OpShr: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str13);
      break;
    }
    case TAG_OpShow: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str14);
      break;
    }
    case TAG_OpFromInt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str15);
      break;
    }
    case TAG_OpToInt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str16);
      break;
    }
    case TAG_OpSqrt: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str17);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str18);
      break;
    }
    case TAG_OpToFloat: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str19);
      break;
    }
    case TAG_OpFloor: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str20);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_246 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2413;
    {
      V v_field_248 = v_t_246.f[1];
      V v_field_249 = v_t_246.f[2];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_248;
        V v_x12_2412 = v_field_249;
        heff_drop(v_x12_2412);
        v_t_2413 = v_x_2411;
      } else {
        heff_drop(v_field_248);
        heff_drop(v_field_249);
        v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str21);
      }
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str22), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str23)));
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str24), heff_strAppend(v_t_245, v_t_2414));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str25), heff_strAppend(v_t_244, v_t_2415));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str26), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str27)));
  }
  case TAG_OpSub: {
    V v_t_2419;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str28);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_vs_241, 0);
      v_t_2419 = heff_dup(v_x_2417);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2420;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str29);
      break;
    }
    case TAG_OpSub: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str30);
      break;
    }
    case TAG_OpMul: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str31);
      break;
    }
    case TAG_OpDiv: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str32);
      break;
    }
    case TAG_OpRem: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str33);
      break;
    }
    case TAG_OpEq: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str34);
      break;
    }
    case TAG_OpLt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str35);
      break;
    }
    case TAG_OpLe: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str36);
      break;
    }
    case TAG_OpAnd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str37);
      break;
    }
    case TAG_OpOr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str38);
      break;
    }
    case TAG_OpXor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str39);
      break;
    }
    case TAG_OpShl: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str40);
      break;
    }
    case TAG_OpShr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str41);
      break;
    }
    case TAG_OpShow: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str42);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str43);
      break;
    }
    case TAG_OpToInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str44);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str45);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str46);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str47);
      break;
    }
    case TAG_OpFloor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str48);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2421 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2428;
    {
      V v_field_2423 = v_t_2421.f[1];
      V v_field_2424 = v_t_2421.f[2];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_x_2426 = v_field_2423;
        V v_x12_2427 = v_field_2424;
        heff_drop(v_x12_2427);
        v_t_2428 = v_x_2426;
      } else {
        heff_drop(v_field_2423);
        heff_drop(v_field_2424);
        v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str49);
      }
    }
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str50), heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str51)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str52), heff_strAppend(v_t_2420, v_t_2429));
    V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str53), heff_strAppend(v_t_2419, v_t_2430));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str54), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str55)));
  }
  case TAG_OpMul: {
    V v_t_2434;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str56);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_vs_241, 0);
      v_t_2434 = heff_dup(v_x_2432);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2435;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str57);
      break;
    }
    case TAG_OpSub: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str58);
      break;
    }
    case TAG_OpMul: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str59);
      break;
    }
    case TAG_OpDiv: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str60);
      break;
    }
    case TAG_OpRem: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str61);
      break;
    }
    case TAG_OpEq: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str62);
      break;
    }
    case TAG_OpLt: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str63);
      break;
    }
    case TAG_OpLe: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str64);
      break;
    }
    case TAG_OpAnd: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str65);
      break;
    }
    case TAG_OpOr: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str66);
      break;
    }
    case TAG_OpXor: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str67);
      break;
    }
    case TAG_OpShl: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str68);
      break;
    }
    case TAG_OpShr: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str69);
      break;
    }
    case TAG_OpShow: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str70);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str71);
      break;
    }
    case TAG_OpToInt: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str72);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str73);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str74);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str75);
      break;
    }
    case TAG_OpFloor: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str76);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2436 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2443;
    {
      V v_field_2438 = v_t_2436.f[1];
      V v_field_2439 = v_t_2436.f[2];
      int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
      if ((v_tag_2437 == ((int64_t)0ULL))) {
        V v_x_2441 = v_field_2438;
        V v_x12_2442 = v_field_2439;
        heff_drop(v_x12_2442);
        v_t_2443 = v_x_2441;
      } else {
        heff_drop(v_field_2438);
        heff_drop(v_field_2439);
        v_t_2443 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str77);
      }
    }
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str78), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str79)));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str80), heff_strAppend(v_t_2435, v_t_2444));
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str81), heff_strAppend(v_t_2434, v_t_2445));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str82), heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str83)));
  }
  case TAG_OpDiv: {
    V v_t_2449;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str84);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_vs_241, 0);
      v_t_2449 = heff_dup(v_x_2447);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2450;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str85);
      break;
    }
    case TAG_OpSub: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str86);
      break;
    }
    case TAG_OpMul: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str87);
      break;
    }
    case TAG_OpDiv: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str88);
      break;
    }
    case TAG_OpRem: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str89);
      break;
    }
    case TAG_OpEq: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str90);
      break;
    }
    case TAG_OpLt: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str91);
      break;
    }
    case TAG_OpLe: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str92);
      break;
    }
    case TAG_OpAnd: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str93);
      break;
    }
    case TAG_OpOr: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str94);
      break;
    }
    case TAG_OpXor: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str95);
      break;
    }
    case TAG_OpShl: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str96);
      break;
    }
    case TAG_OpShr: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str97);
      break;
    }
    case TAG_OpShow: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str98);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str99);
      break;
    }
    case TAG_OpToInt: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str100);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str101);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str102);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str103);
      break;
    }
    case TAG_OpFloor: {
      v_t_2450 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str104);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2451 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2458;
    {
      V v_field_2453 = v_t_2451.f[1];
      V v_field_2454 = v_t_2451.f[2];
      int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
      if ((v_tag_2452 == ((int64_t)0ULL))) {
        V v_x_2456 = v_field_2453;
        V v_x12_2457 = v_field_2454;
        heff_drop(v_x12_2457);
        v_t_2458 = v_x_2456;
      } else {
        heff_drop(v_field_2453);
        heff_drop(v_field_2454);
        v_t_2458 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str105);
      }
    }
    V v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str106), heff_strAppend(v_t_2458, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str107)));
    V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str108), heff_strAppend(v_t_2450, v_t_2459));
    V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str109), heff_strAppend(v_t_2449, v_t_2460));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str110), heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str111)));
  }
  case TAG_OpRem: {
    V v_t_2464;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2464 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str112);
      break;
    }
    case TAG_Cons: {
      V v_x_2462 = heff_field(v_vs_241, 0);
      v_t_2464 = heff_dup(v_x_2462);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2465;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str113);
      break;
    }
    case TAG_OpSub: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str114);
      break;
    }
    case TAG_OpMul: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str115);
      break;
    }
    case TAG_OpDiv: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str116);
      break;
    }
    case TAG_OpRem: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str117);
      break;
    }
    case TAG_OpEq: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str118);
      break;
    }
    case TAG_OpLt: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str119);
      break;
    }
    case TAG_OpLe: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str120);
      break;
    }
    case TAG_OpAnd: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str121);
      break;
    }
    case TAG_OpOr: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str122);
      break;
    }
    case TAG_OpXor: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str123);
      break;
    }
    case TAG_OpShl: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str124);
      break;
    }
    case TAG_OpShr: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str125);
      break;
    }
    case TAG_OpShow: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str126);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str127);
      break;
    }
    case TAG_OpToInt: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str128);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str129);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str130);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str131);
      break;
    }
    case TAG_OpFloor: {
      v_t_2465 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str132);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2466 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2473;
    {
      V v_field_2468 = v_t_2466.f[1];
      V v_field_2469 = v_t_2466.f[2];
      int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
      if ((v_tag_2467 == ((int64_t)0ULL))) {
        V v_x_2471 = v_field_2468;
        V v_x12_2472 = v_field_2469;
        heff_drop(v_x12_2472);
        v_t_2473 = v_x_2471;
      } else {
        heff_drop(v_field_2468);
        heff_drop(v_field_2469);
        v_t_2473 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str133);
      }
    }
    V v_t_2474 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str134), heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str135)));
    V v_t_2475 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str136), heff_strAppend(v_t_2465, v_t_2474));
    V v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str137), heff_strAppend(v_t_2464, v_t_2475));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str138), heff_strAppend(v_t_2476, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str139)));
  }
  case TAG_OpEq: {
    V v_t_2479;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2479 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str140);
      break;
    }
    case TAG_Cons: {
      V v_x_2477 = heff_field(v_vs_241, 0);
      v_t_2479 = heff_dup(v_x_2477);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2480;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str141);
      break;
    }
    case TAG_OpSub: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str142);
      break;
    }
    case TAG_OpMul: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str143);
      break;
    }
    case TAG_OpDiv: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str144);
      break;
    }
    case TAG_OpRem: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str145);
      break;
    }
    case TAG_OpEq: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str146);
      break;
    }
    case TAG_OpLt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str147);
      break;
    }
    case TAG_OpLe: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str148);
      break;
    }
    case TAG_OpAnd: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str149);
      break;
    }
    case TAG_OpOr: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str150);
      break;
    }
    case TAG_OpXor: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str151);
      break;
    }
    case TAG_OpShl: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str152);
      break;
    }
    case TAG_OpShr: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str153);
      break;
    }
    case TAG_OpShow: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str154);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str155);
      break;
    }
    case TAG_OpToInt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str156);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str157);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str158);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str159);
      break;
    }
    case TAG_OpFloor: {
      v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str160);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2481 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2488;
    {
      V v_field_2483 = v_t_2481.f[1];
      V v_field_2484 = v_t_2481.f[2];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        V v_x_2486 = v_field_2483;
        V v_x12_2487 = v_field_2484;
        heff_drop(v_x12_2487);
        v_t_2488 = v_x_2486;
      } else {
        heff_drop(v_field_2483);
        heff_drop(v_field_2484);
        v_t_2488 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str161);
      }
    }
    V v_t_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str162), heff_strAppend(v_t_2488, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str163)));
    V v_t_2490 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str164), heff_strAppend(v_t_2480, v_t_2489));
    V v_t_2491 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str165), heff_strAppend(v_t_2479, v_t_2490));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str166), heff_strAppend(v_t_2491, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str167)));
  }
  case TAG_OpLt: {
    V v_t_2494;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2494 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str168);
      break;
    }
    case TAG_Cons: {
      V v_x_2492 = heff_field(v_vs_241, 0);
      v_t_2494 = heff_dup(v_x_2492);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2495;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str169);
      break;
    }
    case TAG_OpSub: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str170);
      break;
    }
    case TAG_OpMul: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str171);
      break;
    }
    case TAG_OpDiv: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str172);
      break;
    }
    case TAG_OpRem: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str173);
      break;
    }
    case TAG_OpEq: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str174);
      break;
    }
    case TAG_OpLt: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str175);
      break;
    }
    case TAG_OpLe: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str176);
      break;
    }
    case TAG_OpAnd: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str177);
      break;
    }
    case TAG_OpOr: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str178);
      break;
    }
    case TAG_OpXor: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str179);
      break;
    }
    case TAG_OpShl: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str180);
      break;
    }
    case TAG_OpShr: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str181);
      break;
    }
    case TAG_OpShow: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str182);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str183);
      break;
    }
    case TAG_OpToInt: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str184);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str185);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str186);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str187);
      break;
    }
    case TAG_OpFloor: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str188);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2496 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24103;
    {
      V v_field_2498 = v_t_2496.f[1];
      V v_field_2499 = v_t_2496.f[2];
      int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
      if ((v_tag_2497 == ((int64_t)0ULL))) {
        V v_x_24101 = v_field_2498;
        V v_x12_24102 = v_field_2499;
        heff_drop(v_x12_24102);
        v_t_24103 = v_x_24101;
      } else {
        heff_drop(v_field_2498);
        heff_drop(v_field_2499);
        v_t_24103 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str189);
      }
    }
    V v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str190), heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str191)));
    V v_t_24105 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str192), heff_strAppend(v_t_2495, v_t_24104));
    V v_t_24106 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str193), heff_strAppend(v_t_2494, v_t_24105));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str194), heff_strAppend(v_t_24106, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str195)));
  }
  case TAG_OpLe: {
    V v_t_24109;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24109 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str196);
      break;
    }
    case TAG_Cons: {
      V v_x_24107 = heff_field(v_vs_241, 0);
      v_t_24109 = heff_dup(v_x_24107);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24110;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str197);
      break;
    }
    case TAG_OpSub: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str198);
      break;
    }
    case TAG_OpMul: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str199);
      break;
    }
    case TAG_OpDiv: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str200);
      break;
    }
    case TAG_OpRem: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str201);
      break;
    }
    case TAG_OpEq: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str202);
      break;
    }
    case TAG_OpLt: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str203);
      break;
    }
    case TAG_OpLe: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str204);
      break;
    }
    case TAG_OpAnd: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str205);
      break;
    }
    case TAG_OpOr: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str206);
      break;
    }
    case TAG_OpXor: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str207);
      break;
    }
    case TAG_OpShl: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str208);
      break;
    }
    case TAG_OpShr: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str209);
      break;
    }
    case TAG_OpShow: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str210);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str211);
      break;
    }
    case TAG_OpToInt: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str212);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str213);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str214);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str215);
      break;
    }
    case TAG_OpFloor: {
      v_t_24110 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str216);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24111 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24118;
    {
      V v_field_24113 = v_t_24111.f[1];
      V v_field_24114 = v_t_24111.f[2];
      int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
      if ((v_tag_24112 == ((int64_t)0ULL))) {
        V v_x_24116 = v_field_24113;
        V v_x12_24117 = v_field_24114;
        heff_drop(v_x12_24117);
        v_t_24118 = v_x_24116;
      } else {
        heff_drop(v_field_24113);
        heff_drop(v_field_24114);
        v_t_24118 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str217);
      }
    }
    V v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str218), heff_strAppend(v_t_24118, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str219)));
    V v_t_24120 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str220), heff_strAppend(v_t_24110, v_t_24119));
    V v_t_24121 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str221), heff_strAppend(v_t_24109, v_t_24120));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str222), heff_strAppend(v_t_24121, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str223)));
  }
  case TAG_OpAnd: {
    V v_t_24124;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24124 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str224);
      break;
    }
    case TAG_Cons: {
      V v_x_24122 = heff_field(v_vs_241, 0);
      v_t_24124 = heff_dup(v_x_24122);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24125;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str225);
      break;
    }
    case TAG_OpSub: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str226);
      break;
    }
    case TAG_OpMul: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str227);
      break;
    }
    case TAG_OpDiv: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str228);
      break;
    }
    case TAG_OpRem: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str229);
      break;
    }
    case TAG_OpEq: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str230);
      break;
    }
    case TAG_OpLt: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str231);
      break;
    }
    case TAG_OpLe: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str232);
      break;
    }
    case TAG_OpAnd: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str233);
      break;
    }
    case TAG_OpOr: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str234);
      break;
    }
    case TAG_OpXor: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str235);
      break;
    }
    case TAG_OpShl: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str236);
      break;
    }
    case TAG_OpShr: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str237);
      break;
    }
    case TAG_OpShow: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str238);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str239);
      break;
    }
    case TAG_OpToInt: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str240);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str241);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str242);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str243);
      break;
    }
    case TAG_OpFloor: {
      v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str244);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24126 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24133;
    {
      V v_field_24128 = v_t_24126.f[1];
      V v_field_24129 = v_t_24126.f[2];
      int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
      if ((v_tag_24127 == ((int64_t)0ULL))) {
        V v_x_24131 = v_field_24128;
        V v_x12_24132 = v_field_24129;
        heff_drop(v_x12_24132);
        v_t_24133 = v_x_24131;
      } else {
        heff_drop(v_field_24128);
        heff_drop(v_field_24129);
        v_t_24133 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str245);
      }
    }
    V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str246), heff_strAppend(v_t_24133, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str247)));
    V v_t_24135 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str248), heff_strAppend(v_t_24125, v_t_24134));
    V v_t_24136 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str249), heff_strAppend(v_t_24124, v_t_24135));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str250), heff_strAppend(v_t_24136, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str251)));
  }
  case TAG_OpOr: {
    V v_t_24139;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24139 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str252);
      break;
    }
    case TAG_Cons: {
      V v_x_24137 = heff_field(v_vs_241, 0);
      v_t_24139 = heff_dup(v_x_24137);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24140;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str253);
      break;
    }
    case TAG_OpSub: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str254);
      break;
    }
    case TAG_OpMul: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str255);
      break;
    }
    case TAG_OpDiv: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str256);
      break;
    }
    case TAG_OpRem: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str257);
      break;
    }
    case TAG_OpEq: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str258);
      break;
    }
    case TAG_OpLt: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str259);
      break;
    }
    case TAG_OpLe: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str260);
      break;
    }
    case TAG_OpAnd: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str261);
      break;
    }
    case TAG_OpOr: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str262);
      break;
    }
    case TAG_OpXor: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str263);
      break;
    }
    case TAG_OpShl: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str264);
      break;
    }
    case TAG_OpShr: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str265);
      break;
    }
    case TAG_OpShow: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str266);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str267);
      break;
    }
    case TAG_OpToInt: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str268);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str269);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str270);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str271);
      break;
    }
    case TAG_OpFloor: {
      v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str272);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24141 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24148;
    {
      V v_field_24143 = v_t_24141.f[1];
      V v_field_24144 = v_t_24141.f[2];
      int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
      if ((v_tag_24142 == ((int64_t)0ULL))) {
        V v_x_24146 = v_field_24143;
        V v_x12_24147 = v_field_24144;
        heff_drop(v_x12_24147);
        v_t_24148 = v_x_24146;
      } else {
        heff_drop(v_field_24143);
        heff_drop(v_field_24144);
        v_t_24148 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str273);
      }
    }
    V v_t_24149 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str274), heff_strAppend(v_t_24148, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str275)));
    V v_t_24150 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str276), heff_strAppend(v_t_24140, v_t_24149));
    V v_t_24151 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str277), heff_strAppend(v_t_24139, v_t_24150));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str278), heff_strAppend(v_t_24151, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str279)));
  }
  case TAG_OpXor: {
    V v_t_24154;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24154 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str280);
      break;
    }
    case TAG_Cons: {
      V v_x_24152 = heff_field(v_vs_241, 0);
      v_t_24154 = heff_dup(v_x_24152);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24155;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str281);
      break;
    }
    case TAG_OpSub: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str282);
      break;
    }
    case TAG_OpMul: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str283);
      break;
    }
    case TAG_OpDiv: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str284);
      break;
    }
    case TAG_OpRem: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str285);
      break;
    }
    case TAG_OpEq: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str286);
      break;
    }
    case TAG_OpLt: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str287);
      break;
    }
    case TAG_OpLe: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str288);
      break;
    }
    case TAG_OpAnd: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str289);
      break;
    }
    case TAG_OpOr: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str290);
      break;
    }
    case TAG_OpXor: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str291);
      break;
    }
    case TAG_OpShl: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str292);
      break;
    }
    case TAG_OpShr: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str293);
      break;
    }
    case TAG_OpShow: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str294);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str295);
      break;
    }
    case TAG_OpToInt: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str296);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str297);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str298);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str299);
      break;
    }
    case TAG_OpFloor: {
      v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str300);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24156 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24163;
    {
      V v_field_24158 = v_t_24156.f[1];
      V v_field_24159 = v_t_24156.f[2];
      int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
      if ((v_tag_24157 == ((int64_t)0ULL))) {
        V v_x_24161 = v_field_24158;
        V v_x12_24162 = v_field_24159;
        heff_drop(v_x12_24162);
        v_t_24163 = v_x_24161;
      } else {
        heff_drop(v_field_24158);
        heff_drop(v_field_24159);
        v_t_24163 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str301);
      }
    }
    V v_t_24164 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str302), heff_strAppend(v_t_24163, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str303)));
    V v_t_24165 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str304), heff_strAppend(v_t_24155, v_t_24164));
    V v_t_24166 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str305), heff_strAppend(v_t_24154, v_t_24165));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str306), heff_strAppend(v_t_24166, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str307)));
  }
  case TAG_OpShl: {
    V v_t_24169;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24169 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str308);
      break;
    }
    case TAG_Cons: {
      V v_x_24167 = heff_field(v_vs_241, 0);
      v_t_24169 = heff_dup(v_x_24167);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24170;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str309);
      break;
    }
    case TAG_OpSub: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str310);
      break;
    }
    case TAG_OpMul: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str311);
      break;
    }
    case TAG_OpDiv: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str312);
      break;
    }
    case TAG_OpRem: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str313);
      break;
    }
    case TAG_OpEq: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str314);
      break;
    }
    case TAG_OpLt: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str315);
      break;
    }
    case TAG_OpLe: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str316);
      break;
    }
    case TAG_OpAnd: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str317);
      break;
    }
    case TAG_OpOr: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str318);
      break;
    }
    case TAG_OpXor: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str319);
      break;
    }
    case TAG_OpShl: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str320);
      break;
    }
    case TAG_OpShr: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str321);
      break;
    }
    case TAG_OpShow: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str322);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str323);
      break;
    }
    case TAG_OpToInt: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str324);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str325);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str326);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str327);
      break;
    }
    case TAG_OpFloor: {
      v_t_24170 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str328);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24171 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24178;
    {
      V v_field_24173 = v_t_24171.f[1];
      V v_field_24174 = v_t_24171.f[2];
      int64_t v_tag_24172 = ((int64_t)v_t_24171.f[0]);
      if ((v_tag_24172 == ((int64_t)0ULL))) {
        V v_x_24176 = v_field_24173;
        V v_x12_24177 = v_field_24174;
        heff_drop(v_x12_24177);
        v_t_24178 = v_x_24176;
      } else {
        heff_drop(v_field_24173);
        heff_drop(v_field_24174);
        v_t_24178 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str329);
      }
    }
    V v_t_24179 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str330), heff_strAppend(v_t_24178, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str331)));
    V v_t_24180 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str332), heff_strAppend(v_t_24170, v_t_24179));
    V v_t_24181 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str333), heff_strAppend(v_t_24169, v_t_24180));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str334), heff_strAppend(v_t_24181, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str335)));
  }
  case TAG_OpShr: {
    V v_t_24184;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24184 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str336);
      break;
    }
    case TAG_Cons: {
      V v_x_24182 = heff_field(v_vs_241, 0);
      v_t_24184 = heff_dup(v_x_24182);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24185;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str337);
      break;
    }
    case TAG_OpSub: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str338);
      break;
    }
    case TAG_OpMul: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str339);
      break;
    }
    case TAG_OpDiv: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str340);
      break;
    }
    case TAG_OpRem: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str341);
      break;
    }
    case TAG_OpEq: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str342);
      break;
    }
    case TAG_OpLt: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str343);
      break;
    }
    case TAG_OpLe: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str344);
      break;
    }
    case TAG_OpAnd: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str345);
      break;
    }
    case TAG_OpOr: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str346);
      break;
    }
    case TAG_OpXor: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str347);
      break;
    }
    case TAG_OpShl: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str348);
      break;
    }
    case TAG_OpShr: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str349);
      break;
    }
    case TAG_OpShow: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str350);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str351);
      break;
    }
    case TAG_OpToInt: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str352);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str353);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str354);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str355);
      break;
    }
    case TAG_OpFloor: {
      v_t_24185 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str356);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24186 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24193;
    {
      V v_field_24188 = v_t_24186.f[1];
      V v_field_24189 = v_t_24186.f[2];
      int64_t v_tag_24187 = ((int64_t)v_t_24186.f[0]);
      if ((v_tag_24187 == ((int64_t)0ULL))) {
        V v_x_24191 = v_field_24188;
        V v_x12_24192 = v_field_24189;
        heff_drop(v_x12_24192);
        v_t_24193 = v_x_24191;
      } else {
        heff_drop(v_field_24188);
        heff_drop(v_field_24189);
        v_t_24193 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str357);
      }
    }
    V v_t_24194 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str358), heff_strAppend(v_t_24193, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str359)));
    V v_t_24195 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str360), heff_strAppend(v_t_24185, v_t_24194));
    V v_t_24196 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str361), heff_strAppend(v_t_24184, v_t_24195));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str362), heff_strAppend(v_t_24196, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str363)));
  }
  case TAG_OpShow: {
    V v_t_24199;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24199 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str364);
      break;
    }
    case TAG_Cons: {
      V v_x_24197 = heff_field(v_vs_241, 0);
      v_t_24199 = heff_dup(v_x_24197);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24200;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str365);
      break;
    }
    case TAG_OpSub: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str366);
      break;
    }
    case TAG_OpMul: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str367);
      break;
    }
    case TAG_OpDiv: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str368);
      break;
    }
    case TAG_OpRem: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str369);
      break;
    }
    case TAG_OpEq: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str370);
      break;
    }
    case TAG_OpLt: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str371);
      break;
    }
    case TAG_OpLe: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str372);
      break;
    }
    case TAG_OpAnd: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str373);
      break;
    }
    case TAG_OpOr: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str374);
      break;
    }
    case TAG_OpXor: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str375);
      break;
    }
    case TAG_OpShl: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str376);
      break;
    }
    case TAG_OpShr: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str377);
      break;
    }
    case TAG_OpShow: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str378);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str379);
      break;
    }
    case TAG_OpToInt: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str380);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str381);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str382);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str383);
      break;
    }
    case TAG_OpFloor: {
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str384);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24201 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24208;
    {
      V v_field_24203 = v_t_24201.f[1];
      V v_field_24204 = v_t_24201.f[2];
      int64_t v_tag_24202 = ((int64_t)v_t_24201.f[0]);
      if ((v_tag_24202 == ((int64_t)0ULL))) {
        V v_x_24206 = v_field_24203;
        V v_x12_24207 = v_field_24204;
        heff_drop(v_x12_24207);
        v_t_24208 = v_x_24206;
      } else {
        heff_drop(v_field_24203);
        heff_drop(v_field_24204);
        v_t_24208 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str385);
      }
    }
    V v_t_24209 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str386), heff_strAppend(v_t_24208, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str387)));
    V v_t_24210 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str388), heff_strAppend(v_t_24200, v_t_24209));
    V v_t_24211 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str389), heff_strAppend(v_t_24199, v_t_24210));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str390), heff_strAppend(v_t_24211, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str391)));
  }
  case TAG_OpFromInt: {
    V v_t_24214;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24214 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str392);
      break;
    }
    case TAG_Cons: {
      V v_x_24212 = heff_field(v_vs_241, 0);
      V v_xs_24213 = heff_field(v_vs_241, 1);
      v_t_24214 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str393), heff_dup(v_x_24212), v_xs_24213));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str394), heff_strAppend(v_t_24214, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str395)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str396), v_t_24215);
  }
  case TAG_OpToInt: {
    V v_t_24218;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str397);
      break;
    }
    case TAG_Cons: {
      V v_x_24216 = heff_field(v_vs_241, 0);
      v_t_24218 = heff_dup(v_x_24216);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24219;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str398);
      break;
    }
    case TAG_OpSub: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str399);
      break;
    }
    case TAG_OpMul: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str400);
      break;
    }
    case TAG_OpDiv: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str401);
      break;
    }
    case TAG_OpRem: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str402);
      break;
    }
    case TAG_OpEq: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str403);
      break;
    }
    case TAG_OpLt: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str404);
      break;
    }
    case TAG_OpLe: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str405);
      break;
    }
    case TAG_OpAnd: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str406);
      break;
    }
    case TAG_OpOr: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str407);
      break;
    }
    case TAG_OpXor: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str408);
      break;
    }
    case TAG_OpShl: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str409);
      break;
    }
    case TAG_OpShr: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str410);
      break;
    }
    case TAG_OpShow: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str411);
      break;
    }
    case TAG_OpFromInt: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str412);
      break;
    }
    case TAG_OpToInt: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str413);
      break;
    }
    case TAG_OpSqrt: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str414);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str415);
      break;
    }
    case TAG_OpToFloat: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str416);
      break;
    }
    case TAG_OpFloor: {
      v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str417);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_24220 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_24227;
    {
      V v_field_24222 = v_t_24220.f[1];
      V v_field_24223 = v_t_24220.f[2];
      int64_t v_tag_24221 = ((int64_t)v_t_24220.f[0]);
      if ((v_tag_24221 == ((int64_t)0ULL))) {
        V v_x_24225 = v_field_24222;
        V v_x12_24226 = v_field_24223;
        heff_drop(v_x12_24226);
        v_t_24227 = v_x_24225;
      } else {
        heff_drop(v_field_24222);
        heff_drop(v_field_24223);
        v_t_24227 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str418);
      }
    }
    V v_t_24228 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str419), heff_strAppend(v_t_24227, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str420)));
    V v_t_24229 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str421), heff_strAppend(v_t_24219, v_t_24228));
    V v_t_24230 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str422), heff_strAppend(v_t_24218, v_t_24229));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str423), heff_strAppend(v_t_24230, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str424)));
  }
  case TAG_OpSqrt: {
    V v_t_24233;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24233 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str425);
      break;
    }
    case TAG_Cons: {
      V v_x_24231 = heff_field(v_vs_241, 0);
      V v_xs_24232 = heff_field(v_vs_241, 1);
      v_t_24233 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str426), heff_dup(v_x_24231), v_xs_24232));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24234 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str427), heff_strAppend(v_t_24233, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str428)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str429), v_t_24234);
  }
  case TAG_OpFromFloat: {
    V v_t_24237;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24237 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str430);
      break;
    }
    case TAG_Cons: {
      V v_x_24235 = heff_field(v_vs_241, 0);
      v_t_24237 = heff_dup(v_x_24235);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str431), heff_strAppend(v_t_24237, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str432)));
  }
  case TAG_OpToFloat: {
    V v_t_24240;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24240 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str433);
      break;
    }
    case TAG_Cons: {
      V v_x_24238 = heff_field(v_vs_241, 0);
      v_t_24240 = heff_dup(v_x_24238);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str434), heff_strAppend(v_t_24240, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str435)));
  }
  case TAG_OpFloor: {
    V v_t_24243;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_24243 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str436);
      break;
    }
    case TAG_Cons: {
      V v_x_24241 = heff_field(v_vs_241, 0);
      V v_xs_24242 = heff_field(v_vs_241, 1);
      v_t_24243 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str437), heff_dup(v_x_24241), v_xs_24242));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_24244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str438), heff_strAppend(v_t_24243, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str439)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str440), v_t_24244);
  }
  default: return heff_nomatch(v_op_240);
  }
}
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2efloat32U(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str0, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str1, 19, "(V self, V *args) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str2, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str5, 8, " = args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str6, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str7, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str8, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str10, 18, " = heff_env(self)[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str12, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str13, 22, "  heff_clo_take(self, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str14, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str15, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2elamLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_body_243) {
top: ;
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str0), heff_strAppend(v_k_240, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str1)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(1LL))));
  V v_t_248 = (g_list_2ezipWith_24s457513469x1891643252(((V)&g_heff_2ecompile_2eemitc_2elamLines_str2), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str4), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str5), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str6), v_xs_241, v_t_247));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fv_242));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
  V v_t_2411 = (g_list_2ezipWith_24s457513469x1891643252(((V)&g_heff_2ecompile_2eemitc_2elamLines_str7), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str8), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str9), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str10), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str11), heff_dup(v_fv_242), v_t_2410));
  V v_t_2416;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2415 = heff_strAppend(heff_intShow(v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str12));
    v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str13), v_t_2415), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elamLines_str14), NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str15), v_body_243));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2419));
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_248, v_t_2420));
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2421));
}
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleTake_str0, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleTake_str1, 3, ".f[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleTake_str2, 3, "]);");
V g_heff_2ecompile_2eemitc_2etupleTake_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etupleTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etupleTake_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2etupleTake(V v_sv_240, V v_kinds_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_TakeNone: {
    heff_drop(v_sv_240);
    return NTAG(TAG_Nil);
  }
  case TAG_TakeN: {
    V v_mask_244 = heff_field(v_t_242, 1);
    V v_n_245 = heff_field(v_t_242, 2);
    V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(heff_dup(v_n_245), MK_INT(1LL))));
    return (g_list_2emap_24f1546297617x1475313215(((V)&g_heff_2ecompile_2eemitc_2etupleTake_str0), v_sv_240, ((V)&g_heff_2ecompile_2eemitc_2etupleTake_str1), ((V)&g_heff_2ecompile_2eemitc_2etupleTake_str2), heff_clo_n(g_heff_2ecompile_2eemitc_2etupleTake_lam0, 1, 2, (V[]){heff_dup(v_mask_244), heff_dup(v_kinds_241)}), v_t_246));
  }
  case TAG_TakeKeep: {
    heff_drop(v_sv_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemitc_2etupleTake_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2etupleTake(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2etupleTake_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_mask_244 = heff_env(self)[0];
  V v_kinds_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = (g_heff_2ecompile_2erefcount_2epow2(heff_dup(v_i_247)));
  V v_t_249 = heff_intMod(heff_intDiv(v_mask_244, v_t_248), MK_INT(2LL));
  if ((heff_unbox_word(v_t_249) == ((int64_t)1ULL))) {
    heff_drop(v_i_247);
    heff_drop(v_kinds_241);
    return NTAG(TAG_False);
  } else {
    HeffT3 v_t_2411 = ({ V a_0 = v_i_247; V a_1 = v_kinds_241; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_kinds_241); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      V v_field_2414 = v_t_2411.f[2];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2416 = v_field_2413;
        V v_x12_2417 = v_field_2414;
        heff_drop(v_x12_2417);
        switch (heff_tag_of(v_x_2416)) {
        case TAG_RepV: {
          return NTAG(TAG_True);
        }
        case TAG_RepFix: {
          heff_take_n(v_x_2416, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_RepF64: {
          return NTAG(TAG_False);
        }
        case TAG_RepInt: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x_2416);
        }
      } else {
        heff_drop(v_field_2413);
        heff_drop(v_field_2414);
        return NTAG(TAG_True);
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eletType_str0, 5, "HeffT");
Clo g_heff_2ecompile_2eemitc_2eletType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletType_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eletType(V v_k_240, V v_x_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_RLocal: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RDup: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RClo: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RGet: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RGetRaw: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RInt: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RFloat: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RStr: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RBytes: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RFixed: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RF32: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RNTag: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RTag: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RTagIn: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RRec: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RRecIn: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RField: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RDupE: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RFieldV: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RGetN: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RFieldU: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RGetNU: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RWord: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RTakeField: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RGetLabel: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RPrimFn: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RPrim: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RLam: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RCall: {
    V v_g_2464 = heff_field(v_e_242, 0);
    HeffT2 v_t_2468 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_k_240, 3), v_g_2464));
    {
      V v_field_2470 = v_t_2468.f[1];
      int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
      V v_t_2473;
      if ((v_tag_2469 == ((int64_t)0ULL))) {
        V v_x_2472 = v_field_2470;
        v_t_2473 = v_x_2472;
      } else {
        heff_drop(v_field_2470);
        v_t_2473 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_t_2473)) {
        heff_drop(v_x_241);
        HeffT2 v_t_2475 = ({ V b_0 = heff_get_n(v_k_240, 3, 6); V a_1 = v_g_2464; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2477 = v_t_2475.f[1];
          int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
          V v_t_2480;
          if ((v_tag_2476 == ((int64_t)0ULL))) {
            V v_x_2479 = v_field_2477;
            v_t_2480 = v_x_2479;
          } else {
            heff_drop(v_field_2477);
            v_t_2480 = MK_INT(0LL);
          }
          return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eletType_str0), heff_intShow(v_t_2480));
        }
      } else {
        return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
      }
    }
  }
  case TAG_RApply: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RBool: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RAbandon: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RBox: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RUnbox: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RPeek: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RPrimU: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RPrimAt: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RFixU: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RF32U: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  case TAG_RF64U: {
    return heff_tail(heff_get_n(v_k_240, 2, 6), 1, (V[]){v_x_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemitc_2eletType_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eletType(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str3, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str5, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str6, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str10, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str14, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str16, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str17, 15, "heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str18, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str19, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str21, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str23, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str24, 20, "switch (heff_tag_of(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str25, 4, ")) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str26, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str27, 20, "switch (heff_tag_of(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str28, 4, ")) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str29, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str30, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str31, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str32, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str33, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str34, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str35, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str36, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str37, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str38, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str39, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str40, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str41, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str42, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str43, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str44, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str45, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str46, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str47, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str48, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str49, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str50, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str51, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str52, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str53, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str54, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str55, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str56, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str57, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str58, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str59, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str60, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str61, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str62, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str63, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str64, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str65, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str66, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str67, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str68, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str69, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str70, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str71, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str72, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str73, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str74, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str75, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str76, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str77, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str78, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str79, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str80, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str81, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str82, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str83, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str84, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str85, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str86, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str87, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str88, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str89, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str90, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str91, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str92, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str93, 21, "){{heff_abandon()}});");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str94, 9, "return ((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str95, 22, "return heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str96, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str97, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str98, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str99, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str100, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str101, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str102, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str103, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str104, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str105, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str106, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str107, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str108, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str109, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str110, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str111, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str112, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str113, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str114, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str115, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str116, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str117, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str118, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str119, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str120, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str121, 17, "return heff_tail(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str122, 3, "top");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str123, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str124, 4, "top_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str125, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str126, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str127, 4, "top_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str128, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str129, 3, ": ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str130, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str131, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str132, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str133, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str134, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str135, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str136, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str138, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str139, 17, "HEFF_LAST return ");
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2estmtF_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_lam4, 1, 0};
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam35(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam36(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam37(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam38(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam39(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam40(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam41(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam42(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam43(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam44(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam45(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam46(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam47(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam48(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam49(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam50(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam51(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam52(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam53(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam54(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estmtF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_248;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x12_244 = heff_field(v_d_242, 1);
      heff_take_n(v_d_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = ({ V a_0 = v_x_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_243); r_; });
        V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str1), v_t_245), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str2));
        v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str3), v_t_246);
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_243); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam0, 1, 1, (V[]){v_x_249});
  }
  case TAG_CLet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_e_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2413 = heff_tr(g_heff_2ecompile_2eemitc_2eletType(heff_dup(v_k_240), heff_dup(v_x_2411), v_e_2412));
    V v_t_2414 = ({ V a_0 = v_x_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str4); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str5), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str6));
    V v_pre_2416 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str7), v_t_2415));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2412}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam1, 1, 2, (V[]){v_m_2417, v_pre_2416});
  }
  case TAG_CDecl: {
    V v_x_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_2424)}));
    V v_t_2426 = ({ V a_0 = v_x_2424; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str9); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2424); r_; });
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str10), v_t_2426), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str11));
    V v_t_2428 = heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str12), v_t_2427));
    V v_x_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam2, 1, 1, (V[]){v_x_2429});
  }
  case TAG_CSet: {
    V v_x_2431 = heff_field(v_x2_241, 0);
    V v_e_2432 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2433 = ({ V a_0 = v_x_2431; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str13); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2431); r_; });
    V v_pre_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str14), v_t_2433), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str15));
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2432}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam3, 1, 2, (V[]){v_m_2435, v_pre_2434});
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2estmtF_lam4_clo);
  }
  case TAG_CIf: {
    V v_c_2444 = heff_field(v_x2_241, 0);
    V v_yes_2445 = heff_field(v_x2_241, 1);
    V v_no_2446 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2447 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_2444));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam5, 1, 4, (V[]){v_m_2447, v_k_240, v_yes_2445, v_no_2446});
  }
  case TAG_CSwitch: {
    V v_e_2466 = heff_field(v_x2_241, 0);
    V v_arms_2467 = heff_field(v_x2_241, 1);
    V v_returns_2468 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_2466}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam6, 1, 4, (V[]){v_m_2469, v_arms_2467, v_k_240, v_returns_2468});
  }
  case TAG_CReturn: {
    V v_x21_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_24123)) {
    case TAG_RLocal: {
      V v_m_24125 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam8, 1, 1, (V[]){v_m_24125});
    }
    case TAG_RDup: {
      V v_m_24133 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam9, 1, 1, (V[]){v_m_24133});
    }
    case TAG_RClo: {
      V v_m_24141 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam10, 1, 1, (V[]){v_m_24141});
    }
    case TAG_RGet: {
      V v_m_24149 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam11, 1, 1, (V[]){v_m_24149});
    }
    case TAG_RGetRaw: {
      V v_m_24157 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam12, 1, 1, (V[]){v_m_24157});
    }
    case TAG_RInt: {
      V v_m_24165 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam13, 1, 1, (V[]){v_m_24165});
    }
    case TAG_RFloat: {
      V v_m_24173 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam14, 1, 1, (V[]){v_m_24173});
    }
    case TAG_RStr: {
      V v_m_24181 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam15, 1, 1, (V[]){v_m_24181});
    }
    case TAG_RBytes: {
      V v_m_24189 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam16, 1, 1, (V[]){v_m_24189});
    }
    case TAG_RFixed: {
      V v_m_24198 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam17, 1, 1, (V[]){v_m_24198});
    }
    case TAG_RF32: {
      V v_m_24206 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam18, 1, 1, (V[]){v_m_24206});
    }
    case TAG_RNTag: {
      V v_m_24214 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam19, 1, 1, (V[]){v_m_24214});
    }
    case TAG_RTag: {
      V v_m_24224 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam20, 1, 1, (V[]){v_m_24224});
    }
    case TAG_RTagIn: {
      V v_m_24235 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam21, 1, 1, (V[]){v_m_24235});
    }
    case TAG_RRec: {
      V v_m_24245 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam22, 1, 1, (V[]){v_m_24245});
    }
    case TAG_RRecIn: {
      V v_m_24260 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam23, 1, 1, (V[]){v_m_24260});
    }
    case TAG_RField: {
      V v_m_24269 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam24, 1, 1, (V[]){v_m_24269});
    }
    case TAG_RDupE: {
      V v_m_24277 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam25, 1, 1, (V[]){v_m_24277});
    }
    case TAG_RFieldV: {
      V v_m_24286 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam26, 1, 1, (V[]){v_m_24286});
    }
    case TAG_RGetN: {
      V v_m_24296 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam27, 1, 1, (V[]){v_m_24296});
    }
    case TAG_RFieldU: {
      V v_m_24307 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam28, 1, 1, (V[]){v_m_24307});
    }
    case TAG_RGetNU: {
      V v_m_24319 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam29, 1, 1, (V[]){v_m_24319});
    }
    case TAG_RWord: {
      V v_m_24328 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam30, 1, 1, (V[]){v_m_24328});
    }
    case TAG_RTakeField: {
      V v_m_24337 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam31, 1, 1, (V[]){v_m_24337});
    }
    case TAG_RGetLabel: {
      V v_m_24346 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam32, 1, 1, (V[]){v_m_24346});
    }
    case TAG_RPrimFn: {
      V v_m_24354 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam33, 1, 1, (V[]){v_m_24354});
    }
    case TAG_RPrim: {
      V v_m_24363 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam34, 1, 1, (V[]){v_m_24363});
    }
    case TAG_RLam: {
      V v_m_24374 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam35, 1, 1, (V[]){v_m_24374});
    }
    case TAG_RCall: {
      V v_m_24385 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam36, 1, 1, (V[]){v_m_24385});
    }
    case TAG_RApply: {
      V v_m_24394 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam37, 1, 1, (V[]){v_m_24394});
    }
    case TAG_RBool: {
      V v_m_24402 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam38, 1, 1, (V[]){v_m_24402});
    }
    case TAG_RAbandon: {
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam39, 1, 1, (V[]){v_k_240});
    }
    case TAG_RBox: {
      V v_m_24417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam40, 1, 1, (V[]){v_m_24417});
    }
    case TAG_RUnbox: {
      V v_m_24426 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam41, 1, 1, (V[]){v_m_24426});
    }
    case TAG_RPeek: {
      V v_m_24435 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam42, 1, 1, (V[]){v_m_24435});
    }
    case TAG_RPrimU: {
      V v_m_24444 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam43, 1, 1, (V[]){v_m_24444});
    }
    case TAG_RPrimAt: {
      V v_m_24454 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam44, 1, 1, (V[]){v_m_24454});
    }
    case TAG_RFixU: {
      V v_m_24463 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam45, 1, 1, (V[]){v_m_24463});
    }
    case TAG_RF32U: {
      V v_m_24471 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam46, 1, 1, (V[]){v_m_24471});
    }
    case TAG_RF64U: {
      V v_m_24479 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24123}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam47, 1, 1, (V[]){v_m_24479});
    }
    default: return heff_nomatch(v_x21_24123);
    }
  }
  case TAG_CInPlace: {
    V v_f_24486 = heff_field(v_x2_241, 0);
    V v_es_24487 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CInPlace = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24488 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_at_n(v_ru_24x2_241_24CInPlace, TAG_Cons, 2, (V[]){v_f_24486, v_es_24487})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam48, 1, 1, (V[]){v_m_24488});
  }
  case TAG_CRoomed: {
    V v_f_24494 = heff_field(v_x2_241, 0);
    V v_es_24495 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CRoomed = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24496 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_at_n(v_ru_24x2_241_24CRoomed, TAG_Cons, 2, (V[]){v_f_24494, v_es_24495})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam49, 1, 1, (V[]){v_m_24496});
  }
  case TAG_CTail: {
    V v_f_24502 = heff_field(v_x2_241, 0);
    V v_es_24503 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CTail = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24504 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_at_n(v_ru_24x2_241_24CTail, TAG_Cons, 2, (V[]){v_f_24502, heff_dup(v_es_24503)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam50, 1, 2, (V[]){v_m_24504, v_es_24503});
  }
  case TAG_CLoop: {
    V v_ps_24529 = heff_field(v_x2_241, 0);
    V v_es_24530 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24531 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_24530));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam51, 1, 3, (V[]){v_m_24531, v_k_240, v_ps_24529});
  }
  case TAG_CLoopTo: {
    V v_t_24538 = heff_field(v_x2_241, 0);
    V v_ps_24539 = heff_field(v_x2_241, 1);
    V v_es_24540 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24541 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_24540));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam52, 1, 4, (V[]){v_m_24541, v_t_24538, v_k_240, v_ps_24539});
  }
  case TAG_CLabel: {
    V v_t_24550 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_24551 = ({ V a_0 = v_t_24550; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str126); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_24550); r_; });
    V v_t_24552 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str127), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str128), v_t_24551));
    V v_x_24553 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24552, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str129)), NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam53, 1, 1, (V[]){v_x_24553});
  }
  case TAG_CJump: {
    V v_g_24555 = heff_field(v_x2_241, 0);
    V v_w_24556 = heff_field(v_x2_241, 1);
    V v_es_24557 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24558 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24557));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam54, 1, 3, (V[]){v_m_24558, v_w_24556, v_g_24555});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estmtF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_pre_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_strAppend(v_pre_2416, heff_strAppend(v_x_2420, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str8)));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_s_2430});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_pre_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440 = heff_strAppend(v_pre_2434, heff_strAppend(v_x_2438, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str16)));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){v_t_2441, v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args) {
  V v_s_2442 = args[0];
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str17), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2442});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args) {
  V v_s_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_yes_2445 = heff_env(self)[2];
  V v_no_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_s_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_s_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    V v_m_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_yes_2445}));
    V v_x2_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2451}));
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_MkPair: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_s_2455 = heff_field(v_x2_2453, 1);
      V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
      V v_m_2456 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 6), 1, (V[]){v_no_2446}));
      V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2455}));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str18), heff_strAppend(v_x_2450, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str19)));
        V v_t_2461 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2estmtF_str20), v_x_2454));
        V v_t_2462 = heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str21), NTAG(TAG_Nil)});
        V v_t_2463 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2462, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str22), v_x_2458));
        V v_t_2464 = (g_prelude_2e_2b_2b(v_t_2461, heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str23), v_t_2463})));
        V v_x_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2464});
        return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){v_x_2465, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
    default: return heff_nomatch(v_x2_2453);
    }
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args) {
  V v_a_2474 = args[0];
  V v_arms_2467 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_arms_2467)) {
  case TAG_Nil: {
    return ({ V a_0 = v_k_240; V a_1 = v_x_2472; V a_2 = v_a_2474; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2474); r_; });
  }
  case TAG_Cons: {
    V v_arms1_2475 = heff_field(v_arms_2467, 0);
    V v_arms2_2476 = heff_field(v_arms_2467, 1);
    heff_take_n(v_arms_2467, 3ULL, 2);
    V v_t_2488;
    switch (heff_tag_of(v_arms1_2475)) {
    case TAG_MkCArm: {
      V v_t_2477 = heff_field(v_arms1_2475, 0);
      heff_take_n(v_arms1_2475, 1ULL, 8);
      switch (heff_tag_of(v_arms2_2476)) {
      case TAG_Nil: {
        v_t_2488 = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2477, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2477, MK_INT(0LL), 2)) == ((int64_t)35ULL))));
        heff_drop(v_t_2477);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_arms2_2476, 0ULL, 2);
        heff_drop(v_t_2477);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_arms2_2476);
      }
      break;
    }
    default: heff_nomatch(v_arms1_2475);
    }
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop(v_t_2488);
      return ({ V a_0 = v_k_240; V a_1 = v_x_2472; V a_2 = v_a_2474; V r_ = (g_heff_2ecompile_2eemitc_2etupleArm(a_0, a_1, a_2)); heff_drop(v_a_2474); r_; });
    } else {
      heff_drop(v_t_2488);
      return ({ V a_0 = v_k_240; V a_1 = v_x_2472; V a_2 = v_a_2474; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2474); r_; });
    }
  }
  default: return heff_nomatch(v_arms_2467);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_arms_2467 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_returns_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    V v_m_2489 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam7, 1, 3, (V[]){heff_dup(v_arms_2467), heff_dup(v_k_240), heff_dup(v_x_2472)}), heff_dup(v_arms_2467)));
    V v_x2_2490 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2473}));
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_MkPair: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_s_2492 = heff_field(v_x2_2490, 1);
      V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
      V v_x_24122;
      switch (heff_tag_of(v_arms_2467)) {
      case TAG_Nil: {
        V v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str24), heff_strAppend(heff_dup(v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str25)));
        V v_t_2494 = heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
        V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2491));
        V v_t_2496 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2495; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2495); r_; });
        V v_t_2497 = ({ V a_0 = heff_get_n(v_k_240, 4, 6); V a_1 = v_returns_2468; V a_2 = v_x_2472; V r_ = (g_heff_2ecompile_2eemitc_2enomatchLine(a_0, a_1, a_2)); heff_drop(v_returns_2468); r_; });
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str26), NTAG(TAG_Nil)});
        V v_t_2499 = (g_prelude_2e_2b_2b(v_t_2496, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_t_2498})));
        v_x_24122 = (g_prelude_2e_2b_2b(v_t_2494, v_t_2499));
        break;
      }
      case TAG_Cons: {
        V v_arms1_24100 = heff_field(v_arms_2467, 0);
        V v_arms2_24101 = heff_field(v_arms_2467, 1);
        V v_ru_24arms_2467_24Cons = heff_take_reuse_n(v_arms_2467, 3ULL, 2);
        V v_t_24113;
        switch (heff_tag_of(v_arms1_24100)) {
        case TAG_MkCArm: {
          V v_t_24102 = heff_field(v_arms1_24100, 0);
          heff_take_n(v_arms1_24100, 1ULL, 8);
          switch (heff_tag_of(v_arms2_24101)) {
          case TAG_Nil: {
            v_t_24113 = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24102, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_24102, MK_INT(0LL), 2)) == ((int64_t)35ULL))));
            heff_drop(v_t_24102);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_arms2_24101, 0ULL, 2);
            heff_drop(v_t_24102);
            v_t_24113 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_arms2_24101);
          }
          break;
        }
        default: heff_nomatch(v_arms1_24100);
        }
        if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
          heff_drop_rec(v_k_240, 6);
          heff_drop(v_returns_2468);
          heff_drop(v_x_2472);
          heff_drop_cell(v_ru_24x2_2490_24MkPair, 2);
          heff_drop_cell(v_ru_24arms_2467_24Cons, 2);
          heff_drop(v_t_24113);
          V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2491));
          v_x_24122 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24114; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24114); r_; });
        } else {
          heff_drop(v_t_24113);
          V v_t_24115 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str27), heff_strAppend(heff_dup(v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str28)));
          V v_t_24116 = heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
          V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2491));
          V v_t_24118 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24117; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24117); r_; });
          V v_t_24119 = ({ V a_0 = heff_get_n(v_k_240, 4, 6); V a_1 = v_returns_2468; V a_2 = v_x_2472; V r_ = (g_heff_2ecompile_2eemitc_2enomatchLine(a_0, a_1, a_2)); heff_drop(v_returns_2468); r_; });
          V v_t_24120 = heff_tag_at_n(v_ru_24arms_2467_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str29), NTAG(TAG_Nil)});
          V v_t_24121 = (g_prelude_2e_2b_2b(v_t_24118, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24119, v_t_24120})));
          v_x_24122 = (g_prelude_2e_2b_2b(v_t_24116, v_t_24121));
        }
        break;
      }
      default: heff_nomatch(v_arms_2467);
      }
      return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_x_24122, v_s_2492});
    }
    default: return heff_nomatch(v_x2_2490);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str30), heff_strAppend(v_x_24128, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str31)));
    V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){v_t_24131, v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_t_24138 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str32), heff_strAppend(v_x_24136, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str33)));
    V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){v_t_24139, v_s_24137});
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args) {
  V v_s_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_s_24142}));
  switch (heff_tag_of(v_x2_24143)) {
  case TAG_MkPair: {
    V v_x_24144 = heff_field(v_x2_24143, 0);
    V v_s_24145 = heff_field(v_x2_24143, 1);
    V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
    V v_t_24146 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str34), heff_strAppend(v_x_24144, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str35)));
    V v_t_24147 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24146, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24143_24MkPair, TAG_MkPair, 2, (V[]){v_t_24147, v_s_24145});
  }
  default: return heff_nomatch(v_x2_24143);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args) {
  V v_s_24150 = args[0];
  V v_m_24149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24151 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_s_24150}));
  switch (heff_tag_of(v_x2_24151)) {
  case TAG_MkPair: {
    V v_x_24152 = heff_field(v_x2_24151, 0);
    V v_s_24153 = heff_field(v_x2_24151, 1);
    V v_ru_24x2_24151_24MkPair = heff_take_reuse_n(v_x2_24151, 3ULL, 2);
    V v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str36), heff_strAppend(v_x_24152, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str37)));
    V v_t_24155 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24154, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24151_24MkPair, TAG_MkPair, 2, (V[]){v_t_24155, v_s_24153});
  }
  default: return heff_nomatch(v_x2_24151);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args) {
  V v_s_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_s_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_s_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_t_24162 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str38), heff_strAppend(v_x_24160, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str39)));
    V v_t_24163 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24162, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_t_24163, v_s_24161});
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam13(V self, V *args) {
  V v_s_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_s_24166}));
  switch (heff_tag_of(v_x2_24167)) {
  case TAG_MkPair: {
    V v_x_24168 = heff_field(v_x2_24167, 0);
    V v_s_24169 = heff_field(v_x2_24167, 1);
    V v_ru_24x2_24167_24MkPair = heff_take_reuse_n(v_x2_24167, 3ULL, 2);
    V v_t_24170 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str40), heff_strAppend(v_x_24168, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str41)));
    V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24170, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24167_24MkPair, TAG_MkPair, 2, (V[]){v_t_24171, v_s_24169});
  }
  default: return heff_nomatch(v_x2_24167);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam14(V self, V *args) {
  V v_s_24174 = args[0];
  V v_m_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24175 = heff_tr(heff_call(v_m_24173, 1, (V[]){v_s_24174}));
  switch (heff_tag_of(v_x2_24175)) {
  case TAG_MkPair: {
    V v_x_24176 = heff_field(v_x2_24175, 0);
    V v_s_24177 = heff_field(v_x2_24175, 1);
    V v_ru_24x2_24175_24MkPair = heff_take_reuse_n(v_x2_24175, 3ULL, 2);
    V v_t_24178 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str42), heff_strAppend(v_x_24176, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str43)));
    V v_t_24179 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24178, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24175_24MkPair, TAG_MkPair, 2, (V[]){v_t_24179, v_s_24177});
  }
  default: return heff_nomatch(v_x2_24175);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam15(V self, V *args) {
  V v_s_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_s_24182}));
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_MkPair: {
    V v_x_24184 = heff_field(v_x2_24183, 0);
    V v_s_24185 = heff_field(v_x2_24183, 1);
    V v_ru_24x2_24183_24MkPair = heff_take_reuse_n(v_x2_24183, 3ULL, 2);
    V v_t_24186 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str44), heff_strAppend(v_x_24184, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str45)));
    V v_t_24187 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24186, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24183_24MkPair, TAG_MkPair, 2, (V[]){v_t_24187, v_s_24185});
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam16(V self, V *args) {
  V v_s_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24191 = heff_tr(heff_call(v_m_24189, 1, (V[]){v_s_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_s_24193 = heff_field(v_x2_24191, 1);
    V v_ru_24x2_24191_24MkPair = heff_take_reuse_n(v_x2_24191, 3ULL, 2);
    V v_t_24194 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str46), heff_strAppend(v_x_24192, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str47)));
    V v_t_24195 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24194, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24191_24MkPair, TAG_MkPair, 2, (V[]){v_t_24195, v_s_24193});
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam17(V self, V *args) {
  V v_s_24199 = args[0];
  V v_m_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24200 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_s_24199}));
  switch (heff_tag_of(v_x2_24200)) {
  case TAG_MkPair: {
    V v_x_24201 = heff_field(v_x2_24200, 0);
    V v_s_24202 = heff_field(v_x2_24200, 1);
    V v_ru_24x2_24200_24MkPair = heff_take_reuse_n(v_x2_24200, 3ULL, 2);
    V v_t_24203 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str48), heff_strAppend(v_x_24201, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str49)));
    V v_t_24204 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24203, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24200_24MkPair, TAG_MkPair, 2, (V[]){v_t_24204, v_s_24202});
  }
  default: return heff_nomatch(v_x2_24200);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam18(V self, V *args) {
  V v_s_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_s_24207}));
  switch (heff_tag_of(v_x2_24208)) {
  case TAG_MkPair: {
    V v_x_24209 = heff_field(v_x2_24208, 0);
    V v_s_24210 = heff_field(v_x2_24208, 1);
    V v_ru_24x2_24208_24MkPair = heff_take_reuse_n(v_x2_24208, 3ULL, 2);
    V v_t_24211 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str50), heff_strAppend(v_x_24209, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str51)));
    V v_t_24212 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24211, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24208_24MkPair, TAG_MkPair, 2, (V[]){v_t_24212, v_s_24210});
  }
  default: return heff_nomatch(v_x2_24208);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam19(V self, V *args) {
  V v_s_24215 = args[0];
  V v_m_24214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24216 = heff_tr(heff_call(v_m_24214, 1, (V[]){v_s_24215}));
  switch (heff_tag_of(v_x2_24216)) {
  case TAG_MkPair: {
    V v_x_24217 = heff_field(v_x2_24216, 0);
    V v_s_24218 = heff_field(v_x2_24216, 1);
    V v_ru_24x2_24216_24MkPair = heff_take_reuse_n(v_x2_24216, 3ULL, 2);
    V v_t_24219 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str52), heff_strAppend(v_x_24217, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str53)));
    V v_t_24220 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24219, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24216_24MkPair, TAG_MkPair, 2, (V[]){v_t_24220, v_s_24218});
  }
  default: return heff_nomatch(v_x2_24216);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam20(V self, V *args) {
  V v_s_24225 = args[0];
  V v_m_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24226 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_s_24225}));
  switch (heff_tag_of(v_x2_24226)) {
  case TAG_MkPair: {
    V v_x_24227 = heff_field(v_x2_24226, 0);
    V v_s_24228 = heff_field(v_x2_24226, 1);
    V v_ru_24x2_24226_24MkPair = heff_take_reuse_n(v_x2_24226, 3ULL, 2);
    V v_t_24229 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str54), heff_strAppend(v_x_24227, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str55)));
    V v_t_24230 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24229, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24226_24MkPair, TAG_MkPair, 2, (V[]){v_t_24230, v_s_24228});
  }
  default: return heff_nomatch(v_x2_24226);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam21(V self, V *args) {
  V v_s_24236 = args[0];
  V v_m_24235 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24237 = heff_tr(heff_call(v_m_24235, 1, (V[]){v_s_24236}));
  switch (heff_tag_of(v_x2_24237)) {
  case TAG_MkPair: {
    V v_x_24238 = heff_field(v_x2_24237, 0);
    V v_s_24239 = heff_field(v_x2_24237, 1);
    V v_ru_24x2_24237_24MkPair = heff_take_reuse_n(v_x2_24237, 3ULL, 2);
    V v_t_24240 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str56), heff_strAppend(v_x_24238, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str57)));
    V v_t_24241 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24240, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24237_24MkPair, TAG_MkPair, 2, (V[]){v_t_24241, v_s_24239});
  }
  default: return heff_nomatch(v_x2_24237);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam22(V self, V *args) {
  V v_s_24246 = args[0];
  V v_m_24245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24247 = heff_tr(heff_call(v_m_24245, 1, (V[]){v_s_24246}));
  switch (heff_tag_of(v_x2_24247)) {
  case TAG_MkPair: {
    V v_x_24248 = heff_field(v_x2_24247, 0);
    V v_s_24249 = heff_field(v_x2_24247, 1);
    V v_ru_24x2_24247_24MkPair = heff_take_reuse_n(v_x2_24247, 3ULL, 2);
    V v_t_24250 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str58), heff_strAppend(v_x_24248, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str59)));
    V v_t_24251 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24250, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24247_24MkPair, TAG_MkPair, 2, (V[]){v_t_24251, v_s_24249});
  }
  default: return heff_nomatch(v_x2_24247);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam23(V self, V *args) {
  V v_s_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_s_24261}));
  switch (heff_tag_of(v_x2_24262)) {
  case TAG_MkPair: {
    V v_x_24263 = heff_field(v_x2_24262, 0);
    V v_s_24264 = heff_field(v_x2_24262, 1);
    V v_ru_24x2_24262_24MkPair = heff_take_reuse_n(v_x2_24262, 3ULL, 2);
    V v_t_24265 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str60), heff_strAppend(v_x_24263, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str61)));
    V v_t_24266 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24265, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24262_24MkPair, TAG_MkPair, 2, (V[]){v_t_24266, v_s_24264});
  }
  default: return heff_nomatch(v_x2_24262);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam24(V self, V *args) {
  V v_s_24270 = args[0];
  V v_m_24269 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24271 = heff_tr(heff_call(v_m_24269, 1, (V[]){v_s_24270}));
  switch (heff_tag_of(v_x2_24271)) {
  case TAG_MkPair: {
    V v_x_24272 = heff_field(v_x2_24271, 0);
    V v_s_24273 = heff_field(v_x2_24271, 1);
    V v_ru_24x2_24271_24MkPair = heff_take_reuse_n(v_x2_24271, 3ULL, 2);
    V v_t_24274 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str62), heff_strAppend(v_x_24272, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str63)));
    V v_t_24275 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24274, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24271_24MkPair, TAG_MkPair, 2, (V[]){v_t_24275, v_s_24273});
  }
  default: return heff_nomatch(v_x2_24271);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam25(V self, V *args) {
  V v_s_24278 = args[0];
  V v_m_24277 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24279 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_s_24278}));
  switch (heff_tag_of(v_x2_24279)) {
  case TAG_MkPair: {
    V v_x_24280 = heff_field(v_x2_24279, 0);
    V v_s_24281 = heff_field(v_x2_24279, 1);
    V v_ru_24x2_24279_24MkPair = heff_take_reuse_n(v_x2_24279, 3ULL, 2);
    V v_t_24282 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str64), heff_strAppend(v_x_24280, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str65)));
    V v_t_24283 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24282, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24279_24MkPair, TAG_MkPair, 2, (V[]){v_t_24283, v_s_24281});
  }
  default: return heff_nomatch(v_x2_24279);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam26(V self, V *args) {
  V v_s_24287 = args[0];
  V v_m_24286 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24288 = heff_tr(heff_call(v_m_24286, 1, (V[]){v_s_24287}));
  switch (heff_tag_of(v_x2_24288)) {
  case TAG_MkPair: {
    V v_x_24289 = heff_field(v_x2_24288, 0);
    V v_s_24290 = heff_field(v_x2_24288, 1);
    V v_ru_24x2_24288_24MkPair = heff_take_reuse_n(v_x2_24288, 3ULL, 2);
    V v_t_24291 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str66), heff_strAppend(v_x_24289, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str67)));
    V v_t_24292 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24291, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24288_24MkPair, TAG_MkPair, 2, (V[]){v_t_24292, v_s_24290});
  }
  default: return heff_nomatch(v_x2_24288);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam27(V self, V *args) {
  V v_s_24297 = args[0];
  V v_m_24296 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24298 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_s_24297}));
  switch (heff_tag_of(v_x2_24298)) {
  case TAG_MkPair: {
    V v_x_24299 = heff_field(v_x2_24298, 0);
    V v_s_24300 = heff_field(v_x2_24298, 1);
    V v_ru_24x2_24298_24MkPair = heff_take_reuse_n(v_x2_24298, 3ULL, 2);
    V v_t_24301 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str68), heff_strAppend(v_x_24299, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str69)));
    V v_t_24302 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24301, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24298_24MkPair, TAG_MkPair, 2, (V[]){v_t_24302, v_s_24300});
  }
  default: return heff_nomatch(v_x2_24298);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam28(V self, V *args) {
  V v_s_24308 = args[0];
  V v_m_24307 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24309 = heff_tr(heff_call(v_m_24307, 1, (V[]){v_s_24308}));
  switch (heff_tag_of(v_x2_24309)) {
  case TAG_MkPair: {
    V v_x_24310 = heff_field(v_x2_24309, 0);
    V v_s_24311 = heff_field(v_x2_24309, 1);
    V v_ru_24x2_24309_24MkPair = heff_take_reuse_n(v_x2_24309, 3ULL, 2);
    V v_t_24312 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str70), heff_strAppend(v_x_24310, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str71)));
    V v_t_24313 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24312, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24309_24MkPair, TAG_MkPair, 2, (V[]){v_t_24313, v_s_24311});
  }
  default: return heff_nomatch(v_x2_24309);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam29(V self, V *args) {
  V v_s_24320 = args[0];
  V v_m_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24321 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_s_24320}));
  switch (heff_tag_of(v_x2_24321)) {
  case TAG_MkPair: {
    V v_x_24322 = heff_field(v_x2_24321, 0);
    V v_s_24323 = heff_field(v_x2_24321, 1);
    V v_ru_24x2_24321_24MkPair = heff_take_reuse_n(v_x2_24321, 3ULL, 2);
    V v_t_24324 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str72), heff_strAppend(v_x_24322, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str73)));
    V v_t_24325 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24324, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24321_24MkPair, TAG_MkPair, 2, (V[]){v_t_24325, v_s_24323});
  }
  default: return heff_nomatch(v_x2_24321);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam30(V self, V *args) {
  V v_s_24329 = args[0];
  V v_m_24328 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24330 = heff_tr(heff_call(v_m_24328, 1, (V[]){v_s_24329}));
  switch (heff_tag_of(v_x2_24330)) {
  case TAG_MkPair: {
    V v_x_24331 = heff_field(v_x2_24330, 0);
    V v_s_24332 = heff_field(v_x2_24330, 1);
    V v_ru_24x2_24330_24MkPair = heff_take_reuse_n(v_x2_24330, 3ULL, 2);
    V v_t_24333 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str74), heff_strAppend(v_x_24331, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str75)));
    V v_t_24334 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24333, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24330_24MkPair, TAG_MkPair, 2, (V[]){v_t_24334, v_s_24332});
  }
  default: return heff_nomatch(v_x2_24330);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam31(V self, V *args) {
  V v_s_24338 = args[0];
  V v_m_24337 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24339 = heff_tr(heff_call(v_m_24337, 1, (V[]){v_s_24338}));
  switch (heff_tag_of(v_x2_24339)) {
  case TAG_MkPair: {
    V v_x_24340 = heff_field(v_x2_24339, 0);
    V v_s_24341 = heff_field(v_x2_24339, 1);
    V v_ru_24x2_24339_24MkPair = heff_take_reuse_n(v_x2_24339, 3ULL, 2);
    V v_t_24342 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str76), heff_strAppend(v_x_24340, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str77)));
    V v_t_24343 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24342, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24339_24MkPair, TAG_MkPair, 2, (V[]){v_t_24343, v_s_24341});
  }
  default: return heff_nomatch(v_x2_24339);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam32(V self, V *args) {
  V v_s_24347 = args[0];
  V v_m_24346 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24348 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_s_24347}));
  switch (heff_tag_of(v_x2_24348)) {
  case TAG_MkPair: {
    V v_x_24349 = heff_field(v_x2_24348, 0);
    V v_s_24350 = heff_field(v_x2_24348, 1);
    V v_ru_24x2_24348_24MkPair = heff_take_reuse_n(v_x2_24348, 3ULL, 2);
    V v_t_24351 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str78), heff_strAppend(v_x_24349, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str79)));
    V v_t_24352 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24351, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24348_24MkPair, TAG_MkPair, 2, (V[]){v_t_24352, v_s_24350});
  }
  default: return heff_nomatch(v_x2_24348);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam33(V self, V *args) {
  V v_s_24355 = args[0];
  V v_m_24354 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24356 = heff_tr(heff_call(v_m_24354, 1, (V[]){v_s_24355}));
  switch (heff_tag_of(v_x2_24356)) {
  case TAG_MkPair: {
    V v_x_24357 = heff_field(v_x2_24356, 0);
    V v_s_24358 = heff_field(v_x2_24356, 1);
    V v_ru_24x2_24356_24MkPair = heff_take_reuse_n(v_x2_24356, 3ULL, 2);
    V v_t_24359 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str80), heff_strAppend(v_x_24357, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str81)));
    V v_t_24360 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24359, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24356_24MkPair, TAG_MkPair, 2, (V[]){v_t_24360, v_s_24358});
  }
  default: return heff_nomatch(v_x2_24356);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam34(V self, V *args) {
  V v_s_24364 = args[0];
  V v_m_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24365 = heff_tr(heff_call(v_m_24363, 1, (V[]){v_s_24364}));
  switch (heff_tag_of(v_x2_24365)) {
  case TAG_MkPair: {
    V v_x_24366 = heff_field(v_x2_24365, 0);
    V v_s_24367 = heff_field(v_x2_24365, 1);
    V v_ru_24x2_24365_24MkPair = heff_take_reuse_n(v_x2_24365, 3ULL, 2);
    V v_t_24368 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str82), heff_strAppend(v_x_24366, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str83)));
    V v_t_24369 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24368, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24365_24MkPair, TAG_MkPair, 2, (V[]){v_t_24369, v_s_24367});
  }
  default: return heff_nomatch(v_x2_24365);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam35(V self, V *args) {
  V v_s_24375 = args[0];
  V v_m_24374 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24376 = heff_tr(heff_call(v_m_24374, 1, (V[]){v_s_24375}));
  switch (heff_tag_of(v_x2_24376)) {
  case TAG_MkPair: {
    V v_x_24377 = heff_field(v_x2_24376, 0);
    V v_s_24378 = heff_field(v_x2_24376, 1);
    V v_ru_24x2_24376_24MkPair = heff_take_reuse_n(v_x2_24376, 3ULL, 2);
    V v_t_24379 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str84), heff_strAppend(v_x_24377, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str85)));
    V v_t_24380 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24379, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24376_24MkPair, TAG_MkPair, 2, (V[]){v_t_24380, v_s_24378});
  }
  default: return heff_nomatch(v_x2_24376);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam36(V self, V *args) {
  V v_s_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_s_24386}));
  switch (heff_tag_of(v_x2_24387)) {
  case TAG_MkPair: {
    V v_x_24388 = heff_field(v_x2_24387, 0);
    V v_s_24389 = heff_field(v_x2_24387, 1);
    V v_ru_24x2_24387_24MkPair = heff_take_reuse_n(v_x2_24387, 3ULL, 2);
    V v_t_24390 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str86), heff_strAppend(v_x_24388, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str87)));
    V v_t_24391 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24390, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24387_24MkPair, TAG_MkPair, 2, (V[]){v_t_24391, v_s_24389});
  }
  default: return heff_nomatch(v_x2_24387);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam37(V self, V *args) {
  V v_s_24395 = args[0];
  V v_m_24394 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24396 = heff_tr(heff_call(v_m_24394, 1, (V[]){v_s_24395}));
  switch (heff_tag_of(v_x2_24396)) {
  case TAG_MkPair: {
    V v_x_24397 = heff_field(v_x2_24396, 0);
    V v_s_24398 = heff_field(v_x2_24396, 1);
    V v_ru_24x2_24396_24MkPair = heff_take_reuse_n(v_x2_24396, 3ULL, 2);
    V v_t_24399 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str88), heff_strAppend(v_x_24397, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str89)));
    V v_t_24400 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24399, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24396_24MkPair, TAG_MkPair, 2, (V[]){v_t_24400, v_s_24398});
  }
  default: return heff_nomatch(v_x2_24396);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam38(V self, V *args) {
  V v_s_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_s_24403}));
  switch (heff_tag_of(v_x2_24404)) {
  case TAG_MkPair: {
    V v_x_24405 = heff_field(v_x2_24404, 0);
    V v_s_24406 = heff_field(v_x2_24404, 1);
    V v_ru_24x2_24404_24MkPair = heff_take_reuse_n(v_x2_24404, 3ULL, 2);
    V v_t_24407 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str90), heff_strAppend(v_x_24405, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str91)));
    V v_t_24408 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24407, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24404_24MkPair, TAG_MkPair, 2, (V[]){v_t_24408, v_s_24406});
  }
  default: return heff_nomatch(v_x2_24404);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam39(V self, V *args) {
  V v_s_24409 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24413;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_k_240, 4)))) {
    V v_t_24411 = heff_intShow(heff_get_n(v_k_240, 4, 6));
    V v_t_24412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str92), v_t_24411), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str93));
    v_t_24413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str94), v_t_24412);
  } else {
    heff_drop_rec(v_k_240, 6);
    v_t_24413 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str95);
  }
  V v_t_24414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24413, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24414, v_s_24409});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam40(V self, V *args) {
  V v_s_24418 = args[0];
  V v_m_24417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24419 = heff_tr(heff_call(v_m_24417, 1, (V[]){v_s_24418}));
  switch (heff_tag_of(v_x2_24419)) {
  case TAG_MkPair: {
    V v_x_24420 = heff_field(v_x2_24419, 0);
    V v_s_24421 = heff_field(v_x2_24419, 1);
    V v_ru_24x2_24419_24MkPair = heff_take_reuse_n(v_x2_24419, 3ULL, 2);
    V v_t_24422 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str96), heff_strAppend(v_x_24420, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str97)));
    V v_t_24423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24422, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24419_24MkPair, TAG_MkPair, 2, (V[]){v_t_24423, v_s_24421});
  }
  default: return heff_nomatch(v_x2_24419);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam41(V self, V *args) {
  V v_s_24427 = args[0];
  V v_m_24426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24428 = heff_tr(heff_call(v_m_24426, 1, (V[]){v_s_24427}));
  switch (heff_tag_of(v_x2_24428)) {
  case TAG_MkPair: {
    V v_x_24429 = heff_field(v_x2_24428, 0);
    V v_s_24430 = heff_field(v_x2_24428, 1);
    V v_ru_24x2_24428_24MkPair = heff_take_reuse_n(v_x2_24428, 3ULL, 2);
    V v_t_24431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str98), heff_strAppend(v_x_24429, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str99)));
    V v_t_24432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24431, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24428_24MkPair, TAG_MkPair, 2, (V[]){v_t_24432, v_s_24430});
  }
  default: return heff_nomatch(v_x2_24428);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam42(V self, V *args) {
  V v_s_24436 = args[0];
  V v_m_24435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24437 = heff_tr(heff_call(v_m_24435, 1, (V[]){v_s_24436}));
  switch (heff_tag_of(v_x2_24437)) {
  case TAG_MkPair: {
    V v_x_24438 = heff_field(v_x2_24437, 0);
    V v_s_24439 = heff_field(v_x2_24437, 1);
    V v_ru_24x2_24437_24MkPair = heff_take_reuse_n(v_x2_24437, 3ULL, 2);
    V v_t_24440 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str100), heff_strAppend(v_x_24438, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str101)));
    V v_t_24441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24440, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24437_24MkPair, TAG_MkPair, 2, (V[]){v_t_24441, v_s_24439});
  }
  default: return heff_nomatch(v_x2_24437);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam43(V self, V *args) {
  V v_s_24445 = args[0];
  V v_m_24444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24446 = heff_tr(heff_call(v_m_24444, 1, (V[]){v_s_24445}));
  switch (heff_tag_of(v_x2_24446)) {
  case TAG_MkPair: {
    V v_x_24447 = heff_field(v_x2_24446, 0);
    V v_s_24448 = heff_field(v_x2_24446, 1);
    V v_ru_24x2_24446_24MkPair = heff_take_reuse_n(v_x2_24446, 3ULL, 2);
    V v_t_24449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str102), heff_strAppend(v_x_24447, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str103)));
    V v_t_24450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24449, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24446_24MkPair, TAG_MkPair, 2, (V[]){v_t_24450, v_s_24448});
  }
  default: return heff_nomatch(v_x2_24446);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam44(V self, V *args) {
  V v_s_24455 = args[0];
  V v_m_24454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24456 = heff_tr(heff_call(v_m_24454, 1, (V[]){v_s_24455}));
  switch (heff_tag_of(v_x2_24456)) {
  case TAG_MkPair: {
    V v_x_24457 = heff_field(v_x2_24456, 0);
    V v_s_24458 = heff_field(v_x2_24456, 1);
    V v_ru_24x2_24456_24MkPair = heff_take_reuse_n(v_x2_24456, 3ULL, 2);
    V v_t_24459 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str104), heff_strAppend(v_x_24457, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str105)));
    V v_t_24460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24459, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24456_24MkPair, TAG_MkPair, 2, (V[]){v_t_24460, v_s_24458});
  }
  default: return heff_nomatch(v_x2_24456);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam45(V self, V *args) {
  V v_s_24464 = args[0];
  V v_m_24463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24465 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_s_24464}));
  switch (heff_tag_of(v_x2_24465)) {
  case TAG_MkPair: {
    V v_x_24466 = heff_field(v_x2_24465, 0);
    V v_s_24467 = heff_field(v_x2_24465, 1);
    V v_ru_24x2_24465_24MkPair = heff_take_reuse_n(v_x2_24465, 3ULL, 2);
    V v_t_24468 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str106), heff_strAppend(v_x_24466, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str107)));
    V v_t_24469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24468, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24465_24MkPair, TAG_MkPair, 2, (V[]){v_t_24469, v_s_24467});
  }
  default: return heff_nomatch(v_x2_24465);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam46(V self, V *args) {
  V v_s_24472 = args[0];
  V v_m_24471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24473 = heff_tr(heff_call(v_m_24471, 1, (V[]){v_s_24472}));
  switch (heff_tag_of(v_x2_24473)) {
  case TAG_MkPair: {
    V v_x_24474 = heff_field(v_x2_24473, 0);
    V v_s_24475 = heff_field(v_x2_24473, 1);
    V v_ru_24x2_24473_24MkPair = heff_take_reuse_n(v_x2_24473, 3ULL, 2);
    V v_t_24476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str108), heff_strAppend(v_x_24474, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str109)));
    V v_t_24477 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24476, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24473_24MkPair, TAG_MkPair, 2, (V[]){v_t_24477, v_s_24475});
  }
  default: return heff_nomatch(v_x2_24473);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam47(V self, V *args) {
  V v_s_24480 = args[0];
  V v_m_24479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24481 = heff_tr(heff_call(v_m_24479, 1, (V[]){v_s_24480}));
  switch (heff_tag_of(v_x2_24481)) {
  case TAG_MkPair: {
    V v_x_24482 = heff_field(v_x2_24481, 0);
    V v_s_24483 = heff_field(v_x2_24481, 1);
    V v_ru_24x2_24481_24MkPair = heff_take_reuse_n(v_x2_24481, 3ULL, 2);
    V v_t_24484 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str110), heff_strAppend(v_x_24482, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str111)));
    V v_t_24485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24484, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24481_24MkPair, TAG_MkPair, 2, (V[]){v_t_24485, v_s_24483});
  }
  default: return heff_nomatch(v_x2_24481);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam48(V self, V *args) {
  V v_s_24489 = args[0];
  V v_m_24488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24490 = heff_tr(heff_call(v_m_24488, 1, (V[]){v_s_24489}));
  switch (heff_tag_of(v_x2_24490)) {
  case TAG_MkPair: {
    V v_x_24491 = heff_field(v_x2_24490, 0);
    V v_s_24492 = heff_field(v_x2_24490, 1);
    V v_ru_24x2_24490_24MkPair = heff_take_reuse_n(v_x2_24490, 3ULL, 2);
    V v_x_24493 = ({ V a_0 = v_x_24491; V r_ = (g_heff_2ecompile_2eemitc_2einPlace(a_0)); heff_drop(v_x_24491); r_; });
    return heff_tag_at_n(v_ru_24x2_24490_24MkPair, TAG_MkPair, 2, (V[]){v_x_24493, v_s_24492});
  }
  default: return heff_nomatch(v_x2_24490);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam49(V self, V *args) {
  V v_s_24497 = args[0];
  V v_m_24496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24498 = heff_tr(heff_call(v_m_24496, 1, (V[]){v_s_24497}));
  switch (heff_tag_of(v_x2_24498)) {
  case TAG_MkPair: {
    V v_x_24499 = heff_field(v_x2_24498, 0);
    V v_s_24500 = heff_field(v_x2_24498, 1);
    V v_ru_24x2_24498_24MkPair = heff_take_reuse_n(v_x2_24498, 3ULL, 2);
    V v_x_24501 = ({ V a_0 = v_x_24499; V r_ = (g_heff_2ecompile_2eemitc_2eroomed(a_0)); heff_drop(v_x_24499); r_; });
    return heff_tag_at_n(v_ru_24x2_24498_24MkPair, TAG_MkPair, 2, (V[]){v_x_24501, v_s_24500});
  }
  default: return heff_nomatch(v_x2_24498);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam50(V self, V *args) {
  V v_s_24505 = args[0];
  V v_m_24504 = heff_env(self)[0];
  V v_es_24503 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24506 = heff_tr(heff_call(v_m_24504, 1, (V[]){v_s_24505}));
  switch (heff_tag_of(v_x2_24506)) {
  case TAG_MkPair: {
    V v_x_24507 = heff_field(v_x2_24506, 0);
    V v_s_24508 = heff_field(v_x2_24506, 1);
    V v_ru_24x2_24506_24MkPair = heff_take_reuse_n(v_x2_24506, 3ULL, 2);
    V v_t_24511;
    switch (heff_tag_of(v_x_24507)) {
    case TAG_Nil: {
      v_t_24511 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str112);
      break;
    }
    case TAG_Cons: {
      V v_x_24509 = heff_dup(heff_field(v_x_24507, 0));
      v_t_24511 = v_x_24509;
      break;
    }
    default: heff_nomatch(v_x_24507);
    }
    V v_t_24512 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24503; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24503); r_; });
    HeffT3 v_t_24513 = ({ V a_0 = MK_INT(1LL); V a_1 = v_x_24507; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_x_24507); r_; });
    V v_t_24524;
    {
      V v_field_24515 = v_t_24513.f[1];
      V v_field_24516 = v_t_24513.f[2];
      int64_t v_tag_24514 = ((int64_t)v_t_24513.f[0]);
      if ((v_tag_24514 == ((int64_t)0ULL))) {
        V v_x11_24518 = heff_dup(v_field_24515);
        heff_drop(v_x11_24518);
        V v_x12_24519 = heff_dup(v_field_24516);
        heff_drop(v_x12_24519);
        V v_t_24523;
        if ((v_tag_24514 == ((int64_t)0ULL))) {
          V v_x_24521 = v_field_24515;
          V v_xs_24522 = v_field_24516;
          v_t_24523 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str113); V a_1 = v_x_24521; V a_2 = v_xs_24522; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24522); r_; });
        } else {
          heff_drop(v_field_24515);
          heff_drop(v_field_24516);
          v_t_24523 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str114);
        }
        v_t_24524 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str115), heff_strAppend(v_t_24523, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str116)));
      } else {
        heff_drop(v_field_24515);
        heff_drop(v_field_24516);
        v_t_24524 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str117);
      }
    }
    V v_t_24525 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str118), heff_strAppend(v_t_24524, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str119)));
    V v_t_24526 = heff_strAppend(heff_intShow(v_t_24512), v_t_24525);
    V v_t_24527 = heff_strAppend(v_t_24511, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str120), v_t_24526));
    V v_x_24528 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str121), v_t_24527), NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24506_24MkPair, TAG_MkPair, 2, (V[]){v_x_24528, v_s_24508});
  }
  default: return heff_nomatch(v_x2_24506);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam51(V self, V *args) {
  V v_s_24532 = args[0];
  V v_m_24531 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_ps_24529 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24533 = heff_tr(heff_call(v_m_24531, 1, (V[]){v_s_24532}));
  switch (heff_tag_of(v_x2_24533)) {
  case TAG_MkPair: {
    V v_x_24534 = heff_field(v_x2_24533, 0);
    V v_s_24535 = heff_field(v_x2_24533, 1);
    V v_ru_24x2_24533_24MkPair = heff_take_reuse_n(v_x2_24533, 3ULL, 2);
    V v_ts_24536 = (g_list_2emap(heff_get_n(v_k_240, 2, 6), heff_dup(v_ps_24529)));
    V v_x_24537 = (g_heff_2ecompile_2eemitc_2eagainTo(((V)&g_heff_2ecompile_2eemitc_2estmtF_str122), v_ts_24536, v_ps_24529, v_x_24534));
    return heff_tag_at_n(v_ru_24x2_24533_24MkPair, TAG_MkPair, 2, (V[]){v_x_24537, v_s_24535});
  }
  default: return heff_nomatch(v_x2_24533);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam52(V self, V *args) {
  V v_s_24542 = args[0];
  V v_m_24541 = heff_env(self)[0];
  V v_t_24538 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_ps_24539 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24543 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_s_24542}));
  switch (heff_tag_of(v_x2_24543)) {
  case TAG_MkPair: {
    V v_x_24544 = heff_field(v_x2_24543, 0);
    V v_s_24545 = heff_field(v_x2_24543, 1);
    V v_ru_24x2_24543_24MkPair = heff_take_reuse_n(v_x2_24543, 3ULL, 2);
    V v_t_24546 = ({ V a_0 = v_t_24538; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str123); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_24538); r_; });
    V v_t_24547 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str124), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str125), v_t_24546));
    V v_t_24548 = (g_list_2emap(heff_get_n(v_k_240, 2, 6), heff_dup(v_ps_24539)));
    V v_x_24549 = (g_heff_2ecompile_2eemitc_2eagainTo(v_t_24547, v_t_24548, v_ps_24539, v_x_24544));
    return heff_tag_at_n(v_ru_24x2_24543_24MkPair, TAG_MkPair, 2, (V[]){v_x_24549, v_s_24545});
  }
  default: return heff_nomatch(v_x2_24543);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam53(V self, V *args) {
  V v_s_24554 = args[0];
  V v_x_24553 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24553, v_s_24554});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam54(V self, V *args) {
  V v_s_24559 = args[0];
  V v_m_24558 = heff_env(self)[0];
  V v_w_24556 = heff_env(self)[1];
  V v_g_24555 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24560 = heff_tr(heff_call(v_m_24558, 1, (V[]){v_s_24559}));
  switch (heff_tag_of(v_x2_24560)) {
  case TAG_MkPair: {
    V v_x_24561 = heff_field(v_x2_24560, 0);
    V v_s_24562 = heff_field(v_x2_24560, 1);
    V v_ru_24x2_24560_24MkPair = heff_take_reuse_n(v_x2_24560, 3ULL, 2);
    V v_t_24565;
    if ((heff_dup(v_w_24556) == NTAG(TAG_True))) {
      heff_drop(v_w_24556);
      V v_t_24563 = ({ V a_0 = v_g_24555; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str130); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24555); r_; });
      v_t_24565 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str131), v_t_24563), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str132));
    } else {
      heff_drop(v_w_24556);
      V v_t_24564 = ({ V a_0 = v_g_24555; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str133); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24555); r_; });
      v_t_24565 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str134), v_t_24564);
    }
    V v_t_24568;
    switch (heff_tag_of(v_x_24561)) {
    case TAG_Nil: {
      v_t_24568 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str135);
      break;
    }
    case TAG_Cons: {
      V v_x_24566 = heff_field(v_x_24561, 0);
      V v_xs_24567 = heff_field(v_x_24561, 1);
      heff_take_n(v_x_24561, 3ULL, 2);
      v_t_24568 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str136); V a_1 = v_x_24566; V a_2 = v_xs_24567; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24567); r_; });
      break;
    }
    default: heff_nomatch(v_x_24561);
    }
    V v_t_24569 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str137), heff_strAppend(v_t_24568, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str138)));
    V v_t_24570 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str139), heff_strAppend(v_t_24565, v_t_24569));
    V v_x_24571 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24570, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24560_24MkPair, TAG_MkPair, 2, (V[]){v_x_24571, v_s_24562});
  }
  default: return heff_nomatch(v_x2_24560);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str3, 1, "V");
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam4(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eckOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eckOf(V v_rs_240, V v_tu_241, V v_ret_242) {
top: ;
  return heff_rec_n(6, shape_exp__stmts__ctype__tuples__ret__inLam, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam0, 1, 3, (V[]){heff_dup(v_rs_240), heff_dup(v_tu_241), heff_dup(v_ret_242)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam1, 1, 3, (V[]){heff_dup(v_rs_240), heff_dup(v_tu_241), heff_dup(v_ret_242)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam3, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_dup(v_tu_241), v_ret_242, heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam4, 1, 2, (V[]){heff_dup(v_rs_240), v_tu_241})});
}
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eckOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  V v_ret_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = v_ret_242; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
  return (g_heff_2ecompile_2eemitc_2eexpF(v_t_244, v_e_243));
}
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2410));
    V v_x_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2412); r_; });
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args) {
  V v_ss_245 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  V v_ret_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_246 = ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = v_ret_242; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
  V v_m_247 = (g_prelude_2etraverse_24s428640578x580976168(v_k_246, v_ss_245));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam2, 1, 1, (V[]){v_m_247});
}
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_rs_240; V a_1 = v_x_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_rs_240); heff_drop(v_x_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      switch (heff_tag_of(v_x_2419)) {
      case TAG_RepV: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str0);
      }
      case TAG_RepFix: {
        V v_w_2420 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 1);
        return ({ V a_0 = v_w_2420; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2420); r_; });
      }
      case TAG_RepF64: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str1);
      }
      case TAG_RepInt: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str2);
      }
      default: return heff_nomatch(v_x_2419);
      }
    } else {
      heff_drop(v_field_2417);
      return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str3);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_lam4(V self, V *args) {
  V v_u_2421 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2421);
  return ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str0, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str1, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str5, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str6, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str9, 32, "static V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str11, 1, "\012");
Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_t_245 = (g_prelude_2etraverse_24s1370495575x1780346529(heff_dup(v_ce_244), v_defs_243));
  V v_t_246 = heff_tr(heff_call(v_t_245, 1, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkPair: {
    V v_ems_247 = heff_field(v_t_246, 0);
    V v_s_248 = heff_field(v_t_246, 1);
    V v_ru_24t_246_24MkPair = heff_take_reuse_n(v_t_246, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24t_246_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str0), heff_dup(heff_rfield(v_ending_242, 0))});
    V v_t_2410 = (g_std_2emap_2etoListOnto(heff_rfield(v_ce_244, 0), NTAG(TAG_Nil)));
    V v_t_2411 = (g_list_2efilter_24s1018181017x1541469354(v_t_2410));
    V v_t_2412 = (g_list_2emap_24s275211812x1381242052(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str1), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str2), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str3), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str4), v_t_2411));
    V v_t_2413 = (g_std_2emap_2etoListOnto(heff_rfield(v_ce_244, 1), NTAG(TAG_Nil)));
    V v_t_2414 = (g_list_2emap_24s275211812x1381242052(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str5), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str6), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str7), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str8), v_t_2413));
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
    V v_t_2416 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str9), NTAG(TAG_Nil)});
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 5)));
    V v_t_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 6)));
    V v_t_2421 = (g_list_2emap_24s1173914895x100384474(v_t_2420));
    V v_t_2422 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_std_2emap_2eempty_get()), v_t_2421));
    V v_t_2423 = (g_list_2emap_24s2073083146x1445066245(v_t_2422));
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_247)));
    V v_t_2425 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24s292588827x1477362994(a_0, a_1)); heff_drop(v_t_2424); r_; });
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 3)));
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474(v_t_2426));
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_248, 7)));
    V v_t_2429 = (g_list_2emap_24s1173914895x100384474(v_t_2428));
    V v_t_2430 = (g_list_2efoldl_24f96178826x1085061806(NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get()), v_t_2429));
    V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_247));
    V v_t_2433 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s1028839125x1033007016(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_248, 2, 8)));
    V v_t_2435 = (g_list_2emap_24s1173914895x100384474(v_t_2434));
    V v_t_2436 = heff_tr(heff_call(heff_get_n(v_ending_242, 1, 2), 1, (V[]){v_ce_244}));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2435, v_t_2436));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2437));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2438));
    V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2427, v_t_2439));
    V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2440));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2447));
    V v_x2_2449 = (g_prelude_2e_2b_2b(v_t_249, v_t_2448));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str10);
    }
    case TAG_Cons: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_xs_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str11); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str0, 11, "static V g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str1, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str2, 11, "_init(void)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str3, 22, "static V heff_perform(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str4, 7, "static ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str5, 3, " g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str6, 12, "static HeffT");
Clo g_heff_2ecompile_2eemitc_2epubLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epubLine_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2epubLine(V v_l_240) {
top: ;
  V v_t_246 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(11LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str0)) && ({ int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_l_240, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_243 = heff_strSlice(heff_dup(v_l_240), heff_box_word(v_t_242), heff_strLength_lent(v_l_240, 0)); int c_ = (heff_strEq_c_lent(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2epubLine_str1), 2) ? 0 : !heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ecompile_2eemitc_2epubLine_str2), v_l_240, MK_INT(0LL), 5))); heff_drop(v_t_243); c_; }); c_; })));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
  } else {
    heff_drop(v_t_246);
    if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str3))) {
      return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
    } else {
      V v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str4); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2epubLine_str5); V a_2 = v_l_240; V b_3 = MK_INT(0LL); V b_4 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany_24s1182572632x117717553(a_0, a_1, a_2, b_3, b_4)); heff_drop(b_3); heff_drop(b_4); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      } else {
        heff_drop(v_t_248);
        if (heff_strEq_c(heff_strSlice_lent(v_l_240, MK_INT(0LL), MK_INT(12LL), 6), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str6))) {
          return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
        } else {
          return v_l_240;
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epubLine(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str0)));
    V v_o_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str1), v_t_247);
    HeffT2 v_t_249 = ({ V a_0 = v_strs_241; V a_1 = v_o_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_o_248); r_; });
    V v_t_2414;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2411;
        v_t_2414 = v_x_2413;
      } else {
        heff_drop(v_field_2411);
        v_t_2414 = NTAG(TAG_Nil);
      }
    }
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str2)));
    V v_o_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str3), v_t_2415);
    HeffT2 v_t_2417 = ({ V a_0 = v_protos_242; V a_1 = v_o_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_o_2416); r_; });
    V v_t_2422;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_x_2421 = v_field_2419;
        v_t_2422 = v_x_2421;
      } else {
        heff_drop(v_field_2419);
        v_t_2422 = NTAG(TAG_Nil);
      }
    }
    V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
    V v_t_2424 = ({ V b_0 = MK_INT(7LL); V a_1 = heff_dup(heff_rfield(v_e_246, 0)); V r_ = (g_list_2emap_24f966602123x1640556393(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2425 = (g_list_2emap_24s380834591x871125279(heff_dup(heff_rfield(v_e_246, 1))));
    V v_t_2426 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str4)));
    V v_o_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str5), v_t_2426);
    HeffT2 v_t_2428 = ({ V a_0 = v_lams_243; V a_1 = v_o_2427; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_o_2427); r_; });
    V v_t_2433;
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_x_2432 = v_field_2430;
        v_t_2433 = v_x_2432;
      } else {
        heff_drop(v_field_2430);
        v_t_2433 = NTAG(TAG_Nil);
      }
    }
    V v_t_2434 = (g_list_2emap_24s380834591x871125279(v_t_2433));
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2434));
    V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2435));
    V v_t_2437 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2436));
    return (g_prelude_2e_2b_2b(v_t_2414, v_t_2437));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eownLines(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryPart_str0, 10, "run$main.c");

static V g_heff_2ecompile_2eemitc_2eentryPart_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eentryPart_st;
static V g_heff_2ecompile_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eentryPart_str0);
}
V g_heff_2ecompile_2eemitc_2eentryPart_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eentryPart_st)) return g_heff_2ecompile_2eemitc_2eentryPart_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eentryPart_val, &g_heff_2ecompile_2eemitc_2eentryPart_st, g_heff_2ecompile_2eemitc_2eentryPart_init);
}