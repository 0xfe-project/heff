// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CDropSelf 14512
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_CTakeSelf 23160
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_MkCArm 24694
#define TAG_MkDrop 35958
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandon 7524
#define TAG_RCall 39004
#define TAG_RFloat 50557
#define TAG_RPrim 49376
#define TAG_RRec 43273
#define TAG_RTag 45075
#define TAG_StrRuneDecode 45427
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_exp 310423
#define LBL_inLam 301681229
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_ret 322331
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_tuples 1084651734
static uint32_t shape_exp__stmts__ctype__tuples__ret__inLam[] = {LBL_exp, LBL_stmts, LBL_ctype, LBL_tuples, LBL_ret, LBL_inLam};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2eagainTo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagainTo_clo;
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
HeffT6 g_heff_2ecompile_2eemitc_2eckOf_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
HeffT2 g_heff_2ecompile_2eemitc_2efunDef_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
HeffT2 g_heff_2ecompile_2eemitc_2elitName_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2estaticOf(V, V, V);
V g_heff_2ecompile_2eemitc_2estaticOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estaticOf_clo;
V g_heff_2ecompile_2eemitc_2estaticText(V, V, V, V);
V g_heff_2ecompile_2eemitc_2estaticText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estaticText_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etupleArm(V, V, V);
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleArm_clo;
HeffT2 g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2eemitc_2evalDef_24cpr(V, V, V, V, V);
V g_list_2eany_24s1041788812x158895160(V);
V g_list_2eany_24s1041788812x158895160_entry(V self, V *a);
extern Clo g_list_2eany_24s1041788812x158895160_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1668908788x1049324851(V, V);
V g_list_2efoldl_24s1668908788x1049324851_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1668908788x1049324851_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1814523351x214817707(V);
V g_list_2ekeepIf_24s1814523351x214817707_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1632378148x1903828118(V, V);
V g_list_2emap_24f1632378148x1903828118_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2133060086x110881273(V, V, V, V, V, V, V);
V g_list_2emap_24s2133060086x110881273_entry(V self, V *a);
extern Clo g_list_2emap_24s2133060086x110881273_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s952564628x174753269(V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1212489961x1573143196(V, V, V);
V g_prelude_2etraverse_24s1212489961x1573143196_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1212489961x1573143196_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
HeffT2 g_prelude_2etraverse_24s1370495575x1780346529_24cpr(V, V, V);
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str2, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str3, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str4, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str5, 4, "Just");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str6, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str7, 6, "MkPair");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str8, 3, "InL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str9, 3, "InR");
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit10, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str9), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit11, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str8), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit10));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit12, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str7), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit11));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit13, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str6), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit12));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit14, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str5), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit13));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit15, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str4), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit14));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit16, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str3), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit15));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit17, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str2), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit16));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit18, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str1), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit17));
HEFF_TAG_LIT(g_heff_2ecompile_2eemitc_2eknownTags_lit19, TAG_Cons, 2, ((V)&g_heff_2ecompile_2eemitc_2eknownTags_str0), ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit18));

static V g_heff_2ecompile_2eemitc_2eknownTags_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eknownTags_st;
static V g_heff_2ecompile_2eemitc_2eknownTags_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eknownTags_lit19);
}
V g_heff_2ecompile_2eemitc_2eknownTags_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eknownTags_st)) return g_heff_2ecompile_2eemitc_2eknownTags_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eknownTags_val, &g_heff_2ecompile_2eemitc_2eknownTags_st, g_heff_2ecompile_2eemitc_2eknownTags_init);
}
Clo g_heff_2ecompile_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c_lent(v_o_240, v_o2_245, 0)) {
        if (heff_strEq_c_lent(v_k_241, v_k2_246, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eownHas(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str2, 18, "heff_from_int_f32(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str6, 6, "sqrtf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str9, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str11, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str12, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str16, 15, "heff_floor_f32(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str18, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str19, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str21, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str22, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str24, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str25, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str26, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str27, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str28, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str29, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str39, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str41, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str42, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str43, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str44, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str45, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efloat32U_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efloat32U_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efloat32U(V v_op_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpFromInt: {
    V v_t_244;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_242 = heff_field(v_vs_241, 0);
      V v_xs_243 = heff_field(v_vs_241, 1);
      v_t_244 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str1), heff_dup(v_x_242), v_xs_243));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str2), v_t_244), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str3));
  }
  case TAG_OpSqrt: {
    V v_t_247;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_241, 0);
      V v_xs_246 = heff_field(v_vs_241, 1);
      v_t_247 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str5), heff_dup(v_x_245), v_xs_246));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str6), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str7));
  }
  case TAG_OpFromFloat: {
    V v_t_2410;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_vs_241, 0);
      v_t_2410 = heff_dup(v_x_248);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str9), v_t_2410), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str10));
  }
  case TAG_OpToFloat: {
    V v_t_2413;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_vs_241, 0);
      v_t_2413 = heff_dup(v_x_2411);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str12), v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str13));
  }
  case TAG_OpFloor: {
    V v_t_2416;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_vs_241, 0);
      V v_xs_2415 = heff_field(v_vs_241, 1);
      v_t_2416 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str15), heff_dup(v_x_2414), v_xs_2415));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str16), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str17));
  }
  default: {
    V v_t_2419;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_vs_241, 0);
      v_t_2419 = heff_dup(v_x_2417);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2420;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str19);
      break;
    }
    case TAG_OpSub: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str20);
      break;
    }
    case TAG_OpMul: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str21);
      break;
    }
    case TAG_OpDiv: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str22);
      break;
    }
    case TAG_OpRem: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str23);
      break;
    }
    case TAG_OpEq: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str24);
      break;
    }
    case TAG_OpLt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str25);
      break;
    }
    case TAG_OpLe: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str26);
      break;
    }
    case TAG_OpAnd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str27);
      break;
    }
    case TAG_OpOr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str28);
      break;
    }
    case TAG_OpXor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str29);
      break;
    }
    case TAG_OpShl: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str30);
      break;
    }
    case TAG_OpShr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str31);
      break;
    }
    case TAG_OpShow: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str32);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str33);
      break;
    }
    case TAG_OpToInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str34);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str35);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str36);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str37);
      break;
    }
    case TAG_OpFloor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str38);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    HeffT3 v_t_2421 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    {
      V v_field_2423 = v_t_2421.f[1];
      V v_field_2424 = v_t_2421.f[2];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      V v_t_2427;
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_x_2425 = v_field_2423;
        V v_x12_2426 = v_field_2424;
        heff_drop(v_x12_2426);
        v_t_2427 = v_x_2425;
      } else {
        heff_drop(v_field_2423);
        heff_drop(v_field_2424);
        v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str39);
      }
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str40), v_t_2419), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str41));
      V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_t_2420), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str42));
      V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2427), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str43));
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str44), v_t_2430), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str45));
    }
  }
  }
}
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2efloat32U(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str0, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str1, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str2, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str3, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str4, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str5, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str8, 11, "static Flt ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str9, 26, " = {{IMMORTAL, K_FLT, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str10, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str11, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str14, 7, "K_TAG, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str15, 8, "K_TAGF, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str17, 11, "{IMMORTAL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str18, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str19, 3, "}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str20, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str21, 33, "Obj h; int32_t n; uint32_t flat; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str22, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str24, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str25, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str26, 13, "HEFF_TAG_LIT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str27, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str28, 7, "K_TAG, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str29, 8, "K_TAGF, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str30, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str31, 11, "{IMMORTAL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str32, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str33, 3, "}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str34, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str35, 33, "Obj h; int32_t n; uint32_t flat; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str36, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str37, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str40, 22, "{IMMORTAL, K_REC, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str41, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str42, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str43, 48, "Obj h; int32_t n; uint32_t flat; uint32_t *lbl; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str44, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str45, 13, "HEFF_REC_LIT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str46, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str47, 22, "{IMMORTAL, K_REC, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str48, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str49, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str50, 48, "Obj h; int32_t n; uint32_t flat; uint32_t *lbl; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str51, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estaticOf_str52, 1, ")");
V g_heff_2ecompile_2eemitc_2estaticOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estaticOf_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estaticOf_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estaticOf_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estaticOf_lam4(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estaticOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estaticOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2estaticOf(V v_k_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_RFloat: {
    V v_d_243 = heff_tget_v(v_x3_242, 0);
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estaticOf_lam0, 1, 2, (V[]){heff_dup(v_x_241), v_d_243});
  }
  case TAG_RTag: {
    V v_t_2418 = heff_field(v_x3_242, 0);
    V v_flat_2419 = heff_field(v_x3_242, 1);
    V v_es_2420 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_m_2422 = (g_prelude_2etraverse_24s1212489961x1573143196(heff_clo_n(g_heff_2ecompile_2eemitc_2estaticOf_lam1, 1, 1, (V[]){heff_dup(v_k_240)}), v_k_240, heff_dup(v_es_2420)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estaticOf_lam2, 1, 5, (V[]){v_m_2422, heff_dup(v_x_241), v_flat_2419, v_t_2418, v_es_2420});
  }
  case TAG_RRec: {
    V v_ls_2458 = heff_field(v_x3_242, 0);
    V v_flat_2459 = heff_field(v_x3_242, 1);
    V v_es_2460 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_m_2462 = (g_prelude_2etraverse_24s1212489961x1573143196(heff_clo_n(g_heff_2ecompile_2eemitc_2estaticOf_lam3, 1, 1, (V[]){heff_dup(v_k_240)}), v_k_240, heff_dup(v_es_2460)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estaticOf_lam4, 1, 5, (V[]){v_m_2462, v_ls_2458, heff_dup(v_x_241), v_flat_2459, v_es_2460});
  }
  default: {
    return heff_tail(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x3_242});
  }
  }
}
V g_heff_2ecompile_2eemitc_2estaticOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2estaticOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2estaticOf_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_x_241; V a_1 = v_s_244; HeffT2 r_ = (g_heff_2ecompile_2eemitc_2elitName_24cpr(a_0, a_1)); heff_drop(v_x_241); r_; });
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_x_248 = v_field_246;
    V v_s_249 = v_field_247;
    V v_t_2411;
    if (heff_strEq_c(heff_floatShow(heff_dup(v_d_243)), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str0))) {
      heff_drop(v_d_243);
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str1);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_d_243)), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str2))) {
        heff_drop(v_d_243);
        v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str3);
      } else {
        if (heff_strEq_c(heff_floatShow(heff_dup(v_d_243)), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str4))) {
          heff_drop(v_d_243);
          v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str5);
        } else {
          V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str6), heff_floatShow(v_d_243));
          v_t_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str7));
        }
      }
    }
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str8), heff_dup(v_x_248)), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str9));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2411), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str10));
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_249, 0)), v_t_2413});
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_s_249, 5)});
    V v_s_2416 = ({ V rv_5 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_249, 223ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str11), v_x_248), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str12));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_s_2416});
  }
}
V g_heff_2ecompile_2eemitc_2estaticOf_lam1(V self, V *args) {
  V v_e_2421 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_240; V b_1 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str13); V a_2 = v_e_2421; V r_ = (g_heff_2ecompile_2eemitc_2estaticOf(a_0, b_1, a_2)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2eemitc_2estaticOf_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_flat_2419 = heff_env(self)[2];
  V v_t_2418 = heff_env(self)[3];
  V v_es_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    HeffT2 v_t_2427 = ({ V a_0 = v_x_241; V a_1 = v_s_2426; HeffT2 r_ = (g_heff_2ecompile_2eemitc_2elitName_24cpr(a_0, a_1)); heff_drop(v_x_241); r_; });
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_x_2430 = v_field_2428;
      V v_s_2431 = v_field_2429;
      V v_l_2453;
      if (heff_intEq_c_lent(v_flat_2419, MK_INT(0LL), 2)) {
        switch (heff_tag_of(v_x_2425)) {
        case TAG_Nil: {
          V v_t_2432;
          if ((heff_peek_word(v_flat_2419) == ((int64_t)0ULL))) {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str14);
          } else {
            v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str15);
          }
          V v_t_2433 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str16); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
          V v_t_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2420); r_; });
          V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str17), v_t_2432), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str18), v_t_2433));
          V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str19)), heff_intShow(v_t_2434));
          V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str20)), heff_intShow(v_flat_2419));
          v_l_2453 = (g_heff_2ecompile_2eemitc_2estaticText(heff_dup(v_x_2430), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str21), heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str22)), v_x_2425));
          break;
        }
        case TAG_Cons: {
          heff_drop(v_flat_2419);
          heff_drop(v_es_2420);
          V v_t_2440 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str23); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
          V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str24), v_t_2440);
          V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2425));
          V v_t_2443 = heff_intShow(v_t_2442);
          V v_t_2444 = (g_list_2emap_24s1173914895x100384474(v_x_2425));
          V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2444})});
          V v_t_2446 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str25); V a_1 = heff_dup(v_x_2430); V a_2 = v_t_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2445, 2); r_; });
          v_l_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str26), v_t_2446), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str27));
          break;
        }
        default: heff_nomatch(v_x_2425);
        }
      } else {
        V v_t_2447;
        if (heff_intEq_c_lent(v_flat_2419, MK_INT(0LL), 2)) {
          v_t_2447 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str28);
        } else {
          v_t_2447 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str29);
        }
        V v_t_2448 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str30); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
        V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2420; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2420); r_; });
        V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str31), v_t_2447), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str32), v_t_2448));
        V v_t_2451 = heff_strAppend(heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str33)), heff_intShow(v_t_2449));
        V v_t_2452 = heff_strAppend(heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str34)), heff_intShow(v_flat_2419));
        v_l_2453 = (g_heff_2ecompile_2eemitc_2estaticText(heff_dup(v_x_2430), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str35), heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str36)), v_x_2425));
      }
      V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str37), v_x_2430), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str38));
      V v_t_2455 = heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_2431, 0)), v_l_2453});
      V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, heff_take_field(v_s_2431, 5)});
      V v_t_2457 = ({ V rv_5 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_s_2431, 223ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2454, v_t_2457});
    }
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eemitc_2estaticOf_lam3(V self, V *args) {
  V v_e_2461 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_240; V b_1 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str39); V a_2 = v_e_2461; V r_ = (g_heff_2ecompile_2eemitc_2estaticOf(a_0, b_1, a_2)); heff_drop(b_1); r_; });
}
V g_heff_2ecompile_2eemitc_2estaticOf_lam4(V self, V *args) {
  V v_s_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  V v_ls_2458 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_flat_2459 = heff_env(self)[3];
  V v_es_2460 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_s_2463}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_s_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    HeffT2 v_t_2467 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(v_ls_2458, v_s_2466));
    {
      V v_field_2468 = v_t_2467.f[0];
      V v_field_2469 = v_t_2467.f[1];
      V v_x_2470 = v_field_2468;
      V v_s_2471 = v_field_2469;
      HeffT2 v_t_2472 = ({ V a_0 = v_x_241; V a_1 = v_s_2471; HeffT2 r_ = (g_heff_2ecompile_2eemitc_2elitName_24cpr(a_0, a_1)); heff_drop(v_x_241); r_; });
      {
        V v_field_2473 = v_t_2472.f[0];
        V v_field_2474 = v_t_2472.f[1];
        V v_x_2475 = v_field_2473;
        V v_s_2476 = v_field_2474;
        V v_l_2492;
        if (heff_intEq_c_lent(v_flat_2459, MK_INT(0LL), 2)) {
          switch (heff_tag_of(v_x_2465)) {
          case TAG_Nil: {
            V v_t_2477 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2460; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2460); r_; });
            V v_t_2478 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str40), heff_intShow(v_t_2477));
            V v_t_2479 = heff_strAppend(heff_strAppend(v_t_2478, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str41)), heff_intShow(v_flat_2459));
            V v_t_2480 = heff_strAppend(heff_strAppend(v_t_2479, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str42)), v_x_2470);
            v_l_2492 = (g_heff_2ecompile_2eemitc_2estaticText(heff_dup(v_x_2475), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str43), v_t_2480, v_x_2465));
            break;
          }
          case TAG_Cons: {
            heff_drop(v_flat_2459);
            heff_drop(v_es_2460);
            V v_t_2483 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2465));
            V v_t_2484 = heff_intShow(v_t_2483);
            V v_t_2485 = (g_list_2emap_24s1173914895x100384474(v_x_2465));
            V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2470, v_t_2485})});
            V v_t_2487 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str44); V a_1 = heff_dup(v_x_2475); V a_2 = v_t_2486; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2486, 2); r_; });
            v_l_2492 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str45), v_t_2487), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str46));
            break;
          }
          default: heff_nomatch(v_x_2465);
          }
        } else {
          V v_t_2488 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2460; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2460); r_; });
          V v_t_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str47), heff_intShow(v_t_2488));
          V v_t_2490 = heff_strAppend(heff_strAppend(v_t_2489, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str48)), heff_intShow(v_flat_2459));
          V v_t_2491 = heff_strAppend(heff_strAppend(v_t_2490, ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str49)), v_x_2470);
          v_l_2492 = (g_heff_2ecompile_2eemitc_2estaticText(heff_dup(v_x_2475), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str50), v_t_2491, v_x_2465));
        }
        V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estaticOf_str51), v_x_2475), ((V)&g_heff_2ecompile_2eemitc_2estaticOf_str52));
        V v_t_2494 = heff_tag_at_n(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_s_2476, 0)), v_l_2492});
        V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, heff_take_field(v_s_2476, 5)});
        V v_t_2496 = ({ V rv_5 = v_t_2495; V rr_ = heff_rec_reuse_nf(v_s_2476, 223ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2493, v_t_2496});
      }
    }
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str1, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str2, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str4, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str5, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str8, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str9, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str13, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str14, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str16, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str17, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str18, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str19, 15, "heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str21, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str23, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str24, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str25, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str26, 20, "switch (heff_tag_of(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str27, 4, ")) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str28, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str29, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str30, 18, "default: return ((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str31, 16, "){{heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str32, 5, ")}});");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str33, 29, "default: return heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str34, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str35, 22, "default: heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str36, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str37, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str38, 9, "return ((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str39, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str40, 21, "){{heff_abandon()}});");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str41, 22, "return heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str42, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str43, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str44, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str45, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str46, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str47, 5, "args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str48, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str49, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str50, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str51, 52, ", args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str52, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str53, 8, ", args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str54, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str55, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str56, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str57, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str58, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str59, 17, "return heff_tail(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str60, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str61, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str62, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str63, 3, "top");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str64, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str65, 4, "top_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str66, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str67, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str68, 4, "top_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str69, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str70, 3, ": ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str71, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str72, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str73, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str74, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str75, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str76, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str77, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str78, 17, "HEFF_LAST return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str79, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str80, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str81, 20, "heff_clo_take(self, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str82, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str83, 16, "heff_drop(self);");
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2estmtF_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_lam4, 1, 0};
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam18(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2estmtF_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_lam18, 1, 0};
Clo g_heff_2ecompile_2eemitc_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estmtF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_248;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x12_244 = heff_field(v_d_242, 1);
      heff_take_n(v_d_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = ({ V a_0 = v_x_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_243); r_; });
        V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str2), v_t_245));
        v_t_248 = heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str3));
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_243); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam0, 1, 1, (V[]){v_x_249});
  }
  case TAG_CLet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_e_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_k_2413 = heff_dup(v_k_240);
    V v_ctype_2414 = heff_take_field(v_k_2413, 2);
    V v_tuples_2415 = heff_get_n(v_k_2413, 3, 6);
    V v_x_2416 = heff_dup(v_x_2411);
    V v_e_2417 = heff_dup(v_e_2412);
    V v_t_2436;
    switch (heff_tag_of(v_e_2417)) {
    case TAG_RPrim: {
      V v_p_2418 = heff_field(v_e_2417, 0);
      heff_take_n(v_e_2417, 1ULL, 2);
      heff_drop(v_tuples_2415);
      int64_t v_t_2420;
      switch (heff_tag_of(v_p_2418)) {
      case TAG_StrRuneDecode: {
        v_t_2420 = ((int64_t)2ULL);
        break;
      }
      default: {
        v_t_2420 = ((int64_t)0ULL);
        break;
      }
      }
      if ((((int64_t)0ULL) < v_t_2420)) {
        heff_drop(v_ctype_2414);
        heff_drop(v_x_2416);
        V v_t_2421;
        switch (heff_tag_of(v_p_2418)) {
        case TAG_StrRuneDecode: {
          v_t_2421 = MK_INT(2LL);
          break;
        }
        default: {
          heff_drop(v_p_2418);
          v_t_2421 = MK_INT(0LL);
          break;
        }
        }
        v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str4), heff_intShow(v_t_2421));
      } else {
        heff_drop(v_p_2418);
        v_t_2436 = heff_tr(heff_call(v_ctype_2414, 1, (V[]){v_x_2416}));
      }
      break;
    }
    case TAG_RCall: {
      V v_g_2422 = heff_field(v_e_2417, 0);
      heff_take_n(v_e_2417, 1ULL, 4);
      HeffT2 v_t_2426 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_tuples_2415, v_g_2422));
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        V v_t_2430;
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_x_2429 = v_field_2428;
          v_t_2430 = v_x_2429;
        } else {
          heff_drop(v_field_2428);
          v_t_2430 = MK_INT(0LL);
        }
        if (heff_intLt_c(MK_INT(0LL), v_t_2430)) {
          heff_drop(v_ctype_2414);
          heff_drop(v_x_2416);
          HeffT2 v_t_2431 = ({ V a_0 = v_tuples_2415; V a_1 = v_g_2422; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_tuples_2415); heff_drop(v_g_2422); r_; });
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            V v_t_2435;
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              V v_x_2434 = v_field_2433;
              v_t_2435 = v_x_2434;
            } else {
              heff_drop(v_field_2433);
              v_t_2435 = MK_INT(0LL);
            }
            v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str5), heff_intShow(v_t_2435));
          }
        } else {
          heff_drop(v_tuples_2415);
          heff_drop(v_g_2422);
          v_t_2436 = heff_tr(heff_call(v_ctype_2414, 1, (V[]){v_x_2416}));
        }
      }
      break;
    }
    default: {
      heff_drop(v_tuples_2415);
      heff_drop(v_e_2417);
      v_t_2436 = heff_tr(heff_call(v_ctype_2414, 1, (V[]){v_x_2416}));
      break;
    }
    }
    V v_t_2437 = ({ V a_0 = v_x_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str6); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
    V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str7)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str8), v_t_2437));
    V v_pre_2439 = heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str9));
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2412}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam1, 1, 2, (V[]){v_m_2440, v_pre_2439});
  }
  case TAG_CDecl: {
    V v_x_2447 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2448 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_2447)}));
    V v_t_2449 = ({ V a_0 = v_x_2447; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str11); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2447); r_; });
    V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str12)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str13), v_t_2449));
    V v_x_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str14)), NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam2, 1, 1, (V[]){v_x_2451});
  }
  case TAG_CSet: {
    V v_x_2453 = heff_field(v_x2_241, 0);
    V v_e_2454 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2455 = ({ V a_0 = v_x_2453; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str15); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2453); r_; });
    V v_pre_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str16), v_t_2455), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str17));
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2454}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam3, 1, 2, (V[]){v_m_2457, v_pre_2456});
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2estmtF_lam4_clo);
  }
  case TAG_CIf: {
    V v_c_2466 = heff_field(v_x2_241, 0);
    V v_yes_2467 = heff_field(v_x2_241, 1);
    V v_no_2468 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2469 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_2466));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam5, 1, 4, (V[]){v_m_2469, v_k_240, v_yes_2467, v_no_2468});
  }
  case TAG_CSwitch: {
    V v_e_2488 = heff_field(v_x2_241, 0);
    V v_arms_2489 = heff_field(v_x2_241, 1);
    V v_returns_2490 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_2488}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam6, 1, 4, (V[]){v_m_2491, v_arms_2489, v_k_240, v_returns_2490});
  }
  case TAG_CReturn: {
    V v_x21_24141 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_24141)) {
    case TAG_RAbandon: {
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam8, 1, 1, (V[]){v_k_240});
    }
    default: {
      V v_m_24147 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24141}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam9, 1, 1, (V[]){v_m_24147});
    }
    }
  }
  case TAG_CInPlace: {
    V v_f_24154 = heff_field(v_x2_241, 0);
    V v_es_24155 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24156 = heff_get_n(v_k_240, 0, 6);
    V v_m_24157 = heff_tr(heff_call(heff_dup(v_f_24156), 1, (V[]){v_f_24154}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam10, 1, 3, (V[]){v_m_24157, v_f_24156, v_es_24155});
  }
  case TAG_CRoomed: {
    V v_f_24184 = heff_field(v_x2_241, 0);
    V v_es_24185 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24186 = heff_get_n(v_k_240, 0, 6);
    V v_m_24187 = heff_tr(heff_call(heff_dup(v_f_24186), 1, (V[]){v_f_24184}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam11, 1, 3, (V[]){v_m_24187, v_f_24186, v_es_24185});
  }
  case TAG_CTail: {
    V v_f_24197 = heff_field(v_x2_241, 0);
    V v_es_24198 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24199 = heff_get_n(v_k_240, 0, 6);
    V v_m_24200 = heff_tr(heff_call(heff_dup(v_f_24199), 1, (V[]){v_f_24197}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam12, 1, 3, (V[]){v_m_24200, v_f_24199, v_es_24198});
  }
  case TAG_CLoop: {
    V v_ps_24224 = heff_field(v_x2_241, 0);
    V v_es_24225 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24226 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_24225));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam13, 1, 3, (V[]){v_m_24226, v_k_240, v_ps_24224});
  }
  case TAG_CLoopTo: {
    V v_t_24233 = heff_field(v_x2_241, 0);
    V v_ps_24234 = heff_field(v_x2_241, 1);
    V v_es_24235 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24236 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_24235));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam14, 1, 4, (V[]){v_m_24236, v_t_24233, v_k_240, v_ps_24234});
  }
  case TAG_CLabel: {
    V v_t_24245 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_24246 = ({ V a_0 = v_t_24245; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str67); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_24245); r_; });
    V v_t_24247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str68), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str69), v_t_24246));
    V v_x_24248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24247, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str70)), NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam15, 1, 1, (V[]){v_x_24248});
  }
  case TAG_CJump: {
    V v_g_24250 = heff_field(v_x2_241, 0);
    V v_w_24251 = heff_field(v_x2_241, 1);
    V v_es_24252 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24253 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24252));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam16, 1, 3, (V[]){v_m_24253, v_w_24251, v_g_24250});
  }
  case TAG_CTakeSelf: {
    V v_n_24267 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam17, 1, 1, (V[]){v_n_24267});
  }
  case TAG_CDropSelf: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2estmtF_lam18_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estmtF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args) {
  V v_s_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_pre_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_s_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    V v_t_2445 = heff_strAppend(heff_strAppend(v_pre_2439, v_x_2443), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str10));
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2446, v_s_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args) {
  V v_s_2452 = args[0];
  V v_x_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_s_2452});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_pre_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2462 = heff_strAppend(heff_strAppend(v_pre_2456, v_x_2460), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str18));
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2463, v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args) {
  V v_s_2464 = args[0];
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str19), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_s_2464});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_yes_2467 = heff_env(self)[2];
  V v_no_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    V v_m_2474 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_yes_2467}));
    V v_x2_2475 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2473}));
    switch (heff_tag_of(v_x2_2475)) {
    case TAG_MkPair: {
      V v_x_2476 = heff_field(v_x2_2475, 0);
      V v_s_2477 = heff_field(v_x2_2475, 1);
      V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
      V v_m_2478 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 6), 1, (V[]){v_no_2468}));
      V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_s_2477}));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_MkPair: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_s_2481 = heff_field(v_x2_2479, 1);
        V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
        V v_t_2482 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2estmtF_str20), v_x_2476));
        V v_t_2483 = heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str21), NTAG(TAG_Nil)});
        V v_t_2484 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2483, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str22), v_x_2480));
        V v_t_2485 = (g_prelude_2e_2b_2b(v_t_2482, heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str23), v_t_2484})));
        V v_t_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str24), v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str25));
        V v_x_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, v_t_2485});
        return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_x_2487, v_s_2481});
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
    default: return heff_nomatch(v_x2_2475);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args) {
  V v_a_2496 = args[0];
  V v_arms_2489 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_arms_2489)) {
  case TAG_Nil: {
    return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
  }
  case TAG_Cons: {
    V v_arms1_2497 = heff_field(v_arms_2489, 0);
    V v_arms2_2498 = heff_field(v_arms_2489, 1);
    heff_take_n(v_arms_2489, 3ULL, 2);
    switch (heff_tag_of(v_arms1_2497)) {
    case TAG_MkCArm: {
      V v_t_2499 = heff_field(v_arms1_2497, 0);
      heff_take_n(v_arms1_2497, 1ULL, 8);
      switch (heff_tag_of(v_arms2_2498)) {
      case TAG_Nil: {
        if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2499, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2499, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
          heff_drop(v_t_2499);
          return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2etupleArm(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
        } else {
          heff_drop(v_t_2499);
          return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
        }
      }
      case TAG_Cons: {
        heff_take_n(v_arms2_2498, 0ULL, 2);
        heff_drop(v_t_2499);
        return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
      }
      default: return heff_nomatch(v_arms2_2498);
      }
    }
    default: return heff_nomatch(v_arms1_2497);
    }
  }
  default: return heff_nomatch(v_arms_2489);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  V v_arms_2489 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_returns_2490 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2493 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_t_24109 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam7, 1, 3, (V[]){heff_dup(v_arms_2489), heff_dup(v_k_240), heff_dup(v_x_2494)}), heff_dup(v_arms_2489)));
    V v_x2_24110 = heff_tr(heff_call(v_t_24109, 1, (V[]){v_s_2495}));
    switch (heff_tag_of(v_x2_24110)) {
    case TAG_MkPair: {
      V v_x_24111 = heff_field(v_x2_24110, 0);
      V v_s_24112 = heff_field(v_x2_24110, 1);
      V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
      V v_t_24125;
      switch (heff_tag_of(v_arms_2489)) {
      case TAG_Nil: {
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_arms1_24113 = heff_dup(heff_field(v_arms_2489, 0));
        V v_arms2_24114 = heff_dup(heff_field(v_arms_2489, 1));
        switch (heff_tag_of(v_arms1_24113)) {
        case TAG_MkCArm: {
          V v_t_24115 = heff_field(v_arms1_24113, 0);
          heff_take_n(v_arms1_24113, 1ULL, 8);
          switch (heff_tag_of(v_arms2_24114)) {
          case TAG_Nil: {
            v_t_24125 = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24115, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_24115, MK_INT(0LL), 2)) == ((int64_t)35ULL))));
            heff_drop(v_t_24115);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_arms2_24114, 0ULL, 2);
            heff_drop(v_t_24115);
            v_t_24125 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_arms2_24114);
          }
          break;
        }
        default: heff_nomatch(v_arms1_24113);
        }
        break;
      }
      default: heff_nomatch(v_arms_2489);
      }
      V v_x_24140;
      if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
        heff_drop(v_arms_2489);
        heff_drop_rec(v_k_240, 6);
        heff_drop(v_returns_2490);
        heff_drop(v_x_2494);
        heff_drop_cell(v_ru_24x2_24110_24MkPair, 2);
        heff_drop(v_t_24125);
        V v_t_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24111));
        v_x_24140 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24126; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24126); r_; });
      } else {
        heff_drop(v_t_24125);
        V v_t_24127 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str26), heff_dup(v_x_2494)), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str27));
        V v_t_24128 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24111));
        V v_t_24129 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24128; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24128); r_; });
        V v_t_24130 = ({ V a_0 = v_arms_2489; V r_ = (g_list_2eany_24s1041788812x158895160(a_0)); heff_drop(v_arms_2489); r_; });
        V v_t_24138;
        if ((heff_dup(v_t_24130) == NTAG(TAG_True))) {
          heff_drop_rec(v_k_240, 6);
          heff_drop(v_returns_2490);
          heff_drop(v_x_2494);
          heff_drop(v_t_24130);
          v_t_24138 = heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str28), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_24130);
          V v_n_24131 = heff_get_n(v_k_240, 4, 6);
          V v_x2_24132 = v_returns_2490;
          V v_sv_24133 = v_x_2494;
          V v_t_24136;
          if ((heff_dup(v_x2_24132) == NTAG(TAG_True))) {
            heff_drop(v_x2_24132);
            if (heff_intLt_c_lent(MK_INT(0LL), v_n_24131, 1)) {
              V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str29), heff_intShow(v_n_24131));
              V v_t_24135 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str30), v_t_24134), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str31));
              v_t_24136 = heff_strAppend(heff_strAppend(v_t_24135, v_sv_24133), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str32));
            } else {
              heff_drop(v_n_24131);
              v_t_24136 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str33), v_sv_24133), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str34));
            }
          } else {
            heff_drop(v_n_24131);
            heff_drop(v_x2_24132);
            v_t_24136 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str35), v_sv_24133), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str36));
          }
          V v_t_24137 = heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str37), NTAG(TAG_Nil)});
          v_t_24138 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, v_t_24137});
        }
        V v_ys_24139 = (g_prelude_2e_2b_2b(v_t_24129, v_t_24138));
        v_x_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24127, v_ys_24139});
      }
      return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_x_24140, v_s_24112});
    }
    default: return heff_nomatch(v_x2_24110);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args) {
  V v_s_24142 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_t_24145;
  heff_clo_take(self, 1);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_k_240, 4)))) {
    V v_t_24143 = heff_intShow(heff_get_n(v_k_240, 4, 6));
    V v_t_24144 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str38), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str39), v_t_24143));
    v_t_24145 = heff_strAppend(v_t_24144, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str40));
  } else {
    heff_drop_rec(v_k_240, 6);
    v_t_24145 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str41);
  }
  V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24145, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24146, v_s_24142});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args) {
  V v_s_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_s_24148}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_s_24151 = heff_field(v_x2_24149, 1);
    V v_ru_24x2_24149_24MkPair = heff_take_reuse_n(v_x2_24149, 3ULL, 2);
    V v_t_24152 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str42), v_x_24150), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str43));
    V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24152, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_24149_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24153, v_s_24151});
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args) {
  V v_s_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_f_24156 = heff_env(self)[1];
  V v_es_24155 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_s_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_s_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_t_24162 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24156, v_es_24155));
    V v_x2_24163 = heff_tr(heff_call(v_t_24162, 1, (V[]){v_s_24161}));
    switch (heff_tag_of(v_x2_24163)) {
    case TAG_MkPair: {
      V v_x_24164 = heff_field(v_x2_24163, 0);
      V v_s_24165 = heff_field(v_x2_24163, 1);
      V v_ru_24x2_24163_24MkPair = heff_take_reuse_n(v_x2_24163, 3ULL, 2);
      V v_vs_24166 = heff_tag_at_n(v_ru_24x2_24163_24MkPair, TAG_Cons, 2, (V[]){v_x_24160, v_x_24164});
      V v_t_24169;
      switch (heff_tag_of(v_vs_24166)) {
      case TAG_Nil: {
        v_t_24169 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str44);
        break;
      }
      case TAG_Cons: {
        V v_x_24167 = heff_dup(heff_field(v_vs_24166, 0));
        v_t_24169 = v_x_24167;
        break;
      }
      default: heff_nomatch(v_vs_24166);
      }
      V v_t_24170 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str45), v_t_24169), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str46));
      V v_t_24171 = (g_list_2edrop(MK_INT(1LL), v_vs_24166));
      V v_t_24172 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_24166));
      V v_t_24173 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_24172, MK_INT(2LL))));
      V v_t_24174 = (g_list_2ezipWith_24s952564628x174753269(((V)&g_heff_2ecompile_2eemitc_2estmtF_str47), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str48), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str49), v_t_24171, v_t_24173));
      V v_t_24175 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_24166));
      V v_t_24176 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_24166; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_vs_24166, 2); r_; });
      V v_t_24177 = heff_intShow(heff_intSub(v_t_24175, MK_INT(1LL)));
      V v_t_24178 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str50), v_t_24177), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str51));
      V v_t_24179 = heff_intShow(heff_intSub(v_t_24176, MK_INT(1LL)));
      V v_t_24180 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str52), v_t_24179), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str53));
      V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24180, NTAG(TAG_Nil)});
      V v_ys_24182 = (g_prelude_2e_2b_2b(v_t_24174, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24178, v_t_24181})));
      V v_x_24183 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24170, v_ys_24182});
      return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_x_24183, v_s_24165});
    }
    default: return heff_nomatch(v_x2_24163);
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args) {
  V v_s_24188 = args[0];
  V v_m_24187 = heff_env(self)[0];
  V v_f_24186 = heff_env(self)[1];
  V v_es_24185 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24189 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_s_24188}));
  switch (heff_tag_of(v_x2_24189)) {
  case TAG_MkPair: {
    V v_x_24190 = heff_field(v_x2_24189, 0);
    V v_s_24191 = heff_field(v_x2_24189, 1);
    V v_ru_24x2_24189_24MkPair = heff_take_reuse_n(v_x2_24189, 3ULL, 2);
    V v_t_24192 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24186, v_es_24185));
    V v_x2_24193 = heff_tr(heff_call(v_t_24192, 1, (V[]){v_s_24191}));
    switch (heff_tag_of(v_x2_24193)) {
    case TAG_MkPair: {
      V v_x_24194 = heff_field(v_x2_24193, 0);
      V v_s_24195 = heff_field(v_x2_24193, 1);
      V v_ru_24x2_24193_24MkPair = heff_take_reuse_n(v_x2_24193, 3ULL, 2);
      V v_x_24196 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_24193_24MkPair, TAG_Cons, 2, (V[]){v_x_24190, v_x_24194}); V r_ = (g_heff_2ecompile_2eemitc_2eroomed(b_0)); heff_drop(b_0); r_; });
      return heff_tag_at_n(v_ru_24x2_24189_24MkPair, TAG_MkPair, 2, (V[]){v_x_24196, v_s_24195});
    }
    default: return heff_nomatch(v_x2_24193);
    }
  }
  default: return heff_nomatch(v_x2_24189);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args) {
  V v_s_24201 = args[0];
  V v_m_24200 = heff_env(self)[0];
  V v_f_24199 = heff_env(self)[1];
  V v_es_24198 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24202 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_s_24201}));
  switch (heff_tag_of(v_x2_24202)) {
  case TAG_MkPair: {
    V v_x_24203 = heff_field(v_x2_24202, 0);
    V v_s_24204 = heff_field(v_x2_24202, 1);
    V v_ru_24x2_24202_24MkPair = heff_take_reuse_n(v_x2_24202, 3ULL, 2);
    V v_t_24205 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24199, heff_dup(v_es_24198)));
    V v_x2_24206 = heff_tr(heff_call(v_t_24205, 1, (V[]){v_s_24204}));
    switch (heff_tag_of(v_x2_24206)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_field(v_x2_24206, 0);
      V v_s_24208 = heff_field(v_x2_24206, 1);
      V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
      V v_t_24209 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24198; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24198); r_; });
      HeffT3 v_t_24210 = ({ V a_0 = MK_INT(1LL); V b_1 = heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_24203), v_x_24207}); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_24212 = v_t_24210.f[1];
        V v_field_24213 = v_t_24210.f[2];
        int64_t v_tag_24211 = ((int64_t)v_t_24210.f[0]);
        V v_t_24219;
        if ((v_tag_24211 == ((int64_t)0ULL))) {
          V v_x11_24214 = heff_dup(v_field_24212);
          heff_drop(v_x11_24214);
          V v_x12_24215 = heff_dup(v_field_24213);
          heff_drop(v_x12_24215);
          V v_t_24218;
          if ((v_tag_24211 == ((int64_t)0ULL))) {
            V v_x_24216 = v_field_24212;
            V v_xs_24217 = v_field_24213;
            v_t_24218 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str54); V a_1 = v_x_24216; V a_2 = v_xs_24217; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24217); r_; });
          } else {
            heff_drop(v_field_24212);
            heff_drop(v_field_24213);
            v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str55);
          }
          v_t_24219 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str56), v_t_24218), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str57));
        } else {
          heff_drop(v_field_24212);
          heff_drop(v_field_24213);
          v_t_24219 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str58);
        }
        V v_t_24220 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str59), v_x_24203), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str60));
        V v_t_24221 = heff_strAppend(v_t_24220, heff_intShow(v_t_24209));
        V v_t_24222 = heff_strAppend(heff_strAppend(v_t_24221, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str61)), v_t_24219);
        V v_x_24223 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24222, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str62)), NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x2_24202_24MkPair, TAG_MkPair, 2, (V[]){v_x_24223, v_s_24208});
      }
    }
    default: return heff_nomatch(v_x2_24206);
    }
  }
  default: return heff_nomatch(v_x2_24202);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam13(V self, V *args) {
  V v_s_24227 = args[0];
  V v_m_24226 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_ps_24224 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24228 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_s_24227}));
  switch (heff_tag_of(v_x2_24228)) {
  case TAG_MkPair: {
    V v_x_24229 = heff_field(v_x2_24228, 0);
    V v_s_24230 = heff_field(v_x2_24228, 1);
    V v_ru_24x2_24228_24MkPair = heff_take_reuse_n(v_x2_24228, 3ULL, 2);
    V v_ts_24231 = (g_list_2emap(heff_get_n(v_k_240, 2, 6), heff_dup(v_ps_24224)));
    V v_x_24232 = (g_heff_2ecompile_2eemitc_2eagainTo(((V)&g_heff_2ecompile_2eemitc_2estmtF_str63), v_ts_24231, v_ps_24224, v_x_24229));
    return heff_tag_re_n(v_ru_24x2_24228_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24232, v_s_24230});
  }
  default: return heff_nomatch(v_x2_24228);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam14(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  V v_t_24233 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_ps_24234 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    V v_ru_24x2_24238_24MkPair = heff_take_reuse_n(v_x2_24238, 3ULL, 2);
    V v_t_24241 = ({ V a_0 = v_t_24233; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str64); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_24233); r_; });
    V v_t_24242 = (g_list_2emap(heff_get_n(v_k_240, 2, 6), heff_dup(v_ps_24234)));
    V v_t_24243 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str65), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str66), v_t_24241));
    V v_x_24244 = (g_heff_2ecompile_2eemitc_2eagainTo(v_t_24243, v_t_24242, v_ps_24234, v_x_24239));
    return heff_tag_re_n(v_ru_24x2_24238_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24244, v_s_24240});
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam15(V self, V *args) {
  V v_s_24249 = args[0];
  V v_x_24248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24248, v_s_24249});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam16(V self, V *args) {
  V v_s_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  V v_w_24251 = heff_env(self)[1];
  V v_g_24250 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24255 = heff_tr(heff_call(v_m_24253, 1, (V[]){v_s_24254}));
  switch (heff_tag_of(v_x2_24255)) {
  case TAG_MkPair: {
    V v_x_24256 = heff_field(v_x2_24255, 0);
    V v_s_24257 = heff_field(v_x2_24255, 1);
    V v_ru_24x2_24255_24MkPair = heff_take_reuse_n(v_x2_24255, 3ULL, 2);
    V v_t_24260;
    if ((heff_dup(v_w_24251) == NTAG(TAG_True))) {
      heff_drop(v_w_24251);
      V v_t_24258 = ({ V a_0 = v_g_24250; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str71); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24250); r_; });
      v_t_24260 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str72), v_t_24258), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str73));
    } else {
      heff_drop(v_w_24251);
      V v_t_24259 = ({ V a_0 = v_g_24250; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str74); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24250); r_; });
      v_t_24260 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str75), v_t_24259);
    }
    V v_t_24263;
    switch (heff_tag_of(v_x_24256)) {
    case TAG_Nil: {
      v_t_24263 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str76);
      break;
    }
    case TAG_Cons: {
      V v_x_24261 = heff_field(v_x_24256, 0);
      V v_xs_24262 = heff_field(v_x_24256, 1);
      heff_take_n(v_x_24256, 3ULL, 2);
      v_t_24263 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str77); V a_1 = v_x_24261; V a_2 = v_xs_24262; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24262); r_; });
      break;
    }
    default: heff_nomatch(v_x_24256);
    }
    V v_t_24264 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str78), v_t_24260), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str79));
    V v_t_24265 = heff_strAppend(heff_strAppend(v_t_24264, v_t_24263), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str80));
    V v_x_24266 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24265, NTAG(TAG_Nil)});
    return heff_tag_re_n(v_ru_24x2_24255_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24266, v_s_24257});
  }
  default: return heff_nomatch(v_x2_24255);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam17(V self, V *args) {
  V v_s_24268 = args[0];
  V v_n_24267 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24269 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str81), heff_intShow(v_n_24267));
  V v_t_24270 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24269, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str82)), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24270, v_s_24268});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam18(V self, V *args) {
  V v_s_24271 = args[0];
  V v_t_24272 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str83), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24272, v_s_24271});
}
Clo g_heff_2ecompile_2eemitc_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eckOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eckOf(V v_rs_240, V v_tu_241, V v_ret_242) {
top: ;
  HeffT6 v_t_243 = (g_heff_2ecompile_2eemitc_2eckOf_24cpr(v_rs_240, v_tu_241, v_ret_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    V v_field_247 = v_t_243.f[3];
    V v_field_248 = v_t_243.f[4];
    V v_field_249 = v_t_243.f[5];
    return heff_rec_n(6, shape_exp__stmts__ctype__tuples__ret__inLam, (V[]){v_field_244, v_field_245, v_field_246, v_field_247, v_field_248, v_field_249});
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eckOf(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V v_tu_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DFun: {
    V v_f_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_tu_240, heff_rfield(v_f_243, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_248;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        v_t_248 = v_x_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_t_248)) {
        HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_tu_240, heff_rfield(v_f_243, 0)));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          V v_t_2413;
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2411;
            v_t_2413 = v_x_2412;
          } else {
            heff_drop(v_field_2411);
            v_t_2413 = MK_INT(0LL);
          }
          return (g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(v_tu_240, v_t_2413, heff_dup(v_f_243), v_z_242));
        }
      } else {
        HEFF_LAST return g_heff_2ecompile_2eemitc_2efunDef_24cpr(v_tu_240, heff_dup(v_f_243), v_z_242);
      }
    }
  }
  case TAG_DVal: {
    V v_key_2414 = heff_field(v_x2_241, 0);
    V v_body_2415 = heff_field(v_x2_241, 1);
    V v_rs_2416 = heff_field(v_x2_241, 2);
    return (g_heff_2ecompile_2eemitc_2evalDef_24cpr(v_tu_240, v_key_2414, heff_dup(v_body_2415), v_rs_2416, v_z_242));
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str0, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str2, 12, "static void ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str3, 12, "(void *q) { ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str4, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str5, 8, " *)q); }");
Clo g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(V v_leaf_240, V v_what_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_leaf_240);
    heff_drop(v_what_241);
    heff_drop(v_i_242);
    return heff_setField(heff_dup(v_d_244), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_t_247 = heff_field(v_x41_245, 0);
      V v_r_248 = heff_field(v_x41_245, 1);
      heff_take_n(v_x41_245, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str0), heff_dup(v_leaf_240)), ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str1));
      V v_t_2410 = heff_strAppend(heff_dup(v_what_241), heff_intShow(heff_dup(v_i_242)));
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str2), heff_strAppend(v_t_249, v_t_2410));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str3)), v_r_248);
      V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str4)), v_t_247);
      V v_cell_2414 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str5)), heff_hole()});
      V v_u_2415 = heff_setFieldPeek(v_d_244, MK_INT(1LL), v_cell_2414);
      V t_0 = v_leaf_240;
      V t_1 = v_what_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_u_2415;
      v_leaf_240 = t_0;
      v_what_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str0, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str1, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str4, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str5, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str8, 22, "V heff_bocTaken(V tn);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str9, 27, "V heff_bocGiven(V tn, V v);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str10, 49, "V heff_bocWhen(V cs, V body, V cond, V ws, V rs);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str11, 19, "V heff_bocNew(V v);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str12, 32, "static V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str13, 41, "static V heff_performAt(int i, V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str14, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str16, 1, "\012");
Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_end_245 = heff_take_field(v_ending_242, 1);
  V v_prefix_246 = heff_get_n(v_ending_242, 0, 2);
  HeffT2 v_t_247 = (g_prelude_2etraverse_24s1370495575x1780346529_24cpr(heff_dup(v_ce_244), v_defs_243, heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_ems_2410 = v_field_248;
    V v_s_2411 = v_field_249;
    V v_shapes_2412 = heff_take_field(v_s_2411, 6);
    V v_strs_2413 = heff_take_field(v_s_2411, 5);
    V v_protos_2414 = heff_take_field(v_s_2411, 3);
    V v_prims_2415 = heff_take_field(v_s_2411, 7);
    V v_lams_2416 = heff_get_n(v_s_2411, 2, 8);
    V v_t_2417 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_ce_244, 0), NTAG(TAG_Nil)));
    V v_t_2418 = (g_list_2ekeepIf_24s1814523351x214817707(v_t_2417));
    V v_t_2419 = (g_list_2emap_24s2133060086x110881273(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str0), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str1), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str2), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str3), v_t_2418));
    V v_t_2420 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_ce_244, 1), NTAG(TAG_Nil)));
    V v_t_2421 = (g_list_2emap_24s2133060086x110881273(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str4), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str5), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str6), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str7), v_t_2420));
    V v_t_2422 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_shapes_2412));
    V v_t_2424 = (g_list_2emap_24s1173914895x100384474(v_t_2423));
    V v_t_2425 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2424));
    V v_t_2426 = (g_list_2emap_24s2073083146x1445066245(v_t_2425));
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_strs_2413));
    V v_t_2428 = (g_list_2emap_24s1173914895x100384474(v_t_2427));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_2410)));
    V v_t_2430 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2429; V r_ = (g_list_2efoldl_24s292588827x1477362994(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_protos_2414));
    V v_t_2432 = (g_list_2emap_24s1173914895x100384474(v_t_2431));
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_prims_2415));
    V v_t_2434 = (g_list_2emap_24s1173914895x100384474(v_t_2433));
    V v_t_2435 = (g_list_2efoldl_24f96178826x1085061806(NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), v_t_2434));
    V v_t_2436 = (g_list_2efoldl_24s1668908788x1049324851(NTAG(TAG_Nil), v_t_2435));
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_2410));
    V v_t_2438 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2437; V r_ = (g_list_2efoldl_24s1028839125x1033007016(a_0, a_1)); heff_drop(v_t_2437); r_; });
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_lams_2416));
    V v_t_2440 = (g_list_2emap_24s1173914895x100384474(v_t_2439));
    V v_t_2441 = heff_tr(heff_call(v_end_245, 1, (V[]){v_ce_244}));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2432, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2446));
    V v_ys_2448 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2447));
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str9), v_ys_2448})});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str11), v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str13), v_t_2450})});
    V v_ys_2452 = (g_prelude_2e_2b_2b(v_t_2422, v_t_2451));
    V v_t_2453 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_2452));
    V v_t_2454 = (g_prelude_2e_2b_2b(v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, v_t_2453})));
    V v_t_2455 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2454));
    V v_x2_2456 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str14), v_prefix_246}), v_t_2455));
    switch (heff_tag_of(v_x2_2456)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str15);
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x2_2456, 0);
      V v_xs_2458 = heff_field(v_x2_2456, 1);
      heff_take_n(v_x2_2456, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str16); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
    }
    default: return heff_nomatch(v_x2_2456);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_protos_247 = heff_dup(heff_rfield(v_e_246, 0));
    V v_code_248 = heff_dup(heff_rfield(v_e_246, 1));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str0)));
    V v_o_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str1), v_t_249);
    HeffT2 v_t_2411 = ({ V a_0 = v_strs_241; V a_1 = v_o_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_o_2410); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      V v_t_2415;
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        v_t_2415 = v_x_2414;
      } else {
        heff_drop(v_field_2413);
        v_t_2415 = NTAG(TAG_Nil);
      }
      V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str2)));
      V v_o_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str3), v_t_2416);
      HeffT2 v_t_2418 = ({ V a_0 = v_protos_242; V a_1 = v_o_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_o_2417); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        V v_t_2422;
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_x_2421 = v_field_2420;
          v_t_2422 = v_x_2421;
        } else {
          heff_drop(v_field_2420);
          v_t_2422 = NTAG(TAG_Nil);
        }
        V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
        V v_t_2424 = ({ V b_0 = MK_INT(7LL); V a_1 = v_protos_247; V r_ = (g_list_2emap_24f1632378148x1903828118(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2425 = (g_list_2emap_24s380834591x871125279(v_code_248));
        V v_t_2426 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str4)));
        V v_o_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str5), v_t_2426);
        HeffT2 v_t_2428 = ({ V a_0 = v_lams_243; V a_1 = v_o_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_o_2427); r_; });
        {
          V v_field_2430 = v_t_2428.f[1];
          int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
          V v_t_2432;
          if ((v_tag_2429 == ((int64_t)0ULL))) {
            V v_x_2431 = v_field_2430;
            v_t_2432 = v_x_2431;
          } else {
            heff_drop(v_field_2430);
            v_t_2432 = NTAG(TAG_Nil);
          }
          V v_t_2433 = (g_list_2emap_24s380834591x871125279(v_t_2432));
          V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2433));
          V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2434));
          V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2435));
          return (g_prelude_2e_2b_2b(v_t_2415, v_t_2436));
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eownLines(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryPart_str0, 10, "run$main.c");

static V g_heff_2ecompile_2eemitc_2eentryPart_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eentryPart_st;
static V g_heff_2ecompile_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eentryPart_str0);
}
V g_heff_2ecompile_2eemitc_2eentryPart_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eentryPart_st)) return g_heff_2ecompile_2eemitc_2eentryPart_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eentryPart_val, &g_heff_2ecompile_2eemitc_2eentryPart_st, g_heff_2ecompile_2eemitc_2eentryPart_init);
}