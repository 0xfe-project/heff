// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_MkDrop 35958
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_exp 310423
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
static uint32_t shape_exp__stmts__ctype[] = {LBL_exp, LBL_stmts, LBL_ctype};
V g_heff_2ecompile_2eemitc_2eagain(V, V, V);
V g_heff_2ecompile_2eemitc_2eagain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagain_clo;
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2ecallHead(V, V, V);
V g_heff_2ecompile_2eemitc_2ecallHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallHead_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edefOwn(V, V);
V g_heff_2ecompile_2eemitc_2edefOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefOwn_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2einfixC(V, V);
V g_heff_2ecompile_2eemitc_2einfixC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einfixC_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamLines_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1018181017x1541469354(V);
V g_list_2efilter_24s1018181017x1541469354_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s125569247x179592613(V, V);
V g_list_2efoldl_24s125569247x179592613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s125569247x179592613_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f309885682x1545997284(V, V);
V g_list_2emap_24f309885682x1545997284_entry(V self, V *a);
extern Clo g_list_2emap_24f309885682x1545997284_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s424921060x1532378(V, V, V, V, V, V, V);
V g_list_2emap_24s424921060x1532378_entry(V self, V *a);
extern Clo g_list_2emap_24s424921060x1532378_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s203264781x503274820(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s203264781x503274820_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s203264781x503274820_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1280198663x1762821176(V, V, V);
V g_prelude_2e_2b_2b_24f1280198663x1762821176_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1280198663x1762821176_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str0, 3, "InR");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str1, 6, "MkPair");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str2, 3, "InL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str3, 4, "Just");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str4, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str5, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str6, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str8, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str9, 4, "True");

static V g_heff_2ecompile_2eemitc_2eknownTags_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eknownTags_st;
static V g_heff_2ecompile_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eknownTags_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eknownTags_st)) return g_heff_2ecompile_2eemitc_2eknownTags_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eknownTags_val, &g_heff_2ecompile_2eemitc_2eknownTags_st, g_heff_2ecompile_2eemitc_2eknownTags_init);
}
Clo g_heff_2ecompile_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_o_240);
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c(heff_dup(v_o_240), heff_dup(v_o2_245))) {
        if (heff_strEq_c(heff_dup(v_k_241), heff_dup(v_k2_246))) {
          heff_drop(v_o_240);
          heff_drop(v_k_241);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_o_240);
        heff_drop(v_k_241);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eownHas(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str3, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str5, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str6, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str7, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str8, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str9, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str10, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str20, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str21, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str22, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str24, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str25, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str27, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str28, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str29, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str30, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str31, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str32, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str42, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str43, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str44, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str46, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str47, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str49, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str50, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str51, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str52, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str53, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str54, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str55, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str56, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str57, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str58, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str59, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str60, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str61, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str62, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str63, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str64, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str65, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str66, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str67, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str68, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str69, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str70, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str71, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str72, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str73, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str74, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str75, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str76, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str77, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str78, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str79, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str80, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str81, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str82, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str83, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str84, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str85, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str86, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str87, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str88, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str89, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str90, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str91, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str92, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str93, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str94, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str95, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str96, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str97, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str98, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str99, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str100, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str101, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str102, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str103, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str104, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str105, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str106, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str107, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str108, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str109, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str110, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str111, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str112, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str113, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str114, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str115, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str116, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str117, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str118, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str119, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str120, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str121, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str122, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str123, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str124, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str125, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str126, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str127, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str128, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str129, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str130, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str131, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str132, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str133, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str134, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str135, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str136, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str137, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str138, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str139, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str140, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str141, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str142, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str143, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str144, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str145, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str146, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str147, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str148, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str149, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str150, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str151, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str152, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str153, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str154, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str155, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str156, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str157, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str158, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str159, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str160, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str161, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str162, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str163, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str164, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str165, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str166, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str167, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str168, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str169, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str170, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str171, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str172, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str173, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str174, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str175, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str176, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str177, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str178, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str179, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str180, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str181, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str182, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str183, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str184, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str185, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str186, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str187, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str188, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str189, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str190, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str191, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str192, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str193, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str194, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str195, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str196, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str197, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str198, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str199, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str200, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str201, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str202, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str203, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str204, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str205, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str206, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str207, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str208, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str209, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str210, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str211, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str212, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str213, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str214, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str215, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str216, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str217, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str218, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str219, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str220, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str221, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str222, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str223, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str224, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str225, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str226, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str227, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str228, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str229, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str230, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str231, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str232, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str233, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str234, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str235, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str236, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str237, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str238, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str239, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str240, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str241, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str242, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str243, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str244, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str245, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str246, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str247, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str248, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str249, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str250, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str251, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str252, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str253, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str254, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str255, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str256, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str257, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str258, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str259, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str260, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str261, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str262, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str263, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str264, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str265, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str266, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str267, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str268, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str269, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str270, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str271, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str272, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str273, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str274, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str275, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str276, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str277, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str278, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str279, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str280, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str281, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str282, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str283, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str284, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str285, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str286, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str287, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str288, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str289, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str290, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str291, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str292, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str293, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str294, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str295, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str296, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str297, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str298, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str299, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str300, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str301, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str302, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str303, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str304, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str305, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str306, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str307, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str308, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str309, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str310, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str311, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str312, 17, "heff_from_int_f32");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str313, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str314, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str315, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str316, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str317, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str318, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str319, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str320, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str321, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str322, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str323, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str324, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str325, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str326, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str327, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str328, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str329, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str330, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str331, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str332, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str333, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str334, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str335, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str336, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str337, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str338, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str339, 5, "sqrtf");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str340, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str341, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str342, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str343, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str344, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str345, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str346, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str347, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str348, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str349, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str350, 14, "heff_floor_f32");
Clo g_heff_2ecompile_2eemitc_2efloat32U_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efloat32U_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efloat32U(V v_op_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpAdd: {
    V v_t_242;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str0);
      break;
    }
    case TAG_OpSub: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str1);
      break;
    }
    case TAG_OpMul: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str2);
      break;
    }
    case TAG_OpDiv: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str3);
      break;
    }
    case TAG_OpRem: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str4);
      break;
    }
    case TAG_OpEq: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str5);
      break;
    }
    case TAG_OpLt: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str6);
      break;
    }
    case TAG_OpLe: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str7);
      break;
    }
    case TAG_OpAnd: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str8);
      break;
    }
    case TAG_OpOr: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str9);
      break;
    }
    case TAG_OpXor: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str10);
      break;
    }
    case TAG_OpShl: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str11);
      break;
    }
    case TAG_OpShr: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str12);
      break;
    }
    case TAG_OpShow: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str13);
      break;
    }
    case TAG_OpFromInt: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str14);
      break;
    }
    case TAG_OpToInt: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str15);
      break;
    }
    case TAG_OpSqrt: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str16);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str17);
      break;
    }
    case TAG_OpToFloat: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str18);
      break;
    }
    case TAG_OpFloor: {
      v_t_242 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str19);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_243 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_242, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str20), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str21)));
  }
  case TAG_OpSub: {
    V v_t_244;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str22);
      break;
    }
    case TAG_OpSub: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str23);
      break;
    }
    case TAG_OpMul: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str24);
      break;
    }
    case TAG_OpDiv: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str25);
      break;
    }
    case TAG_OpRem: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str26);
      break;
    }
    case TAG_OpEq: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str27);
      break;
    }
    case TAG_OpLt: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str28);
      break;
    }
    case TAG_OpLe: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str29);
      break;
    }
    case TAG_OpAnd: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str30);
      break;
    }
    case TAG_OpOr: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str31);
      break;
    }
    case TAG_OpXor: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str32);
      break;
    }
    case TAG_OpShl: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str33);
      break;
    }
    case TAG_OpShr: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str34);
      break;
    }
    case TAG_OpShow: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str35);
      break;
    }
    case TAG_OpFromInt: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str36);
      break;
    }
    case TAG_OpToInt: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str37);
      break;
    }
    case TAG_OpSqrt: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str38);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str39);
      break;
    }
    case TAG_OpToFloat: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str40);
      break;
    }
    case TAG_OpFloor: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str41);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_245 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_244, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str42), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str43)));
  }
  case TAG_OpMul: {
    V v_t_246;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str44);
      break;
    }
    case TAG_OpSub: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str45);
      break;
    }
    case TAG_OpMul: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str46);
      break;
    }
    case TAG_OpDiv: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str47);
      break;
    }
    case TAG_OpRem: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str48);
      break;
    }
    case TAG_OpEq: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str49);
      break;
    }
    case TAG_OpLt: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str50);
      break;
    }
    case TAG_OpLe: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str51);
      break;
    }
    case TAG_OpAnd: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str52);
      break;
    }
    case TAG_OpOr: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str53);
      break;
    }
    case TAG_OpXor: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str54);
      break;
    }
    case TAG_OpShl: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str55);
      break;
    }
    case TAG_OpShr: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str56);
      break;
    }
    case TAG_OpShow: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str57);
      break;
    }
    case TAG_OpFromInt: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str58);
      break;
    }
    case TAG_OpToInt: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str59);
      break;
    }
    case TAG_OpSqrt: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str60);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str61);
      break;
    }
    case TAG_OpToFloat: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str62);
      break;
    }
    case TAG_OpFloor: {
      v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str63);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_247 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_246, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str64), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str65)));
  }
  case TAG_OpDiv: {
    V v_t_248;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str66);
      break;
    }
    case TAG_OpSub: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str67);
      break;
    }
    case TAG_OpMul: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str68);
      break;
    }
    case TAG_OpDiv: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str69);
      break;
    }
    case TAG_OpRem: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str70);
      break;
    }
    case TAG_OpEq: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str71);
      break;
    }
    case TAG_OpLt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str72);
      break;
    }
    case TAG_OpLe: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str73);
      break;
    }
    case TAG_OpAnd: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str74);
      break;
    }
    case TAG_OpOr: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str75);
      break;
    }
    case TAG_OpXor: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str76);
      break;
    }
    case TAG_OpShl: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str77);
      break;
    }
    case TAG_OpShr: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str78);
      break;
    }
    case TAG_OpShow: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str79);
      break;
    }
    case TAG_OpFromInt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str80);
      break;
    }
    case TAG_OpToInt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str81);
      break;
    }
    case TAG_OpSqrt: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str82);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str83);
      break;
    }
    case TAG_OpToFloat: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str84);
      break;
    }
    case TAG_OpFloor: {
      v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str85);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_249 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_248, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str86), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str87)));
  }
  case TAG_OpRem: {
    V v_t_2410;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str88);
      break;
    }
    case TAG_OpSub: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str89);
      break;
    }
    case TAG_OpMul: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str90);
      break;
    }
    case TAG_OpDiv: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str91);
      break;
    }
    case TAG_OpRem: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str92);
      break;
    }
    case TAG_OpEq: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str93);
      break;
    }
    case TAG_OpLt: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str94);
      break;
    }
    case TAG_OpLe: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str95);
      break;
    }
    case TAG_OpAnd: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str96);
      break;
    }
    case TAG_OpOr: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str97);
      break;
    }
    case TAG_OpXor: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str98);
      break;
    }
    case TAG_OpShl: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str99);
      break;
    }
    case TAG_OpShr: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str100);
      break;
    }
    case TAG_OpShow: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str101);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str102);
      break;
    }
    case TAG_OpToInt: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str103);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str104);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str105);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str106);
      break;
    }
    case TAG_OpFloor: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str107);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2411 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2410, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str108), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str109)));
  }
  case TAG_OpEq: {
    V v_t_2412;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str110);
      break;
    }
    case TAG_OpSub: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str111);
      break;
    }
    case TAG_OpMul: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str112);
      break;
    }
    case TAG_OpDiv: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str113);
      break;
    }
    case TAG_OpRem: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str114);
      break;
    }
    case TAG_OpEq: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str115);
      break;
    }
    case TAG_OpLt: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str116);
      break;
    }
    case TAG_OpLe: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str117);
      break;
    }
    case TAG_OpAnd: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str118);
      break;
    }
    case TAG_OpOr: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str119);
      break;
    }
    case TAG_OpXor: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str120);
      break;
    }
    case TAG_OpShl: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str121);
      break;
    }
    case TAG_OpShr: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str122);
      break;
    }
    case TAG_OpShow: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str123);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str124);
      break;
    }
    case TAG_OpToInt: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str125);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str126);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str127);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str128);
      break;
    }
    case TAG_OpFloor: {
      v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str129);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2412, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str130), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str131)));
  }
  case TAG_OpLt: {
    V v_t_2414;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str132);
      break;
    }
    case TAG_OpSub: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str133);
      break;
    }
    case TAG_OpMul: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str134);
      break;
    }
    case TAG_OpDiv: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str135);
      break;
    }
    case TAG_OpRem: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str136);
      break;
    }
    case TAG_OpEq: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str137);
      break;
    }
    case TAG_OpLt: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str138);
      break;
    }
    case TAG_OpLe: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str139);
      break;
    }
    case TAG_OpAnd: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str140);
      break;
    }
    case TAG_OpOr: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str141);
      break;
    }
    case TAG_OpXor: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str142);
      break;
    }
    case TAG_OpShl: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str143);
      break;
    }
    case TAG_OpShr: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str144);
      break;
    }
    case TAG_OpShow: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str145);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str146);
      break;
    }
    case TAG_OpToInt: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str147);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str148);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str149);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str150);
      break;
    }
    case TAG_OpFloor: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str151);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2414, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str152), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str153)));
  }
  case TAG_OpLe: {
    V v_t_2416;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str154);
      break;
    }
    case TAG_OpSub: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str155);
      break;
    }
    case TAG_OpMul: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str156);
      break;
    }
    case TAG_OpDiv: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str157);
      break;
    }
    case TAG_OpRem: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str158);
      break;
    }
    case TAG_OpEq: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str159);
      break;
    }
    case TAG_OpLt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str160);
      break;
    }
    case TAG_OpLe: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str161);
      break;
    }
    case TAG_OpAnd: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str162);
      break;
    }
    case TAG_OpOr: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str163);
      break;
    }
    case TAG_OpXor: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str164);
      break;
    }
    case TAG_OpShl: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str165);
      break;
    }
    case TAG_OpShr: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str166);
      break;
    }
    case TAG_OpShow: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str167);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str168);
      break;
    }
    case TAG_OpToInt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str169);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str170);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str171);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str172);
      break;
    }
    case TAG_OpFloor: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str173);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2416, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str174), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str175)));
  }
  case TAG_OpAnd: {
    V v_t_2418;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str176);
      break;
    }
    case TAG_OpSub: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str177);
      break;
    }
    case TAG_OpMul: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str178);
      break;
    }
    case TAG_OpDiv: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str179);
      break;
    }
    case TAG_OpRem: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str180);
      break;
    }
    case TAG_OpEq: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str181);
      break;
    }
    case TAG_OpLt: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str182);
      break;
    }
    case TAG_OpLe: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str183);
      break;
    }
    case TAG_OpAnd: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str184);
      break;
    }
    case TAG_OpOr: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str185);
      break;
    }
    case TAG_OpXor: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str186);
      break;
    }
    case TAG_OpShl: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str187);
      break;
    }
    case TAG_OpShr: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str188);
      break;
    }
    case TAG_OpShow: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str189);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str190);
      break;
    }
    case TAG_OpToInt: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str191);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str192);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str193);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str194);
      break;
    }
    case TAG_OpFloor: {
      v_t_2418 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str195);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2419 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2418, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str196), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str197)));
  }
  case TAG_OpOr: {
    V v_t_2420;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str198);
      break;
    }
    case TAG_OpSub: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str199);
      break;
    }
    case TAG_OpMul: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str200);
      break;
    }
    case TAG_OpDiv: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str201);
      break;
    }
    case TAG_OpRem: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str202);
      break;
    }
    case TAG_OpEq: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str203);
      break;
    }
    case TAG_OpLt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str204);
      break;
    }
    case TAG_OpLe: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str205);
      break;
    }
    case TAG_OpAnd: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str206);
      break;
    }
    case TAG_OpOr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str207);
      break;
    }
    case TAG_OpXor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str208);
      break;
    }
    case TAG_OpShl: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str209);
      break;
    }
    case TAG_OpShr: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str210);
      break;
    }
    case TAG_OpShow: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str211);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str212);
      break;
    }
    case TAG_OpToInt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str213);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str214);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str215);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str216);
      break;
    }
    case TAG_OpFloor: {
      v_t_2420 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str217);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2421 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2420, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str218), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str219)));
  }
  case TAG_OpXor: {
    V v_t_2422;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str220);
      break;
    }
    case TAG_OpSub: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str221);
      break;
    }
    case TAG_OpMul: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str222);
      break;
    }
    case TAG_OpDiv: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str223);
      break;
    }
    case TAG_OpRem: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str224);
      break;
    }
    case TAG_OpEq: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str225);
      break;
    }
    case TAG_OpLt: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str226);
      break;
    }
    case TAG_OpLe: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str227);
      break;
    }
    case TAG_OpAnd: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str228);
      break;
    }
    case TAG_OpOr: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str229);
      break;
    }
    case TAG_OpXor: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str230);
      break;
    }
    case TAG_OpShl: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str231);
      break;
    }
    case TAG_OpShr: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str232);
      break;
    }
    case TAG_OpShow: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str233);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str234);
      break;
    }
    case TAG_OpToInt: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str235);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str236);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str237);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str238);
      break;
    }
    case TAG_OpFloor: {
      v_t_2422 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str239);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2422, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str240), heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str241)));
  }
  case TAG_OpShl: {
    V v_t_2424;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str242);
      break;
    }
    case TAG_OpSub: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str243);
      break;
    }
    case TAG_OpMul: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str244);
      break;
    }
    case TAG_OpDiv: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str245);
      break;
    }
    case TAG_OpRem: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str246);
      break;
    }
    case TAG_OpEq: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str247);
      break;
    }
    case TAG_OpLt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str248);
      break;
    }
    case TAG_OpLe: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str249);
      break;
    }
    case TAG_OpAnd: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str250);
      break;
    }
    case TAG_OpOr: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str251);
      break;
    }
    case TAG_OpXor: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str252);
      break;
    }
    case TAG_OpShl: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str253);
      break;
    }
    case TAG_OpShr: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str254);
      break;
    }
    case TAG_OpShow: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str255);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str256);
      break;
    }
    case TAG_OpToInt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str257);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str258);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str259);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str260);
      break;
    }
    case TAG_OpFloor: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str261);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2425 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2424, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str262), heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str263)));
  }
  case TAG_OpShr: {
    V v_t_2426;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str264);
      break;
    }
    case TAG_OpSub: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str265);
      break;
    }
    case TAG_OpMul: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str266);
      break;
    }
    case TAG_OpDiv: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str267);
      break;
    }
    case TAG_OpRem: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str268);
      break;
    }
    case TAG_OpEq: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str269);
      break;
    }
    case TAG_OpLt: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str270);
      break;
    }
    case TAG_OpLe: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str271);
      break;
    }
    case TAG_OpAnd: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str272);
      break;
    }
    case TAG_OpOr: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str273);
      break;
    }
    case TAG_OpXor: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str274);
      break;
    }
    case TAG_OpShl: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str275);
      break;
    }
    case TAG_OpShr: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str276);
      break;
    }
    case TAG_OpShow: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str277);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str278);
      break;
    }
    case TAG_OpToInt: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str279);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str280);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str281);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str282);
      break;
    }
    case TAG_OpFloor: {
      v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str283);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2427 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2426, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str284), heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str285)));
  }
  case TAG_OpShow: {
    V v_t_2428;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str286);
      break;
    }
    case TAG_OpSub: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str287);
      break;
    }
    case TAG_OpMul: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str288);
      break;
    }
    case TAG_OpDiv: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str289);
      break;
    }
    case TAG_OpRem: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str290);
      break;
    }
    case TAG_OpEq: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str291);
      break;
    }
    case TAG_OpLt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str292);
      break;
    }
    case TAG_OpLe: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str293);
      break;
    }
    case TAG_OpAnd: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str294);
      break;
    }
    case TAG_OpOr: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str295);
      break;
    }
    case TAG_OpXor: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str296);
      break;
    }
    case TAG_OpShl: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str297);
      break;
    }
    case TAG_OpShr: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str298);
      break;
    }
    case TAG_OpShow: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str299);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str300);
      break;
    }
    case TAG_OpToInt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str301);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str302);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str303);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str304);
      break;
    }
    case TAG_OpFloor: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str305);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2429 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2428, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str306), heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str307)));
  }
  case TAG_OpFromInt: {
    V v_t_2432;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str308);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_vs_241, 0);
      V v_xs_2431 = heff_field(v_vs_241, 1);
      heff_take_n(v_vs_241, 3ULL, 2);
      v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str309); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str310), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str311)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str312), v_t_2433);
  }
  case TAG_OpToInt: {
    V v_t_2434;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str313);
      break;
    }
    case TAG_OpSub: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str314);
      break;
    }
    case TAG_OpMul: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str315);
      break;
    }
    case TAG_OpDiv: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str316);
      break;
    }
    case TAG_OpRem: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str317);
      break;
    }
    case TAG_OpEq: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str318);
      break;
    }
    case TAG_OpLt: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str319);
      break;
    }
    case TAG_OpLe: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str320);
      break;
    }
    case TAG_OpAnd: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str321);
      break;
    }
    case TAG_OpOr: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str322);
      break;
    }
    case TAG_OpXor: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str323);
      break;
    }
    case TAG_OpShl: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str324);
      break;
    }
    case TAG_OpShr: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str325);
      break;
    }
    case TAG_OpShow: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str326);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str327);
      break;
    }
    case TAG_OpToInt: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str328);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str329);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str330);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str331);
      break;
    }
    case TAG_OpFloor: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str332);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2435 = (g_heff_2ecompile_2eemitc_2einfixC(v_t_2434, v_vs_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str333), heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str334)));
  }
  case TAG_OpSqrt: {
    V v_t_2438;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str335);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_vs_241, 0);
      V v_xs_2437 = heff_field(v_vs_241, 1);
      heff_take_n(v_vs_241, 3ULL, 2);
      v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str336); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str337), heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str338)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str339), v_t_2439);
  }
  case TAG_OpFromFloat: {
    V v_x2_2442;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_x2_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_vs_241, 0);
      heff_take_n(v_vs_241, 1ULL, 2);
      v_x2_2442 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2440});
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2444;
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_Nothing: {
      v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str340);
      break;
    }
    case TAG_Just: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      heff_take_n(v_x2_2442, 1ULL, 1);
      v_t_2444 = v_x_2443;
      break;
    }
    default: heff_nomatch(v_x2_2442);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str341), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str342)));
  }
  case TAG_OpToFloat: {
    V v_x2_2447;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_x2_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2445 = heff_field(v_vs_241, 0);
      heff_take_n(v_vs_241, 1ULL, 2);
      v_x2_2447 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2445});
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2449;
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nothing: {
      v_t_2449 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str343);
      break;
    }
    case TAG_Just: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      heff_take_n(v_x2_2447, 1ULL, 1);
      v_t_2449 = v_x_2448;
      break;
    }
    default: heff_nomatch(v_x2_2447);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str344), heff_strAppend(v_t_2449, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str345)));
  }
  case TAG_OpFloor: {
    V v_t_2452;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2452 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str346);
      break;
    }
    case TAG_Cons: {
      V v_x_2450 = heff_field(v_vs_241, 0);
      V v_xs_2451 = heff_field(v_vs_241, 1);
      heff_take_n(v_vs_241, 3ULL, 2);
      v_t_2452 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str347); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2453 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str348), heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str349)));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str350), v_t_2453);
  }
  default: return heff_nomatch(v_op_240);
  }
}
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2efloat32U(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str0, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str4, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str6, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallHead_str7, 1, "(");
Clo g_heff_2ecompile_2eemitc_2ecallHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallHead_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ecallHead(V v_g_240, V v_tr_241, V v_w_242) {
top: ;
  V v_t_243;
  if ((heff_dup(v_tr_241) == NTAG(TAG_True))) {
    v_t_243 = ((V)&g_heff_2ecompile_2eemitc_2ecallHead_str0);
  } else {
    v_t_243 = ((V)&g_heff_2ecompile_2eemitc_2ecallHead_str1);
  }
  V v_x2_245;
  switch (heff_tag_of(v_w_242)) {
  case TAG_Nothing: {
    v_x2_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    v_x2_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_w_242);
  }
  V v_t_248;
  if ((heff_dup(v_x2_245) == NTAG(TAG_True))) {
    heff_drop(v_x2_245);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallHead_str2)));
    v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallHead_str3), v_t_246), ((V)&g_heff_2ecompile_2eemitc_2ecallHead_str4));
  } else {
    heff_drop(v_x2_245);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallHead_str5)));
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallHead_str6), v_t_247);
  }
  return heff_strAppend(v_t_243, heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2ecallHead_str7)));
}
V g_heff_2ecompile_2eemitc_2ecallHead_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ecallHead(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str0, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str1, 19, "(V self, V *args) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str2, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str5, 8, " = args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str6, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str7, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str8, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str10, 18, " = heff_env(self)[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str11, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str12, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str13, 22, "  heff_clo_take(self, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str14, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_str15, 2, "  ");
Clo g_heff_2ecompile_2eemitc_2elamLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2elamLines(V v_k_240, V v_xs_241, V v_fv_242, V v_body_243) {
top: ;
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str0), heff_strAppend(v_k_240, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str1)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(1LL))));
  V v_t_248 = (g_list_2ezipWith_24s203264781x503274820(((V)&g_heff_2ecompile_2eemitc_2elamLines_str2), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str4), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str5), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str6), v_xs_241, v_t_247));
  V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fv_242));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
  V v_t_2411 = (g_list_2ezipWith_24s203264781x503274820(((V)&g_heff_2ecompile_2eemitc_2elamLines_str7), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str8), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str9), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str10), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str11), heff_dup(v_fv_242), v_t_2410));
  V v_t_2416;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2415 = heff_strAppend(heff_intShow(v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2elamLines_str12));
    v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_str13), v_t_2415), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elamLines_str14), NTAG(TAG_Nil)});
  V v_t_2418 = (g_prelude_2e_2b_2b_24f1280198663x1762821176(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2elamLines_str15), v_body_243));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2419));
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_248, v_t_2420));
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2421));
}
V g_heff_2ecompile_2eemitc_2elamLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str3, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str5, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str6, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str8, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str10, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str14, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str16, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str17, 15, "heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str18, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str19, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str21, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str23, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str24, 20, "switch (heff_tag_of(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str25, 4, ")) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str26, 29, "default: return heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str27, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str28, 22, "default: heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str29, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str30, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str31, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str32, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str33, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str34, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str37, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str38, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str39, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str40, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str41, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str42, 17, "return heff_tail(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str44, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str45, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str47, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str49, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str50, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str51, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str52, 17, "HEFF_LAST return ");
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2estmtF_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_lam4, 1, 0};
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estmtF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_248;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x12_244 = heff_field(v_d_242, 1);
      heff_take_n(v_d_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_243, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str0)));
        V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str1), v_t_245), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str2));
        v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str3), v_t_246);
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam0, 1, 1, (V[]){v_x_249});
  }
  case TAG_CLet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_e_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_k_240, 2), 1, (V[]){heff_dup(v_x_2411)}));
    V v_t_2414 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2411, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str4)));
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str5), v_t_2414), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str6));
    V v_pre_2416 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str7), v_t_2415));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2412}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam1, 1, 2, (V[]){v_m_2417, v_pre_2416});
  }
  case TAG_CDecl: {
    V v_x_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 3), 1, (V[]){heff_dup(v_x_2424)}));
    V v_t_2426 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2424, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str9)));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str10), v_t_2426), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str11));
    V v_t_2428 = heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str12), v_t_2427));
    V v_x_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam2, 1, 1, (V[]){v_x_2429});
  }
  case TAG_CSet: {
    V v_x_2431 = heff_field(v_x2_241, 0);
    V v_e_2432 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_2431, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str13)));
    V v_pre_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str14), v_t_2433), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str15));
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2432}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam3, 1, 2, (V[]){v_m_2435, v_pre_2434});
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2estmtF_lam4_clo);
  }
  case TAG_CIf: {
    V v_c_2444 = heff_field(v_x2_241, 0);
    V v_yes_2445 = heff_field(v_x2_241, 1);
    V v_no_2446 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2447 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_2444));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam5, 1, 4, (V[]){v_m_2447, v_k_240, v_yes_2445, v_no_2446});
  }
  case TAG_CSwitch: {
    V v_e_2466 = heff_field(v_x2_241, 0);
    V v_arms_2467 = heff_field(v_x2_241, 1);
    V v_returns_2468 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_2466}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam6, 1, 4, (V[]){v_m_2469, v_k_240, v_arms_2467, v_returns_2468});
  }
  case TAG_CReturn: {
    V v_e_2487 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2488 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_2487}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam7, 1, 1, (V[]){v_m_2488});
  }
  case TAG_CInPlace: {
    V v_f_2495 = heff_field(v_x2_241, 0);
    V v_es_2496 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CInPlace = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_2497 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24CInPlace, TAG_Cons, 2, (V[]){v_f_2495, v_es_2496})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam8, 1, 1, (V[]){v_m_2497});
  }
  case TAG_CRoomed: {
    V v_f_24103 = heff_field(v_x2_241, 0);
    V v_es_24104 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CRoomed = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24105 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24CRoomed, TAG_Cons, 2, (V[]){v_f_24103, v_es_24104})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam9, 1, 1, (V[]){v_m_24105});
  }
  case TAG_CTail: {
    V v_f_24111 = heff_field(v_x2_241, 0);
    V v_es_24112 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24CTail = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24113 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24CTail, TAG_Cons, 2, (V[]){v_f_24111, heff_dup(v_es_24112)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam10, 1, 2, (V[]){v_m_24113, v_es_24112});
  }
  case TAG_CLoop: {
    V v_ps_24135 = heff_field(v_x2_241, 0);
    V v_es_24136 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24137 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_dup(heff_rfield(v_k_240, 0)), v_es_24136));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam11, 1, 3, (V[]){v_m_24137, v_k_240, v_ps_24135});
  }
  case TAG_CJump: {
    V v_g_24144 = heff_field(v_x2_241, 0);
    V v_w_24145 = heff_field(v_x2_241, 1);
    V v_es_24146 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24147 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_24146));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam12, 1, 3, (V[]){v_m_24147, v_w_24145, v_g_24144});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estmtF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_pre_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_strAppend(v_pre_2416, heff_strAppend(v_x_2420, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str8)));
    V v_t_2423 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args) {
  V v_s_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_s_2430});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_pre_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440 = heff_strAppend(v_pre_2434, heff_strAppend(v_x_2438, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str16)));
    V v_t_2441 = heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args) {
  V v_s_2442 = args[0];
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str17), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2443, v_s_2442});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args) {
  V v_s_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_yes_2445 = heff_env(self)[2];
  V v_no_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_s_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_s_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    V v_m_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_yes_2445}));
    V v_x2_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2451}));
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_MkPair: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_s_2455 = heff_field(v_x2_2453, 1);
      V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
      V v_m_2456 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 3), 1, (V[]){v_no_2446}));
      V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2455}));
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_MkPair: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_s_2459 = heff_field(v_x2_2457, 1);
        V v_ru_24x2_2457_24MkPair = heff_take_reuse_n(v_x2_2457, 3ULL, 2);
        V v_t_2460 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str18), heff_strAppend(v_x_2450, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str19)));
        V v_t_2461 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2estmtF_str20), v_x_2454));
        V v_t_2462 = heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str21), NTAG(TAG_Nil)});
        V v_t_2463 = (g_prelude_2e_2b_2b_24f1280198663x1762821176(v_t_2462, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str22), v_x_2458));
        V v_t_2464 = (g_prelude_2e_2b_2b(v_t_2461, heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str23), v_t_2463})));
        V v_x_2465 = heff_tag_at_n(v_ru_24x2_2457_24MkPair, TAG_Cons, 2, (V[]){v_t_2460, v_t_2464});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2465, v_s_2459});
      }
      default: return heff_nomatch(v_x2_2457);
      }
    }
    default: return heff_nomatch(v_x2_2453);
    }
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_arms_2467 = heff_env(self)[2];
  V v_returns_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2earmF_clo), 2, (V[]){v_k_240, heff_dup(v_x_2472)}));
    V v_m_2475 = (g_heff_2ecompile_2eemitc_2etraverseC(v_t_2474, v_arms_2467));
    V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_s_2473}));
    switch (heff_tag_of(v_x2_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x2_2476, 0);
      V v_s_2478 = heff_field(v_x2_2476, 1);
      V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
      V v_t_2479 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str24), heff_strAppend(heff_dup(v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str25)));
      V v_t_2480 = heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
      V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2477));
      V v_t_2482 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2481; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2481); r_; });
      V v_t_2483;
      if ((heff_dup(v_returns_2468) == NTAG(TAG_True))) {
        heff_drop(v_returns_2468);
        v_t_2483 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str26), heff_strAppend(v_x_2472, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str27)));
      } else {
        heff_drop(v_returns_2468);
        v_t_2483 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str28), heff_strAppend(v_x_2472, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str29)));
      }
      V v_t_2484 = heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str30), NTAG(TAG_Nil)});
      V v_t_2485 = (g_prelude_2e_2b_2b(v_t_2482, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, v_t_2484})));
      V v_x_2486 = (g_prelude_2e_2b_2b(v_t_2480, v_t_2485));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2486, v_s_2478});
    }
    default: return heff_nomatch(v_x2_2476);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args) {
  V v_s_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_s_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    V v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str31), heff_strAppend(v_x_2491, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str32)));
    V v_t_2494 = heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_s_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args) {
  V v_s_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2499 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_s_2498}));
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_MkPair: {
    V v_x_24100 = heff_field(v_x2_2499, 0);
    V v_s_24101 = heff_field(v_x2_2499, 1);
    V v_ru_24x2_2499_24MkPair = heff_take_reuse_n(v_x2_2499, 3ULL, 2);
    V v_x_24102 = (g_heff_2ecompile_2eemitc_2einPlace(v_x_24100));
    return heff_tag_at_n(v_ru_24x2_2499_24MkPair, TAG_MkPair, 2, (V[]){v_x_24102, v_s_24101});
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args) {
  V v_s_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_s_24106}));
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_x_24108 = heff_field(v_x2_24107, 0);
    V v_s_24109 = heff_field(v_x2_24107, 1);
    V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
    V v_x_24110 = (g_heff_2ecompile_2eemitc_2eroomed(v_x_24108));
    return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){v_x_24110, v_s_24109});
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args) {
  V v_s_24114 = args[0];
  V v_m_24113 = heff_env(self)[0];
  V v_es_24112 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24115 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_s_24114}));
  switch (heff_tag_of(v_x2_24115)) {
  case TAG_MkPair: {
    V v_x_24116 = heff_field(v_x2_24115, 0);
    V v_s_24117 = heff_field(v_x2_24115, 1);
    V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
    V v_x2_24120;
    switch (heff_tag_of(v_x_24116)) {
    case TAG_Nil: {
      v_x2_24120 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_24118 = heff_dup(heff_field(v_x_24116, 0));
      v_x2_24120 = heff_tag_n(TAG_Just, 1, (V[]){v_x_24118});
      break;
    }
    default: heff_nomatch(v_x_24116);
    }
    V v_t_24122;
    switch (heff_tag_of(v_x2_24120)) {
    case TAG_Nothing: {
      v_t_24122 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str33);
      break;
    }
    case TAG_Just: {
      V v_x_24121 = heff_field(v_x2_24120, 0);
      heff_take_n(v_x2_24120, 1ULL, 1);
      v_t_24122 = v_x_24121;
      break;
    }
    default: heff_nomatch(v_x2_24120);
    }
    V v_t_24123 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24112; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_es_24112); r_; });
    V v_vs_24124 = (g_list_2edrop(MK_INT(1LL), v_x_24116));
    V v_t_24130;
    switch (heff_tag_of(v_vs_24124)) {
    case TAG_Nil: {
      v_t_24130 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str34);
      break;
    }
    case TAG_Cons: {
      V v_t_24129;
      switch (heff_tag_of(v_vs_24124)) {
      case TAG_Nil: {
        v_t_24129 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str35);
        break;
      }
      case TAG_Cons: {
        V v_x_24127 = heff_field(v_vs_24124, 0);
        V v_xs_24128 = heff_field(v_vs_24124, 1);
        heff_take_n(v_vs_24124, 3ULL, 2);
        v_t_24129 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str36); V a_1 = v_x_24127; V a_2 = v_xs_24128; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24128); r_; });
        break;
      }
      default: heff_nomatch(v_vs_24124);
      }
      v_t_24130 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str37), heff_strAppend(v_t_24129, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str38)));
      break;
    }
    default: heff_nomatch(v_vs_24124);
    }
    V v_t_24131 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str39), heff_strAppend(v_t_24130, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str40)));
    V v_t_24132 = heff_strAppend(heff_intShow(v_t_24123), v_t_24131);
    V v_t_24133 = heff_strAppend(v_t_24122, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str41), v_t_24132));
    V v_x_24134 = heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str42), v_t_24133), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24134, v_s_24117});
  }
  default: return heff_nomatch(v_x2_24115);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args) {
  V v_s_24138 = args[0];
  V v_m_24137 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_ps_24135 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24139 = heff_tr(heff_call(v_m_24137, 1, (V[]){v_s_24138}));
  switch (heff_tag_of(v_x2_24139)) {
  case TAG_MkPair: {
    V v_x_24140 = heff_field(v_x2_24139, 0);
    V v_s_24141 = heff_field(v_x2_24139, 1);
    V v_ru_24x2_24139_24MkPair = heff_take_reuse_n(v_x2_24139, 3ULL, 2);
    V v_t_24142 = (g_list_2emap(heff_get_n(v_k_240, 2, 3), heff_dup(v_ps_24135)));
    V v_x_24143 = (g_heff_2ecompile_2eemitc_2eagain(v_t_24142, v_ps_24135, v_x_24140));
    return heff_tag_at_n(v_ru_24x2_24139_24MkPair, TAG_MkPair, 2, (V[]){v_x_24143, v_s_24141});
  }
  default: return heff_nomatch(v_x2_24139);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args) {
  V v_s_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  V v_w_24145 = heff_env(self)[1];
  V v_g_24144 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_s_24148}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_s_24151 = heff_field(v_x2_24149, 1);
    V v_ru_24x2_24149_24MkPair = heff_take_reuse_n(v_x2_24149, 3ULL, 2);
    V v_t_24154;
    if ((heff_dup(v_w_24145) == NTAG(TAG_True))) {
      heff_drop(v_w_24145);
      V v_t_24152 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_24144, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str43)));
      v_t_24154 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str44), v_t_24152), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str45));
    } else {
      heff_drop(v_w_24145);
      V v_t_24153 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_24144, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str46)));
      v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str47), v_t_24153);
    }
    V v_t_24157;
    switch (heff_tag_of(v_x_24150)) {
    case TAG_Nil: {
      v_t_24157 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_24155 = heff_field(v_x_24150, 0);
      V v_xs_24156 = heff_field(v_x_24150, 1);
      heff_take_n(v_x_24150, 3ULL, 2);
      v_t_24157 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str49); V a_1 = v_x_24155; V a_2 = v_xs_24156; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24156); r_; });
      break;
    }
    default: heff_nomatch(v_x_24150);
    }
    V v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str50), heff_strAppend(v_t_24157, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str51)));
    V v_t_24159 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str52), heff_strAppend(v_t_24154, v_t_24158));
    V v_x_24160 = heff_tag_at_n(v_ru_24x2_24149_24MkPair, TAG_Cons, 2, (V[]){v_t_24159, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24160, v_s_24151});
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str1, 6, "double");
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eckOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eckOf(V v_rs_240) {
top: ;
  return heff_rec_n(3, shape_exp__stmts__ctype, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam0, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam1, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam3, 1, 1, (V[]){heff_dup(v_rs_240)})});
}
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eckOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = ({ V a_0 = v_rs_240; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0)); heff_drop(v_rs_240); r_; });
  return (g_heff_2ecompile_2eemitc_2eexpF(v_t_242, v_e_241));
}
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_249));
    V v_x_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2411); r_; });
    return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2412, v_s_2410});
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args) {
  V v_ss_243 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_k_244 = ({ V a_0 = v_rs_240; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0)); heff_drop(v_rs_240); r_; });
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2estmtF_clo), 1, (V[]){v_k_244}));
  V v_m_246 = (g_heff_2ecompile_2eemitc_2etraverseC(v_t_245, v_ss_243));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam2, 1, 1, (V[]){v_m_246});
}
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2414 = ({ V a_0 = v_x_2413; V a_1 = v_rs_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_rs_240); r_; });
  V v_x1_2416;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    v_x1_2416 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    v_x1_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_RepV: {
    return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str0);
  }
  case TAG_RepFix: {
    V v_w_2417 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    return ({ V a_0 = v_w_2417; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2417); r_; });
  }
  case TAG_RepF64: {
    return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str1);
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str0, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str1, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str5, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str6, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str9, 32, "static V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str11, 1, "\012");
Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2edefOwn_clo), 1, (V[]){heff_dup(v_ce_244)}));
  V v_t_246 = (g_heff_2ecompile_2eemitc_2etraverseC(v_t_245, v_defs_243));
  V v_t_247 = heff_tr(heff_call(v_t_246, 1, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_247)) {
  case TAG_MkPair: {
    V v_ems_248 = heff_field(v_t_247, 0);
    V v_s_249 = heff_field(v_t_247, 1);
    V v_ru_24t_247_24MkPair = heff_take_reuse_n(v_t_247, 3ULL, 2);
    V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str0), heff_dup(heff_rfield(v_ending_242, 0))});
    V v_t_2411 = (g_map_2etoListOnto(heff_rfield(v_ce_244, 0), NTAG(TAG_Nil)));
    V v_t_2412 = (g_list_2efilter_24s1018181017x1541469354(v_t_2411));
    V v_t_2413 = (g_list_2emap_24s424921060x1532378(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str1), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str2), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str3), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str4), v_t_2412));
    V v_t_2414 = (g_map_2etoListOnto(heff_rfield(v_ce_244, 1), NTAG(TAG_Nil)));
    V v_t_2415 = (g_list_2emap_24s424921060x1532378(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str5), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str6), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str7), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str8), v_t_2414));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, NTAG(TAG_Nil)});
    V v_t_2417 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str9), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 5)));
    V v_t_2420 = (g_list_2emap_24s1173914895x100384474(v_t_2419));
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 6)));
    V v_t_2422 = (g_list_2emap_24s1173914895x100384474(v_t_2421));
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_map_2eempty_get()), v_t_2422));
    V v_t_2424 = (g_list_2emap_24s2073083146x1445066245(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_248)));
    V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s292588827x1477362994(a_0, a_1)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 3)));
    V v_t_2428 = (g_list_2emap_24s1173914895x100384474(v_t_2427));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_249, 7)));
    V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_t_2429));
    V v_t_2431 = (g_list_2efoldl_24f96178826x1085061806(NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), v_t_2430));
    V v_t_2432 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2431; V r_ = (g_list_2efoldl_24s125569247x179592613(a_0, a_1)); heff_drop(v_t_2431); r_; });
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_248));
    V v_t_2434 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2433; V r_ = (g_list_2efoldl_24s1028839125x1033007016(a_0, a_1)); heff_drop(v_t_2433); r_; });
    V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_s_249, 2, 8)));
    V v_t_2436 = (g_list_2emap_24s1173914895x100384474(v_t_2435));
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_ending_242, 1, 2), 1, (V[]){v_ce_244}));
    V v_t_2438 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2437));
    V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2438));
    V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2432, v_t_2439));
    V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2440));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2446));
    V v_t_2448 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2447));
    V v_t_2449 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2448));
    V v_x2_2450 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2449));
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str10);
    }
    case TAG_Cons: {
      V v_x_2451 = heff_field(v_x2_2450, 0);
      V v_xs_2452 = heff_field(v_x2_2450, 1);
      heff_take_n(v_x2_2450, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str11); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
    }
    default: return heff_nomatch(v_x2_2450);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str0, 11, "static V g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str1, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str2, 11, "_init(void)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str3, 22, "static V heff_perform(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str4, 7, "static ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epubLine_str5, 3, " g_");
V g_heff_2ecompile_2eemitc_2epubLine_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2epubLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epubLine_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2epubLine(V v_l_240) {
top: ;
  V v_t_248;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(11LL)), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str0))) {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_l_240)), MK_INT(5LL));
    V v_t_243 = heff_strSlice(heff_dup(v_l_240), v_t_242, heff_strLength(heff_dup(v_l_240)));
    if (heff_strEq_c(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2epubLine_str1))) {
      v_t_248 = NTAG(TAG_False);
    } else {
      V v_x3_245 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemitc_2epubLine_str2), heff_dup(v_l_240), MK_INT(0LL)));
      V v_x1_247;
      switch (heff_tag_of(v_x3_245)) {
      case TAG_Nothing: {
        v_x1_247 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_245, 0ULL, 1);
        v_x1_247 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_245);
      }
      v_t_248 = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
      heff_drop(v_x1_247);
    }
  } else {
    v_t_248 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
  } else {
    heff_drop(v_t_248);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2ecompile_2eemitc_2epubLine_str3))) {
      return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
    } else {
      V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2epubLine_lam0, 1, 1, (V[]){heff_dup(v_l_240)}); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        return heff_strSlice(heff_dup(v_l_240), MK_INT(7LL), heff_strLength(v_l_240));
      } else {
        heff_drop(v_t_2413);
        return v_l_240;
      }
    }
  }
}
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epubLine(a[0]);
}
V g_heff_2ecompile_2eemitc_2epubLine_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  V v_l_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_prefix_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epubLine_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2epubLine_str5)));
  V v_t_2412 = heff_strSlice(v_l_240, MK_INT(0LL), heff_strLength(heff_dup(v_prefix_2411)));
  return heff_strEq(v_t_2412, v_prefix_2411);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str0)));
    V v_o_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str1), v_t_247);
    V v_x2_249 = (g_map_2elookup_24s1546226666x2146984184(v_o_248, v_strs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take_n(v_x2_249, 1ULL, 1);
      v_t_2411 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str2)));
    V v_o_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str3), v_t_2412);
    V v_x2_2414 = (g_map_2elookup_24s1546226666x2146984184(v_o_2413, v_protos_242));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nothing: {
      v_t_2416 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      heff_take_n(v_x2_2414, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2417 = (g_list_2emap_24s380834591x871125279(v_t_2416));
    V v_t_2418 = (g_list_2emap_24f309885682x1545997284(MK_INT(7LL), heff_dup(heff_rfield(v_e_246, 0))));
    V v_t_2419 = (g_list_2emap_24s380834591x871125279(heff_dup(heff_rfield(v_e_246, 1))));
    V v_t_2420 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str4)));
    V v_o_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str5), v_t_2420);
    V v_x2_2422 = (g_map_2elookup_24s1546226666x2146984184(v_o_2421, v_lams_243));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nothing: {
      v_t_2424 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      heff_take_n(v_x2_2422, 1ULL, 1);
      v_t_2424 = v_x_2423;
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2425 = (g_list_2emap_24s380834591x871125279(v_t_2424));
    V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2425));
    V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2426));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2427));
    return (g_prelude_2e_2b_2b(v_t_2411, v_t_2428));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eownLines(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryPart_str0, 10, "run$main.c");

static V g_heff_2ecompile_2eemitc_2eentryPart_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eentryPart_st;
static V g_heff_2ecompile_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eentryPart_str0);
}
V g_heff_2ecompile_2eemitc_2eentryPart_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eentryPart_st)) return g_heff_2ecompile_2eemitc_2eentryPart_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eentryPart_val, &g_heff_2ecompile_2eemitc_2eentryPart_st, g_heff_2ecompile_2eemitc_2eentryPart_init);
}