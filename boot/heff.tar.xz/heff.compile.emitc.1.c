// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatPow 21165
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_HS 9084
#define TAG_MkCArm 24694
#define TAG_MkDrop 35958
#define TAG_OfFixed 17267
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandon 7524
#define TAG_RCall 39004
#define TAG_RPrim 49376
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_StrRuneDecode 45427
#define TAG_UFixed 18334
#define TAG_UFn 31401
#define TAG_UOp 31682
#define TAG_URel 1603
#define TAG_UToDouble 51807
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_body 9524841
#define LBL_byFun 295539138
#define LBL_code 9554612
#define LBL_ctype 296362551
#define LBL_end 310101
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_inLam 301681229
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_ret 322331
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
static uint32_t shape_exp__stmts__ctype__tuples__ret__inLam[] = {LBL_exp, LBL_stmts, LBL_ctype, LBL_tuples, LBL_ret, LBL_inLam};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
V g_heff_2ecompile_2eemitc_2eaddLam(V, V, V);
V g_heff_2ecompile_2eemitc_2eaddLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eaddLam_clo;
V g_heff_2ecompile_2eemitc_2eagainTo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagainTo_clo;
V g_heff_2ecompile_2eemitc_2earmF(V, V, V);
V g_heff_2ecompile_2eemitc_2earmF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2earmF_clo;
V g_heff_2ecompile_2eemitc_2ecallBound(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallBound_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edeclOf(V, V);
V g_heff_2ecompile_2eemitc_2edeclOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edeclOf_clo;
HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemI(V, V);
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemI_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryPart_get(void);
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efloat32U(V, V);
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat32U_clo;
HeffT2 g_heff_2ecompile_2eemitc_2efunDef_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2elamLines_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo;
V g_heff_2ecompile_2eemitc_2emangleChar(V);
V g_heff_2ecompile_2eemitc_2emangleChar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleChar_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo;
V g_heff_2ecompile_2eemitc_2enumbersOf(V, V);
V g_heff_2ecompile_2eemitc_2enumbersOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbersOf_clo;
V g_heff_2ecompile_2eemitc_2eonceInOrder(V, V);
V g_heff_2ecompile_2eemitc_2eonceInOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eonceInOrder_clo;
V g_heff_2ecompile_2eemitc_2eownHas(V, V, V);
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownHas_clo;
V g_heff_2ecompile_2eemitc_2eownLines(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eownLines_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2eshapeH(V, V, V);
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeH_clo;
V g_heff_2ecompile_2eemitc_2eslotFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo;
V g_heff_2ecompile_2eemitc_2estmtF(V, V);
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estmtF_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2etupleArm(V, V, V);
V g_heff_2ecompile_2eemitc_2etupleArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etupleArm_clo;
HeffT2 g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eunboxed(V);
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxed_clo;
V g_heff_2ecompile_2eemitc_2eusedBy(V, V);
V g_heff_2ecompile_2eemitc_2eusedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eusedBy_clo;
HeffT2 g_heff_2ecompile_2eemitc_2evalDef_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_intShow_get(void);
V g_list_2eany_24s1041788812x158895160(V);
V g_list_2eany_24s1041788812x158895160_entry(V self, V *a);
extern Clo g_list_2eany_24s1041788812x158895160_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1257949983x1023832813(V, V);
V g_list_2efoldl_24f1257949983x1023832813_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1257949983x1023832813_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24f891411706x655200538(V, V);
V g_list_2efoldl_24f891411706x655200538_entry(V self, V *a);
extern Clo g_list_2efoldl_24f891411706x655200538_clo;
V g_list_2efoldl_24f96178826x1085061806(V, V, V);
V g_list_2efoldl_24f96178826x1085061806_entry(V self, V *a);
extern Clo g_list_2efoldl_24f96178826x1085061806_clo;
V g_list_2efoldl_24s1028839125x1033007016(V, V);
V g_list_2efoldl_24s1028839125x1033007016_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1028839125x1033007016_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1483820613x1826490246(V, V);
V g_list_2efoldl_24s1483820613x1826490246_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1483820613x1826490246_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s2138447488x1597606028(V, V);
V g_list_2efoldl_24s2138447488x1597606028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2138447488x1597606028_clo;
V g_list_2efoldl_24s292588827x1477362994(V, V);
V g_list_2efoldl_24s292588827x1477362994_entry(V self, V *a);
extern Clo g_list_2efoldl_24s292588827x1477362994_clo;
V g_list_2efoldl_24s41085868x1118058949(V, V);
V g_list_2efoldl_24s41085868x1118058949_entry(V self, V *a);
extern Clo g_list_2efoldl_24s41085868x1118058949_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1814523351x214817707(V);
V g_list_2ekeepIf_24s1814523351x214817707_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1814523351x214817707_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1632378148x1903828118(V, V);
V g_list_2emap_24f1632378148x1903828118_entry(V self, V *a);
extern Clo g_list_2emap_24f1632378148x1903828118_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s2073083146x1445066245(V);
V g_list_2emap_24s2073083146x1445066245_entry(V self, V *a);
extern Clo g_list_2emap_24s2073083146x1445066245_clo;
V g_list_2emap_24s2133060086x110881273(V, V, V, V, V, V, V);
V g_list_2emap_24s2133060086x110881273_entry(V self, V *a);
extern Clo g_list_2emap_24s2133060086x110881273_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s380834591x871125279(V);
V g_list_2emap_24s380834591x871125279_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_clo;
V g_list_2emap_24s640776339x1223679834(V);
V g_list_2emap_24s640776339x1223679834_entry(V self, V *a);
extern Clo g_list_2emap_24s640776339x1223679834_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s490727218x2138671(V, V, V, V, V);
V g_list_2ezipWith_24s490727218x2138671_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s490727218x2138671_clo;
V g_list_2ezipWith_24s952564628x174753269(V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f132290754x1091834184(V, V, V, V);
V g_prelude_2e_2b_2b_24f132290754x1091834184_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f132290754x1091834184_clo;
V g_prelude_2e_2b_2b_24f543054808x1503188303(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f543054808x1503188303_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f543054808x1503188303_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_prelude_2etraverse_24s1370495575x1780346529(V, V);
V g_prelude_2etraverse_24s1370495575x1780346529_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1370495575x1780346529_clo;
V g_prelude_2etraverse_24s428640578x580976168(V, V);
V g_prelude_2etraverse_24s428640578x580976168_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s428640578x580976168_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eemitc_2emangleW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emangleW_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2emangleW(V v_s_240, V v_i_241, V v_box_24j_242, V v_acc_243) {
  int64_t v_j_242 = heff_unbox_word(v_box_24j_242);
top: ;
  if ((v_j_242 < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    V v_c_244 = heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2);
    if ((((((int64_t)97ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)90ULL))) || ((((int64_t)48ULL) <= heff_peek_word(v_c_244)) && (heff_peek_word(v_c_244) <= ((int64_t)57ULL)))))) {
      heff_drop(v_c_244);
      V t_0 = v_s_240;
      V t_1 = v_i_241;
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_c_244);
      if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_j_242)) {
        return heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
      } else {
        V v_t_245 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
        V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
        V t_0 = v_s_240;
        V t_1 = heff_box_word((v_j_242 + ((int64_t)1ULL)));
        int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
        V t_3 = heff_strAppend(v_t_245, v_t_246);
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      }
    }
  } else {
    if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_j_242)) {
      return heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
    } else {
      V v_t_247 = heff_strAppend(v_acc_243, heff_strSlice_lent(v_s_240, v_i_241, heff_box_word(v_j_242), 6));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2emangleChar(heff_strByteAt_lent(v_s_240, heff_box_word(v_j_242), 2)));
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_j_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_j_242 + ((int64_t)1ULL));
      V t_3 = heff_strAppend(v_t_247, v_t_248);
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2emangleW(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str0, 3, "InR");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str1, 6, "MkPair");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str2, 3, "InL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str3, 4, "Just");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str4, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str5, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str6, 6, "MkUnit");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str8, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eknownTags_str9, 4, "True");

static V g_heff_2ecompile_2eemitc_2eknownTags_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eknownTags_st;
static V g_heff_2ecompile_2eemitc_2eknownTags_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eknownTags_str9), v_t_244});
}
V g_heff_2ecompile_2eemitc_2eknownTags_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eknownTags_st)) return g_heff_2ecompile_2eemitc_2eknownTags_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eknownTags_val, &g_heff_2ecompile_2eemitc_2eknownTags_st, g_heff_2ecompile_2eemitc_2eknownTags_init);
}
Clo g_heff_2ecompile_2eemitc_2eslotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eslotFrom_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eslotFrom(V v_base_240, V v_m_241, V v_h_242, V v_taken_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(v_taken_243, heff_intAdd(heff_dup(v_base_240), heff_dup(v_h_242))));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      heff_drop(v_x_247);
      V v_t_248 = heff_intMod(heff_intAdd(v_h_242, MK_INT(1LL)), heff_dup(v_m_241));
      V t_0 = v_base_240;
      V t_1 = v_m_241;
      V t_2 = v_t_248;
      V t_3 = v_taken_243;
      v_base_240 = t_0;
      v_m_241 = t_1;
      v_h_242 = t_2;
      v_taken_243 = t_3;
      goto top;
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_246);
      return heff_intAdd(v_base_240, v_h_242);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eslotFrom_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eslotFrom(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eemitc_2eownHas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownHas_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eownHas(V v_o_240, V v_k_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_o2_245 = heff_field(v_x31_243, 0);
      V v_k2_246 = heff_field(v_x31_243, 1);
      if (heff_strEq_c_lent(v_o_240, v_o2_245, 0)) {
        if (heff_strEq_c_lent(v_k_241, v_k2_246, 0)) {
          return NTAG(TAG_True);
        } else {
          V t_0 = v_o_240;
          V t_1 = v_k_241;
          V t_2 = v_rest_244;
          v_o_240 = t_0;
          v_k_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eownHas_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eownHas(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str1, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str2, 18, "heff_from_int_f32(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str6, 6, "sqrtf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str9, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str11, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str12, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str16, 15, "heff_floor_f32(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str18, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str19, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str20, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str21, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str22, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str23, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str24, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str26, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str27, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str28, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str29, 1, "&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str30, 1, "|");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str31, 1, "^");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str36, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str41, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str42, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str43, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str44, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efloat32U_str45, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efloat32U_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efloat32U_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2efloat32U(V v_op_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_op_240)) {
  case TAG_OpFromInt: {
    V v_t_244;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_244 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_242 = heff_field(v_vs_241, 0);
      V v_xs_243 = heff_field(v_vs_241, 1);
      v_t_244 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str1), heff_dup(v_x_242), v_xs_243));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str2), v_t_244), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str3));
  }
  case TAG_OpSqrt: {
    V v_t_247;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_241, 0);
      V v_xs_246 = heff_field(v_vs_241, 1);
      v_t_247 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str5), heff_dup(v_x_245), v_xs_246));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str6), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str7));
  }
  case TAG_OpFromFloat: {
    V v_t_2410;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_vs_241, 0);
      v_t_2410 = heff_dup(v_x_248);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str9), v_t_2410), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str10));
  }
  case TAG_OpToFloat: {
    V v_t_2413;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_vs_241, 0);
      v_t_2413 = heff_dup(v_x_2411);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str12), v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str13));
  }
  case TAG_OpFloor: {
    V v_t_2416;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_vs_241, 0);
      V v_xs_2415 = heff_field(v_vs_241, 1);
      v_t_2416 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str15), heff_dup(v_x_2414), v_xs_2415));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str16), v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str17));
  }
  default: {
    V v_t_2419;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_vs_241, 0);
      v_t_2419 = heff_dup(v_x_2417);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str19), v_t_2419), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str20));
    V v_t_2421;
    switch (heff_tag_of(v_op_240)) {
    case TAG_OpAdd: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str21);
      break;
    }
    case TAG_OpSub: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str22);
      break;
    }
    case TAG_OpMul: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str23);
      break;
    }
    case TAG_OpDiv: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str24);
      break;
    }
    case TAG_OpRem: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str25);
      break;
    }
    case TAG_OpEq: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str26);
      break;
    }
    case TAG_OpLt: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str27);
      break;
    }
    case TAG_OpLe: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str28);
      break;
    }
    case TAG_OpAnd: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str29);
      break;
    }
    case TAG_OpOr: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str30);
      break;
    }
    case TAG_OpXor: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str31);
      break;
    }
    case TAG_OpShl: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str32);
      break;
    }
    case TAG_OpShr: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str33);
      break;
    }
    case TAG_OpShow: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str34);
      break;
    }
    case TAG_OpFromInt: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str35);
      break;
    }
    case TAG_OpToInt: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str36);
      break;
    }
    case TAG_OpSqrt: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str37);
      break;
    }
    case TAG_OpFromFloat: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str38);
      break;
    }
    case TAG_OpToFloat: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str39);
      break;
    }
    case TAG_OpFloor: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str40);
      break;
    }
    default: heff_nomatch(v_op_240);
    }
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2420, v_t_2421), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str41));
    HeffT3 v_t_2423 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2429;
    {
      V v_field_2425 = v_t_2423.f[1];
      V v_field_2426 = v_t_2423.f[2];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_x_2427 = v_field_2425;
        V v_x12_2428 = v_field_2426;
        heff_drop(v_x12_2428);
        v_t_2429 = v_x_2427;
      } else {
        heff_drop(v_field_2425);
        heff_drop(v_field_2426);
        v_t_2429 = ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str42);
      }
    }
    V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2422, v_t_2429), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str43));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efloat32U_str44), v_t_2430), ((V)&g_heff_2ecompile_2eemitc_2efloat32U_str45));
  }
  }
}
V g_heff_2ecompile_2eemitc_2efloat32U_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2efloat32U(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str0, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str1, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str2, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str3, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str4, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str5, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str6, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str7, 17, "heff_from_int_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str8, 4, "sqrt");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str9, 14, "heff_floor_f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str10, 3, "sin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str11, 3, "cos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str12, 3, "tan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str13, 4, "asin");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str14, 4, "acos");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str15, 4, "atan");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str16, 5, "atan2");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str17, 3, "exp");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str18, 3, "log");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str19, 3, "pow");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str20, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str21, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str22, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str23, 13, "heff_word_div");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str24, 13, "heff_word_mod");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str25, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str26, 1, "%");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str27, 2, "==");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str28, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxed_str29, 2, "<=");
Clo g_heff_2ecompile_2eemitc_2eunboxed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eunboxed_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eunboxed(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_FloatAdd: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str0)});
  }
  case TAG_FloatSub: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str1)});
  }
  case TAG_FloatMul: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str2)});
  }
  case TAG_FloatDiv: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str3)});
  }
  case TAG_FloatEq: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str4)});
  }
  case TAG_FloatLt: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str5)});
  }
  case TAG_FloatLe: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str6)});
  }
  case TAG_FloatFromInt: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str7)});
  }
  case TAG_FloatSqrt: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str8)});
  }
  case TAG_FloatFloor: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str9)});
  }
  case TAG_FloatSin: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str10)});
  }
  case TAG_FloatCos: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str11)});
  }
  case TAG_FloatTan: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str12)});
  }
  case TAG_FloatAsin: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str13)});
  }
  case TAG_FloatAcos: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str14)});
  }
  case TAG_FloatAtan: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str15)});
  }
  case TAG_FloatAtan2: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str16)});
  }
  case TAG_FloatExp: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str17)});
  }
  case TAG_FloatLog: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str18)});
  }
  case TAG_FloatPow: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str19)});
  }
  case TAG_OfFixed: {
    V v_w_241 = heff_field(v_p_240, 0);
    V v_op_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24OfFixed = heff_take_reuse_n(v_p_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_240_24OfFixed, TAG_UFixed, 2, (V[]){v_w_241, v_op_242});
  }
  case TAG_WordAdd: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str20)});
  }
  case TAG_WordSub: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str21)});
  }
  case TAG_WordMul: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str22)});
  }
  case TAG_WordDiv: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str23)});
  }
  case TAG_WordMod: {
    return heff_tag_n(TAG_UFn, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str24)});
  }
  case TAG_WordQuot: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str25)});
  }
  case TAG_WordRem: {
    return heff_tag_n(TAG_UOp, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str26)});
  }
  case TAG_WordEq: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str27)});
  }
  case TAG_WordLt: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str28)});
  }
  case TAG_WordLe: {
    return heff_tag_n(TAG_URel, 1, (V[]){((V)&g_heff_2ecompile_2eemitc_2eunboxed_str29)});
  }
  case TAG_WordToFloat: {
    return NTAG(TAG_UToDouble);
  }
  default: {
    V v_t_243 = ({ V a_0 = v_p_240; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_240); r_; });
    return heff_tag_n(TAG_UFn, 1, (V[]){v_t_243});
  }
  }
}
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eunboxed(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str2, 3, "({ ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str4, 6, " r_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str5, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str8, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str10, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str11, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str14, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str16, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str17, 4, ")); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ecallBound_str18, 7, " r_; })");
Clo g_heff_2ecompile_2eemitc_2ecallBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecallBound_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2ecallBound(V v_ty_240, V v_g_241, V v_tr_242, V v_w_243, V v_bs_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_bs_244)));
  V v_x2_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1483820613x1826490246(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str1); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str2), v_t_249), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str3));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, v_ty_240), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str4));
  V v_t_2412;
  if ((heff_dup(v_tr_242) == NTAG(TAG_True))) {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str5);
  } else {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str6);
  }
  V v_t_2416;
  switch (heff_tag_of(v_w_243)) {
  case TAG_Nothing: {
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str7)));
    v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str8), v_t_2413);
    break;
  }
  case TAG_Just: {
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str9)));
    v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ecallBound_str10), v_t_2415), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str11));
    break;
  }
  default: heff_nomatch(v_w_243);
  }
  V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2412, v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str12));
  V v_x2_2418 = (g_list_2emap_24s640776339x1223679834(heff_dup(v_bs_244)));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str13);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str14); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2411, v_t_2417), v_t_2421);
  V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_244));
  V v_x2_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s2138447488x1597606028(a_0, a_1)); heff_drop(v_t_2423); r_; });
  V v_t_2427;
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_Nil: {
    v_t_2427 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str15);
    break;
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_xs_2426 = heff_field(v_x2_2424, 1);
    heff_take_n(v_x2_2424, 3ULL, 2);
    v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str16); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2424);
  }
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str17)), v_t_2427);
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2ecallBound_str18));
}
V g_heff_2ecompile_2eemitc_2ecallBound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2ecallBound(a[0], a1, a2, a3, a[4]); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str0, 4, "_lam");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str1, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str2, 30, "(V self, V *args); static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str3, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str5, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str6, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str7, 18, "(V self, V *args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str8, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str10, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str11, 11, "heff_clo_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str12, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str14, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str17, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str18, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str19, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamC_str20, 1, ")");
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elamC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elamC_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2elamC(V v_k_240, V v_xs_241, V v_fv_242, V v_held_243, V v_body_244, V v_s_245) {
top: ;
  V v_inLam_246 = heff_take_field(v_k_240, 5);
  V v_exp_247 = heff_get_n(v_k_240, 0, 6);
  V v_s_248 = v_s_245;
  V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_s_248, 0)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str0));
  V v_t_2410 = heff_intShow(heff_dup(heff_rfield(v_s_248, 1)));
  V v_t_2411 = heff_intAdd(heff_take_field(v_s_248, 1), MK_INT(1LL));
  V v_t_2412 = ({ V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_s_248, 253ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_x2_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_249, v_t_2410), v_t_2412});
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tr(heff_call(v_inLam_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_t_2416, 1, 6), 1, (V[]){v_body_244}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      V v_n_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2428;
      switch (heff_tag_of(v_fv_242)) {
      case TAG_Nil: {
        V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str1), heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str2));
        V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str3));
        V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str4));
        V v_t_2425 = heff_strAppend(v_t_2424, heff_intShow(v_n_2421));
        v_t_2428 = heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2elamC_str5));
        break;
      }
      case TAG_Cons: {
        heff_drop(v_n_2421);
        v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str6), heff_dup(v_x_2414)), ((V)&g_heff_2ecompile_2eemitc_2elamC_str7));
        break;
      }
      default: heff_nomatch(v_fv_242);
      }
      HeffT2 v_t_2429 = (g_heff_2ecompile_2eemitc_2elamLines_24cpr(heff_dup(v_x_2414), heff_dup(v_xs_241), heff_dup(v_fv_242), v_x_2419));
      V v_t_2434;
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_x_2432 = v_field_2430;
        V v_xs_2433 = v_field_2431;
        v_t_2434 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str8); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
      }
      V v_m_2435 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2eaddLam_clo), 2, (V[]){v_t_2428, v_t_2434}));
      V v_f_2457 = heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam0, 1, 5, (V[]){v_exp_247, v_held_243, v_fv_242, v_x_2414, v_xs_241});
      V v_s_2458 = v_s_2420;
      V v_x2_2459 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2458}));
      switch (heff_tag_of(v_x2_2459)) {
      case TAG_MkPair: {
        V v_x_2460 = heff_field(v_x2_2459, 0);
        V v_s_2461 = heff_field(v_x2_2459, 1);
        heff_take_n(v_x2_2459, 3ULL, 2);
        return heff_tail(v_f_2457, 2, (V[]){v_x_2460, v_s_2461});
      }
      default: return heff_nomatch(v_x2_2459);
      }
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2elamC(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eemitc_2elamC_lam1(V self, V *args) {
  V v_s_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_fv_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_xs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_s_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_s_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    V v_x_2456;
    switch (heff_tag_of(v_fv_242)) {
    case TAG_Nil: {
      heff_drop(v_xs_241);
      heff_drop(v_x_2440);
      v_x_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str9), v_x_2414), ((V)&g_heff_2ecompile_2eemitc_2elamC_str10));
      break;
    }
    case TAG_Cons: {
      V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str11), v_x_2414), ((V)&g_heff_2ecompile_2eemitc_2elamC_str12));
      V v_t_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
      V v_t_2446 = heff_strAppend(v_t_2444, heff_intShow(v_t_2445));
      V v_t_2447 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
      V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2elamC_str13)), heff_intShow(v_t_2447));
      V v_t_2454;
      switch (heff_tag_of(v_x_2440)) {
      case TAG_Nil: {
        v_t_2454 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str14);
        break;
      }
      case TAG_Cons: {
        V v_t_2453;
        switch (heff_tag_of(v_x_2440)) {
        case TAG_Nil: {
          v_t_2453 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str15);
          break;
        }
        case TAG_Cons: {
          V v_x_2451 = heff_field(v_x_2440, 0);
          V v_xs_2452 = heff_field(v_x_2440, 1);
          heff_take_n(v_x_2440, 3ULL, 2);
          v_t_2453 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elamC_str16); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
          break;
        }
        default: heff_nomatch(v_x_2440);
        }
        v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamC_str17), v_t_2453), ((V)&g_heff_2ecompile_2eemitc_2elamC_str18));
        break;
      }
      default: heff_nomatch(v_x_2440);
      }
      V v_t_2455 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2elamC_str19)), v_t_2454);
      v_x_2456 = heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2eemitc_2elamC_str20));
      break;
    }
    default: heff_nomatch(v_fv_242);
    }
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){v_x_2456, v_s_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eemitc_2elamC_lam0(V self, V *args) {
  V v_u_2436 = args[0];
  V v_exp_247 = heff_env(self)[0];
  V v_held_243 = heff_env(self)[1];
  V v_fv_242 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_xs_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2436);
  V v_m_2437 = (g_prelude_2etraverse_24s1362847681x1386678580(v_exp_247, v_held_243));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2elamC_lam1, 1, 4, (V[]){v_m_2437, v_fv_242, v_x_2414, v_xs_241});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str0, 3, " t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str3, 5, "goto ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str4, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str5, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str7, 5, " = t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagainTo_str8, 1, ";");
Clo g_heff_2ecompile_2eemitc_2eagainTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eagainTo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eagainTo(V v_label_240, V v_ts_241, V v_ps_242, V v_vs_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s1876717925x1404326288(v_ts_241, heff_dup(v_vs_243)));
  V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_243));
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_247 = (g_list_2ezipWith_24s490727218x2138671(((V)&g_heff_2ecompile_2eemitc_2eagainTo_str0), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str1), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str2), v_t_244, v_t_246));
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eagainTo_str3), v_label_240), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str4));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_243); r_; });
  V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
  V v_t_2412 = (g_prelude_2e_2b_2b_24f543054808x1503188303(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str5), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str6), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str7), ((V)&g_heff_2ecompile_2eemitc_2eagainTo_str8), v_ps_242, v_t_2411));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2412));
}
V g_heff_2ecompile_2eemitc_2eagainTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eagainTo(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str1, 10, "heff_drop(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str2, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str3, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str4, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str5, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str8, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str9, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str13, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str14, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str16, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str17, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str18, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str19, 15, "heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str20, 4, "if (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str21, 3, ") {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str23, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str24, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str25, 8, "} else {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str26, 20, "switch (heff_tag_of(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str27, 4, ")) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str28, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str29, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str30, 18, "default: return ((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str31, 16, "){{heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str32, 5, ")}});");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str33, 29, "default: return heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str34, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str35, 22, "default: heff_nomatch(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str36, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str37, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str38, 9, "return ((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str39, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str40, 21, "){{heff_abandon()}});");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str41, 22, "return heff_abandon();");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str42, 7, "return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str43, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str44, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str45, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str46, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str47, 5, "args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str48, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str49, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str50, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str51, 52, ", args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str52, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str53, 8, ", args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str54, 17, "return heff_tail(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str55, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str56, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str57, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str58, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str59, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str60, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str61, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str62, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str63, 3, "top");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str64, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str65, 4, "top_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str66, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str67, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str68, 4, "top_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str69, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str70, 3, ": ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str71, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str72, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str73, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str74, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str75, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str76, 17, "HEFF_LAST return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str77, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str78, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str79, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2estmtF_str80, 2, ");");
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2estmtF_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_lam4, 1, 0};
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2estmtF_lam16(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2estmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2estmtF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2estmtF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CDrop: {
    V v_d_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_248;
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_d_242, 0);
      V v_x12_244 = heff_field(v_d_242, 1);
      heff_take_n(v_d_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = ({ V a_0 = v_x_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_243); r_; });
        V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str2), v_t_245));
        v_t_248 = heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str3));
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_243); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam0, 1, 1, (V[]){v_x_249});
  }
  case TAG_CLet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_e_2412 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_k_2413 = heff_dup(v_k_240);
    V v_ctype_2414 = heff_take_field(v_k_2413, 2);
    V v_tuples_2415 = heff_get_n(v_k_2413, 3, 6);
    V v_x_2416 = heff_dup(v_x_2411);
    V v_e_2417 = heff_dup(v_e_2412);
    V v_t_2436;
    switch (heff_tag_of(v_e_2417)) {
    case TAG_RPrim: {
      V v_p_2418 = heff_field(v_e_2417, 0);
      heff_take_n(v_e_2417, 1ULL, 2);
      heff_drop(v_tuples_2415);
      int64_t v_t_2420;
      switch (heff_tag_of(v_p_2418)) {
      case TAG_StrRuneDecode: {
        v_t_2420 = ((int64_t)2ULL);
        break;
      }
      default: {
        v_t_2420 = ((int64_t)0ULL);
        break;
      }
      }
      if ((((int64_t)0ULL) < v_t_2420)) {
        heff_drop(v_ctype_2414);
        heff_drop(v_x_2416);
        V v_t_2421;
        switch (heff_tag_of(v_p_2418)) {
        case TAG_StrRuneDecode: {
          v_t_2421 = MK_INT(2LL);
          break;
        }
        default: {
          heff_drop(v_p_2418);
          v_t_2421 = MK_INT(0LL);
          break;
        }
        }
        v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str4), heff_intShow(v_t_2421));
      } else {
        heff_drop(v_p_2418);
        v_t_2436 = heff_tr(heff_call(v_ctype_2414, 1, (V[]){v_x_2416}));
      }
      break;
    }
    case TAG_RCall: {
      V v_g_2422 = heff_field(v_e_2417, 0);
      heff_take_n(v_e_2417, 1ULL, 4);
      HeffT2 v_t_2426 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_tuples_2415, v_g_2422));
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        V v_t_2430;
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_x_2429 = v_field_2428;
          v_t_2430 = v_x_2429;
        } else {
          heff_drop(v_field_2428);
          v_t_2430 = MK_INT(0LL);
        }
        if (heff_intLt_c(MK_INT(0LL), v_t_2430)) {
          heff_drop(v_ctype_2414);
          heff_drop(v_x_2416);
          HeffT2 v_t_2431 = ({ V a_0 = v_tuples_2415; V a_1 = v_g_2422; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_tuples_2415); heff_drop(v_g_2422); r_; });
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            V v_t_2435;
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              V v_x_2434 = v_field_2433;
              v_t_2435 = v_x_2434;
            } else {
              heff_drop(v_field_2433);
              v_t_2435 = MK_INT(0LL);
            }
            v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str5), heff_intShow(v_t_2435));
          }
        } else {
          heff_drop(v_tuples_2415);
          heff_drop(v_g_2422);
          v_t_2436 = heff_tr(heff_call(v_ctype_2414, 1, (V[]){v_x_2416}));
        }
      }
      break;
    }
    default: {
      heff_drop(v_tuples_2415);
      heff_drop(v_e_2417);
      v_t_2436 = heff_tr(heff_call(v_ctype_2414, 1, (V[]){v_x_2416}));
      break;
    }
    }
    V v_t_2437 = ({ V a_0 = v_x_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str6); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
    V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str7)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str8), v_t_2437));
    V v_pre_2439 = heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str9));
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2412}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam1, 1, 2, (V[]){v_m_2440, v_pre_2439});
  }
  case TAG_CDecl: {
    V v_x_2447 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2448 = heff_tr(heff_call(heff_get_n(v_k_240, 2, 6), 1, (V[]){heff_dup(v_x_2447)}));
    V v_t_2449 = ({ V a_0 = v_x_2447; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str11); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2447); r_; });
    V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str12)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str13), v_t_2449));
    V v_x_2451 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2450, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str14)), NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam2, 1, 1, (V[]){v_x_2451});
  }
  case TAG_CSet: {
    V v_x_2453 = heff_field(v_x2_241, 0);
    V v_e_2454 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2455 = ({ V a_0 = v_x_2453; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str15); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2453); r_; });
    V v_pre_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str16), v_t_2455), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str17));
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2454}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam3, 1, 2, (V[]){v_m_2457, v_pre_2456});
  }
  case TAG_CAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2estmtF_lam4_clo);
  }
  case TAG_CIf: {
    V v_c_2466 = heff_field(v_x2_241, 0);
    V v_yes_2467 = heff_field(v_x2_241, 1);
    V v_no_2468 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2469 = (g_heff_2ecompile_2eemitc_2etestC(heff_dup(v_k_240), v_c_2466));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam5, 1, 4, (V[]){v_m_2469, v_k_240, v_yes_2467, v_no_2468});
  }
  case TAG_CSwitch: {
    V v_e_2488 = heff_field(v_x2_241, 0);
    V v_arms_2489 = heff_field(v_x2_241, 1);
    V v_returns_2490 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e_2488}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam6, 1, 4, (V[]){v_m_2491, v_arms_2489, v_k_240, v_returns_2490});
  }
  case TAG_CReturn: {
    V v_x21_24141 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_24141)) {
    case TAG_RAbandon: {
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam8, 1, 1, (V[]){v_k_240});
    }
    default: {
      V v_m_24147 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_x21_24141}));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam9, 1, 1, (V[]){v_m_24147});
    }
    }
  }
  case TAG_CInPlace: {
    V v_f_24154 = heff_field(v_x2_241, 0);
    V v_es_24155 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24156 = heff_get_n(v_k_240, 0, 6);
    V v_m_24157 = heff_tr(heff_call(heff_dup(v_f_24156), 1, (V[]){v_f_24154}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam10, 1, 3, (V[]){v_m_24157, v_f_24156, v_es_24155});
  }
  case TAG_CRoomed: {
    V v_f_24184 = heff_field(v_x2_241, 0);
    V v_es_24185 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24186 = heff_get_n(v_k_240, 0, 6);
    V v_m_24187 = heff_tr(heff_call(heff_dup(v_f_24186), 1, (V[]){v_f_24184}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam11, 1, 3, (V[]){v_m_24187, v_f_24186, v_es_24185});
  }
  case TAG_CTail: {
    V v_f_24197 = heff_field(v_x2_241, 0);
    V v_es_24198 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24199 = heff_get_n(v_k_240, 0, 6);
    V v_m_24200 = heff_tr(heff_call(heff_dup(v_f_24199), 1, (V[]){v_f_24197}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam12, 1, 3, (V[]){v_m_24200, v_f_24199, v_es_24198});
  }
  case TAG_CLoop: {
    V v_ps_24224 = heff_field(v_x2_241, 0);
    V v_es_24225 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24226 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_24225));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam13, 1, 3, (V[]){v_m_24226, v_k_240, v_ps_24224});
  }
  case TAG_CLoopTo: {
    V v_t_24233 = heff_field(v_x2_241, 0);
    V v_ps_24234 = heff_field(v_x2_241, 1);
    V v_es_24235 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24236 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_dup(heff_rfield(v_k_240, 0)), v_es_24235));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam14, 1, 4, (V[]){v_m_24236, v_t_24233, v_k_240, v_ps_24234});
  }
  case TAG_CLabel: {
    V v_t_24245 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_24246 = ({ V a_0 = v_t_24245; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str67); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_24245); r_; });
    V v_t_24247 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str68), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str69), v_t_24246));
    V v_x_24248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24247, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str70)), NTAG(TAG_Nil)});
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam15, 1, 1, (V[]){v_x_24248});
  }
  case TAG_CJump: {
    V v_g_24250 = heff_field(v_x2_241, 0);
    V v_w_24251 = heff_field(v_x2_241, 1);
    V v_es_24252 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24253 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24252));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam16, 1, 3, (V[]){v_m_24253, v_w_24251, v_g_24250});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2estmtF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2estmtF_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam1(V self, V *args) {
  V v_s_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_pre_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_s_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    V v_t_2445 = heff_strAppend(heff_strAppend(v_pre_2439, v_x_2443), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str10));
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){v_t_2446, v_s_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam2(V self, V *args) {
  V v_s_2452 = args[0];
  V v_x_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_s_2452});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam3(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_pre_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2462 = heff_strAppend(heff_strAppend(v_pre_2456, v_x_2460), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str18));
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_t_2463, v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam4(V self, V *args) {
  V v_s_2464 = args[0];
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str19), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_s_2464});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam5(V self, V *args) {
  V v_s_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_yes_2467 = heff_env(self)[2];
  V v_no_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_s_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    V v_m_2474 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_yes_2467}));
    V v_x2_2475 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_s_2473}));
    switch (heff_tag_of(v_x2_2475)) {
    case TAG_MkPair: {
      V v_x_2476 = heff_field(v_x2_2475, 0);
      V v_s_2477 = heff_field(v_x2_2475, 1);
      V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
      V v_m_2478 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 6), 1, (V[]){v_no_2468}));
      V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_s_2477}));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_MkPair: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_s_2481 = heff_field(v_x2_2479, 1);
        V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
        V v_t_2482 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str20), v_x_2472), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str21));
        V v_t_2483 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2estmtF_str22), v_x_2476));
        V v_t_2484 = heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str23), NTAG(TAG_Nil)});
        V v_t_2485 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2484, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str24), v_x_2480));
        V v_t_2486 = (g_prelude_2e_2b_2b(v_t_2483, heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str25), v_t_2485})));
        V v_x_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, v_t_2486});
        return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_x_2487, v_s_2481});
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
    default: return heff_nomatch(v_x2_2475);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam7(V self, V *args) {
  V v_a_2496 = args[0];
  V v_arms_2489 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_x_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_arms_2489)) {
  case TAG_Nil: {
    return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
  }
  case TAG_Cons: {
    V v_arms1_2497 = heff_field(v_arms_2489, 0);
    V v_arms2_2498 = heff_field(v_arms_2489, 1);
    heff_take_n(v_arms_2489, 3ULL, 2);
    switch (heff_tag_of(v_arms1_2497)) {
    case TAG_MkCArm: {
      V v_t_2499 = heff_field(v_arms1_2497, 0);
      heff_take_n(v_arms1_2497, 1ULL, 8);
      switch (heff_tag_of(v_arms2_2498)) {
      case TAG_Nil: {
        if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2499, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2499, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
          heff_drop(v_t_2499);
          return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2etupleArm(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
        } else {
          heff_drop(v_t_2499);
          return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
        }
      }
      case TAG_Cons: {
        heff_take_n(v_arms2_2498, 0ULL, 2);
        heff_drop(v_t_2499);
        return ({ V a_0 = v_k_240; V a_1 = v_x_2494; V a_2 = v_a_2496; V r_ = (g_heff_2ecompile_2eemitc_2earmF(a_0, a_1, a_2)); heff_drop(v_a_2496); r_; });
      }
      default: return heff_nomatch(v_arms2_2498);
      }
    }
    default: return heff_nomatch(v_arms1_2497);
    }
  }
  default: return heff_nomatch(v_arms_2489);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam6(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  V v_arms_2489 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_returns_2490 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2493 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_m_24109 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_clo_n(g_heff_2ecompile_2eemitc_2estmtF_lam7, 1, 3, (V[]){heff_dup(v_arms_2489), heff_dup(v_k_240), heff_dup(v_x_2494)}), heff_dup(v_arms_2489)));
    V v_x2_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_s_2495}));
    switch (heff_tag_of(v_x2_24110)) {
    case TAG_MkPair: {
      V v_x_24111 = heff_field(v_x2_24110, 0);
      V v_s_24112 = heff_field(v_x2_24110, 1);
      V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
      V v_t_24125;
      switch (heff_tag_of(v_arms_2489)) {
      case TAG_Nil: {
        v_t_24125 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_arms1_24113 = heff_dup(heff_field(v_arms_2489, 0));
        V v_arms2_24114 = heff_dup(heff_field(v_arms_2489, 1));
        switch (heff_tag_of(v_arms1_24113)) {
        case TAG_MkCArm: {
          V v_t_24115 = heff_field(v_arms1_24113, 0);
          heff_take_n(v_arms1_24113, 1ULL, 8);
          switch (heff_tag_of(v_arms2_24114)) {
          case TAG_Nil: {
            v_t_24125 = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_24115, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_24115, MK_INT(0LL), 2)) == ((int64_t)35ULL))));
            heff_drop(v_t_24115);
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_arms2_24114, 0ULL, 2);
            heff_drop(v_t_24115);
            v_t_24125 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_arms2_24114);
          }
          break;
        }
        default: heff_nomatch(v_arms1_24113);
        }
        break;
      }
      default: heff_nomatch(v_arms_2489);
      }
      V v_x_24140;
      if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
        heff_drop(v_arms_2489);
        heff_drop_rec(v_k_240, 6);
        heff_drop(v_returns_2490);
        heff_drop(v_x_2494);
        heff_drop_cell(v_ru_24x2_24110_24MkPair, 2);
        heff_drop(v_t_24125);
        V v_t_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24111));
        v_x_24140 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24126; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24126); r_; });
      } else {
        heff_drop(v_t_24125);
        V v_t_24127 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str26), heff_dup(v_x_2494)), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str27));
        V v_t_24128 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_24111));
        V v_t_24129 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24128; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_24128); r_; });
        V v_t_24130 = ({ V a_0 = v_arms_2489; V r_ = (g_list_2eany_24s1041788812x158895160(a_0)); heff_drop(v_arms_2489); r_; });
        V v_t_24138;
        if ((heff_dup(v_t_24130) == NTAG(TAG_True))) {
          heff_drop_rec(v_k_240, 6);
          heff_drop(v_returns_2490);
          heff_drop(v_x_2494);
          heff_drop(v_t_24130);
          v_t_24138 = heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str28), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_24130);
          V v_n_24131 = heff_get_n(v_k_240, 4, 6);
          V v_x2_24132 = v_returns_2490;
          V v_sv_24133 = v_x_2494;
          V v_t_24136;
          if ((heff_dup(v_x2_24132) == NTAG(TAG_True))) {
            heff_drop(v_x2_24132);
            if (heff_intLt_c_lent(MK_INT(0LL), v_n_24131, 1)) {
              V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str29), heff_intShow(v_n_24131));
              V v_t_24135 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str30), v_t_24134), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str31));
              v_t_24136 = heff_strAppend(heff_strAppend(v_t_24135, v_sv_24133), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str32));
            } else {
              heff_drop(v_n_24131);
              v_t_24136 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str33), v_sv_24133), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str34));
            }
          } else {
            heff_drop(v_n_24131);
            heff_drop(v_x2_24132);
            v_t_24136 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str35), v_sv_24133), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str36));
          }
          V v_t_24137 = heff_tag_at_n(v_ru_24x2_24110_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2estmtF_str37), NTAG(TAG_Nil)});
          v_t_24138 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, v_t_24137});
        }
        V v_ys_24139 = (g_prelude_2e_2b_2b(v_t_24129, v_t_24138));
        v_x_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24127, v_ys_24139});
      }
      return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_x_24140, v_s_24112});
    }
    default: return heff_nomatch(v_x2_24110);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam8(V self, V *args) {
  V v_s_24142 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24145;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_k_240, 4)))) {
    V v_t_24143 = heff_intShow(heff_get_n(v_k_240, 4, 6));
    V v_t_24144 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str38), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str39), v_t_24143));
    v_t_24145 = heff_strAppend(v_t_24144, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str40));
  } else {
    heff_drop_rec(v_k_240, 6);
    v_t_24145 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str41);
  }
  V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24145, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24146, v_s_24142});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam9(V self, V *args) {
  V v_s_24148 = args[0];
  V v_m_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24149 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_s_24148}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_s_24151 = heff_field(v_x2_24149, 1);
    V v_ru_24x2_24149_24MkPair = heff_take_reuse_n(v_x2_24149, 3ULL, 2);
    V v_t_24152 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str42), v_x_24150), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str43));
    V v_t_24153 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24152, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24149_24MkPair, TAG_MkPair, 2, (V[]){v_t_24153, v_s_24151});
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam10(V self, V *args) {
  V v_s_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_f_24156 = heff_env(self)[1];
  V v_es_24155 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_s_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_s_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_m_24162 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24156, v_es_24155));
    V v_x2_24163 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_s_24161}));
    switch (heff_tag_of(v_x2_24163)) {
    case TAG_MkPair: {
      V v_x_24164 = heff_field(v_x2_24163, 0);
      V v_s_24165 = heff_field(v_x2_24163, 1);
      V v_ru_24x2_24163_24MkPair = heff_take_reuse_n(v_x2_24163, 3ULL, 2);
      V v_vs_24166 = heff_tag_at_n(v_ru_24x2_24163_24MkPair, TAG_Cons, 2, (V[]){v_x_24160, v_x_24164});
      V v_t_24169;
      switch (heff_tag_of(v_vs_24166)) {
      case TAG_Nil: {
        v_t_24169 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str44);
        break;
      }
      case TAG_Cons: {
        V v_x_24167 = heff_dup(heff_field(v_vs_24166, 0));
        v_t_24169 = v_x_24167;
        break;
      }
      default: heff_nomatch(v_vs_24166);
      }
      V v_t_24170 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str45), v_t_24169), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str46));
      V v_t_24171 = (g_list_2edrop(MK_INT(1LL), v_vs_24166));
      V v_t_24172 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_24166));
      V v_t_24173 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_24172, MK_INT(2LL))));
      V v_t_24174 = (g_list_2ezipWith_24s952564628x174753269(((V)&g_heff_2ecompile_2eemitc_2estmtF_str47), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str48), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str49), v_t_24171, v_t_24173));
      V v_t_24175 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_24166));
      V v_t_24176 = heff_intShow(heff_intSub(v_t_24175, MK_INT(1LL)));
      V v_t_24177 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str50), v_t_24176), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str51));
      V v_t_24178 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_24166; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_vs_24166, 2); r_; });
      V v_t_24179 = heff_intShow(heff_intSub(v_t_24178, MK_INT(1LL)));
      V v_t_24180 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str52), v_t_24179), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str53));
      V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24180, NTAG(TAG_Nil)});
      V v_ys_24182 = (g_prelude_2e_2b_2b(v_t_24174, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24177, v_t_24181})));
      V v_x_24183 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24170, v_ys_24182});
      return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_x_24183, v_s_24165});
    }
    default: return heff_nomatch(v_x2_24163);
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam11(V self, V *args) {
  V v_s_24188 = args[0];
  V v_m_24187 = heff_env(self)[0];
  V v_f_24186 = heff_env(self)[1];
  V v_es_24185 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24189 = heff_tr(heff_call(v_m_24187, 1, (V[]){v_s_24188}));
  switch (heff_tag_of(v_x2_24189)) {
  case TAG_MkPair: {
    V v_x_24190 = heff_field(v_x2_24189, 0);
    V v_s_24191 = heff_field(v_x2_24189, 1);
    V v_ru_24x2_24189_24MkPair = heff_take_reuse_n(v_x2_24189, 3ULL, 2);
    V v_m_24192 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24186, v_es_24185));
    V v_x2_24193 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_s_24191}));
    switch (heff_tag_of(v_x2_24193)) {
    case TAG_MkPair: {
      V v_x_24194 = heff_field(v_x2_24193, 0);
      V v_s_24195 = heff_field(v_x2_24193, 1);
      V v_ru_24x2_24193_24MkPair = heff_take_reuse_n(v_x2_24193, 3ULL, 2);
      V v_x_24196 = ({ V b_0 = heff_tag_at_n(v_ru_24x2_24193_24MkPair, TAG_Cons, 2, (V[]){v_x_24190, v_x_24194}); V r_ = (g_heff_2ecompile_2eemitc_2eroomed(b_0)); heff_drop(b_0); r_; });
      return heff_tag_at_n(v_ru_24x2_24189_24MkPair, TAG_MkPair, 2, (V[]){v_x_24196, v_s_24195});
    }
    default: return heff_nomatch(v_x2_24193);
    }
  }
  default: return heff_nomatch(v_x2_24189);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam12(V self, V *args) {
  V v_s_24201 = args[0];
  V v_m_24200 = heff_env(self)[0];
  V v_f_24199 = heff_env(self)[1];
  V v_es_24198 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24202 = heff_tr(heff_call(v_m_24200, 1, (V[]){v_s_24201}));
  switch (heff_tag_of(v_x2_24202)) {
  case TAG_MkPair: {
    V v_x_24203 = heff_field(v_x2_24202, 0);
    V v_s_24204 = heff_field(v_x2_24202, 1);
    V v_ru_24x2_24202_24MkPair = heff_take_reuse_n(v_x2_24202, 3ULL, 2);
    V v_m_24205 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24199, heff_dup(v_es_24198)));
    V v_x2_24206 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_s_24204}));
    switch (heff_tag_of(v_x2_24206)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_field(v_x2_24206, 0);
      V v_s_24208 = heff_field(v_x2_24206, 1);
      V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
      V v_t_24209 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str54), heff_dup(v_x_24203)), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str55));
      V v_t_24210 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24198; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24198); r_; });
      V v_t_24211 = heff_strAppend(v_t_24209, heff_intShow(v_t_24210));
      HeffT3 v_t_24212 = ({ V a_0 = MK_INT(1LL); V b_1 = heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_Cons, 2, (V[]){v_x_24203, v_x_24207}); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24221;
      {
        V v_field_24214 = v_t_24212.f[1];
        V v_field_24215 = v_t_24212.f[2];
        int64_t v_tag_24213 = ((int64_t)v_t_24212.f[0]);
        if ((v_tag_24213 == ((int64_t)0ULL))) {
          V v_x11_24216 = heff_dup(v_field_24214);
          heff_drop(v_x11_24216);
          V v_x12_24217 = heff_dup(v_field_24215);
          heff_drop(v_x12_24217);
          V v_t_24220;
          if ((v_tag_24213 == ((int64_t)0ULL))) {
            V v_x_24218 = v_field_24214;
            V v_xs_24219 = v_field_24215;
            v_t_24220 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str56); V a_1 = v_x_24218; V a_2 = v_xs_24219; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24219); r_; });
          } else {
            heff_drop(v_field_24214);
            heff_drop(v_field_24215);
            v_t_24220 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str57);
          }
          v_t_24221 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str58), v_t_24220), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str59));
        } else {
          heff_drop(v_field_24214);
          heff_drop(v_field_24215);
          v_t_24221 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str60);
        }
      }
      V v_t_24222 = heff_strAppend(heff_strAppend(v_t_24211, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str61)), v_t_24221);
      V v_x_24223 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24222, ((V)&g_heff_2ecompile_2eemitc_2estmtF_str62)), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_24202_24MkPair, TAG_MkPair, 2, (V[]){v_x_24223, v_s_24208});
    }
    default: return heff_nomatch(v_x2_24206);
    }
  }
  default: return heff_nomatch(v_x2_24202);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam13(V self, V *args) {
  V v_s_24227 = args[0];
  V v_m_24226 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  V v_ps_24224 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24228 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_s_24227}));
  switch (heff_tag_of(v_x2_24228)) {
  case TAG_MkPair: {
    V v_x_24229 = heff_field(v_x2_24228, 0);
    V v_s_24230 = heff_field(v_x2_24228, 1);
    V v_ru_24x2_24228_24MkPair = heff_take_reuse_n(v_x2_24228, 3ULL, 2);
    V v_ts_24231 = (g_list_2emap(heff_get_n(v_k_240, 2, 6), heff_dup(v_ps_24224)));
    V v_x_24232 = (g_heff_2ecompile_2eemitc_2eagainTo(((V)&g_heff_2ecompile_2eemitc_2estmtF_str63), v_ts_24231, v_ps_24224, v_x_24229));
    return heff_tag_at_n(v_ru_24x2_24228_24MkPair, TAG_MkPair, 2, (V[]){v_x_24232, v_s_24230});
  }
  default: return heff_nomatch(v_x2_24228);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam14(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  V v_t_24233 = heff_env(self)[1];
  V v_k_240 = heff_env(self)[2];
  V v_ps_24234 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    V v_ru_24x2_24238_24MkPair = heff_take_reuse_n(v_x2_24238, 3ULL, 2);
    V v_t_24241 = ({ V a_0 = v_t_24233; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str64); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_24233); r_; });
    V v_t_24242 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str65), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str66), v_t_24241));
    V v_t_24243 = (g_list_2emap(heff_get_n(v_k_240, 2, 6), heff_dup(v_ps_24234)));
    V v_x_24244 = (g_heff_2ecompile_2eemitc_2eagainTo(v_t_24242, v_t_24243, v_ps_24234, v_x_24239));
    return heff_tag_at_n(v_ru_24x2_24238_24MkPair, TAG_MkPair, 2, (V[]){v_x_24244, v_s_24240});
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2ecompile_2eemitc_2estmtF_lam15(V self, V *args) {
  V v_s_24249 = args[0];
  V v_x_24248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24248, v_s_24249});
}
V g_heff_2ecompile_2eemitc_2estmtF_lam16(V self, V *args) {
  V v_s_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  V v_w_24251 = heff_env(self)[1];
  V v_g_24250 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24255 = heff_tr(heff_call(v_m_24253, 1, (V[]){v_s_24254}));
  switch (heff_tag_of(v_x2_24255)) {
  case TAG_MkPair: {
    V v_x_24256 = heff_field(v_x2_24255, 0);
    V v_s_24257 = heff_field(v_x2_24255, 1);
    V v_ru_24x2_24255_24MkPair = heff_take_reuse_n(v_x2_24255, 3ULL, 2);
    V v_t_24260;
    if ((heff_dup(v_w_24251) == NTAG(TAG_True))) {
      heff_drop(v_w_24251);
      V v_t_24258 = ({ V a_0 = v_g_24250; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str71); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24250); r_; });
      v_t_24260 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str72), v_t_24258), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str73));
    } else {
      heff_drop(v_w_24251);
      V v_t_24259 = ({ V a_0 = v_g_24250; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str74); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24250); r_; });
      v_t_24260 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str75), v_t_24259);
    }
    V v_t_24261 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2estmtF_str76), v_t_24260), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str77));
    V v_t_24264;
    switch (heff_tag_of(v_x_24256)) {
    case TAG_Nil: {
      v_t_24264 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str78);
      break;
    }
    case TAG_Cons: {
      V v_x_24262 = heff_field(v_x_24256, 0);
      V v_xs_24263 = heff_field(v_x_24256, 1);
      heff_take_n(v_x_24256, 3ULL, 2);
      v_t_24264 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2estmtF_str79); V a_1 = v_x_24262; V a_2 = v_xs_24263; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24263); r_; });
      break;
    }
    default: heff_nomatch(v_x_24256);
    }
    V v_t_24265 = heff_strAppend(heff_strAppend(v_t_24261, v_t_24264), ((V)&g_heff_2ecompile_2eemitc_2estmtF_str80));
    V v_x_24266 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24265, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_24255_24MkPair, TAG_MkPair, 2, (V[]){v_x_24266, v_s_24257});
  }
  default: return heff_nomatch(v_x2_24255);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eckOf_str3, 1, "V");
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eckOf_lam4(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eckOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eckOf(V v_rs_240, V v_tu_241, V v_ret_242) {
top: ;
  return heff_rec_n(6, shape_exp__stmts__ctype__tuples__ret__inLam, (V[]){heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam0, 1, 3, (V[]){heff_dup(v_rs_240), heff_dup(v_tu_241), heff_dup(v_ret_242)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam1, 1, 3, (V[]){heff_dup(v_rs_240), heff_dup(v_tu_241), heff_dup(v_ret_242)}), heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam3, 1, 1, (V[]){heff_dup(v_rs_240)}), heff_dup(v_tu_241), v_ret_242, heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam4, 1, 2, (V[]){heff_dup(v_rs_240), v_tu_241})});
}
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eckOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemitc_2eckOf_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  V v_ret_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = v_ret_242; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
  return (g_heff_2ecompile_2eemitc_2eexpF(v_t_244, v_e_243));
}
V g_heff_2ecompile_2eemitc_2eckOf_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2410));
    V v_x_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2412); r_; });
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_s_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_lam1(V self, V *args) {
  V v_ss_245 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  V v_ret_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_246 = ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = v_ret_242; V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
  V v_m_247 = (g_prelude_2etraverse_24s428640578x580976168(v_k_246, v_ss_245));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2eckOf_lam2, 1, 1, (V[]){v_m_247});
}
V g_heff_2ecompile_2eemitc_2eckOf_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V a_0 = v_rs_240; V a_1 = v_x_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_rs_240); heff_drop(v_x_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      switch (heff_tag_of(v_x_2418)) {
      case TAG_RepV: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str0);
      }
      case TAG_RepFix: {
        V v_w_2419 = heff_field(v_x_2418, 0);
        heff_take_n(v_x_2418, 1ULL, 1);
        return ({ V a_0 = v_w_2419; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2419); r_; });
      }
      case TAG_RepF64: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str1);
      }
      case TAG_RepInt: {
        return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str2);
      }
      default: return heff_nomatch(v_x_2418);
      }
    } else {
      heff_drop(v_field_2417);
      return ((V)&g_heff_2ecompile_2eemitc_2eckOf_str3);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eckOf_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_rs_240 = heff_env(self)[0];
  V v_tu_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2420);
  return ({ V a_0 = v_rs_240; V a_1 = v_tu_241; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2eemitc_2eckOf(a_0, a_1, a_2)); heff_drop(v_rs_240); r_; });
}
Clo g_heff_2ecompile_2eemitc_2eelemI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemI_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemI(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_j_242 = heff_field(v_x2_241, 0);
    V v_js_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, v_j_242, 0)) {
      heff_drop(v_i_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_js_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemI_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemI(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V v_tu_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_DFun: {
    V v_f_243 = heff_field(v_x2_241, 0);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_tu_240, heff_rfield(v_f_243, 0)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      V v_t_248;
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_246;
        v_t_248 = v_x_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = MK_INT(0LL);
      }
      if (heff_intLt_c(MK_INT(0LL), v_t_248)) {
        HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_tu_240, heff_rfield(v_f_243, 0)));
        V v_t_2413;
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2411;
            v_t_2413 = v_x_2412;
          } else {
            heff_drop(v_field_2411);
            v_t_2413 = MK_INT(0LL);
          }
        }
        return (g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(v_tu_240, v_t_2413, heff_dup(v_f_243), v_z_242));
      } else {
        HEFF_LAST return g_heff_2ecompile_2eemitc_2efunDef_24cpr(v_tu_240, heff_dup(v_f_243), v_z_242);
      }
    }
  }
  case TAG_DVal: {
    V v_key_2414 = heff_field(v_x2_241, 0);
    V v_body_2415 = heff_field(v_x2_241, 1);
    V v_rs_2416 = heff_field(v_x2_241, 2);
    return (g_heff_2ecompile_2eemitc_2evalDef_24cpr(v_tu_240, v_key_2414, heff_dup(v_body_2415), v_rs_2416, v_z_242));
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eemitc_2eletGoIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2eletGoIndexGo(V v_i_240, V v_x2_241, V v_t_242, V v_r_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_t2_246 = heff_field(v_x21_244, 0);
      V v_r2_247 = heff_field(v_x21_244, 1);
      if ((heff_strEq_c_lent(v_t_242, v_t2_246, 0) && heff_strEq_c_lent(v_r_243, v_r2_247, 0))) {
        return v_i_240;
      } else {
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_rest_245;
        V t_2 = v_t_242;
        V t_3 = v_r_243;
        v_i_240 = t_0;
        v_x2_241 = t_1;
        v_t_242 = t_2;
        v_r_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eletGoIndexGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eemitc_2eletGoIndexGo(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str0, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str2, 12, "static void ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str3, 12, "(void *q) { ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str4, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str5, 8, " *)q); }");
Clo g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(V v_leaf_240, V v_what_241, V v_i_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_leaf_240);
    heff_drop(v_what_241);
    heff_drop(v_i_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_t_247 = heff_field(v_x41_245, 0);
      V v_r_248 = heff_field(v_x41_245, 1);
      heff_take_n(v_x41_245, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str0), heff_dup(v_leaf_240)), ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str1));
      V v_t_2410 = heff_strAppend(heff_dup(v_what_241), heff_intShow(heff_dup(v_i_242)));
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str2), heff_strAppend(v_t_249, v_t_2410));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str3)), v_r_248);
      V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str4)), v_t_247);
      V v_cell_2414 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_str5)), heff_hole()});
      V v_u_2415 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2414));
      heff_drop(v_u_2415);
      V t_0 = v_leaf_240;
      V t_1 = v_what_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_rest_246;
      V t_4 = v_cell_2414;
      v_leaf_240 = t_0;
      v_what_241 = t_1;
      v_i_242 = t_2;
      v_x4_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str0, 64, "static V heff_perform(V p, V k) { return heff_perform_0(p, k); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str2, 35, "static V heff_entry(void) { return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str5, 9, "_get(); }");
HEFF_LIT(g_heff_2ecompile_2eemitc_2erunEnd_str6, 0, "");
Clo g_heff_2ecompile_2eemitc_2erunEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2erunEnd_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2erunEnd(V v_eff_240, V v_ce_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eemitc_2eperformNodes_24cpr(v_eff_240, MK_INT(0LL)));
  V v_t_247;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_x_245 = v_field_243;
    V v_y_246 = v_field_244;
    heff_drop(v_y_246);
    v_t_247 = v_x_245;
  }
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str0), NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
  V v_t_2410 = ({ V b_0 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str1); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str2), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2erunEnd_str3), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str4), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2erunEnd_str5)), v_t_2412});
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2erunEnd_str6), v_t_2413}));
}
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2erunEnd(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str0, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str1, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str4, 8, "#define ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str5, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str8, 32, "static V heff_perform(V p, V k);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str9, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprogramCE_str10, 42, "// Generated from Hippogriff; do not edit.");
Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprogramCE_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eprogramCE(V v_runtime_240, V v_provs_241, V v_ending_242, V v_defs_243, V v_ce_244) {
top: ;
  V v_prefix_245 = heff_take_field(v_ending_242, 0);
  V v_end_246 = heff_get_n(v_ending_242, 1, 2);
  V v_t_247 = (g_prelude_2etraverse_24s1370495575x1780346529(heff_dup(v_ce_244), v_defs_243));
  V v_t_248 = heff_tr(heff_call(v_t_247, 1, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get())}));
  switch (heff_tag_of(v_t_248)) {
  case TAG_MkPair: {
    V v_ems_249 = heff_field(v_t_248, 0);
    V v_s_2410 = heff_field(v_t_248, 1);
    V v_ru_24t_248_24MkPair = heff_take_reuse_n(v_t_248, 3ULL, 2);
    V v_strs_2411 = heff_take_field(v_s_2410, 5);
    V v_shapes_2412 = heff_take_field(v_s_2410, 6);
    V v_protos_2413 = heff_take_field(v_s_2410, 3);
    V v_prims_2414 = heff_take_field(v_s_2410, 7);
    V v_lams_2415 = heff_get_n(v_s_2410, 2, 8);
    V v_t_2416 = v_prefix_245;
    V v_t_2417 = (g_std_2eordmap_2etoListOnto(heff_rfield(v_ce_244, 0), NTAG(TAG_Nil)));
    V v_t_2418 = (g_list_2ekeepIf_24s1814523351x214817707(v_t_2417));
    V v_t_2419 = (g_list_2emap_24s2133060086x110881273(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str0), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str1), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str2), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str3), v_t_2418));
    V v_t_2420 = (g_std_2eordmap_2etoListOnto(heff_rfield(v_ce_244, 1), NTAG(TAG_Nil)));
    V v_t_2421 = (g_list_2emap_24s2133060086x110881273(((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str4), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str5), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str6), ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str7), v_t_2420));
    V v_t_2422 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_strs_2411));
    V v_t_2424 = (g_list_2emap_24s1173914895x100384474(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_shapes_2412));
    V v_t_2426 = (g_list_2emap_24s1173914895x100384474(v_t_2425));
    V v_t_2427 = (g_heff_2ecompile_2eemitc_2eonceInOrder(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2426));
    V v_t_2428 = (g_list_2emap_24s2073083146x1445066245(v_t_2427));
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ems_249)));
    V v_t_2430 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2429; V r_ = (g_list_2efoldl_24s292588827x1477362994(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_protos_2413));
    V v_t_2432 = (g_list_2emap_24s1173914895x100384474(v_t_2431));
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_prims_2414));
    V v_t_2434 = (g_list_2emap_24s1173914895x100384474(v_t_2433));
    V v_t_2435 = (g_list_2efoldl_24f96178826x1085061806(NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get()), v_t_2434));
    V v_t_2436 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s41085868x1118058949(a_0, a_1)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ems_249));
    V v_t_2438 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2437; V r_ = (g_list_2efoldl_24s1028839125x1033007016(a_0, a_1)); heff_drop(v_t_2437); r_; });
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_lams_2415));
    V v_t_2440 = (g_list_2emap_24s1173914895x100384474(v_t_2439));
    V v_t_2441 = heff_tr(heff_call(v_end_246, 1, (V[]){v_ce_244}));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
    V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2442));
    V v_t_2444 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2443));
    V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2432, v_t_2444));
    V v_t_2446 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2445));
    V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2446));
    V v_ys_2448 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2447));
    V v_ys_2449 = (g_prelude_2e_2b_2b(v_t_2422, heff_tag_at_n(v_ru_24t_248_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str8), v_ys_2448})));
    V v_t_2450 = (g_prelude_2e_2b_2b(v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_runtime_240, v_ys_2449})));
    V v_ys_2451 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2450));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str9); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2eprogramCE_str10); V a_2 = v_t_2416; V a_3 = v_ys_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); heff_drop(v_ys_2451); r_; });
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprogramCE(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eownLines_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eownLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eownLines_entry, 5, 0};

V g_heff_2ecompile_2eemitc_2eownLines(V v_s_240, V v_strs_241, V v_protos_242, V v_lams_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_d_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_field(v_x5_244, 1);
    V v_protos_247 = heff_dup(heff_rfield(v_e_246, 0));
    V v_code_248 = heff_dup(heff_rfield(v_e_246, 1));
    V v_t_249 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str0)));
    V v_o_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str1), v_t_249);
    HeffT2 v_t_2411 = ({ V a_0 = v_strs_241; V a_1 = v_o_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_o_2410); r_; });
    V v_t_2415;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2413;
        v_t_2415 = v_x_2414;
      } else {
        heff_drop(v_field_2413);
        v_t_2415 = NTAG(TAG_Nil);
      }
    }
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str2)));
    V v_o_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str3), v_t_2416);
    HeffT2 v_t_2418 = ({ V a_0 = v_protos_242; V a_1 = v_o_2417; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_o_2417); r_; });
    V v_t_2422;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2421 = v_field_2420;
        v_t_2422 = v_x_2421;
      } else {
        heff_drop(v_field_2420);
        v_t_2422 = NTAG(TAG_Nil);
      }
    }
    V v_t_2423 = (g_list_2emap_24s380834591x871125279(v_t_2422));
    V v_t_2424 = ({ V b_0 = MK_INT(7LL); V a_1 = v_protos_247; V r_ = (g_list_2emap_24f1632378148x1903828118(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2425 = (g_list_2emap_24s380834591x871125279(v_code_248));
    V v_t_2426 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_245, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eownLines_str4)));
    V v_o_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eownLines_str5), v_t_2426);
    HeffT2 v_t_2428 = ({ V a_0 = v_lams_243; V a_1 = v_o_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_o_2427); r_; });
    V v_t_2432;
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_x_2431 = v_field_2430;
        v_t_2432 = v_x_2431;
      } else {
        heff_drop(v_field_2430);
        v_t_2432 = NTAG(TAG_Nil);
      }
    }
    V v_t_2433 = (g_list_2emap_24s380834591x871125279(v_t_2432));
    V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2425, v_t_2433));
    V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2434));
    V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2435));
    return (g_prelude_2e_2b_2b(v_t_2415, v_t_2436));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eemitc_2eownLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eownLines(a0, a1, a2, a3, a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eentryPart_str0, 10, "run$main.c");

static V g_heff_2ecompile_2eemitc_2eentryPart_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eentryPart_st;
static V g_heff_2ecompile_2eemitc_2eentryPart_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2eentryPart_str0);
}
V g_heff_2ecompile_2eemitc_2eentryPart_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eentryPart_st)) return g_heff_2ecompile_2eemitc_2eentryPart_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eentryPart_val, &g_heff_2ecompile_2eemitc_2eentryPart_st, g_heff_2ecompile_2eemitc_2eentryPart_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str0, 4, "$tok");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str1, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str2, 2, ".c");
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry, 11, 0};

V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(V v_lit_240, V v_lit_241, V v_lit_242, V v_ce_243, V v_s_244, V v_shapes_245, V v_prims_246, V v_strs_247, V v_protos_248, V v_lams_249, V v_x9_2410) {
top: ;
  switch (heff_tag_of(v_x9_2410)) {
  case TAG_MkPair: {
    V v_m_2411 = heff_field(v_x9_2410, 0);
    V v_ps_2412 = heff_field(v_x9_2410, 1);
    V v_ru_24x9_2410_24MkPair = heff_take_reuse_n(v_x9_2410, 3ULL, 2);
    V v_t_2413 = heff_tag_at_n(v_ru_24x9_2410_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2414 = (g_list_2efoldl_24f891411706x655200538(NTAG(TAG_Nil), heff_dup(v_ps_2412)));
    V v_t_2415 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2413, v_t_2414));
    V v_t_2416 = ({ V a_0 = heff_dup(v_ce_243); V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2eemitc_2enumbersOf(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2eusedBy(v_shapes_245, heff_dup(v_ps_2412)));
    V v_t_2418 = (g_list_2emap_24s2073083146x1445066245(v_t_2417));
    V v_xs_2419 = (g_heff_2ecompile_2eemitc_2eusedBy(v_prims_246, heff_dup(v_ps_2412)));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    V v_t_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s41085868x1118058949(a_0, a_1)); heff_drop(v_t_2420); r_; });
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2412)));
    V v_xs_2443 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam0, 2, 1, (V[]){heff_dup(v_ce_243)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2422; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    V v_m_2444 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2443; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2443); r_; });
    V v_t_2445 = ({ V a_0 = v_m_2444; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2444); r_; });
    V v_t_2446 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_2445));
    V v_t_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam2, 2, 1, (V[]){v_ce_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
    V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
    V v_t_2455 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam3, 2, 4, (V[]){heff_dup(v_s_244), heff_dup(v_strs_247), heff_dup(v_protos_248), heff_dup(v_lams_249)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2451; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; });
    V v_t_2456 = (g_prelude_2e_2b_2b(v_t_2450, v_t_2455));
    V v_t_2457 = (g_prelude_2e_2b_2b(v_t_2421, v_t_2456));
    V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2457));
    V v_ys_2459 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2458));
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, v_ys_2459})});
    V v_t_2461 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str1); V a_1 = v_lit_240; V a_2 = v_t_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2460, 2); r_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_m_2411, ((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str2)), v_t_2461});
  }
  default: return heff_nomatch(v_x9_2410);
  }
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V r = g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866(a[0], a[1], a[2], a[3], a4, a5, a6, a7, a8, a9, a[10]); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); return r;
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam1(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_x_2433 = args[1];
  V v_ce_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_get_n(heff_get_n(v_ce_2429, 2, 3), 10, 11);
  HeffT2 v_t_2435 = ({ V b_0 = heff_get_n(v_t_2434, 0, 2); V a_1 = v_x_2433; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2439;
  {
    V v_field_2437 = v_t_2435.f[1];
    int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
    if ((v_tag_2436 == ((int64_t)0ULL))) {
      V v_x_2438 = v_field_2437;
      v_t_2439 = v_x_2438;
    } else {
      heff_drop(v_field_2437);
      v_t_2439 = NTAG(TAG_Nil);
    }
  }
  V v_t_2440 = (g_prelude_2e_2b_2b_24f132290754x1091834184(v_acc_2432, heff_dup(v_x_2433), ((V)&g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_str0), v_t_2439));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2433, v_t_2440});
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam0(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_x_2424 = args[1];
  V v_ce_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_MkPair: {
    V v_d_2425 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24MkPair = heff_take_reuse_n(v_x_2424, 1ULL, 2);
    V v_key_2427 = heff_take_field(v_d_2425, 0);
    V v_body_2428 = heff_get_n(v_d_2425, 2, 3);
    V v_ce_2429 = v_ce_243;
    V v_t_2430 = (g_heff_2ecompile_2eir_2eglobalsGo(v_body_2428));
    V v_t_2431 = (g_list_2efoldl_24f1257949983x1023832813(NTAG(TAG_Nil), v_t_2430));
    V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam1, 2, 1, (V[]){v_ce_2429}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
    v_t_2442 = heff_tag_at_n(v_ru_24x_2424_24MkPair, TAG_Cons, 2, (V[]){v_key_2427, v_t_2441});
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  return (g_prelude_2e_2b_2b(v_t_2442, v_acc_2423));
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam2(V self, V *args) {
  V v_acc_2447 = args[0];
  V v_x_2448 = args[1];
  V v_ce_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = (g_heff_2ecompile_2eemitc_2edeclOf(v_ce_243, v_x_2448));
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2447));
}
V g_heff_2ecompile_2eemitc_2emodulePart_24s1410740931x1313196866_lam3(V self, V *args) {
  V v_acc_2452 = args[0];
  V v_x_2453 = args[1];
  V v_s_244 = heff_env(self)[0];
  V v_strs_247 = heff_env(self)[1];
  V v_protos_248 = heff_env(self)[2];
  V v_lams_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2454 = ({ V a_0 = v_s_244; V a_1 = v_strs_247; V a_2 = v_protos_248; V a_3 = v_lams_249; V a_4 = v_x_2453; V r_ = (g_heff_2ecompile_2eemitc_2eownLines(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_244); heff_drop(v_strs_247); heff_drop(v_protos_248); heff_drop(v_lams_249); heff_drop(v_x_2453); r_; });
  return (g_prelude_2e_2b_2b(v_t_2454, v_acc_2452));
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eshapeH_str1, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eshapeH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eshapeH_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eshapeH(V v_ce_240, V v_sh_241, V v_rest_242) {
top: ;
  V v_t_243 = heff_get_n(heff_get_n(v_ce_240, 2, 3), 7, 11);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_sh_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_248;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = NTAG(TAG_Nil);
    }
  }
  V v_x2_249 = (g_list_2emap(heff_dup(g_intShow_get()), v_t_248));
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eshapeH_str1); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_2412}), v_rest_242});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_sh_241}), v_t_2413});
}
V g_heff_2ecompile_2eemitc_2eshapeH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eshapeH(a[0], a[1], a[2]);
}