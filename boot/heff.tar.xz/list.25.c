// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArmCovered 35323
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CDecl 45531
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Dim 16148
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_GivenBuilt 47694
#define TAG_GivenMany 26952
#define TAG_GivenOne 45466
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_HS 9084
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkArm 55352
#define TAG_MkDef 57825
#define TAG_MkEquation 38417
#define TAG_None 17785
#define TAG_NoneGiven 36085
#define TAG_RepV 61860
#define TAG_SGlobal 8650
#define TAG_ShapeRecord 31660
#define TAG_ShapeTag 9776
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Text 56194
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_def 308863
#define LBL_done 9584713
#define LBL_el 9998
#define LBL_end 310101
#define LBL_esc 310255
#define LBL_fl 10029
#define LBL_flows 298885407
#define LBL_head 9693863
#define LBL_implicit 319715269
#define LBL_imps 9731822
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_library 398066429
#define LBL_local 304503685
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_n 328
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_op 10312
#define LBL_out 319944
#define LBL_outs 9918380
#define LBL_params 951713969
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_target 1066236092
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_total 311908190
#define LBL_uses 10094739
#define LBL_version 583465758
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_module__named__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_named, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_name__args[] = {LBL_name, LBL_args};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name__span[] = {LBL_target, LBL_name, LBL_span};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2edefun_2eargsStep(V, V, V, V);
V g_heff_2ecompile_2edefun_2eargsStep_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2eargsStep_clo;
V g_heff_2ecompile_2edefun_2emarkBad(V, V);
V g_heff_2ecompile_2edefun_2emarkBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2edefun_2emarkBad_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
HeffT4 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ewaysOut(V);
V g_heff_2ecompile_2eir_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOut_clo;
HeffT2 g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(V, V, V);
V g_heff_2ecompile_2elift_2eordered(V, V);
V g_heff_2ecompile_2elift_2eordered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2eordered_clo;
V g_heff_2ecompile_2escalars_2esameLabels(V, V);
V g_heff_2ecompile_2escalars_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esameLabels_clo;
V g_heff_2ecompile_2esimplify_2egivesItBack(V, V);
V g_heff_2ecompile_2esimplify_2egivesItBack_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egivesItBack_clo;
V g_heff_2ecompile_2eworker_2eweighImp(V, V, V, V, V);
V g_heff_2ecompile_2eworker_2eweighImp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2eweighImp_clo;
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo;
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V, V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_heff_2eelab_2etoplevel_2ecoveredAbove_get(void);
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_list_2eall_24s673599783x290475791(V, V);
V g_list_2eall_24s673599783x290475791_entry(V self, V *a);
extern Clo g_list_2eall_24s673599783x290475791_clo;
V g_list_2eascending_24s946492440x1788863194(V, V, V);
V g_list_2eascending_24s946492440x1788863194_entry(V self, V *a);
extern Clo g_list_2eascending_24s946492440x1788863194_clo;
V g_list_2ecollapse_24s705464212x1327502534(V, V);
V g_list_2ecollapse_24s705464212x1327502534_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s705464212x1327502534_clo;
HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1113296953x161795409(V, V);
V g_list_2efoldl_24s1113296953x161795409_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1113296953x161795409_clo;
V g_list_2efoldl_24s1242386649x1014712668(V, V);
V g_list_2efoldl_24s1242386649x1014712668_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1242386649x1014712668_clo;
V g_list_2efoldl_24s1242386649x1014712668_24scalars(V, V, V, V, V, V);
V g_list_2efoldl_24s1242386649x1014712668_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1242386649x1014712668_24scalars_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1544308498x936697067(V, V);
V g_list_2efoldl_24s1544308498x936697067_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1544308498x936697067_clo;
V g_list_2efoldl_24s1551647072x1644392086(V, V);
V g_list_2efoldl_24s1551647072x1644392086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1551647072x1644392086_clo;
V g_list_2efoldl_24s1587638778x899913804(V, V, V, V, V);
V g_list_2efoldl_24s1587638778x899913804_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1587638778x899913804_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s2086705387x1592057803(V, V, V, V, V);
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2086705387x1592057803_clo;
V g_list_2efoldl_24s243182857x1571262076(V, V);
V g_list_2efoldl_24s243182857x1571262076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s243182857x1571262076_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s500871478x288223602(V, V, V);
V g_list_2efoldl_24s500871478x288223602_entry(V self, V *a);
extern Clo g_list_2efoldl_24s500871478x288223602_clo;
V g_list_2efoldl_24s650566757x317183241(V, V, V);
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s650566757x317183241_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1181715076x1618420649(V, V, V, V, V, V);
V g_list_2ekeepIf_24s1181715076x1618420649_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1181715076x1618420649_clo;
V g_list_2ekeepIf_24s1181715076x1618420649_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s1181715076x1618420649_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1181715076x1618420649_24dps_clo;
V g_list_2ekeepIf_24s1201185697x960477413_24dps(V, V, V);
V g_list_2ekeepIf_24s1201185697x960477413_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_24dps_clo;
V g_list_2ekeepIf_24s1950790755x1251737354_24dps(V, V, V);
V g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1950790755x1251737354_24dps_clo;
V g_list_2ekeepIf_24s735270044x1288664053(V, V, V, V);
V g_list_2ekeepIf_24s735270044x1288664053_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s735270044x1288664053_clo;
V g_list_2ekeepIf_24s735270044x1288664053_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s735270044x1288664053_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s735270044x1288664053_24dps_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f1340051005x157438530_24dps(V, V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24dps_clo;
V g_list_2emap_24f1677329353x1774765664(V, V);
V g_list_2emap_24f1677329353x1774765664_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_clo;
V g_list_2emap_24f1677329353x1774765664_24dps(V, V, V);
V g_list_2emap_24f1677329353x1774765664_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1677329353x1774765664_24dps_clo;
V g_list_2emap_24f1832335087x1608171547(V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_clo;
V g_list_2emap_24f1832335087x1608171547_24dps(V, V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_24dps_clo;
V g_list_2emap_24f783067987x1926181389_24dps(V, V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_24dps_clo;
V g_list_2emap_24f889159142x1775976195(V, V, V, V);
V g_list_2emap_24f889159142x1775976195_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_clo;
V g_list_2emap_24f889159142x1775976195_24dps(V, V, V, V, V);
V g_list_2emap_24f889159142x1775976195_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_24dps_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1193924222x1531824795_24dps(V, V, V, V);
V g_list_2emap_24s1193924222x1531824795_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_24dps_clo;
V g_list_2emap_24s1258450377x973220636_24dps(V, V);
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_24dps_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s148260373x1589531897_24dps(V, V, V, V);
V g_list_2emap_24s148260373x1589531897_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s148260373x1589531897_24dps_clo;
V g_list_2emap_24s1681408447x1763680441_24dps(V, V, V, V);
V g_list_2emap_24s1681408447x1763680441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_24dps_clo;
V g_list_2emap_24s1729297000x968708966(V);
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_clo;
V g_list_2emap_24s1729297000x968708966_24dps(V, V);
V g_list_2emap_24s1729297000x968708966_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1729297000x968708966_24dps_clo;
V g_list_2emap_24s1835183789x486277886_24dps(V, V);
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_24dps_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s319754340x1392149466(V, V, V, V);
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_clo;
V g_list_2emap_24s319754340x1392149466_24dps(V, V, V, V, V);
V g_list_2emap_24s319754340x1392149466_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_24dps_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s467798769x1763085075_24dps(V, V);
V g_list_2emap_24s467798769x1763085075_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_24dps_clo;
V g_list_2emap_24s549405518x243689326(V);
V g_list_2emap_24s549405518x243689326_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_clo;
V g_list_2emap_24s549405518x243689326_24dps(V, V);
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_24dps_clo;
V g_list_2emap_24s580776739x648604941(V);
V g_list_2emap_24s580776739x648604941_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_clo;
V g_list_2emap_24s580776739x648604941_24dps(V, V);
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_24dps_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s698037429x265256386(V);
V g_list_2emap_24s698037429x265256386_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_clo;
V g_list_2emap_24s698037429x265256386_24dps(V, V);
V g_list_2emap_24s698037429x265256386_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s698037429x265256386_24dps_clo;
V g_list_2emap_24s839307021x1449425912(V);
V g_list_2emap_24s839307021x1449425912_entry(V self, V *a);
extern Clo g_list_2emap_24s839307021x1449425912_clo;
V g_list_2emap_24s839307021x1449425912_24dps(V, V);
V g_list_2emap_24s839307021x1449425912_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s839307021x1449425912_24dps_clo;
V g_list_2emap_24s865484684x739952503(V);
V g_list_2emap_24s865484684x739952503_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_clo;
V g_list_2emap_24s865484684x739952503_24dps(V, V);
V g_list_2emap_24s865484684x739952503_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s865484684x739952503_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emerge_24s1926973041x331495419(V, V);
V g_list_2emerge_24s1926973041x331495419_entry(V self, V *a);
extern Clo g_list_2emerge_24s1926973041x331495419_clo;
V g_list_2epushRun_24s2065172444x1912428477(V, V, V, V, V);
V g_list_2epushRun_24s2065172444x1912428477_entry(V self, V *a);
extern Clo g_list_2epushRun_24s2065172444x1912428477_clo;
V g_list_2ezipWith_24s1893966264x617194987(V, V);
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2efoldl_24s1544308498x936697067_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1544308498x936697067_entry, 2, 0};

V g_list_2efoldl_24s1544308498x936697067(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 4ULL, 3);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_248 = (g_heff_2ecompile_2eir_2ewaysOut(v_t_247));
    V v_t_2414;
    switch (heff_tag_of(v_z_240)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_z_240, 0);
      V v_a_2410 = heff_field(v_z_240, 1);
      V v_ru_24z_240_24MkPair = heff_take_reuse_n(v_z_240, 3ULL, 2);
      switch (heff_tag_of(v_a_248)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_a_248, 0);
        V v_a_2412 = heff_field(v_a_248, 1);
        heff_take_n(v_a_248, 3ULL, 2);
        V v_t_2413 = (g_prelude_2e_2b_2b_24tok2(v_ru_24z_240_24MkPair, v_a_249, v_a_2411));
        v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_2413, heff_intAdd(v_a_2410, v_a_2412)});
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      break;
    }
    default: heff_nomatch(v_z_240);
    }
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1544308498x936697067_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1544308498x936697067(a[0], a[1]);
}
Clo g_list_2emap_24s1835183789x486277886_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1835183789x486277886_24dps_entry, 2, 0};

V g_list_2emap_24s1835183789x486277886_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 3), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1835183789x486277886_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1835183789x486277886_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1258450377x973220636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1258450377x973220636_24dps_entry, 2, 0};

V g_list_2emap_24s1258450377x973220636_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2426;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_TagVariant: {
        V v_t_247 = heff_field(v_x21_245, 0);
        V v_tsp_248 = heff_field(v_x21_245, 1);
        V v_args_249 = heff_field(v_x21_245, 2);
        V v_ru_24x21_245_24TagVariant = heff_take_reuse_n(v_x21_245, 7ULL, 3);
        V v_t_2410 = (g_list_2emap_24s1887874170x1747433177(v_args_249));
        v_t_2426 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_245_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_247, v_tsp_248, v_t_2410}), v_sp_246});
        break;
      }
      case TAG_BadVariant: {
        V v_e_2411 = heff_field(v_x21_245, 0);
        V v_ru_24x21_245_24BadVariant = heff_take_reuse_n(v_x21_245, 1ULL, 1);
        HeffT3 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2411));
        V v_t_2425;
        {
          V v_field_2414 = v_t_2412.f[1];
          V v_field_2415 = v_t_2412.f[2];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_c_2416 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2414, v_field_2415});
            V v_t_2419;
            switch (heff_tag_of(v_c_2416)) {
            case TAG_At: {
              V v_s_2418 = heff_dup(heff_field(v_c_2416, 1));
              v_t_2419 = v_s_2418;
              break;
            }
            default: heff_nomatch(v_c_2416);
            }
            v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2416}), v_t_2419});
          } else {
            if ((v_tag_2413 == ((int64_t)1ULL))) {
              heff_drop(v_field_2415);
              V v_i_2420 = v_field_2414;
              V v_t_2423;
              switch (heff_tag_of(v_i_2420)) {
              case TAG_At: {
                V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
                v_t_2423 = v_s_2422;
                break;
              }
              default: heff_nomatch(v_i_2420);
              }
              v_t_2425 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2420}), v_t_2423});
            } else {
              V v_t_2424 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2414, v_field_2415});
              v_t_2425 = v_t_2424;
            }
          }
        }
        v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_245_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2425}), v_sp_246});
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2427 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
    V v_u_2428 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2427));
    heff_drop(v_u_2428);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2427;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1258450377x973220636_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s549405518x243689326_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s549405518x243689326_entry, 1, 0};

V g_list_2emap_24s549405518x243689326(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_x12_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_EVar: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x12_244, 0ULL, 4);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x12_244, 0ULL, 3);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x12_244, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x12_244, 0ULL, 2);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2445 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2444, heff_hole()});
    V v_u_2446 = (g_list_2emap_24s549405518x243689326_24dps(v_xs_242, heff_dup(v_cell_2445)));
    heff_drop(v_u_2446);
    return v_cell_2445;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s549405518x243689326_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s549405518x243689326(a[0]);
}
Clo g_list_2efoldl_24s1587638778x899913804_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1587638778x899913804_entry, 5, 0};

V g_list_2efoldl_24s1587638778x899913804(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 2ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_z_243)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_z_243, 0);
      V v_a_248 = heff_field(v_z_243, 1);
      V v_ru_24z_243_24MkPair = heff_take_reuse_n(v_z_243, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_intShow(heff_dup(v_a_248)));
      v_t_2410 = heff_tag_at_n(v_ru_24z_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_a_247}), heff_intAdd(v_a_248, heff_dup(v_lit_242))});
      break;
    }
    default: heff_nomatch(v_z_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2410;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s1587638778x899913804_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1587638778x899913804(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1123370502x1982532655_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_entry, 1, 0};

V g_list_2emap_24s1123370502x1982532655(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1123370502x1982532655_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655(a[0]);
}
Clo g_list_2eall_24s673599783x290475791_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s673599783x290475791_entry, 2, 0};

V g_list_2eall_24s673599783x290475791(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2egivesItBack(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s673599783x290475791_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eall_24s673599783x290475791(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s650566757x317183241_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s650566757x317183241_entry, 3, 0};

V g_list_2efoldl_24s650566757x317183241(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    HeffT2 v_t_245 = (g_heff_2ecompile_2elift_2eliftGo_24s705580446x2046783682_24cpr(heff_dup(v_lit_240), heff_dup(v_x_243), heff_dup(heff_rfield(v_x_243, 2))));
    V v_t_2411;
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_a_248 = v_field_246;
      V v_a_249 = v_field_247;
      V v_t_2410 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_x_243, 1)), v_a_248});
      v_t_2411 = (g_heff_2ecompile_2elift_2eordered(heff_get_n(v_a_249, 0, 2), v_t_2410));
    }
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_2412;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s650566757x317183241_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s650566757x317183241(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s698037429x265256386_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s698037429x265256386_entry, 1, 0};

V g_list_2emap_24s698037429x265256386(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s698037429x265256386_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s698037429x265256386_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s698037429x265256386(a[0]);
}
Clo g_list_2efoldl_24s243182857x1571262076_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s243182857x1571262076_entry, 2, 0};

V g_list_2efoldl_24s243182857x1571262076(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s243182857x1571262076_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s243182857x1571262076(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1242386649x1014712668_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1242386649x1014712668_entry, 2, 0};

V g_list_2efoldl_24s1242386649x1014712668(V v_z_240, V v_x3_241) {
top: ;
  V v_n_242 = heff_take_field(v_z_240, 0);
  V v_flows_243 = heff_take_field(v_z_240, 1);
  V v_outs_244 = heff_take_field(v_z_240, 2);
  V v_calls_245 = heff_take_field(v_z_240, 3);
  V v_lams_246 = heff_get_n(v_z_240, 4, 5);
  return (g_list_2efoldl_24s1242386649x1014712668_24scalars(v_n_242, v_flows_243, v_outs_244, v_calls_245, v_lams_246, v_x3_241));
}
V g_list_2efoldl_24s1242386649x1014712668_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1242386649x1014712668(a[0], a[1]);
}
V g_list_2efoldl_24s500871478x288223602_lam0(V self, V *args);
Clo g_list_2efoldl_24s500871478x288223602_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s500871478x288223602_entry, 3, 0};

V g_list_2efoldl_24s500871478x288223602(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_strict_245 = heff_dup(v_lit_240);
    V v_st_246 = v_z_241;
    V v_c_247 = heff_dup(v_x_243);
    HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_246, 1), heff_rfield(v_c_247, 0)));
    V v_t_2412;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_2410;
        heff_drop(v_x_2411);
        v_t_2412 = (g_heff_2ecompile_2edefun_2emarkBad(heff_dup(heff_rfield(v_c_247, 0)), heff_dup(v_st_246)));
      } else {
        heff_drop(v_field_2410);
        v_t_2412 = heff_dup(v_st_246);
      }
    }
    HeffT2 v_t_2413 = ({ V b_0 = heff_get_n(v_st_246, 0, 6); V a_1 = heff_rfield(v_c_247, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2419;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      V v_t_2417;
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_x_2416 = v_field_2415;
        v_t_2417 = v_x_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = heff_dup(g_std_2eordmap_2eempty_get());
      }
      V v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_t_2417); r_; });
      v_t_2419 = (g_list_2emap_24s1415906091x1371825187(v_t_2418));
    }
    V v_t_2438 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s500871478x288223602_lam0, 2, 2, (V[]){v_strict_245, v_c_247}); V a_1 = v_t_2412; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_t_2438;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s500871478x288223602_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s500871478x288223602(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_list_2efoldl_24s500871478x288223602_lam0(V self, V *args) {
  V v_s_2420 = args[0];
  V v_l_2421 = args[1];
  V v_strict_245 = heff_env(self)[0];
  V v_c_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_strict_2422 = v_strict_245;
  V v_c_2423 = v_c_247;
  V v_args_2424 = heff_take_field(v_c_2423, 1);
  V v_head_2425 = heff_get_n(v_c_2423, 0, 2);
  V v_st_2426 = heff_dup(v_s_2420);
  V v_l_2427 = heff_dup(v_l_2421);
  HeffT2 v_t_2428 = ({ V b_0 = heff_get_n(v_s_2420, 5, 6); V a_1 = v_l_2421; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_l_2421); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_lam_2431 = v_field_2430;
      HeffT2 v_t_2432 = ({ V a_0 = heff_rfield(v_st_2426, 3); V a_1 = v_l_2427; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_l_2427); r_; });
      V v_t_2436;
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        v_t_2436 = heff_bool(((v_tag_2433 == ((int64_t)0ULL)) && ({ V v_x_2435 = heff_dup(v_field_2434); int c_ = 1; heff_drop(v_x_2435); c_; })));
        heff_drop(v_field_2434);
      }
      V v_t_2437;
      if (((heff_dup(v_t_2436) == NTAG(TAG_True)) || ((heff_dup(v_strict_2422) == NTAG(TAG_True)) && ({ V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2424)); int c_ = ({ V v_t_2440 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_lam_2431, 0))); int c_ = heff_intLt_c_lent(v_t_2439, v_t_2440, 0); heff_drop(v_t_2440); c_; }); heff_drop(v_t_2439); c_; })))) {
        heff_drop(v_t_2436);
        v_t_2437 = (g_heff_2ecompile_2edefun_2emarkBad(v_head_2425, v_st_2426));
      } else {
        heff_drop(v_head_2425);
        heff_drop(v_t_2436);
        v_t_2437 = v_st_2426;
      }
      return ({ V a_0 = v_strict_2422; V a_1 = v_args_2424; V a_2 = heff_get_n(v_lam_2431, 0, 2); V a_3 = v_t_2437; V r_ = (g_heff_2ecompile_2edefun_2eargsStep(a_0, a_1, a_2, a_3)); heff_drop(v_strict_2422); heff_drop(v_args_2424); r_; });
    } else {
      heff_drop(v_strict_2422);
      heff_drop(v_args_2424);
      heff_drop(v_l_2427);
      heff_drop(v_field_2430);
      return (g_heff_2ecompile_2edefun_2emarkBad(v_head_2425, v_st_2426));
    }
  }
}
Clo g_list_2emap_24s1729297000x968708966_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1729297000x968708966_entry, 1, 0};

V g_list_2emap_24s1729297000x968708966(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_el_244 = heff_get_n(v_x_241, 2, 5);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, v_el_244}), heff_hole()});
    V v_u_246 = (g_list_2emap_24s1729297000x968708966_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1729297000x968708966_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1729297000x968708966(a[0]);
}
Clo g_list_2efoldl_24s1551647072x1644392086_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1551647072x1644392086_entry, 2, 0};

V g_list_2efoldl_24s1551647072x1644392086(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2424;
    switch (heff_tag_of(v_x_242)) {
    case TAG_GivenBuilt: {
      V v_g1_244 = heff_field(v_x_242, 0);
      V v_g2_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_NoneGiven: {
        v_t_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_GivenOne, 2, (V[]){v_g1_244, v_g2_245});
        break;
      }
      case TAG_GivenOne: {
        V v_sh_246 = heff_field(v_z_240, 0);
        V v_ts_247 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_sh_248 = v_sh_246;
        V v_ts_249 = v_ts_247;
        V v_sh2_2410 = v_g1_244;
        V v_ts2_2411 = v_g2_245;
        switch (heff_tag_of(v_sh_248)) {
        case TAG_ShapeRecord: {
          V v_ls_2412 = heff_dup(heff_field(v_sh_248, 0));
          switch (heff_tag_of(v_sh2_2410)) {
          case TAG_ShapeRecord: {
            V v_ls2_2413 = heff_field(v_sh2_2410, 0);
            heff_take_n(v_sh2_2410, 1ULL, 1);
            V v_t_2414 = ({ V a_0 = v_ls_2412; V a_1 = v_ls2_2413; V r_ = (g_heff_2ecompile_2escalars_2esameLabels(a_0, a_1)); heff_drop(v_ls_2412); heff_drop(v_ls2_2413); r_; });
            if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
              heff_drop(v_t_2414);
              V v_t_2415 = (g_list_2ezipWith_24s1893966264x617194987(v_ts_249, v_ts2_2411));
              v_t_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_GivenOne, 2, (V[]){v_sh_248, v_t_2415});
            } else {
              heff_drop_cell(v_ru_24x3_241_24Cons, 2);
              heff_drop_tag(v_sh_248, 1);
              heff_drop(v_ts_249);
              heff_drop(v_ts2_2411);
              heff_drop(v_t_2414);
              v_t_2424 = NTAG(TAG_GivenMany);
            }
            break;
          }
          case TAG_ShapeTag: {
            heff_take_n(v_sh2_2410, 0ULL, 2);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop_tag(v_sh_248, 1);
            heff_drop(v_ts_249);
            heff_drop(v_ts2_2411);
            heff_drop(v_ls_2412);
            v_t_2424 = NTAG(TAG_GivenMany);
            break;
          }
          default: heff_nomatch(v_sh2_2410);
          }
          break;
        }
        case TAG_ShapeTag: {
          V v_t_2418 = heff_dup(heff_field(v_sh_248, 0));
          V v_k_2419 = heff_dup(heff_field(v_sh_248, 1));
          switch (heff_tag_of(v_sh2_2410)) {
          case TAG_ShapeRecord: {
            heff_take_n(v_sh2_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            heff_drop_tag(v_sh_248, 2);
            heff_drop(v_ts_249);
            heff_drop(v_ts2_2411);
            heff_drop(v_t_2418);
            heff_drop(v_k_2419);
            v_t_2424 = NTAG(TAG_GivenMany);
            break;
          }
          case TAG_ShapeTag: {
            V v_t2_2421 = heff_field(v_sh2_2410, 0);
            V v_k2_2422 = heff_field(v_sh2_2410, 1);
            heff_take_n(v_sh2_2410, 3ULL, 2);
            if ((heff_strEq_c_lent(v_t_2418, v_t2_2421, 0) && heff_intEq_c_lent(v_k_2419, v_k2_2422, 0))) {
              heff_drop(v_t_2418);
              heff_drop(v_k_2419);
              heff_drop(v_t2_2421);
              heff_drop(v_k2_2422);
              V v_t_2423 = (g_list_2ezipWith_24s1893966264x617194987(v_ts_249, v_ts2_2411));
              v_t_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_GivenOne, 2, (V[]){v_sh_248, v_t_2423});
            } else {
              heff_drop_cell(v_ru_24x3_241_24Cons, 2);
              heff_drop_tag(v_sh_248, 2);
              heff_drop(v_ts_249);
              heff_drop(v_ts2_2411);
              heff_drop(v_t_2418);
              heff_drop(v_k_2419);
              heff_drop(v_t2_2421);
              heff_drop(v_k2_2422);
              v_t_2424 = NTAG(TAG_GivenMany);
            }
            break;
          }
          default: heff_nomatch(v_sh2_2410);
          }
          break;
        }
        default: heff_nomatch(v_sh_248);
        }
        break;
      }
      case TAG_GivenMany: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_g1_244);
        heff_drop(v_g2_245);
        v_t_2424 = NTAG(TAG_GivenMany);
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    case TAG_GivenSame: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2424 = v_z_240;
      break;
    }
    case TAG_GivenOther: {
      heff_drop(v_z_240);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_t_2424 = NTAG(TAG_GivenMany);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2424;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1551647072x1644392086_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1551647072x1644392086(a[0], a[1]);
}
Clo g_list_2efoldl_24s2086705387x1592057803_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2086705387x1592057803_entry, 5, 0};

V g_list_2efoldl_24s2086705387x1592057803(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_244, 0);
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_facts_247 = heff_dup(v_lit_240);
    V v_defs_248 = heff_dup(v_lit_241);
    V v_sg_249 = heff_dup(v_lit_242);
    V v_acc_2410 = v_z_243;
    V v_k_2411 = heff_dup(v_x_245);
    HeffT2 v_t_2412 = ({ V a_0 = v_defs_248; V a_1 = v_k_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_defs_248); r_; });
    V v_t_2477;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_d_2415 = v_field_2414;
        V v_t_2416 = heff_dup(heff_rfield(v_d_2415, 2));
        switch (heff_tag_of(v_t_2416)) {
        case TAG_EVar: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EGlobal: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_t_2416, 0ULL, 2);
          V v_imps_2421 = heff_dup(heff_rfield(v_acc_2410, 1));
          V v_d_2422 = v_d_2415;
          HeffT2 v_t_2423 = ({ V a_0 = v_imps_2421; V a_1 = heff_rfield(v_d_2422, 0); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_imps_2421); r_; });
          V v_t_2441;
          {
            V v_field_2425 = v_t_2423.f[1];
            int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
            if ((v_tag_2424 == ((int64_t)0ULL))) {
              heff_drop_rec(v_d_2422, 3);
              V v_md_2426 = v_field_2425;
              v_t_2441 = v_md_2426;
            } else {
              heff_drop(v_field_2425);
              HeffT2 v_t_2427 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), heff_take_field(v_d_2422, 2)));
              {
                V v_field_2428 = v_t_2427.f[0];
                V v_field_2429 = v_t_2427.f[1];
                V v_b_2430 = v_field_2428;
                V v_n_2431 = v_field_2429;
                V v_t_2432 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
                V v_t_2433 = ({ V rv_2 = v_b_2430; V rr_ = heff_rec_reuse_nf(v_d_2422, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
                HeffT4 v_t_2434 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2432, v_t_2433, v_n_2431));
                {
                  V v_field_2435 = v_t_2434.f[0];
                  V v_field_2436 = v_t_2434.f[1];
                  V v_field_2437 = v_t_2434.f[2];
                  V v_field_2438 = v_t_2434.f[3];
                  V v_x_2439 = heff_tag_n(TAG_MkDef, 3, (V[]){v_field_2435, v_field_2436, v_field_2437});
                  V v_y_2440 = v_field_2438;
                  heff_drop(v_y_2440);
                  v_t_2441 = v_x_2439;
                }
              }
            }
          }
          v_t_2477 = (g_heff_2ecompile_2eworker_2eweighImp(v_facts_247, v_sg_249, v_acc_2410, v_k_2411, v_t_2441));
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_ELet: {
          heff_take_n(v_t_2416, 0ULL, 3);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_ERecord: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EProj: {
          heff_take_n(v_t_2416, 0ULL, 4);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_t_2416, 0ULL, 3);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EPrim: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EPrimCall: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_ECall: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EStr: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EBytes: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EFixed: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EFloat32: {
          heff_take_na(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EAbandon: {
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EBool: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_ESet: {
          heff_take_n(v_t_2416, 0ULL, 3);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EValues: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        case TAG_EFix: {
          heff_take_n(v_t_2416, 0ULL, 2);
          heff_drop(v_facts_247);
          heff_drop(v_sg_249);
          heff_drop(v_k_2411);
          heff_drop_rec(v_d_2415, 3);
          v_t_2477 = v_acc_2410;
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
      } else {
        heff_drop(v_facts_247);
        heff_drop(v_sg_249);
        heff_drop(v_k_2411);
        heff_drop(v_field_2414);
        v_t_2477 = v_acc_2410;
      }
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2477;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s2086705387x1592057803_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_list_2efoldl_24s2086705387x1592057803(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_list_2emap_24s319754340x1392149466_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s319754340x1392149466_entry, 4, 0};

V g_list_2emap_24s319754340x1392149466(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_a_247 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 3ULL, 2);
      if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_a_246, v_lit_241, v_lit_242, 1))) {
        v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_a_247});
      } else {
        heff_drop(v_a_247);
        v_t_248 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s319754340x1392149466_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24s319754340x1392149466(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(heff_get_n(v_t_246, 0, 2), 0, 7);
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s839307021x1449425912_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s839307021x1449425912_entry, 1, 0};

V g_list_2emap_24s839307021x1449425912(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ArmCovered, 2, (V[]){v_x_241, heff_dup(g_heff_2eelab_2etoplevel_2ecoveredAbove_get())}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s839307021x1449425912_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s839307021x1449425912_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s839307021x1449425912(a[0]);
}
Clo g_list_2emap_24s265594371x763318798_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_24dps_entry, 2, 0};

V g_list_2emap_24s265594371x763318798_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_key_245 = heff_get_n(v_x_242, 1, 4);
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){v_name_244, heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_245})});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s467798769x1763085075_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s467798769x1763085075_entry, 1, 0};

V g_list_2emap_24s467798769x1763085075(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s467798769x1763085075_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s467798769x1763085075(a[0]);
}
V g_list_2efoldl_24s44351024x1408738471_lam0(V self, V *args);
Clo g_list_2efoldl_24s44351024x1408738471_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s44351024x1408738471_entry, 2, 0};

V g_list_2efoldl_24s44351024x1408738471(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_x1_244 = heff_dup(v_x_242);
    V v_a_2457;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_At: {
      V v_x11_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24At = heff_take_reuse_n(v_x1_244, 1ULL, 2);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_DeclEquations: {
        V v_ty_2410 = heff_field(v_x11_245, 3);
        V v_eqs_2411 = heff_field(v_x11_245, 4);
        heff_take_n(v_x11_245, 24ULL, 5);
        V v_a_2412 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_2410)));
        V v_binders_2413 = heff_take_field(v_a_2412, 0);
        V v_uses_2414 = heff_get_n(v_a_2412, 1, 2);
        V v_b_2437 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s44351024x1408738471_lam0, 2, 1, (V[]){v_ty_2410}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_2411); r_; });
        V v_binders_2438 = heff_take_field(v_b_2437, 0);
        V v_uses_2439 = heff_get_n(v_b_2437, 1, 2);
        V v_t_2440 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_244_24At, v_binders_2413, v_binders_2438));
        V v_t_2441 = (g_prelude_2e_2b_2b(v_uses_2414, v_uses_2439));
        v_a_2457 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2440, v_t_2441});
        break;
      }
      case TAG_DeclDefine: {
        V v_ps_2444 = heff_field(v_x11_245, 2);
        V v_ty_2445 = heff_field(v_x11_245, 3);
        V v_body_2446 = heff_field(v_x11_245, 4);
        heff_take_n(v_x11_245, 28ULL, 5);
        heff_drop_cell(v_ru_24x1_244_24At, 2);
        v_a_2457 = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(v_ty_2445, v_body_2446, NTAG(TAG_Nil), v_ps_2444));
        break;
      }
      case TAG_DeclTheory: {
        V v_ps_2449 = heff_field(v_x11_245, 2);
        V v_body_2450 = heff_field(v_x11_245, 3);
        heff_take_n(v_x11_245, 12ULL, 4);
        heff_drop_cell(v_ru_24x1_244_24At, 2);
        v_a_2457 = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(v_body_2450, NTAG(TAG_Nil), v_ps_2449));
        break;
      }
      case TAG_DeclPrimitive: {
        V v_t_2453 = heff_field(v_x11_245, 2);
        heff_take_n(v_x11_245, 4ULL, 3);
        heff_drop_cell(v_ru_24x1_244_24At, 2);
        v_a_2457 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_t_2453));
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24At, 2);
        v_a_2457 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_DeclWatch: {
        V v_e_2456 = heff_field(v_x11_245, 0);
        heff_take_n(v_x11_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24At, 2);
        v_a_2457 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_e_2456));
        break;
      }
      default: heff_nomatch(v_x11_245);
      }
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_binders_2458 = heff_take_field(v_a_2457, 0);
    V v_uses_2459 = heff_get_n(v_a_2457, 1, 2);
    V v_t_2460 = (g_prelude_2e_2b_2b(heff_take_field(v_z_240, 0), v_binders_2458));
    V v_t_2461 = (g_prelude_2e_2b_2b(heff_get_n(v_z_240, 1, 2), v_uses_2459));
    V t_0 = heff_rec_n(2, shape_binders__uses, (V[]){v_t_2460, v_t_2461});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s44351024x1408738471(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s44351024x1408738471_lam0(V self, V *args) {
  V v_acc_2415 = args[0];
  V v_eq_2416 = args[1];
  V v_ty_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_binders_2417 = heff_take_field(v_acc_2415, 0);
  V v_uses_2418 = heff_get_n(v_acc_2415, 1, 2);
  V v_env_2419 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_2410));
  V v_x3_2420 = v_eq_2416;
  V v_b_2432;
  switch (heff_tag_of(v_x3_2420)) {
  case TAG_At: {
    V v_x31_2421 = heff_field(v_x3_2420, 0);
    V v_ru_24x3_2420_24At = heff_take_reuse_n(v_x3_2420, 1ULL, 2);
    switch (heff_tag_of(v_x31_2421)) {
    case TAG_MkEquation: {
      V v_ps_2425 = heff_field(v_x31_2421, 2);
      V v_rhs_2426 = heff_field(v_x31_2421, 3);
      heff_take_n(v_x31_2421, 12ULL, 4);
      V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2425));
      V v_bs_2428 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2427); r_; });
      V v_env_2429 = (g_list_2efoldl_24s1370882877x364361272(v_env_2419, heff_dup(v_bs_2428)));
      V v_b_2430 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(v_env_2429, v_rhs_2426));
      V v_t_2431 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_2420_24At, v_bs_2428, heff_take_field(v_b_2430, 0)));
      v_b_2432 = ({ V rv_0 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_b_2430, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2421);
    }
    break;
  }
  default: heff_nomatch(v_x3_2420);
  }
  V v_binders_2433 = heff_take_field(v_b_2432, 0);
  V v_uses_2434 = heff_get_n(v_b_2432, 1, 2);
  V v_t_2435 = (g_prelude_2e_2b_2b(v_binders_2417, v_binders_2433));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_uses_2418, v_uses_2434));
  return heff_rec_n(2, shape_binders__uses, (V[]){v_t_2435, v_t_2436});
}
Clo g_list_2emap_24s148260373x1589531897_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s148260373x1589531897_24dps_entry, 4, 0};

V g_list_2emap_24s148260373x1589531897_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_rec_n(3, shape_key__member__local, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_a_247 = heff_take_field(v_x_244, 0);
    V v_a_248 = heff_intSub(heff_dup(heff_rfield(v_x_244, 1)), heff_strLength_lent(v_lit_241, 0));
    V v_t_249;
    if (heff_intLe_c_lent(v_a_247, v_a_248, 0)) {
      heff_drop(v_a_247);
      v_t_249 = v_a_248;
    } else {
      heff_drop(v_a_248);
      v_t_249 = v_a_247;
    }
    V v_t_2410 = ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_x_244, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_target__name__span, (V[]){v_t_246, heff_dup(v_lit_241), v_t_2410}), heff_hole()});
    V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s148260373x1589531897_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s148260373x1589531897_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s1950790755x1251737354_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1950790755x1251737354_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_245)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1950790755x1251737354_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1950790755x1251737354_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1113296953x161795409_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1113296953x161795409_entry, 2, 0};

V g_list_2efoldl_24s1113296953x161795409(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2422;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      heff_take_n(v_x2_244, 1ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_StmtBind: {
        V v_e_249 = heff_field(v_x21_245, 2);
        heff_take_n(v_x21_245, 4ULL, 3);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2422 = ({ V a_0 = v_e_249; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_e_249); r_; });
        break;
      }
      case TAG_StmtLet: {
        V v_e_2411 = heff_field(v_x21_245, 1);
        heff_take_n(v_x21_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2422 = ({ V a_0 = v_e_2411; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_e_2411); r_; });
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2412 = heff_field(v_x21_245, 0);
        heff_take_n(v_x21_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2422 = ({ V a_0 = v_e_2412; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_e_2412); r_; });
        break;
      }
      case TAG_StmtLetMut: {
        V v_e_2415 = heff_field(v_x21_245, 2);
        heff_take_n(v_x21_245, 4ULL, 3);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_2422 = ({ V a_0 = v_e_2415; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_e_2415); r_; });
        break;
      }
      case TAG_StmtLetElse: {
        V v_e_2417 = heff_field(v_x21_245, 1);
        V v_ss_2418 = heff_field(v_x21_245, 2);
        heff_take_n(v_x21_245, 6ULL, 3);
        V v_t_2419 = ({ V a_0 = v_e_2417; V r_ = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a_0)); heff_drop(v_e_2417); r_; });
        V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_2418));
        V v_t_2421 = (g_list_2efoldl_24s1113296953x161795409(NTAG(TAG_Nil), v_t_2420));
        v_t_2422 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_241_24Cons, v_t_2419, v_t_2421));
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2422, v_z_240));
    V t_0 = v_t_2423;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1113296953x161795409_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1113296953x161795409(a[0], a[1]);
}
Clo g_list_2eascending_24s946492440x1788863194_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s946492440x1788863194_entry, 3, 0};

V g_list_2eascending_24s946492440x1788863194(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 7);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_242, 0);
    V v_ys_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_intLe_c(heff_get_n(v_x_240, 2, 7), heff_dup(heff_rfield(v_y_244, 2)))) {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    } else {
      V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_244, v_ys_245})});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s946492440x1788863194_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s946492440x1788863194(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1181715076x1618420649_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1181715076x1618420649_entry, 6, 0};

V g_list_2ekeepIf_24s1181715076x1618420649(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_a_248 = heff_dup(heff_rfield(v_x_246, 1));
    V v_t_249 = ({ V a_0 = v_a_248; V a_1 = v_lit_240; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_a_248, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_248); r_; });
    V v_t_2410 = (g_list_2emap_24s649333309x1802289391(v_t_249));
    V v_a_2411 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2410));
    switch (heff_tag_of(v_a_2411)) {
    case TAG_Nil: {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_2413 = (g_list_2ekeepIf_24s1181715076x1618420649_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_Cons: {
      V v_a_2414 = heff_field(v_a_2411, 0);
      heff_take_n(v_a_2411, 1ULL, 2);
      if (heff_strEq_c_lent(v_a_2414, v_lit_244, 1)) {
        V v_cell_2416 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
        V v_u_2417 = (g_list_2ekeepIf_24s1181715076x1618420649_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2416)));
        heff_drop(v_u_2417);
        return v_cell_2416;
      } else {
        heff_drop_rec(v_x_246, 2);
        heff_drop_cell(v_ru_24x2_245_24Cons, 2);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_lit_243;
        V t_4 = v_lit_244;
        V t_5 = v_xs_247;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_lit_243 = t_3;
        v_lit_244 = t_4;
        v_x2_245 = t_5;
        goto top;
      }
    }
    default: return heff_nomatch(v_a_2411);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s1181715076x1618420649_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V r = g_list_2ekeepIf_24s1181715076x1618420649(a0, a[1], a2, a3, a4, a[5]); heff_drop(a0); heff_drop(a2); heff_drop(a3); heff_drop(a4); return r;
}
Clo g_list_2emap_24s1681408447x1763680441_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1681408447x1763680441_24dps_entry, 4, 0};

V g_list_2emap_24s1681408447x1763680441_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      V v_t_246 = heff_strAppend(heff_take_field(v_x_244, 4), heff_dup(v_lit_241));
      v_t_247 = ({ V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_244, 239ULL, 8, shape_module__named__path__shown__source__renames__implicit__library, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      v_t_247 = v_x_244;
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1681408447x1763680441_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1681408447x1763680441_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2ecollapse_24s705464212x1327502534_clo = {{0x80000000u, K_CLO, 0}, g_list_2ecollapse_24s705464212x1327502534_entry, 2, 0};

V g_list_2ecollapse_24s705464212x1327502534(V v_run_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_run_240;
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkPair: {
      V v_below_245 = heff_field(v_x31_242, 1);
      V v_t_246 = (g_list_2emerge_24s1926973041x331495419(heff_dup(v_below_245), v_run_240));
      V t_0 = v_t_246;
      V t_1 = v_rest_243;
      v_run_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2ecollapse_24s705464212x1327502534_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2ecollapse_24s705464212x1327502534(a[0], a1); heff_drop(a1); return r;
}
V g_list_2epushRun_24s2065172444x1912428477_lam0(V self, V *args);
Clo g_list_2epushRun_24s2065172444x1912428477_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s2065172444x1912428477_entry, 5, 0};

V g_list_2epushRun_24s2065172444x1912428477(V v_lit_240, V v_lit_241, V v_k_242, V v_run_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_245 = heff_field(v_x4_244, 0);
    V v_rest_246 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_MkPair: {
      V v_j_247 = heff_field(v_x41_245, 0);
      V v_below_248 = heff_field(v_x41_245, 1);
      V v_ru_24x41_245_24MkPair = heff_take_reuse_n(v_x41_245, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_247, v_k_242, 0)) {
        heff_drop_cell(v_ru_24x4_244_24Cons, 2);
        heff_drop(v_j_247);
        heff_drop_cell(v_ru_24x41_245_24MkPair, 2);
        V v_t_2412 = (g_list_2emerge(heff_clo_n(g_list_2epushRun_24s2065172444x1912428477_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_below_248, v_run_243));
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = heff_intAdd(v_k_242, MK_INT(1LL));
        V t_3 = v_t_2412;
        V t_4 = v_rest_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_k_242 = t_2;
        v_run_243 = t_3;
        v_x4_244 = t_4;
        goto top;
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        V v_t_2413 = heff_tag_at_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_245_24MkPair, TAG_MkPair, 2, (V[]){v_j_247, v_below_248}), v_rest_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_run_243}), v_t_2413});
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2epushRun_24s2065172444x1912428477_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s2065172444x1912428477(a[0], a[1], a[2], a[3], a[4]);
}
V g_list_2epushRun_24s2065172444x1912428477_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2411 = heff_strCompare(heff_get_n(v_a_249, 0, 14), heff_get_n(v_a_2410, 0, 14));
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2411, v_lit_240, 0) || heff_intEq_c_lent(v_a_2411, v_lit_241, 0)));
  heff_drop(v_lit_240);
  heff_drop(v_lit_241);
  heff_drop(v_a_2411);
  return v_ret_24bool;
}
Clo g_list_2emap_24s1193924222x1531824795_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1193924222x1531824795_24dps_entry, 4, 0};

V g_list_2emap_24s1193924222x1531824795_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_240))) {
      v_t_246 = ({ V rv_1 = heff_dup(v_lit_240); V rv_2 = heff_dup(v_lit_241); V rr_ = heff_rec_reuse_nf(v_x_244, 1ULL, 3, shape_name__path__version, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    } else {
      v_t_246 = v_x_244;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1193924222x1531824795_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1193924222x1531824795_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s580776739x648604941_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580776739x648604941_entry, 1, 0};

V g_list_2emap_24s580776739x648604941(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_args_247 = heff_field(v_x11_243, 2);
        heff_take_n(v_x11_243, 5ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__args, (V[]){v_t_245, v_args_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s580776739x648604941_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580776739x648604941_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580776739x648604941(a[0]);
}
Clo g_list_2ekeepIf_24s735270044x1288664053_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s735270044x1288664053_entry, 4, 0};

V g_list_2ekeepIf_24s735270044x1288664053(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_244)) {
    case TAG_JNull: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_JBool: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_JInt: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_JFloat: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_JString: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_JArray: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_JObject: {
      V v_a_2411 = heff_dup(heff_field(v_x_244, 0));
      HeffT2 v_t_2412 = ({ V a_0 = v_lit_240; V a_1 = v_a_2411; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_a_2411); r_; });
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_a_2415 = v_field_2414;
          V v_t_2418;
          switch (heff_tag_of(v_a_2415)) {
          case TAG_MkPair: {
            V v_a_2417 = heff_field(v_a_2415, 1);
            heff_take_n(v_a_2415, 2ULL, 2);
            v_t_2418 = v_a_2417;
            break;
          }
          default: heff_nomatch(v_a_2415);
          }
          switch (heff_tag_of(v_t_2418)) {
          case TAG_JNull: {
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          case TAG_JString: {
            V v_a_2422 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 1);
            v_t_2425 = heff_bool((heff_strEq_c_lent(v_a_2422, v_lit_241, 0) || heff_strEq_c_lent(v_a_2422, v_lit_242, 0)));
            heff_drop(v_a_2422);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2418);
          }
        } else {
          heff_drop(v_field_2414);
          v_t_2425 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      V v_cell_2426 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_2427 = (g_list_2ekeepIf_24s735270044x1288664053_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2426)));
      heff_drop(v_u_2427);
      return v_cell_2426;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_2425);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s735270044x1288664053_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s735270044x1288664053(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1201185697x960477413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1201185697x960477413_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1201185697x960477413_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_dup(heff_field(v_x_243, 1));
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_intLe_c_lent(v_t_247, v_lit_240, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1201185697x960477413_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1201185697x960477413_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s865484684x739952503_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s865484684x739952503_entry, 1, 0};

V g_list_2emap_24s865484684x739952503(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){v_x_241, NTAG(TAG_Dim)});
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s865484684x739952503_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s865484684x739952503_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s865484684x739952503(a[0]);
}
Clo g_list_2emap_24f889159142x1775976195_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f889159142x1775976195_entry, 4, 0};

V g_list_2emap_24f889159142x1775976195(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Nil);
  } else {
    V v_t_244;
    if (heff_intEq_c_lent(v_a_242, v_lit_240, 0)) {
      v_t_244 = heff_dup(v_lit_241);
    } else {
      v_t_244 = NTAG(TAG_RepV);
    }
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24f889159142x1775976195_24dps(v_lit_240, v_lit_241, heff_box_word((heff_unbox_word(v_a_242) + ((int64_t)1ULL))), v_b_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
}
V g_list_2emap_24f889159142x1775976195_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f889159142x1775976195(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1677329353x1774765664_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1677329353x1774765664_entry, 2, 0};

V g_list_2emap_24f1677329353x1774765664(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_x_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, heff_dup(v_lit_240)}), heff_hole()});
    V v_u_248 = (g_list_2emap_24f1677329353x1774765664_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1677329353x1774765664_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1677329353x1774765664(a[0], a[1]);
}
Clo g_list_2emap_24f783067987x1926181389_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f783067987x1926181389_24dps_entry, 6, 0};

V g_list_2emap_24f783067987x1926181389_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_a_243, V v_b_244, V v_d_245) {
top: ;
  if (heff_intLt_c_lent(v_b_244, v_a_243, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_a_243));
    V v_cell_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_t_246, heff_dup(v_lit_242)), heff_hole()});
    V v_u_248 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = heff_intAdd(v_a_243, MK_INT(1LL));
    V t_4 = v_b_244;
    V t_5 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_a_243 = t_3;
    v_b_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
}
V g_list_2emap_24f783067987x1926181389_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f783067987x1926181389_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1229912102x1467950109_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_24dps_entry, 3, 0};

V g_list_2emap_24f1229912102x1467950109_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_t_245 = (g_list_2emap_24s2029035892x1571084362_24tok2(v_ru_24x2_241_24Cons, v_xs_244));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_245);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2efoldl_24f1160581125x508466714_str0, 1, "\012");
HEFF_LIT(g_list_2efoldl_24f1160581125x508466714_str1, 1, "\012");
HEFF_LIT(g_list_2efoldl_24f1160581125x508466714_str2, 0, "");
HEFF_LIT(g_list_2efoldl_24f1160581125x508466714_str3, 0, "");
HEFF_LIT(g_list_2efoldl_24f1160581125x508466714_str4, 1, " ");
Clo g_list_2efoldl_24f1160581125x508466714_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1160581125x508466714_entry, 2, 0};

V g_list_2efoldl_24f1160581125x508466714(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_c_244 = heff_dup(v_x_242);
    V v_x2_245 = ({ V a_0 = v_c_244; V b_1 = ((V)&g_list_2efoldl_24f1160581125x508466714_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2efoldl_24f1160581125x508466714_str1), v_c_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_c_244); heff_drop(b_1); r_; });
    V v_s_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_s_248 = ((V)&g_list_2efoldl_24f1160581125x508466714_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_s_248 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249;
    if (heff_strEq_c_lent(v_s_248, ((V)&g_list_2efoldl_24f1160581125x508466714_str3), 2)) {
      heff_drop(v_s_248);
      v_t_249 = NTAG(TAG_None);
    } else {
      v_t_249 = heff_tag_n(TAG_Text, 1, (V[]){v_s_248});
    }
    V v_x_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_list_2efoldl_24f1160581125x508466714_str4)})));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_2410));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1160581125x508466714(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f1340051005x157438530_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1340051005x157438530_24dps_entry, 5, 0};

V g_list_2emap_24f1340051005x157438530_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_strSlice(heff_dup(v_x_245), heff_dup(v_lit_241), heff_strLength_lent(v_lit_242, 0));
    if (heff_strEq_c_lent(v_t_247, v_lit_242, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_245, heff_dup(v_lit_240)), heff_hole()});
      V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1340051005x157438530_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2emap_24f1340051005x157438530_24dps(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1832335087x1608171547_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1832335087x1608171547_entry, 4, 0};

V g_list_2emap_24f1832335087x1608171547(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242))) {
      V v_t_247;
      if (heff_intEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
        V v_t_246 = heff_intAdd(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
        v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_nf(v_x_244, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        v_t_247 = v_x_244;
      }
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2emap_24f1832335087x1608171547_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 5);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1832335087x1608171547_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1832335087x1608171547(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f556306710x2087456230_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f556306710x2087456230_entry, 4, 0};

V g_list_2efoldl_24f556306710x2087456230(V v_lit_240, V v_z_241, V v_f_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_f_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_242), 1, (V[]){heff_dup(v_x_244)}));
    heff_drop(v_x_246);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_f_242;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_f_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24f556306710x2087456230(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}