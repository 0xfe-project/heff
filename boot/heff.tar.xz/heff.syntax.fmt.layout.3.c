// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkChain 10459
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_ifLink 754803170
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_ops 319788
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2echain(V);
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str1, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_x1_245;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_x1_245 = NTAG(TAG_Nil);
  } else {
    V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_x1_245 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      v_x1_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
  }
  V v_t_2413;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    V v_t_2411;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
      v_t_2411 = NTAG(TAG_Nil);
    } else {
      V v_x2_249 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
    }
    V v_t_2412 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2411); r_; });
    v_t_2413 = (g_std_2edoc_2e_3c_3e(v_t_2412, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x2_2414 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 2)));
  V v_t_2416;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2417 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_s_2418 = heff_take_field(v_t_241, 2);
  V v_t_2420;
  if (heff_strEq_c_lent(v_s_2418, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2418);
    v_t_2420 = NTAG(TAG_None);
  } else {
    v_t_2420 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2418});
  }
  V v_t_2426;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2426 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    V v_t_2422 = ({ V a_0 = heff_get_n(v_t_241, 7, 9); V b_1 = heff_get_n(v_env_240, 3, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2422)) {
    case TAG_Nothing: {
      v_t_2426 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_c_2423 = heff_field(v_t_2422, 0);
      V v_ru_24t_2422_24Just = heff_take_reuse_n(v_t_2422, 1ULL, 1);
      V v_t_2424 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(v_c_2423));
      V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2424, heff_dup(g_std_2edoc_2ehardline_get())));
      v_t_2426 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_2422_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str1)}), v_t_2425));
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
  }
  V v_t_2427 = (g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2426));
  V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2427));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2428);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_dup(heff_rfield(v_c_242, 0))));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2476 = heff_field(v_e_240, 3);
    V t_0 = v_body_2476;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2439 = heff_field(v_e_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2439, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2echain_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2echain(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EParen: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Named: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Tup: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Seg: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Braces: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Update: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EUSet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_InstB: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFSet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFDefault: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Sum: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECon: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EField: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ENeg: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_App: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Op: {
    V v_a_2454 = heff_field(v_e_240, 0);
    V v_op_2455 = heff_field(v_e_240, 1);
    V v_b_2456 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_x4_2457 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_dup(v_b_2456)));
    switch (heff_tag_of(v_x4_2457)) {
    case TAG_MkChain: {
      V v_bf_2458 = heff_field(v_x4_2457, 0);
      V v_rest_2459 = heff_field(v_x4_2457, 1);
      V v_ru_24x4_2457_24MkChain = heff_take_reuse_n(v_x4_2457, 3ULL, 2);
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2455), v_rest_2459));
      if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
        heff_drop(v_b_2456);
        heff_drop(v_t_2460);
        V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_bf_2458}), v_rest_2459});
        return heff_tag_at_n(v_ru_24x4_2457_24MkChain, TAG_MkChain, 2, (V[]){v_a_2454, v_t_2461});
      } else {
        heff_drop(v_bf_2458);
        heff_drop(v_rest_2459);
        heff_drop(v_t_2460);
        V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_b_2456}), NTAG(TAG_Nil)});
        return heff_tag_at_n(v_ru_24x4_2457_24MkChain, TAG_MkChain, 2, (V[]){v_a_2454, v_t_2462});
      }
    }
    default: return heff_nomatch(v_x4_2457);
    }
  }
  case TAG_Ops: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_OpRhs: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Ann: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BVar: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BImp: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BAnn: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Lam: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Case: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAlt: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_If: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Do: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ESBind: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2echain(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2461 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2461, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = (g_list_2edrop(MK_INT(1LL), v_commas_243));
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_240, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Atom: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EParen: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Named: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Tup: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Seg: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Braces: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Update: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EUSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_InstB: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFDefault: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Sum: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECon: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EField: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENeg: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_App: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Op: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Ops: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRhs: {
      V v_op_2462 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2466 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0, 1, 1, (V[]){heff_dup(v_op_2462)}), heff_rfield(v_f_240, 0)));
      switch (heff_tag_of(v_t_2466)) {
      case TAG_Nothing: {
        heff_drop_rec(v_f_240, 2);
        heff_drop(v_rs_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_rec(v_op_2462, 9);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ru_24t_2466_24Just = heff_take_reuse_n(v_t_2466, 0ULL, 1);
        V v_x2_2468 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(v_f_240, v_rs_243));
        switch (heff_tag_of(v_x2_2468)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2462, 9);
          heff_drop_cell(v_ru_24t_2466_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_ops_2469 = heff_field(v_x2_2468, 0);
          heff_take_n(v_x2_2468, 1ULL, 1);
          V v_t_2470 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2462, 1, 9), v_ops_2469});
          return heff_tag_at_n(v_ru_24t_2466_24Just, TAG_Just, 1, (V[]){v_t_2470});
        }
        default: return heff_nomatch(v_x2_2468);
        }
      }
      default: return heff_nomatch(v_t_2466);
      }
    }
    case TAG_Ann: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BImp: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BAnn: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Lam: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Case: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAlt: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_If: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Do: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESBind: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eopsOf(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args) {
  V v_g_2464 = args[0];
  V v_op_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_op_2462, 1, 9)}));
  return ({ V a_0 = v_t_2465; V b_1 = heff_get_n(v_g_2464, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_r_242, 0);
    V v_t_2463 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2461, 1))));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2412;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_t_2411;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_t_2411 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        switch (heff_tag_of(v_x_248)) {
        case TAG_Nil: {
          v_t_2411 = heff_get_n(v_t_246, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x_248, 0);
          heff_take_n(v_x_248, 1ULL, 2);
          heff_drop_rec(v_t_246, 9);
          v_t_2411 = heff_get_n(v_x_249, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        v_t_2412 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2411);
        v_t_2412 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_2412 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2414 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2416 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2413, v_t_2414, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2418 = (g_std_2edoc_2e_3c_3e(v_t_2416, v_t_2417));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2418));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2419));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2415 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2415;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam88_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam96_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam22_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam23_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam25_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam86_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam87_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam88_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam89_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam90_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam93_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam94_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam95_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam96_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c(heff_dup(v_i_2411), MK_INT(0LL))) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2440 = args[0];
  V v_e_2441 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2440));
  V v_b_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_2441}));
  V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2443));
  V v_t_2445 = (g_std_2edoc_2e_3c_3e(v_a_2442, v_t_2444));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2445));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2456 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_d_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2457 = heff_intSub(v_k_2455, v_i_2456);
  if (heff_intEq_c(heff_dup(v_i_2457), MK_INT(0LL))) {
    heff_drop(v_i_2457);
    return v_d_2454;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2457, v_d_2454});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2455 = args[0];
  V v_d_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2455, v_d_2454})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2464 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2464));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2479 = args[0];
  V v_f_2480 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2479));
  V v_d_2482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2480}));
  V v_t_2483 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2482})));
  V v_t_2484 = (g_std_2edoc_2e_3c_3e(v_a_2481, v_t_2483));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2484));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_d_2491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2494 = heff_intSub(v_k_2492, v_i_2493);
  if (heff_intEq_c(heff_dup(v_i_2494), MK_INT(0LL))) {
    heff_drop(v_i_2494);
    return v_d_2491;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2494, v_d_2491});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_2492 = args[0];
  V v_d_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_2492, v_d_2491})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24121 = args[0];
  V v_f_24122 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24121));
  V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24122}));
  V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24124})));
  V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24126));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24137 = args[0];
  V v_k_24136 = heff_env(self)[0];
  V v_d_24135 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24138 = heff_intSub(v_k_24136, v_i_24137);
  if (heff_intEq_c(heff_dup(v_i_24138), MK_INT(0LL))) {
    heff_drop(v_i_24138);
    return v_d_24135;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24138, v_d_24135});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24136 = args[0];
  V v_d_24135 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24136, v_d_24135})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24195 = args[0];
  V v_a_24196 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24178 = heff_env(self)[1];
  V v_c_24181 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24197 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_24178, 4, 9), heff_get_n(v_c_24181, 3, 9)));
  V v_t_24198;
  if ((heff_dup(v_x1_24197) == NTAG(TAG_True))) {
    heff_drop(v_x1_24197);
    v_t_24198 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24197);
    v_t_24198 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24199 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24195));
  V v_b_24200 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24196}));
  V v_t_24201 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24200));
  V v_t_24202 = (g_std_2edoc_2e_3c_3e(v_a_24199, v_t_24201));
  return (g_std_2edoc_2e_3c_3e(v_t_24198, v_t_24202));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24209 = args[0];
  V v_k_24208 = heff_env(self)[0];
  V v_d_24207 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24210 = heff_intSub(v_k_24208, v_i_24209);
  if (heff_intEq_c(heff_dup(v_i_24210), MK_INT(0LL))) {
    heff_drop(v_i_24210);
    return v_d_24207;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24210, v_d_24207});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24208 = args[0];
  V v_d_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24208, v_d_24207})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24217 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24218 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24217}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24218));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24237 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24235 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24238 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24237));
  V v_t_24239;
  if ((heff_dup(v_x1_24238) == NTAG(TAG_True))) {
    heff_drop(v_x1_24238);
    v_t_24239 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24238);
    v_t_24239 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24240 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24235, v_r_24237}));
  return (g_std_2edoc_2e_3c_3e(v_t_24239, v_t_24240));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24353 = args[0];
  V v_k_24352 = heff_env(self)[0];
  V v_d_24351 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24354 = heff_intSub(v_k_24352, v_i_24353);
  if (heff_intEq_c(heff_dup(v_i_24354), MK_INT(0LL))) {
    heff_drop(v_i_24354);
    return v_d_24351;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24354, v_d_24351});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24352 = args[0];
  V v_d_24351 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24352, v_d_24351})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e1_2435}));
      V v_t_2446 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2447 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2448;
      if ((heff_dup(v_x1_2447) == NTAG(TAG_True))) {
        heff_drop(v_x1_2447);
        v_t_2448 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2447);
        v_t_2448 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2450 = (g_std_2edoc_2e_3c_3e(v_t_2448, v_t_2449));
      V v_t_2451 = (g_std_2edoc_2e_3c_3e(v_t_2446, v_t_2450));
      V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2451));
      V v_t_2453 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2452));
      V v_d_2454 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2453));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2454})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2459 = heff_field(v_e0_241, 0);
    V v_cc_2460 = heff_field(v_e0_241, 1);
    V v_spec_2461 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2459}));
    V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2460));
    V v_t_2465 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2461; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2461); r_; });
    V v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2463, v_t_2465));
    return (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2466));
  }
  case TAG_Braces: {
    V v_o_2467 = heff_field(v_e0_241, 0);
    V v_fs_2468 = heff_field(v_e0_241, 1);
    V v_commas_2469 = heff_field(v_e0_241, 2);
    V v_c_2470 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2468)) {
    case TAG_Nil: {
      heff_drop(v_commas_2469);
      V v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2467));
      V v_t_2472 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2470));
      return (g_std_2edoc_2e_3c_3e(v_t_2471, v_t_2472));
    }
    case TAG_Cons: {
      V v_f1_2473 = heff_field(v_fs_2468, 0);
      V v_more_2474 = heff_field(v_fs_2468, 1);
      V v_ru_24fs_2468_24Cons = heff_take_reuse_n(v_fs_2468, 3ULL, 2);
      V v_a_2475 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2467)));
      V v_d_2476 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2473}));
      V v_t_2477 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2468_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2476})));
      V v_t_2478 = (g_std_2edoc_2e_3c_3e(v_a_2475, v_t_2477));
      V v_t_2485 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2469; V a_3 = v_more_2474; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2469); heff_drop(v_more_2474); r_; });
      V v_x1_2486 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_2467, 4, 9), heff_dup(heff_rfield(v_c_2470, 3))));
      V v_t_2487;
      if ((heff_dup(v_x1_2486) == NTAG(TAG_True))) {
        heff_drop(v_x1_2486);
        v_t_2487 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2486);
        v_t_2487 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2488 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2470));
      V v_t_2489 = (g_std_2edoc_2e_3c_3e(v_t_2487, v_t_2488));
      V v_t_2490 = (g_std_2edoc_2e_3c_3e(v_t_2485, v_t_2489));
      V v_d_2491 = (g_std_2edoc_2e_3c_3e(v_t_2478, v_t_2490));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_2491})})));
    }
    default: return heff_nomatch(v_fs_2468);
    }
  }
  case TAG_Update: {
    V v_o_2496 = heff_field(v_e0_241, 0);
    V v_r_2497 = heff_field(v_e0_241, 1);
    V v_bar_2498 = heff_field(v_e0_241, 2);
    V v_fs_2499 = heff_field(v_e0_241, 3);
    V v_commas_24100 = heff_field(v_e0_241, 4);
    V v_c_24101 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_2499)) {
    case TAG_Nil: {
      heff_drop(v_commas_24100);
      V v_a_24102 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2496));
      V v_a_24103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_2497}));
      V v_a_24104 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2498));
      V v_b_24105 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24101));
      V v_t_24106 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24105));
      V v_t_24107 = (g_std_2edoc_2e_3c_3e(v_a_24104, v_t_24106));
      V v_t_24108 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24107));
      V v_t_24109 = (g_std_2edoc_2e_3c_3e(v_a_24103, v_t_24108));
      V v_t_24110 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24109));
      return (g_std_2edoc_2e_3c_3e(v_a_24102, v_t_24110));
    }
    case TAG_Cons: {
      V v_f1_24111 = heff_field(v_fs_2499, 0);
      V v_more_24112 = heff_field(v_fs_2499, 1);
      V v_ru_24fs_2499_24Cons = heff_take_reuse_n(v_fs_2499, 3ULL, 2);
      V v_a_24113 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2496)));
      V v_d_24114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_2497}));
      V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_2499_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24114})));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24115));
      V v_a_24117 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2498));
      V v_d_24118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24111}));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24118})));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(v_a_24117, v_t_24119));
      V v_t_24127 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24100; V a_3 = v_more_24112; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24100); heff_drop(v_more_24112); r_; });
      V v_x1_24128 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_2496, 4, 9), heff_dup(heff_rfield(v_c_24101, 3))));
      V v_t_24129;
      if ((heff_dup(v_x1_24128) == NTAG(TAG_True))) {
        heff_drop(v_x1_24128);
        v_t_24129 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24128);
        v_t_24129 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24130 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24101));
      V v_t_24131 = (g_std_2edoc_2e_3c_3e(v_t_24129, v_t_24130));
      V v_t_24132 = (g_std_2edoc_2e_3c_3e(v_t_24127, v_t_24131));
      V v_t_24133 = (g_std_2edoc_2e_3c_3e(v_t_24120, v_t_24132));
      V v_t_24134 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24133));
      V v_d_24135 = (g_std_2edoc_2e_3c_3e(v_t_24116, v_t_24134));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24135})})));
    }
    default: return heff_nomatch(v_fs_2499);
    }
  }
  case TAG_EUSet: {
    V v_x_24140 = heff_field(v_e0_241, 0);
    V v_eq_24141 = heff_field(v_e0_241, 1);
    V v_e_24142 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24143 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24140}));
    V v_b_24144 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24141));
    V v_t_24145 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24144));
    V v_t_24146 = (g_std_2edoc_2e_3c_3e(v_a_24143, v_t_24145));
    V v_t_24147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24142}));
    return (g_std_2edoc_2e_3c_3e(v_t_24146, v_t_24147));
  }
  case TAG_InstB: {
    V v_o_24148 = heff_field(v_e0_241, 0);
    V v_o2_24149 = heff_field(v_e0_241, 1);
    V v_d_24150 = heff_field(v_e0_241, 2);
    V v_c1_24151 = heff_field(v_e0_241, 3);
    V v_c_24152 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24153 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24148));
    V v_t_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24149));
    V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24150}));
    V v_t_24156 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24151));
    V v_t_24157 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24152));
    V v_t_24158 = (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
    V v_t_24159 = (g_std_2edoc_2e_3c_3e(v_t_24155, v_t_24158));
    V v_t_24160 = (g_std_2edoc_2e_3c_3e(v_t_24154, v_t_24159));
    return (g_std_2edoc_2e_3c_3e(v_t_24153, v_t_24160));
  }
  case TAG_EFSet: {
    V v_x_24161 = heff_field(v_e0_241, 0);
    V v_eq_24162 = heff_field(v_e0_241, 1);
    V v_e_24163 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24161));
    V v_b_24165 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24162));
    V v_t_24166 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24165));
    V v_t_24167 = (g_std_2edoc_2e_3c_3e(v_a_24164, v_t_24166));
    V v_t_24168 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24163}));
    return (g_std_2edoc_2e_3c_3e(v_t_24167, v_t_24168));
  }
  case TAG_EFDefault: {
    V v_d_24169 = heff_field(v_e0_241, 0);
    V v_eq_24170 = heff_field(v_e0_241, 1);
    V v_e_24171 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24169}));
    V v_b_24173 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24170));
    V v_t_24174 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24173));
    V v_t_24175 = (g_std_2edoc_2e_3c_3e(v_a_24172, v_t_24174));
    V v_t_24176 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24171}));
    return (g_std_2edoc_2e_3c_3e(v_t_24175, v_t_24176));
  }
  case TAG_Sum: {
    V v_kw_24177 = heff_field(v_e0_241, 0);
    V v_o_24178 = heff_field(v_e0_241, 1);
    V v_alts_24179 = heff_field(v_e0_241, 2);
    V v_bars_24180 = heff_field(v_e0_241, 3);
    V v_c_24181 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24179)) {
    case TAG_Nil: {
      heff_drop(v_bars_24180);
      V v_a_24182 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24177));
      V v_a_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24178));
      V v_b_24184 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24181));
      V v_t_24185 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24184));
      V v_t_24186 = (g_std_2edoc_2e_3c_3e(v_a_24183, v_t_24185));
      V v_t_24187 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24186));
      return (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24187));
    }
    case TAG_Cons: {
      V v_a1_24188 = heff_field(v_alts_24179, 0);
      V v_more_24189 = heff_field(v_alts_24179, 1);
      heff_take_n(v_alts_24179, 3ULL, 2);
      V v_a_24190 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24177));
      V v_a_24191 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24178)));
      V v_b_24192 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24188}));
      V v_t_24193 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24192));
      V v_t_24194 = (g_std_2edoc_2e_3c_3e(v_a_24191, v_t_24193));
      V v_a_24203 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24178, heff_dup(v_c_24181)}); V a_2 = v_bars_24180; V a_3 = v_more_24189; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24180); heff_drop(v_more_24189); r_; });
      V v_b_24204 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24181));
      V v_t_24205 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24204));
      V v_t_24206 = (g_std_2edoc_2e_3c_3e(v_a_24203, v_t_24205));
      V v_d_24207 = (g_std_2edoc_2e_3c_3e(v_t_24194, v_t_24206));
      V v_b_24212 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24207})})));
      V v_t_24213 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24212));
      return (g_std_2edoc_2e_3c_3e(v_a_24190, v_t_24213));
    }
    default: return heff_nomatch(v_alts_24179);
    }
  }
  case TAG_ECon: {
    V v_c_24214 = heff_field(v_e0_241, 0);
    V v_args_24215 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24216 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24214));
    V v_t_24219 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24215; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24215); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24216, v_t_24219));
  }
  case TAG_EField: {
    V v_e_24220 = heff_field(v_e0_241, 0);
    V v_f_24221 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24220}));
    V v_t_24223 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24221));
    return (g_std_2edoc_2e_3c_3e(v_t_24222, v_t_24223));
  }
  case TAG_ENeg: {
    V v_m_24224 = heff_field(v_e0_241, 0);
    V v_e_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24224));
    V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24225}));
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24227));
  }
  case TAG_App: {
    V v_h_24228 = heff_field(v_e0_241, 0);
    V v_args_24229 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24228;
    heff_room[2] = v_args_24229;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24230 = heff_field(v_e0_241, 0);
    V v_op_24231 = heff_field(v_e0_241, 1);
    V v_b_24232 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    V v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24230, v_op_24231, v_b_24232})));
    switch (heff_tag_of(v_t_24233)) {
    case TAG_MkChain: {
      V v_first_24234 = heff_field(v_t_24233, 0);
      V v_rest_24235 = heff_field(v_t_24233, 1);
      heff_take_n(v_t_24233, 3ULL, 2);
      V v_t_24236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24235), v_first_24234}));
      V v_t_24241 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24235)}); V a_2 = v_rest_24235; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24235); r_; });
      V v_t_24242 = (g_std_2edoc_2e_3c_3e(v_t_24236, v_t_24241));
      return (g_std_2edoc_2egroup(v_t_24242));
    }
    default: return heff_nomatch(v_t_24233);
    }
  }
  case TAG_Ops: {
    V v_a_24243 = heff_field(v_e0_241, 0);
    V v_rest_24244 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24243;
    heff_room[2] = v_rest_24244;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24245 = heff_field(v_e0_241, 0);
    V v_e_24246 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24247 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24245));
    V v_b_24248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24246}));
    V v_t_24249 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24248));
    return (g_std_2edoc_2e_3c_3e(v_a_24247, v_t_24249));
  }
  case TAG_Ann: {
    V v_e_24250 = heff_field(v_e0_241, 0);
    V v_cc_24251 = heff_field(v_e0_241, 1);
    V v_ty_24252 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24253 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24250}));
    V v_b_24254 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24251));
    V v_t_24255 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24254));
    V v_t_24256 = (g_std_2edoc_2e_3c_3e(v_a_24253, v_t_24255));
    V v_t_24257 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24252}));
    V v_d_24258 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24257));
    V v_t_24259 = (g_std_2edoc_2e_3c_3e(v_t_24256, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24258})));
    return (g_std_2edoc_2egroup(v_t_24259));
  }
  case TAG_BVar: {
    V v_t_24260 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24260));
  }
  case TAG_BImp: {
    V v_o_24261 = heff_field(v_e0_241, 0);
    V v_x_24262 = heff_field(v_e0_241, 1);
    V v_c_24263 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24264 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24261));
    V v_t_24265 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24262));
    V v_t_24266 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24263));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e(v_t_24265, v_t_24266));
    return (g_std_2edoc_2e_3c_3e(v_t_24264, v_t_24267));
  }
  case TAG_BAnn: {
    V v_o_24268 = heff_field(v_e0_241, 0);
    V v_x_24269 = heff_field(v_e0_241, 1);
    V v_cc_24270 = heff_field(v_e0_241, 2);
    V v_ty_24271 = heff_field(v_e0_241, 3);
    V v_c_24272 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24273 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24268));
    V v_a_24274 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24269));
    V v_a_24275 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24270));
    V v_b_24276 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24271}));
    V v_t_24277 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24276));
    V v_t_24278 = (g_std_2edoc_2e_3c_3e(v_a_24275, v_t_24277));
    V v_t_24279 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24278));
    V v_t_24280 = (g_std_2edoc_2e_3c_3e(v_a_24274, v_t_24279));
    V v_t_24281 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24272));
    V v_t_24282 = (g_std_2edoc_2e_3c_3e(v_t_24280, v_t_24281));
    return (g_std_2edoc_2e_3c_3e(v_t_24273, v_t_24282));
  }
  case TAG_Lam: {
    V v_bs_24283 = heff_field(v_e0_241, 0);
    V v_binders_24284 = heff_field(v_e0_241, 1);
    V v_arrow_24285 = heff_field(v_e0_241, 2);
    V v_body_24286 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24287 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24283));
    V v_t_24288 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24289 = (g_list_2emap(v_t_24288, v_binders_24284));
    V v_a_24290 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24289; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24289); r_; });
    V v_b_24291 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24285));
    V v_t_24292 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24291));
    V v_t_24293 = (g_std_2edoc_2e_3c_3e(v_a_24290, v_t_24292));
    V v_t_24294 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24286));
    V v_t_24298;
    if ((heff_dup(v_t_24294) == NTAG(TAG_True))) {
      heff_drop(v_t_24294);
      V v_t_24295 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24286}));
      v_t_24298 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24295));
    } else {
      heff_drop(v_t_24294);
      V v_t_24296 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24286}));
      V v_d_24297 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24296));
      v_t_24298 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24297})));
    }
    V v_t_24299 = (g_std_2edoc_2e_3c_3e(v_t_24293, v_t_24298));
    return (g_std_2edoc_2e_3c_3e(v_t_24287, v_t_24299));
  }
  case TAG_Case: {
    V v_kw_24300 = heff_field(v_e0_241, 0);
    V v_scrut_24301 = heff_field(v_e0_241, 1);
    V v_of2_24302 = heff_field(v_e0_241, 2);
    V v_alts_24303 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24304 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24300));
    V v_a_24305 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24301}));
    V v_b_24306 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24302));
    V v_t_24307 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24306));
    V v_t_24308 = (g_std_2edoc_2e_3c_3e(v_a_24305, v_t_24307));
    V v_t_24309 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24308));
    V v_t_24310 = (g_std_2edoc_2e_3c_3e(v_a_24304, v_t_24309));
    V v_t_24311 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24303; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24303); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24310, v_t_24311));
  }
  case TAG_EAlt: {
    V v_p_24312 = heff_field(v_e0_241, 0);
    V v_arrow_24313 = heff_field(v_e0_241, 1);
    V v_body_24314 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24315 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24312; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24312); r_; });
    V v_b_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24313));
    V v_t_24317 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24316));
    V v_t_24318 = (g_std_2edoc_2e_3c_3e(v_a_24315, v_t_24317));
    V v_t_24319 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24314}));
    return (g_std_2edoc_2e_3c_3e(v_t_24318, v_t_24319));
  }
  case TAG_If: {
    V v_kw_24320 = heff_field(v_e0_241, 0);
    V v_c_24321 = heff_field(v_e0_241, 1);
    V v_th_24322 = heff_field(v_e0_241, 2);
    V v_a_24323 = heff_field(v_e0_241, 3);
    V v_el_24324 = heff_field(v_e0_241, 4);
    V v_b_24325 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24326 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24320, v_c_24321, v_th_24322, v_a_24323}));
    V v_t_24327 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24324, v_b_24325}));
    V v_t_24328 = (g_std_2edoc_2e_3c_3e(v_t_24326, v_t_24327));
    return (g_std_2edoc_2egroup(v_t_24328));
  }
  case TAG_Do: {
    V v_kw_24329 = heff_field(v_e0_241, 0);
    V v_stmts_24330 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24331 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24329));
    V v_t_24332 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24330; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24330); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24331, v_t_24332));
  }
  case TAG_ESBind: {
    V v_x_24333 = heff_field(v_e0_241, 0);
    V v_arrow_24334 = heff_field(v_e0_241, 1);
    V v_e_24335 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24336 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24333));
    V v_b_24337 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24334));
    V v_t_24338 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24337));
    V v_t_24339 = (g_std_2edoc_2e_3c_3e(v_a_24336, v_t_24338));
    V v_t_24340 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24335}));
    return (g_std_2edoc_2e_3c_3e(v_t_24339, v_t_24340));
  }
  case TAG_ELet: {
    V v_kw_24341 = heff_field(v_e0_241, 0);
    V v_p_24342 = heff_field(v_e0_241, 1);
    V v_ann_24343 = heff_field(v_e0_241, 2);
    V v_eq_24344 = heff_field(v_e0_241, 3);
    V v_e_24345 = heff_field(v_e0_241, 4);
    V v_body_24346 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24346)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24341, v_p_24342, v_ann_24343, v_eq_24344, v_e_24345});
    }
    case TAG_Just: {
      V v_it1_24347 = heff_field(v_body_24346, 0);
      V v_ru_24body_24346_24Just = heff_take_reuse_n(v_body_24346, 1ULL, 1);
      switch (heff_tag_of(v_it1_24347)) {
      case TAG_MkPair: {
        V v_i_24348 = heff_field(v_it1_24347, 0);
        V v_b_24349 = heff_field(v_it1_24347, 1);
        heff_take_n(v_it1_24347, 3ULL, 2);
        V v_t_24350 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24341, v_p_24342, v_ann_24343, v_eq_24344, v_e_24345, v_i_24348, v_b_24349}));
        V v_d_24351 = (g_std_2edoc_2egroup(v_t_24350));
        return heff_tag_at_n(v_ru_24body_24346_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24351})});
      }
      default: return heff_nomatch(v_it1_24347);
      }
    }
    default: return heff_nomatch(v_body_24346);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_env_24356 = args[0];
  V v_e_24357 = args[1];
  V v_t_24358 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24357));
  if ((heff_dup(v_t_24358) == NTAG(TAG_True))) {
    heff_drop(v_t_24358);
    V v_t_24359 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24356, v_e_24357}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_t_24359));
  } else {
    heff_drop(v_t_24358);
    V v_t_24360 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24356, v_e_24357}));
    V v_t_24361 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24360));
    return (g_std_2edoc_2egroup(v_t_24361));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_env_24362 = args[0];
  V v_kw_24363 = args[1];
  V v_p_24364 = args[2];
  V v_ann_24365 = args[3];
  V v_eq_24366 = args[4];
  V v_e_24367 = args[5];
  V v_a_24368 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24362), v_kw_24363));
  V v_b_24369 = ({ V a_0 = heff_dup(v_env_24362); V a_1 = v_p_24364; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24364); r_; });
  V v_t_24370 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_b_24369));
  V v_t_24371 = (g_std_2edoc_2e_3c_3e(v_a_24368, v_t_24370));
  V v_a_24379;
  switch (heff_tag_of(v_ann_24365)) {
  case TAG_Nothing: {
    v_a_24379 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24372 = heff_field(v_ann_24365, 0);
    V v_ru_24ann_24365_24Just = heff_take_reuse_n(v_ann_24365, 1ULL, 1);
    switch (heff_tag_of(v_it1_24372)) {
    case TAG_MkPair: {
      V v_cc_24373 = heff_field(v_it1_24372, 0);
      V v_ty_24374 = heff_field(v_it1_24372, 1);
      heff_take_n(v_it1_24372, 3ULL, 2);
      V v_a_24375 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24362), v_cc_24373));
      V v_b_24376 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24362), v_ty_24374}));
      V v_t_24377 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24365_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24376));
      V v_t_24378 = (g_std_2edoc_2e_3c_3e(v_a_24375, v_t_24377));
      v_a_24379 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24378));
      break;
    }
    default: heff_nomatch(v_it1_24372);
    }
    break;
  }
  default: heff_nomatch(v_ann_24365);
  }
  V v_b_24380 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24362), v_eq_24366));
  V v_t_24381 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24380));
  V v_t_24382 = (g_std_2edoc_2e_3c_3e(v_a_24379, v_t_24381));
  V v_t_24383 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24362, v_e_24367}));
  V v_t_24384 = (g_std_2edoc_2e_3c_3e(v_t_24382, v_t_24383));
  return (g_std_2edoc_2e_3c_3e(v_t_24371, v_t_24384));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_env_24385 = args[0];
  V v_kw_24386 = args[1];
  V v_p_24387 = args[2];
  V v_ann_24388 = args[3];
  V v_eq_24389 = args[4];
  V v_e_24390 = args[5];
  V v_i_24391 = args[6];
  V v_b_24392 = args[7];
  V v_d_24393 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24385), v_kw_24386, v_p_24387, v_ann_24388, v_eq_24389, v_e_24390}));
  V v_t_24394 = heff_dup(heff_rfield(v_i_24391, 6));
  V v_x1_24396;
  if ((heff_dup(v_t_24394) == NTAG(TAG_True))) {
    heff_drop(v_t_24394);
    v_x1_24396 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_24394);
    V v_t_24395 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24392));
    v_x1_24396 = heff_get_n(v_t_24395, 6, 9);
  }
  V v_t_24397;
  if ((heff_dup(v_x1_24396) == NTAG(TAG_True))) {
    heff_drop(v_x1_24396);
    v_t_24397 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24396);
    v_t_24397 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24398 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24385), v_i_24391));
  V v_b_24502;
  switch (heff_tag_of(v_b_24392)) {
  case TAG_Atom: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_EParen: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Named: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Tup: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Seg: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Braces: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Update: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_EUSet: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_InstB: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_EFSet: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Sum: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_ECon: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_EField: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_ENeg: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_App: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Op: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Ops: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Ann: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_BVar: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_BImp: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_BAnn: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Lam: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Case: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_EAlt: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_If: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_Do: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_ESBind: {
    v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24493 = heff_dup(heff_field(v_b_24392, 0));
    V v_p2_24494 = heff_dup(heff_field(v_b_24392, 1));
    V v_ann2_24495 = heff_dup(heff_field(v_b_24392, 2));
    V v_eq2_24496 = heff_dup(heff_field(v_b_24392, 3));
    V v_e2_24497 = heff_dup(heff_field(v_b_24392, 4));
    V v_it6_24498 = heff_dup(heff_field(v_b_24392, 5));
    switch (heff_tag_of(v_it6_24498)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24493);
      heff_drop(v_p2_24494);
      heff_drop(v_ann2_24495);
      heff_drop(v_eq2_24496);
      heff_drop(v_e2_24497);
      v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24385, v_b_24392}));
      break;
    }
    case TAG_Just: {
      V v_it61_24499 = heff_field(v_it6_24498, 0);
      heff_take_n(v_it6_24498, 1ULL, 1);
      heff_drop_tag(v_b_24392, 6);
      switch (heff_tag_of(v_it61_24499)) {
      case TAG_MkPair: {
        V v_i2_24500 = heff_field(v_it61_24499, 0);
        V v_b2_24501 = heff_field(v_it61_24499, 1);
        heff_take_n(v_it61_24499, 3ULL, 2);
        v_b_24502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24385, v_kw2_24493, v_p2_24494, v_ann2_24495, v_eq2_24496, v_e2_24497, v_i2_24500, v_b2_24501}));
        break;
      }
      default: heff_nomatch(v_it61_24499);
      }
      break;
    }
    default: heff_nomatch(v_it6_24498);
    }
    break;
  }
  default: heff_nomatch(v_b_24392);
  }
  V v_t_24503 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24502));
  V v_t_24504 = (g_std_2edoc_2e_3c_3e(v_a_24398, v_t_24503));
  V v_t_24505 = (g_std_2edoc_2e_3c_3e(v_t_24397, v_t_24504));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24393}), v_t_24505));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_env_24506 = args[0];
  V v_kw_24507 = args[1];
  V v_c_24508 = args[2];
  V v_th_24509 = args[3];
  V v_a_24510 = args[4];
  V v_a_24511 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24506), v_kw_24507));
  V v_b_24512 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24506), v_c_24508}));
  V v_t_24513 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24512));
  V v_t_24514 = (g_std_2edoc_2e_3c_3e(v_a_24511, v_t_24513));
  V v_t_24515 = heff_dup(heff_rfield(v_th_24509, 6));
  V v_x1_24517;
  if ((heff_dup(v_t_24515) == NTAG(TAG_True))) {
    heff_drop(v_t_24515);
    v_x1_24517 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_24515);
    V v_t_24516 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24510));
    v_x1_24517 = heff_get_n(v_t_24516, 6, 9);
  }
  V v_t_24518;
  if ((heff_dup(v_x1_24517) == NTAG(TAG_True))) {
    heff_drop(v_x1_24517);
    v_t_24518 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24517);
    v_t_24518 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24519 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24506), v_th_24509));
  V v_d_24520 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24506, v_a_24510}));
  V v_t_24521 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24520})));
  V v_t_24522 = (g_std_2edoc_2e_3c_3e(v_a_24519, v_t_24521));
  V v_d_24523 = (g_std_2edoc_2e_3c_3e(v_t_24518, v_t_24522));
  V v_t_24524 = (g_std_2edoc_2e_3c_3e(v_t_24514, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24523})));
  return (g_std_2edoc_2egroup(v_t_24524));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_env_24525 = args[0];
  V v_el_24526 = args[1];
  V v_b_24527 = args[2];
  switch (heff_tag_of(v_b_24527)) {
  case TAG_Atom: {
    V v_t_24529 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24531;
    if ((heff_dup(v_t_24529) == NTAG(TAG_True))) {
      heff_drop(v_t_24529);
      v_x1_24531 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24529);
      V v_t_24530 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24531 = heff_get_n(v_t_24530, 6, 9);
    }
    V v_t_24532;
    if ((heff_dup(v_x1_24531) == NTAG(TAG_True))) {
      heff_drop(v_x1_24531);
      v_t_24532 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24531);
      v_t_24532 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24533 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24534 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24535 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24534})));
    V v_t_24536 = (g_std_2edoc_2e_3c_3e(v_a_24533, v_t_24535));
    return (g_std_2edoc_2e_3c_3e(v_t_24532, v_t_24536));
  }
  case TAG_EParen: {
    V v_t_24540 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24542;
    if ((heff_dup(v_t_24540) == NTAG(TAG_True))) {
      heff_drop(v_t_24540);
      v_x1_24542 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24540);
      V v_t_24541 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24542 = heff_get_n(v_t_24541, 6, 9);
    }
    V v_t_24543;
    if ((heff_dup(v_x1_24542) == NTAG(TAG_True))) {
      heff_drop(v_x1_24542);
      v_t_24543 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24542);
      v_t_24543 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24544 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24545 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24546 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24545})));
    V v_t_24547 = (g_std_2edoc_2e_3c_3e(v_a_24544, v_t_24546));
    return (g_std_2edoc_2e_3c_3e(v_t_24543, v_t_24547));
  }
  case TAG_Named: {
    V v_t_24553 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24555;
    if ((heff_dup(v_t_24553) == NTAG(TAG_True))) {
      heff_drop(v_t_24553);
      v_x1_24555 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24553);
      V v_t_24554 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24555 = heff_get_n(v_t_24554, 6, 9);
    }
    V v_t_24556;
    if ((heff_dup(v_x1_24555) == NTAG(TAG_True))) {
      heff_drop(v_x1_24555);
      v_t_24556 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24555);
      v_t_24556 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24557 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24558 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24559 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24558})));
    V v_t_24560 = (g_std_2edoc_2e_3c_3e(v_a_24557, v_t_24559));
    return (g_std_2edoc_2e_3c_3e(v_t_24556, v_t_24560));
  }
  case TAG_Tup: {
    V v_t_24565 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24567;
    if ((heff_dup(v_t_24565) == NTAG(TAG_True))) {
      heff_drop(v_t_24565);
      v_x1_24567 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24565);
      V v_t_24566 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24567 = heff_get_n(v_t_24566, 6, 9);
    }
    V v_t_24568;
    if ((heff_dup(v_x1_24567) == NTAG(TAG_True))) {
      heff_drop(v_x1_24567);
      v_t_24568 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24567);
      v_t_24568 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24569 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24570 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24571 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24570})));
    V v_t_24572 = (g_std_2edoc_2e_3c_3e(v_a_24569, v_t_24571));
    return (g_std_2edoc_2e_3c_3e(v_t_24568, v_t_24572));
  }
  case TAG_Seg: {
    V v_t_24576 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24578;
    if ((heff_dup(v_t_24576) == NTAG(TAG_True))) {
      heff_drop(v_t_24576);
      v_x1_24578 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24576);
      V v_t_24577 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24578 = heff_get_n(v_t_24577, 6, 9);
    }
    V v_t_24579;
    if ((heff_dup(v_x1_24578) == NTAG(TAG_True))) {
      heff_drop(v_x1_24578);
      v_t_24579 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24578);
      v_t_24579 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24580 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24581 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24582 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24581})));
    V v_t_24583 = (g_std_2edoc_2e_3c_3e(v_a_24580, v_t_24582));
    return (g_std_2edoc_2e_3c_3e(v_t_24579, v_t_24583));
  }
  case TAG_Braces: {
    V v_t_24588 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24590;
    if ((heff_dup(v_t_24588) == NTAG(TAG_True))) {
      heff_drop(v_t_24588);
      v_x1_24590 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24588);
      V v_t_24589 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24590 = heff_get_n(v_t_24589, 6, 9);
    }
    V v_t_24591;
    if ((heff_dup(v_x1_24590) == NTAG(TAG_True))) {
      heff_drop(v_x1_24590);
      v_t_24591 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24590);
      v_t_24591 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24592 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24593 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24594 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24593})));
    V v_t_24595 = (g_std_2edoc_2e_3c_3e(v_a_24592, v_t_24594));
    return (g_std_2edoc_2e_3c_3e(v_t_24591, v_t_24595));
  }
  case TAG_Update: {
    V v_t_24602 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24604;
    if ((heff_dup(v_t_24602) == NTAG(TAG_True))) {
      heff_drop(v_t_24602);
      v_x1_24604 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24602);
      V v_t_24603 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24604 = heff_get_n(v_t_24603, 6, 9);
    }
    V v_t_24605;
    if ((heff_dup(v_x1_24604) == NTAG(TAG_True))) {
      heff_drop(v_x1_24604);
      v_t_24605 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24604);
      v_t_24605 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24606 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24607 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24608 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24607})));
    V v_t_24609 = (g_std_2edoc_2e_3c_3e(v_a_24606, v_t_24608));
    return (g_std_2edoc_2e_3c_3e(v_t_24605, v_t_24609));
  }
  case TAG_EUSet: {
    V v_t_24613 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24615;
    if ((heff_dup(v_t_24613) == NTAG(TAG_True))) {
      heff_drop(v_t_24613);
      v_x1_24615 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24613);
      V v_t_24614 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24615 = heff_get_n(v_t_24614, 6, 9);
    }
    V v_t_24616;
    if ((heff_dup(v_x1_24615) == NTAG(TAG_True))) {
      heff_drop(v_x1_24615);
      v_t_24616 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24615);
      v_t_24616 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24617 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24618 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24619 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24618})));
    V v_t_24620 = (g_std_2edoc_2e_3c_3e(v_a_24617, v_t_24619));
    return (g_std_2edoc_2e_3c_3e(v_t_24616, v_t_24620));
  }
  case TAG_InstB: {
    V v_t_24626 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24628;
    if ((heff_dup(v_t_24626) == NTAG(TAG_True))) {
      heff_drop(v_t_24626);
      v_x1_24628 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24626);
      V v_t_24627 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24628 = heff_get_n(v_t_24627, 6, 9);
    }
    V v_t_24629;
    if ((heff_dup(v_x1_24628) == NTAG(TAG_True))) {
      heff_drop(v_x1_24628);
      v_t_24629 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24628);
      v_t_24629 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24630 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24631 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24632 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24631})));
    V v_t_24633 = (g_std_2edoc_2e_3c_3e(v_a_24630, v_t_24632));
    return (g_std_2edoc_2e_3c_3e(v_t_24629, v_t_24633));
  }
  case TAG_EFSet: {
    V v_t_24637 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24639;
    if ((heff_dup(v_t_24637) == NTAG(TAG_True))) {
      heff_drop(v_t_24637);
      v_x1_24639 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24637);
      V v_t_24638 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24639 = heff_get_n(v_t_24638, 6, 9);
    }
    V v_t_24640;
    if ((heff_dup(v_x1_24639) == NTAG(TAG_True))) {
      heff_drop(v_x1_24639);
      v_t_24640 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24639);
      v_t_24640 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24641 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24642 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24643 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24642})));
    V v_t_24644 = (g_std_2edoc_2e_3c_3e(v_a_24641, v_t_24643));
    return (g_std_2edoc_2e_3c_3e(v_t_24640, v_t_24644));
  }
  case TAG_EFDefault: {
    V v_t_24648 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24650;
    if ((heff_dup(v_t_24648) == NTAG(TAG_True))) {
      heff_drop(v_t_24648);
      v_x1_24650 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24648);
      V v_t_24649 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24650 = heff_get_n(v_t_24649, 6, 9);
    }
    V v_t_24651;
    if ((heff_dup(v_x1_24650) == NTAG(TAG_True))) {
      heff_drop(v_x1_24650);
      v_t_24651 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24650);
      v_t_24651 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24652 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24653 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24654 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24653})));
    V v_t_24655 = (g_std_2edoc_2e_3c_3e(v_a_24652, v_t_24654));
    return (g_std_2edoc_2e_3c_3e(v_t_24651, v_t_24655));
  }
  case TAG_Sum: {
    V v_t_24661 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24663;
    if ((heff_dup(v_t_24661) == NTAG(TAG_True))) {
      heff_drop(v_t_24661);
      v_x1_24663 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24661);
      V v_t_24662 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24663 = heff_get_n(v_t_24662, 6, 9);
    }
    V v_t_24664;
    if ((heff_dup(v_x1_24663) == NTAG(TAG_True))) {
      heff_drop(v_x1_24663);
      v_t_24664 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24663);
      v_t_24664 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24665 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24666 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24667 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24666})));
    V v_t_24668 = (g_std_2edoc_2e_3c_3e(v_a_24665, v_t_24667));
    return (g_std_2edoc_2e_3c_3e(v_t_24664, v_t_24668));
  }
  case TAG_ECon: {
    V v_t_24671 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24673;
    if ((heff_dup(v_t_24671) == NTAG(TAG_True))) {
      heff_drop(v_t_24671);
      v_x1_24673 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24671);
      V v_t_24672 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24673 = heff_get_n(v_t_24672, 6, 9);
    }
    V v_t_24674;
    if ((heff_dup(v_x1_24673) == NTAG(TAG_True))) {
      heff_drop(v_x1_24673);
      v_t_24674 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24673);
      v_t_24674 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24675 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24676 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24677 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24676})));
    V v_t_24678 = (g_std_2edoc_2e_3c_3e(v_a_24675, v_t_24677));
    return (g_std_2edoc_2e_3c_3e(v_t_24674, v_t_24678));
  }
  case TAG_EField: {
    V v_t_24681 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24683;
    if ((heff_dup(v_t_24681) == NTAG(TAG_True))) {
      heff_drop(v_t_24681);
      v_x1_24683 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24681);
      V v_t_24682 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24683 = heff_get_n(v_t_24682, 6, 9);
    }
    V v_t_24684;
    if ((heff_dup(v_x1_24683) == NTAG(TAG_True))) {
      heff_drop(v_x1_24683);
      v_t_24684 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24683);
      v_t_24684 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24685 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24686 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24687 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24686})));
    V v_t_24688 = (g_std_2edoc_2e_3c_3e(v_a_24685, v_t_24687));
    return (g_std_2edoc_2e_3c_3e(v_t_24684, v_t_24688));
  }
  case TAG_ENeg: {
    V v_t_24691 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24693;
    if ((heff_dup(v_t_24691) == NTAG(TAG_True))) {
      heff_drop(v_t_24691);
      v_x1_24693 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24691);
      V v_t_24692 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24693 = heff_get_n(v_t_24692, 6, 9);
    }
    V v_t_24694;
    if ((heff_dup(v_x1_24693) == NTAG(TAG_True))) {
      heff_drop(v_x1_24693);
      v_t_24694 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24693);
      v_t_24694 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24695 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24696 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24697 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24696})));
    V v_t_24698 = (g_std_2edoc_2e_3c_3e(v_a_24695, v_t_24697));
    return (g_std_2edoc_2e_3c_3e(v_t_24694, v_t_24698));
  }
  case TAG_App: {
    V v_t_24701 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24703;
    if ((heff_dup(v_t_24701) == NTAG(TAG_True))) {
      heff_drop(v_t_24701);
      v_x1_24703 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24701);
      V v_t_24702 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24703 = heff_get_n(v_t_24702, 6, 9);
    }
    V v_t_24704;
    if ((heff_dup(v_x1_24703) == NTAG(TAG_True))) {
      heff_drop(v_x1_24703);
      v_t_24704 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24703);
      v_t_24704 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24705 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24706 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24707 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24706})));
    V v_t_24708 = (g_std_2edoc_2e_3c_3e(v_a_24705, v_t_24707));
    return (g_std_2edoc_2e_3c_3e(v_t_24704, v_t_24708));
  }
  case TAG_Op: {
    V v_t_24712 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24714;
    if ((heff_dup(v_t_24712) == NTAG(TAG_True))) {
      heff_drop(v_t_24712);
      v_x1_24714 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24712);
      V v_t_24713 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24714 = heff_get_n(v_t_24713, 6, 9);
    }
    V v_t_24715;
    if ((heff_dup(v_x1_24714) == NTAG(TAG_True))) {
      heff_drop(v_x1_24714);
      v_t_24715 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24714);
      v_t_24715 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24716 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24717 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24718 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24717})));
    V v_t_24719 = (g_std_2edoc_2e_3c_3e(v_a_24716, v_t_24718));
    return (g_std_2edoc_2e_3c_3e(v_t_24715, v_t_24719));
  }
  case TAG_Ops: {
    V v_t_24722 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24724;
    if ((heff_dup(v_t_24722) == NTAG(TAG_True))) {
      heff_drop(v_t_24722);
      v_x1_24724 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24722);
      V v_t_24723 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24724 = heff_get_n(v_t_24723, 6, 9);
    }
    V v_t_24725;
    if ((heff_dup(v_x1_24724) == NTAG(TAG_True))) {
      heff_drop(v_x1_24724);
      v_t_24725 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24724);
      v_t_24725 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24726 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24727 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24728 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24727})));
    V v_t_24729 = (g_std_2edoc_2e_3c_3e(v_a_24726, v_t_24728));
    return (g_std_2edoc_2e_3c_3e(v_t_24725, v_t_24729));
  }
  case TAG_OpRhs: {
    V v_t_24732 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24734;
    if ((heff_dup(v_t_24732) == NTAG(TAG_True))) {
      heff_drop(v_t_24732);
      v_x1_24734 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24732);
      V v_t_24733 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24734 = heff_get_n(v_t_24733, 6, 9);
    }
    V v_t_24735;
    if ((heff_dup(v_x1_24734) == NTAG(TAG_True))) {
      heff_drop(v_x1_24734);
      v_t_24735 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24734);
      v_t_24735 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24736 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24737 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24738 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24737})));
    V v_t_24739 = (g_std_2edoc_2e_3c_3e(v_a_24736, v_t_24738));
    return (g_std_2edoc_2e_3c_3e(v_t_24735, v_t_24739));
  }
  case TAG_Ann: {
    V v_t_24743 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24745;
    if ((heff_dup(v_t_24743) == NTAG(TAG_True))) {
      heff_drop(v_t_24743);
      v_x1_24745 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24743);
      V v_t_24744 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24745 = heff_get_n(v_t_24744, 6, 9);
    }
    V v_t_24746;
    if ((heff_dup(v_x1_24745) == NTAG(TAG_True))) {
      heff_drop(v_x1_24745);
      v_t_24746 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24745);
      v_t_24746 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24747 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24748 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24749 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24748})));
    V v_t_24750 = (g_std_2edoc_2e_3c_3e(v_a_24747, v_t_24749));
    return (g_std_2edoc_2e_3c_3e(v_t_24746, v_t_24750));
  }
  case TAG_BVar: {
    V v_t_24752 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24754;
    if ((heff_dup(v_t_24752) == NTAG(TAG_True))) {
      heff_drop(v_t_24752);
      v_x1_24754 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24752);
      V v_t_24753 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24754 = heff_get_n(v_t_24753, 6, 9);
    }
    V v_t_24755;
    if ((heff_dup(v_x1_24754) == NTAG(TAG_True))) {
      heff_drop(v_x1_24754);
      v_t_24755 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24754);
      v_t_24755 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24756 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24757 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24758 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24757})));
    V v_t_24759 = (g_std_2edoc_2e_3c_3e(v_a_24756, v_t_24758));
    return (g_std_2edoc_2e_3c_3e(v_t_24755, v_t_24759));
  }
  case TAG_BImp: {
    V v_t_24763 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24765;
    if ((heff_dup(v_t_24763) == NTAG(TAG_True))) {
      heff_drop(v_t_24763);
      v_x1_24765 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24763);
      V v_t_24764 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24765 = heff_get_n(v_t_24764, 6, 9);
    }
    V v_t_24766;
    if ((heff_dup(v_x1_24765) == NTAG(TAG_True))) {
      heff_drop(v_x1_24765);
      v_t_24766 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24765);
      v_t_24766 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24767 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24768 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24769 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24768})));
    V v_t_24770 = (g_std_2edoc_2e_3c_3e(v_a_24767, v_t_24769));
    return (g_std_2edoc_2e_3c_3e(v_t_24766, v_t_24770));
  }
  case TAG_BAnn: {
    V v_t_24776 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24778;
    if ((heff_dup(v_t_24776) == NTAG(TAG_True))) {
      heff_drop(v_t_24776);
      v_x1_24778 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24776);
      V v_t_24777 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24778 = heff_get_n(v_t_24777, 6, 9);
    }
    V v_t_24779;
    if ((heff_dup(v_x1_24778) == NTAG(TAG_True))) {
      heff_drop(v_x1_24778);
      v_t_24779 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24778);
      v_t_24779 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24780 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24781 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24782 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24781})));
    V v_t_24783 = (g_std_2edoc_2e_3c_3e(v_a_24780, v_t_24782));
    return (g_std_2edoc_2e_3c_3e(v_t_24779, v_t_24783));
  }
  case TAG_Lam: {
    V v_t_24788 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24790;
    if ((heff_dup(v_t_24788) == NTAG(TAG_True))) {
      heff_drop(v_t_24788);
      v_x1_24790 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24788);
      V v_t_24789 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24790 = heff_get_n(v_t_24789, 6, 9);
    }
    V v_t_24791;
    if ((heff_dup(v_x1_24790) == NTAG(TAG_True))) {
      heff_drop(v_x1_24790);
      v_t_24791 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24790);
      v_t_24791 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24792 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24793 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24794 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24793})));
    V v_t_24795 = (g_std_2edoc_2e_3c_3e(v_a_24792, v_t_24794));
    return (g_std_2edoc_2e_3c_3e(v_t_24791, v_t_24795));
  }
  case TAG_Case: {
    V v_t_24800 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24802;
    if ((heff_dup(v_t_24800) == NTAG(TAG_True))) {
      heff_drop(v_t_24800);
      v_x1_24802 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24800);
      V v_t_24801 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24802 = heff_get_n(v_t_24801, 6, 9);
    }
    V v_t_24803;
    if ((heff_dup(v_x1_24802) == NTAG(TAG_True))) {
      heff_drop(v_x1_24802);
      v_t_24803 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24802);
      v_t_24803 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24804 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24805 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24806 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24805})));
    V v_t_24807 = (g_std_2edoc_2e_3c_3e(v_a_24804, v_t_24806));
    return (g_std_2edoc_2e_3c_3e(v_t_24803, v_t_24807));
  }
  case TAG_EAlt: {
    V v_t_24811 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24813;
    if ((heff_dup(v_t_24811) == NTAG(TAG_True))) {
      heff_drop(v_t_24811);
      v_x1_24813 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24811);
      V v_t_24812 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24813 = heff_get_n(v_t_24812, 6, 9);
    }
    V v_t_24814;
    if ((heff_dup(v_x1_24813) == NTAG(TAG_True))) {
      heff_drop(v_x1_24813);
      v_t_24814 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24813);
      v_t_24814 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24815 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24816 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24817 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24816})));
    V v_t_24818 = (g_std_2edoc_2e_3c_3e(v_a_24815, v_t_24817));
    return (g_std_2edoc_2e_3c_3e(v_t_24814, v_t_24818));
  }
  case TAG_If: {
    V v_kw_24819 = heff_dup(heff_field(v_b_24527, 0));
    V v_c_24820 = heff_dup(heff_field(v_b_24527, 1));
    V v_th_24821 = heff_dup(heff_field(v_b_24527, 2));
    V v_a_24822 = heff_dup(heff_field(v_b_24527, 3));
    V v_el2_24823 = heff_dup(heff_field(v_b_24527, 4));
    V v_b2_24824 = heff_dup(heff_field(v_b_24527, 5));
    V v_t_24825 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24827;
    if ((heff_dup(v_t_24825) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24527, 6);
      heff_drop(v_t_24825);
      v_x1_24827 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24825);
      V v_t_24826 = ({ V a_0 = v_b_24527; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24527, 6); r_; });
      v_x1_24827 = heff_get_n(v_t_24826, 6, 9);
    }
    V v_t_24828;
    if ((heff_dup(v_x1_24827) == NTAG(TAG_True))) {
      heff_drop(v_x1_24827);
      v_t_24828 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24827);
      v_t_24828 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24829 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_b_24830 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24525), v_kw_24819, v_c_24820, v_th_24821, v_a_24822}));
    V v_t_24831 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_b_24830));
    V v_t_24832 = (g_std_2edoc_2e_3c_3e(v_a_24829, v_t_24831));
    V v_t_24833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24525, v_el2_24823, v_b2_24824}));
    V v_t_24834 = (g_std_2edoc_2e_3c_3e(v_t_24832, v_t_24833));
    return (g_std_2edoc_2e_3c_3e(v_t_24828, v_t_24834));
  }
  case TAG_Do: {
    V v_t_24837 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24839;
    if ((heff_dup(v_t_24837) == NTAG(TAG_True))) {
      heff_drop(v_t_24837);
      v_x1_24839 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24837);
      V v_t_24838 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24839 = heff_get_n(v_t_24838, 6, 9);
    }
    V v_t_24840;
    if ((heff_dup(v_x1_24839) == NTAG(TAG_True))) {
      heff_drop(v_x1_24839);
      v_t_24840 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24839);
      v_t_24840 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24841 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24842 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24843 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24842})));
    V v_t_24844 = (g_std_2edoc_2e_3c_3e(v_a_24841, v_t_24843));
    return (g_std_2edoc_2e_3c_3e(v_t_24840, v_t_24844));
  }
  case TAG_ESBind: {
    V v_t_24848 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24850;
    if ((heff_dup(v_t_24848) == NTAG(TAG_True))) {
      heff_drop(v_t_24848);
      v_x1_24850 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24848);
      V v_t_24849 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24850 = heff_get_n(v_t_24849, 6, 9);
    }
    V v_t_24851;
    if ((heff_dup(v_x1_24850) == NTAG(TAG_True))) {
      heff_drop(v_x1_24850);
      v_t_24851 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24850);
      v_t_24851 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24852 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24853 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24854 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24853})));
    V v_t_24855 = (g_std_2edoc_2e_3c_3e(v_a_24852, v_t_24854));
    return (g_std_2edoc_2e_3c_3e(v_t_24851, v_t_24855));
  }
  case TAG_ELet: {
    V v_t_24862 = heff_dup(heff_rfield(v_el_24526, 6));
    V v_x1_24864;
    if ((heff_dup(v_t_24862) == NTAG(TAG_True))) {
      heff_drop(v_t_24862);
      v_x1_24864 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24862);
      V v_t_24863 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24527));
      v_x1_24864 = heff_get_n(v_t_24863, 6, 9);
    }
    V v_t_24865;
    if ((heff_dup(v_x1_24864) == NTAG(TAG_True))) {
      heff_drop(v_x1_24864);
      v_t_24865 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24864);
      v_t_24865 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24866 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24525), v_el_24526));
    V v_d_24867 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24525, v_b_24527}));
    V v_t_24868 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24867})));
    V v_t_24869 = (g_std_2edoc_2e_3c_3e(v_a_24866, v_t_24868));
    return (g_std_2edoc_2e_3c_3e(v_t_24865, v_t_24869));
  }
  default: return heff_nomatch(v_b_24527);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_a_24885 = args[0];
  V v_one_24884 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24886 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24885));
  V v_x1_24887 = heff_get_n(v_t_24886, 6, 9);
  V v_t_24888;
  if ((heff_dup(v_x1_24887) == NTAG(TAG_True))) {
    heff_drop(v_x1_24887);
    v_t_24888 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24887);
    v_t_24888 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24889 = heff_tr(heff_call(v_one_24884, 1, (V[]){v_a_24885}));
  return (g_std_2edoc_2e_3c_3e(v_t_24888, v_t_24889));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_a_24897 = args[0];
  V v_one_24896 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24898 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24897));
  V v_x1_24899 = heff_get_n(v_t_24898, 6, 9);
  V v_t_24900;
  if ((heff_dup(v_x1_24899) == NTAG(TAG_True))) {
    heff_drop(v_x1_24899);
    v_t_24900 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24899);
    v_t_24900 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24901 = heff_tr(heff_call(v_one_24896, 1, (V[]){v_a_24897}));
  return (g_std_2edoc_2e_3c_3e(v_t_24900, v_t_24901));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_a_24910 = args[0];
  V v_one_24909 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24911 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24910));
  V v_x1_24912 = heff_get_n(v_t_24911, 6, 9);
  V v_t_24913;
  if ((heff_dup(v_x1_24912) == NTAG(TAG_True))) {
    heff_drop(v_x1_24912);
    v_t_24913 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24912);
    v_t_24913 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24914 = heff_tr(heff_call(v_one_24909, 1, (V[]){v_a_24910}));
  return (g_std_2edoc_2e_3c_3e(v_t_24913, v_t_24914));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_a_24926 = args[0];
  V v_one_24925 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24927 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24926));
  V v_x1_24928 = heff_get_n(v_t_24927, 6, 9);
  V v_t_24929;
  if ((heff_dup(v_x1_24928) == NTAG(TAG_True))) {
    heff_drop(v_x1_24928);
    v_t_24929 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24928);
    v_t_24929 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24930 = heff_tr(heff_call(v_one_24925, 1, (V[]){v_a_24926}));
  return (g_std_2edoc_2e_3c_3e(v_t_24929, v_t_24930));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_a_24941 = args[0];
  V v_one_24940 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24942 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24941));
  V v_x1_24943 = heff_get_n(v_t_24942, 6, 9);
  V v_t_24944;
  if ((heff_dup(v_x1_24943) == NTAG(TAG_True))) {
    heff_drop(v_x1_24943);
    v_t_24944 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24943);
    v_t_24944 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24945 = heff_tr(heff_call(v_one_24940, 1, (V[]){v_a_24941}));
  return (g_std_2edoc_2e_3c_3e(v_t_24944, v_t_24945));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_a_24953 = args[0];
  V v_one_24952 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24954 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24953));
  V v_x1_24955 = heff_get_n(v_t_24954, 6, 9);
  V v_t_24956;
  if ((heff_dup(v_x1_24955) == NTAG(TAG_True))) {
    heff_drop(v_x1_24955);
    v_t_24956 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24955);
    v_t_24956 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24957 = heff_tr(heff_call(v_one_24952, 1, (V[]){v_a_24953}));
  return (g_std_2edoc_2e_3c_3e(v_t_24956, v_t_24957));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_24967 = args[0];
  V v_one_24966 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24968 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24967));
  V v_x1_24969 = heff_get_n(v_t_24968, 6, 9);
  V v_t_24970;
  if ((heff_dup(v_x1_24969) == NTAG(TAG_True))) {
    heff_drop(v_x1_24969);
    v_t_24970 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24969);
    v_t_24970 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24971 = heff_tr(heff_call(v_one_24966, 1, (V[]){v_a_24967}));
  return (g_std_2edoc_2e_3c_3e(v_t_24970, v_t_24971));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_24979 = args[0];
  V v_one_24978 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24980 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24979));
  V v_x1_24981 = heff_get_n(v_t_24980, 6, 9);
  V v_t_24982;
  if ((heff_dup(v_x1_24981) == NTAG(TAG_True))) {
    heff_drop(v_x1_24981);
    v_t_24982 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24981);
    v_t_24982 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24983 = heff_tr(heff_call(v_one_24978, 1, (V[]){v_a_24979}));
  return (g_std_2edoc_2e_3c_3e(v_t_24982, v_t_24983));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_24992 = args[0];
  V v_one_24991 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24993 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24992));
  V v_x1_24994 = heff_get_n(v_t_24993, 6, 9);
  V v_t_24995;
  if ((heff_dup(v_x1_24994) == NTAG(TAG_True))) {
    heff_drop(v_x1_24994);
    v_t_24995 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24994);
    v_t_24995 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24996 = heff_tr(heff_call(v_one_24991, 1, (V[]){v_a_24992}));
  return (g_std_2edoc_2e_3c_3e(v_t_24995, v_t_24996));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_241004 = args[0];
  V v_one_241003 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241005 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241004));
  V v_x1_241006 = heff_get_n(v_t_241005, 6, 9);
  V v_t_241007;
  if ((heff_dup(v_x1_241006) == NTAG(TAG_True))) {
    heff_drop(v_x1_241006);
    v_t_241007 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241006);
    v_t_241007 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241008 = heff_tr(heff_call(v_one_241003, 1, (V[]){v_a_241004}));
  return (g_std_2edoc_2e_3c_3e(v_t_241007, v_t_241008));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241018 = args[0];
  V v_one_241017 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241019 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241018));
  V v_x1_241020 = heff_get_n(v_t_241019, 6, 9);
  V v_t_241021;
  if ((heff_dup(v_x1_241020) == NTAG(TAG_True))) {
    heff_drop(v_x1_241020);
    v_t_241021 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241020);
    v_t_241021 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241022 = heff_tr(heff_call(v_one_241017, 1, (V[]){v_a_241018}));
  return (g_std_2edoc_2e_3c_3e(v_t_241021, v_t_241022));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241030 = args[0];
  V v_one_241029 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241031 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241030));
  V v_x1_241032 = heff_get_n(v_t_241031, 6, 9);
  V v_t_241033;
  if ((heff_dup(v_x1_241032) == NTAG(TAG_True))) {
    heff_drop(v_x1_241032);
    v_t_241033 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241032);
    v_t_241033 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241034 = heff_tr(heff_call(v_one_241029, 1, (V[]){v_a_241030}));
  return (g_std_2edoc_2e_3c_3e(v_t_241033, v_t_241034));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241046 = args[0];
  V v_one_241045 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241047 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241046));
  V v_x1_241048 = heff_get_n(v_t_241047, 6, 9);
  V v_t_241049;
  if ((heff_dup(v_x1_241048) == NTAG(TAG_True))) {
    heff_drop(v_x1_241048);
    v_t_241049 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241048);
    v_t_241049 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241050 = heff_tr(heff_call(v_one_241045, 1, (V[]){v_a_241046}));
  return (g_std_2edoc_2e_3c_3e(v_t_241049, v_t_241050));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241058 = args[0];
  V v_one_241057 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241059 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241058));
  V v_x1_241060 = heff_get_n(v_t_241059, 6, 9);
  V v_t_241061;
  if ((heff_dup(v_x1_241060) == NTAG(TAG_True))) {
    heff_drop(v_x1_241060);
    v_t_241061 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241060);
    v_t_241061 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241062 = heff_tr(heff_call(v_one_241057, 1, (V[]){v_a_241058}));
  return (g_std_2edoc_2e_3c_3e(v_t_241061, v_t_241062));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241071 = args[0];
  V v_one_241070 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241072 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241071));
  V v_x1_241073 = heff_get_n(v_t_241072, 6, 9);
  V v_t_241074;
  if ((heff_dup(v_x1_241073) == NTAG(TAG_True))) {
    heff_drop(v_x1_241073);
    v_t_241074 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241073);
    v_t_241074 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241075 = heff_tr(heff_call(v_one_241070, 1, (V[]){v_a_241071}));
  return (g_std_2edoc_2e_3c_3e(v_t_241074, v_t_241075));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241083 = args[0];
  V v_one_241082 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241084 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241083));
  V v_x1_241085 = heff_get_n(v_t_241084, 6, 9);
  V v_t_241086;
  if ((heff_dup(v_x1_241085) == NTAG(TAG_True))) {
    heff_drop(v_x1_241085);
    v_t_241086 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241085);
    v_t_241086 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241087 = heff_tr(heff_call(v_one_241082, 1, (V[]){v_a_241083}));
  return (g_std_2edoc_2e_3c_3e(v_t_241086, v_t_241087));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241098 = args[0];
  V v_one_241097 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241099 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241098));
  V v_x1_241100 = heff_get_n(v_t_241099, 6, 9);
  V v_t_241101;
  if ((heff_dup(v_x1_241100) == NTAG(TAG_True))) {
    heff_drop(v_x1_241100);
    v_t_241101 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241100);
    v_t_241101 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241102 = heff_tr(heff_call(v_one_241097, 1, (V[]){v_a_241098}));
  return (g_std_2edoc_2e_3c_3e(v_t_241101, v_t_241102));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241110 = args[0];
  V v_one_241109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241111 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241110));
  V v_x1_241112 = heff_get_n(v_t_241111, 6, 9);
  V v_t_241113;
  if ((heff_dup(v_x1_241112) == NTAG(TAG_True))) {
    heff_drop(v_x1_241112);
    v_t_241113 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241112);
    v_t_241113 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241114 = heff_tr(heff_call(v_one_241109, 1, (V[]){v_a_241110}));
  return (g_std_2edoc_2e_3c_3e(v_t_241113, v_t_241114));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241123 = args[0];
  V v_one_241122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241124 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241123));
  V v_x1_241125 = heff_get_n(v_t_241124, 6, 9);
  V v_t_241126;
  if ((heff_dup(v_x1_241125) == NTAG(TAG_True))) {
    heff_drop(v_x1_241125);
    v_t_241126 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241125);
    v_t_241126 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241127 = heff_tr(heff_call(v_one_241122, 1, (V[]){v_a_241123}));
  return (g_std_2edoc_2e_3c_3e(v_t_241126, v_t_241127));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241135 = args[0];
  V v_one_241134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241136 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241135));
  V v_x1_241137 = heff_get_n(v_t_241136, 6, 9);
  V v_t_241138;
  if ((heff_dup(v_x1_241137) == NTAG(TAG_True))) {
    heff_drop(v_x1_241137);
    v_t_241138 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241137);
    v_t_241138 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241139 = heff_tr(heff_call(v_one_241134, 1, (V[]){v_a_241135}));
  return (g_std_2edoc_2e_3c_3e(v_t_241138, v_t_241139));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241148 = args[0];
  V v_one_241147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241149 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241148));
  V v_x1_241150 = heff_get_n(v_t_241149, 6, 9);
  V v_t_241151;
  if ((heff_dup(v_x1_241150) == NTAG(TAG_True))) {
    heff_drop(v_x1_241150);
    v_t_241151 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241150);
    v_t_241151 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241152 = heff_tr(heff_call(v_one_241147, 1, (V[]){v_a_241148}));
  return (g_std_2edoc_2e_3c_3e(v_t_241151, v_t_241152));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241160 = args[0];
  V v_one_241159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241161 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241160));
  V v_x1_241162 = heff_get_n(v_t_241161, 6, 9);
  V v_t_241163;
  if ((heff_dup(v_x1_241162) == NTAG(TAG_True))) {
    heff_drop(v_x1_241162);
    v_t_241163 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241162);
    v_t_241163 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241164 = heff_tr(heff_call(v_one_241159, 1, (V[]){v_a_241160}));
  return (g_std_2edoc_2e_3c_3e(v_t_241163, v_t_241164));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241175 = args[0];
  V v_one_241174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241176 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241175));
  V v_x1_241177 = heff_get_n(v_t_241176, 6, 9);
  V v_t_241178;
  if ((heff_dup(v_x1_241177) == NTAG(TAG_True))) {
    heff_drop(v_x1_241177);
    v_t_241178 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241177);
    v_t_241178 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241179 = heff_tr(heff_call(v_one_241174, 1, (V[]){v_a_241175}));
  return (g_std_2edoc_2e_3c_3e(v_t_241178, v_t_241179));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241187 = args[0];
  V v_one_241186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241188 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241187));
  V v_x1_241189 = heff_get_n(v_t_241188, 6, 9);
  V v_t_241190;
  if ((heff_dup(v_x1_241189) == NTAG(TAG_True))) {
    heff_drop(v_x1_241189);
    v_t_241190 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241189);
    v_t_241190 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241191 = heff_tr(heff_call(v_one_241186, 1, (V[]){v_a_241187}));
  return (g_std_2edoc_2e_3c_3e(v_t_241190, v_t_241191));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241199 = args[0];
  V v_one_241198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241200 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241199));
  V v_x1_241201 = heff_get_n(v_t_241200, 6, 9);
  V v_t_241202;
  if ((heff_dup(v_x1_241201) == NTAG(TAG_True))) {
    heff_drop(v_x1_241201);
    v_t_241202 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241201);
    v_t_241202 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241203 = heff_tr(heff_call(v_one_241198, 1, (V[]){v_a_241199}));
  return (g_std_2edoc_2e_3c_3e(v_t_241202, v_t_241203));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241211 = args[0];
  V v_one_241210 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241212 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241211));
  V v_x1_241213 = heff_get_n(v_t_241212, 6, 9);
  V v_t_241214;
  if ((heff_dup(v_x1_241213) == NTAG(TAG_True))) {
    heff_drop(v_x1_241213);
    v_t_241214 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241213);
    v_t_241214 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241215 = heff_tr(heff_call(v_one_241210, 1, (V[]){v_a_241211}));
  return (g_std_2edoc_2e_3c_3e(v_t_241214, v_t_241215));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241223 = args[0];
  V v_one_241222 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241224 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241223));
  V v_x1_241225 = heff_get_n(v_t_241224, 6, 9);
  V v_t_241226;
  if ((heff_dup(v_x1_241225) == NTAG(TAG_True))) {
    heff_drop(v_x1_241225);
    v_t_241226 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241225);
    v_t_241226 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241227 = heff_tr(heff_call(v_one_241222, 1, (V[]){v_a_241223}));
  return (g_std_2edoc_2e_3c_3e(v_t_241226, v_t_241227));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241235 = args[0];
  V v_one_241234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241236 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241235));
  V v_x1_241237 = heff_get_n(v_t_241236, 6, 9);
  V v_t_241238;
  if ((heff_dup(v_x1_241237) == NTAG(TAG_True))) {
    heff_drop(v_x1_241237);
    v_t_241238 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241237);
    v_t_241238 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241239 = heff_tr(heff_call(v_one_241234, 1, (V[]){v_a_241235}));
  return (g_std_2edoc_2e_3c_3e(v_t_241238, v_t_241239));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241247 = args[0];
  V v_one_241246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241248 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241247));
  V v_x1_241249 = heff_get_n(v_t_241248, 6, 9);
  V v_t_241250;
  if ((heff_dup(v_x1_241249) == NTAG(TAG_True))) {
    heff_drop(v_x1_241249);
    v_t_241250 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241249);
    v_t_241250 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241251 = heff_tr(heff_call(v_one_241246, 1, (V[]){v_a_241247}));
  return (g_std_2edoc_2e_3c_3e(v_t_241250, v_t_241251));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241259 = args[0];
  V v_one_241258 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241260 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241259));
  V v_x1_241261 = heff_get_n(v_t_241260, 6, 9);
  V v_t_241262;
  if ((heff_dup(v_x1_241261) == NTAG(TAG_True))) {
    heff_drop(v_x1_241261);
    v_t_241262 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241261);
    v_t_241262 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241263 = heff_tr(heff_call(v_one_241258, 1, (V[]){v_a_241259}));
  return (g_std_2edoc_2e_3c_3e(v_t_241262, v_t_241263));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241271 = args[0];
  V v_one_241270 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241272 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241271));
  V v_x1_241273 = heff_get_n(v_t_241272, 6, 9);
  V v_t_241274;
  if ((heff_dup(v_x1_241273) == NTAG(TAG_True))) {
    heff_drop(v_x1_241273);
    v_t_241274 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241273);
    v_t_241274 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241275 = heff_tr(heff_call(v_one_241270, 1, (V[]){v_a_241271}));
  return (g_std_2edoc_2e_3c_3e(v_t_241274, v_t_241275));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241283 = args[0];
  V v_one_241282 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241284 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241283));
  V v_x1_241285 = heff_get_n(v_t_241284, 6, 9);
  V v_t_241286;
  if ((heff_dup(v_x1_241285) == NTAG(TAG_True))) {
    heff_drop(v_x1_241285);
    v_t_241286 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241285);
    v_t_241286 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241287 = heff_tr(heff_call(v_one_241282, 1, (V[]){v_a_241283}));
  return (g_std_2edoc_2e_3c_3e(v_t_241286, v_t_241287));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241296 = args[0];
  V v_one_241295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241297 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241296));
  V v_x1_241298 = heff_get_n(v_t_241297, 6, 9);
  V v_t_241299;
  if ((heff_dup(v_x1_241298) == NTAG(TAG_True))) {
    heff_drop(v_x1_241298);
    v_t_241299 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241298);
    v_t_241299 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241300 = heff_tr(heff_call(v_one_241295, 1, (V[]){v_a_241296}));
  return (g_std_2edoc_2e_3c_3e(v_t_241299, v_t_241300));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241308 = args[0];
  V v_one_241307 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241309 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241308));
  V v_x1_241310 = heff_get_n(v_t_241309, 6, 9);
  V v_t_241311;
  if ((heff_dup(v_x1_241310) == NTAG(TAG_True))) {
    heff_drop(v_x1_241310);
    v_t_241311 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241310);
    v_t_241311 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241312 = heff_tr(heff_call(v_one_241307, 1, (V[]){v_a_241308}));
  return (g_std_2edoc_2e_3c_3e(v_t_241311, v_t_241312));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241320 = args[0];
  V v_one_241319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241321 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241320));
  V v_x1_241322 = heff_get_n(v_t_241321, 6, 9);
  V v_t_241323;
  if ((heff_dup(v_x1_241322) == NTAG(TAG_True))) {
    heff_drop(v_x1_241322);
    v_t_241323 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241322);
    v_t_241323 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241324 = heff_tr(heff_call(v_one_241319, 1, (V[]){v_a_241320}));
  return (g_std_2edoc_2e_3c_3e(v_t_241323, v_t_241324));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241332 = args[0];
  V v_one_241331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241333 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241332));
  V v_x1_241334 = heff_get_n(v_t_241333, 6, 9);
  V v_t_241335;
  if ((heff_dup(v_x1_241334) == NTAG(TAG_True))) {
    heff_drop(v_x1_241334);
    v_t_241335 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241334);
    v_t_241335 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241336 = heff_tr(heff_call(v_one_241331, 1, (V[]){v_a_241332}));
  return (g_std_2edoc_2e_3c_3e(v_t_241335, v_t_241336));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241344 = args[0];
  V v_one_241343 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241345 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241344));
  V v_x1_241346 = heff_get_n(v_t_241345, 6, 9);
  V v_t_241347;
  if ((heff_dup(v_x1_241346) == NTAG(TAG_True))) {
    heff_drop(v_x1_241346);
    v_t_241347 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241346);
    v_t_241347 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241348 = heff_tr(heff_call(v_one_241343, 1, (V[]){v_a_241344}));
  return (g_std_2edoc_2e_3c_3e(v_t_241347, v_t_241348));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241356 = args[0];
  V v_one_241355 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241357 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241356));
  V v_x1_241358 = heff_get_n(v_t_241357, 6, 9);
  V v_t_241359;
  if ((heff_dup(v_x1_241358) == NTAG(TAG_True))) {
    heff_drop(v_x1_241358);
    v_t_241359 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241358);
    v_t_241359 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241360 = heff_tr(heff_call(v_one_241355, 1, (V[]){v_a_241356}));
  return (g_std_2edoc_2e_3c_3e(v_t_241359, v_t_241360));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241369 = args[0];
  V v_one_241368 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241370 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241369));
  V v_x1_241371 = heff_get_n(v_t_241370, 6, 9);
  V v_t_241372;
  if ((heff_dup(v_x1_241371) == NTAG(TAG_True))) {
    heff_drop(v_x1_241371);
    v_t_241372 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241371);
    v_t_241372 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241373 = heff_tr(heff_call(v_one_241368, 1, (V[]){v_a_241369}));
  return (g_std_2edoc_2e_3c_3e(v_t_241372, v_t_241373));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241381 = args[0];
  V v_one_241380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241382 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241381));
  V v_x1_241383 = heff_get_n(v_t_241382, 6, 9);
  V v_t_241384;
  if ((heff_dup(v_x1_241383) == NTAG(TAG_True))) {
    heff_drop(v_x1_241383);
    v_t_241384 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241383);
    v_t_241384 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241385 = heff_tr(heff_call(v_one_241380, 1, (V[]){v_a_241381}));
  return (g_std_2edoc_2e_3c_3e(v_t_241384, v_t_241385));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241392 = args[0];
  V v_one_241391 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241393 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241392));
  V v_x1_241394 = heff_get_n(v_t_241393, 6, 9);
  V v_t_241395;
  if ((heff_dup(v_x1_241394) == NTAG(TAG_True))) {
    heff_drop(v_x1_241394);
    v_t_241395 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241394);
    v_t_241395 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241396 = heff_tr(heff_call(v_one_241391, 1, (V[]){v_a_241392}));
  return (g_std_2edoc_2e_3c_3e(v_t_241395, v_t_241396));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241404 = args[0];
  V v_one_241403 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241405 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241404));
  V v_x1_241406 = heff_get_n(v_t_241405, 6, 9);
  V v_t_241407;
  if ((heff_dup(v_x1_241406) == NTAG(TAG_True))) {
    heff_drop(v_x1_241406);
    v_t_241407 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241406);
    v_t_241407 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241408 = heff_tr(heff_call(v_one_241403, 1, (V[]){v_a_241404}));
  return (g_std_2edoc_2e_3c_3e(v_t_241407, v_t_241408));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241417 = args[0];
  V v_one_241416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241418 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241417));
  V v_x1_241419 = heff_get_n(v_t_241418, 6, 9);
  V v_t_241420;
  if ((heff_dup(v_x1_241419) == NTAG(TAG_True))) {
    heff_drop(v_x1_241419);
    v_t_241420 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241419);
    v_t_241420 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241421 = heff_tr(heff_call(v_one_241416, 1, (V[]){v_a_241417}));
  return (g_std_2edoc_2e_3c_3e(v_t_241420, v_t_241421));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241429 = args[0];
  V v_one_241428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241430 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241429));
  V v_x1_241431 = heff_get_n(v_t_241430, 6, 9);
  V v_t_241432;
  if ((heff_dup(v_x1_241431) == NTAG(TAG_True))) {
    heff_drop(v_x1_241431);
    v_t_241432 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241431);
    v_t_241432 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241433 = heff_tr(heff_call(v_one_241428, 1, (V[]){v_a_241429}));
  return (g_std_2edoc_2e_3c_3e(v_t_241432, v_t_241433));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241444 = args[0];
  V v_one_241443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241445 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241444));
  V v_x1_241446 = heff_get_n(v_t_241445, 6, 9);
  V v_t_241447;
  if ((heff_dup(v_x1_241446) == NTAG(TAG_True))) {
    heff_drop(v_x1_241446);
    v_t_241447 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241446);
    v_t_241447 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241448 = heff_tr(heff_call(v_one_241443, 1, (V[]){v_a_241444}));
  return (g_std_2edoc_2e_3c_3e(v_t_241447, v_t_241448));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241456 = args[0];
  V v_one_241455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241457 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241456));
  V v_x1_241458 = heff_get_n(v_t_241457, 6, 9);
  V v_t_241459;
  if ((heff_dup(v_x1_241458) == NTAG(TAG_True))) {
    heff_drop(v_x1_241458);
    v_t_241459 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241458);
    v_t_241459 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241460 = heff_tr(heff_call(v_one_241455, 1, (V[]){v_a_241456}));
  return (g_std_2edoc_2e_3c_3e(v_t_241459, v_t_241460));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241470 = args[0];
  V v_one_241469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241471 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241470));
  V v_x1_241472 = heff_get_n(v_t_241471, 6, 9);
  V v_t_241473;
  if ((heff_dup(v_x1_241472) == NTAG(TAG_True))) {
    heff_drop(v_x1_241472);
    v_t_241473 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241472);
    v_t_241473 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241474 = heff_tr(heff_call(v_one_241469, 1, (V[]){v_a_241470}));
  return (g_std_2edoc_2e_3c_3e(v_t_241473, v_t_241474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241482 = args[0];
  V v_one_241481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241483 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241482));
  V v_x1_241484 = heff_get_n(v_t_241483, 6, 9);
  V v_t_241485;
  if ((heff_dup(v_x1_241484) == NTAG(TAG_True))) {
    heff_drop(v_x1_241484);
    v_t_241485 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241484);
    v_t_241485 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241486 = heff_tr(heff_call(v_one_241481, 1, (V[]){v_a_241482}));
  return (g_std_2edoc_2e_3c_3e(v_t_241485, v_t_241486));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241496 = args[0];
  V v_one_241495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241497 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241496));
  V v_x1_241498 = heff_get_n(v_t_241497, 6, 9);
  V v_t_241499;
  if ((heff_dup(v_x1_241498) == NTAG(TAG_True))) {
    heff_drop(v_x1_241498);
    v_t_241499 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241498);
    v_t_241499 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241500 = heff_tr(heff_call(v_one_241495, 1, (V[]){v_a_241496}));
  return (g_std_2edoc_2e_3c_3e(v_t_241499, v_t_241500));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241508 = args[0];
  V v_one_241507 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241509 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241508));
  V v_x1_241510 = heff_get_n(v_t_241509, 6, 9);
  V v_t_241511;
  if ((heff_dup(v_x1_241510) == NTAG(TAG_True))) {
    heff_drop(v_x1_241510);
    v_t_241511 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241510);
    v_t_241511 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241512 = heff_tr(heff_call(v_one_241507, 1, (V[]){v_a_241508}));
  return (g_std_2edoc_2e_3c_3e(v_t_241511, v_t_241512));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241521 = args[0];
  V v_one_241520 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241522 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241521));
  V v_x1_241523 = heff_get_n(v_t_241522, 6, 9);
  V v_t_241524;
  if ((heff_dup(v_x1_241523) == NTAG(TAG_True))) {
    heff_drop(v_x1_241523);
    v_t_241524 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241523);
    v_t_241524 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241525 = heff_tr(heff_call(v_one_241520, 1, (V[]){v_a_241521}));
  return (g_std_2edoc_2e_3c_3e(v_t_241524, v_t_241525));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241533 = args[0];
  V v_one_241532 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241534 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241533));
  V v_x1_241535 = heff_get_n(v_t_241534, 6, 9);
  V v_t_241536;
  if ((heff_dup(v_x1_241535) == NTAG(TAG_True))) {
    heff_drop(v_x1_241535);
    v_t_241536 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241535);
    v_t_241536 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241537 = heff_tr(heff_call(v_one_241532, 1, (V[]){v_a_241533}));
  return (g_std_2edoc_2e_3c_3e(v_t_241536, v_t_241537));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241549 = args[0];
  V v_one_241548 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241550 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241549));
  V v_x1_241551 = heff_get_n(v_t_241550, 6, 9);
  V v_t_241552;
  if ((heff_dup(v_x1_241551) == NTAG(TAG_True))) {
    heff_drop(v_x1_241551);
    v_t_241552 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241551);
    v_t_241552 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241553 = heff_tr(heff_call(v_one_241548, 1, (V[]){v_a_241549}));
  return (g_std_2edoc_2e_3c_3e(v_t_241552, v_t_241553));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241561 = args[0];
  V v_one_241560 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241562 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241561));
  V v_x1_241563 = heff_get_n(v_t_241562, 6, 9);
  V v_t_241564;
  if ((heff_dup(v_x1_241563) == NTAG(TAG_True))) {
    heff_drop(v_x1_241563);
    v_t_241564 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241563);
    v_t_241564 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241565 = heff_tr(heff_call(v_one_241560, 1, (V[]){v_a_241561}));
  return (g_std_2edoc_2e_3c_3e(v_t_241564, v_t_241565));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241573 = args[0];
  V v_one_241572 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241574 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241573));
  V v_x1_241575 = heff_get_n(v_t_241574, 6, 9);
  V v_t_241576;
  if ((heff_dup(v_x1_241575) == NTAG(TAG_True))) {
    heff_drop(v_x1_241575);
    v_t_241576 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241575);
    v_t_241576 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241577 = heff_tr(heff_call(v_one_241572, 1, (V[]){v_a_241573}));
  return (g_std_2edoc_2e_3c_3e(v_t_241576, v_t_241577));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241585 = args[0];
  V v_one_241584 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241586 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241585));
  V v_x1_241587 = heff_get_n(v_t_241586, 6, 9);
  V v_t_241588;
  if ((heff_dup(v_x1_241587) == NTAG(TAG_True))) {
    heff_drop(v_x1_241587);
    v_t_241588 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241587);
    v_t_241588 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241589 = heff_tr(heff_call(v_one_241584, 1, (V[]){v_a_241585}));
  return (g_std_2edoc_2e_3c_3e(v_t_241588, v_t_241589));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241598 = args[0];
  V v_one_241597 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241599 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241598));
  V v_x1_241600 = heff_get_n(v_t_241599, 6, 9);
  V v_t_241601;
  if ((heff_dup(v_x1_241600) == NTAG(TAG_True))) {
    heff_drop(v_x1_241600);
    v_t_241601 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241600);
    v_t_241601 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241602 = heff_tr(heff_call(v_one_241597, 1, (V[]){v_a_241598}));
  return (g_std_2edoc_2e_3c_3e(v_t_241601, v_t_241602));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241610 = args[0];
  V v_one_241609 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241611 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241610));
  V v_x1_241612 = heff_get_n(v_t_241611, 6, 9);
  V v_t_241613;
  if ((heff_dup(v_x1_241612) == NTAG(TAG_True))) {
    heff_drop(v_x1_241612);
    v_t_241613 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241612);
    v_t_241613 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241614 = heff_tr(heff_call(v_one_241609, 1, (V[]){v_a_241610}));
  return (g_std_2edoc_2e_3c_3e(v_t_241613, v_t_241614));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241626 = args[0];
  V v_one_241625 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241627 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241626));
  V v_x1_241628 = heff_get_n(v_t_241627, 6, 9);
  V v_t_241629;
  if ((heff_dup(v_x1_241628) == NTAG(TAG_True))) {
    heff_drop(v_x1_241628);
    v_t_241629 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241628);
    v_t_241629 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241630 = heff_tr(heff_call(v_one_241625, 1, (V[]){v_a_241626}));
  return (g_std_2edoc_2e_3c_3e(v_t_241629, v_t_241630));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241638 = args[0];
  V v_one_241637 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241639 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241638));
  V v_x1_241640 = heff_get_n(v_t_241639, 6, 9);
  V v_t_241641;
  if ((heff_dup(v_x1_241640) == NTAG(TAG_True))) {
    heff_drop(v_x1_241640);
    v_t_241641 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241640);
    v_t_241641 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241642 = heff_tr(heff_call(v_one_241637, 1, (V[]){v_a_241638}));
  return (g_std_2edoc_2e_3c_3e(v_t_241641, v_t_241642));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_env_24870 = args[0];
  V v_h_24871 = args[1];
  V v_args_24872 = args[2];
  V v_x1_24873 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24872)));
  V v_t_24877;
  switch (heff_tag_of(v_x1_24873)) {
  case TAG_Nil: {
    v_t_24877 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_24874 = heff_field(v_x1_24873, 0);
    V v_rev_24875 = heff_field(v_x1_24873, 1);
    V v_ru_24x1_24873_24Cons = heff_take_reuse_n(v_x1_24873, 3ULL, 2);
    V v_t_24876 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24875));
    v_t_24877 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_24873_24Cons, TAG_MkPair, 2, (V[]){v_t_24876, v_x_24874})});
    break;
  }
  default: heff_nomatch(v_x1_24873);
  }
  switch (heff_tag_of(v_t_24877)) {
  case TAG_Nothing: {
    heff_drop(v_args_24872);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24870;
    args[1] = v_h_24871;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Just: {
    V v_pr_24878 = heff_field(v_t_24877, 0);
    V v_ru_24t_24877_24Just = heff_take_reuse_n(v_t_24877, 1ULL, 1);
    switch (heff_tag_of(v_pr_24878)) {
    case TAG_MkPair: {
      V v_init2_24879 = heff_field(v_pr_24878, 0);
      V v_lastA_24880 = heff_field(v_pr_24878, 1);
      V v_ru_24pr_24878_24MkPair = heff_take_reuse_n(v_pr_24878, 3ULL, 2);
      switch (heff_tag_of(v_lastA_24880)) {
      case TAG_Atom: {
        V v_t_24882 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_24882) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_24882);
          V v_t_24883 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24884 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_24890 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_one_24884}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_24891 = (g_std_2edoc_2e_3c_3e(v_t_24883, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24890})));
          V v_a_24892 = (g_std_2edoc_2egroup(v_t_24891));
          V v_b_24893 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_24894 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_b_24893));
          return (g_std_2edoc_2e_3c_3e(v_a_24892, v_t_24894));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 1);
          heff_drop(v_t_24882);
          V v_t_24895 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24896 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_24902 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 1, (V[]){v_one_24896}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_24903 = (g_std_2edoc_2e_3c_3e(v_t_24895, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24902})));
          return (g_std_2edoc_2egroup(v_t_24903));
        }
      }
      case TAG_EParen: {
        V v_o_24904 = heff_field(v_lastA_24880, 0);
        V v_e_24905 = heff_field(v_lastA_24880, 1);
        V v_c_24906 = heff_field(v_lastA_24880, 2);
        heff_take_n(v_lastA_24880, 7ULL, 3);
        V v_t_24907 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24905));
        if ((heff_dup(v_t_24907) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_24907);
          V v_t_24908 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24909 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_24915 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){v_one_24909}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_24916 = (g_std_2edoc_2e_3c_3e(v_t_24908, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24915})));
          V v_a_24917 = (g_std_2edoc_2egroup(v_t_24916));
          V v_b_24918 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24870), v_o_24904));
          V v_t_24919 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_b_24918));
          V v_t_24920 = (g_std_2edoc_2e_3c_3e(v_a_24917, v_t_24919));
          V v_t_24921 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_e_24905}));
          V v_t_24922 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24870, v_c_24906));
          V v_t_24923 = (g_std_2edoc_2e_3c_3e(v_t_24921, v_t_24922));
          return (g_std_2edoc_2e_3c_3e(v_t_24920, v_t_24923));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop(v_o_24904);
          heff_drop(v_e_24905);
          heff_drop(v_c_24906);
          heff_drop(v_t_24907);
          V v_t_24924 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24925 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_24931 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 1, (V[]){v_one_24925}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_24932 = (g_std_2edoc_2e_3c_3e(v_t_24924, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24931})));
          return (g_std_2edoc_2egroup(v_t_24932));
        }
      }
      case TAG_Named: {
        V v_t_24938 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_24938) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_24938);
          V v_t_24939 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24940 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_24946 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){v_one_24940}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_24947 = (g_std_2edoc_2e_3c_3e(v_t_24939, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24946})));
          V v_a_24948 = (g_std_2edoc_2egroup(v_t_24947));
          V v_b_24949 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_24950 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24949));
          return (g_std_2edoc_2e_3c_3e(v_a_24948, v_t_24950));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 5);
          heff_drop(v_t_24938);
          V v_t_24951 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24952 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_24958 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 1, (V[]){v_one_24952}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_24959 = (g_std_2edoc_2e_3c_3e(v_t_24951, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24958})));
          return (g_std_2edoc_2egroup(v_t_24959));
        }
      }
      case TAG_Tup: {
        V v_t_24964 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_24964) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_24964);
          V v_t_24965 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24966 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_24972 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_one_24966}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_24973 = (g_std_2edoc_2e_3c_3e(v_t_24965, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24972})));
          V v_a_24974 = (g_std_2edoc_2egroup(v_t_24973));
          V v_b_24975 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_24976 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24975));
          return (g_std_2edoc_2e_3c_3e(v_a_24974, v_t_24976));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 4);
          heff_drop(v_t_24964);
          V v_t_24977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24978 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_24984 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){v_one_24978}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_24985 = (g_std_2edoc_2e_3c_3e(v_t_24977, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24984})));
          return (g_std_2edoc_2egroup(v_t_24985));
        }
      }
      case TAG_Seg: {
        V v_t_24989 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_24989) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_24989);
          V v_t_24990 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_24991 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_24997 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_one_24991}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_24998 = (g_std_2edoc_2e_3c_3e(v_t_24990, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24997})));
          V v_a_24999 = (g_std_2edoc_2egroup(v_t_24998));
          V v_b_241000 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241001 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_b_241000));
          return (g_std_2edoc_2e_3c_3e(v_a_24999, v_t_241001));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_24989);
          V v_t_241002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241003 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241009 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_one_241003}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241010 = (g_std_2edoc_2e_3c_3e(v_t_241002, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241009})));
          return (g_std_2edoc_2egroup(v_t_241010));
        }
      }
      case TAG_Braces: {
        V v_t_241015 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241015) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241015);
          V v_t_241016 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241017 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241023 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241017}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241024 = (g_std_2edoc_2e_3c_3e(v_t_241016, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241023})));
          V v_a_241025 = (g_std_2edoc_2egroup(v_t_241024));
          V v_b_241026 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241027 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_241026));
          return (g_std_2edoc_2e_3c_3e(v_a_241025, v_t_241027));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 4);
          heff_drop(v_t_241015);
          V v_t_241028 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241029 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241035 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241029}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241036 = (g_std_2edoc_2e_3c_3e(v_t_241028, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241035})));
          return (g_std_2edoc_2egroup(v_t_241036));
        }
      }
      case TAG_Update: {
        V v_t_241043 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241043) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241043);
          V v_t_241044 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241045 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241051 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241045}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241052 = (g_std_2edoc_2e_3c_3e(v_t_241044, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241051})));
          V v_a_241053 = (g_std_2edoc_2egroup(v_t_241052));
          V v_b_241054 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241055 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_241054));
          return (g_std_2edoc_2e_3c_3e(v_a_241053, v_t_241055));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 6);
          heff_drop(v_t_241043);
          V v_t_241056 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241057 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241063 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241057}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241064 = (g_std_2edoc_2e_3c_3e(v_t_241056, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241063})));
          return (g_std_2edoc_2egroup(v_t_241064));
        }
      }
      case TAG_EUSet: {
        V v_t_241068 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241068) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241068);
          V v_t_241069 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241070 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241076 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241070}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241077 = (g_std_2edoc_2e_3c_3e(v_t_241069, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241076})));
          V v_a_241078 = (g_std_2edoc_2egroup(v_t_241077));
          V v_b_241079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241080 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_241079));
          return (g_std_2edoc_2e_3c_3e(v_a_241078, v_t_241080));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241068);
          V v_t_241081 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241082 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241088 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241082}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241089 = (g_std_2edoc_2e_3c_3e(v_t_241081, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241088})));
          return (g_std_2edoc_2egroup(v_t_241089));
        }
      }
      case TAG_InstB: {
        V v_t_241095 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241095) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241095);
          V v_t_241096 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241097 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241103 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241097}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241104 = (g_std_2edoc_2e_3c_3e(v_t_241096, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241103})));
          V v_a_241105 = (g_std_2edoc_2egroup(v_t_241104));
          V v_b_241106 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241107 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_241106));
          return (g_std_2edoc_2e_3c_3e(v_a_241105, v_t_241107));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 5);
          heff_drop(v_t_241095);
          V v_t_241108 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241109 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241115 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241109}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241116 = (g_std_2edoc_2e_3c_3e(v_t_241108, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241115})));
          return (g_std_2edoc_2egroup(v_t_241116));
        }
      }
      case TAG_EFSet: {
        V v_t_241120 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241120) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241120);
          V v_t_241121 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241122 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241128 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241122}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241129 = (g_std_2edoc_2e_3c_3e(v_t_241121, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241128})));
          V v_a_241130 = (g_std_2edoc_2egroup(v_t_241129));
          V v_b_241131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241132 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_241131));
          return (g_std_2edoc_2e_3c_3e(v_a_241130, v_t_241132));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241120);
          V v_t_241133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241140 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241134}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241141 = (g_std_2edoc_2e_3c_3e(v_t_241133, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241140})));
          return (g_std_2edoc_2egroup(v_t_241141));
        }
      }
      case TAG_EFDefault: {
        V v_t_241145 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241145) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241145);
          V v_t_241146 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241153 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241147}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241154 = (g_std_2edoc_2e_3c_3e(v_t_241146, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241153})));
          V v_a_241155 = (g_std_2edoc_2egroup(v_t_241154));
          V v_b_241156 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241157 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_241156));
          return (g_std_2edoc_2e_3c_3e(v_a_241155, v_t_241157));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241145);
          V v_t_241158 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241159 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241165 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241159}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241166 = (g_std_2edoc_2e_3c_3e(v_t_241158, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241165})));
          return (g_std_2edoc_2egroup(v_t_241166));
        }
      }
      case TAG_Sum: {
        V v_t_241172 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241172) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241172);
          V v_t_241173 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241174 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241180 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241174}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241181 = (g_std_2edoc_2e_3c_3e(v_t_241173, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241180})));
          V v_a_241182 = (g_std_2edoc_2egroup(v_t_241181));
          V v_b_241183 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241184 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), v_b_241183));
          return (g_std_2edoc_2e_3c_3e(v_a_241182, v_t_241184));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 5);
          heff_drop(v_t_241172);
          V v_t_241185 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241192 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241186}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241193 = (g_std_2edoc_2e_3c_3e(v_t_241185, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241192})));
          return (g_std_2edoc_2egroup(v_t_241193));
        }
      }
      case TAG_ECon: {
        V v_t_241196 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241196) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241196);
          V v_t_241197 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241204 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241198}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241205 = (g_std_2edoc_2e_3c_3e(v_t_241197, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241204})));
          V v_a_241206 = (g_std_2edoc_2egroup(v_t_241205));
          V v_b_241207 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241208 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_241207));
          return (g_std_2edoc_2e_3c_3e(v_a_241206, v_t_241208));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241196);
          V v_t_241209 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241216 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241210}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241217 = (g_std_2edoc_2e_3c_3e(v_t_241209, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241216})));
          return (g_std_2edoc_2egroup(v_t_241217));
        }
      }
      case TAG_EField: {
        V v_t_241220 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241220) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241220);
          V v_t_241221 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241228 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241222}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241229 = (g_std_2edoc_2e_3c_3e(v_t_241221, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241228})));
          V v_a_241230 = (g_std_2edoc_2egroup(v_t_241229));
          V v_b_241231 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241232 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), v_b_241231));
          return (g_std_2edoc_2e_3c_3e(v_a_241230, v_t_241232));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241220);
          V v_t_241233 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241234 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241240 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241234}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241241 = (g_std_2edoc_2e_3c_3e(v_t_241233, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241240})));
          return (g_std_2edoc_2egroup(v_t_241241));
        }
      }
      case TAG_ENeg: {
        V v_t_241244 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241244) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241244);
          V v_t_241245 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241246 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241252 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241246}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241253 = (g_std_2edoc_2e_3c_3e(v_t_241245, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241252})));
          V v_a_241254 = (g_std_2edoc_2egroup(v_t_241253));
          V v_b_241255 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241256 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), v_b_241255));
          return (g_std_2edoc_2e_3c_3e(v_a_241254, v_t_241256));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241244);
          V v_t_241257 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241258 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241264 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241258}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241265 = (g_std_2edoc_2e_3c_3e(v_t_241257, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241264})));
          return (g_std_2edoc_2egroup(v_t_241265));
        }
      }
      case TAG_App: {
        V v_t_241268 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241268) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241268);
          V v_t_241269 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241270 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241276 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241270}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241277 = (g_std_2edoc_2e_3c_3e(v_t_241269, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241276})));
          V v_a_241278 = (g_std_2edoc_2egroup(v_t_241277));
          V v_b_241279 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241280 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241279));
          return (g_std_2edoc_2e_3c_3e(v_a_241278, v_t_241280));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241268);
          V v_t_241281 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241282 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241288 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241282}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241289 = (g_std_2edoc_2e_3c_3e(v_t_241281, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241288})));
          return (g_std_2edoc_2egroup(v_t_241289));
        }
      }
      case TAG_Op: {
        V v_t_241293 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241293) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241293);
          V v_t_241294 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241295 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241301 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241295}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241302 = (g_std_2edoc_2e_3c_3e(v_t_241294, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241301})));
          V v_a_241303 = (g_std_2edoc_2egroup(v_t_241302));
          V v_b_241304 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241305 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), v_b_241304));
          return (g_std_2edoc_2e_3c_3e(v_a_241303, v_t_241305));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241293);
          V v_t_241306 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241313 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241307}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241314 = (g_std_2edoc_2e_3c_3e(v_t_241306, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241313})));
          return (g_std_2edoc_2egroup(v_t_241314));
        }
      }
      case TAG_Ops: {
        V v_t_241317 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241317) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241317);
          V v_t_241318 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241319 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241325 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241319}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241326 = (g_std_2edoc_2e_3c_3e(v_t_241318, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241325})));
          V v_a_241327 = (g_std_2edoc_2egroup(v_t_241326));
          V v_b_241328 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241329 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), v_b_241328));
          return (g_std_2edoc_2e_3c_3e(v_a_241327, v_t_241329));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241317);
          V v_t_241330 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241337 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241331}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241338 = (g_std_2edoc_2e_3c_3e(v_t_241330, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241337})));
          return (g_std_2edoc_2egroup(v_t_241338));
        }
      }
      case TAG_OpRhs: {
        V v_t_241341 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241341) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241341);
          V v_t_241342 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241343 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241349 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241343}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241350 = (g_std_2edoc_2e_3c_3e(v_t_241342, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241349})));
          V v_a_241351 = (g_std_2edoc_2egroup(v_t_241350));
          V v_b_241352 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241353 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), v_b_241352));
          return (g_std_2edoc_2e_3c_3e(v_a_241351, v_t_241353));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241341);
          V v_t_241354 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241355 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241361 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241355}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241362 = (g_std_2edoc_2e_3c_3e(v_t_241354, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241361})));
          return (g_std_2edoc_2egroup(v_t_241362));
        }
      }
      case TAG_Ann: {
        V v_t_241366 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241366) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241366);
          V v_t_241367 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241368 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241374 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241368}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241375 = (g_std_2edoc_2e_3c_3e(v_t_241367, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241374})));
          V v_a_241376 = (g_std_2edoc_2egroup(v_t_241375));
          V v_b_241377 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241378 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241377));
          return (g_std_2edoc_2e_3c_3e(v_a_241376, v_t_241378));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241366);
          V v_t_241379 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241380 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241386 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241380}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241387 = (g_std_2edoc_2e_3c_3e(v_t_241379, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241386})));
          return (g_std_2edoc_2egroup(v_t_241387));
        }
      }
      case TAG_BVar: {
        V v_t_241389 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241389) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241389);
          V v_t_241390 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241391 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241397 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241391}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241398 = (g_std_2edoc_2e_3c_3e(v_t_241390, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241397})));
          V v_a_241399 = (g_std_2edoc_2egroup(v_t_241398));
          V v_b_241400 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241401 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), v_b_241400));
          return (g_std_2edoc_2e_3c_3e(v_a_241399, v_t_241401));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 1);
          heff_drop(v_t_241389);
          V v_t_241402 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241403 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241409 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241403}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241410 = (g_std_2edoc_2e_3c_3e(v_t_241402, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241409})));
          return (g_std_2edoc_2egroup(v_t_241410));
        }
      }
      case TAG_BImp: {
        V v_t_241414 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241414) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241414);
          V v_t_241415 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241422 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241416}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241423 = (g_std_2edoc_2e_3c_3e(v_t_241415, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241422})));
          V v_a_241424 = (g_std_2edoc_2egroup(v_t_241423));
          V v_b_241425 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241426 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241425));
          return (g_std_2edoc_2e_3c_3e(v_a_241424, v_t_241426));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241414);
          V v_t_241427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241428 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241434 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241428}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241435 = (g_std_2edoc_2e_3c_3e(v_t_241427, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241434})));
          return (g_std_2edoc_2egroup(v_t_241435));
        }
      }
      case TAG_BAnn: {
        V v_t_241441 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241441) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241441);
          V v_t_241442 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241449 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241443}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241450 = (g_std_2edoc_2e_3c_3e(v_t_241442, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241449})));
          V v_a_241451 = (g_std_2edoc_2egroup(v_t_241450));
          V v_b_241452 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241453 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241452));
          return (g_std_2edoc_2e_3c_3e(v_a_241451, v_t_241453));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 5);
          heff_drop(v_t_241441);
          V v_t_241454 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241455 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241461 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241455}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241462 = (g_std_2edoc_2e_3c_3e(v_t_241454, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241461})));
          return (g_std_2edoc_2egroup(v_t_241462));
        }
      }
      case TAG_Lam: {
        V v_t_241467 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241467) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241467);
          V v_t_241468 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241469 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241469}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241476 = (g_std_2edoc_2e_3c_3e(v_t_241468, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241475})));
          V v_a_241477 = (g_std_2edoc_2egroup(v_t_241476));
          V v_b_241478 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241479 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), v_b_241478));
          return (g_std_2edoc_2e_3c_3e(v_a_241477, v_t_241479));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 4);
          heff_drop(v_t_241467);
          V v_t_241480 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241481 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241487 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241481}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241488 = (g_std_2edoc_2e_3c_3e(v_t_241480, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241487})));
          return (g_std_2edoc_2egroup(v_t_241488));
        }
      }
      case TAG_Case: {
        V v_t_241493 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241493) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241493);
          V v_t_241494 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241495 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241501 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241495}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241502 = (g_std_2edoc_2e_3c_3e(v_t_241494, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241501})));
          V v_a_241503 = (g_std_2edoc_2egroup(v_t_241502));
          V v_b_241504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241505 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), v_b_241504));
          return (g_std_2edoc_2e_3c_3e(v_a_241503, v_t_241505));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 4);
          heff_drop(v_t_241493);
          V v_t_241506 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241507 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241513 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241507}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241514 = (g_std_2edoc_2e_3c_3e(v_t_241506, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241513})));
          return (g_std_2edoc_2egroup(v_t_241514));
        }
      }
      case TAG_EAlt: {
        V v_t_241518 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241518) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241518);
          V v_t_241519 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241520 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241526 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241520}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241527 = (g_std_2edoc_2e_3c_3e(v_t_241519, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241526})));
          V v_a_241528 = (g_std_2edoc_2egroup(v_t_241527));
          V v_b_241529 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241530 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), v_b_241529));
          return (g_std_2edoc_2e_3c_3e(v_a_241528, v_t_241530));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241518);
          V v_t_241531 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241532 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241538 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241532}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241539 = (g_std_2edoc_2e_3c_3e(v_t_241531, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241538})));
          return (g_std_2edoc_2egroup(v_t_241539));
        }
      }
      case TAG_If: {
        V v_t_241546 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241546) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241546);
          V v_t_241547 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241548 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241554 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241548}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241555 = (g_std_2edoc_2e_3c_3e(v_t_241547, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241554})));
          V v_a_241556 = (g_std_2edoc_2egroup(v_t_241555));
          V v_b_241557 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241558 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), v_b_241557));
          return (g_std_2edoc_2e_3c_3e(v_a_241556, v_t_241558));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 6);
          heff_drop(v_t_241546);
          V v_t_241559 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241560 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241566 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241560}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241567 = (g_std_2edoc_2e_3c_3e(v_t_241559, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241566})));
          return (g_std_2edoc_2egroup(v_t_241567));
        }
      }
      case TAG_Do: {
        V v_t_241570 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241570) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241570);
          V v_t_241571 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241572 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241578 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241572}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241579 = (g_std_2edoc_2e_3c_3e(v_t_241571, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241578})));
          V v_a_241580 = (g_std_2edoc_2egroup(v_t_241579));
          V v_b_241581 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241582 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), v_b_241581));
          return (g_std_2edoc_2e_3c_3e(v_a_241580, v_t_241582));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 2);
          heff_drop(v_t_241570);
          V v_t_241583 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241584 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241590 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241584}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241591 = (g_std_2edoc_2e_3c_3e(v_t_241583, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241590})));
          return (g_std_2edoc_2egroup(v_t_241591));
        }
      }
      case TAG_ESBind: {
        V v_t_241595 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241595) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241595);
          V v_t_241596 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241597 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241603 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241597}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241604 = (g_std_2edoc_2e_3c_3e(v_t_241596, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241603})));
          V v_a_241605 = (g_std_2edoc_2egroup(v_t_241604));
          V v_b_241606 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241607 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), v_b_241606));
          return (g_std_2edoc_2e_3c_3e(v_a_241605, v_t_241607));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 3);
          heff_drop(v_t_241595);
          V v_t_241608 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241609 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241615 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241609}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241616 = (g_std_2edoc_2e_3c_3e(v_t_241608, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241615})));
          return (g_std_2edoc_2egroup(v_t_241616));
        }
      }
      case TAG_ELet: {
        V v_t_241623 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24880));
        if ((heff_dup(v_t_241623) == NTAG(TAG_True))) {
          heff_drop(v_args_24872);
          heff_drop(v_t_241623);
          V v_t_241624 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241625 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24870)}));
          V v_d_241631 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241625}); V a_2 = v_init2_24879; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24879); r_; });
          V v_t_241632 = (g_std_2edoc_2e_3c_3e(v_t_241624, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241631})));
          V v_a_241633 = (g_std_2edoc_2egroup(v_t_241632));
          V v_b_241634 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24870, v_lastA_24880}));
          V v_t_241635 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24877_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), v_b_241634));
          return (g_std_2edoc_2e_3c_3e(v_a_241633, v_t_241635));
        } else {
          heff_drop_cell(v_ru_24t_24877_24Just, 1);
          heff_drop(v_init2_24879);
          heff_drop_tag(v_lastA_24880, 6);
          heff_drop(v_t_241623);
          V v_t_241636 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24870), v_h_24871}));
          V v_one_241637 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24870}));
          V v_d_241643 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241637}); V a_2 = v_args_24872; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24872); r_; });
          V v_t_241644 = (g_std_2edoc_2e_3c_3e(v_t_241636, heff_tag_at_n(v_ru_24pr_24878_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241643})));
          return (g_std_2edoc_2egroup(v_t_241644));
        }
      }
      default: return heff_nomatch(v_lastA_24880);
      }
    }
    default: return heff_nomatch(v_pr_24878);
    }
  }
  default: return heff_nomatch(v_t_24877);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_env_241645 = args[0];
  V v_rest_241646 = args[1];
  V v_e_241647 = args[2];
  switch (heff_tag_of(v_e_241647)) {
  case TAG_Atom: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_241664 = heff_field(v_e_241647, 0);
    V v_fs_241665 = heff_field(v_e_241647, 1);
    V v_commas_241666 = heff_field(v_e_241647, 2);
    V v_c_241667 = heff_field(v_e_241647, 3);
    heff_take_n(v_e_241647, 15ULL, 4);
    switch (heff_tag_of(v_fs_241665)) {
    case TAG_Nil: {
      heff_drop(v_rest_241646);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_241645;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241664, v_fs_241665, v_commas_241666, v_c_241667});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_241668 = heff_dup(heff_field(v_fs_241665, 0));
      V v_rest2_241669 = heff_dup(heff_field(v_fs_241665, 1));
      switch (heff_tag_of(v_rest2_241669)) {
      case TAG_Nil: {
        V v_t_241670 = ({ V a_0 = v_rest_241646; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_241646); r_; });
        if ((heff_dup(v_t_241670) == NTAG(TAG_True))) {
          heff_drop(v_t_241670);
          V v_x1_241671 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_241668));
          if ((heff_dup(v_x1_241671) == NTAG(TAG_True))) {
            heff_drop(v_d_241668);
            heff_drop(v_x1_241671);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_241645;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241664, v_fs_241665, v_commas_241666, v_c_241667});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_241671);
            switch (heff_tag_of(v_commas_241666)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_241665, 2);
              V v_t_241672 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241645), v_o_241664));
              V v_t_241673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241645), v_d_241668}));
              V v_t_241674 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241645, v_c_241667));
              V v_t_241675 = (g_std_2edoc_2e_3c_3e(v_t_241673, v_t_241674));
              return (g_std_2edoc_2e_3c_3e(v_t_241672, v_t_241675));
            }
            case TAG_Cons: {
              heff_drop(v_d_241668);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_241645;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241664, v_fs_241665, v_commas_241666, v_c_241667});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_241666);
            }
          }
        } else {
          heff_drop(v_d_241668);
          heff_drop(v_t_241670);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_241645;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241664, v_fs_241665, v_commas_241666, v_c_241667});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_241669, 0ULL, 2);
        heff_drop(v_rest_241646);
        heff_drop(v_d_241668);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_241645;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241664, v_fs_241665, v_commas_241666, v_c_241667});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_241669);
      }
    }
    default: return heff_nomatch(v_fs_241665);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241646);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241645;
    args[1] = v_e_241647;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_241647);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_env_241760 = args[0];
  V v_b_241761 = args[1];
  switch (heff_tag_of(v_b_241761)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_241825 = heff_field(v_b_241761, 0);
    heff_take_n(v_b_241761, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241760, v_t_241825));
  }
  case TAG_BImp: {
    V v_o_241826 = heff_field(v_b_241761, 0);
    V v_x_241827 = heff_field(v_b_241761, 1);
    V v_c_241828 = heff_field(v_b_241761, 2);
    heff_take_n(v_b_241761, 7ULL, 3);
    V v_t_241829 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241760), v_o_241826));
    V v_t_241830 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241760), v_x_241827));
    V v_t_241831 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241760, v_c_241828));
    V v_t_241832 = (g_std_2edoc_2e_3c_3e(v_t_241830, v_t_241831));
    return (g_std_2edoc_2e_3c_3e(v_t_241829, v_t_241832));
  }
  case TAG_BAnn: {
    V v_o_241833 = heff_field(v_b_241761, 0);
    V v_x_241834 = heff_field(v_b_241761, 1);
    V v_cc_241835 = heff_field(v_b_241761, 2);
    V v_ty_241836 = heff_field(v_b_241761, 3);
    V v_c_241837 = heff_field(v_b_241761, 4);
    heff_take_n(v_b_241761, 31ULL, 5);
    V v_t_241838 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241760), v_o_241833));
    V v_a_241839 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241760), v_x_241834));
    V v_a_241840 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241760), v_cc_241835));
    V v_b_241841 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241760), v_ty_241836}));
    V v_t_241842 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), v_b_241841));
    V v_t_241843 = (g_std_2edoc_2e_3c_3e(v_a_241840, v_t_241842));
    V v_t_241844 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), v_t_241843));
    V v_t_241845 = (g_std_2edoc_2e_3c_3e(v_a_241839, v_t_241844));
    V v_t_241846 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241760, v_c_241837));
    V v_t_241847 = (g_std_2edoc_2e_3c_3e(v_t_241845, v_t_241846));
    return (g_std_2edoc_2e_3c_3e(v_t_241838, v_t_241847));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241760;
    args[1] = v_b_241761;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_241761);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_env_241876 = args[0];
  V v_rest_241877 = args[1];
  V v_r_241878 = args[2];
  switch (heff_tag_of(v_r_241878)) {
  case TAG_Atom: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241937 = heff_field(v_r_241878, 0);
    V v_e_241938 = heff_field(v_r_241878, 1);
    heff_take_n(v_r_241878, 3ULL, 2);
    V v_a_241939 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241876), v_op_241937));
    V v_b_241940 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_241876, v_rest_241877, v_e_241938}));
    V v_t_241941 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), v_b_241940));
    return (g_std_2edoc_2e_3c_3e(v_a_241939, v_t_241941));
  }
  case TAG_Ann: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241877);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241876;
    args[1] = v_r_241878;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241878);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_env_241982 = args[0];
  V v_r_241983 = args[1];
  switch (heff_tag_of(v_r_241983)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242042 = heff_field(v_r_241983, 0);
    V v_e_242043 = heff_field(v_r_241983, 1);
    heff_take_n(v_r_241983, 3ULL, 2);
    V v_a_242044 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241982), v_op_242042));
    V v_b_242045 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241982, v_e_242043}));
    V v_t_242046 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), v_b_242045));
    return (g_std_2edoc_2e_3c_3e(v_a_242044, v_t_242046));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241982;
    args[1] = v_r_241983;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241983);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_r_242097 = args[0];
  V v_env_242087 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242098 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242097));
  V v_t_242099;
  if ((heff_dup(v_x1_242098) == NTAG(TAG_True))) {
    heff_drop(v_x1_242098);
    v_t_242099 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242098);
    v_t_242099 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242100 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242087, v_r_242097}));
  return (g_std_2edoc_2e_3c_3e(v_t_242099, v_t_242100));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_r_242107 = args[0];
  V v_env_242087 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242108 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242107));
  V v_t_242109;
  if ((heff_dup(v_x1_242108) == NTAG(TAG_True))) {
    heff_drop(v_x1_242108);
    v_t_242109 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242108);
    v_t_242109 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242087, v_r_242107}));
  return (g_std_2edoc_2e_3c_3e(v_t_242109, v_t_242110));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_env_242087 = args[0];
  V v_first_242088 = args[1];
  V v_rest_242089 = args[2];
  V v_f_242090 = heff_dup(heff_rfield(v_env_242087, 6));
  V v_it_242091 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(heff_dup(v_f_242090), heff_dup(v_rest_242089)));
  V v_t_242095;
  switch (heff_tag_of(v_it_242091)) {
  case TAG_Nothing: {
    heff_drop(v_f_242090);
    v_t_242095 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_242092 = heff_field(v_it_242091, 0);
    heff_take_n(v_it_242091, 1ULL, 1);
    switch (heff_tag_of(v_it1_242092)) {
    case TAG_Nil: {
      heff_drop(v_f_242090);
      v_t_242095 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_o_242093 = heff_field(v_it1_242092, 0);
      V v_os_242094 = heff_field(v_it1_242092, 1);
      heff_take_n(v_it1_242092, 3ULL, 2);
      v_t_242095 = ({ V a_0 = v_f_242090; V a_1 = v_o_242093; V a_2 = v_os_242094; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_242094); r_; });
      break;
    }
    default: heff_nomatch(v_it1_242092);
    }
    break;
  }
  default: heff_nomatch(v_it_242091);
  }
  switch (heff_tag_of(v_t_242095)) {
  case TAG_Nothing: {
    V v_t_242096 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242087), v_first_242088}));
    V v_t_242101 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_env_242087}); V a_2 = v_rest_242089; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242089); r_; });
    V v_t_242102 = (g_std_2edoc_2e_3c_3e(v_t_242096, v_t_242101));
    return (g_std_2edoc_2egroup(v_t_242102));
  }
  case TAG_Just: {
    V v_m_242103 = heff_field(v_t_242095, 0);
    heff_take_n(v_t_242095, 1ULL, 1);
    V v_t_242104 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo), 2, (V[]){heff_dup(heff_rfield(v_env_242087, 6)), heff_dup(v_m_242103)}));
    V v_t_242105 = (g_list_2eall(v_t_242104, v_rest_242089));
    if ((heff_dup(v_t_242105) == NTAG(TAG_True))) {
      heff_drop(v_m_242103);
      heff_drop(v_t_242105);
      V v_t_242106 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242087), v_first_242088}));
      V v_t_242111 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_env_242087}); V a_2 = v_rest_242089; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242089); r_; });
      V v_t_242112 = (g_std_2edoc_2e_3c_3e(v_t_242106, v_t_242111));
      return (g_std_2edoc_2egroup(v_t_242112));
    } else {
      heff_drop(v_t_242105);
      V v_t_242113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242087, v_m_242103, v_first_242088, NTAG(TAG_Nil), v_rest_242089}));
      return (g_std_2edoc_2egroup(v_t_242113));
    }
  }
  default: return heff_nomatch(v_t_242095);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_env_242114 = args[0];
  V v_m_242115 = args[1];
  V v_f_242116 = args[2];
  V v_acc_242117 = args[3];
  V v_rs_242118 = args[4];
  switch (heff_tag_of(v_rs_242118)) {
  case TAG_Nil: {
    heff_drop(v_m_242115);
    V v_t_242119 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242117));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_242114;
    args[1] = v_f_242116;
    args[2] = v_t_242119;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_242120 = heff_field(v_rs_242118, 0);
    V v_rest2_242121 = heff_field(v_rs_242118, 1);
    heff_take_n(v_rs_242118, 3ULL, 2);
    switch (heff_tag_of(v_r_242120)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_242180 = heff_dup(heff_field(v_r_242120, 0));
      V v_e_242181 = heff_dup(heff_field(v_r_242120, 1));
      V v_t_242182 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_242114, 6)), heff_dup(v_m_242115), heff_dup(heff_rfield(v_op_242180, 1))));
      V v_t_242185;
      switch (heff_tag_of(v_t_242182)) {
      case TAG_Tighter: {
        v_t_242185 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_242185 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_242182, 0ULL, 1);
        v_t_242185 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_242185 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_242182, 0ULL, 1);
        v_t_242185 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_242182);
      }
      if ((heff_dup(v_t_242185) == NTAG(TAG_True))) {
        heff_drop(v_t_242185);
        V v_t_242186 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242117));
        V v_t_242187 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_242114), v_f_242116, v_t_242186}));
        V v_x1_242188 = ({ V a_0 = v_r_242120; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_242120, 2); r_; });
        V v_t_242189;
        if ((heff_dup(v_x1_242188) == NTAG(TAG_True))) {
          heff_drop(v_x1_242188);
          v_t_242189 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_242188);
          v_t_242189 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_242190 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242114), v_op_242180));
        V v_b_242191 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242114, v_m_242115, v_e_242181, NTAG(TAG_Nil), v_rest2_242121}));
        V v_t_242192 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), v_b_242191));
        V v_t_242193 = (g_std_2edoc_2e_3c_3e(v_a_242190, v_t_242192));
        V v_t_242194 = (g_std_2edoc_2e_3c_3e(v_t_242189, v_t_242193));
        return (g_std_2edoc_2e_3c_3e(v_t_242187, v_t_242194));
      } else {
        heff_drop_rec(v_op_242180, 9);
        heff_drop(v_e_242181);
        heff_drop(v_t_242185);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242114;
        args[1] = v_m_242115;
        args[2] = v_f_242116;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
        args[4] = v_rest2_242121;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242114;
      args[1] = v_m_242115;
      args[2] = v_f_242116;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242120, v_acc_242117});
      args[4] = v_rest2_242121;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_242120);
    }
  }
  default: return heff_nomatch(v_rs_242118);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_env_242235 = args[0];
  V v_a_242236 = args[1];
  switch (heff_tag_of(v_a_242236)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_242317 = heff_field(v_a_242236, 0);
    V v_arrow_242318 = heff_field(v_a_242236, 1);
    V v_body_242319 = heff_field(v_a_242236, 2);
    heff_take_n(v_a_242236, 7ULL, 3);
    V v_a_242320 = ({ V a_0 = heff_dup(v_env_242235); V a_1 = v_p_242317; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_242317); r_; });
    V v_b_242321 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242235), v_arrow_242318));
    V v_t_242322 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), v_b_242321));
    V v_t_242323 = (g_std_2edoc_2e_3c_3e(v_a_242320, v_t_242322));
    V v_t_242324 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242235, v_body_242319}));
    return (g_std_2edoc_2e_3c_3e(v_t_242323, v_t_242324));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242235;
    args[1] = v_a_242236;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_242236);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_env_242342 = args[0];
  V v_s_242343 = args[1];
  switch (heff_tag_of(v_s_242343)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_242435 = heff_field(v_s_242343, 0);
    V v_arrow_242436 = heff_field(v_s_242343, 1);
    V v_e_242437 = heff_field(v_s_242343, 2);
    heff_take_n(v_s_242343, 7ULL, 3);
    V v_a_242438 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242342), v_x_242435));
    V v_b_242439 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242342), v_arrow_242436));
    V v_t_242440 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), v_b_242439));
    V v_t_242441 = (g_std_2edoc_2e_3c_3e(v_a_242438, v_t_242440));
    V v_t_242442 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242342, v_e_242437}));
    return (g_std_2edoc_2e_3c_3e(v_t_242441, v_t_242442));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242342;
    args[1] = v_s_242343;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_242343);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_env_242449 = args[0];
  V v_f_242450 = args[1];
  switch (heff_tag_of(v_f_242450)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_242477 = heff_field(v_f_242450, 0);
    V v_eq_242478 = heff_field(v_f_242450, 1);
    V v_e_242479 = heff_field(v_f_242450, 2);
    heff_take_n(v_f_242450, 7ULL, 3);
    V v_a_242480 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242449), v_x_242477}));
    V v_b_242481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242449), v_eq_242478));
    V v_t_242482 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_242481));
    V v_t_242483 = (g_std_2edoc_2e_3c_3e(v_a_242480, v_t_242482));
    V v_t_242484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242449, v_e_242479}));
    return (g_std_2edoc_2e_3c_3e(v_t_242483, v_t_242484));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_242490 = heff_field(v_f_242450, 0);
    V v_eq_242491 = heff_field(v_f_242450, 1);
    V v_e_242492 = heff_field(v_f_242450, 2);
    heff_take_n(v_f_242450, 7ULL, 3);
    V v_a_242493 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242449), v_x_242490));
    V v_b_242494 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242449), v_eq_242491));
    V v_t_242495 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), v_b_242494));
    V v_t_242496 = (g_std_2edoc_2e_3c_3e(v_a_242493, v_t_242495));
    V v_t_242497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242449, v_e_242492}));
    return (g_std_2edoc_2e_3c_3e(v_t_242496, v_t_242497));
  }
  case TAG_EFDefault: {
    V v_d_242498 = heff_field(v_f_242450, 0);
    V v_eq_242499 = heff_field(v_f_242450, 1);
    V v_e_242500 = heff_field(v_f_242450, 2);
    heff_take_n(v_f_242450, 7ULL, 3);
    V v_a_242501 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242449), v_d_242498}));
    V v_b_242502 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242449), v_eq_242499));
    V v_t_242503 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_242502));
    V v_t_242504 = (g_std_2edoc_2e_3c_3e(v_a_242501, v_t_242503));
    V v_t_242505 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242449, v_e_242500}));
    return (g_std_2edoc_2e_3c_3e(v_t_242504, v_t_242505));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242449;
    args[1] = v_f_242450;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_242450);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_x2_245 = ({ V a_0 = heff_take_field(v_t_244, 7); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_t_249 = heff_get_n(v_t_244, 8, 9);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      switch (heff_tag_of(v_x_246)) {
      case TAG_Nil: {
        v_t_249 = heff_get_n(v_t_244, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 2);
        heff_drop_rec(v_t_244, 9);
        v_t_249 = heff_get_n(v_x_247, 1, 2);
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_2410;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2410 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
    } else {
      heff_drop(v_t_249);
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2410));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DInstance: {
    V v_n_2411 = heff_field(v_d_240, 1);
    V v_x2_2414 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_DEqn: {
    V v_n_2417 = heff_field(v_d_240, 0);
    V v_x2_2422 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2417)));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_244));
    V v_t_2445;
    switch (heff_tag_of(v_d_244)) {
    case TAG_DImport: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2443 = heff_dup(heff_field(v_d_244, 0));
      v_t_2445 = heff_strEq(heff_get_n(v_w_2443, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_t_2466;
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
      V v_t_2447 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
      V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2446, v_t_2447, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_244)})));
      V v_t_2450 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_244); r_; });
      V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2450, v_ds_245));
      v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2451));
    } else {
      heff_drop(v_t_2445);
      V v_t_2452 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_t_2452);
        V v_t_2453 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2454 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_244));
        V v_t_2455 = (g_heff_2esyntax_2efmt_2elayout_2edefLast(v_t_2454, heff_dup(v_d_244), v_ds_245));
        V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(v_t_2455));
        V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2453, v_t_2456));
        V v_t_2458 = ({ V a_0 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_244); r_; });
        V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(v_t_2458, v_ds_245));
        V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_t_2459));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460));
      } else {
        heff_drop(v_t_2452);
        V v_t_2461 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2462 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
        V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2461, v_t_2462, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){v_d_244})));
        V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_ds_245));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2465));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2466));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2448 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2448; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2463 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2463; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = (g_prelude_2estrFind(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1), heff_dup(v_s_243), MK_INT(0LL)));
  V v_t_245 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2), v_s_243, MK_INT(0LL), v_t_244, NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2emap_24s725725455x1186198702(v_t_245));
  V v_x2_247 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5), v_t_2410));
  return heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Left = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_at_240, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Left, TAG_Left, 1, (V[]){v_e_242});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Right = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_env_244 = heff_take_field(v_at_240, 1);
    V v_eof_245 = (g_heff_2esyntax_2efmt_2elayout_2eeofOf(heff_get_n(v_at_240, 0, 2)));
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_dup(v_env_244), MK_INT(0LL), NTAG(TAG_False), v_ds_243));
    V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_eof_245, 7, 9), heff_rfield(v_env_244, 1)));
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2410 = ({ V a_0 = v_env_244; V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410));
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2411));
    return heff_tag_at_n(v_ru_24x2_241_24Right, TAG_Right, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtParsed(a[0], a[1]);
}