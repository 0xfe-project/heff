// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_exposing 966605106
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_2418;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        switch (heff_tag_of(v_x_247)) {
        case TAG_Nil: {
          v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x_247, 0ULL, 2);
          V v_t_2416;
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
            v_t_2416 = NTAG(TAG_Nil);
          } else {
            HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                V v_x_2415 = v_field_2413;
                v_t_2416 = v_x_2415;
              } else {
                heff_drop(v_field_2413);
                v_t_2416 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2417 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2416); r_; });
          v_t_2418 = (g_std_2edoc_2e_3c_3e(v_t_2417, heff_dup(g_std_2edoc_2ehardline_get())));
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
  }
  HeffT2 v_t_2419 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 2), heff_dup(heff_rfield(v_t_241, 7))));
  V v_t_2424;
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2423 = v_field_2421;
      v_t_2424 = v_x_2423;
    } else {
      heff_drop(v_field_2421);
      v_t_2424 = NTAG(TAG_Nil);
    }
  }
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2424); r_; });
  V v_s_2426 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2428;
  if (heff_strEq_c_lent(v_s_2426, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2426);
    v_t_2428 = NTAG(TAG_None);
  } else {
    v_t_2428 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2426});
  }
  V v_t_2430;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2430 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2430 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2431 = (g_std_2edoc_2e_3c_3e(v_t_2428, v_t_2430));
  V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2431));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2432);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_c_242, 0)));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2453));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2453));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2476 = heff_field(v_e_240, 3);
    V t_0 = v_body_2476;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2439 = heff_field(v_x1_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2439, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EField: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_App: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Op: {
    V v_a_2454 = heff_field(v_e_240, 0);
    V v_op_2455 = heff_field(v_e_240, 1);
    V v_b_2456 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_2456)));
    {
      V v_field_2458 = v_t_2457.f[0];
      V v_field_2459 = v_t_2457.f[1];
      V v_bf_2460 = v_field_2458;
      V v_rest_2461 = v_field_2459;
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2455), v_rest_2461));
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop(v_b_2456);
        heff_drop(v_t_2462);
        V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_bf_2460}), v_rest_2461});
        return ((HeffT2){{v_a_2454, v_t_2463}});
      } else {
        heff_drop(v_bf_2460);
        heff_drop(v_rest_2461);
        heff_drop(v_t_2462);
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_b_2456}), NTAG(TAG_Nil)});
        return ((HeffT2){{v_a_2454, v_t_2464}});
      }
    }
  }
  case TAG_Ops: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_If: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetCond: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2461 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2461, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetMut: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAssign: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFor: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EJump: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EReturn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_IfThen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetCond: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ETry: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECatch: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EWith: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_r_242, 0);
    V v_t_2463 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2461, 1))));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_x1_240, 1);
    V v_x1_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2453)));
    switch (heff_tag_of(v_x1_2454)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x1_2454, 0);
      V v_rev_2456 = heff_field(v_x1_2454, 1);
      heff_take_n(v_x1_2454, 3ULL, 2);
      V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2456));
      heff_drop(v_t_2457);
      switch (heff_tag_of(v_x_2455)) {
      case TAG_Atom: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 1); r_; });
      }
      case TAG_EParen: {
        V v_e_2460 = heff_field(v_x_2455, 1);
        heff_take_n(v_x_2455, 2ULL, 3);
        return ({ V a_0 = v_e_2460; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2460); r_; });
      }
      case TAG_Named: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_Tup: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_Seg: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_Braces: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_Update: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_EUSet: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_InstB: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_EFSet: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_EFDefault: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_Sum: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_ECon: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_EField: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_ENeg: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_App: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_Op: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_Ops: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_OpRhs: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_Ann: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_BVar: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 1); r_; });
      }
      case TAG_BImp: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_BAnn: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_Lam: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_Case: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_EAlt: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_If: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_Do: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_ESBind: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_ELet: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_ELetMut: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_EAssign: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_EWhile: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_EFor: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_EJump: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 1); r_; });
      }
      case TAG_EReturn: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_ENest: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_IfThen: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_ELetCond: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_ETry: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_ECatch: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_EWith: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      default: return heff_nomatch(v_x_2455);
      }
    }
    default: return heff_nomatch(v_x1_2454);
    }
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_take_field(v_t_246, 7)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = heff_get_n(v_t_246, 8, 9);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop_rec(v_t_246, 9);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_249);
          v_t_2414 = heff_get_n(v_t_246, 8, 9);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str111, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str113, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str115, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str116, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str117, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str118, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str119, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str122, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str123, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str125, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str126, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str127, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str128, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str129, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str131, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str132, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str133, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str135, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str136, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str137, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str138, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str140, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str141, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str142, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str143, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str145, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str146, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str147, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str149, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str151, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str152, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str153, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str154, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str155, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str156, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str157, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam120, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam121, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam122, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam123, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam124, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam127, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam128, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam129, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam130, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam120_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam121_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam122_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam123_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam124_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam129_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam130_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2445 = args[0];
  V v_e_2446 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2445));
  V v_one_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2446));
  V v_b_2453;
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_t_2449);
    V v_d_2450 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2450});
  } else {
    heff_drop(v_t_2449);
    V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2446));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      V v_d_2452 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
      v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2452});
    } else {
      heff_drop(v_t_2451);
      v_b_2453 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    }
  }
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2453));
  V v_t_2455 = (g_std_2edoc_2e_3c_3e(v_a_2447, v_t_2454));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2455));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  V v_d_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2467 = heff_intSub(v_k_2465, v_i_2466);
  if (heff_intEq_c_lent(v_i_2467, MK_INT(0LL), 2)) {
    heff_drop(v_i_2467);
    return v_d_2464;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2467, v_d_2464});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2465 = args[0];
  V v_d_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2465, v_d_2464})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2474 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2489 = args[0];
  V v_f_2490 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2489));
  V v_d_2492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2490}));
  V v_t_2493 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2492})));
  V v_t_2494 = (g_std_2edoc_2e_3c_3e(v_a_2491, v_t_2493));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2494));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24103 = args[0];
  V v_k_24102 = heff_env(self)[0];
  V v_d_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24104 = heff_intSub(v_k_24102, v_i_24103);
  if (heff_intEq_c_lent(v_i_24104, MK_INT(0LL), 2)) {
    heff_drop(v_i_24104);
    return v_d_24101;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24104, v_d_24101});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24102 = args[0];
  V v_d_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24102, v_d_24101})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24131 = args[0];
  V v_f_24132 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24131));
  V v_d_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24132}));
  V v_t_24135 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24134})));
  V v_t_24136 = (g_std_2edoc_2e_3c_3e(v_a_24133, v_t_24135));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24147 = args[0];
  V v_k_24146 = heff_env(self)[0];
  V v_d_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24148 = heff_intSub(v_k_24146, v_i_24147);
  if (heff_intEq_c_lent(v_i_24148, MK_INT(0LL), 2)) {
    heff_drop(v_i_24148);
    return v_d_24145;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24148, v_d_24145});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24146 = args[0];
  V v_d_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24146, v_d_24145})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24205 = args[0];
  V v_a_24206 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24188 = heff_env(self)[1];
  V v_c_24191 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24207 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24188, 4, 9), heff_get_n(v_c_24191, 3, 9)));
  V v_t_24208;
  if ((heff_dup(v_x1_24207) == NTAG(TAG_True))) {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24209 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24205));
  V v_b_24210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24206}));
  V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24210));
  V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
  return (g_std_2edoc_2e_3c_3e(v_t_24208, v_t_24212));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24219 = args[0];
  V v_k_24218 = heff_env(self)[0];
  V v_d_24217 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24220 = heff_intSub(v_k_24218, v_i_24219);
  if (heff_intEq_c_lent(v_i_24220, MK_INT(0LL), 2)) {
    heff_drop(v_i_24220);
    return v_d_24217;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24220, v_d_24217});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24218 = args[0];
  V v_d_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24218, v_d_24217})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24227 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24227}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24249 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24250 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24249));
  V v_t_24251;
  if ((heff_dup(v_x1_24250) == NTAG(TAG_True))) {
    heff_drop(v_x1_24250);
    v_t_24251 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24250);
    v_t_24251 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24247, v_r_24249}));
  return (g_std_2edoc_2e_3c_3e(v_t_24251, v_t_24252));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24365 = args[0];
  V v_k_24364 = heff_env(self)[0];
  V v_d_24363 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24366 = heff_intSub(v_k_24364, v_i_24365);
  if (heff_intEq_c_lent(v_i_24366, MK_INT(0LL), 2)) {
    heff_drop(v_i_24366);
    return v_d_24363;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24366, v_d_24363});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24364 = args[0];
  V v_d_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24364, v_d_24363})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24411 = args[0];
  V v_k_24410 = heff_env(self)[0];
  V v_d_24407 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24412 = heff_intSub(v_k_24410, v_i_24411);
  if (heff_intEq_c_lent(v_i_24412, MK_INT(0LL), 2)) {
    heff_drop(v_i_24412);
    return v_d_24407;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24412, v_d_24407});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24410 = args[0];
  V v_d_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24410, v_d_24407})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24431 = args[0];
  V v_k_24430 = heff_env(self)[0];
  V v_d_24427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24432 = heff_intSub(v_k_24430, v_i_24431);
  if (heff_intEq_c_lent(v_i_24432, MK_INT(0LL), 2)) {
    heff_drop(v_i_24432);
    return v_d_24427;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24432, v_d_24427});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24430 = args[0];
  V v_d_24427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24430, v_d_24427})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24491 = args[0];
  V v_k_24490 = heff_env(self)[0];
  V v_d_24489 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24492 = heff_intSub(v_k_24490, v_i_24491);
  if (heff_intEq_c_lent(v_i_24492, MK_INT(0LL), 2)) {
    heff_drop(v_i_24492);
    return v_d_24489;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24492, v_d_24489});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24490 = args[0];
  V v_d_24489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24490, v_d_24489})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24523 = args[0];
  V v_k_24522 = heff_env(self)[0];
  V v_d_24513 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24524 = heff_intSub(v_k_24522, v_i_24523);
  if (heff_intEq_c_lent(v_i_24524, MK_INT(0LL), 2)) {
    heff_drop(v_i_24524);
    return v_d_24513;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24524, v_d_24513});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24522 = args[0];
  V v_d_24513 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24522, v_d_24513})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2435));
      V v_t_2444;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        V v_d_2441 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2441});
      } else {
        heff_drop(v_t_2440);
        V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2435));
        if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
          heff_drop(v_t_2442);
          V v_d_2443 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
          v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2443});
        } else {
          heff_drop(v_t_2442);
          v_t_2444 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        }
      }
      V v_t_2456 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2457 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2458;
      if ((heff_dup(v_x1_2457) == NTAG(TAG_True))) {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2444, v_t_2461));
      V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2462));
      V v_d_2464 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2463));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2464})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2469 = heff_field(v_e0_241, 0);
    V v_cc_2470 = heff_field(v_e0_241, 1);
    V v_spec_2471 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2469}));
    V v_t_2473 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2470));
    V v_t_2475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2471; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2471); r_; });
    V v_t_2476 = (g_std_2edoc_2e_3c_3e(v_t_2473, v_t_2475));
    return (g_std_2edoc_2e_3c_3e(v_t_2472, v_t_2476));
  }
  case TAG_Braces: {
    V v_o_2477 = heff_field(v_e0_241, 0);
    V v_fs_2478 = heff_field(v_e0_241, 1);
    V v_commas_2479 = heff_field(v_e0_241, 2);
    V v_c_2480 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2478)) {
    case TAG_Nil: {
      heff_drop(v_commas_2479);
      V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2477));
      V v_t_2482 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      return (g_std_2edoc_2e_3c_3e(v_t_2481, v_t_2482));
    }
    case TAG_Cons: {
      V v_f1_2483 = heff_field(v_fs_2478, 0);
      V v_more_2484 = heff_field(v_fs_2478, 1);
      V v_ru_24fs_2478_24Cons = heff_take_reuse_n(v_fs_2478, 3ULL, 2);
      V v_a_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2477)));
      V v_d_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2483}));
      V v_t_2487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2478_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2486})));
      V v_t_2488 = (g_std_2edoc_2e_3c_3e(v_a_2485, v_t_2487));
      V v_t_2495 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2479; V a_3 = v_more_2484; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2479); heff_drop(v_more_2484); r_; });
      V v_x1_2496 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2477, 4, 9), heff_dup(heff_rfield(v_c_2480, 3))));
      V v_t_2497;
      if ((heff_dup(v_x1_2496) == NTAG(TAG_True))) {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2498 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2497, v_t_2498));
      V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2499));
      V v_d_24101 = (g_std_2edoc_2e_3c_3e(v_t_2488, v_t_24100));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_24101})})));
    }
    default: return heff_nomatch(v_fs_2478);
    }
  }
  case TAG_Update: {
    V v_o_24106 = heff_field(v_e0_241, 0);
    V v_r_24107 = heff_field(v_e0_241, 1);
    V v_bar_24108 = heff_field(v_e0_241, 2);
    V v_fs_24109 = heff_field(v_e0_241, 3);
    V v_commas_24110 = heff_field(v_e0_241, 4);
    V v_c_24111 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24109)) {
    case TAG_Nil: {
      heff_drop(v_commas_24110);
      V v_a_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24106));
      V v_a_24113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_a_24114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_b_24115 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24116));
      V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24117));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24118));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24119));
      return (g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24120));
    }
    case TAG_Cons: {
      V v_f1_24121 = heff_field(v_fs_24109, 0);
      V v_more_24122 = heff_field(v_fs_24109, 1);
      V v_ru_24fs_24109_24Cons = heff_take_reuse_n(v_fs_24109, 3ULL, 2);
      V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24106)));
      V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24109_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24124})));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_a_24127 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_d_24128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24121}));
      V v_t_24129 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24128})));
      V v_t_24130 = (g_std_2edoc_2e_3c_3e(v_a_24127, v_t_24129));
      V v_t_24137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24110; V a_3 = v_more_24122; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24110); heff_drop(v_more_24122); r_; });
      V v_x1_24138 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24106, 4, 9), heff_dup(heff_rfield(v_c_24111, 3))));
      V v_t_24139;
      if ((heff_dup(v_x1_24138) == NTAG(TAG_True))) {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24140 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(v_t_24139, v_t_24140));
      V v_t_24142 = (g_std_2edoc_2e_3c_3e(v_t_24137, v_t_24141));
      V v_t_24143 = (g_std_2edoc_2e_3c_3e(v_t_24130, v_t_24142));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24143));
      V v_d_24145 = (g_std_2edoc_2e_3c_3e(v_t_24126, v_t_24144));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24145})})));
    }
    default: return heff_nomatch(v_fs_24109);
    }
  }
  case TAG_EUSet: {
    V v_x_24150 = heff_field(v_e0_241, 0);
    V v_eq_24151 = heff_field(v_e0_241, 1);
    V v_e_24152 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24150}));
    V v_b_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24151));
    V v_t_24155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24154));
    V v_t_24156 = (g_std_2edoc_2e_3c_3e(v_a_24153, v_t_24155));
    V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24152}));
    return (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
  }
  case TAG_InstB: {
    V v_o_24158 = heff_field(v_e0_241, 0);
    V v_o2_24159 = heff_field(v_e0_241, 1);
    V v_d_24160 = heff_field(v_e0_241, 2);
    V v_c1_24161 = heff_field(v_e0_241, 3);
    V v_c_24162 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24158));
    V v_t_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24159));
    V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24160}));
    V v_t_24166 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24161));
    V v_t_24167 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24162));
    V v_t_24168 = (g_std_2edoc_2e_3c_3e(v_t_24166, v_t_24167));
    V v_t_24169 = (g_std_2edoc_2e_3c_3e(v_t_24165, v_t_24168));
    V v_t_24170 = (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24169));
    return (g_std_2edoc_2e_3c_3e(v_t_24163, v_t_24170));
  }
  case TAG_EFSet: {
    V v_x_24171 = heff_field(v_e0_241, 0);
    V v_eq_24172 = heff_field(v_e0_241, 1);
    V v_e_24173 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24174 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24171));
    V v_b_24175 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24172));
    V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24175));
    V v_t_24177 = (g_std_2edoc_2e_3c_3e(v_a_24174, v_t_24176));
    V v_t_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24173}));
    return (g_std_2edoc_2e_3c_3e(v_t_24177, v_t_24178));
  }
  case TAG_EFDefault: {
    V v_d_24179 = heff_field(v_e0_241, 0);
    V v_eq_24180 = heff_field(v_e0_241, 1);
    V v_e_24181 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24179}));
    V v_b_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24180));
    V v_t_24184 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24183));
    V v_t_24185 = (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24184));
    V v_t_24186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24181}));
    return (g_std_2edoc_2e_3c_3e(v_t_24185, v_t_24186));
  }
  case TAG_Sum: {
    V v_kw_24187 = heff_field(v_e0_241, 0);
    V v_o_24188 = heff_field(v_e0_241, 1);
    V v_alts_24189 = heff_field(v_e0_241, 2);
    V v_bars_24190 = heff_field(v_e0_241, 3);
    V v_c_24191 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24189)) {
    case TAG_Nil: {
      heff_drop(v_bars_24190);
      V v_a_24192 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24193 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24188));
      V v_b_24194 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24195 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24194));
      V v_t_24196 = (g_std_2edoc_2e_3c_3e(v_a_24193, v_t_24195));
      V v_t_24197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24196));
      return (g_std_2edoc_2e_3c_3e(v_a_24192, v_t_24197));
    }
    case TAG_Cons: {
      V v_a1_24198 = heff_field(v_alts_24189, 0);
      V v_more_24199 = heff_field(v_alts_24189, 1);
      heff_take_n(v_alts_24189, 3ULL, 2);
      V v_a_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24201 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24188)));
      V v_b_24202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24198}));
      V v_t_24203 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24202));
      V v_t_24204 = (g_std_2edoc_2e_3c_3e(v_a_24201, v_t_24203));
      V v_a_24213 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24188, heff_dup(v_c_24191)}); V a_2 = v_bars_24190; V a_3 = v_more_24199; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24190); heff_drop(v_more_24199); r_; });
      V v_b_24214 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24215 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24214));
      V v_t_24216 = (g_std_2edoc_2e_3c_3e(v_a_24213, v_t_24215));
      V v_d_24217 = (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24216));
      V v_b_24222 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24217})})));
      V v_t_24223 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24222));
      return (g_std_2edoc_2e_3c_3e(v_a_24200, v_t_24223));
    }
    default: return heff_nomatch(v_alts_24189);
    }
  }
  case TAG_ECon: {
    V v_c_24224 = heff_field(v_e0_241, 0);
    V v_args_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24224));
    V v_t_24229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24225; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24225); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24229));
  }
  case TAG_EField: {
    V v_e_24230 = heff_field(v_e0_241, 0);
    V v_f_24231 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24230}));
    V v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24231));
    return (g_std_2edoc_2e_3c_3e(v_t_24232, v_t_24233));
  }
  case TAG_ENeg: {
    V v_m_24234 = heff_field(v_e0_241, 0);
    V v_e_24235 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24236 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24234));
    V v_t_24237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24235}));
    return (g_std_2edoc_2e_3c_3e(v_t_24236, v_t_24237));
  }
  case TAG_App: {
    V v_h_24238 = heff_field(v_e0_241, 0);
    V v_args_24239 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24238;
    heff_room[2] = v_args_24239;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24240 = heff_field(v_e0_241, 0);
    V v_op_24241 = heff_field(v_e0_241, 1);
    V v_b_24242 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24243 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24240, v_op_24241, v_b_24242})));
    {
      V v_field_24244 = v_t_24243.f[0];
      V v_field_24245 = v_t_24243.f[1];
      V v_first_24246 = v_field_24244;
      V v_rest_24247 = v_field_24245;
      V v_t_24248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24247), v_first_24246}));
      V v_t_24253 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24247)}); V a_2 = v_rest_24247; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24247); r_; });
      V v_t_24254 = (g_std_2edoc_2e_3c_3e(v_t_24248, v_t_24253));
      return (g_std_2edoc_2egroup(v_t_24254));
    }
  }
  case TAG_Ops: {
    V v_a_24255 = heff_field(v_e0_241, 0);
    V v_rest_24256 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24255;
    heff_room[2] = v_rest_24256;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24257 = heff_field(v_e0_241, 0);
    V v_e_24258 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24259 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24257));
    V v_b_24260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24258}));
    V v_t_24261 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24260));
    return (g_std_2edoc_2e_3c_3e(v_a_24259, v_t_24261));
  }
  case TAG_Ann: {
    V v_e_24262 = heff_field(v_e0_241, 0);
    V v_cc_24263 = heff_field(v_e0_241, 1);
    V v_ty_24264 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24265 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24262}));
    V v_b_24266 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24263));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24266));
    V v_t_24268 = (g_std_2edoc_2e_3c_3e(v_a_24265, v_t_24267));
    V v_t_24269 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24264}));
    V v_d_24270 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24269));
    V v_t_24271 = (g_std_2edoc_2e_3c_3e(v_t_24268, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24270})));
    return (g_std_2edoc_2egroup(v_t_24271));
  }
  case TAG_BVar: {
    V v_t_24272 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24272));
  }
  case TAG_BImp: {
    V v_o_24273 = heff_field(v_e0_241, 0);
    V v_x_24274 = heff_field(v_e0_241, 1);
    V v_c_24275 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24276 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24273));
    V v_t_24277 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24274));
    V v_t_24278 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24275));
    V v_t_24279 = (g_std_2edoc_2e_3c_3e(v_t_24277, v_t_24278));
    return (g_std_2edoc_2e_3c_3e(v_t_24276, v_t_24279));
  }
  case TAG_BAnn: {
    V v_o_24280 = heff_field(v_e0_241, 0);
    V v_x_24281 = heff_field(v_e0_241, 1);
    V v_cc_24282 = heff_field(v_e0_241, 2);
    V v_ty_24283 = heff_field(v_e0_241, 3);
    V v_c_24284 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24285 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24280));
    V v_a_24286 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24281));
    V v_a_24287 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24282));
    V v_b_24288 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24283}));
    V v_t_24289 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24288));
    V v_t_24290 = (g_std_2edoc_2e_3c_3e(v_a_24287, v_t_24289));
    V v_t_24291 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24290));
    V v_t_24292 = (g_std_2edoc_2e_3c_3e(v_a_24286, v_t_24291));
    V v_t_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24284));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(v_t_24292, v_t_24293));
    return (g_std_2edoc_2e_3c_3e(v_t_24285, v_t_24294));
  }
  case TAG_Lam: {
    V v_bs_24295 = heff_field(v_e0_241, 0);
    V v_binders_24296 = heff_field(v_e0_241, 1);
    V v_arrow_24297 = heff_field(v_e0_241, 2);
    V v_body_24298 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24299 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24295));
    V v_t_24300 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24301 = (g_list_2emap(v_t_24300, v_binders_24296));
    V v_a_24302 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24301; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24301); r_; });
    V v_b_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24297));
    V v_t_24304 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24303));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(v_a_24302, v_t_24304));
    V v_t_24306 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24298));
    V v_t_24310;
    if ((heff_dup(v_t_24306) == NTAG(TAG_True))) {
      heff_drop(v_t_24306);
      V v_t_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      v_t_24310 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24307));
    } else {
      heff_drop(v_t_24306);
      V v_t_24308 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      V v_d_24309 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24308));
      v_t_24310 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24309})));
    }
    V v_t_24311 = (g_std_2edoc_2e_3c_3e(v_t_24305, v_t_24310));
    return (g_std_2edoc_2e_3c_3e(v_t_24299, v_t_24311));
  }
  case TAG_Case: {
    V v_kw_24312 = heff_field(v_e0_241, 0);
    V v_scrut_24313 = heff_field(v_e0_241, 1);
    V v_of2_24314 = heff_field(v_e0_241, 2);
    V v_alts_24315 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24312));
    V v_a_24317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24313}));
    V v_b_24318 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24314));
    V v_t_24319 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24318));
    V v_t_24320 = (g_std_2edoc_2e_3c_3e(v_a_24317, v_t_24319));
    V v_t_24321 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24320));
    V v_t_24322 = (g_std_2edoc_2e_3c_3e(v_a_24316, v_t_24321));
    V v_t_24323 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24315; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24315); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24322, v_t_24323));
  }
  case TAG_EAlt: {
    V v_p_24324 = heff_field(v_e0_241, 0);
    V v_arrow_24325 = heff_field(v_e0_241, 1);
    V v_body_24326 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24327 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24324; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24324); r_; });
    V v_b_24328 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24325));
    V v_t_24329 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24328));
    V v_t_24330 = (g_std_2edoc_2e_3c_3e(v_a_24327, v_t_24329));
    V v_t_24331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24326}));
    return (g_std_2edoc_2e_3c_3e(v_t_24330, v_t_24331));
  }
  case TAG_If: {
    V v_kw_24332 = heff_field(v_e0_241, 0);
    V v_c_24333 = heff_field(v_e0_241, 1);
    V v_th_24334 = heff_field(v_e0_241, 2);
    V v_a_24335 = heff_field(v_e0_241, 3);
    V v_el_24336 = heff_field(v_e0_241, 4);
    V v_b_24337 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24332, v_c_24333, v_th_24334, v_a_24335}));
    V v_t_24339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24336, v_b_24337}));
    V v_t_24340 = (g_std_2edoc_2e_3c_3e(v_t_24338, v_t_24339));
    return (g_std_2edoc_2egroup(v_t_24340));
  }
  case TAG_Do: {
    V v_kw_24341 = heff_field(v_e0_241, 0);
    V v_stmts_24342 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24343 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24341));
    V v_t_24344 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24342; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24342); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
  }
  case TAG_ESBind: {
    V v_x_24345 = heff_field(v_e0_241, 0);
    V v_arrow_24346 = heff_field(v_e0_241, 1);
    V v_e_24347 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24348 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24345));
    V v_b_24349 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24346));
    V v_t_24350 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24349));
    V v_t_24351 = (g_std_2edoc_2e_3c_3e(v_a_24348, v_t_24350));
    V v_t_24352 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24347}));
    return (g_std_2edoc_2e_3c_3e(v_t_24351, v_t_24352));
  }
  case TAG_ELet: {
    V v_kw_24353 = heff_field(v_e0_241, 0);
    V v_p_24354 = heff_field(v_e0_241, 1);
    V v_ann_24355 = heff_field(v_e0_241, 2);
    V v_eq_24356 = heff_field(v_e0_241, 3);
    V v_e_24357 = heff_field(v_e0_241, 4);
    V v_body_24358 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24358)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357});
    }
    case TAG_Just: {
      V v_it1_24359 = heff_field(v_body_24358, 0);
      V v_ru_24body_24358_24Just = heff_take_reuse_n(v_body_24358, 1ULL, 1);
      switch (heff_tag_of(v_it1_24359)) {
      case TAG_MkPair: {
        V v_i_24360 = heff_field(v_it1_24359, 0);
        V v_b_24361 = heff_field(v_it1_24359, 1);
        heff_take_n(v_it1_24359, 3ULL, 2);
        V v_t_24362 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357, v_i_24360, v_b_24361}));
        V v_d_24363 = (g_std_2edoc_2egroup(v_t_24362));
        return heff_tag_at_n(v_ru_24body_24358_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24363})});
      }
      default: return heff_nomatch(v_it1_24359);
      }
    }
    default: return heff_nomatch(v_body_24358);
    }
  }
  case TAG_ELetMut: {
    V v_kw_24368 = heff_field(v_e0_241, 0);
    V v_m_24369 = heff_field(v_e0_241, 1);
    V v_x_24370 = heff_field(v_e0_241, 2);
    V v_ann_24371 = heff_field(v_e0_241, 3);
    V v_eq_24372 = heff_field(v_e0_241, 4);
    V v_e_24373 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24374 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24368));
    V v_a_24375 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24369));
    V v_b_24376 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24370));
    V v_t_24377 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24376));
    V v_t_24378 = (g_std_2edoc_2e_3c_3e(v_a_24375, v_t_24377));
    V v_t_24379 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24378));
    V v_t_24380 = (g_std_2edoc_2e_3c_3e(v_a_24374, v_t_24379));
    V v_a_24388;
    switch (heff_tag_of(v_ann_24371)) {
    case TAG_Nothing: {
      v_a_24388 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24381 = heff_field(v_ann_24371, 0);
      V v_ru_24ann_24371_24Just = heff_take_reuse_n(v_ann_24371, 1ULL, 1);
      switch (heff_tag_of(v_it1_24381)) {
      case TAG_MkPair: {
        V v_cc_24382 = heff_field(v_it1_24381, 0);
        V v_ty_24383 = heff_field(v_it1_24381, 1);
        heff_take_n(v_it1_24381, 3ULL, 2);
        V v_a_24384 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24382));
        V v_b_24385 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24383}));
        V v_t_24386 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24371_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24385));
        V v_t_24387 = (g_std_2edoc_2e_3c_3e(v_a_24384, v_t_24386));
        v_a_24388 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24387));
        break;
      }
      default: heff_nomatch(v_it1_24381);
      }
      break;
    }
    default: heff_nomatch(v_ann_24371);
    }
    V v_b_24389 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24372));
    V v_t_24390 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24389));
    V v_t_24391 = (g_std_2edoc_2e_3c_3e(v_a_24388, v_t_24390));
    V v_t_24392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24373}));
    V v_t_24393 = (g_std_2edoc_2e_3c_3e(v_t_24391, v_t_24392));
    return (g_std_2edoc_2e_3c_3e(v_t_24380, v_t_24393));
  }
  case TAG_EAssign: {
    V v_x_24394 = heff_field(v_e0_241, 0);
    V v_k_24395 = heff_field(v_e0_241, 1);
    V v_e_24396 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24397 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24394));
    V v_b_24398 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24395));
    V v_t_24399 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24398));
    V v_t_24400 = (g_std_2edoc_2e_3c_3e(v_a_24397, v_t_24399));
    V v_t_24401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24396}));
    return (g_std_2edoc_2e_3c_3e(v_t_24400, v_t_24401));
  }
  case TAG_EWhile: {
    V v_kw_24402 = heff_field(v_e0_241, 0);
    V v_c_24403 = heff_field(v_e0_241, 1);
    V v_d_24404 = heff_field(v_e0_241, 2);
    V v_body_24405 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24406 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24402));
    V v_d_24407 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24403}));
    V v_b_24408 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24404));
    V v_t_24409 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24408));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24407})}), v_t_24409));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_t_24414));
    V v_t_24416 = (g_std_2edoc_2e_3c_3e(v_a_24406, v_t_24415));
    V v_t_24417 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24405; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24405); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24416, v_t_24417));
  }
  case TAG_EFor: {
    V v_kw_24418 = heff_field(v_e0_241, 0);
    V v_p_24419 = heff_field(v_e0_241, 1);
    V v_i_24420 = heff_field(v_e0_241, 2);
    V v_c_24421 = heff_field(v_e0_241, 3);
    V v_d_24422 = heff_field(v_e0_241, 4);
    V v_body_24423 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24418));
    V v_a_24425 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24419; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24419); r_; });
    V v_a_24426 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24420));
    V v_d_24427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24421}));
    V v_b_24428 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24422));
    V v_t_24429 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24428));
    V v_t_24434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24427})}), v_t_24429));
    V v_t_24435 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24434));
    V v_t_24436 = (g_std_2edoc_2e_3c_3e(v_a_24426, v_t_24435));
    V v_t_24437 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_t_24436));
    V v_t_24438 = (g_std_2edoc_2e_3c_3e(v_a_24425, v_t_24437));
    V v_t_24439 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24438));
    V v_t_24440 = (g_std_2edoc_2e_3c_3e(v_a_24424, v_t_24439));
    V v_t_24441 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24423; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24423); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24440, v_t_24441));
  }
  case TAG_EJump: {
    V v_kw_24442 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_kw_24442));
  }
  case TAG_EReturn: {
    V v_kw_24443 = heff_field(v_e0_241, 0);
    V v_e_24444 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24445 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24443));
    V v_d_24446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24444}));
    V v_t_24447 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24446})));
    return (g_std_2edoc_2e_3c_3e(v_a_24445, v_t_24447));
  }
  case TAG_ENest: {
    V v_o_24448 = heff_field(v_e0_241, 0);
    V v_arrow_24449 = heff_field(v_e0_241, 1);
    V v_e_24450 = heff_field(v_e0_241, 2);
    V v_c_24451 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24452 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24448));
    V v_a_24453 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24449));
    V v_b_24454 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24450}));
    V v_t_24455 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_b_24454));
    V v_t_24456 = (g_std_2edoc_2e_3c_3e(v_a_24453, v_t_24455));
    V v_t_24457 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24451));
    V v_t_24458 = (g_std_2edoc_2e_3c_3e(v_t_24456, v_t_24457));
    return (g_std_2edoc_2e_3c_3e(v_t_24452, v_t_24458));
  }
  case TAG_IfThen: {
    V v_kw_24459 = heff_field(v_e0_241, 0);
    V v_c_24460 = heff_field(v_e0_241, 1);
    V v_th_24461 = heff_field(v_e0_241, 2);
    V v_a_24462 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24459, v_c_24460, v_th_24461, v_a_24462}));
    return (g_std_2edoc_2egroup(v_t_24463));
  }
  case TAG_ELetCond: {
    V v_kw_24464 = heff_field(v_e0_241, 0);
    V v_p_24465 = heff_field(v_e0_241, 1);
    V v_eq_24466 = heff_field(v_e0_241, 2);
    V v_e_24467 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24468 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24464));
    V v_a_24469 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24465; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24465); r_; });
    V v_b_24470 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24466));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), v_b_24470));
    V v_t_24472 = (g_std_2edoc_2e_3c_3e(v_a_24469, v_t_24471));
    V v_t_24473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_t_24472));
    V v_t_24474 = (g_std_2edoc_2e_3c_3e(v_a_24468, v_t_24473));
    V v_t_24475 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24467}));
    return (g_std_2edoc_2e_3c_3e(v_t_24474, v_t_24475));
  }
  case TAG_ETry: {
    V v_kw_24476 = heff_field(v_e0_241, 0);
    V v_ty_24477 = heff_field(v_e0_241, 1);
    V v_body_24478 = heff_field(v_e0_241, 2);
    V v_c_24479 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24480 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24476));
    V v_t_24483;
    switch (heff_tag_of(v_ty_24477)) {
    case TAG_Nothing: {
      v_t_24483 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24481 = heff_field(v_ty_24477, 0);
      V v_ru_24ty_24477_24Just = heff_take_reuse_n(v_ty_24477, 1ULL, 1);
      V v_t_24482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24481}));
      v_t_24483 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24477_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_t_24482));
      break;
    }
    default: heff_nomatch(v_ty_24477);
    }
    V v_d_24484 = ({ V a_0 = heff_dup(v_env_240); V a_1 = MK_INT(0LL); V a_2 = v_body_24478; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24478); r_; });
    V v_t_24485 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24479}));
    V v_t_24486 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24485));
    V v_t_24487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24484}), v_t_24486));
    V v_t_24488 = (g_std_2edoc_2e_3c_3e(v_t_24483, v_t_24487));
    V v_d_24489 = (g_std_2edoc_2e_3c_3e(v_t_24480, v_t_24488));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24489})});
  }
  case TAG_ECatch: {
    V v_kw_24494 = heff_field(v_e0_241, 0);
    V v_b_24495 = heff_field(v_e0_241, 1);
    V v_arrow_24496 = heff_field(v_e0_241, 2);
    V v_body_24497 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24498 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24494));
    V v_a_24499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 2, (V[]){heff_dup(v_env_240), v_b_24495}));
    V v_b_24500 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24496));
    V v_t_24501 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_b_24500));
    V v_t_24502 = (g_std_2edoc_2e_3c_3e(v_a_24499, v_t_24501));
    V v_t_24503 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_t_24502));
    V v_t_24504 = (g_std_2edoc_2e_3c_3e(v_a_24498, v_t_24503));
    V v_d_24505 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24497; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24497); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24504, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24505})));
  }
  case TAG_EWith: {
    V v_kw_24506 = heff_field(v_e0_241, 0);
    V v_e_24507 = heff_field(v_e0_241, 1);
    V v_a_24508 = heff_field(v_e0_241, 2);
    V v_x_24509 = heff_field(v_e0_241, 3);
    V v_d_24510 = heff_field(v_e0_241, 4);
    V v_body_24511 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24512 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24506));
    V v_d_24513 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24507}));
    V v_a_24514 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_a_24508));
    V v_a_24515 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24509));
    V v_b_24516 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24510));
    V v_t_24517 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_b_24516));
    V v_t_24518 = (g_std_2edoc_2e_3c_3e(v_a_24515, v_t_24517));
    V v_t_24519 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_t_24518));
    V v_t_24520 = (g_std_2edoc_2e_3c_3e(v_a_24514, v_t_24519));
    V v_t_24521 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24520));
    V v_t_24526 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24513})}), v_t_24521));
    V v_t_24527 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24526));
    V v_t_24528 = (g_std_2edoc_2e_3c_3e(v_a_24512, v_t_24527));
    V v_t_24529 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24511; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24511); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24528, v_t_24529));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_env_24530 = args[0];
  V v_e_24531 = args[1];
  V v_t_24532 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24531));
  if ((heff_dup(v_t_24532) == NTAG(TAG_True))) {
    heff_drop(v_t_24532);
    V v_t_24533 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24530, v_e_24531}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24533));
  } else {
    heff_drop(v_t_24532);
    V v_t_24534 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24530, v_e_24531}));
    V v_t_24535 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24534));
    return (g_std_2edoc_2egroup(v_t_24535));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_env_24536 = args[0];
  V v_kw_24537 = args[1];
  V v_p_24538 = args[2];
  V v_ann_24539 = args[3];
  V v_eq_24540 = args[4];
  V v_e_24541 = args[5];
  V v_a_24542 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24536), v_kw_24537));
  V v_b_24543 = ({ V a_0 = heff_dup(v_env_24536); V a_1 = v_p_24538; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24538); r_; });
  V v_t_24544 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_b_24543));
  V v_t_24545 = (g_std_2edoc_2e_3c_3e(v_a_24542, v_t_24544));
  V v_a_24553;
  switch (heff_tag_of(v_ann_24539)) {
  case TAG_Nothing: {
    v_a_24553 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24546 = heff_field(v_ann_24539, 0);
    V v_ru_24ann_24539_24Just = heff_take_reuse_n(v_ann_24539, 1ULL, 1);
    switch (heff_tag_of(v_it1_24546)) {
    case TAG_MkPair: {
      V v_cc_24547 = heff_field(v_it1_24546, 0);
      V v_ty_24548 = heff_field(v_it1_24546, 1);
      heff_take_n(v_it1_24546, 3ULL, 2);
      V v_a_24549 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24536), v_cc_24547));
      V v_b_24550 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24536), v_ty_24548}));
      V v_t_24551 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24539_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), v_b_24550));
      V v_t_24552 = (g_std_2edoc_2e_3c_3e(v_a_24549, v_t_24551));
      v_a_24553 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), v_t_24552));
      break;
    }
    default: heff_nomatch(v_it1_24546);
    }
    break;
  }
  default: heff_nomatch(v_ann_24539);
  }
  V v_b_24554 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24536), v_eq_24540));
  V v_t_24555 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_b_24554));
  V v_t_24556 = (g_std_2edoc_2e_3c_3e(v_a_24553, v_t_24555));
  V v_t_24557 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24536, v_e_24541}));
  V v_t_24558 = (g_std_2edoc_2e_3c_3e(v_t_24556, v_t_24557));
  return (g_std_2edoc_2e_3c_3e(v_t_24545, v_t_24558));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_env_24559 = args[0];
  V v_kw_24560 = args[1];
  V v_p_24561 = args[2];
  V v_ann_24562 = args[3];
  V v_eq_24563 = args[4];
  V v_e_24564 = args[5];
  V v_i_24565 = args[6];
  V v_b_24566 = args[7];
  V v_d_24567 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24559), v_kw_24560, v_p_24561, v_ann_24562, v_eq_24563, v_e_24564}));
  V v_t_24568 = heff_dup(heff_rfield(v_i_24565, 6));
  V v_t_24571;
  if ((heff_dup(v_t_24568) == NTAG(TAG_True))) {
    heff_drop(v_t_24568);
    v_t_24571 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24568);
    V v_t_24569 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24566));
    V v_x1_24570 = heff_get_n(v_t_24569, 6, 9);
    if ((heff_dup(v_x1_24570) == NTAG(TAG_True))) {
      heff_drop(v_x1_24570);
      v_t_24571 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24570);
      v_t_24571 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24572 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24559), v_i_24565));
  V v_b_24724;
  switch (heff_tag_of(v_b_24566)) {
  case TAG_Atom: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EParen: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Named: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Tup: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Seg: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Braces: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Update: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EUSet: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_InstB: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EFSet: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Sum: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ECon: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EField: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ENeg: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_App: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Op: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Ops: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Ann: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_BVar: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_BImp: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_BAnn: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Lam: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Case: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EAlt: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_If: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_Do: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ESBind: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24667 = heff_dup(heff_field(v_b_24566, 0));
    V v_p2_24668 = heff_dup(heff_field(v_b_24566, 1));
    V v_ann2_24669 = heff_dup(heff_field(v_b_24566, 2));
    V v_eq2_24670 = heff_dup(heff_field(v_b_24566, 3));
    V v_e2_24671 = heff_dup(heff_field(v_b_24566, 4));
    V v_it6_24672 = heff_dup(heff_field(v_b_24566, 5));
    switch (heff_tag_of(v_it6_24672)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24667);
      heff_drop(v_p2_24668);
      heff_drop(v_ann2_24669);
      heff_drop(v_eq2_24670);
      heff_drop(v_e2_24671);
      v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
      break;
    }
    case TAG_Just: {
      V v_it61_24673 = heff_field(v_it6_24672, 0);
      heff_take_n(v_it6_24672, 1ULL, 1);
      heff_drop_tag(v_b_24566, 6);
      switch (heff_tag_of(v_it61_24673)) {
      case TAG_MkPair: {
        V v_i2_24674 = heff_field(v_it61_24673, 0);
        V v_b2_24675 = heff_field(v_it61_24673, 1);
        heff_take_n(v_it61_24673, 3ULL, 2);
        v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24559, v_kw2_24667, v_p2_24668, v_ann2_24669, v_eq2_24670, v_e2_24671, v_i2_24674, v_b2_24675}));
        break;
      }
      default: heff_nomatch(v_it61_24673);
      }
      break;
    }
    default: heff_nomatch(v_it6_24672);
    }
    break;
  }
  case TAG_ELetMut: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EAssign: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EWhile: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EFor: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EJump: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EReturn: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ENest: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_IfThen: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ELetCond: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ETry: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_ECatch: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  case TAG_EWith: {
    v_b_24724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24559, v_b_24566}));
    break;
  }
  default: heff_nomatch(v_b_24566);
  }
  V v_t_24725 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24724));
  V v_t_24726 = (g_std_2edoc_2e_3c_3e(v_a_24572, v_t_24725));
  V v_t_24727 = (g_std_2edoc_2e_3c_3e(v_t_24571, v_t_24726));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24567}), v_t_24727));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24736 = args[0];
  V v_k_24735 = heff_env(self)[0];
  V v_d_24734 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24737 = heff_intSub(v_k_24735, v_i_24736);
  if (heff_intEq_c_lent(v_i_24737, MK_INT(0LL), 2)) {
    heff_drop(v_i_24737);
    return v_d_24734;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24737, v_d_24734});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24735 = args[0];
  V v_d_24734 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24735, v_d_24734})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_env_24728 = args[0];
  V v_kw_24729 = args[1];
  V v_c_24730 = args[2];
  V v_th_24731 = args[3];
  V v_a_24732 = args[4];
  V v_a_24733 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24728), v_kw_24729));
  V v_d_24734 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24728), v_c_24730}));
  V v_t_24739 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24734})})));
  V v_t_24740 = (g_std_2edoc_2e_3c_3e(v_a_24733, v_t_24739));
  V v_t_24741 = heff_dup(heff_rfield(v_th_24731, 6));
  V v_t_24744;
  if ((heff_dup(v_t_24741) == NTAG(TAG_True))) {
    heff_drop(v_t_24741);
    v_t_24744 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24741);
    V v_t_24742 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24732));
    V v_x1_24743 = heff_get_n(v_t_24742, 6, 9);
    if ((heff_dup(v_x1_24743) == NTAG(TAG_True))) {
      heff_drop(v_x1_24743);
      v_t_24744 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24743);
      v_t_24744 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24745 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24728), v_th_24731));
  V v_d_24746 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24728, v_a_24732}));
  V v_t_24747 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24746})));
  V v_t_24748 = (g_std_2edoc_2e_3c_3e(v_a_24745, v_t_24747));
  V v_t_24749 = (g_std_2edoc_2e_3c_3e(v_t_24744, v_t_24748));
  V v_t_24750 = (g_std_2edoc_2e_3c_3e(v_t_24740, v_t_24749));
  return (g_std_2edoc_2egroup(v_t_24750));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_env_24751 = args[0];
  V v_el_24752 = args[1];
  V v_b_24753 = args[2];
  switch (heff_tag_of(v_b_24753)) {
  case TAG_Atom: {
    V v_t_24755 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24758;
    if ((heff_dup(v_t_24755) == NTAG(TAG_True))) {
      heff_drop(v_t_24755);
      v_t_24758 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24755);
      V v_t_24756 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24757 = heff_get_n(v_t_24756, 6, 9);
      if ((heff_dup(v_x1_24757) == NTAG(TAG_True))) {
        heff_drop(v_x1_24757);
        v_t_24758 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24757);
        v_t_24758 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24759 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24760 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24761 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24760})));
    V v_t_24762 = (g_std_2edoc_2e_3c_3e(v_a_24759, v_t_24761));
    return (g_std_2edoc_2e_3c_3e(v_t_24758, v_t_24762));
  }
  case TAG_EParen: {
    V v_t_24766 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24769;
    if ((heff_dup(v_t_24766) == NTAG(TAG_True))) {
      heff_drop(v_t_24766);
      v_t_24769 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24766);
      V v_t_24767 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24768 = heff_get_n(v_t_24767, 6, 9);
      if ((heff_dup(v_x1_24768) == NTAG(TAG_True))) {
        heff_drop(v_x1_24768);
        v_t_24769 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24768);
        v_t_24769 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24770 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24771 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24772 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24771})));
    V v_t_24773 = (g_std_2edoc_2e_3c_3e(v_a_24770, v_t_24772));
    return (g_std_2edoc_2e_3c_3e(v_t_24769, v_t_24773));
  }
  case TAG_Named: {
    V v_t_24779 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24782;
    if ((heff_dup(v_t_24779) == NTAG(TAG_True))) {
      heff_drop(v_t_24779);
      v_t_24782 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24779);
      V v_t_24780 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24781 = heff_get_n(v_t_24780, 6, 9);
      if ((heff_dup(v_x1_24781) == NTAG(TAG_True))) {
        heff_drop(v_x1_24781);
        v_t_24782 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24781);
        v_t_24782 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24783 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24784 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24785 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24784})));
    V v_t_24786 = (g_std_2edoc_2e_3c_3e(v_a_24783, v_t_24785));
    return (g_std_2edoc_2e_3c_3e(v_t_24782, v_t_24786));
  }
  case TAG_Tup: {
    V v_t_24791 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24794;
    if ((heff_dup(v_t_24791) == NTAG(TAG_True))) {
      heff_drop(v_t_24791);
      v_t_24794 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24791);
      V v_t_24792 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24793 = heff_get_n(v_t_24792, 6, 9);
      if ((heff_dup(v_x1_24793) == NTAG(TAG_True))) {
        heff_drop(v_x1_24793);
        v_t_24794 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24793);
        v_t_24794 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24795 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24796 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24797 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24796})));
    V v_t_24798 = (g_std_2edoc_2e_3c_3e(v_a_24795, v_t_24797));
    return (g_std_2edoc_2e_3c_3e(v_t_24794, v_t_24798));
  }
  case TAG_Seg: {
    V v_t_24802 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24805;
    if ((heff_dup(v_t_24802) == NTAG(TAG_True))) {
      heff_drop(v_t_24802);
      v_t_24805 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24802);
      V v_t_24803 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24804 = heff_get_n(v_t_24803, 6, 9);
      if ((heff_dup(v_x1_24804) == NTAG(TAG_True))) {
        heff_drop(v_x1_24804);
        v_t_24805 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24804);
        v_t_24805 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24806 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24807 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24808 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24807})));
    V v_t_24809 = (g_std_2edoc_2e_3c_3e(v_a_24806, v_t_24808));
    return (g_std_2edoc_2e_3c_3e(v_t_24805, v_t_24809));
  }
  case TAG_Braces: {
    V v_t_24814 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24817;
    if ((heff_dup(v_t_24814) == NTAG(TAG_True))) {
      heff_drop(v_t_24814);
      v_t_24817 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24814);
      V v_t_24815 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24816 = heff_get_n(v_t_24815, 6, 9);
      if ((heff_dup(v_x1_24816) == NTAG(TAG_True))) {
        heff_drop(v_x1_24816);
        v_t_24817 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24816);
        v_t_24817 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24818 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24819 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24820 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24819})));
    V v_t_24821 = (g_std_2edoc_2e_3c_3e(v_a_24818, v_t_24820));
    return (g_std_2edoc_2e_3c_3e(v_t_24817, v_t_24821));
  }
  case TAG_Update: {
    V v_t_24828 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24831;
    if ((heff_dup(v_t_24828) == NTAG(TAG_True))) {
      heff_drop(v_t_24828);
      v_t_24831 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24828);
      V v_t_24829 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24830 = heff_get_n(v_t_24829, 6, 9);
      if ((heff_dup(v_x1_24830) == NTAG(TAG_True))) {
        heff_drop(v_x1_24830);
        v_t_24831 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24830);
        v_t_24831 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24832 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24834 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24833})));
    V v_t_24835 = (g_std_2edoc_2e_3c_3e(v_a_24832, v_t_24834));
    return (g_std_2edoc_2e_3c_3e(v_t_24831, v_t_24835));
  }
  case TAG_EUSet: {
    V v_t_24839 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24842;
    if ((heff_dup(v_t_24839) == NTAG(TAG_True))) {
      heff_drop(v_t_24839);
      v_t_24842 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24839);
      V v_t_24840 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24841 = heff_get_n(v_t_24840, 6, 9);
      if ((heff_dup(v_x1_24841) == NTAG(TAG_True))) {
        heff_drop(v_x1_24841);
        v_t_24842 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24841);
        v_t_24842 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24843 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24845 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24844})));
    V v_t_24846 = (g_std_2edoc_2e_3c_3e(v_a_24843, v_t_24845));
    return (g_std_2edoc_2e_3c_3e(v_t_24842, v_t_24846));
  }
  case TAG_InstB: {
    V v_t_24852 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24855;
    if ((heff_dup(v_t_24852) == NTAG(TAG_True))) {
      heff_drop(v_t_24852);
      v_t_24855 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24852);
      V v_t_24853 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24854 = heff_get_n(v_t_24853, 6, 9);
      if ((heff_dup(v_x1_24854) == NTAG(TAG_True))) {
        heff_drop(v_x1_24854);
        v_t_24855 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24854);
        v_t_24855 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24856 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24857 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24858 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24857})));
    V v_t_24859 = (g_std_2edoc_2e_3c_3e(v_a_24856, v_t_24858));
    return (g_std_2edoc_2e_3c_3e(v_t_24855, v_t_24859));
  }
  case TAG_EFSet: {
    V v_t_24863 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24866;
    if ((heff_dup(v_t_24863) == NTAG(TAG_True))) {
      heff_drop(v_t_24863);
      v_t_24866 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24863);
      V v_t_24864 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24865 = heff_get_n(v_t_24864, 6, 9);
      if ((heff_dup(v_x1_24865) == NTAG(TAG_True))) {
        heff_drop(v_x1_24865);
        v_t_24866 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24865);
        v_t_24866 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24867 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24868 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24869 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24868})));
    V v_t_24870 = (g_std_2edoc_2e_3c_3e(v_a_24867, v_t_24869));
    return (g_std_2edoc_2e_3c_3e(v_t_24866, v_t_24870));
  }
  case TAG_EFDefault: {
    V v_t_24874 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24877;
    if ((heff_dup(v_t_24874) == NTAG(TAG_True))) {
      heff_drop(v_t_24874);
      v_t_24877 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24874);
      V v_t_24875 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24876 = heff_get_n(v_t_24875, 6, 9);
      if ((heff_dup(v_x1_24876) == NTAG(TAG_True))) {
        heff_drop(v_x1_24876);
        v_t_24877 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24876);
        v_t_24877 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24878 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24879 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24880 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24879})));
    V v_t_24881 = (g_std_2edoc_2e_3c_3e(v_a_24878, v_t_24880));
    return (g_std_2edoc_2e_3c_3e(v_t_24877, v_t_24881));
  }
  case TAG_Sum: {
    V v_t_24887 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24890;
    if ((heff_dup(v_t_24887) == NTAG(TAG_True))) {
      heff_drop(v_t_24887);
      v_t_24890 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24887);
      V v_t_24888 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24889 = heff_get_n(v_t_24888, 6, 9);
      if ((heff_dup(v_x1_24889) == NTAG(TAG_True))) {
        heff_drop(v_x1_24889);
        v_t_24890 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24889);
        v_t_24890 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24891 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24892 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24893 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24892})));
    V v_t_24894 = (g_std_2edoc_2e_3c_3e(v_a_24891, v_t_24893));
    return (g_std_2edoc_2e_3c_3e(v_t_24890, v_t_24894));
  }
  case TAG_ECon: {
    V v_t_24897 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24900;
    if ((heff_dup(v_t_24897) == NTAG(TAG_True))) {
      heff_drop(v_t_24897);
      v_t_24900 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24897);
      V v_t_24898 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24899 = heff_get_n(v_t_24898, 6, 9);
      if ((heff_dup(v_x1_24899) == NTAG(TAG_True))) {
        heff_drop(v_x1_24899);
        v_t_24900 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24899);
        v_t_24900 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24901 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24902 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24903 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24902})));
    V v_t_24904 = (g_std_2edoc_2e_3c_3e(v_a_24901, v_t_24903));
    return (g_std_2edoc_2e_3c_3e(v_t_24900, v_t_24904));
  }
  case TAG_EField: {
    V v_t_24907 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24910;
    if ((heff_dup(v_t_24907) == NTAG(TAG_True))) {
      heff_drop(v_t_24907);
      v_t_24910 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24907);
      V v_t_24908 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24909 = heff_get_n(v_t_24908, 6, 9);
      if ((heff_dup(v_x1_24909) == NTAG(TAG_True))) {
        heff_drop(v_x1_24909);
        v_t_24910 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24909);
        v_t_24910 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24911 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24912 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24913 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24912})));
    V v_t_24914 = (g_std_2edoc_2e_3c_3e(v_a_24911, v_t_24913));
    return (g_std_2edoc_2e_3c_3e(v_t_24910, v_t_24914));
  }
  case TAG_ENeg: {
    V v_t_24917 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24920;
    if ((heff_dup(v_t_24917) == NTAG(TAG_True))) {
      heff_drop(v_t_24917);
      v_t_24920 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24917);
      V v_t_24918 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24919 = heff_get_n(v_t_24918, 6, 9);
      if ((heff_dup(v_x1_24919) == NTAG(TAG_True))) {
        heff_drop(v_x1_24919);
        v_t_24920 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24919);
        v_t_24920 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24921 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24922 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24923 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24922})));
    V v_t_24924 = (g_std_2edoc_2e_3c_3e(v_a_24921, v_t_24923));
    return (g_std_2edoc_2e_3c_3e(v_t_24920, v_t_24924));
  }
  case TAG_App: {
    V v_t_24927 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24930;
    if ((heff_dup(v_t_24927) == NTAG(TAG_True))) {
      heff_drop(v_t_24927);
      v_t_24930 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24927);
      V v_t_24928 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24929 = heff_get_n(v_t_24928, 6, 9);
      if ((heff_dup(v_x1_24929) == NTAG(TAG_True))) {
        heff_drop(v_x1_24929);
        v_t_24930 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24929);
        v_t_24930 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24931 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24932 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24933 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24932})));
    V v_t_24934 = (g_std_2edoc_2e_3c_3e(v_a_24931, v_t_24933));
    return (g_std_2edoc_2e_3c_3e(v_t_24930, v_t_24934));
  }
  case TAG_Op: {
    V v_t_24938 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24941;
    if ((heff_dup(v_t_24938) == NTAG(TAG_True))) {
      heff_drop(v_t_24938);
      v_t_24941 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24938);
      V v_t_24939 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24940 = heff_get_n(v_t_24939, 6, 9);
      if ((heff_dup(v_x1_24940) == NTAG(TAG_True))) {
        heff_drop(v_x1_24940);
        v_t_24941 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24940);
        v_t_24941 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24942 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24943 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24944 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24943})));
    V v_t_24945 = (g_std_2edoc_2e_3c_3e(v_a_24942, v_t_24944));
    return (g_std_2edoc_2e_3c_3e(v_t_24941, v_t_24945));
  }
  case TAG_Ops: {
    V v_t_24948 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24951;
    if ((heff_dup(v_t_24948) == NTAG(TAG_True))) {
      heff_drop(v_t_24948);
      v_t_24951 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24948);
      V v_t_24949 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24950 = heff_get_n(v_t_24949, 6, 9);
      if ((heff_dup(v_x1_24950) == NTAG(TAG_True))) {
        heff_drop(v_x1_24950);
        v_t_24951 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24950);
        v_t_24951 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24952 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24953 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24954 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24953})));
    V v_t_24955 = (g_std_2edoc_2e_3c_3e(v_a_24952, v_t_24954));
    return (g_std_2edoc_2e_3c_3e(v_t_24951, v_t_24955));
  }
  case TAG_OpRhs: {
    V v_t_24958 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24961;
    if ((heff_dup(v_t_24958) == NTAG(TAG_True))) {
      heff_drop(v_t_24958);
      v_t_24961 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24958);
      V v_t_24959 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24960 = heff_get_n(v_t_24959, 6, 9);
      if ((heff_dup(v_x1_24960) == NTAG(TAG_True))) {
        heff_drop(v_x1_24960);
        v_t_24961 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24960);
        v_t_24961 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24962 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24963 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24964 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24963})));
    V v_t_24965 = (g_std_2edoc_2e_3c_3e(v_a_24962, v_t_24964));
    return (g_std_2edoc_2e_3c_3e(v_t_24961, v_t_24965));
  }
  case TAG_Ann: {
    V v_t_24969 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24972;
    if ((heff_dup(v_t_24969) == NTAG(TAG_True))) {
      heff_drop(v_t_24969);
      v_t_24972 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24969);
      V v_t_24970 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24971 = heff_get_n(v_t_24970, 6, 9);
      if ((heff_dup(v_x1_24971) == NTAG(TAG_True))) {
        heff_drop(v_x1_24971);
        v_t_24972 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24971);
        v_t_24972 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24973 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24974 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24975 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24974})));
    V v_t_24976 = (g_std_2edoc_2e_3c_3e(v_a_24973, v_t_24975));
    return (g_std_2edoc_2e_3c_3e(v_t_24972, v_t_24976));
  }
  case TAG_BVar: {
    V v_t_24978 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24981;
    if ((heff_dup(v_t_24978) == NTAG(TAG_True))) {
      heff_drop(v_t_24978);
      v_t_24981 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24978);
      V v_t_24979 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24980 = heff_get_n(v_t_24979, 6, 9);
      if ((heff_dup(v_x1_24980) == NTAG(TAG_True))) {
        heff_drop(v_x1_24980);
        v_t_24981 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24980);
        v_t_24981 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24982 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24983 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24984 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24983})));
    V v_t_24985 = (g_std_2edoc_2e_3c_3e(v_a_24982, v_t_24984));
    return (g_std_2edoc_2e_3c_3e(v_t_24981, v_t_24985));
  }
  case TAG_BImp: {
    V v_t_24989 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_24992;
    if ((heff_dup(v_t_24989) == NTAG(TAG_True))) {
      heff_drop(v_t_24989);
      v_t_24992 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24989);
      V v_t_24990 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_24991 = heff_get_n(v_t_24990, 6, 9);
      if ((heff_dup(v_x1_24991) == NTAG(TAG_True))) {
        heff_drop(v_x1_24991);
        v_t_24992 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24991);
        v_t_24992 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24993 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_24994 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_24995 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24994})));
    V v_t_24996 = (g_std_2edoc_2e_3c_3e(v_a_24993, v_t_24995));
    return (g_std_2edoc_2e_3c_3e(v_t_24992, v_t_24996));
  }
  case TAG_BAnn: {
    V v_t_241002 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241005;
    if ((heff_dup(v_t_241002) == NTAG(TAG_True))) {
      heff_drop(v_t_241002);
      v_t_241005 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241002);
      V v_t_241003 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241004 = heff_get_n(v_t_241003, 6, 9);
      if ((heff_dup(v_x1_241004) == NTAG(TAG_True))) {
        heff_drop(v_x1_241004);
        v_t_241005 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241004);
        v_t_241005 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241006 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241007 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241008 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241007})));
    V v_t_241009 = (g_std_2edoc_2e_3c_3e(v_a_241006, v_t_241008));
    return (g_std_2edoc_2e_3c_3e(v_t_241005, v_t_241009));
  }
  case TAG_Lam: {
    V v_t_241014 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241017;
    if ((heff_dup(v_t_241014) == NTAG(TAG_True))) {
      heff_drop(v_t_241014);
      v_t_241017 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241014);
      V v_t_241015 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241016 = heff_get_n(v_t_241015, 6, 9);
      if ((heff_dup(v_x1_241016) == NTAG(TAG_True))) {
        heff_drop(v_x1_241016);
        v_t_241017 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241016);
        v_t_241017 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241018 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241019 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241020 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241019})));
    V v_t_241021 = (g_std_2edoc_2e_3c_3e(v_a_241018, v_t_241020));
    return (g_std_2edoc_2e_3c_3e(v_t_241017, v_t_241021));
  }
  case TAG_Case: {
    V v_t_241026 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241029;
    if ((heff_dup(v_t_241026) == NTAG(TAG_True))) {
      heff_drop(v_t_241026);
      v_t_241029 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241026);
      V v_t_241027 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241028 = heff_get_n(v_t_241027, 6, 9);
      if ((heff_dup(v_x1_241028) == NTAG(TAG_True))) {
        heff_drop(v_x1_241028);
        v_t_241029 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241028);
        v_t_241029 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241030 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241031 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241032 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241031})));
    V v_t_241033 = (g_std_2edoc_2e_3c_3e(v_a_241030, v_t_241032));
    return (g_std_2edoc_2e_3c_3e(v_t_241029, v_t_241033));
  }
  case TAG_EAlt: {
    V v_t_241037 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241040;
    if ((heff_dup(v_t_241037) == NTAG(TAG_True))) {
      heff_drop(v_t_241037);
      v_t_241040 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241037);
      V v_t_241038 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241039 = heff_get_n(v_t_241038, 6, 9);
      if ((heff_dup(v_x1_241039) == NTAG(TAG_True))) {
        heff_drop(v_x1_241039);
        v_t_241040 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241039);
        v_t_241040 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241041 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241042 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241043 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241042})));
    V v_t_241044 = (g_std_2edoc_2e_3c_3e(v_a_241041, v_t_241043));
    return (g_std_2edoc_2e_3c_3e(v_t_241040, v_t_241044));
  }
  case TAG_If: {
    V v_kw_241045 = heff_dup(heff_field(v_b_24753, 0));
    V v_c_241046 = heff_dup(heff_field(v_b_24753, 1));
    V v_th_241047 = heff_dup(heff_field(v_b_24753, 2));
    V v_a_241048 = heff_dup(heff_field(v_b_24753, 3));
    V v_el2_241049 = heff_dup(heff_field(v_b_24753, 4));
    V v_b2_241050 = heff_dup(heff_field(v_b_24753, 5));
    V v_t_241051 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241054;
    if ((heff_dup(v_t_241051) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24753, 6);
      heff_drop(v_t_241051);
      v_t_241054 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241051);
      V v_t_241052 = ({ V a_0 = v_b_24753; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24753, 6); r_; });
      V v_x1_241053 = heff_get_n(v_t_241052, 6, 9);
      if ((heff_dup(v_x1_241053) == NTAG(TAG_True))) {
        heff_drop(v_x1_241053);
        v_t_241054 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241053);
        v_t_241054 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241055 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_b_241056 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24751), v_kw_241045, v_c_241046, v_th_241047, v_a_241048}));
    V v_t_241057 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241056));
    V v_t_241058 = (g_std_2edoc_2e_3c_3e(v_a_241055, v_t_241057));
    V v_t_241059 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24751, v_el2_241049, v_b2_241050}));
    V v_t_241060 = (g_std_2edoc_2e_3c_3e(v_t_241058, v_t_241059));
    return (g_std_2edoc_2e_3c_3e(v_t_241054, v_t_241060));
  }
  case TAG_Do: {
    V v_t_241063 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241066;
    if ((heff_dup(v_t_241063) == NTAG(TAG_True))) {
      heff_drop(v_t_241063);
      v_t_241066 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241063);
      V v_t_241064 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241065 = heff_get_n(v_t_241064, 6, 9);
      if ((heff_dup(v_x1_241065) == NTAG(TAG_True))) {
        heff_drop(v_x1_241065);
        v_t_241066 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241065);
        v_t_241066 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241067 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241068 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241069 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241068})));
    V v_t_241070 = (g_std_2edoc_2e_3c_3e(v_a_241067, v_t_241069));
    return (g_std_2edoc_2e_3c_3e(v_t_241066, v_t_241070));
  }
  case TAG_ESBind: {
    V v_t_241074 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241077;
    if ((heff_dup(v_t_241074) == NTAG(TAG_True))) {
      heff_drop(v_t_241074);
      v_t_241077 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241074);
      V v_t_241075 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241076 = heff_get_n(v_t_241075, 6, 9);
      if ((heff_dup(v_x1_241076) == NTAG(TAG_True))) {
        heff_drop(v_x1_241076);
        v_t_241077 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241076);
        v_t_241077 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241078 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241080 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241079})));
    V v_t_241081 = (g_std_2edoc_2e_3c_3e(v_a_241078, v_t_241080));
    return (g_std_2edoc_2e_3c_3e(v_t_241077, v_t_241081));
  }
  case TAG_ELet: {
    V v_t_241088 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241091;
    if ((heff_dup(v_t_241088) == NTAG(TAG_True))) {
      heff_drop(v_t_241088);
      v_t_241091 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241088);
      V v_t_241089 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241090 = heff_get_n(v_t_241089, 6, 9);
      if ((heff_dup(v_x1_241090) == NTAG(TAG_True))) {
        heff_drop(v_x1_241090);
        v_t_241091 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241090);
        v_t_241091 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241092 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241093 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241094 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241093})));
    V v_t_241095 = (g_std_2edoc_2e_3c_3e(v_a_241092, v_t_241094));
    return (g_std_2edoc_2e_3c_3e(v_t_241091, v_t_241095));
  }
  case TAG_ELetMut: {
    V v_t_241102 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241105;
    if ((heff_dup(v_t_241102) == NTAG(TAG_True))) {
      heff_drop(v_t_241102);
      v_t_241105 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241102);
      V v_t_241103 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241104 = heff_get_n(v_t_241103, 6, 9);
      if ((heff_dup(v_x1_241104) == NTAG(TAG_True))) {
        heff_drop(v_x1_241104);
        v_t_241105 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241104);
        v_t_241105 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241106 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241108 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241107})));
    V v_t_241109 = (g_std_2edoc_2e_3c_3e(v_a_241106, v_t_241108));
    return (g_std_2edoc_2e_3c_3e(v_t_241105, v_t_241109));
  }
  case TAG_EAssign: {
    V v_t_241113 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241116;
    if ((heff_dup(v_t_241113) == NTAG(TAG_True))) {
      heff_drop(v_t_241113);
      v_t_241116 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241113);
      V v_t_241114 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241115 = heff_get_n(v_t_241114, 6, 9);
      if ((heff_dup(v_x1_241115) == NTAG(TAG_True))) {
        heff_drop(v_x1_241115);
        v_t_241116 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241115);
        v_t_241116 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241117 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241119 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241118})));
    V v_t_241120 = (g_std_2edoc_2e_3c_3e(v_a_241117, v_t_241119));
    return (g_std_2edoc_2e_3c_3e(v_t_241116, v_t_241120));
  }
  case TAG_EWhile: {
    V v_t_241125 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241128;
    if ((heff_dup(v_t_241125) == NTAG(TAG_True))) {
      heff_drop(v_t_241125);
      v_t_241128 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241125);
      V v_t_241126 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241127 = heff_get_n(v_t_241126, 6, 9);
      if ((heff_dup(v_x1_241127) == NTAG(TAG_True))) {
        heff_drop(v_x1_241127);
        v_t_241128 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241127);
        v_t_241128 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241129 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241130 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241131 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241130})));
    V v_t_241132 = (g_std_2edoc_2e_3c_3e(v_a_241129, v_t_241131));
    return (g_std_2edoc_2e_3c_3e(v_t_241128, v_t_241132));
  }
  case TAG_EFor: {
    V v_t_241139 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241142;
    if ((heff_dup(v_t_241139) == NTAG(TAG_True))) {
      heff_drop(v_t_241139);
      v_t_241142 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241139);
      V v_t_241140 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241141 = heff_get_n(v_t_241140, 6, 9);
      if ((heff_dup(v_x1_241141) == NTAG(TAG_True))) {
        heff_drop(v_x1_241141);
        v_t_241142 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241141);
        v_t_241142 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241143 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241144 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241145 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241144})));
    V v_t_241146 = (g_std_2edoc_2e_3c_3e(v_a_241143, v_t_241145));
    return (g_std_2edoc_2e_3c_3e(v_t_241142, v_t_241146));
  }
  case TAG_EJump: {
    V v_t_241148 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241151;
    if ((heff_dup(v_t_241148) == NTAG(TAG_True))) {
      heff_drop(v_t_241148);
      v_t_241151 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241148);
      V v_t_241149 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241150 = heff_get_n(v_t_241149, 6, 9);
      if ((heff_dup(v_x1_241150) == NTAG(TAG_True))) {
        heff_drop(v_x1_241150);
        v_t_241151 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241150);
        v_t_241151 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241152 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241154 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241153})));
    V v_t_241155 = (g_std_2edoc_2e_3c_3e(v_a_241152, v_t_241154));
    return (g_std_2edoc_2e_3c_3e(v_t_241151, v_t_241155));
  }
  case TAG_EReturn: {
    V v_t_241158 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241161;
    if ((heff_dup(v_t_241158) == NTAG(TAG_True))) {
      heff_drop(v_t_241158);
      v_t_241161 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241158);
      V v_t_241159 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241160 = heff_get_n(v_t_241159, 6, 9);
      if ((heff_dup(v_x1_241160) == NTAG(TAG_True))) {
        heff_drop(v_x1_241160);
        v_t_241161 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241160);
        v_t_241161 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241162 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241163 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241164 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241163})));
    V v_t_241165 = (g_std_2edoc_2e_3c_3e(v_a_241162, v_t_241164));
    return (g_std_2edoc_2e_3c_3e(v_t_241161, v_t_241165));
  }
  case TAG_ENest: {
    V v_t_241170 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241173;
    if ((heff_dup(v_t_241170) == NTAG(TAG_True))) {
      heff_drop(v_t_241170);
      v_t_241173 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241170);
      V v_t_241171 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241172 = heff_get_n(v_t_241171, 6, 9);
      if ((heff_dup(v_x1_241172) == NTAG(TAG_True))) {
        heff_drop(v_x1_241172);
        v_t_241173 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241172);
        v_t_241173 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241174 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241175 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241175})));
    V v_t_241177 = (g_std_2edoc_2e_3c_3e(v_a_241174, v_t_241176));
    return (g_std_2edoc_2e_3c_3e(v_t_241173, v_t_241177));
  }
  case TAG_IfThen: {
    V v_t_241182 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241185;
    if ((heff_dup(v_t_241182) == NTAG(TAG_True))) {
      heff_drop(v_t_241182);
      v_t_241185 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241182);
      V v_t_241183 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241184 = heff_get_n(v_t_241183, 6, 9);
      if ((heff_dup(v_x1_241184) == NTAG(TAG_True))) {
        heff_drop(v_x1_241184);
        v_t_241185 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241184);
        v_t_241185 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241186 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241187 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241188 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241187})));
    V v_t_241189 = (g_std_2edoc_2e_3c_3e(v_a_241186, v_t_241188));
    return (g_std_2edoc_2e_3c_3e(v_t_241185, v_t_241189));
  }
  case TAG_ELetCond: {
    V v_t_241194 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241197;
    if ((heff_dup(v_t_241194) == NTAG(TAG_True))) {
      heff_drop(v_t_241194);
      v_t_241197 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241194);
      V v_t_241195 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241196 = heff_get_n(v_t_241195, 6, 9);
      if ((heff_dup(v_x1_241196) == NTAG(TAG_True))) {
        heff_drop(v_x1_241196);
        v_t_241197 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241196);
        v_t_241197 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241198 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241199 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241200 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241199})));
    V v_t_241201 = (g_std_2edoc_2e_3c_3e(v_a_241198, v_t_241200));
    return (g_std_2edoc_2e_3c_3e(v_t_241197, v_t_241201));
  }
  case TAG_ETry: {
    V v_t_241206 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241209;
    if ((heff_dup(v_t_241206) == NTAG(TAG_True))) {
      heff_drop(v_t_241206);
      v_t_241209 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241206);
      V v_t_241207 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241208 = heff_get_n(v_t_241207, 6, 9);
      if ((heff_dup(v_x1_241208) == NTAG(TAG_True))) {
        heff_drop(v_x1_241208);
        v_t_241209 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241208);
        v_t_241209 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241210 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241211 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241212 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241211})));
    V v_t_241213 = (g_std_2edoc_2e_3c_3e(v_a_241210, v_t_241212));
    return (g_std_2edoc_2e_3c_3e(v_t_241209, v_t_241213));
  }
  case TAG_ECatch: {
    V v_t_241218 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241221;
    if ((heff_dup(v_t_241218) == NTAG(TAG_True))) {
      heff_drop(v_t_241218);
      v_t_241221 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241218);
      V v_t_241219 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241220 = heff_get_n(v_t_241219, 6, 9);
      if ((heff_dup(v_x1_241220) == NTAG(TAG_True))) {
        heff_drop(v_x1_241220);
        v_t_241221 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241220);
        v_t_241221 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241222 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241224 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241223})));
    V v_t_241225 = (g_std_2edoc_2e_3c_3e(v_a_241222, v_t_241224));
    return (g_std_2edoc_2e_3c_3e(v_t_241221, v_t_241225));
  }
  case TAG_EWith: {
    V v_t_241232 = heff_dup(heff_rfield(v_el_24752, 6));
    V v_t_241235;
    if ((heff_dup(v_t_241232) == NTAG(TAG_True))) {
      heff_drop(v_t_241232);
      v_t_241235 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241232);
      V v_t_241233 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24753));
      V v_x1_241234 = heff_get_n(v_t_241233, 6, 9);
      if ((heff_dup(v_x1_241234) == NTAG(TAG_True))) {
        heff_drop(v_x1_241234);
        v_t_241235 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241234);
        v_t_241235 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241236 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24751), v_el_24752));
    V v_d_241237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24751, v_b_24753}));
    V v_t_241238 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241237})));
    V v_t_241239 = (g_std_2edoc_2e_3c_3e(v_a_241236, v_t_241238));
    return (g_std_2edoc_2e_3c_3e(v_t_241235, v_t_241239));
  }
  default: return heff_nomatch(v_b_24753);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241251 = args[0];
  V v_one_241250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241252 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241251));
  V v_x1_241253 = heff_get_n(v_t_241252, 6, 9);
  V v_t_241254;
  if ((heff_dup(v_x1_241253) == NTAG(TAG_True))) {
    heff_drop(v_x1_241253);
    v_t_241254 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241253);
    v_t_241254 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241255 = heff_tr(heff_call(v_one_241250, 1, (V[]){v_a_241251}));
  return (g_std_2edoc_2e_3c_3e(v_t_241254, v_t_241255));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241263 = args[0];
  V v_one_241262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241264 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241263));
  V v_x1_241265 = heff_get_n(v_t_241264, 6, 9);
  V v_t_241266;
  if ((heff_dup(v_x1_241265) == NTAG(TAG_True))) {
    heff_drop(v_x1_241265);
    v_t_241266 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241265);
    v_t_241266 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241267 = heff_tr(heff_call(v_one_241262, 1, (V[]){v_a_241263}));
  return (g_std_2edoc_2e_3c_3e(v_t_241266, v_t_241267));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241276 = args[0];
  V v_one_241275 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241277 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241276));
  V v_x1_241278 = heff_get_n(v_t_241277, 6, 9);
  V v_t_241279;
  if ((heff_dup(v_x1_241278) == NTAG(TAG_True))) {
    heff_drop(v_x1_241278);
    v_t_241279 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241278);
    v_t_241279 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241280 = heff_tr(heff_call(v_one_241275, 1, (V[]){v_a_241276}));
  return (g_std_2edoc_2e_3c_3e(v_t_241279, v_t_241280));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241292 = args[0];
  V v_one_241291 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241293 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241292));
  V v_x1_241294 = heff_get_n(v_t_241293, 6, 9);
  V v_t_241295;
  if ((heff_dup(v_x1_241294) == NTAG(TAG_True))) {
    heff_drop(v_x1_241294);
    v_t_241295 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241294);
    v_t_241295 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241296 = heff_tr(heff_call(v_one_241291, 1, (V[]){v_a_241292}));
  return (g_std_2edoc_2e_3c_3e(v_t_241295, v_t_241296));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241307 = args[0];
  V v_one_241306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241308 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241307));
  V v_x1_241309 = heff_get_n(v_t_241308, 6, 9);
  V v_t_241310;
  if ((heff_dup(v_x1_241309) == NTAG(TAG_True))) {
    heff_drop(v_x1_241309);
    v_t_241310 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241309);
    v_t_241310 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241311 = heff_tr(heff_call(v_one_241306, 1, (V[]){v_a_241307}));
  return (g_std_2edoc_2e_3c_3e(v_t_241310, v_t_241311));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241319 = args[0];
  V v_one_241318 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241320 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241319));
  V v_x1_241321 = heff_get_n(v_t_241320, 6, 9);
  V v_t_241322;
  if ((heff_dup(v_x1_241321) == NTAG(TAG_True))) {
    heff_drop(v_x1_241321);
    v_t_241322 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241321);
    v_t_241322 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241323 = heff_tr(heff_call(v_one_241318, 1, (V[]){v_a_241319}));
  return (g_std_2edoc_2e_3c_3e(v_t_241322, v_t_241323));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241333 = args[0];
  V v_one_241332 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241334 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241333));
  V v_x1_241335 = heff_get_n(v_t_241334, 6, 9);
  V v_t_241336;
  if ((heff_dup(v_x1_241335) == NTAG(TAG_True))) {
    heff_drop(v_x1_241335);
    v_t_241336 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241335);
    v_t_241336 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241337 = heff_tr(heff_call(v_one_241332, 1, (V[]){v_a_241333}));
  return (g_std_2edoc_2e_3c_3e(v_t_241336, v_t_241337));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241345 = args[0];
  V v_one_241344 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241346 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241345));
  V v_x1_241347 = heff_get_n(v_t_241346, 6, 9);
  V v_t_241348;
  if ((heff_dup(v_x1_241347) == NTAG(TAG_True))) {
    heff_drop(v_x1_241347);
    v_t_241348 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241347);
    v_t_241348 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241349 = heff_tr(heff_call(v_one_241344, 1, (V[]){v_a_241345}));
  return (g_std_2edoc_2e_3c_3e(v_t_241348, v_t_241349));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241358 = args[0];
  V v_one_241357 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241359 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241358));
  V v_x1_241360 = heff_get_n(v_t_241359, 6, 9);
  V v_t_241361;
  if ((heff_dup(v_x1_241360) == NTAG(TAG_True))) {
    heff_drop(v_x1_241360);
    v_t_241361 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241360);
    v_t_241361 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241362 = heff_tr(heff_call(v_one_241357, 1, (V[]){v_a_241358}));
  return (g_std_2edoc_2e_3c_3e(v_t_241361, v_t_241362));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241370 = args[0];
  V v_one_241369 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241371 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241370));
  V v_x1_241372 = heff_get_n(v_t_241371, 6, 9);
  V v_t_241373;
  if ((heff_dup(v_x1_241372) == NTAG(TAG_True))) {
    heff_drop(v_x1_241372);
    v_t_241373 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241372);
    v_t_241373 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241374 = heff_tr(heff_call(v_one_241369, 1, (V[]){v_a_241370}));
  return (g_std_2edoc_2e_3c_3e(v_t_241373, v_t_241374));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241384 = args[0];
  V v_one_241383 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241385 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241384));
  V v_x1_241386 = heff_get_n(v_t_241385, 6, 9);
  V v_t_241387;
  if ((heff_dup(v_x1_241386) == NTAG(TAG_True))) {
    heff_drop(v_x1_241386);
    v_t_241387 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241386);
    v_t_241387 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241388 = heff_tr(heff_call(v_one_241383, 1, (V[]){v_a_241384}));
  return (g_std_2edoc_2e_3c_3e(v_t_241387, v_t_241388));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241396 = args[0];
  V v_one_241395 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241397 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241396));
  V v_x1_241398 = heff_get_n(v_t_241397, 6, 9);
  V v_t_241399;
  if ((heff_dup(v_x1_241398) == NTAG(TAG_True))) {
    heff_drop(v_x1_241398);
    v_t_241399 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241398);
    v_t_241399 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241400 = heff_tr(heff_call(v_one_241395, 1, (V[]){v_a_241396}));
  return (g_std_2edoc_2e_3c_3e(v_t_241399, v_t_241400));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241412 = args[0];
  V v_one_241411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241413 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241412));
  V v_x1_241414 = heff_get_n(v_t_241413, 6, 9);
  V v_t_241415;
  if ((heff_dup(v_x1_241414) == NTAG(TAG_True))) {
    heff_drop(v_x1_241414);
    v_t_241415 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241414);
    v_t_241415 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241416 = heff_tr(heff_call(v_one_241411, 1, (V[]){v_a_241412}));
  return (g_std_2edoc_2e_3c_3e(v_t_241415, v_t_241416));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241424 = args[0];
  V v_one_241423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241425 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241424));
  V v_x1_241426 = heff_get_n(v_t_241425, 6, 9);
  V v_t_241427;
  if ((heff_dup(v_x1_241426) == NTAG(TAG_True))) {
    heff_drop(v_x1_241426);
    v_t_241427 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241426);
    v_t_241427 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241428 = heff_tr(heff_call(v_one_241423, 1, (V[]){v_a_241424}));
  return (g_std_2edoc_2e_3c_3e(v_t_241427, v_t_241428));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241437 = args[0];
  V v_one_241436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241438 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241437));
  V v_x1_241439 = heff_get_n(v_t_241438, 6, 9);
  V v_t_241440;
  if ((heff_dup(v_x1_241439) == NTAG(TAG_True))) {
    heff_drop(v_x1_241439);
    v_t_241440 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241439);
    v_t_241440 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241441 = heff_tr(heff_call(v_one_241436, 1, (V[]){v_a_241437}));
  return (g_std_2edoc_2e_3c_3e(v_t_241440, v_t_241441));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241449 = args[0];
  V v_one_241448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241450 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241449));
  V v_x1_241451 = heff_get_n(v_t_241450, 6, 9);
  V v_t_241452;
  if ((heff_dup(v_x1_241451) == NTAG(TAG_True))) {
    heff_drop(v_x1_241451);
    v_t_241452 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241451);
    v_t_241452 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241453 = heff_tr(heff_call(v_one_241448, 1, (V[]){v_a_241449}));
  return (g_std_2edoc_2e_3c_3e(v_t_241452, v_t_241453));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241464 = args[0];
  V v_one_241463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241465 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241464));
  V v_x1_241466 = heff_get_n(v_t_241465, 6, 9);
  V v_t_241467;
  if ((heff_dup(v_x1_241466) == NTAG(TAG_True))) {
    heff_drop(v_x1_241466);
    v_t_241467 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241466);
    v_t_241467 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241468 = heff_tr(heff_call(v_one_241463, 1, (V[]){v_a_241464}));
  return (g_std_2edoc_2e_3c_3e(v_t_241467, v_t_241468));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241476 = args[0];
  V v_one_241475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241477 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241476));
  V v_x1_241478 = heff_get_n(v_t_241477, 6, 9);
  V v_t_241479;
  if ((heff_dup(v_x1_241478) == NTAG(TAG_True))) {
    heff_drop(v_x1_241478);
    v_t_241479 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241478);
    v_t_241479 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241480 = heff_tr(heff_call(v_one_241475, 1, (V[]){v_a_241476}));
  return (g_std_2edoc_2e_3c_3e(v_t_241479, v_t_241480));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241489 = args[0];
  V v_one_241488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241490 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241489));
  V v_x1_241491 = heff_get_n(v_t_241490, 6, 9);
  V v_t_241492;
  if ((heff_dup(v_x1_241491) == NTAG(TAG_True))) {
    heff_drop(v_x1_241491);
    v_t_241492 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241491);
    v_t_241492 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241493 = heff_tr(heff_call(v_one_241488, 1, (V[]){v_a_241489}));
  return (g_std_2edoc_2e_3c_3e(v_t_241492, v_t_241493));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241501 = args[0];
  V v_one_241500 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241502 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241501));
  V v_x1_241503 = heff_get_n(v_t_241502, 6, 9);
  V v_t_241504;
  if ((heff_dup(v_x1_241503) == NTAG(TAG_True))) {
    heff_drop(v_x1_241503);
    v_t_241504 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241503);
    v_t_241504 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241505 = heff_tr(heff_call(v_one_241500, 1, (V[]){v_a_241501}));
  return (g_std_2edoc_2e_3c_3e(v_t_241504, v_t_241505));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241514 = args[0];
  V v_one_241513 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241515 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241514));
  V v_x1_241516 = heff_get_n(v_t_241515, 6, 9);
  V v_t_241517;
  if ((heff_dup(v_x1_241516) == NTAG(TAG_True))) {
    heff_drop(v_x1_241516);
    v_t_241517 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241516);
    v_t_241517 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241518 = heff_tr(heff_call(v_one_241513, 1, (V[]){v_a_241514}));
  return (g_std_2edoc_2e_3c_3e(v_t_241517, v_t_241518));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241526 = args[0];
  V v_one_241525 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241527 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241526));
  V v_x1_241528 = heff_get_n(v_t_241527, 6, 9);
  V v_t_241529;
  if ((heff_dup(v_x1_241528) == NTAG(TAG_True))) {
    heff_drop(v_x1_241528);
    v_t_241529 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241528);
    v_t_241529 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241530 = heff_tr(heff_call(v_one_241525, 1, (V[]){v_a_241526}));
  return (g_std_2edoc_2e_3c_3e(v_t_241529, v_t_241530));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241541 = args[0];
  V v_one_241540 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241542 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241541));
  V v_x1_241543 = heff_get_n(v_t_241542, 6, 9);
  V v_t_241544;
  if ((heff_dup(v_x1_241543) == NTAG(TAG_True))) {
    heff_drop(v_x1_241543);
    v_t_241544 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241543);
    v_t_241544 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241545 = heff_tr(heff_call(v_one_241540, 1, (V[]){v_a_241541}));
  return (g_std_2edoc_2e_3c_3e(v_t_241544, v_t_241545));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241553 = args[0];
  V v_one_241552 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241554 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241553));
  V v_x1_241555 = heff_get_n(v_t_241554, 6, 9);
  V v_t_241556;
  if ((heff_dup(v_x1_241555) == NTAG(TAG_True))) {
    heff_drop(v_x1_241555);
    v_t_241556 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241555);
    v_t_241556 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241557 = heff_tr(heff_call(v_one_241552, 1, (V[]){v_a_241553}));
  return (g_std_2edoc_2e_3c_3e(v_t_241556, v_t_241557));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241565 = args[0];
  V v_one_241564 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241566 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241565));
  V v_x1_241567 = heff_get_n(v_t_241566, 6, 9);
  V v_t_241568;
  if ((heff_dup(v_x1_241567) == NTAG(TAG_True))) {
    heff_drop(v_x1_241567);
    v_t_241568 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241567);
    v_t_241568 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241569 = heff_tr(heff_call(v_one_241564, 1, (V[]){v_a_241565}));
  return (g_std_2edoc_2e_3c_3e(v_t_241568, v_t_241569));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241577 = args[0];
  V v_one_241576 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241578 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241577));
  V v_x1_241579 = heff_get_n(v_t_241578, 6, 9);
  V v_t_241580;
  if ((heff_dup(v_x1_241579) == NTAG(TAG_True))) {
    heff_drop(v_x1_241579);
    v_t_241580 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241579);
    v_t_241580 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241581 = heff_tr(heff_call(v_one_241576, 1, (V[]){v_a_241577}));
  return (g_std_2edoc_2e_3c_3e(v_t_241580, v_t_241581));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241589 = args[0];
  V v_one_241588 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241590 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241589));
  V v_x1_241591 = heff_get_n(v_t_241590, 6, 9);
  V v_t_241592;
  if ((heff_dup(v_x1_241591) == NTAG(TAG_True))) {
    heff_drop(v_x1_241591);
    v_t_241592 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241591);
    v_t_241592 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241593 = heff_tr(heff_call(v_one_241588, 1, (V[]){v_a_241589}));
  return (g_std_2edoc_2e_3c_3e(v_t_241592, v_t_241593));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241601 = args[0];
  V v_one_241600 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241602 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241601));
  V v_x1_241603 = heff_get_n(v_t_241602, 6, 9);
  V v_t_241604;
  if ((heff_dup(v_x1_241603) == NTAG(TAG_True))) {
    heff_drop(v_x1_241603);
    v_t_241604 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241603);
    v_t_241604 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241605 = heff_tr(heff_call(v_one_241600, 1, (V[]){v_a_241601}));
  return (g_std_2edoc_2e_3c_3e(v_t_241604, v_t_241605));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241613 = args[0];
  V v_one_241612 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241614 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241613));
  V v_x1_241615 = heff_get_n(v_t_241614, 6, 9);
  V v_t_241616;
  if ((heff_dup(v_x1_241615) == NTAG(TAG_True))) {
    heff_drop(v_x1_241615);
    v_t_241616 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241615);
    v_t_241616 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241617 = heff_tr(heff_call(v_one_241612, 1, (V[]){v_a_241613}));
  return (g_std_2edoc_2e_3c_3e(v_t_241616, v_t_241617));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241625 = args[0];
  V v_one_241624 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241626 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241625));
  V v_x1_241627 = heff_get_n(v_t_241626, 6, 9);
  V v_t_241628;
  if ((heff_dup(v_x1_241627) == NTAG(TAG_True))) {
    heff_drop(v_x1_241627);
    v_t_241628 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241627);
    v_t_241628 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241629 = heff_tr(heff_call(v_one_241624, 1, (V[]){v_a_241625}));
  return (g_std_2edoc_2e_3c_3e(v_t_241628, v_t_241629));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241637 = args[0];
  V v_one_241636 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241638 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241637));
  V v_x1_241639 = heff_get_n(v_t_241638, 6, 9);
  V v_t_241640;
  if ((heff_dup(v_x1_241639) == NTAG(TAG_True))) {
    heff_drop(v_x1_241639);
    v_t_241640 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241639);
    v_t_241640 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241641 = heff_tr(heff_call(v_one_241636, 1, (V[]){v_a_241637}));
  return (g_std_2edoc_2e_3c_3e(v_t_241640, v_t_241641));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241649 = args[0];
  V v_one_241648 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241650 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241649));
  V v_x1_241651 = heff_get_n(v_t_241650, 6, 9);
  V v_t_241652;
  if ((heff_dup(v_x1_241651) == NTAG(TAG_True))) {
    heff_drop(v_x1_241651);
    v_t_241652 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241651);
    v_t_241652 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241653 = heff_tr(heff_call(v_one_241648, 1, (V[]){v_a_241649}));
  return (g_std_2edoc_2e_3c_3e(v_t_241652, v_t_241653));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241662 = args[0];
  V v_one_241661 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241663 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241662));
  V v_x1_241664 = heff_get_n(v_t_241663, 6, 9);
  V v_t_241665;
  if ((heff_dup(v_x1_241664) == NTAG(TAG_True))) {
    heff_drop(v_x1_241664);
    v_t_241665 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241664);
    v_t_241665 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241666 = heff_tr(heff_call(v_one_241661, 1, (V[]){v_a_241662}));
  return (g_std_2edoc_2e_3c_3e(v_t_241665, v_t_241666));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241674 = args[0];
  V v_one_241673 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241675 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241674));
  V v_x1_241676 = heff_get_n(v_t_241675, 6, 9);
  V v_t_241677;
  if ((heff_dup(v_x1_241676) == NTAG(TAG_True))) {
    heff_drop(v_x1_241676);
    v_t_241677 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241676);
    v_t_241677 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241678 = heff_tr(heff_call(v_one_241673, 1, (V[]){v_a_241674}));
  return (g_std_2edoc_2e_3c_3e(v_t_241677, v_t_241678));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241686 = args[0];
  V v_one_241685 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241687 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241686));
  V v_x1_241688 = heff_get_n(v_t_241687, 6, 9);
  V v_t_241689;
  if ((heff_dup(v_x1_241688) == NTAG(TAG_True))) {
    heff_drop(v_x1_241688);
    v_t_241689 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241688);
    v_t_241689 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241690 = heff_tr(heff_call(v_one_241685, 1, (V[]){v_a_241686}));
  return (g_std_2edoc_2e_3c_3e(v_t_241689, v_t_241690));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241698 = args[0];
  V v_one_241697 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241699 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241698));
  V v_x1_241700 = heff_get_n(v_t_241699, 6, 9);
  V v_t_241701;
  if ((heff_dup(v_x1_241700) == NTAG(TAG_True))) {
    heff_drop(v_x1_241700);
    v_t_241701 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241700);
    v_t_241701 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241702 = heff_tr(heff_call(v_one_241697, 1, (V[]){v_a_241698}));
  return (g_std_2edoc_2e_3c_3e(v_t_241701, v_t_241702));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241710 = args[0];
  V v_one_241709 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241711 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241710));
  V v_x1_241712 = heff_get_n(v_t_241711, 6, 9);
  V v_t_241713;
  if ((heff_dup(v_x1_241712) == NTAG(TAG_True))) {
    heff_drop(v_x1_241712);
    v_t_241713 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241712);
    v_t_241713 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241714 = heff_tr(heff_call(v_one_241709, 1, (V[]){v_a_241710}));
  return (g_std_2edoc_2e_3c_3e(v_t_241713, v_t_241714));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241722 = args[0];
  V v_one_241721 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241723 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241722));
  V v_x1_241724 = heff_get_n(v_t_241723, 6, 9);
  V v_t_241725;
  if ((heff_dup(v_x1_241724) == NTAG(TAG_True))) {
    heff_drop(v_x1_241724);
    v_t_241725 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241724);
    v_t_241725 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241726 = heff_tr(heff_call(v_one_241721, 1, (V[]){v_a_241722}));
  return (g_std_2edoc_2e_3c_3e(v_t_241725, v_t_241726));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241735 = args[0];
  V v_one_241734 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241736 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241735));
  V v_x1_241737 = heff_get_n(v_t_241736, 6, 9);
  V v_t_241738;
  if ((heff_dup(v_x1_241737) == NTAG(TAG_True))) {
    heff_drop(v_x1_241737);
    v_t_241738 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241737);
    v_t_241738 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241739 = heff_tr(heff_call(v_one_241734, 1, (V[]){v_a_241735}));
  return (g_std_2edoc_2e_3c_3e(v_t_241738, v_t_241739));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241747 = args[0];
  V v_one_241746 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241748 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241747));
  V v_x1_241749 = heff_get_n(v_t_241748, 6, 9);
  V v_t_241750;
  if ((heff_dup(v_x1_241749) == NTAG(TAG_True))) {
    heff_drop(v_x1_241749);
    v_t_241750 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241749);
    v_t_241750 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241751 = heff_tr(heff_call(v_one_241746, 1, (V[]){v_a_241747}));
  return (g_std_2edoc_2e_3c_3e(v_t_241750, v_t_241751));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241758 = args[0];
  V v_one_241757 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241759 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241758));
  V v_x1_241760 = heff_get_n(v_t_241759, 6, 9);
  V v_t_241761;
  if ((heff_dup(v_x1_241760) == NTAG(TAG_True))) {
    heff_drop(v_x1_241760);
    v_t_241761 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241760);
    v_t_241761 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241762 = heff_tr(heff_call(v_one_241757, 1, (V[]){v_a_241758}));
  return (g_std_2edoc_2e_3c_3e(v_t_241761, v_t_241762));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241770 = args[0];
  V v_one_241769 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241771 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241770));
  V v_x1_241772 = heff_get_n(v_t_241771, 6, 9);
  V v_t_241773;
  if ((heff_dup(v_x1_241772) == NTAG(TAG_True))) {
    heff_drop(v_x1_241772);
    v_t_241773 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241772);
    v_t_241773 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241774 = heff_tr(heff_call(v_one_241769, 1, (V[]){v_a_241770}));
  return (g_std_2edoc_2e_3c_3e(v_t_241773, v_t_241774));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241783 = args[0];
  V v_one_241782 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241784 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241783));
  V v_x1_241785 = heff_get_n(v_t_241784, 6, 9);
  V v_t_241786;
  if ((heff_dup(v_x1_241785) == NTAG(TAG_True))) {
    heff_drop(v_x1_241785);
    v_t_241786 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241785);
    v_t_241786 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241787 = heff_tr(heff_call(v_one_241782, 1, (V[]){v_a_241783}));
  return (g_std_2edoc_2e_3c_3e(v_t_241786, v_t_241787));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241795 = args[0];
  V v_one_241794 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241796 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241795));
  V v_x1_241797 = heff_get_n(v_t_241796, 6, 9);
  V v_t_241798;
  if ((heff_dup(v_x1_241797) == NTAG(TAG_True))) {
    heff_drop(v_x1_241797);
    v_t_241798 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241797);
    v_t_241798 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241799 = heff_tr(heff_call(v_one_241794, 1, (V[]){v_a_241795}));
  return (g_std_2edoc_2e_3c_3e(v_t_241798, v_t_241799));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241810 = args[0];
  V v_one_241809 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241811 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241810));
  V v_x1_241812 = heff_get_n(v_t_241811, 6, 9);
  V v_t_241813;
  if ((heff_dup(v_x1_241812) == NTAG(TAG_True))) {
    heff_drop(v_x1_241812);
    v_t_241813 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241812);
    v_t_241813 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241814 = heff_tr(heff_call(v_one_241809, 1, (V[]){v_a_241810}));
  return (g_std_2edoc_2e_3c_3e(v_t_241813, v_t_241814));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241822 = args[0];
  V v_one_241821 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241823 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241822));
  V v_x1_241824 = heff_get_n(v_t_241823, 6, 9);
  V v_t_241825;
  if ((heff_dup(v_x1_241824) == NTAG(TAG_True))) {
    heff_drop(v_x1_241824);
    v_t_241825 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241824);
    v_t_241825 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241826 = heff_tr(heff_call(v_one_241821, 1, (V[]){v_a_241822}));
  return (g_std_2edoc_2e_3c_3e(v_t_241825, v_t_241826));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241836 = args[0];
  V v_one_241835 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241837 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241836));
  V v_x1_241838 = heff_get_n(v_t_241837, 6, 9);
  V v_t_241839;
  if ((heff_dup(v_x1_241838) == NTAG(TAG_True))) {
    heff_drop(v_x1_241838);
    v_t_241839 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241838);
    v_t_241839 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241840 = heff_tr(heff_call(v_one_241835, 1, (V[]){v_a_241836}));
  return (g_std_2edoc_2e_3c_3e(v_t_241839, v_t_241840));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241848 = args[0];
  V v_one_241847 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241849 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241848));
  V v_x1_241850 = heff_get_n(v_t_241849, 6, 9);
  V v_t_241851;
  if ((heff_dup(v_x1_241850) == NTAG(TAG_True))) {
    heff_drop(v_x1_241850);
    v_t_241851 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241850);
    v_t_241851 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241852 = heff_tr(heff_call(v_one_241847, 1, (V[]){v_a_241848}));
  return (g_std_2edoc_2e_3c_3e(v_t_241851, v_t_241852));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241862 = args[0];
  V v_one_241861 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241863 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241862));
  V v_x1_241864 = heff_get_n(v_t_241863, 6, 9);
  V v_t_241865;
  if ((heff_dup(v_x1_241864) == NTAG(TAG_True))) {
    heff_drop(v_x1_241864);
    v_t_241865 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241864);
    v_t_241865 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241866 = heff_tr(heff_call(v_one_241861, 1, (V[]){v_a_241862}));
  return (g_std_2edoc_2e_3c_3e(v_t_241865, v_t_241866));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241874 = args[0];
  V v_one_241873 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241875 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241874));
  V v_x1_241876 = heff_get_n(v_t_241875, 6, 9);
  V v_t_241877;
  if ((heff_dup(v_x1_241876) == NTAG(TAG_True))) {
    heff_drop(v_x1_241876);
    v_t_241877 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241876);
    v_t_241877 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241878 = heff_tr(heff_call(v_one_241873, 1, (V[]){v_a_241874}));
  return (g_std_2edoc_2e_3c_3e(v_t_241877, v_t_241878));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_a_241887 = args[0];
  V v_one_241886 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241888 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241887));
  V v_x1_241889 = heff_get_n(v_t_241888, 6, 9);
  V v_t_241890;
  if ((heff_dup(v_x1_241889) == NTAG(TAG_True))) {
    heff_drop(v_x1_241889);
    v_t_241890 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241889);
    v_t_241890 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241891 = heff_tr(heff_call(v_one_241886, 1, (V[]){v_a_241887}));
  return (g_std_2edoc_2e_3c_3e(v_t_241890, v_t_241891));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_a_241899 = args[0];
  V v_one_241898 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241900 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241899));
  V v_x1_241901 = heff_get_n(v_t_241900, 6, 9);
  V v_t_241902;
  if ((heff_dup(v_x1_241901) == NTAG(TAG_True))) {
    heff_drop(v_x1_241901);
    v_t_241902 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241901);
    v_t_241902 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241903 = heff_tr(heff_call(v_one_241898, 1, (V[]){v_a_241899}));
  return (g_std_2edoc_2e_3c_3e(v_t_241902, v_t_241903));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_a_241915 = args[0];
  V v_one_241914 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241916 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241915));
  V v_x1_241917 = heff_get_n(v_t_241916, 6, 9);
  V v_t_241918;
  if ((heff_dup(v_x1_241917) == NTAG(TAG_True))) {
    heff_drop(v_x1_241917);
    v_t_241918 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241917);
    v_t_241918 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241919 = heff_tr(heff_call(v_one_241914, 1, (V[]){v_a_241915}));
  return (g_std_2edoc_2e_3c_3e(v_t_241918, v_t_241919));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_a_241927 = args[0];
  V v_one_241926 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241928 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241927));
  V v_x1_241929 = heff_get_n(v_t_241928, 6, 9);
  V v_t_241930;
  if ((heff_dup(v_x1_241929) == NTAG(TAG_True))) {
    heff_drop(v_x1_241929);
    v_t_241930 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241929);
    v_t_241930 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241931 = heff_tr(heff_call(v_one_241926, 1, (V[]){v_a_241927}));
  return (g_std_2edoc_2e_3c_3e(v_t_241930, v_t_241931));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_a_241939 = args[0];
  V v_one_241938 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241940 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241939));
  V v_x1_241941 = heff_get_n(v_t_241940, 6, 9);
  V v_t_241942;
  if ((heff_dup(v_x1_241941) == NTAG(TAG_True))) {
    heff_drop(v_x1_241941);
    v_t_241942 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241941);
    v_t_241942 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241943 = heff_tr(heff_call(v_one_241938, 1, (V[]){v_a_241939}));
  return (g_std_2edoc_2e_3c_3e(v_t_241942, v_t_241943));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_a_241951 = args[0];
  V v_one_241950 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241952 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241951));
  V v_x1_241953 = heff_get_n(v_t_241952, 6, 9);
  V v_t_241954;
  if ((heff_dup(v_x1_241953) == NTAG(TAG_True))) {
    heff_drop(v_x1_241953);
    v_t_241954 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241953);
    v_t_241954 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241955 = heff_tr(heff_call(v_one_241950, 1, (V[]){v_a_241951}));
  return (g_std_2edoc_2e_3c_3e(v_t_241954, v_t_241955));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_a_241964 = args[0];
  V v_one_241963 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241965 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241964));
  V v_x1_241966 = heff_get_n(v_t_241965, 6, 9);
  V v_t_241967;
  if ((heff_dup(v_x1_241966) == NTAG(TAG_True))) {
    heff_drop(v_x1_241966);
    v_t_241967 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241966);
    v_t_241967 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241968 = heff_tr(heff_call(v_one_241963, 1, (V[]){v_a_241964}));
  return (g_std_2edoc_2e_3c_3e(v_t_241967, v_t_241968));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_a_241976 = args[0];
  V v_one_241975 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241977 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241976));
  V v_x1_241978 = heff_get_n(v_t_241977, 6, 9);
  V v_t_241979;
  if ((heff_dup(v_x1_241978) == NTAG(TAG_True))) {
    heff_drop(v_x1_241978);
    v_t_241979 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241978);
    v_t_241979 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241980 = heff_tr(heff_call(v_one_241975, 1, (V[]){v_a_241976}));
  return (g_std_2edoc_2e_3c_3e(v_t_241979, v_t_241980));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_a_241992 = args[0];
  V v_one_241991 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241993 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241992));
  V v_x1_241994 = heff_get_n(v_t_241993, 6, 9);
  V v_t_241995;
  if ((heff_dup(v_x1_241994) == NTAG(TAG_True))) {
    heff_drop(v_x1_241994);
    v_t_241995 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241994);
    v_t_241995 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241996 = heff_tr(heff_call(v_one_241991, 1, (V[]){v_a_241992}));
  return (g_std_2edoc_2e_3c_3e(v_t_241995, v_t_241996));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_a_242004 = args[0];
  V v_one_242003 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242005 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242004));
  V v_x1_242006 = heff_get_n(v_t_242005, 6, 9);
  V v_t_242007;
  if ((heff_dup(v_x1_242006) == NTAG(TAG_True))) {
    heff_drop(v_x1_242006);
    v_t_242007 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242006);
    v_t_242007 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242008 = heff_tr(heff_call(v_one_242003, 1, (V[]){v_a_242004}));
  return (g_std_2edoc_2e_3c_3e(v_t_242007, v_t_242008));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_a_242020 = args[0];
  V v_one_242019 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242021 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242020));
  V v_x1_242022 = heff_get_n(v_t_242021, 6, 9);
  V v_t_242023;
  if ((heff_dup(v_x1_242022) == NTAG(TAG_True))) {
    heff_drop(v_x1_242022);
    v_t_242023 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242022);
    v_t_242023 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242024 = heff_tr(heff_call(v_one_242019, 1, (V[]){v_a_242020}));
  return (g_std_2edoc_2e_3c_3e(v_t_242023, v_t_242024));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args) {
  V v_a_242032 = args[0];
  V v_one_242031 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242033 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242032));
  V v_x1_242034 = heff_get_n(v_t_242033, 6, 9);
  V v_t_242035;
  if ((heff_dup(v_x1_242034) == NTAG(TAG_True))) {
    heff_drop(v_x1_242034);
    v_t_242035 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242034);
    v_t_242035 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242036 = heff_tr(heff_call(v_one_242031, 1, (V[]){v_a_242032}));
  return (g_std_2edoc_2e_3c_3e(v_t_242035, v_t_242036));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args) {
  V v_a_242045 = args[0];
  V v_one_242044 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242046 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242045));
  V v_x1_242047 = heff_get_n(v_t_242046, 6, 9);
  V v_t_242048;
  if ((heff_dup(v_x1_242047) == NTAG(TAG_True))) {
    heff_drop(v_x1_242047);
    v_t_242048 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242047);
    v_t_242048 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242049 = heff_tr(heff_call(v_one_242044, 1, (V[]){v_a_242045}));
  return (g_std_2edoc_2e_3c_3e(v_t_242048, v_t_242049));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args) {
  V v_a_242057 = args[0];
  V v_one_242056 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242058 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242057));
  V v_x1_242059 = heff_get_n(v_t_242058, 6, 9);
  V v_t_242060;
  if ((heff_dup(v_x1_242059) == NTAG(TAG_True))) {
    heff_drop(v_x1_242059);
    v_t_242060 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242059);
    v_t_242060 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242061 = heff_tr(heff_call(v_one_242056, 1, (V[]){v_a_242057}));
  return (g_std_2edoc_2e_3c_3e(v_t_242060, v_t_242061));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args) {
  V v_a_242071 = args[0];
  V v_one_242070 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242072 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242071));
  V v_x1_242073 = heff_get_n(v_t_242072, 6, 9);
  V v_t_242074;
  if ((heff_dup(v_x1_242073) == NTAG(TAG_True))) {
    heff_drop(v_x1_242073);
    v_t_242074 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242073);
    v_t_242074 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242075 = heff_tr(heff_call(v_one_242070, 1, (V[]){v_a_242071}));
  return (g_std_2edoc_2e_3c_3e(v_t_242074, v_t_242075));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args) {
  V v_a_242083 = args[0];
  V v_one_242082 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242084 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242083));
  V v_x1_242085 = heff_get_n(v_t_242084, 6, 9);
  V v_t_242086;
  if ((heff_dup(v_x1_242085) == NTAG(TAG_True))) {
    heff_drop(v_x1_242085);
    v_t_242086 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242085);
    v_t_242086 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242087 = heff_tr(heff_call(v_one_242082, 1, (V[]){v_a_242083}));
  return (g_std_2edoc_2e_3c_3e(v_t_242086, v_t_242087));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args) {
  V v_a_242099 = args[0];
  V v_one_242098 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242100 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242099));
  V v_x1_242101 = heff_get_n(v_t_242100, 6, 9);
  V v_t_242102;
  if ((heff_dup(v_x1_242101) == NTAG(TAG_True))) {
    heff_drop(v_x1_242101);
    v_t_242102 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242101);
    v_t_242102 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242103 = heff_tr(heff_call(v_one_242098, 1, (V[]){v_a_242099}));
  return (g_std_2edoc_2e_3c_3e(v_t_242102, v_t_242103));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args) {
  V v_a_242111 = args[0];
  V v_one_242110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242112 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242111));
  V v_x1_242113 = heff_get_n(v_t_242112, 6, 9);
  V v_t_242114;
  if ((heff_dup(v_x1_242113) == NTAG(TAG_True))) {
    heff_drop(v_x1_242113);
    v_t_242114 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242113);
    v_t_242114 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242115 = heff_tr(heff_call(v_one_242110, 1, (V[]){v_a_242111}));
  return (g_std_2edoc_2e_3c_3e(v_t_242114, v_t_242115));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args) {
  V v_a_242122 = args[0];
  V v_one_242121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242123 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242122));
  V v_x1_242124 = heff_get_n(v_t_242123, 6, 9);
  V v_t_242125;
  if ((heff_dup(v_x1_242124) == NTAG(TAG_True))) {
    heff_drop(v_x1_242124);
    v_t_242125 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242124);
    v_t_242125 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242126 = heff_tr(heff_call(v_one_242121, 1, (V[]){v_a_242122}));
  return (g_std_2edoc_2e_3c_3e(v_t_242125, v_t_242126));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args) {
  V v_a_242134 = args[0];
  V v_one_242133 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242135 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242134));
  V v_x1_242136 = heff_get_n(v_t_242135, 6, 9);
  V v_t_242137;
  if ((heff_dup(v_x1_242136) == NTAG(TAG_True))) {
    heff_drop(v_x1_242136);
    v_t_242137 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242136);
    v_t_242137 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242138 = heff_tr(heff_call(v_one_242133, 1, (V[]){v_a_242134}));
  return (g_std_2edoc_2e_3c_3e(v_t_242137, v_t_242138));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args) {
  V v_a_242146 = args[0];
  V v_one_242145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242147 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242146));
  V v_x1_242148 = heff_get_n(v_t_242147, 6, 9);
  V v_t_242149;
  if ((heff_dup(v_x1_242148) == NTAG(TAG_True))) {
    heff_drop(v_x1_242148);
    v_t_242149 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242148);
    v_t_242149 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242150 = heff_tr(heff_call(v_one_242145, 1, (V[]){v_a_242146}));
  return (g_std_2edoc_2e_3c_3e(v_t_242149, v_t_242150));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args) {
  V v_a_242158 = args[0];
  V v_one_242157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242159 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242158));
  V v_x1_242160 = heff_get_n(v_t_242159, 6, 9);
  V v_t_242161;
  if ((heff_dup(v_x1_242160) == NTAG(TAG_True))) {
    heff_drop(v_x1_242160);
    v_t_242161 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242160);
    v_t_242161 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242162 = heff_tr(heff_call(v_one_242157, 1, (V[]){v_a_242158}));
  return (g_std_2edoc_2e_3c_3e(v_t_242161, v_t_242162));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args) {
  V v_a_242172 = args[0];
  V v_one_242171 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242173 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242172));
  V v_x1_242174 = heff_get_n(v_t_242173, 6, 9);
  V v_t_242175;
  if ((heff_dup(v_x1_242174) == NTAG(TAG_True))) {
    heff_drop(v_x1_242174);
    v_t_242175 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242174);
    v_t_242175 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242176 = heff_tr(heff_call(v_one_242171, 1, (V[]){v_a_242172}));
  return (g_std_2edoc_2e_3c_3e(v_t_242175, v_t_242176));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args) {
  V v_a_242184 = args[0];
  V v_one_242183 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242185 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242184));
  V v_x1_242186 = heff_get_n(v_t_242185, 6, 9);
  V v_t_242187;
  if ((heff_dup(v_x1_242186) == NTAG(TAG_True))) {
    heff_drop(v_x1_242186);
    v_t_242187 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242186);
    v_t_242187 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242188 = heff_tr(heff_call(v_one_242183, 1, (V[]){v_a_242184}));
  return (g_std_2edoc_2e_3c_3e(v_t_242187, v_t_242188));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args) {
  V v_a_242198 = args[0];
  V v_one_242197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242199 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242198));
  V v_x1_242200 = heff_get_n(v_t_242199, 6, 9);
  V v_t_242201;
  if ((heff_dup(v_x1_242200) == NTAG(TAG_True))) {
    heff_drop(v_x1_242200);
    v_t_242201 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242200);
    v_t_242201 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242202 = heff_tr(heff_call(v_one_242197, 1, (V[]){v_a_242198}));
  return (g_std_2edoc_2e_3c_3e(v_t_242201, v_t_242202));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args) {
  V v_a_242210 = args[0];
  V v_one_242209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242211 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242210));
  V v_x1_242212 = heff_get_n(v_t_242211, 6, 9);
  V v_t_242213;
  if ((heff_dup(v_x1_242212) == NTAG(TAG_True))) {
    heff_drop(v_x1_242212);
    v_t_242213 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242212);
    v_t_242213 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242214 = heff_tr(heff_call(v_one_242209, 1, (V[]){v_a_242210}));
  return (g_std_2edoc_2e_3c_3e(v_t_242213, v_t_242214));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args) {
  V v_a_242224 = args[0];
  V v_one_242223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242225 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242224));
  V v_x1_242226 = heff_get_n(v_t_242225, 6, 9);
  V v_t_242227;
  if ((heff_dup(v_x1_242226) == NTAG(TAG_True))) {
    heff_drop(v_x1_242226);
    v_t_242227 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242226);
    v_t_242227 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242228 = heff_tr(heff_call(v_one_242223, 1, (V[]){v_a_242224}));
  return (g_std_2edoc_2e_3c_3e(v_t_242227, v_t_242228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args) {
  V v_a_242236 = args[0];
  V v_one_242235 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242237 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242236));
  V v_x1_242238 = heff_get_n(v_t_242237, 6, 9);
  V v_t_242239;
  if ((heff_dup(v_x1_242238) == NTAG(TAG_True))) {
    heff_drop(v_x1_242238);
    v_t_242239 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242238);
    v_t_242239 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242240 = heff_tr(heff_call(v_one_242235, 1, (V[]){v_a_242236}));
  return (g_std_2edoc_2e_3c_3e(v_t_242239, v_t_242240));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args) {
  V v_a_242250 = args[0];
  V v_one_242249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242251 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242250));
  V v_x1_242252 = heff_get_n(v_t_242251, 6, 9);
  V v_t_242253;
  if ((heff_dup(v_x1_242252) == NTAG(TAG_True))) {
    heff_drop(v_x1_242252);
    v_t_242253 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242252);
    v_t_242253 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242254 = heff_tr(heff_call(v_one_242249, 1, (V[]){v_a_242250}));
  return (g_std_2edoc_2e_3c_3e(v_t_242253, v_t_242254));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args) {
  V v_a_242262 = args[0];
  V v_one_242261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242263 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242262));
  V v_x1_242264 = heff_get_n(v_t_242263, 6, 9);
  V v_t_242265;
  if ((heff_dup(v_x1_242264) == NTAG(TAG_True))) {
    heff_drop(v_x1_242264);
    v_t_242265 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242264);
    v_t_242265 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242266 = heff_tr(heff_call(v_one_242261, 1, (V[]){v_a_242262}));
  return (g_std_2edoc_2e_3c_3e(v_t_242265, v_t_242266));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args) {
  V v_a_242276 = args[0];
  V v_one_242275 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242277 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242276));
  V v_x1_242278 = heff_get_n(v_t_242277, 6, 9);
  V v_t_242279;
  if ((heff_dup(v_x1_242278) == NTAG(TAG_True))) {
    heff_drop(v_x1_242278);
    v_t_242279 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242278);
    v_t_242279 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242280 = heff_tr(heff_call(v_one_242275, 1, (V[]){v_a_242276}));
  return (g_std_2edoc_2e_3c_3e(v_t_242279, v_t_242280));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args) {
  V v_a_242288 = args[0];
  V v_one_242287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242289 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242288));
  V v_x1_242290 = heff_get_n(v_t_242289, 6, 9);
  V v_t_242291;
  if ((heff_dup(v_x1_242290) == NTAG(TAG_True))) {
    heff_drop(v_x1_242290);
    v_t_242291 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242290);
    v_t_242291 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242292 = heff_tr(heff_call(v_one_242287, 1, (V[]){v_a_242288}));
  return (g_std_2edoc_2e_3c_3e(v_t_242291, v_t_242292));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args) {
  V v_a_242304 = args[0];
  V v_one_242303 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242305 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242304));
  V v_x1_242306 = heff_get_n(v_t_242305, 6, 9);
  V v_t_242307;
  if ((heff_dup(v_x1_242306) == NTAG(TAG_True))) {
    heff_drop(v_x1_242306);
    v_t_242307 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242306);
    v_t_242307 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242308 = heff_tr(heff_call(v_one_242303, 1, (V[]){v_a_242304}));
  return (g_std_2edoc_2e_3c_3e(v_t_242307, v_t_242308));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args) {
  V v_a_242316 = args[0];
  V v_one_242315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242317 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242316));
  V v_x1_242318 = heff_get_n(v_t_242317, 6, 9);
  V v_t_242319;
  if ((heff_dup(v_x1_242318) == NTAG(TAG_True))) {
    heff_drop(v_x1_242318);
    v_t_242319 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242318);
    v_t_242319 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242320 = heff_tr(heff_call(v_one_242315, 1, (V[]){v_a_242316}));
  return (g_std_2edoc_2e_3c_3e(v_t_242319, v_t_242320));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_env_241240 = args[0];
  V v_h_241241 = args[1];
  V v_args_241242 = args[2];
  V v_x1_241243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_241242)));
  switch (heff_tag_of(v_x1_241243)) {
  case TAG_Nil: {
    heff_drop(v_args_241242);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241240;
    args[1] = v_h_241241;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_241244 = heff_field(v_x1_241243, 0);
    V v_rev_241245 = heff_field(v_x1_241243, 1);
    V v_ru_24x1_241243_24Cons = heff_take_reuse_n(v_x1_241243, 3ULL, 2);
    V v_t_241246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241245));
    switch (heff_tag_of(v_x_241244)) {
    case TAG_Atom: {
      V v_t_241248 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241248) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241248);
        V v_t_241249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241250 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241256 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241250}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241257 = (g_std_2edoc_2e_3c_3e(v_t_241249, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241256})));
        V v_a_241258 = (g_std_2edoc_2egroup(v_t_241257));
        V v_b_241259 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241260 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), v_b_241259));
        return (g_std_2edoc_2e_3c_3e(v_a_241258, v_t_241260));
      } else {
        heff_drop_tag(v_x_241244, 1);
        heff_drop(v_t_241246);
        heff_drop(v_t_241248);
        V v_t_241261 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241262 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241268 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241262}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241269 = (g_std_2edoc_2e_3c_3e(v_t_241261, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241268})));
        return (g_std_2edoc_2egroup(v_t_241269));
      }
    }
    case TAG_EParen: {
      V v_o_241270 = heff_field(v_x_241244, 0);
      V v_e_241271 = heff_field(v_x_241244, 1);
      V v_c_241272 = heff_field(v_x_241244, 2);
      heff_take_n(v_x_241244, 7ULL, 3);
      V v_t_241273 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_241271));
      if ((heff_dup(v_t_241273) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241273);
        V v_t_241274 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241275 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241281 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241275}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241282 = (g_std_2edoc_2e_3c_3e(v_t_241274, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241281})));
        V v_a_241283 = (g_std_2edoc_2egroup(v_t_241282));
        V v_b_241284 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241240), v_o_241270));
        V v_t_241285 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), v_b_241284));
        V v_t_241286 = (g_std_2edoc_2e_3c_3e(v_a_241283, v_t_241285));
        V v_t_241287 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_e_241271}));
        V v_t_241288 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241240, v_c_241272));
        V v_t_241289 = (g_std_2edoc_2e_3c_3e(v_t_241287, v_t_241288));
        return (g_std_2edoc_2e_3c_3e(v_t_241286, v_t_241289));
      } else {
        heff_drop(v_t_241246);
        heff_drop(v_o_241270);
        heff_drop(v_e_241271);
        heff_drop(v_c_241272);
        heff_drop(v_t_241273);
        V v_t_241290 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241291 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241297 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241291}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241298 = (g_std_2edoc_2e_3c_3e(v_t_241290, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241297})));
        return (g_std_2edoc_2egroup(v_t_241298));
      }
    }
    case TAG_Named: {
      V v_t_241304 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241304) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241304);
        V v_t_241305 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241306 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241312 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241306}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241313 = (g_std_2edoc_2e_3c_3e(v_t_241305, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241312})));
        V v_a_241314 = (g_std_2edoc_2egroup(v_t_241313));
        V v_b_241315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241316 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_241315));
        return (g_std_2edoc_2e_3c_3e(v_a_241314, v_t_241316));
      } else {
        heff_drop_tag(v_x_241244, 5);
        heff_drop(v_t_241246);
        heff_drop(v_t_241304);
        V v_t_241317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241318 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241324 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241318}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241325 = (g_std_2edoc_2e_3c_3e(v_t_241317, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241324})));
        return (g_std_2edoc_2egroup(v_t_241325));
      }
    }
    case TAG_Tup: {
      V v_t_241330 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241330) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241330);
        V v_t_241331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241332 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241338 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241332}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241339 = (g_std_2edoc_2e_3c_3e(v_t_241331, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241338})));
        V v_a_241340 = (g_std_2edoc_2egroup(v_t_241339));
        V v_b_241341 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241342 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), v_b_241341));
        return (g_std_2edoc_2e_3c_3e(v_a_241340, v_t_241342));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_241330);
        V v_t_241343 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241350 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241344}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241351 = (g_std_2edoc_2e_3c_3e(v_t_241343, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241350})));
        return (g_std_2edoc_2egroup(v_t_241351));
      }
    }
    case TAG_Seg: {
      V v_t_241355 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241355) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241355);
        V v_t_241356 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241363 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241357}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241364 = (g_std_2edoc_2e_3c_3e(v_t_241356, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241363})));
        V v_a_241365 = (g_std_2edoc_2egroup(v_t_241364));
        V v_b_241366 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241367 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_241366));
        return (g_std_2edoc_2e_3c_3e(v_a_241365, v_t_241367));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241355);
        V v_t_241368 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241369 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241375 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241369}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241376 = (g_std_2edoc_2e_3c_3e(v_t_241368, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241375})));
        return (g_std_2edoc_2egroup(v_t_241376));
      }
    }
    case TAG_Braces: {
      V v_t_241381 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241381) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241381);
        V v_t_241382 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241383 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241389 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241383}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241390 = (g_std_2edoc_2e_3c_3e(v_t_241382, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241389})));
        V v_a_241391 = (g_std_2edoc_2egroup(v_t_241390));
        V v_b_241392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241393 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str111)}), v_b_241392));
        return (g_std_2edoc_2e_3c_3e(v_a_241391, v_t_241393));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_241381);
        V v_t_241394 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241395 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241401 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241395}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241402 = (g_std_2edoc_2e_3c_3e(v_t_241394, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241401})));
        return (g_std_2edoc_2egroup(v_t_241402));
      }
    }
    case TAG_Update: {
      V v_t_241409 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241409) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241409);
        V v_t_241410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241417 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241411}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241418 = (g_std_2edoc_2e_3c_3e(v_t_241410, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241417})));
        V v_a_241419 = (g_std_2edoc_2egroup(v_t_241418));
        V v_b_241420 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241421 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str112)}), v_b_241420));
        return (g_std_2edoc_2e_3c_3e(v_a_241419, v_t_241421));
      } else {
        heff_drop_tag(v_x_241244, 6);
        heff_drop(v_t_241246);
        heff_drop(v_t_241409);
        V v_t_241422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241423 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241429 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241423}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241430 = (g_std_2edoc_2e_3c_3e(v_t_241422, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241429})));
        return (g_std_2edoc_2egroup(v_t_241430));
      }
    }
    case TAG_EUSet: {
      V v_t_241434 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241434) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241434);
        V v_t_241435 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241436 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241442 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241436}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241443 = (g_std_2edoc_2e_3c_3e(v_t_241435, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241442})));
        V v_a_241444 = (g_std_2edoc_2egroup(v_t_241443));
        V v_b_241445 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241446 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str113)}), v_b_241445));
        return (g_std_2edoc_2e_3c_3e(v_a_241444, v_t_241446));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241434);
        V v_t_241447 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241454 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241448}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241455 = (g_std_2edoc_2e_3c_3e(v_t_241447, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241454})));
        return (g_std_2edoc_2egroup(v_t_241455));
      }
    }
    case TAG_InstB: {
      V v_t_241461 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241461) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241461);
        V v_t_241462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241469 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241463}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241470 = (g_std_2edoc_2e_3c_3e(v_t_241462, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241469})));
        V v_a_241471 = (g_std_2edoc_2egroup(v_t_241470));
        V v_b_241472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str114)}), v_b_241472));
        return (g_std_2edoc_2e_3c_3e(v_a_241471, v_t_241473));
      } else {
        heff_drop_tag(v_x_241244, 5);
        heff_drop(v_t_241246);
        heff_drop(v_t_241461);
        V v_t_241474 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241475 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241481 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241475}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241482 = (g_std_2edoc_2e_3c_3e(v_t_241474, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241481})));
        return (g_std_2edoc_2egroup(v_t_241482));
      }
    }
    case TAG_EFSet: {
      V v_t_241486 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241486) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241486);
        V v_t_241487 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241488 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241494 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241488}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241495 = (g_std_2edoc_2e_3c_3e(v_t_241487, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241494})));
        V v_a_241496 = (g_std_2edoc_2egroup(v_t_241495));
        V v_b_241497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241498 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str115)}), v_b_241497));
        return (g_std_2edoc_2e_3c_3e(v_a_241496, v_t_241498));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241486);
        V v_t_241499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241500 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241506 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241500}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241507 = (g_std_2edoc_2e_3c_3e(v_t_241499, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241506})));
        return (g_std_2edoc_2egroup(v_t_241507));
      }
    }
    case TAG_EFDefault: {
      V v_t_241511 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241511) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241511);
        V v_t_241512 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241513 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241519 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241513}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241520 = (g_std_2edoc_2e_3c_3e(v_t_241512, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241519})));
        V v_a_241521 = (g_std_2edoc_2egroup(v_t_241520));
        V v_b_241522 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241523 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str116)}), v_b_241522));
        return (g_std_2edoc_2e_3c_3e(v_a_241521, v_t_241523));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241511);
        V v_t_241524 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241525 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241531 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241525}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241532 = (g_std_2edoc_2e_3c_3e(v_t_241524, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241531})));
        return (g_std_2edoc_2egroup(v_t_241532));
      }
    }
    case TAG_Sum: {
      V v_t_241538 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241538) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241538);
        V v_t_241539 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241540 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241546 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241540}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241547 = (g_std_2edoc_2e_3c_3e(v_t_241539, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241546})));
        V v_a_241548 = (g_std_2edoc_2egroup(v_t_241547));
        V v_b_241549 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241550 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str117)}), v_b_241549));
        return (g_std_2edoc_2e_3c_3e(v_a_241548, v_t_241550));
      } else {
        heff_drop_tag(v_x_241244, 5);
        heff_drop(v_t_241246);
        heff_drop(v_t_241538);
        V v_t_241551 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241552 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241558 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241552}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241559 = (g_std_2edoc_2e_3c_3e(v_t_241551, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241558})));
        return (g_std_2edoc_2egroup(v_t_241559));
      }
    }
    case TAG_ECon: {
      V v_t_241562 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241562) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241562);
        V v_t_241563 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241564 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241570 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241564}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241571 = (g_std_2edoc_2e_3c_3e(v_t_241563, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241570})));
        V v_a_241572 = (g_std_2edoc_2egroup(v_t_241571));
        V v_b_241573 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241574 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str118)}), v_b_241573));
        return (g_std_2edoc_2e_3c_3e(v_a_241572, v_t_241574));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241562);
        V v_t_241575 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241576 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241582 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241576}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241583 = (g_std_2edoc_2e_3c_3e(v_t_241575, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241582})));
        return (g_std_2edoc_2egroup(v_t_241583));
      }
    }
    case TAG_EField: {
      V v_t_241586 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241586) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241586);
        V v_t_241587 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241588 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241594 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241588}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241595 = (g_std_2edoc_2e_3c_3e(v_t_241587, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241594})));
        V v_a_241596 = (g_std_2edoc_2egroup(v_t_241595));
        V v_b_241597 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241598 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str119)}), v_b_241597));
        return (g_std_2edoc_2e_3c_3e(v_a_241596, v_t_241598));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241586);
        V v_t_241599 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241600 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241606 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241600}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241607 = (g_std_2edoc_2e_3c_3e(v_t_241599, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241606})));
        return (g_std_2edoc_2egroup(v_t_241607));
      }
    }
    case TAG_ENeg: {
      V v_t_241610 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241610) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241610);
        V v_t_241611 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241612 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241618 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241612}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241619 = (g_std_2edoc_2e_3c_3e(v_t_241611, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241618})));
        V v_a_241620 = (g_std_2edoc_2egroup(v_t_241619));
        V v_b_241621 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241622 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str120)}), v_b_241621));
        return (g_std_2edoc_2e_3c_3e(v_a_241620, v_t_241622));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241610);
        V v_t_241623 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241624 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241630 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241624}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241631 = (g_std_2edoc_2e_3c_3e(v_t_241623, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241630})));
        return (g_std_2edoc_2egroup(v_t_241631));
      }
    }
    case TAG_App: {
      V v_t_241634 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241634) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241634);
        V v_t_241635 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241636 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241642 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241636}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241643 = (g_std_2edoc_2e_3c_3e(v_t_241635, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241642})));
        V v_a_241644 = (g_std_2edoc_2egroup(v_t_241643));
        V v_b_241645 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241646 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str121)}), v_b_241645));
        return (g_std_2edoc_2e_3c_3e(v_a_241644, v_t_241646));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241634);
        V v_t_241647 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241648 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241654 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241648}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241655 = (g_std_2edoc_2e_3c_3e(v_t_241647, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241654})));
        return (g_std_2edoc_2egroup(v_t_241655));
      }
    }
    case TAG_Op: {
      V v_t_241659 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241659) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241659);
        V v_t_241660 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241661 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241667 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241661}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241668 = (g_std_2edoc_2e_3c_3e(v_t_241660, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241667})));
        V v_a_241669 = (g_std_2edoc_2egroup(v_t_241668));
        V v_b_241670 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241671 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str122)}), v_b_241670));
        return (g_std_2edoc_2e_3c_3e(v_a_241669, v_t_241671));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241659);
        V v_t_241672 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241673 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241679 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241673}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241680 = (g_std_2edoc_2e_3c_3e(v_t_241672, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241679})));
        return (g_std_2edoc_2egroup(v_t_241680));
      }
    }
    case TAG_Ops: {
      V v_t_241683 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241683) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241683);
        V v_t_241684 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241685 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241691 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241685}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241692 = (g_std_2edoc_2e_3c_3e(v_t_241684, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241691})));
        V v_a_241693 = (g_std_2edoc_2egroup(v_t_241692));
        V v_b_241694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241695 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str123)}), v_b_241694));
        return (g_std_2edoc_2e_3c_3e(v_a_241693, v_t_241695));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241683);
        V v_t_241696 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241697 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241703 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241697}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241704 = (g_std_2edoc_2e_3c_3e(v_t_241696, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241703})));
        return (g_std_2edoc_2egroup(v_t_241704));
      }
    }
    case TAG_OpRhs: {
      V v_t_241707 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241707) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241707);
        V v_t_241708 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241709 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241715 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241709}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241716 = (g_std_2edoc_2e_3c_3e(v_t_241708, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241715})));
        V v_a_241717 = (g_std_2edoc_2egroup(v_t_241716));
        V v_b_241718 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241719 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str124)}), v_b_241718));
        return (g_std_2edoc_2e_3c_3e(v_a_241717, v_t_241719));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241707);
        V v_t_241720 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241721 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241727 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241721}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241728 = (g_std_2edoc_2e_3c_3e(v_t_241720, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241727})));
        return (g_std_2edoc_2egroup(v_t_241728));
      }
    }
    case TAG_Ann: {
      V v_t_241732 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241732) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241732);
        V v_t_241733 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241734 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241740 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241734}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241741 = (g_std_2edoc_2e_3c_3e(v_t_241733, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241740})));
        V v_a_241742 = (g_std_2edoc_2egroup(v_t_241741));
        V v_b_241743 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241744 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str125)}), v_b_241743));
        return (g_std_2edoc_2e_3c_3e(v_a_241742, v_t_241744));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241732);
        V v_t_241745 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241746 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241752 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241746}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241753 = (g_std_2edoc_2e_3c_3e(v_t_241745, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241752})));
        return (g_std_2edoc_2egroup(v_t_241753));
      }
    }
    case TAG_BVar: {
      V v_t_241755 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241755) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241755);
        V v_t_241756 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241757 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241763 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241757}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241764 = (g_std_2edoc_2e_3c_3e(v_t_241756, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241763})));
        V v_a_241765 = (g_std_2edoc_2egroup(v_t_241764));
        V v_b_241766 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241767 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str126)}), v_b_241766));
        return (g_std_2edoc_2e_3c_3e(v_a_241765, v_t_241767));
      } else {
        heff_drop_tag(v_x_241244, 1);
        heff_drop(v_t_241246);
        heff_drop(v_t_241755);
        V v_t_241768 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241769 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241775 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241769}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241776 = (g_std_2edoc_2e_3c_3e(v_t_241768, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241775})));
        return (g_std_2edoc_2egroup(v_t_241776));
      }
    }
    case TAG_BImp: {
      V v_t_241780 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241780) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241780);
        V v_t_241781 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241782 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241788 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241782}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241789 = (g_std_2edoc_2e_3c_3e(v_t_241781, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241788})));
        V v_a_241790 = (g_std_2edoc_2egroup(v_t_241789));
        V v_b_241791 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241792 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str127)}), v_b_241791));
        return (g_std_2edoc_2e_3c_3e(v_a_241790, v_t_241792));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241780);
        V v_t_241793 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241794 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241800 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241794}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241801 = (g_std_2edoc_2e_3c_3e(v_t_241793, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241800})));
        return (g_std_2edoc_2egroup(v_t_241801));
      }
    }
    case TAG_BAnn: {
      V v_t_241807 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241807) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241807);
        V v_t_241808 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241809 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241815 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241809}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241816 = (g_std_2edoc_2e_3c_3e(v_t_241808, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241815})));
        V v_a_241817 = (g_std_2edoc_2egroup(v_t_241816));
        V v_b_241818 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241819 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str128)}), v_b_241818));
        return (g_std_2edoc_2e_3c_3e(v_a_241817, v_t_241819));
      } else {
        heff_drop_tag(v_x_241244, 5);
        heff_drop(v_t_241246);
        heff_drop(v_t_241807);
        V v_t_241820 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241821 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241827 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241821}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241828 = (g_std_2edoc_2e_3c_3e(v_t_241820, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241827})));
        return (g_std_2edoc_2egroup(v_t_241828));
      }
    }
    case TAG_Lam: {
      V v_t_241833 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241833) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241833);
        V v_t_241834 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241835 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241841 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241835}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241842 = (g_std_2edoc_2e_3c_3e(v_t_241834, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241841})));
        V v_a_241843 = (g_std_2edoc_2egroup(v_t_241842));
        V v_b_241844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241845 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str129)}), v_b_241844));
        return (g_std_2edoc_2e_3c_3e(v_a_241843, v_t_241845));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_241833);
        V v_t_241846 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241847 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241853 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241847}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241854 = (g_std_2edoc_2e_3c_3e(v_t_241846, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241853})));
        return (g_std_2edoc_2egroup(v_t_241854));
      }
    }
    case TAG_Case: {
      V v_t_241859 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241859) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241859);
        V v_t_241860 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241861 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241867 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241861}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241868 = (g_std_2edoc_2e_3c_3e(v_t_241860, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241867})));
        V v_a_241869 = (g_std_2edoc_2egroup(v_t_241868));
        V v_b_241870 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241871 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str130)}), v_b_241870));
        return (g_std_2edoc_2e_3c_3e(v_a_241869, v_t_241871));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_241859);
        V v_t_241872 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241873 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241879 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241873}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241880 = (g_std_2edoc_2e_3c_3e(v_t_241872, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241879})));
        return (g_std_2edoc_2egroup(v_t_241880));
      }
    }
    case TAG_EAlt: {
      V v_t_241884 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241884) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241884);
        V v_t_241885 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241886 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241892 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 1, 1, (V[]){v_one_241886}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241893 = (g_std_2edoc_2e_3c_3e(v_t_241885, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241892})));
        V v_a_241894 = (g_std_2edoc_2egroup(v_t_241893));
        V v_b_241895 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241896 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str131)}), v_b_241895));
        return (g_std_2edoc_2e_3c_3e(v_a_241894, v_t_241896));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241884);
        V v_t_241897 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241898 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241904 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 1, 1, (V[]){v_one_241898}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241905 = (g_std_2edoc_2e_3c_3e(v_t_241897, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241904})));
        return (g_std_2edoc_2egroup(v_t_241905));
      }
    }
    case TAG_If: {
      V v_t_241912 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241912) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241912);
        V v_t_241913 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241914 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241920 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_one_241914}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241921 = (g_std_2edoc_2e_3c_3e(v_t_241913, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241920})));
        V v_a_241922 = (g_std_2edoc_2egroup(v_t_241921));
        V v_b_241923 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241924 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str132)}), v_b_241923));
        return (g_std_2edoc_2e_3c_3e(v_a_241922, v_t_241924));
      } else {
        heff_drop_tag(v_x_241244, 6);
        heff_drop(v_t_241246);
        heff_drop(v_t_241912);
        V v_t_241925 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241926 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241932 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_one_241926}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241933 = (g_std_2edoc_2e_3c_3e(v_t_241925, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241932})));
        return (g_std_2edoc_2egroup(v_t_241933));
      }
    }
    case TAG_Do: {
      V v_t_241936 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241936) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241936);
        V v_t_241937 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241938 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241944 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 1, 1, (V[]){v_one_241938}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241945 = (g_std_2edoc_2e_3c_3e(v_t_241937, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241944})));
        V v_a_241946 = (g_std_2edoc_2egroup(v_t_241945));
        V v_b_241947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241948 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str133)}), v_b_241947));
        return (g_std_2edoc_2e_3c_3e(v_a_241946, v_t_241948));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_241936);
        V v_t_241949 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241950 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241956 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_one_241950}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241957 = (g_std_2edoc_2e_3c_3e(v_t_241949, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241956})));
        return (g_std_2edoc_2egroup(v_t_241957));
      }
    }
    case TAG_ESBind: {
      V v_t_241961 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241961) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241961);
        V v_t_241962 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241963 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241969 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_one_241963}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241970 = (g_std_2edoc_2e_3c_3e(v_t_241962, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241969})));
        V v_a_241971 = (g_std_2edoc_2egroup(v_t_241970));
        V v_b_241972 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_241973 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str134)}), v_b_241972));
        return (g_std_2edoc_2e_3c_3e(v_a_241971, v_t_241973));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_241961);
        V v_t_241974 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241975 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_241981 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 1, 1, (V[]){v_one_241975}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_241982 = (g_std_2edoc_2e_3c_3e(v_t_241974, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241981})));
        return (g_std_2edoc_2egroup(v_t_241982));
      }
    }
    case TAG_ELet: {
      V v_t_241989 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_241989) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_241989);
        V v_t_241990 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_241991 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_241997 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 1, 1, (V[]){v_one_241991}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_241998 = (g_std_2edoc_2e_3c_3e(v_t_241990, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241997})));
        V v_a_241999 = (g_std_2edoc_2egroup(v_t_241998));
        V v_b_242000 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242001 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str135)}), v_b_242000));
        return (g_std_2edoc_2e_3c_3e(v_a_241999, v_t_242001));
      } else {
        heff_drop_tag(v_x_241244, 6);
        heff_drop(v_t_241246);
        heff_drop(v_t_241989);
        V v_t_242002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242003 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242009 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 1, 1, (V[]){v_one_242003}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242010 = (g_std_2edoc_2e_3c_3e(v_t_242002, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242009})));
        return (g_std_2edoc_2egroup(v_t_242010));
      }
    }
    case TAG_ELetMut: {
      V v_t_242017 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242017) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242017);
        V v_t_242018 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242019 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242025 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 1, 1, (V[]){v_one_242019}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242026 = (g_std_2edoc_2e_3c_3e(v_t_242018, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242025})));
        V v_a_242027 = (g_std_2edoc_2egroup(v_t_242026));
        V v_b_242028 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242029 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str136)}), v_b_242028));
        return (g_std_2edoc_2e_3c_3e(v_a_242027, v_t_242029));
      } else {
        heff_drop_tag(v_x_241244, 6);
        heff_drop(v_t_241246);
        heff_drop(v_t_242017);
        V v_t_242030 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242031 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242037 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam97, 1, 1, (V[]){v_one_242031}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242038 = (g_std_2edoc_2e_3c_3e(v_t_242030, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242037})));
        return (g_std_2edoc_2egroup(v_t_242038));
      }
    }
    case TAG_EAssign: {
      V v_t_242042 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242042) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242042);
        V v_t_242043 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242044 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242050 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam98, 1, 1, (V[]){v_one_242044}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242051 = (g_std_2edoc_2e_3c_3e(v_t_242043, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242050})));
        V v_a_242052 = (g_std_2edoc_2egroup(v_t_242051));
        V v_b_242053 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242054 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str137)}), v_b_242053));
        return (g_std_2edoc_2e_3c_3e(v_a_242052, v_t_242054));
      } else {
        heff_drop_tag(v_x_241244, 3);
        heff_drop(v_t_241246);
        heff_drop(v_t_242042);
        V v_t_242055 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242056 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242062 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam99, 1, 1, (V[]){v_one_242056}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242063 = (g_std_2edoc_2e_3c_3e(v_t_242055, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242062})));
        return (g_std_2edoc_2egroup(v_t_242063));
      }
    }
    case TAG_EWhile: {
      V v_t_242068 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242068) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242068);
        V v_t_242069 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242070 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242076 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam100, 1, 1, (V[]){v_one_242070}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242077 = (g_std_2edoc_2e_3c_3e(v_t_242069, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242076})));
        V v_a_242078 = (g_std_2edoc_2egroup(v_t_242077));
        V v_b_242079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242080 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str138)}), v_b_242079));
        return (g_std_2edoc_2e_3c_3e(v_a_242078, v_t_242080));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_242068);
        V v_t_242081 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242082 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242088 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam101, 1, 1, (V[]){v_one_242082}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242089 = (g_std_2edoc_2e_3c_3e(v_t_242081, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242088})));
        return (g_std_2edoc_2egroup(v_t_242089));
      }
    }
    case TAG_EFor: {
      V v_t_242096 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242096) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242096);
        V v_t_242097 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242098 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242104 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam102, 1, 1, (V[]){v_one_242098}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242105 = (g_std_2edoc_2e_3c_3e(v_t_242097, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242104})));
        V v_a_242106 = (g_std_2edoc_2egroup(v_t_242105));
        V v_b_242107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242108 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str139)}), v_b_242107));
        return (g_std_2edoc_2e_3c_3e(v_a_242106, v_t_242108));
      } else {
        heff_drop_tag(v_x_241244, 6);
        heff_drop(v_t_241246);
        heff_drop(v_t_242096);
        V v_t_242109 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242116 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam103, 1, 1, (V[]){v_one_242110}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242117 = (g_std_2edoc_2e_3c_3e(v_t_242109, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242116})));
        return (g_std_2edoc_2egroup(v_t_242117));
      }
    }
    case TAG_EJump: {
      V v_t_242119 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242119) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242119);
        V v_t_242120 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242121 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242127 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam104, 1, 1, (V[]){v_one_242121}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242128 = (g_std_2edoc_2e_3c_3e(v_t_242120, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242127})));
        V v_a_242129 = (g_std_2edoc_2egroup(v_t_242128));
        V v_b_242130 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242131 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str140)}), v_b_242130));
        return (g_std_2edoc_2e_3c_3e(v_a_242129, v_t_242131));
      } else {
        heff_drop_tag(v_x_241244, 1);
        heff_drop(v_t_241246);
        heff_drop(v_t_242119);
        V v_t_242132 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242139 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam105, 1, 1, (V[]){v_one_242133}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242140 = (g_std_2edoc_2e_3c_3e(v_t_242132, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242139})));
        return (g_std_2edoc_2egroup(v_t_242140));
      }
    }
    case TAG_EReturn: {
      V v_t_242143 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242143) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242143);
        V v_t_242144 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242145 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242151 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam106, 1, 1, (V[]){v_one_242145}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242152 = (g_std_2edoc_2e_3c_3e(v_t_242144, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242151})));
        V v_a_242153 = (g_std_2edoc_2egroup(v_t_242152));
        V v_b_242154 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str141)}), v_b_242154));
        return (g_std_2edoc_2e_3c_3e(v_a_242153, v_t_242155));
      } else {
        heff_drop_tag(v_x_241244, 2);
        heff_drop(v_t_241246);
        heff_drop(v_t_242143);
        V v_t_242156 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242163 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam107, 1, 1, (V[]){v_one_242157}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242164 = (g_std_2edoc_2e_3c_3e(v_t_242156, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242163})));
        return (g_std_2edoc_2egroup(v_t_242164));
      }
    }
    case TAG_ENest: {
      V v_t_242169 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242169) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242169);
        V v_t_242170 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242171 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242177 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam108, 1, 1, (V[]){v_one_242171}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242178 = (g_std_2edoc_2e_3c_3e(v_t_242170, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242177})));
        V v_a_242179 = (g_std_2edoc_2egroup(v_t_242178));
        V v_b_242180 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242181 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str142)}), v_b_242180));
        return (g_std_2edoc_2e_3c_3e(v_a_242179, v_t_242181));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_242169);
        V v_t_242182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242183 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242189 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam109, 1, 1, (V[]){v_one_242183}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242190 = (g_std_2edoc_2e_3c_3e(v_t_242182, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242189})));
        return (g_std_2edoc_2egroup(v_t_242190));
      }
    }
    case TAG_IfThen: {
      V v_t_242195 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242195) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242195);
        V v_t_242196 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242197 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242203 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam110, 1, 1, (V[]){v_one_242197}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242204 = (g_std_2edoc_2e_3c_3e(v_t_242196, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242203})));
        V v_a_242205 = (g_std_2edoc_2egroup(v_t_242204));
        V v_b_242206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242207 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str143)}), v_b_242206));
        return (g_std_2edoc_2e_3c_3e(v_a_242205, v_t_242207));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_242195);
        V v_t_242208 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242209 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242215 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam111, 1, 1, (V[]){v_one_242209}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242216 = (g_std_2edoc_2e_3c_3e(v_t_242208, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242215})));
        return (g_std_2edoc_2egroup(v_t_242216));
      }
    }
    case TAG_ELetCond: {
      V v_t_242221 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242221) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242221);
        V v_t_242222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam112, 1, 1, (V[]){v_one_242223}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242230 = (g_std_2edoc_2e_3c_3e(v_t_242222, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242229})));
        V v_a_242231 = (g_std_2edoc_2egroup(v_t_242230));
        V v_b_242232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242233 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str144)}), v_b_242232));
        return (g_std_2edoc_2e_3c_3e(v_a_242231, v_t_242233));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_242221);
        V v_t_242234 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242235 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242241 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam113, 1, 1, (V[]){v_one_242235}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242242 = (g_std_2edoc_2e_3c_3e(v_t_242234, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242241})));
        return (g_std_2edoc_2egroup(v_t_242242));
      }
    }
    case TAG_ETry: {
      V v_t_242247 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242247) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242247);
        V v_t_242248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242255 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam114, 1, 1, (V[]){v_one_242249}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242256 = (g_std_2edoc_2e_3c_3e(v_t_242248, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242255})));
        V v_a_242257 = (g_std_2edoc_2egroup(v_t_242256));
        V v_b_242258 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242259 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str145)}), v_b_242258));
        return (g_std_2edoc_2e_3c_3e(v_a_242257, v_t_242259));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_242247);
        V v_t_242260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242261 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242267 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam115, 1, 1, (V[]){v_one_242261}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242268 = (g_std_2edoc_2e_3c_3e(v_t_242260, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242267})));
        return (g_std_2edoc_2egroup(v_t_242268));
      }
    }
    case TAG_ECatch: {
      V v_t_242273 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242273) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242273);
        V v_t_242274 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242275 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242281 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam116, 1, 1, (V[]){v_one_242275}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242282 = (g_std_2edoc_2e_3c_3e(v_t_242274, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242281})));
        V v_a_242283 = (g_std_2edoc_2egroup(v_t_242282));
        V v_b_242284 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242285 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str146)}), v_b_242284));
        return (g_std_2edoc_2e_3c_3e(v_a_242283, v_t_242285));
      } else {
        heff_drop_tag(v_x_241244, 4);
        heff_drop(v_t_241246);
        heff_drop(v_t_242273);
        V v_t_242286 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242287 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242293 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam117, 1, 1, (V[]){v_one_242287}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242294 = (g_std_2edoc_2e_3c_3e(v_t_242286, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242293})));
        return (g_std_2edoc_2egroup(v_t_242294));
      }
    }
    case TAG_EWith: {
      V v_t_242301 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241244));
      if ((heff_dup(v_t_242301) == NTAG(TAG_True))) {
        heff_drop(v_args_241242);
        heff_drop(v_t_242301);
        V v_t_242302 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242303 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241240)}));
        V v_d_242309 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam118, 1, 1, (V[]){v_one_242303}); V a_2 = v_t_241246; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241246); r_; });
        V v_t_242310 = (g_std_2edoc_2e_3c_3e(v_t_242302, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242309})));
        V v_a_242311 = (g_std_2edoc_2egroup(v_t_242310));
        V v_b_242312 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241240, v_x_241244}));
        V v_t_242313 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str147)}), v_b_242312));
        return (g_std_2edoc_2e_3c_3e(v_a_242311, v_t_242313));
      } else {
        heff_drop_tag(v_x_241244, 6);
        heff_drop(v_t_241246);
        heff_drop(v_t_242301);
        V v_t_242314 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241240), v_h_241241}));
        V v_one_242315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241240}));
        V v_d_242321 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam119, 1, 1, (V[]){v_one_242315}); V a_2 = v_args_241242; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241242); r_; });
        V v_t_242322 = (g_std_2edoc_2e_3c_3e(v_t_242314, heff_tag_at_n(v_ru_24x1_241243_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242321})));
        return (g_std_2edoc_2egroup(v_t_242322));
      }
    }
    default: return heff_nomatch(v_x_241244);
    }
  }
  default: return heff_nomatch(v_x1_241243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args) {
  V v_env_242323 = args[0];
  V v_rest_242324 = args[1];
  V v_e_242325 = args[2];
  switch (heff_tag_of(v_e_242325)) {
  case TAG_Atom: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_242342 = heff_field(v_e_242325, 0);
    V v_fs_242343 = heff_field(v_e_242325, 1);
    V v_commas_242344 = heff_field(v_e_242325, 2);
    V v_c_242345 = heff_field(v_e_242325, 3);
    heff_take_n(v_e_242325, 15ULL, 4);
    switch (heff_tag_of(v_fs_242343)) {
    case TAG_Nil: {
      heff_drop(v_rest_242324);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_242323;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242342, v_fs_242343, v_commas_242344, v_c_242345});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_242346 = heff_dup(heff_field(v_fs_242343, 0));
      V v_rest2_242347 = heff_dup(heff_field(v_fs_242343, 1));
      switch (heff_tag_of(v_rest2_242347)) {
      case TAG_Nil: {
        V v_t_242348 = ({ V a_0 = v_rest_242324; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_242324); r_; });
        if ((heff_dup(v_t_242348) == NTAG(TAG_True))) {
          heff_drop(v_t_242348);
          V v_x1_242349 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_242346));
          if ((heff_dup(v_x1_242349) == NTAG(TAG_True))) {
            heff_drop(v_d_242346);
            heff_drop(v_x1_242349);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_242323;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242342, v_fs_242343, v_commas_242344, v_c_242345});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_242349);
            switch (heff_tag_of(v_commas_242344)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_242343, 2);
              V v_t_242350 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242323), v_o_242342));
              V v_t_242351 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242323), v_d_242346}));
              V v_t_242352 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242323, v_c_242345));
              V v_t_242353 = (g_std_2edoc_2e_3c_3e(v_t_242351, v_t_242352));
              return (g_std_2edoc_2e_3c_3e(v_t_242350, v_t_242353));
            }
            case TAG_Cons: {
              heff_drop(v_d_242346);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_242323;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242342, v_fs_242343, v_commas_242344, v_c_242345});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_242344);
            }
          }
        } else {
          heff_drop(v_d_242346);
          heff_drop(v_t_242348);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_242323;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242342, v_fs_242343, v_commas_242344, v_c_242345});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_242347, 0ULL, 2);
        heff_drop(v_rest_242324);
        heff_drop(v_d_242346);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_242323;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242342, v_fs_242343, v_commas_242344, v_c_242345});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_242347);
      }
    }
    default: return heff_nomatch(v_fs_242343);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242324);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242323;
    args[1] = v_e_242325;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_242325);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args) {
  V v_env_242486 = args[0];
  V v_b_242487 = args[1];
  switch (heff_tag_of(v_b_242487)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_242551 = heff_field(v_b_242487, 0);
    heff_take_n(v_b_242487, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242486, v_t_242551));
  }
  case TAG_BImp: {
    V v_o_242552 = heff_field(v_b_242487, 0);
    V v_x_242553 = heff_field(v_b_242487, 1);
    V v_c_242554 = heff_field(v_b_242487, 2);
    heff_take_n(v_b_242487, 7ULL, 3);
    V v_t_242555 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242486), v_o_242552));
    V v_t_242556 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242486), v_x_242553));
    V v_t_242557 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242486, v_c_242554));
    V v_t_242558 = (g_std_2edoc_2e_3c_3e(v_t_242556, v_t_242557));
    return (g_std_2edoc_2e_3c_3e(v_t_242555, v_t_242558));
  }
  case TAG_BAnn: {
    V v_o_242559 = heff_field(v_b_242487, 0);
    V v_x_242560 = heff_field(v_b_242487, 1);
    V v_cc_242561 = heff_field(v_b_242487, 2);
    V v_ty_242562 = heff_field(v_b_242487, 3);
    V v_c_242563 = heff_field(v_b_242487, 4);
    heff_take_n(v_b_242487, 31ULL, 5);
    V v_t_242564 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242486), v_o_242559));
    V v_a_242565 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242486), v_x_242560));
    V v_a_242566 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242486), v_cc_242561));
    V v_b_242567 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242486), v_ty_242562}));
    V v_t_242568 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str148)}), v_b_242567));
    V v_t_242569 = (g_std_2edoc_2e_3c_3e(v_a_242566, v_t_242568));
    V v_t_242570 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str149)}), v_t_242569));
    V v_t_242571 = (g_std_2edoc_2e_3c_3e(v_a_242565, v_t_242570));
    V v_t_242572 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242486, v_c_242563));
    V v_t_242573 = (g_std_2edoc_2e_3c_3e(v_t_242571, v_t_242572));
    return (g_std_2edoc_2e_3c_3e(v_t_242564, v_t_242573));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242486;
    args[1] = v_b_242487;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_242487);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args) {
  V v_env_242650 = args[0];
  V v_rest_242651 = args[1];
  V v_r_242652 = args[2];
  switch (heff_tag_of(v_r_242652)) {
  case TAG_Atom: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242711 = heff_field(v_r_242652, 0);
    V v_e_242712 = heff_field(v_r_242652, 1);
    heff_take_n(v_r_242652, 3ULL, 2);
    V v_a_242713 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242650), v_op_242711));
    V v_b_242714 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_242650, v_rest_242651, v_e_242712}));
    V v_t_242715 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str150)}), v_b_242714));
    return (g_std_2edoc_2e_3c_3e(v_a_242713, v_t_242715));
  }
  case TAG_Ann: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242651);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242650;
    args[1] = v_r_242652;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242652);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args) {
  V v_env_242804 = args[0];
  V v_r_242805 = args[1];
  switch (heff_tag_of(v_r_242805)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242864 = heff_field(v_r_242805, 0);
    V v_e_242865 = heff_field(v_r_242805, 1);
    heff_take_n(v_r_242805, 3ULL, 2);
    V v_a_242866 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242804), v_op_242864));
    V v_b_242867 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_242804, v_e_242865}));
    V v_t_242868 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str151)}), v_b_242867));
    return (g_std_2edoc_2e_3c_3e(v_a_242866, v_t_242868));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242804;
    args[1] = v_r_242805;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242805);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args) {
  V v_r_242970 = args[0];
  V v_env_242957 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242971 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242970));
  V v_t_242972;
  if ((heff_dup(v_x1_242971) == NTAG(TAG_True))) {
    heff_drop(v_x1_242971);
    v_t_242972 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242971);
    v_t_242972 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242973 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242957, v_r_242970}));
  return (g_std_2edoc_2e_3c_3e(v_t_242972, v_t_242973));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args) {
  V v_r_242979 = args[0];
  V v_env_242957 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242980 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242979));
  V v_t_242981;
  if ((heff_dup(v_x1_242980) == NTAG(TAG_True))) {
    heff_drop(v_x1_242980);
    v_t_242981 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242980);
    v_t_242981 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242982 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242957, v_r_242979}));
  return (g_std_2edoc_2e_3c_3e(v_t_242981, v_t_242982));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args) {
  V v_env_242957 = args[0];
  V v_first_242958 = args[1];
  V v_rest_242959 = args[2];
  V v_f_242960 = heff_dup(heff_rfield(v_env_242957, 6));
  HeffT2 v_t_242961 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_242960), heff_dup(v_rest_242959)));
  {
    V v_field_242963 = v_t_242961.f[1];
    int64_t v_tag_242962 = ((int64_t)v_t_242961.f[0]);
    V v_t_242968;
    if ((v_tag_242962 == ((int64_t)0ULL))) {
      V v_it1_242965 = v_field_242963;
      switch (heff_tag_of(v_it1_242965)) {
      case TAG_Nil: {
        heff_drop(v_f_242960);
        v_t_242968 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_242966 = heff_field(v_it1_242965, 0);
        V v_os_242967 = heff_field(v_it1_242965, 1);
        heff_take_n(v_it1_242965, 3ULL, 2);
        v_t_242968 = ({ V a_0 = v_f_242960; V a_1 = v_o_242966; V a_2 = v_os_242967; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_242967); r_; });
        break;
      }
      default: heff_nomatch(v_it1_242965);
      }
    } else {
      heff_drop(v_f_242960);
      heff_drop(v_field_242963);
      v_t_242968 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_242968)) {
    case TAG_Nothing: {
      V v_t_242969 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242957), v_first_242958}));
      V v_t_242974 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam125, 1, 1, (V[]){v_env_242957}); V a_2 = v_rest_242959; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242959); r_; });
      V v_t_242975 = (g_std_2edoc_2e_3c_3e(v_t_242969, v_t_242974));
      return (g_std_2edoc_2egroup(v_t_242975));
    }
    case TAG_Just: {
      V v_m_242976 = heff_field(v_t_242968, 0);
      heff_take_n(v_t_242968, 1ULL, 1);
      V v_t_242977 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_242957, 6)), heff_dup(v_m_242976), v_rest_242959));
      if ((heff_dup(v_t_242977) == NTAG(TAG_True))) {
        heff_drop(v_m_242976);
        heff_drop(v_t_242977);
        V v_t_242978 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242957), v_first_242958}));
        V v_t_242983 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam126, 1, 1, (V[]){v_env_242957}); V a_2 = v_rest_242959; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242959); r_; });
        V v_t_242984 = (g_std_2edoc_2e_3c_3e(v_t_242978, v_t_242983));
        return (g_std_2edoc_2egroup(v_t_242984));
      } else {
        heff_drop(v_t_242977);
        V v_t_242985 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242957, v_m_242976, v_first_242958, NTAG(TAG_Nil), v_rest_242959}));
        return (g_std_2edoc_2egroup(v_t_242985));
      }
    }
    default: return heff_nomatch(v_t_242968);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args) {
  V v_env_242986 = args[0];
  V v_m_242987 = args[1];
  V v_f_242988 = args[2];
  V v_acc_242989 = args[3];
  V v_rs_242990 = args[4];
  switch (heff_tag_of(v_rs_242990)) {
  case TAG_Nil: {
    heff_drop(v_m_242987);
    V v_t_242991 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242989));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_242986;
    args[1] = v_f_242988;
    args[2] = v_t_242991;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_242992 = heff_field(v_rs_242990, 0);
    V v_rest2_242993 = heff_field(v_rs_242990, 1);
    heff_take_n(v_rs_242990, 3ULL, 2);
    switch (heff_tag_of(v_r_242992)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_243052 = heff_dup(heff_field(v_r_242992, 0));
      V v_e_243053 = heff_dup(heff_field(v_r_242992, 1));
      V v_t_243054 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_242986, 6)), heff_dup(v_m_242987), heff_dup(heff_rfield(v_op_243052, 1))));
      switch (heff_tag_of(v_t_243054)) {
      case TAG_Tighter: {
        heff_drop_rec(v_op_243052, 9);
        heff_drop(v_e_243053);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242986;
        args[1] = v_m_242987;
        args[2] = v_f_242988;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
        args[4] = v_rest2_242993;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_rec(v_op_243052, 9);
        heff_drop(v_e_243053);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242986;
        args[1] = v_m_242987;
        args[2] = v_f_242988;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
        args[4] = v_rest2_242993;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_243054_24Same = heff_take_reuse_n(v_t_243054, 0ULL, 1);
        V v_t_243056 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242989));
        V v_t_243057 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_242986), v_f_242988, v_t_243056}));
        V v_x1_243058 = ({ V a_0 = v_r_242992; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_242992, 2); r_; });
        V v_t_243059;
        if ((heff_dup(v_x1_243058) == NTAG(TAG_True))) {
          heff_drop(v_x1_243058);
          v_t_243059 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_243058);
          v_t_243059 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_243060 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242986), v_op_243052));
        V v_b_243061 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242986, v_m_242987, v_e_243053, NTAG(TAG_Nil), v_rest2_242993}));
        V v_t_243062 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_243054_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str152)}), v_b_243061));
        V v_t_243063 = (g_std_2edoc_2e_3c_3e(v_a_243060, v_t_243062));
        V v_t_243064 = (g_std_2edoc_2e_3c_3e(v_t_243059, v_t_243063));
        return (g_std_2edoc_2e_3c_3e(v_t_243057, v_t_243064));
      }
      case TAG_Unrelated: {
        heff_drop_rec(v_op_243052, 9);
        heff_drop(v_e_243053);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242986;
        args[1] = v_m_242987;
        args[2] = v_f_242988;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
        args[4] = v_rest2_242993;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_243054, 0ULL, 1);
        heff_drop_rec(v_op_243052, 9);
        heff_drop(v_e_243053);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242986;
        args[1] = v_m_242987;
        args[2] = v_f_242988;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
        args[4] = v_rest2_242993;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_243054);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetMut: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAssign: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWhile: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFor: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EJump: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EReturn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENest: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_IfThen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetCond: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETry: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECatch: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWith: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242986;
      args[1] = v_m_242987;
      args[2] = v_f_242988;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242992, v_acc_242989});
      args[4] = v_rest2_242993;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_242992);
    }
  }
  default: return heff_nomatch(v_rs_242990);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args) {
  V v_env_243154 = args[0];
  V v_a_243155 = args[1];
  switch (heff_tag_of(v_a_243155)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_243236 = heff_field(v_a_243155, 0);
    V v_arrow_243237 = heff_field(v_a_243155, 1);
    V v_body_243238 = heff_field(v_a_243155, 2);
    heff_take_n(v_a_243155, 7ULL, 3);
    V v_a_243239 = ({ V a_0 = heff_dup(v_env_243154); V a_1 = v_p_243236; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_243236); r_; });
    V v_b_243240 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243154), v_arrow_243237));
    V v_t_243241 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str153)}), v_b_243240));
    V v_t_243242 = (g_std_2edoc_2e_3c_3e(v_a_243239, v_t_243241));
    V v_t_243243 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243154, v_body_243238}));
    return (g_std_2edoc_2e_3c_3e(v_t_243242, v_t_243243));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243154;
    args[1] = v_a_243155;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_243155);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args) {
  V v_env_243309 = args[0];
  V v_s_243310 = args[1];
  switch (heff_tag_of(v_s_243310)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_243402 = heff_field(v_s_243310, 0);
    V v_arrow_243403 = heff_field(v_s_243310, 1);
    V v_e_243404 = heff_field(v_s_243310, 2);
    heff_take_n(v_s_243310, 7ULL, 3);
    V v_a_243405 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243309), v_x_243402));
    V v_b_243406 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243309), v_arrow_243403));
    V v_t_243407 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str154)}), v_b_243406));
    V v_t_243408 = (g_std_2edoc_2e_3c_3e(v_a_243405, v_t_243407));
    V v_t_243409 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243309, v_e_243404}));
    return (g_std_2edoc_2e_3c_3e(v_t_243408, v_t_243409));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243309;
    args[1] = v_s_243310;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_243310);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args) {
  V v_env_243464 = args[0];
  V v_f_243465 = args[1];
  switch (heff_tag_of(v_f_243465)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_243492 = heff_field(v_f_243465, 0);
    V v_eq_243493 = heff_field(v_f_243465, 1);
    V v_e_243494 = heff_field(v_f_243465, 2);
    heff_take_n(v_f_243465, 7ULL, 3);
    V v_a_243495 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243464), v_x_243492}));
    V v_b_243496 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243464), v_eq_243493));
    V v_t_243497 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str155)}), v_b_243496));
    V v_t_243498 = (g_std_2edoc_2e_3c_3e(v_a_243495, v_t_243497));
    V v_t_243499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243464, v_e_243494}));
    return (g_std_2edoc_2e_3c_3e(v_t_243498, v_t_243499));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_243505 = heff_field(v_f_243465, 0);
    V v_eq_243506 = heff_field(v_f_243465, 1);
    V v_e_243507 = heff_field(v_f_243465, 2);
    heff_take_n(v_f_243465, 7ULL, 3);
    V v_a_243508 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243464), v_x_243505));
    V v_b_243509 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243464), v_eq_243506));
    V v_t_243510 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str156)}), v_b_243509));
    V v_t_243511 = (g_std_2edoc_2e_3c_3e(v_a_243508, v_t_243510));
    V v_t_243512 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243464, v_e_243507}));
    return (g_std_2edoc_2e_3c_3e(v_t_243511, v_t_243512));
  }
  case TAG_EFDefault: {
    V v_d_243513 = heff_field(v_f_243465, 0);
    V v_eq_243514 = heff_field(v_f_243465, 1);
    V v_e_243515 = heff_field(v_f_243465, 2);
    heff_take_n(v_f_243465, 7ULL, 3);
    V v_a_243516 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243464), v_d_243513}));
    V v_b_243517 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243464), v_eq_243514));
    V v_t_243518 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str157)}), v_b_243517));
    V v_t_243519 = (g_std_2edoc_2e_3c_3e(v_a_243516, v_t_243518));
    V v_t_243520 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243464, v_e_243515}));
    return (g_std_2edoc_2e_3c_3e(v_t_243519, v_t_243520));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243464;
    args[1] = v_f_243465;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_243465);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = heff_take_field(v_t_244, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2412;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = heff_get_n(v_t_244, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop_rec(v_t_244, 9);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2412 = heff_get_n(v_t_244, 8, 9);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str14, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DInstance: {
    V v_n_2411 = heff_field(v_d_240, 1);
    V v_x2_2414 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_DEqn: {
    V v_n_2417 = heff_field(v_d_240, 0);
    V v_x2_2422 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2417)));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DMutual: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str14);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0, 7, "doctest");
Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DFixity: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DSig: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DInstance: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DEqn: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DData: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DType: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTheory: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DMutual: {
    V v_ds_2433 = heff_field(v_d_241, 1);
    V v_x1_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ds_2433)));
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 7);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 2);
      switch (heff_tag_of(v_x_2435)) {
      case TAG_DImport: {
        heff_take_n(v_x_2435, 0ULL, 1);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DFixity: {
        heff_take_n(v_x_2435, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DSig: {
        heff_take_n(v_x_2435, 0ULL, 3);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DInstance: {
        heff_take_n(v_x_2435, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DEqn: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DData: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DType: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTheory: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DMutual: {
        heff_take_n(v_x_2435, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DPrimitive: {
        heff_take_n(v_x_2435, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTest: {
        heff_take_n(v_x_2435, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DWatch: {
        V v_w_2475 = heff_field(v_x_2435, 0);
        V v_e_2476 = heff_field(v_x_2435, 1);
        heff_take_n(v_x_2435, 3ULL, 2);
        V v_t_2477 = heff_strEq(heff_get_n(v_w_2475, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0));
        V v_t_2478 = (g_heff_2esyntax_2ecst_2elastE(v_e_2476));
        V v_t_2479 = heff_intAdd(heff_get_n(v_t_2478, 7, 9), MK_INT(1LL));
        HeffT2 v_t_2480 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_t_2479; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2485;
        {
          V v_field_2482 = v_t_2480.f[1];
          int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
          if ((v_tag_2481 == ((int64_t)0ULL))) {
            V v_x_2484 = v_field_2482;
            v_t_2485 = v_x_2484;
          } else {
            heff_drop(v_field_2482);
            v_t_2485 = NTAG(TAG_Nil);
          }
        }
        return ({ V a_0 = v_t_2477; V a_1 = v_t_2485; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines(a_0, a_1)); heff_drop(v_t_2477); r_; });
      }
      default: return heff_nomatch(v_x_2435);
      }
    }
    default: return heff_nomatch(v_x1_2434);
    }
  }
  case TAG_DPrimitive: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTest: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DWatch: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eblockExpect(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_eof_243, 7, 9)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_247);
        v_t_2410 = NTAG(TAG_Nil);
      }
    }
    return ({ V a_0 = v_env_240; V a_1 = v_t_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_2410); r_; });
  }
  case TAG_Cons: {
    V v_d_2411 = heff_field(v_x5_244, 0);
    V v_ds_2412 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2411));
    V v_t_2454;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_DImport: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2452 = heff_dup(heff_field(v_d_2411, 0));
      v_t_2454 = heff_strEq(heff_get_n(v_w_2452, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2482;
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
      V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2455, v_t_2456, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2411)})));
      V v_t_2459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2411); r_; });
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2459, v_eof_243, v_ds_2412));
      v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2460));
    } else {
      heff_drop(v_t_2454);
      V v_t_2461 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2461);
        V v_t_2462 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2411));
        V v_t_2464 = ({ V a_0 = v_t_2463; V a_1 = heff_dup(v_d_2411); V a_2 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
        V v_t_2465 = (g_heff_2esyntax_2ecst_2elastD(v_t_2464));
        V v_t_2466 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2462, v_t_2465));
        V v_t_2467 = ({ V a_0 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2411); r_; });
        V v_t_2468 = ({ V a_0 = v_t_2467; V a_1 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2467); r_; });
        V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2468));
        v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2466, v_t_2469));
      } else {
        heff_drop(v_t_2461);
        V v_expect_2470 = (g_heff_2esyntax_2efmt_2elayout_2eblockExpect(heff_dup(v_env_240), v_d_2411));
        V v_t_2471 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2472 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
        V v_t_2474 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2471, v_t_2472, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2411)})));
        V v_d_2475 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_2470));
        V v_t_2476 = (g_heff_2esyntax_2ecst_2elastD(v_d_2411));
        V v_t_2477 = heff_intAdd(heff_get_n(v_t_2476, 7, 9), MK_INT(1LL));
        V v_t_2478 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_2470; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_2470); r_; });
        V v_t_2479 = (g_heff_2esyntax_2efmt_2elayout_2eleadLaid(v_env_240, v_t_2477, v_t_2478));
        V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_2479, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2412));
        V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2475}), v_t_2480));
        v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2474, v_t_2481));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2482));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2457 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2457; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2473 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2473; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = ({ V b_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5); V a_2 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  return heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_claim_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    V v_t_245 = (g_heff_2esyntax_2efmt_2eimports_2eexposingToks(heff_rfield(v_claim_242, 1)));
    V v_t_246 = (g_list_2emap_24s1845612977x612508518(heff_get_n(v_claim_242, 0, 3)));
    V v_t_247 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_take_field(v_l_243, 0), v_t_245, v_t_246));
    V v_t_248 = (g_list_2esortBy_24s88152486x2058486153(v_t_247));
    HeffT2 v_t_249 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_248, heff_get_n(v_l_243, 2, 3)));
    V v_t_2413;
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_t_2412 = ({ V rv_6 = v_f_240; V rr_ = heff_rec_reuse_nf(v_field_2411, 63ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      v_t_2413 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2410, v_t_2412});
    }
    return (g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(v_t_2413));
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_claim_242, 3);
    heff_drop_rec(v_l_243, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_244)}});
  }
}