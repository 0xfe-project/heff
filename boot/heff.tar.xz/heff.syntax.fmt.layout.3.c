// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_exposing 966605106
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_2418;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        switch (heff_tag_of(v_x_247)) {
        case TAG_Nil: {
          v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x_247, 0ULL, 2);
          V v_t_2416;
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
            v_t_2416 = NTAG(TAG_Nil);
          } else {
            HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                V v_x_2415 = v_field_2413;
                v_t_2416 = v_x_2415;
              } else {
                heff_drop(v_field_2413);
                v_t_2416 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2417 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2416); r_; });
          v_t_2418 = (g_std_2edoc_2e_3c_3e(v_t_2417, heff_dup(g_std_2edoc_2ehardline_get())));
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
  }
  HeffT2 v_t_2419 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 2), heff_dup(heff_rfield(v_t_241, 7))));
  V v_t_2424;
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2423 = v_field_2421;
      v_t_2424 = v_x_2423;
    } else {
      heff_drop(v_field_2421);
      v_t_2424 = NTAG(TAG_Nil);
    }
  }
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2424); r_; });
  V v_s_2426 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2428;
  if (heff_strEq_c_lent(v_s_2426, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2426);
    v_t_2428 = NTAG(TAG_None);
  } else {
    v_t_2428 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2426});
  }
  V v_t_2430;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2430 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2430 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2431 = (g_std_2edoc_2e_3c_3e(v_t_2428, v_t_2430));
  V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2431));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2432);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_c_242, 0)));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2453));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2453));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2476 = heff_field(v_e_240, 3);
    V t_0 = v_body_2476;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2439 = heff_field(v_x1_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2439, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EField: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_App: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Op: {
    V v_a_2454 = heff_field(v_e_240, 0);
    V v_op_2455 = heff_field(v_e_240, 1);
    V v_b_2456 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_2456)));
    {
      V v_field_2458 = v_t_2457.f[0];
      V v_field_2459 = v_t_2457.f[1];
      V v_bf_2460 = v_field_2458;
      V v_rest_2461 = v_field_2459;
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2455), v_rest_2461));
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop(v_b_2456);
        heff_drop(v_t_2462);
        V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_bf_2460}), v_rest_2461});
        return ((HeffT2){{v_a_2454, v_t_2463}});
      } else {
        heff_drop(v_bf_2460);
        heff_drop(v_rest_2461);
        heff_drop(v_t_2462);
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_b_2456}), NTAG(TAG_Nil)});
        return ((HeffT2){{v_a_2454, v_t_2464}});
      }
    }
  }
  case TAG_Ops: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_If: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetCond: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2461 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2461, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetMut: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAssign: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFor: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EJump: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EReturn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_IfThen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetCond: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ETry: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECatch: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_r_242, 0);
    V v_t_2463 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2461, 1))));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_x1_240, 1);
    V v_x1_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2453)));
    switch (heff_tag_of(v_x1_2454)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x1_2454, 0);
      V v_rev_2456 = heff_field(v_x1_2454, 1);
      heff_take_n(v_x1_2454, 3ULL, 2);
      V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2456));
      heff_drop(v_t_2457);
      switch (heff_tag_of(v_x_2455)) {
      case TAG_Atom: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 1); r_; });
      }
      case TAG_EParen: {
        V v_e_2460 = heff_field(v_x_2455, 1);
        heff_take_n(v_x_2455, 2ULL, 3);
        return ({ V a_0 = v_e_2460; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2460); r_; });
      }
      case TAG_Named: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_Tup: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_Seg: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_Braces: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_Update: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_EUSet: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_InstB: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_EFSet: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_EFDefault: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_Sum: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_ECon: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_EField: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_ENeg: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_App: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_Op: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_Ops: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_OpRhs: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_Ann: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_BVar: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 1); r_; });
      }
      case TAG_BImp: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_BAnn: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 5); r_; });
      }
      case TAG_Lam: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_Case: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_EAlt: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_If: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_Do: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_ESBind: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_ELet: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_ELetMut: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_EAssign: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 3); r_; });
      }
      case TAG_EWhile: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_EFor: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 6); r_; });
      }
      case TAG_EJump: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 1); r_; });
      }
      case TAG_EReturn: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 2); r_; });
      }
      case TAG_ENest: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_IfThen: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_ELetCond: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_ETry: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      case TAG_ECatch: {
        return ({ V a_0 = v_x_2455; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2455, 4); r_; });
      }
      default: return heff_nomatch(v_x_2455);
      }
    }
    default: return heff_nomatch(v_x1_2454);
    }
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_take_field(v_t_246, 7)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = heff_get_n(v_t_246, 8, 9);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop_rec(v_t_246, 9);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_249);
          v_t_2414 = heff_get_n(v_t_246, 8, 9);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str111, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str113, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str115, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str116, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str117, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str118, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str119, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str122, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str123, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str125, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str126, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str127, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str128, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str129, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str131, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str132, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str133, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str135, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str136, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str137, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str138, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str140, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str141, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str142, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str143, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str145, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str146, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str147, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str149, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str151, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam116, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam117, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam118, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam119, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam120, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam123, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam124, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam125, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam126, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam26_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam27_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam32_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam33_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam116_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam117_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam118_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam119_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam120_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam123_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam124_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam125_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2445 = args[0];
  V v_e_2446 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2445));
  V v_one_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2446));
  V v_b_2453;
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_t_2449);
    V v_d_2450 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2450});
  } else {
    heff_drop(v_t_2449);
    V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2446));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      V v_d_2452 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
      v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2452});
    } else {
      heff_drop(v_t_2451);
      v_b_2453 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    }
  }
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2453));
  V v_t_2455 = (g_std_2edoc_2e_3c_3e(v_a_2447, v_t_2454));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2455));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  V v_d_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2467 = heff_intSub(v_k_2465, v_i_2466);
  if (heff_intEq_c_lent(v_i_2467, MK_INT(0LL), 2)) {
    heff_drop(v_i_2467);
    return v_d_2464;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2467, v_d_2464});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2465 = args[0];
  V v_d_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2465, v_d_2464})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2474 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2489 = args[0];
  V v_f_2490 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2489));
  V v_d_2492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2490}));
  V v_t_2493 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2492})));
  V v_t_2494 = (g_std_2edoc_2e_3c_3e(v_a_2491, v_t_2493));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2494));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24103 = args[0];
  V v_k_24102 = heff_env(self)[0];
  V v_d_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24104 = heff_intSub(v_k_24102, v_i_24103);
  if (heff_intEq_c_lent(v_i_24104, MK_INT(0LL), 2)) {
    heff_drop(v_i_24104);
    return v_d_24101;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24104, v_d_24101});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24102 = args[0];
  V v_d_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24102, v_d_24101})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24131 = args[0];
  V v_f_24132 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24131));
  V v_d_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24132}));
  V v_t_24135 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24134})));
  V v_t_24136 = (g_std_2edoc_2e_3c_3e(v_a_24133, v_t_24135));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24147 = args[0];
  V v_k_24146 = heff_env(self)[0];
  V v_d_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24148 = heff_intSub(v_k_24146, v_i_24147);
  if (heff_intEq_c_lent(v_i_24148, MK_INT(0LL), 2)) {
    heff_drop(v_i_24148);
    return v_d_24145;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24148, v_d_24145});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24146 = args[0];
  V v_d_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24146, v_d_24145})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24205 = args[0];
  V v_a_24206 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24188 = heff_env(self)[1];
  V v_c_24191 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24207 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24188, 4, 9), heff_get_n(v_c_24191, 3, 9)));
  V v_t_24208;
  if ((heff_dup(v_x1_24207) == NTAG(TAG_True))) {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24209 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24205));
  V v_b_24210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24206}));
  V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24210));
  V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
  return (g_std_2edoc_2e_3c_3e(v_t_24208, v_t_24212));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24219 = args[0];
  V v_k_24218 = heff_env(self)[0];
  V v_d_24217 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24220 = heff_intSub(v_k_24218, v_i_24219);
  if (heff_intEq_c_lent(v_i_24220, MK_INT(0LL), 2)) {
    heff_drop(v_i_24220);
    return v_d_24217;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24220, v_d_24217});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24218 = args[0];
  V v_d_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24218, v_d_24217})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24227 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24227}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24249 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24250 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24249));
  V v_t_24251;
  if ((heff_dup(v_x1_24250) == NTAG(TAG_True))) {
    heff_drop(v_x1_24250);
    v_t_24251 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24250);
    v_t_24251 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24247, v_r_24249}));
  return (g_std_2edoc_2e_3c_3e(v_t_24251, v_t_24252));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24365 = args[0];
  V v_k_24364 = heff_env(self)[0];
  V v_d_24363 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24366 = heff_intSub(v_k_24364, v_i_24365);
  if (heff_intEq_c_lent(v_i_24366, MK_INT(0LL), 2)) {
    heff_drop(v_i_24366);
    return v_d_24363;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24366, v_d_24363});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24364 = args[0];
  V v_d_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24364, v_d_24363})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24411 = args[0];
  V v_k_24410 = heff_env(self)[0];
  V v_d_24407 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24412 = heff_intSub(v_k_24410, v_i_24411);
  if (heff_intEq_c_lent(v_i_24412, MK_INT(0LL), 2)) {
    heff_drop(v_i_24412);
    return v_d_24407;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24412, v_d_24407});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24410 = args[0];
  V v_d_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24410, v_d_24407})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24431 = args[0];
  V v_k_24430 = heff_env(self)[0];
  V v_d_24427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24432 = heff_intSub(v_k_24430, v_i_24431);
  if (heff_intEq_c_lent(v_i_24432, MK_INT(0LL), 2)) {
    heff_drop(v_i_24432);
    return v_d_24427;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24432, v_d_24427});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24430 = args[0];
  V v_d_24427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24430, v_d_24427})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24491 = args[0];
  V v_k_24490 = heff_env(self)[0];
  V v_d_24489 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24492 = heff_intSub(v_k_24490, v_i_24491);
  if (heff_intEq_c_lent(v_i_24492, MK_INT(0LL), 2)) {
    heff_drop(v_i_24492);
    return v_d_24489;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24492, v_d_24489});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24490 = args[0];
  V v_d_24489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24490, v_d_24489})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2435));
      V v_t_2444;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        V v_d_2441 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2441});
      } else {
        heff_drop(v_t_2440);
        V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2435));
        if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
          heff_drop(v_t_2442);
          V v_d_2443 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
          v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2443});
        } else {
          heff_drop(v_t_2442);
          v_t_2444 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        }
      }
      V v_t_2456 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2457 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2458;
      if ((heff_dup(v_x1_2457) == NTAG(TAG_True))) {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2444, v_t_2461));
      V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2462));
      V v_d_2464 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2463));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2464})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2469 = heff_field(v_e0_241, 0);
    V v_cc_2470 = heff_field(v_e0_241, 1);
    V v_spec_2471 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2469}));
    V v_t_2473 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2470));
    V v_t_2475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2471; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2471); r_; });
    V v_t_2476 = (g_std_2edoc_2e_3c_3e(v_t_2473, v_t_2475));
    return (g_std_2edoc_2e_3c_3e(v_t_2472, v_t_2476));
  }
  case TAG_Braces: {
    V v_o_2477 = heff_field(v_e0_241, 0);
    V v_fs_2478 = heff_field(v_e0_241, 1);
    V v_commas_2479 = heff_field(v_e0_241, 2);
    V v_c_2480 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2478)) {
    case TAG_Nil: {
      heff_drop(v_commas_2479);
      V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2477));
      V v_t_2482 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      return (g_std_2edoc_2e_3c_3e(v_t_2481, v_t_2482));
    }
    case TAG_Cons: {
      V v_f1_2483 = heff_field(v_fs_2478, 0);
      V v_more_2484 = heff_field(v_fs_2478, 1);
      V v_ru_24fs_2478_24Cons = heff_take_reuse_n(v_fs_2478, 3ULL, 2);
      V v_a_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2477)));
      V v_d_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2483}));
      V v_t_2487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2478_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2486})));
      V v_t_2488 = (g_std_2edoc_2e_3c_3e(v_a_2485, v_t_2487));
      V v_t_2495 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2479; V a_3 = v_more_2484; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2479); heff_drop(v_more_2484); r_; });
      V v_x1_2496 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2477, 4, 9), heff_dup(heff_rfield(v_c_2480, 3))));
      V v_t_2497;
      if ((heff_dup(v_x1_2496) == NTAG(TAG_True))) {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2498 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2497, v_t_2498));
      V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2499));
      V v_d_24101 = (g_std_2edoc_2e_3c_3e(v_t_2488, v_t_24100));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_24101})})));
    }
    default: return heff_nomatch(v_fs_2478);
    }
  }
  case TAG_Update: {
    V v_o_24106 = heff_field(v_e0_241, 0);
    V v_r_24107 = heff_field(v_e0_241, 1);
    V v_bar_24108 = heff_field(v_e0_241, 2);
    V v_fs_24109 = heff_field(v_e0_241, 3);
    V v_commas_24110 = heff_field(v_e0_241, 4);
    V v_c_24111 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24109)) {
    case TAG_Nil: {
      heff_drop(v_commas_24110);
      V v_a_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24106));
      V v_a_24113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_a_24114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_b_24115 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24116));
      V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24117));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24118));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24119));
      return (g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24120));
    }
    case TAG_Cons: {
      V v_f1_24121 = heff_field(v_fs_24109, 0);
      V v_more_24122 = heff_field(v_fs_24109, 1);
      V v_ru_24fs_24109_24Cons = heff_take_reuse_n(v_fs_24109, 3ULL, 2);
      V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24106)));
      V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24109_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24124})));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_a_24127 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_d_24128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24121}));
      V v_t_24129 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24128})));
      V v_t_24130 = (g_std_2edoc_2e_3c_3e(v_a_24127, v_t_24129));
      V v_t_24137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24110; V a_3 = v_more_24122; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24110); heff_drop(v_more_24122); r_; });
      V v_x1_24138 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24106, 4, 9), heff_dup(heff_rfield(v_c_24111, 3))));
      V v_t_24139;
      if ((heff_dup(v_x1_24138) == NTAG(TAG_True))) {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24140 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(v_t_24139, v_t_24140));
      V v_t_24142 = (g_std_2edoc_2e_3c_3e(v_t_24137, v_t_24141));
      V v_t_24143 = (g_std_2edoc_2e_3c_3e(v_t_24130, v_t_24142));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24143));
      V v_d_24145 = (g_std_2edoc_2e_3c_3e(v_t_24126, v_t_24144));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24145})})));
    }
    default: return heff_nomatch(v_fs_24109);
    }
  }
  case TAG_EUSet: {
    V v_x_24150 = heff_field(v_e0_241, 0);
    V v_eq_24151 = heff_field(v_e0_241, 1);
    V v_e_24152 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24150}));
    V v_b_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24151));
    V v_t_24155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24154));
    V v_t_24156 = (g_std_2edoc_2e_3c_3e(v_a_24153, v_t_24155));
    V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24152}));
    return (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
  }
  case TAG_InstB: {
    V v_o_24158 = heff_field(v_e0_241, 0);
    V v_o2_24159 = heff_field(v_e0_241, 1);
    V v_d_24160 = heff_field(v_e0_241, 2);
    V v_c1_24161 = heff_field(v_e0_241, 3);
    V v_c_24162 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24158));
    V v_t_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24159));
    V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24160}));
    V v_t_24166 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24161));
    V v_t_24167 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24162));
    V v_t_24168 = (g_std_2edoc_2e_3c_3e(v_t_24166, v_t_24167));
    V v_t_24169 = (g_std_2edoc_2e_3c_3e(v_t_24165, v_t_24168));
    V v_t_24170 = (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24169));
    return (g_std_2edoc_2e_3c_3e(v_t_24163, v_t_24170));
  }
  case TAG_EFSet: {
    V v_x_24171 = heff_field(v_e0_241, 0);
    V v_eq_24172 = heff_field(v_e0_241, 1);
    V v_e_24173 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24174 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24171));
    V v_b_24175 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24172));
    V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24175));
    V v_t_24177 = (g_std_2edoc_2e_3c_3e(v_a_24174, v_t_24176));
    V v_t_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24173}));
    return (g_std_2edoc_2e_3c_3e(v_t_24177, v_t_24178));
  }
  case TAG_EFDefault: {
    V v_d_24179 = heff_field(v_e0_241, 0);
    V v_eq_24180 = heff_field(v_e0_241, 1);
    V v_e_24181 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24179}));
    V v_b_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24180));
    V v_t_24184 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24183));
    V v_t_24185 = (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24184));
    V v_t_24186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24181}));
    return (g_std_2edoc_2e_3c_3e(v_t_24185, v_t_24186));
  }
  case TAG_Sum: {
    V v_kw_24187 = heff_field(v_e0_241, 0);
    V v_o_24188 = heff_field(v_e0_241, 1);
    V v_alts_24189 = heff_field(v_e0_241, 2);
    V v_bars_24190 = heff_field(v_e0_241, 3);
    V v_c_24191 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24189)) {
    case TAG_Nil: {
      heff_drop(v_bars_24190);
      V v_a_24192 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24193 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24188));
      V v_b_24194 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24195 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24194));
      V v_t_24196 = (g_std_2edoc_2e_3c_3e(v_a_24193, v_t_24195));
      V v_t_24197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24196));
      return (g_std_2edoc_2e_3c_3e(v_a_24192, v_t_24197));
    }
    case TAG_Cons: {
      V v_a1_24198 = heff_field(v_alts_24189, 0);
      V v_more_24199 = heff_field(v_alts_24189, 1);
      heff_take_n(v_alts_24189, 3ULL, 2);
      V v_a_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24201 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24188)));
      V v_b_24202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24198}));
      V v_t_24203 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24202));
      V v_t_24204 = (g_std_2edoc_2e_3c_3e(v_a_24201, v_t_24203));
      V v_a_24213 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24188, heff_dup(v_c_24191)}); V a_2 = v_bars_24190; V a_3 = v_more_24199; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24190); heff_drop(v_more_24199); r_; });
      V v_b_24214 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24215 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24214));
      V v_t_24216 = (g_std_2edoc_2e_3c_3e(v_a_24213, v_t_24215));
      V v_d_24217 = (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24216));
      V v_b_24222 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24217})})));
      V v_t_24223 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24222));
      return (g_std_2edoc_2e_3c_3e(v_a_24200, v_t_24223));
    }
    default: return heff_nomatch(v_alts_24189);
    }
  }
  case TAG_ECon: {
    V v_c_24224 = heff_field(v_e0_241, 0);
    V v_args_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24224));
    V v_t_24229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24225; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24225); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24229));
  }
  case TAG_EField: {
    V v_e_24230 = heff_field(v_e0_241, 0);
    V v_f_24231 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24230}));
    V v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24231));
    return (g_std_2edoc_2e_3c_3e(v_t_24232, v_t_24233));
  }
  case TAG_ENeg: {
    V v_m_24234 = heff_field(v_e0_241, 0);
    V v_e_24235 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24236 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24234));
    V v_t_24237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24235}));
    return (g_std_2edoc_2e_3c_3e(v_t_24236, v_t_24237));
  }
  case TAG_App: {
    V v_h_24238 = heff_field(v_e0_241, 0);
    V v_args_24239 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24238;
    heff_room[2] = v_args_24239;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24240 = heff_field(v_e0_241, 0);
    V v_op_24241 = heff_field(v_e0_241, 1);
    V v_b_24242 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24243 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24240, v_op_24241, v_b_24242})));
    {
      V v_field_24244 = v_t_24243.f[0];
      V v_field_24245 = v_t_24243.f[1];
      V v_first_24246 = v_field_24244;
      V v_rest_24247 = v_field_24245;
      V v_t_24248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24247), v_first_24246}));
      V v_t_24253 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24247)}); V a_2 = v_rest_24247; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24247); r_; });
      V v_t_24254 = (g_std_2edoc_2e_3c_3e(v_t_24248, v_t_24253));
      return (g_std_2edoc_2egroup(v_t_24254));
    }
  }
  case TAG_Ops: {
    V v_a_24255 = heff_field(v_e0_241, 0);
    V v_rest_24256 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24255;
    heff_room[2] = v_rest_24256;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24257 = heff_field(v_e0_241, 0);
    V v_e_24258 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24259 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24257));
    V v_b_24260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24258}));
    V v_t_24261 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24260));
    return (g_std_2edoc_2e_3c_3e(v_a_24259, v_t_24261));
  }
  case TAG_Ann: {
    V v_e_24262 = heff_field(v_e0_241, 0);
    V v_cc_24263 = heff_field(v_e0_241, 1);
    V v_ty_24264 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24265 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24262}));
    V v_b_24266 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24263));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24266));
    V v_t_24268 = (g_std_2edoc_2e_3c_3e(v_a_24265, v_t_24267));
    V v_t_24269 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24264}));
    V v_d_24270 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24269));
    V v_t_24271 = (g_std_2edoc_2e_3c_3e(v_t_24268, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24270})));
    return (g_std_2edoc_2egroup(v_t_24271));
  }
  case TAG_BVar: {
    V v_t_24272 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24272));
  }
  case TAG_BImp: {
    V v_o_24273 = heff_field(v_e0_241, 0);
    V v_x_24274 = heff_field(v_e0_241, 1);
    V v_c_24275 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24276 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24273));
    V v_t_24277 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24274));
    V v_t_24278 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24275));
    V v_t_24279 = (g_std_2edoc_2e_3c_3e(v_t_24277, v_t_24278));
    return (g_std_2edoc_2e_3c_3e(v_t_24276, v_t_24279));
  }
  case TAG_BAnn: {
    V v_o_24280 = heff_field(v_e0_241, 0);
    V v_x_24281 = heff_field(v_e0_241, 1);
    V v_cc_24282 = heff_field(v_e0_241, 2);
    V v_ty_24283 = heff_field(v_e0_241, 3);
    V v_c_24284 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24285 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24280));
    V v_a_24286 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24281));
    V v_a_24287 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24282));
    V v_b_24288 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24283}));
    V v_t_24289 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24288));
    V v_t_24290 = (g_std_2edoc_2e_3c_3e(v_a_24287, v_t_24289));
    V v_t_24291 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24290));
    V v_t_24292 = (g_std_2edoc_2e_3c_3e(v_a_24286, v_t_24291));
    V v_t_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24284));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(v_t_24292, v_t_24293));
    return (g_std_2edoc_2e_3c_3e(v_t_24285, v_t_24294));
  }
  case TAG_Lam: {
    V v_bs_24295 = heff_field(v_e0_241, 0);
    V v_binders_24296 = heff_field(v_e0_241, 1);
    V v_arrow_24297 = heff_field(v_e0_241, 2);
    V v_body_24298 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24299 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24295));
    V v_t_24300 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24301 = (g_list_2emap(v_t_24300, v_binders_24296));
    V v_a_24302 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24301; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24301); r_; });
    V v_b_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24297));
    V v_t_24304 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24303));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(v_a_24302, v_t_24304));
    V v_t_24306 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24298));
    V v_t_24310;
    if ((heff_dup(v_t_24306) == NTAG(TAG_True))) {
      heff_drop(v_t_24306);
      V v_t_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      v_t_24310 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24307));
    } else {
      heff_drop(v_t_24306);
      V v_t_24308 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      V v_d_24309 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24308));
      v_t_24310 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24309})));
    }
    V v_t_24311 = (g_std_2edoc_2e_3c_3e(v_t_24305, v_t_24310));
    return (g_std_2edoc_2e_3c_3e(v_t_24299, v_t_24311));
  }
  case TAG_Case: {
    V v_kw_24312 = heff_field(v_e0_241, 0);
    V v_scrut_24313 = heff_field(v_e0_241, 1);
    V v_of2_24314 = heff_field(v_e0_241, 2);
    V v_alts_24315 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24312));
    V v_a_24317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24313}));
    V v_b_24318 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24314));
    V v_t_24319 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24318));
    V v_t_24320 = (g_std_2edoc_2e_3c_3e(v_a_24317, v_t_24319));
    V v_t_24321 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24320));
    V v_t_24322 = (g_std_2edoc_2e_3c_3e(v_a_24316, v_t_24321));
    V v_t_24323 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24315; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24315); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24322, v_t_24323));
  }
  case TAG_EAlt: {
    V v_p_24324 = heff_field(v_e0_241, 0);
    V v_arrow_24325 = heff_field(v_e0_241, 1);
    V v_body_24326 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24327 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24324; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24324); r_; });
    V v_b_24328 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24325));
    V v_t_24329 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24328));
    V v_t_24330 = (g_std_2edoc_2e_3c_3e(v_a_24327, v_t_24329));
    V v_t_24331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24326}));
    return (g_std_2edoc_2e_3c_3e(v_t_24330, v_t_24331));
  }
  case TAG_If: {
    V v_kw_24332 = heff_field(v_e0_241, 0);
    V v_c_24333 = heff_field(v_e0_241, 1);
    V v_th_24334 = heff_field(v_e0_241, 2);
    V v_a_24335 = heff_field(v_e0_241, 3);
    V v_el_24336 = heff_field(v_e0_241, 4);
    V v_b_24337 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24332, v_c_24333, v_th_24334, v_a_24335}));
    V v_t_24339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24336, v_b_24337}));
    V v_t_24340 = (g_std_2edoc_2e_3c_3e(v_t_24338, v_t_24339));
    return (g_std_2edoc_2egroup(v_t_24340));
  }
  case TAG_Do: {
    V v_kw_24341 = heff_field(v_e0_241, 0);
    V v_stmts_24342 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24343 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24341));
    V v_t_24344 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24342; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24342); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
  }
  case TAG_ESBind: {
    V v_x_24345 = heff_field(v_e0_241, 0);
    V v_arrow_24346 = heff_field(v_e0_241, 1);
    V v_e_24347 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24348 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24345));
    V v_b_24349 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24346));
    V v_t_24350 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24349));
    V v_t_24351 = (g_std_2edoc_2e_3c_3e(v_a_24348, v_t_24350));
    V v_t_24352 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24347}));
    return (g_std_2edoc_2e_3c_3e(v_t_24351, v_t_24352));
  }
  case TAG_ELet: {
    V v_kw_24353 = heff_field(v_e0_241, 0);
    V v_p_24354 = heff_field(v_e0_241, 1);
    V v_ann_24355 = heff_field(v_e0_241, 2);
    V v_eq_24356 = heff_field(v_e0_241, 3);
    V v_e_24357 = heff_field(v_e0_241, 4);
    V v_body_24358 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24358)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357});
    }
    case TAG_Just: {
      V v_it1_24359 = heff_field(v_body_24358, 0);
      V v_ru_24body_24358_24Just = heff_take_reuse_n(v_body_24358, 1ULL, 1);
      switch (heff_tag_of(v_it1_24359)) {
      case TAG_MkPair: {
        V v_i_24360 = heff_field(v_it1_24359, 0);
        V v_b_24361 = heff_field(v_it1_24359, 1);
        heff_take_n(v_it1_24359, 3ULL, 2);
        V v_t_24362 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357, v_i_24360, v_b_24361}));
        V v_d_24363 = (g_std_2edoc_2egroup(v_t_24362));
        return heff_tag_at_n(v_ru_24body_24358_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24363})});
      }
      default: return heff_nomatch(v_it1_24359);
      }
    }
    default: return heff_nomatch(v_body_24358);
    }
  }
  case TAG_ELetMut: {
    V v_kw_24368 = heff_field(v_e0_241, 0);
    V v_m_24369 = heff_field(v_e0_241, 1);
    V v_x_24370 = heff_field(v_e0_241, 2);
    V v_ann_24371 = heff_field(v_e0_241, 3);
    V v_eq_24372 = heff_field(v_e0_241, 4);
    V v_e_24373 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24374 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24368));
    V v_a_24375 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24369));
    V v_b_24376 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24370));
    V v_t_24377 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24376));
    V v_t_24378 = (g_std_2edoc_2e_3c_3e(v_a_24375, v_t_24377));
    V v_t_24379 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24378));
    V v_t_24380 = (g_std_2edoc_2e_3c_3e(v_a_24374, v_t_24379));
    V v_a_24388;
    switch (heff_tag_of(v_ann_24371)) {
    case TAG_Nothing: {
      v_a_24388 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24381 = heff_field(v_ann_24371, 0);
      V v_ru_24ann_24371_24Just = heff_take_reuse_n(v_ann_24371, 1ULL, 1);
      switch (heff_tag_of(v_it1_24381)) {
      case TAG_MkPair: {
        V v_cc_24382 = heff_field(v_it1_24381, 0);
        V v_ty_24383 = heff_field(v_it1_24381, 1);
        heff_take_n(v_it1_24381, 3ULL, 2);
        V v_a_24384 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24382));
        V v_b_24385 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24383}));
        V v_t_24386 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24371_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24385));
        V v_t_24387 = (g_std_2edoc_2e_3c_3e(v_a_24384, v_t_24386));
        v_a_24388 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24387));
        break;
      }
      default: heff_nomatch(v_it1_24381);
      }
      break;
    }
    default: heff_nomatch(v_ann_24371);
    }
    V v_b_24389 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24372));
    V v_t_24390 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24389));
    V v_t_24391 = (g_std_2edoc_2e_3c_3e(v_a_24388, v_t_24390));
    V v_t_24392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24373}));
    V v_t_24393 = (g_std_2edoc_2e_3c_3e(v_t_24391, v_t_24392));
    return (g_std_2edoc_2e_3c_3e(v_t_24380, v_t_24393));
  }
  case TAG_EAssign: {
    V v_x_24394 = heff_field(v_e0_241, 0);
    V v_k_24395 = heff_field(v_e0_241, 1);
    V v_e_24396 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24397 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24394));
    V v_b_24398 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24395));
    V v_t_24399 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24398));
    V v_t_24400 = (g_std_2edoc_2e_3c_3e(v_a_24397, v_t_24399));
    V v_t_24401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24396}));
    return (g_std_2edoc_2e_3c_3e(v_t_24400, v_t_24401));
  }
  case TAG_EWhile: {
    V v_kw_24402 = heff_field(v_e0_241, 0);
    V v_c_24403 = heff_field(v_e0_241, 1);
    V v_d_24404 = heff_field(v_e0_241, 2);
    V v_body_24405 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24406 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24402));
    V v_d_24407 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24403}));
    V v_b_24408 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24404));
    V v_t_24409 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24408));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24407})}), v_t_24409));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_t_24414));
    V v_t_24416 = (g_std_2edoc_2e_3c_3e(v_a_24406, v_t_24415));
    V v_t_24417 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24405; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24405); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24416, v_t_24417));
  }
  case TAG_EFor: {
    V v_kw_24418 = heff_field(v_e0_241, 0);
    V v_p_24419 = heff_field(v_e0_241, 1);
    V v_i_24420 = heff_field(v_e0_241, 2);
    V v_c_24421 = heff_field(v_e0_241, 3);
    V v_d_24422 = heff_field(v_e0_241, 4);
    V v_body_24423 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24418));
    V v_a_24425 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24419; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24419); r_; });
    V v_a_24426 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24420));
    V v_d_24427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24421}));
    V v_b_24428 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24422));
    V v_t_24429 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24428));
    V v_t_24434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24427})}), v_t_24429));
    V v_t_24435 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24434));
    V v_t_24436 = (g_std_2edoc_2e_3c_3e(v_a_24426, v_t_24435));
    V v_t_24437 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_t_24436));
    V v_t_24438 = (g_std_2edoc_2e_3c_3e(v_a_24425, v_t_24437));
    V v_t_24439 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24438));
    V v_t_24440 = (g_std_2edoc_2e_3c_3e(v_a_24424, v_t_24439));
    V v_t_24441 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24423; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24423); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24440, v_t_24441));
  }
  case TAG_EJump: {
    V v_kw_24442 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_kw_24442));
  }
  case TAG_EReturn: {
    V v_kw_24443 = heff_field(v_e0_241, 0);
    V v_e_24444 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24445 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24443));
    V v_d_24446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24444}));
    V v_t_24447 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24446})));
    return (g_std_2edoc_2e_3c_3e(v_a_24445, v_t_24447));
  }
  case TAG_ENest: {
    V v_o_24448 = heff_field(v_e0_241, 0);
    V v_arrow_24449 = heff_field(v_e0_241, 1);
    V v_e_24450 = heff_field(v_e0_241, 2);
    V v_c_24451 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24452 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24448));
    V v_a_24453 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24449));
    V v_b_24454 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24450}));
    V v_t_24455 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_b_24454));
    V v_t_24456 = (g_std_2edoc_2e_3c_3e(v_a_24453, v_t_24455));
    V v_t_24457 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24451));
    V v_t_24458 = (g_std_2edoc_2e_3c_3e(v_t_24456, v_t_24457));
    return (g_std_2edoc_2e_3c_3e(v_t_24452, v_t_24458));
  }
  case TAG_IfThen: {
    V v_kw_24459 = heff_field(v_e0_241, 0);
    V v_c_24460 = heff_field(v_e0_241, 1);
    V v_th_24461 = heff_field(v_e0_241, 2);
    V v_a_24462 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24459, v_c_24460, v_th_24461, v_a_24462}));
    return (g_std_2edoc_2egroup(v_t_24463));
  }
  case TAG_ELetCond: {
    V v_kw_24464 = heff_field(v_e0_241, 0);
    V v_p_24465 = heff_field(v_e0_241, 1);
    V v_eq_24466 = heff_field(v_e0_241, 2);
    V v_e_24467 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24468 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24464));
    V v_a_24469 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24465; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24465); r_; });
    V v_b_24470 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24466));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), v_b_24470));
    V v_t_24472 = (g_std_2edoc_2e_3c_3e(v_a_24469, v_t_24471));
    V v_t_24473 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_t_24472));
    V v_t_24474 = (g_std_2edoc_2e_3c_3e(v_a_24468, v_t_24473));
    V v_t_24475 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24467}));
    return (g_std_2edoc_2e_3c_3e(v_t_24474, v_t_24475));
  }
  case TAG_ETry: {
    V v_kw_24476 = heff_field(v_e0_241, 0);
    V v_ty_24477 = heff_field(v_e0_241, 1);
    V v_body_24478 = heff_field(v_e0_241, 2);
    V v_c_24479 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24480 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24476));
    V v_t_24483;
    switch (heff_tag_of(v_ty_24477)) {
    case TAG_Nothing: {
      v_t_24483 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24481 = heff_field(v_ty_24477, 0);
      V v_ru_24ty_24477_24Just = heff_take_reuse_n(v_ty_24477, 1ULL, 1);
      V v_t_24482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24481}));
      v_t_24483 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24477_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_t_24482));
      break;
    }
    default: heff_nomatch(v_ty_24477);
    }
    V v_d_24484 = ({ V a_0 = heff_dup(v_env_240); V a_1 = MK_INT(0LL); V a_2 = v_body_24478; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24478); r_; });
    V v_t_24485 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24479}));
    V v_t_24486 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24485));
    V v_t_24487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24484}), v_t_24486));
    V v_t_24488 = (g_std_2edoc_2e_3c_3e(v_t_24483, v_t_24487));
    V v_d_24489 = (g_std_2edoc_2e_3c_3e(v_t_24480, v_t_24488));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24489})});
  }
  case TAG_ECatch: {
    V v_kw_24494 = heff_field(v_e0_241, 0);
    V v_b_24495 = heff_field(v_e0_241, 1);
    V v_arrow_24496 = heff_field(v_e0_241, 2);
    V v_body_24497 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24498 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24494));
    V v_a_24499 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 2, (V[]){heff_dup(v_env_240), v_b_24495}));
    V v_b_24500 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24496));
    V v_t_24501 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_b_24500));
    V v_t_24502 = (g_std_2edoc_2e_3c_3e(v_a_24499, v_t_24501));
    V v_t_24503 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_t_24502));
    V v_t_24504 = (g_std_2edoc_2e_3c_3e(v_a_24498, v_t_24503));
    V v_d_24505 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24497; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24497); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24504, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24505})));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_env_24506 = args[0];
  V v_e_24507 = args[1];
  V v_t_24508 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24507));
  if ((heff_dup(v_t_24508) == NTAG(TAG_True))) {
    heff_drop(v_t_24508);
    V v_t_24509 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24506, v_e_24507}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_t_24509));
  } else {
    heff_drop(v_t_24508);
    V v_t_24510 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24506, v_e_24507}));
    V v_t_24511 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24510));
    return (g_std_2edoc_2egroup(v_t_24511));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_env_24512 = args[0];
  V v_kw_24513 = args[1];
  V v_p_24514 = args[2];
  V v_ann_24515 = args[3];
  V v_eq_24516 = args[4];
  V v_e_24517 = args[5];
  V v_a_24518 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24512), v_kw_24513));
  V v_b_24519 = ({ V a_0 = heff_dup(v_env_24512); V a_1 = v_p_24514; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24514); r_; });
  V v_t_24520 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24519));
  V v_t_24521 = (g_std_2edoc_2e_3c_3e(v_a_24518, v_t_24520));
  V v_a_24529;
  switch (heff_tag_of(v_ann_24515)) {
  case TAG_Nothing: {
    v_a_24529 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24522 = heff_field(v_ann_24515, 0);
    V v_ru_24ann_24515_24Just = heff_take_reuse_n(v_ann_24515, 1ULL, 1);
    switch (heff_tag_of(v_it1_24522)) {
    case TAG_MkPair: {
      V v_cc_24523 = heff_field(v_it1_24522, 0);
      V v_ty_24524 = heff_field(v_it1_24522, 1);
      heff_take_n(v_it1_24522, 3ULL, 2);
      V v_a_24525 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24512), v_cc_24523));
      V v_b_24526 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24512), v_ty_24524}));
      V v_t_24527 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24515_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_b_24526));
      V v_t_24528 = (g_std_2edoc_2e_3c_3e(v_a_24525, v_t_24527));
      v_a_24529 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24528));
      break;
    }
    default: heff_nomatch(v_it1_24522);
    }
    break;
  }
  default: heff_nomatch(v_ann_24515);
  }
  V v_b_24530 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24512), v_eq_24516));
  V v_t_24531 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_b_24530));
  V v_t_24532 = (g_std_2edoc_2e_3c_3e(v_a_24529, v_t_24531));
  V v_t_24533 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24512, v_e_24517}));
  V v_t_24534 = (g_std_2edoc_2e_3c_3e(v_t_24532, v_t_24533));
  return (g_std_2edoc_2e_3c_3e(v_t_24521, v_t_24534));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_env_24535 = args[0];
  V v_kw_24536 = args[1];
  V v_p_24537 = args[2];
  V v_ann_24538 = args[3];
  V v_eq_24539 = args[4];
  V v_e_24540 = args[5];
  V v_i_24541 = args[6];
  V v_b_24542 = args[7];
  V v_d_24543 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24535), v_kw_24536, v_p_24537, v_ann_24538, v_eq_24539, v_e_24540}));
  V v_t_24544 = heff_dup(heff_rfield(v_i_24541, 6));
  V v_t_24547;
  if ((heff_dup(v_t_24544) == NTAG(TAG_True))) {
    heff_drop(v_t_24544);
    v_t_24547 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24544);
    V v_t_24545 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24542));
    V v_x1_24546 = heff_get_n(v_t_24545, 6, 9);
    if ((heff_dup(v_x1_24546) == NTAG(TAG_True))) {
      heff_drop(v_x1_24546);
      v_t_24547 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24546);
      v_t_24547 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24548 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24535), v_i_24541));
  V v_b_24694;
  switch (heff_tag_of(v_b_24542)) {
  case TAG_Atom: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EParen: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Named: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Tup: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Seg: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Braces: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Update: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EUSet: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_InstB: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EFSet: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Sum: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ECon: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EField: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ENeg: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_App: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Op: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Ops: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Ann: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_BVar: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_BImp: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_BAnn: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Lam: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Case: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EAlt: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_If: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_Do: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ESBind: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24643 = heff_dup(heff_field(v_b_24542, 0));
    V v_p2_24644 = heff_dup(heff_field(v_b_24542, 1));
    V v_ann2_24645 = heff_dup(heff_field(v_b_24542, 2));
    V v_eq2_24646 = heff_dup(heff_field(v_b_24542, 3));
    V v_e2_24647 = heff_dup(heff_field(v_b_24542, 4));
    V v_it6_24648 = heff_dup(heff_field(v_b_24542, 5));
    switch (heff_tag_of(v_it6_24648)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24643);
      heff_drop(v_p2_24644);
      heff_drop(v_ann2_24645);
      heff_drop(v_eq2_24646);
      heff_drop(v_e2_24647);
      v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
      break;
    }
    case TAG_Just: {
      V v_it61_24649 = heff_field(v_it6_24648, 0);
      heff_take_n(v_it6_24648, 1ULL, 1);
      heff_drop_tag(v_b_24542, 6);
      switch (heff_tag_of(v_it61_24649)) {
      case TAG_MkPair: {
        V v_i2_24650 = heff_field(v_it61_24649, 0);
        V v_b2_24651 = heff_field(v_it61_24649, 1);
        heff_take_n(v_it61_24649, 3ULL, 2);
        v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24535, v_kw2_24643, v_p2_24644, v_ann2_24645, v_eq2_24646, v_e2_24647, v_i2_24650, v_b2_24651}));
        break;
      }
      default: heff_nomatch(v_it61_24649);
      }
      break;
    }
    default: heff_nomatch(v_it6_24648);
    }
    break;
  }
  case TAG_ELetMut: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EAssign: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EWhile: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EFor: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EJump: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_EReturn: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ENest: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_IfThen: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ELetCond: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ETry: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  case TAG_ECatch: {
    v_b_24694 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24535, v_b_24542}));
    break;
  }
  default: heff_nomatch(v_b_24542);
  }
  V v_t_24695 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_b_24694));
  V v_t_24696 = (g_std_2edoc_2e_3c_3e(v_a_24548, v_t_24695));
  V v_t_24697 = (g_std_2edoc_2e_3c_3e(v_t_24547, v_t_24696));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24543}), v_t_24697));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_i_24706 = args[0];
  V v_k_24705 = heff_env(self)[0];
  V v_d_24704 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24707 = heff_intSub(v_k_24705, v_i_24706);
  if (heff_intEq_c_lent(v_i_24707, MK_INT(0LL), 2)) {
    heff_drop(v_i_24707);
    return v_d_24704;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24707, v_d_24704});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_k_24705 = args[0];
  V v_d_24704 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 2, (V[]){v_k_24705, v_d_24704})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_env_24698 = args[0];
  V v_kw_24699 = args[1];
  V v_c_24700 = args[2];
  V v_th_24701 = args[3];
  V v_a_24702 = args[4];
  V v_a_24703 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24698), v_kw_24699));
  V v_d_24704 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24698), v_c_24700}));
  V v_t_24709 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){v_d_24704})})));
  V v_t_24710 = (g_std_2edoc_2e_3c_3e(v_a_24703, v_t_24709));
  V v_t_24711 = heff_dup(heff_rfield(v_th_24701, 6));
  V v_t_24714;
  if ((heff_dup(v_t_24711) == NTAG(TAG_True))) {
    heff_drop(v_t_24711);
    v_t_24714 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24711);
    V v_t_24712 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24702));
    V v_x1_24713 = heff_get_n(v_t_24712, 6, 9);
    if ((heff_dup(v_x1_24713) == NTAG(TAG_True))) {
      heff_drop(v_x1_24713);
      v_t_24714 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24713);
      v_t_24714 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24715 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24698), v_th_24701));
  V v_d_24716 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24698, v_a_24702}));
  V v_t_24717 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24716})));
  V v_t_24718 = (g_std_2edoc_2e_3c_3e(v_a_24715, v_t_24717));
  V v_t_24719 = (g_std_2edoc_2e_3c_3e(v_t_24714, v_t_24718));
  V v_t_24720 = (g_std_2edoc_2e_3c_3e(v_t_24710, v_t_24719));
  return (g_std_2edoc_2egroup(v_t_24720));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_env_24721 = args[0];
  V v_el_24722 = args[1];
  V v_b_24723 = args[2];
  switch (heff_tag_of(v_b_24723)) {
  case TAG_Atom: {
    V v_t_24725 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24728;
    if ((heff_dup(v_t_24725) == NTAG(TAG_True))) {
      heff_drop(v_t_24725);
      v_t_24728 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24725);
      V v_t_24726 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24727 = heff_get_n(v_t_24726, 6, 9);
      if ((heff_dup(v_x1_24727) == NTAG(TAG_True))) {
        heff_drop(v_x1_24727);
        v_t_24728 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24727);
        v_t_24728 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24729 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24730 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24731 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24730})));
    V v_t_24732 = (g_std_2edoc_2e_3c_3e(v_a_24729, v_t_24731));
    return (g_std_2edoc_2e_3c_3e(v_t_24728, v_t_24732));
  }
  case TAG_EParen: {
    V v_t_24736 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24739;
    if ((heff_dup(v_t_24736) == NTAG(TAG_True))) {
      heff_drop(v_t_24736);
      v_t_24739 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24736);
      V v_t_24737 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24738 = heff_get_n(v_t_24737, 6, 9);
      if ((heff_dup(v_x1_24738) == NTAG(TAG_True))) {
        heff_drop(v_x1_24738);
        v_t_24739 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24738);
        v_t_24739 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24740 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24741 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24742 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24741})));
    V v_t_24743 = (g_std_2edoc_2e_3c_3e(v_a_24740, v_t_24742));
    return (g_std_2edoc_2e_3c_3e(v_t_24739, v_t_24743));
  }
  case TAG_Named: {
    V v_t_24749 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24752;
    if ((heff_dup(v_t_24749) == NTAG(TAG_True))) {
      heff_drop(v_t_24749);
      v_t_24752 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24749);
      V v_t_24750 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24751 = heff_get_n(v_t_24750, 6, 9);
      if ((heff_dup(v_x1_24751) == NTAG(TAG_True))) {
        heff_drop(v_x1_24751);
        v_t_24752 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24751);
        v_t_24752 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24753 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24754 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24755 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24754})));
    V v_t_24756 = (g_std_2edoc_2e_3c_3e(v_a_24753, v_t_24755));
    return (g_std_2edoc_2e_3c_3e(v_t_24752, v_t_24756));
  }
  case TAG_Tup: {
    V v_t_24761 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24764;
    if ((heff_dup(v_t_24761) == NTAG(TAG_True))) {
      heff_drop(v_t_24761);
      v_t_24764 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24761);
      V v_t_24762 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24763 = heff_get_n(v_t_24762, 6, 9);
      if ((heff_dup(v_x1_24763) == NTAG(TAG_True))) {
        heff_drop(v_x1_24763);
        v_t_24764 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24763);
        v_t_24764 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24765 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24766 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24767 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24766})));
    V v_t_24768 = (g_std_2edoc_2e_3c_3e(v_a_24765, v_t_24767));
    return (g_std_2edoc_2e_3c_3e(v_t_24764, v_t_24768));
  }
  case TAG_Seg: {
    V v_t_24772 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24775;
    if ((heff_dup(v_t_24772) == NTAG(TAG_True))) {
      heff_drop(v_t_24772);
      v_t_24775 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24772);
      V v_t_24773 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24774 = heff_get_n(v_t_24773, 6, 9);
      if ((heff_dup(v_x1_24774) == NTAG(TAG_True))) {
        heff_drop(v_x1_24774);
        v_t_24775 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24774);
        v_t_24775 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24776 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24777 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24778 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24777})));
    V v_t_24779 = (g_std_2edoc_2e_3c_3e(v_a_24776, v_t_24778));
    return (g_std_2edoc_2e_3c_3e(v_t_24775, v_t_24779));
  }
  case TAG_Braces: {
    V v_t_24784 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24787;
    if ((heff_dup(v_t_24784) == NTAG(TAG_True))) {
      heff_drop(v_t_24784);
      v_t_24787 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24784);
      V v_t_24785 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24786 = heff_get_n(v_t_24785, 6, 9);
      if ((heff_dup(v_x1_24786) == NTAG(TAG_True))) {
        heff_drop(v_x1_24786);
        v_t_24787 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24786);
        v_t_24787 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24788 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24789 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24790 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24789})));
    V v_t_24791 = (g_std_2edoc_2e_3c_3e(v_a_24788, v_t_24790));
    return (g_std_2edoc_2e_3c_3e(v_t_24787, v_t_24791));
  }
  case TAG_Update: {
    V v_t_24798 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24801;
    if ((heff_dup(v_t_24798) == NTAG(TAG_True))) {
      heff_drop(v_t_24798);
      v_t_24801 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24798);
      V v_t_24799 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24800 = heff_get_n(v_t_24799, 6, 9);
      if ((heff_dup(v_x1_24800) == NTAG(TAG_True))) {
        heff_drop(v_x1_24800);
        v_t_24801 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24800);
        v_t_24801 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24802 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24803 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24804 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24803})));
    V v_t_24805 = (g_std_2edoc_2e_3c_3e(v_a_24802, v_t_24804));
    return (g_std_2edoc_2e_3c_3e(v_t_24801, v_t_24805));
  }
  case TAG_EUSet: {
    V v_t_24809 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24812;
    if ((heff_dup(v_t_24809) == NTAG(TAG_True))) {
      heff_drop(v_t_24809);
      v_t_24812 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24809);
      V v_t_24810 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24811 = heff_get_n(v_t_24810, 6, 9);
      if ((heff_dup(v_x1_24811) == NTAG(TAG_True))) {
        heff_drop(v_x1_24811);
        v_t_24812 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24811);
        v_t_24812 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24813 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24814 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24815 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24814})));
    V v_t_24816 = (g_std_2edoc_2e_3c_3e(v_a_24813, v_t_24815));
    return (g_std_2edoc_2e_3c_3e(v_t_24812, v_t_24816));
  }
  case TAG_InstB: {
    V v_t_24822 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24825;
    if ((heff_dup(v_t_24822) == NTAG(TAG_True))) {
      heff_drop(v_t_24822);
      v_t_24825 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24822);
      V v_t_24823 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24824 = heff_get_n(v_t_24823, 6, 9);
      if ((heff_dup(v_x1_24824) == NTAG(TAG_True))) {
        heff_drop(v_x1_24824);
        v_t_24825 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24824);
        v_t_24825 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24826 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24827 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24828 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24827})));
    V v_t_24829 = (g_std_2edoc_2e_3c_3e(v_a_24826, v_t_24828));
    return (g_std_2edoc_2e_3c_3e(v_t_24825, v_t_24829));
  }
  case TAG_EFSet: {
    V v_t_24833 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24836;
    if ((heff_dup(v_t_24833) == NTAG(TAG_True))) {
      heff_drop(v_t_24833);
      v_t_24836 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24833);
      V v_t_24834 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24835 = heff_get_n(v_t_24834, 6, 9);
      if ((heff_dup(v_x1_24835) == NTAG(TAG_True))) {
        heff_drop(v_x1_24835);
        v_t_24836 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24835);
        v_t_24836 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24837 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24838 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24839 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24838})));
    V v_t_24840 = (g_std_2edoc_2e_3c_3e(v_a_24837, v_t_24839));
    return (g_std_2edoc_2e_3c_3e(v_t_24836, v_t_24840));
  }
  case TAG_EFDefault: {
    V v_t_24844 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24847;
    if ((heff_dup(v_t_24844) == NTAG(TAG_True))) {
      heff_drop(v_t_24844);
      v_t_24847 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24844);
      V v_t_24845 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24846 = heff_get_n(v_t_24845, 6, 9);
      if ((heff_dup(v_x1_24846) == NTAG(TAG_True))) {
        heff_drop(v_x1_24846);
        v_t_24847 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24846);
        v_t_24847 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24848 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24849 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24850 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24849})));
    V v_t_24851 = (g_std_2edoc_2e_3c_3e(v_a_24848, v_t_24850));
    return (g_std_2edoc_2e_3c_3e(v_t_24847, v_t_24851));
  }
  case TAG_Sum: {
    V v_t_24857 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24860;
    if ((heff_dup(v_t_24857) == NTAG(TAG_True))) {
      heff_drop(v_t_24857);
      v_t_24860 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24857);
      V v_t_24858 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24859 = heff_get_n(v_t_24858, 6, 9);
      if ((heff_dup(v_x1_24859) == NTAG(TAG_True))) {
        heff_drop(v_x1_24859);
        v_t_24860 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24859);
        v_t_24860 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24861 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24862 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24863 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24862})));
    V v_t_24864 = (g_std_2edoc_2e_3c_3e(v_a_24861, v_t_24863));
    return (g_std_2edoc_2e_3c_3e(v_t_24860, v_t_24864));
  }
  case TAG_ECon: {
    V v_t_24867 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24870;
    if ((heff_dup(v_t_24867) == NTAG(TAG_True))) {
      heff_drop(v_t_24867);
      v_t_24870 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24867);
      V v_t_24868 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24869 = heff_get_n(v_t_24868, 6, 9);
      if ((heff_dup(v_x1_24869) == NTAG(TAG_True))) {
        heff_drop(v_x1_24869);
        v_t_24870 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24869);
        v_t_24870 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24871 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24872 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24873 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24872})));
    V v_t_24874 = (g_std_2edoc_2e_3c_3e(v_a_24871, v_t_24873));
    return (g_std_2edoc_2e_3c_3e(v_t_24870, v_t_24874));
  }
  case TAG_EField: {
    V v_t_24877 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24880;
    if ((heff_dup(v_t_24877) == NTAG(TAG_True))) {
      heff_drop(v_t_24877);
      v_t_24880 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24877);
      V v_t_24878 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24879 = heff_get_n(v_t_24878, 6, 9);
      if ((heff_dup(v_x1_24879) == NTAG(TAG_True))) {
        heff_drop(v_x1_24879);
        v_t_24880 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24879);
        v_t_24880 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24881 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24882 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24883 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24882})));
    V v_t_24884 = (g_std_2edoc_2e_3c_3e(v_a_24881, v_t_24883));
    return (g_std_2edoc_2e_3c_3e(v_t_24880, v_t_24884));
  }
  case TAG_ENeg: {
    V v_t_24887 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24890;
    if ((heff_dup(v_t_24887) == NTAG(TAG_True))) {
      heff_drop(v_t_24887);
      v_t_24890 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24887);
      V v_t_24888 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24889 = heff_get_n(v_t_24888, 6, 9);
      if ((heff_dup(v_x1_24889) == NTAG(TAG_True))) {
        heff_drop(v_x1_24889);
        v_t_24890 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24889);
        v_t_24890 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24891 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24892 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24893 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24892})));
    V v_t_24894 = (g_std_2edoc_2e_3c_3e(v_a_24891, v_t_24893));
    return (g_std_2edoc_2e_3c_3e(v_t_24890, v_t_24894));
  }
  case TAG_App: {
    V v_t_24897 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24900;
    if ((heff_dup(v_t_24897) == NTAG(TAG_True))) {
      heff_drop(v_t_24897);
      v_t_24900 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24897);
      V v_t_24898 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24899 = heff_get_n(v_t_24898, 6, 9);
      if ((heff_dup(v_x1_24899) == NTAG(TAG_True))) {
        heff_drop(v_x1_24899);
        v_t_24900 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24899);
        v_t_24900 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24901 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24902 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24903 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24902})));
    V v_t_24904 = (g_std_2edoc_2e_3c_3e(v_a_24901, v_t_24903));
    return (g_std_2edoc_2e_3c_3e(v_t_24900, v_t_24904));
  }
  case TAG_Op: {
    V v_t_24908 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24911;
    if ((heff_dup(v_t_24908) == NTAG(TAG_True))) {
      heff_drop(v_t_24908);
      v_t_24911 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24908);
      V v_t_24909 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24910 = heff_get_n(v_t_24909, 6, 9);
      if ((heff_dup(v_x1_24910) == NTAG(TAG_True))) {
        heff_drop(v_x1_24910);
        v_t_24911 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24910);
        v_t_24911 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24912 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24913 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24914 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24913})));
    V v_t_24915 = (g_std_2edoc_2e_3c_3e(v_a_24912, v_t_24914));
    return (g_std_2edoc_2e_3c_3e(v_t_24911, v_t_24915));
  }
  case TAG_Ops: {
    V v_t_24918 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24921;
    if ((heff_dup(v_t_24918) == NTAG(TAG_True))) {
      heff_drop(v_t_24918);
      v_t_24921 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24918);
      V v_t_24919 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24920 = heff_get_n(v_t_24919, 6, 9);
      if ((heff_dup(v_x1_24920) == NTAG(TAG_True))) {
        heff_drop(v_x1_24920);
        v_t_24921 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24920);
        v_t_24921 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24922 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24923 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24924 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24923})));
    V v_t_24925 = (g_std_2edoc_2e_3c_3e(v_a_24922, v_t_24924));
    return (g_std_2edoc_2e_3c_3e(v_t_24921, v_t_24925));
  }
  case TAG_OpRhs: {
    V v_t_24928 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24931;
    if ((heff_dup(v_t_24928) == NTAG(TAG_True))) {
      heff_drop(v_t_24928);
      v_t_24931 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24928);
      V v_t_24929 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24930 = heff_get_n(v_t_24929, 6, 9);
      if ((heff_dup(v_x1_24930) == NTAG(TAG_True))) {
        heff_drop(v_x1_24930);
        v_t_24931 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24930);
        v_t_24931 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24932 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24933 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24934 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24933})));
    V v_t_24935 = (g_std_2edoc_2e_3c_3e(v_a_24932, v_t_24934));
    return (g_std_2edoc_2e_3c_3e(v_t_24931, v_t_24935));
  }
  case TAG_Ann: {
    V v_t_24939 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24942;
    if ((heff_dup(v_t_24939) == NTAG(TAG_True))) {
      heff_drop(v_t_24939);
      v_t_24942 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24939);
      V v_t_24940 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24941 = heff_get_n(v_t_24940, 6, 9);
      if ((heff_dup(v_x1_24941) == NTAG(TAG_True))) {
        heff_drop(v_x1_24941);
        v_t_24942 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24941);
        v_t_24942 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24943 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24944 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24945 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24944})));
    V v_t_24946 = (g_std_2edoc_2e_3c_3e(v_a_24943, v_t_24945));
    return (g_std_2edoc_2e_3c_3e(v_t_24942, v_t_24946));
  }
  case TAG_BVar: {
    V v_t_24948 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24951;
    if ((heff_dup(v_t_24948) == NTAG(TAG_True))) {
      heff_drop(v_t_24948);
      v_t_24951 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24948);
      V v_t_24949 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24950 = heff_get_n(v_t_24949, 6, 9);
      if ((heff_dup(v_x1_24950) == NTAG(TAG_True))) {
        heff_drop(v_x1_24950);
        v_t_24951 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24950);
        v_t_24951 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24952 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24953 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24954 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24953})));
    V v_t_24955 = (g_std_2edoc_2e_3c_3e(v_a_24952, v_t_24954));
    return (g_std_2edoc_2e_3c_3e(v_t_24951, v_t_24955));
  }
  case TAG_BImp: {
    V v_t_24959 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24962;
    if ((heff_dup(v_t_24959) == NTAG(TAG_True))) {
      heff_drop(v_t_24959);
      v_t_24962 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24959);
      V v_t_24960 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24961 = heff_get_n(v_t_24960, 6, 9);
      if ((heff_dup(v_x1_24961) == NTAG(TAG_True))) {
        heff_drop(v_x1_24961);
        v_t_24962 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24961);
        v_t_24962 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24963 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24964 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24965 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24964})));
    V v_t_24966 = (g_std_2edoc_2e_3c_3e(v_a_24963, v_t_24965));
    return (g_std_2edoc_2e_3c_3e(v_t_24962, v_t_24966));
  }
  case TAG_BAnn: {
    V v_t_24972 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24975;
    if ((heff_dup(v_t_24972) == NTAG(TAG_True))) {
      heff_drop(v_t_24972);
      v_t_24975 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24972);
      V v_t_24973 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24974 = heff_get_n(v_t_24973, 6, 9);
      if ((heff_dup(v_x1_24974) == NTAG(TAG_True))) {
        heff_drop(v_x1_24974);
        v_t_24975 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24974);
        v_t_24975 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24976 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24978 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24977})));
    V v_t_24979 = (g_std_2edoc_2e_3c_3e(v_a_24976, v_t_24978));
    return (g_std_2edoc_2e_3c_3e(v_t_24975, v_t_24979));
  }
  case TAG_Lam: {
    V v_t_24984 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24987;
    if ((heff_dup(v_t_24984) == NTAG(TAG_True))) {
      heff_drop(v_t_24984);
      v_t_24987 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24984);
      V v_t_24985 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24986 = heff_get_n(v_t_24985, 6, 9);
      if ((heff_dup(v_x1_24986) == NTAG(TAG_True))) {
        heff_drop(v_x1_24986);
        v_t_24987 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24986);
        v_t_24987 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24988 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_24989 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_24990 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24989})));
    V v_t_24991 = (g_std_2edoc_2e_3c_3e(v_a_24988, v_t_24990));
    return (g_std_2edoc_2e_3c_3e(v_t_24987, v_t_24991));
  }
  case TAG_Case: {
    V v_t_24996 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_24999;
    if ((heff_dup(v_t_24996) == NTAG(TAG_True))) {
      heff_drop(v_t_24996);
      v_t_24999 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24996);
      V v_t_24997 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_24998 = heff_get_n(v_t_24997, 6, 9);
      if ((heff_dup(v_x1_24998) == NTAG(TAG_True))) {
        heff_drop(v_x1_24998);
        v_t_24999 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24998);
        v_t_24999 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241000 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241001 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241002 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241001})));
    V v_t_241003 = (g_std_2edoc_2e_3c_3e(v_a_241000, v_t_241002));
    return (g_std_2edoc_2e_3c_3e(v_t_24999, v_t_241003));
  }
  case TAG_EAlt: {
    V v_t_241007 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241010;
    if ((heff_dup(v_t_241007) == NTAG(TAG_True))) {
      heff_drop(v_t_241007);
      v_t_241010 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241007);
      V v_t_241008 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241009 = heff_get_n(v_t_241008, 6, 9);
      if ((heff_dup(v_x1_241009) == NTAG(TAG_True))) {
        heff_drop(v_x1_241009);
        v_t_241010 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241009);
        v_t_241010 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241011 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241012 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241013 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241012})));
    V v_t_241014 = (g_std_2edoc_2e_3c_3e(v_a_241011, v_t_241013));
    return (g_std_2edoc_2e_3c_3e(v_t_241010, v_t_241014));
  }
  case TAG_If: {
    V v_kw_241015 = heff_dup(heff_field(v_b_24723, 0));
    V v_c_241016 = heff_dup(heff_field(v_b_24723, 1));
    V v_th_241017 = heff_dup(heff_field(v_b_24723, 2));
    V v_a_241018 = heff_dup(heff_field(v_b_24723, 3));
    V v_el2_241019 = heff_dup(heff_field(v_b_24723, 4));
    V v_b2_241020 = heff_dup(heff_field(v_b_24723, 5));
    V v_t_241021 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241024;
    if ((heff_dup(v_t_241021) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24723, 6);
      heff_drop(v_t_241021);
      v_t_241024 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241021);
      V v_t_241022 = ({ V a_0 = v_b_24723; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24723, 6); r_; });
      V v_x1_241023 = heff_get_n(v_t_241022, 6, 9);
      if ((heff_dup(v_x1_241023) == NTAG(TAG_True))) {
        heff_drop(v_x1_241023);
        v_t_241024 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241023);
        v_t_241024 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241025 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_b_241026 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24721), v_kw_241015, v_c_241016, v_th_241017, v_a_241018}));
    V v_t_241027 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241026));
    V v_t_241028 = (g_std_2edoc_2e_3c_3e(v_a_241025, v_t_241027));
    V v_t_241029 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24721, v_el2_241019, v_b2_241020}));
    V v_t_241030 = (g_std_2edoc_2e_3c_3e(v_t_241028, v_t_241029));
    return (g_std_2edoc_2e_3c_3e(v_t_241024, v_t_241030));
  }
  case TAG_Do: {
    V v_t_241033 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241036;
    if ((heff_dup(v_t_241033) == NTAG(TAG_True))) {
      heff_drop(v_t_241033);
      v_t_241036 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241033);
      V v_t_241034 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241035 = heff_get_n(v_t_241034, 6, 9);
      if ((heff_dup(v_x1_241035) == NTAG(TAG_True))) {
        heff_drop(v_x1_241035);
        v_t_241036 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241035);
        v_t_241036 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241037 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241038 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241039 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241038})));
    V v_t_241040 = (g_std_2edoc_2e_3c_3e(v_a_241037, v_t_241039));
    return (g_std_2edoc_2e_3c_3e(v_t_241036, v_t_241040));
  }
  case TAG_ESBind: {
    V v_t_241044 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241047;
    if ((heff_dup(v_t_241044) == NTAG(TAG_True))) {
      heff_drop(v_t_241044);
      v_t_241047 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241044);
      V v_t_241045 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241046 = heff_get_n(v_t_241045, 6, 9);
      if ((heff_dup(v_x1_241046) == NTAG(TAG_True))) {
        heff_drop(v_x1_241046);
        v_t_241047 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241046);
        v_t_241047 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241048 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241049 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241050 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241049})));
    V v_t_241051 = (g_std_2edoc_2e_3c_3e(v_a_241048, v_t_241050));
    return (g_std_2edoc_2e_3c_3e(v_t_241047, v_t_241051));
  }
  case TAG_ELet: {
    V v_t_241058 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241061;
    if ((heff_dup(v_t_241058) == NTAG(TAG_True))) {
      heff_drop(v_t_241058);
      v_t_241061 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241058);
      V v_t_241059 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241060 = heff_get_n(v_t_241059, 6, 9);
      if ((heff_dup(v_x1_241060) == NTAG(TAG_True))) {
        heff_drop(v_x1_241060);
        v_t_241061 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241060);
        v_t_241061 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241062 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241063 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241064 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241063})));
    V v_t_241065 = (g_std_2edoc_2e_3c_3e(v_a_241062, v_t_241064));
    return (g_std_2edoc_2e_3c_3e(v_t_241061, v_t_241065));
  }
  case TAG_ELetMut: {
    V v_t_241072 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241075;
    if ((heff_dup(v_t_241072) == NTAG(TAG_True))) {
      heff_drop(v_t_241072);
      v_t_241075 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241072);
      V v_t_241073 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241074 = heff_get_n(v_t_241073, 6, 9);
      if ((heff_dup(v_x1_241074) == NTAG(TAG_True))) {
        heff_drop(v_x1_241074);
        v_t_241075 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241074);
        v_t_241075 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241076 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241077 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241078 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241077})));
    V v_t_241079 = (g_std_2edoc_2e_3c_3e(v_a_241076, v_t_241078));
    return (g_std_2edoc_2e_3c_3e(v_t_241075, v_t_241079));
  }
  case TAG_EAssign: {
    V v_t_241083 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241086;
    if ((heff_dup(v_t_241083) == NTAG(TAG_True))) {
      heff_drop(v_t_241083);
      v_t_241086 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241083);
      V v_t_241084 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241085 = heff_get_n(v_t_241084, 6, 9);
      if ((heff_dup(v_x1_241085) == NTAG(TAG_True))) {
        heff_drop(v_x1_241085);
        v_t_241086 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241085);
        v_t_241086 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241087 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241088 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241089 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241088})));
    V v_t_241090 = (g_std_2edoc_2e_3c_3e(v_a_241087, v_t_241089));
    return (g_std_2edoc_2e_3c_3e(v_t_241086, v_t_241090));
  }
  case TAG_EWhile: {
    V v_t_241095 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241098;
    if ((heff_dup(v_t_241095) == NTAG(TAG_True))) {
      heff_drop(v_t_241095);
      v_t_241098 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241095);
      V v_t_241096 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241097 = heff_get_n(v_t_241096, 6, 9);
      if ((heff_dup(v_x1_241097) == NTAG(TAG_True))) {
        heff_drop(v_x1_241097);
        v_t_241098 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241097);
        v_t_241098 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241099 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241100 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241101 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241100})));
    V v_t_241102 = (g_std_2edoc_2e_3c_3e(v_a_241099, v_t_241101));
    return (g_std_2edoc_2e_3c_3e(v_t_241098, v_t_241102));
  }
  case TAG_EFor: {
    V v_t_241109 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241112;
    if ((heff_dup(v_t_241109) == NTAG(TAG_True))) {
      heff_drop(v_t_241109);
      v_t_241112 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241109);
      V v_t_241110 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241111 = heff_get_n(v_t_241110, 6, 9);
      if ((heff_dup(v_x1_241111) == NTAG(TAG_True))) {
        heff_drop(v_x1_241111);
        v_t_241112 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241111);
        v_t_241112 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241113 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241114})));
    V v_t_241116 = (g_std_2edoc_2e_3c_3e(v_a_241113, v_t_241115));
    return (g_std_2edoc_2e_3c_3e(v_t_241112, v_t_241116));
  }
  case TAG_EJump: {
    V v_t_241118 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241121;
    if ((heff_dup(v_t_241118) == NTAG(TAG_True))) {
      heff_drop(v_t_241118);
      v_t_241121 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241118);
      V v_t_241119 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241120 = heff_get_n(v_t_241119, 6, 9);
      if ((heff_dup(v_x1_241120) == NTAG(TAG_True))) {
        heff_drop(v_x1_241120);
        v_t_241121 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241120);
        v_t_241121 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241122 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241123 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241124 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241123})));
    V v_t_241125 = (g_std_2edoc_2e_3c_3e(v_a_241122, v_t_241124));
    return (g_std_2edoc_2e_3c_3e(v_t_241121, v_t_241125));
  }
  case TAG_EReturn: {
    V v_t_241128 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241131;
    if ((heff_dup(v_t_241128) == NTAG(TAG_True))) {
      heff_drop(v_t_241128);
      v_t_241131 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241128);
      V v_t_241129 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241130 = heff_get_n(v_t_241129, 6, 9);
      if ((heff_dup(v_x1_241130) == NTAG(TAG_True))) {
        heff_drop(v_x1_241130);
        v_t_241131 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241130);
        v_t_241131 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241132 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241134 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241133})));
    V v_t_241135 = (g_std_2edoc_2e_3c_3e(v_a_241132, v_t_241134));
    return (g_std_2edoc_2e_3c_3e(v_t_241131, v_t_241135));
  }
  case TAG_ENest: {
    V v_t_241140 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241143;
    if ((heff_dup(v_t_241140) == NTAG(TAG_True))) {
      heff_drop(v_t_241140);
      v_t_241143 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241140);
      V v_t_241141 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241142 = heff_get_n(v_t_241141, 6, 9);
      if ((heff_dup(v_x1_241142) == NTAG(TAG_True))) {
        heff_drop(v_x1_241142);
        v_t_241143 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241142);
        v_t_241143 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241144 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241145 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241146 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241145})));
    V v_t_241147 = (g_std_2edoc_2e_3c_3e(v_a_241144, v_t_241146));
    return (g_std_2edoc_2e_3c_3e(v_t_241143, v_t_241147));
  }
  case TAG_IfThen: {
    V v_t_241152 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241155;
    if ((heff_dup(v_t_241152) == NTAG(TAG_True))) {
      heff_drop(v_t_241152);
      v_t_241155 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241152);
      V v_t_241153 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241154 = heff_get_n(v_t_241153, 6, 9);
      if ((heff_dup(v_x1_241154) == NTAG(TAG_True))) {
        heff_drop(v_x1_241154);
        v_t_241155 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241154);
        v_t_241155 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241156 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241158 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241157})));
    V v_t_241159 = (g_std_2edoc_2e_3c_3e(v_a_241156, v_t_241158));
    return (g_std_2edoc_2e_3c_3e(v_t_241155, v_t_241159));
  }
  case TAG_ELetCond: {
    V v_t_241164 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241167;
    if ((heff_dup(v_t_241164) == NTAG(TAG_True))) {
      heff_drop(v_t_241164);
      v_t_241167 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241164);
      V v_t_241165 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241166 = heff_get_n(v_t_241165, 6, 9);
      if ((heff_dup(v_x1_241166) == NTAG(TAG_True))) {
        heff_drop(v_x1_241166);
        v_t_241167 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241166);
        v_t_241167 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241168 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241169 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241170 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241169})));
    V v_t_241171 = (g_std_2edoc_2e_3c_3e(v_a_241168, v_t_241170));
    return (g_std_2edoc_2e_3c_3e(v_t_241167, v_t_241171));
  }
  case TAG_ETry: {
    V v_t_241176 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241179;
    if ((heff_dup(v_t_241176) == NTAG(TAG_True))) {
      heff_drop(v_t_241176);
      v_t_241179 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241176);
      V v_t_241177 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241178 = heff_get_n(v_t_241177, 6, 9);
      if ((heff_dup(v_x1_241178) == NTAG(TAG_True))) {
        heff_drop(v_x1_241178);
        v_t_241179 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241178);
        v_t_241179 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241180 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241181 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241182 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241181})));
    V v_t_241183 = (g_std_2edoc_2e_3c_3e(v_a_241180, v_t_241182));
    return (g_std_2edoc_2e_3c_3e(v_t_241179, v_t_241183));
  }
  case TAG_ECatch: {
    V v_t_241188 = heff_dup(heff_rfield(v_el_24722, 6));
    V v_t_241191;
    if ((heff_dup(v_t_241188) == NTAG(TAG_True))) {
      heff_drop(v_t_241188);
      v_t_241191 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241188);
      V v_t_241189 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24723));
      V v_x1_241190 = heff_get_n(v_t_241189, 6, 9);
      if ((heff_dup(v_x1_241190) == NTAG(TAG_True))) {
        heff_drop(v_x1_241190);
        v_t_241191 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241190);
        v_t_241191 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241192 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24721), v_el_24722));
    V v_d_241193 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24721, v_b_24723}));
    V v_t_241194 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241193})));
    V v_t_241195 = (g_std_2edoc_2e_3c_3e(v_a_241192, v_t_241194));
    return (g_std_2edoc_2e_3c_3e(v_t_241191, v_t_241195));
  }
  default: return heff_nomatch(v_b_24723);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_241207 = args[0];
  V v_one_241206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241208 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241207));
  V v_x1_241209 = heff_get_n(v_t_241208, 6, 9);
  V v_t_241210;
  if ((heff_dup(v_x1_241209) == NTAG(TAG_True))) {
    heff_drop(v_x1_241209);
    v_t_241210 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241209);
    v_t_241210 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241211 = heff_tr(heff_call(v_one_241206, 1, (V[]){v_a_241207}));
  return (g_std_2edoc_2e_3c_3e(v_t_241210, v_t_241211));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_241219 = args[0];
  V v_one_241218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241220 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241219));
  V v_x1_241221 = heff_get_n(v_t_241220, 6, 9);
  V v_t_241222;
  if ((heff_dup(v_x1_241221) == NTAG(TAG_True))) {
    heff_drop(v_x1_241221);
    v_t_241222 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241221);
    v_t_241222 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241223 = heff_tr(heff_call(v_one_241218, 1, (V[]){v_a_241219}));
  return (g_std_2edoc_2e_3c_3e(v_t_241222, v_t_241223));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241232 = args[0];
  V v_one_241231 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241233 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241232));
  V v_x1_241234 = heff_get_n(v_t_241233, 6, 9);
  V v_t_241235;
  if ((heff_dup(v_x1_241234) == NTAG(TAG_True))) {
    heff_drop(v_x1_241234);
    v_t_241235 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241234);
    v_t_241235 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241236 = heff_tr(heff_call(v_one_241231, 1, (V[]){v_a_241232}));
  return (g_std_2edoc_2e_3c_3e(v_t_241235, v_t_241236));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241248 = args[0];
  V v_one_241247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241249 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241248));
  V v_x1_241250 = heff_get_n(v_t_241249, 6, 9);
  V v_t_241251;
  if ((heff_dup(v_x1_241250) == NTAG(TAG_True))) {
    heff_drop(v_x1_241250);
    v_t_241251 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241250);
    v_t_241251 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241252 = heff_tr(heff_call(v_one_241247, 1, (V[]){v_a_241248}));
  return (g_std_2edoc_2e_3c_3e(v_t_241251, v_t_241252));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241263 = args[0];
  V v_one_241262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241264 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241263));
  V v_x1_241265 = heff_get_n(v_t_241264, 6, 9);
  V v_t_241266;
  if ((heff_dup(v_x1_241265) == NTAG(TAG_True))) {
    heff_drop(v_x1_241265);
    v_t_241266 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241265);
    v_t_241266 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241267 = heff_tr(heff_call(v_one_241262, 1, (V[]){v_a_241263}));
  return (g_std_2edoc_2e_3c_3e(v_t_241266, v_t_241267));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241275 = args[0];
  V v_one_241274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241276 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241275));
  V v_x1_241277 = heff_get_n(v_t_241276, 6, 9);
  V v_t_241278;
  if ((heff_dup(v_x1_241277) == NTAG(TAG_True))) {
    heff_drop(v_x1_241277);
    v_t_241278 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241277);
    v_t_241278 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241279 = heff_tr(heff_call(v_one_241274, 1, (V[]){v_a_241275}));
  return (g_std_2edoc_2e_3c_3e(v_t_241278, v_t_241279));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241289 = args[0];
  V v_one_241288 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241290 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241289));
  V v_x1_241291 = heff_get_n(v_t_241290, 6, 9);
  V v_t_241292;
  if ((heff_dup(v_x1_241291) == NTAG(TAG_True))) {
    heff_drop(v_x1_241291);
    v_t_241292 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241291);
    v_t_241292 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241293 = heff_tr(heff_call(v_one_241288, 1, (V[]){v_a_241289}));
  return (g_std_2edoc_2e_3c_3e(v_t_241292, v_t_241293));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241301 = args[0];
  V v_one_241300 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241302 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241301));
  V v_x1_241303 = heff_get_n(v_t_241302, 6, 9);
  V v_t_241304;
  if ((heff_dup(v_x1_241303) == NTAG(TAG_True))) {
    heff_drop(v_x1_241303);
    v_t_241304 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241303);
    v_t_241304 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241305 = heff_tr(heff_call(v_one_241300, 1, (V[]){v_a_241301}));
  return (g_std_2edoc_2e_3c_3e(v_t_241304, v_t_241305));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241314 = args[0];
  V v_one_241313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241315 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241314));
  V v_x1_241316 = heff_get_n(v_t_241315, 6, 9);
  V v_t_241317;
  if ((heff_dup(v_x1_241316) == NTAG(TAG_True))) {
    heff_drop(v_x1_241316);
    v_t_241317 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241316);
    v_t_241317 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241318 = heff_tr(heff_call(v_one_241313, 1, (V[]){v_a_241314}));
  return (g_std_2edoc_2e_3c_3e(v_t_241317, v_t_241318));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241326 = args[0];
  V v_one_241325 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241327 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241326));
  V v_x1_241328 = heff_get_n(v_t_241327, 6, 9);
  V v_t_241329;
  if ((heff_dup(v_x1_241328) == NTAG(TAG_True))) {
    heff_drop(v_x1_241328);
    v_t_241329 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241328);
    v_t_241329 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241330 = heff_tr(heff_call(v_one_241325, 1, (V[]){v_a_241326}));
  return (g_std_2edoc_2e_3c_3e(v_t_241329, v_t_241330));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241340 = args[0];
  V v_one_241339 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241341 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241340));
  V v_x1_241342 = heff_get_n(v_t_241341, 6, 9);
  V v_t_241343;
  if ((heff_dup(v_x1_241342) == NTAG(TAG_True))) {
    heff_drop(v_x1_241342);
    v_t_241343 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241342);
    v_t_241343 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241344 = heff_tr(heff_call(v_one_241339, 1, (V[]){v_a_241340}));
  return (g_std_2edoc_2e_3c_3e(v_t_241343, v_t_241344));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241352 = args[0];
  V v_one_241351 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241353 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241352));
  V v_x1_241354 = heff_get_n(v_t_241353, 6, 9);
  V v_t_241355;
  if ((heff_dup(v_x1_241354) == NTAG(TAG_True))) {
    heff_drop(v_x1_241354);
    v_t_241355 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241354);
    v_t_241355 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241356 = heff_tr(heff_call(v_one_241351, 1, (V[]){v_a_241352}));
  return (g_std_2edoc_2e_3c_3e(v_t_241355, v_t_241356));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241368 = args[0];
  V v_one_241367 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241369 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241368));
  V v_x1_241370 = heff_get_n(v_t_241369, 6, 9);
  V v_t_241371;
  if ((heff_dup(v_x1_241370) == NTAG(TAG_True))) {
    heff_drop(v_x1_241370);
    v_t_241371 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241370);
    v_t_241371 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241372 = heff_tr(heff_call(v_one_241367, 1, (V[]){v_a_241368}));
  return (g_std_2edoc_2e_3c_3e(v_t_241371, v_t_241372));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241380 = args[0];
  V v_one_241379 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241381 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241380));
  V v_x1_241382 = heff_get_n(v_t_241381, 6, 9);
  V v_t_241383;
  if ((heff_dup(v_x1_241382) == NTAG(TAG_True))) {
    heff_drop(v_x1_241382);
    v_t_241383 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241382);
    v_t_241383 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241384 = heff_tr(heff_call(v_one_241379, 1, (V[]){v_a_241380}));
  return (g_std_2edoc_2e_3c_3e(v_t_241383, v_t_241384));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241393 = args[0];
  V v_one_241392 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241394 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241393));
  V v_x1_241395 = heff_get_n(v_t_241394, 6, 9);
  V v_t_241396;
  if ((heff_dup(v_x1_241395) == NTAG(TAG_True))) {
    heff_drop(v_x1_241395);
    v_t_241396 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241395);
    v_t_241396 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241397 = heff_tr(heff_call(v_one_241392, 1, (V[]){v_a_241393}));
  return (g_std_2edoc_2e_3c_3e(v_t_241396, v_t_241397));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241405 = args[0];
  V v_one_241404 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241406 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241405));
  V v_x1_241407 = heff_get_n(v_t_241406, 6, 9);
  V v_t_241408;
  if ((heff_dup(v_x1_241407) == NTAG(TAG_True))) {
    heff_drop(v_x1_241407);
    v_t_241408 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241407);
    v_t_241408 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241409 = heff_tr(heff_call(v_one_241404, 1, (V[]){v_a_241405}));
  return (g_std_2edoc_2e_3c_3e(v_t_241408, v_t_241409));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241420 = args[0];
  V v_one_241419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241421 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241420));
  V v_x1_241422 = heff_get_n(v_t_241421, 6, 9);
  V v_t_241423;
  if ((heff_dup(v_x1_241422) == NTAG(TAG_True))) {
    heff_drop(v_x1_241422);
    v_t_241423 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241422);
    v_t_241423 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241424 = heff_tr(heff_call(v_one_241419, 1, (V[]){v_a_241420}));
  return (g_std_2edoc_2e_3c_3e(v_t_241423, v_t_241424));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241432 = args[0];
  V v_one_241431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241433 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241432));
  V v_x1_241434 = heff_get_n(v_t_241433, 6, 9);
  V v_t_241435;
  if ((heff_dup(v_x1_241434) == NTAG(TAG_True))) {
    heff_drop(v_x1_241434);
    v_t_241435 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241434);
    v_t_241435 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241436 = heff_tr(heff_call(v_one_241431, 1, (V[]){v_a_241432}));
  return (g_std_2edoc_2e_3c_3e(v_t_241435, v_t_241436));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241445 = args[0];
  V v_one_241444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241446 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241445));
  V v_x1_241447 = heff_get_n(v_t_241446, 6, 9);
  V v_t_241448;
  if ((heff_dup(v_x1_241447) == NTAG(TAG_True))) {
    heff_drop(v_x1_241447);
    v_t_241448 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241447);
    v_t_241448 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241449 = heff_tr(heff_call(v_one_241444, 1, (V[]){v_a_241445}));
  return (g_std_2edoc_2e_3c_3e(v_t_241448, v_t_241449));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241457 = args[0];
  V v_one_241456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241458 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241457));
  V v_x1_241459 = heff_get_n(v_t_241458, 6, 9);
  V v_t_241460;
  if ((heff_dup(v_x1_241459) == NTAG(TAG_True))) {
    heff_drop(v_x1_241459);
    v_t_241460 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241459);
    v_t_241460 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241461 = heff_tr(heff_call(v_one_241456, 1, (V[]){v_a_241457}));
  return (g_std_2edoc_2e_3c_3e(v_t_241460, v_t_241461));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241470 = args[0];
  V v_one_241469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241471 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241470));
  V v_x1_241472 = heff_get_n(v_t_241471, 6, 9);
  V v_t_241473;
  if ((heff_dup(v_x1_241472) == NTAG(TAG_True))) {
    heff_drop(v_x1_241472);
    v_t_241473 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241472);
    v_t_241473 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241474 = heff_tr(heff_call(v_one_241469, 1, (V[]){v_a_241470}));
  return (g_std_2edoc_2e_3c_3e(v_t_241473, v_t_241474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241482 = args[0];
  V v_one_241481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241483 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241482));
  V v_x1_241484 = heff_get_n(v_t_241483, 6, 9);
  V v_t_241485;
  if ((heff_dup(v_x1_241484) == NTAG(TAG_True))) {
    heff_drop(v_x1_241484);
    v_t_241485 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241484);
    v_t_241485 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241486 = heff_tr(heff_call(v_one_241481, 1, (V[]){v_a_241482}));
  return (g_std_2edoc_2e_3c_3e(v_t_241485, v_t_241486));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241497 = args[0];
  V v_one_241496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241498 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241497));
  V v_x1_241499 = heff_get_n(v_t_241498, 6, 9);
  V v_t_241500;
  if ((heff_dup(v_x1_241499) == NTAG(TAG_True))) {
    heff_drop(v_x1_241499);
    v_t_241500 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241499);
    v_t_241500 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241501 = heff_tr(heff_call(v_one_241496, 1, (V[]){v_a_241497}));
  return (g_std_2edoc_2e_3c_3e(v_t_241500, v_t_241501));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241509 = args[0];
  V v_one_241508 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241510 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241509));
  V v_x1_241511 = heff_get_n(v_t_241510, 6, 9);
  V v_t_241512;
  if ((heff_dup(v_x1_241511) == NTAG(TAG_True))) {
    heff_drop(v_x1_241511);
    v_t_241512 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241511);
    v_t_241512 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241513 = heff_tr(heff_call(v_one_241508, 1, (V[]){v_a_241509}));
  return (g_std_2edoc_2e_3c_3e(v_t_241512, v_t_241513));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241521 = args[0];
  V v_one_241520 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241522 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241521));
  V v_x1_241523 = heff_get_n(v_t_241522, 6, 9);
  V v_t_241524;
  if ((heff_dup(v_x1_241523) == NTAG(TAG_True))) {
    heff_drop(v_x1_241523);
    v_t_241524 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241523);
    v_t_241524 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241525 = heff_tr(heff_call(v_one_241520, 1, (V[]){v_a_241521}));
  return (g_std_2edoc_2e_3c_3e(v_t_241524, v_t_241525));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241533 = args[0];
  V v_one_241532 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241534 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241533));
  V v_x1_241535 = heff_get_n(v_t_241534, 6, 9);
  V v_t_241536;
  if ((heff_dup(v_x1_241535) == NTAG(TAG_True))) {
    heff_drop(v_x1_241535);
    v_t_241536 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241535);
    v_t_241536 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241537 = heff_tr(heff_call(v_one_241532, 1, (V[]){v_a_241533}));
  return (g_std_2edoc_2e_3c_3e(v_t_241536, v_t_241537));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241545 = args[0];
  V v_one_241544 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241546 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241545));
  V v_x1_241547 = heff_get_n(v_t_241546, 6, 9);
  V v_t_241548;
  if ((heff_dup(v_x1_241547) == NTAG(TAG_True))) {
    heff_drop(v_x1_241547);
    v_t_241548 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241547);
    v_t_241548 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241549 = heff_tr(heff_call(v_one_241544, 1, (V[]){v_a_241545}));
  return (g_std_2edoc_2e_3c_3e(v_t_241548, v_t_241549));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241557 = args[0];
  V v_one_241556 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241558 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241557));
  V v_x1_241559 = heff_get_n(v_t_241558, 6, 9);
  V v_t_241560;
  if ((heff_dup(v_x1_241559) == NTAG(TAG_True))) {
    heff_drop(v_x1_241559);
    v_t_241560 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241559);
    v_t_241560 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241561 = heff_tr(heff_call(v_one_241556, 1, (V[]){v_a_241557}));
  return (g_std_2edoc_2e_3c_3e(v_t_241560, v_t_241561));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241569 = args[0];
  V v_one_241568 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241570 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241569));
  V v_x1_241571 = heff_get_n(v_t_241570, 6, 9);
  V v_t_241572;
  if ((heff_dup(v_x1_241571) == NTAG(TAG_True))) {
    heff_drop(v_x1_241571);
    v_t_241572 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241571);
    v_t_241572 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241573 = heff_tr(heff_call(v_one_241568, 1, (V[]){v_a_241569}));
  return (g_std_2edoc_2e_3c_3e(v_t_241572, v_t_241573));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241581 = args[0];
  V v_one_241580 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241582 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241581));
  V v_x1_241583 = heff_get_n(v_t_241582, 6, 9);
  V v_t_241584;
  if ((heff_dup(v_x1_241583) == NTAG(TAG_True))) {
    heff_drop(v_x1_241583);
    v_t_241584 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241583);
    v_t_241584 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241585 = heff_tr(heff_call(v_one_241580, 1, (V[]){v_a_241581}));
  return (g_std_2edoc_2e_3c_3e(v_t_241584, v_t_241585));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241593 = args[0];
  V v_one_241592 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241594 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241593));
  V v_x1_241595 = heff_get_n(v_t_241594, 6, 9);
  V v_t_241596;
  if ((heff_dup(v_x1_241595) == NTAG(TAG_True))) {
    heff_drop(v_x1_241595);
    v_t_241596 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241595);
    v_t_241596 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241597 = heff_tr(heff_call(v_one_241592, 1, (V[]){v_a_241593}));
  return (g_std_2edoc_2e_3c_3e(v_t_241596, v_t_241597));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241605 = args[0];
  V v_one_241604 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241606 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241605));
  V v_x1_241607 = heff_get_n(v_t_241606, 6, 9);
  V v_t_241608;
  if ((heff_dup(v_x1_241607) == NTAG(TAG_True))) {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241609 = heff_tr(heff_call(v_one_241604, 1, (V[]){v_a_241605}));
  return (g_std_2edoc_2e_3c_3e(v_t_241608, v_t_241609));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241618 = args[0];
  V v_one_241617 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241619 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241618));
  V v_x1_241620 = heff_get_n(v_t_241619, 6, 9);
  V v_t_241621;
  if ((heff_dup(v_x1_241620) == NTAG(TAG_True))) {
    heff_drop(v_x1_241620);
    v_t_241621 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241620);
    v_t_241621 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241622 = heff_tr(heff_call(v_one_241617, 1, (V[]){v_a_241618}));
  return (g_std_2edoc_2e_3c_3e(v_t_241621, v_t_241622));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241630 = args[0];
  V v_one_241629 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241631 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241630));
  V v_x1_241632 = heff_get_n(v_t_241631, 6, 9);
  V v_t_241633;
  if ((heff_dup(v_x1_241632) == NTAG(TAG_True))) {
    heff_drop(v_x1_241632);
    v_t_241633 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241632);
    v_t_241633 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241634 = heff_tr(heff_call(v_one_241629, 1, (V[]){v_a_241630}));
  return (g_std_2edoc_2e_3c_3e(v_t_241633, v_t_241634));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241642 = args[0];
  V v_one_241641 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241643 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241642));
  V v_x1_241644 = heff_get_n(v_t_241643, 6, 9);
  V v_t_241645;
  if ((heff_dup(v_x1_241644) == NTAG(TAG_True))) {
    heff_drop(v_x1_241644);
    v_t_241645 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241644);
    v_t_241645 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241646 = heff_tr(heff_call(v_one_241641, 1, (V[]){v_a_241642}));
  return (g_std_2edoc_2e_3c_3e(v_t_241645, v_t_241646));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241654 = args[0];
  V v_one_241653 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241655 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241654));
  V v_x1_241656 = heff_get_n(v_t_241655, 6, 9);
  V v_t_241657;
  if ((heff_dup(v_x1_241656) == NTAG(TAG_True))) {
    heff_drop(v_x1_241656);
    v_t_241657 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241656);
    v_t_241657 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241658 = heff_tr(heff_call(v_one_241653, 1, (V[]){v_a_241654}));
  return (g_std_2edoc_2e_3c_3e(v_t_241657, v_t_241658));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241666 = args[0];
  V v_one_241665 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241667 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241666));
  V v_x1_241668 = heff_get_n(v_t_241667, 6, 9);
  V v_t_241669;
  if ((heff_dup(v_x1_241668) == NTAG(TAG_True))) {
    heff_drop(v_x1_241668);
    v_t_241669 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241668);
    v_t_241669 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241670 = heff_tr(heff_call(v_one_241665, 1, (V[]){v_a_241666}));
  return (g_std_2edoc_2e_3c_3e(v_t_241669, v_t_241670));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241678 = args[0];
  V v_one_241677 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241679 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241678));
  V v_x1_241680 = heff_get_n(v_t_241679, 6, 9);
  V v_t_241681;
  if ((heff_dup(v_x1_241680) == NTAG(TAG_True))) {
    heff_drop(v_x1_241680);
    v_t_241681 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241680);
    v_t_241681 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241682 = heff_tr(heff_call(v_one_241677, 1, (V[]){v_a_241678}));
  return (g_std_2edoc_2e_3c_3e(v_t_241681, v_t_241682));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241691 = args[0];
  V v_one_241690 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241692 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241691));
  V v_x1_241693 = heff_get_n(v_t_241692, 6, 9);
  V v_t_241694;
  if ((heff_dup(v_x1_241693) == NTAG(TAG_True))) {
    heff_drop(v_x1_241693);
    v_t_241694 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241693);
    v_t_241694 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241695 = heff_tr(heff_call(v_one_241690, 1, (V[]){v_a_241691}));
  return (g_std_2edoc_2e_3c_3e(v_t_241694, v_t_241695));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241703 = args[0];
  V v_one_241702 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241704 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241703));
  V v_x1_241705 = heff_get_n(v_t_241704, 6, 9);
  V v_t_241706;
  if ((heff_dup(v_x1_241705) == NTAG(TAG_True))) {
    heff_drop(v_x1_241705);
    v_t_241706 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241705);
    v_t_241706 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241707 = heff_tr(heff_call(v_one_241702, 1, (V[]){v_a_241703}));
  return (g_std_2edoc_2e_3c_3e(v_t_241706, v_t_241707));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241714 = args[0];
  V v_one_241713 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241715 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241714));
  V v_x1_241716 = heff_get_n(v_t_241715, 6, 9);
  V v_t_241717;
  if ((heff_dup(v_x1_241716) == NTAG(TAG_True))) {
    heff_drop(v_x1_241716);
    v_t_241717 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241716);
    v_t_241717 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241718 = heff_tr(heff_call(v_one_241713, 1, (V[]){v_a_241714}));
  return (g_std_2edoc_2e_3c_3e(v_t_241717, v_t_241718));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241726 = args[0];
  V v_one_241725 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241727 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241726));
  V v_x1_241728 = heff_get_n(v_t_241727, 6, 9);
  V v_t_241729;
  if ((heff_dup(v_x1_241728) == NTAG(TAG_True))) {
    heff_drop(v_x1_241728);
    v_t_241729 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241728);
    v_t_241729 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241730 = heff_tr(heff_call(v_one_241725, 1, (V[]){v_a_241726}));
  return (g_std_2edoc_2e_3c_3e(v_t_241729, v_t_241730));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241739 = args[0];
  V v_one_241738 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241740 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241739));
  V v_x1_241741 = heff_get_n(v_t_241740, 6, 9);
  V v_t_241742;
  if ((heff_dup(v_x1_241741) == NTAG(TAG_True))) {
    heff_drop(v_x1_241741);
    v_t_241742 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241741);
    v_t_241742 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241743 = heff_tr(heff_call(v_one_241738, 1, (V[]){v_a_241739}));
  return (g_std_2edoc_2e_3c_3e(v_t_241742, v_t_241743));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241751 = args[0];
  V v_one_241750 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241752 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241751));
  V v_x1_241753 = heff_get_n(v_t_241752, 6, 9);
  V v_t_241754;
  if ((heff_dup(v_x1_241753) == NTAG(TAG_True))) {
    heff_drop(v_x1_241753);
    v_t_241754 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241753);
    v_t_241754 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241755 = heff_tr(heff_call(v_one_241750, 1, (V[]){v_a_241751}));
  return (g_std_2edoc_2e_3c_3e(v_t_241754, v_t_241755));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241766 = args[0];
  V v_one_241765 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241767 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241766));
  V v_x1_241768 = heff_get_n(v_t_241767, 6, 9);
  V v_t_241769;
  if ((heff_dup(v_x1_241768) == NTAG(TAG_True))) {
    heff_drop(v_x1_241768);
    v_t_241769 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241768);
    v_t_241769 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241770 = heff_tr(heff_call(v_one_241765, 1, (V[]){v_a_241766}));
  return (g_std_2edoc_2e_3c_3e(v_t_241769, v_t_241770));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241778 = args[0];
  V v_one_241777 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241779 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241778));
  V v_x1_241780 = heff_get_n(v_t_241779, 6, 9);
  V v_t_241781;
  if ((heff_dup(v_x1_241780) == NTAG(TAG_True))) {
    heff_drop(v_x1_241780);
    v_t_241781 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241780);
    v_t_241781 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241782 = heff_tr(heff_call(v_one_241777, 1, (V[]){v_a_241778}));
  return (g_std_2edoc_2e_3c_3e(v_t_241781, v_t_241782));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241792 = args[0];
  V v_one_241791 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241793 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241792));
  V v_x1_241794 = heff_get_n(v_t_241793, 6, 9);
  V v_t_241795;
  if ((heff_dup(v_x1_241794) == NTAG(TAG_True))) {
    heff_drop(v_x1_241794);
    v_t_241795 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241794);
    v_t_241795 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241796 = heff_tr(heff_call(v_one_241791, 1, (V[]){v_a_241792}));
  return (g_std_2edoc_2e_3c_3e(v_t_241795, v_t_241796));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241804 = args[0];
  V v_one_241803 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241805 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241804));
  V v_x1_241806 = heff_get_n(v_t_241805, 6, 9);
  V v_t_241807;
  if ((heff_dup(v_x1_241806) == NTAG(TAG_True))) {
    heff_drop(v_x1_241806);
    v_t_241807 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241806);
    v_t_241807 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241808 = heff_tr(heff_call(v_one_241803, 1, (V[]){v_a_241804}));
  return (g_std_2edoc_2e_3c_3e(v_t_241807, v_t_241808));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241818 = args[0];
  V v_one_241817 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241819 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241818));
  V v_x1_241820 = heff_get_n(v_t_241819, 6, 9);
  V v_t_241821;
  if ((heff_dup(v_x1_241820) == NTAG(TAG_True))) {
    heff_drop(v_x1_241820);
    v_t_241821 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241820);
    v_t_241821 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241822 = heff_tr(heff_call(v_one_241817, 1, (V[]){v_a_241818}));
  return (g_std_2edoc_2e_3c_3e(v_t_241821, v_t_241822));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241830 = args[0];
  V v_one_241829 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241831 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241830));
  V v_x1_241832 = heff_get_n(v_t_241831, 6, 9);
  V v_t_241833;
  if ((heff_dup(v_x1_241832) == NTAG(TAG_True))) {
    heff_drop(v_x1_241832);
    v_t_241833 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241832);
    v_t_241833 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241834 = heff_tr(heff_call(v_one_241829, 1, (V[]){v_a_241830}));
  return (g_std_2edoc_2e_3c_3e(v_t_241833, v_t_241834));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241843 = args[0];
  V v_one_241842 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241844 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241843));
  V v_x1_241845 = heff_get_n(v_t_241844, 6, 9);
  V v_t_241846;
  if ((heff_dup(v_x1_241845) == NTAG(TAG_True))) {
    heff_drop(v_x1_241845);
    v_t_241846 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241845);
    v_t_241846 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241847 = heff_tr(heff_call(v_one_241842, 1, (V[]){v_a_241843}));
  return (g_std_2edoc_2e_3c_3e(v_t_241846, v_t_241847));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241855 = args[0];
  V v_one_241854 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241856 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241855));
  V v_x1_241857 = heff_get_n(v_t_241856, 6, 9);
  V v_t_241858;
  if ((heff_dup(v_x1_241857) == NTAG(TAG_True))) {
    heff_drop(v_x1_241857);
    v_t_241858 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241857);
    v_t_241858 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241859 = heff_tr(heff_call(v_one_241854, 1, (V[]){v_a_241855}));
  return (g_std_2edoc_2e_3c_3e(v_t_241858, v_t_241859));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_a_241871 = args[0];
  V v_one_241870 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241872 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241871));
  V v_x1_241873 = heff_get_n(v_t_241872, 6, 9);
  V v_t_241874;
  if ((heff_dup(v_x1_241873) == NTAG(TAG_True))) {
    heff_drop(v_x1_241873);
    v_t_241874 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241873);
    v_t_241874 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241875 = heff_tr(heff_call(v_one_241870, 1, (V[]){v_a_241871}));
  return (g_std_2edoc_2e_3c_3e(v_t_241874, v_t_241875));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_a_241883 = args[0];
  V v_one_241882 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241884 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241883));
  V v_x1_241885 = heff_get_n(v_t_241884, 6, 9);
  V v_t_241886;
  if ((heff_dup(v_x1_241885) == NTAG(TAG_True))) {
    heff_drop(v_x1_241885);
    v_t_241886 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241885);
    v_t_241886 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241887 = heff_tr(heff_call(v_one_241882, 1, (V[]){v_a_241883}));
  return (g_std_2edoc_2e_3c_3e(v_t_241886, v_t_241887));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_a_241895 = args[0];
  V v_one_241894 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241896 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241895));
  V v_x1_241897 = heff_get_n(v_t_241896, 6, 9);
  V v_t_241898;
  if ((heff_dup(v_x1_241897) == NTAG(TAG_True))) {
    heff_drop(v_x1_241897);
    v_t_241898 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241897);
    v_t_241898 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241899 = heff_tr(heff_call(v_one_241894, 1, (V[]){v_a_241895}));
  return (g_std_2edoc_2e_3c_3e(v_t_241898, v_t_241899));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_a_241907 = args[0];
  V v_one_241906 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241908 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241907));
  V v_x1_241909 = heff_get_n(v_t_241908, 6, 9);
  V v_t_241910;
  if ((heff_dup(v_x1_241909) == NTAG(TAG_True))) {
    heff_drop(v_x1_241909);
    v_t_241910 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241909);
    v_t_241910 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241911 = heff_tr(heff_call(v_one_241906, 1, (V[]){v_a_241907}));
  return (g_std_2edoc_2e_3c_3e(v_t_241910, v_t_241911));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_a_241920 = args[0];
  V v_one_241919 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241921 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241920));
  V v_x1_241922 = heff_get_n(v_t_241921, 6, 9);
  V v_t_241923;
  if ((heff_dup(v_x1_241922) == NTAG(TAG_True))) {
    heff_drop(v_x1_241922);
    v_t_241923 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241922);
    v_t_241923 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241924 = heff_tr(heff_call(v_one_241919, 1, (V[]){v_a_241920}));
  return (g_std_2edoc_2e_3c_3e(v_t_241923, v_t_241924));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_a_241932 = args[0];
  V v_one_241931 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241933 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241932));
  V v_x1_241934 = heff_get_n(v_t_241933, 6, 9);
  V v_t_241935;
  if ((heff_dup(v_x1_241934) == NTAG(TAG_True))) {
    heff_drop(v_x1_241934);
    v_t_241935 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241934);
    v_t_241935 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241936 = heff_tr(heff_call(v_one_241931, 1, (V[]){v_a_241932}));
  return (g_std_2edoc_2e_3c_3e(v_t_241935, v_t_241936));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_a_241948 = args[0];
  V v_one_241947 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241949 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241948));
  V v_x1_241950 = heff_get_n(v_t_241949, 6, 9);
  V v_t_241951;
  if ((heff_dup(v_x1_241950) == NTAG(TAG_True))) {
    heff_drop(v_x1_241950);
    v_t_241951 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241950);
    v_t_241951 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241952 = heff_tr(heff_call(v_one_241947, 1, (V[]){v_a_241948}));
  return (g_std_2edoc_2e_3c_3e(v_t_241951, v_t_241952));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_a_241960 = args[0];
  V v_one_241959 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241961 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241960));
  V v_x1_241962 = heff_get_n(v_t_241961, 6, 9);
  V v_t_241963;
  if ((heff_dup(v_x1_241962) == NTAG(TAG_True))) {
    heff_drop(v_x1_241962);
    v_t_241963 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241962);
    v_t_241963 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241964 = heff_tr(heff_call(v_one_241959, 1, (V[]){v_a_241960}));
  return (g_std_2edoc_2e_3c_3e(v_t_241963, v_t_241964));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_a_241976 = args[0];
  V v_one_241975 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241977 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241976));
  V v_x1_241978 = heff_get_n(v_t_241977, 6, 9);
  V v_t_241979;
  if ((heff_dup(v_x1_241978) == NTAG(TAG_True))) {
    heff_drop(v_x1_241978);
    v_t_241979 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241978);
    v_t_241979 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241980 = heff_tr(heff_call(v_one_241975, 1, (V[]){v_a_241976}));
  return (g_std_2edoc_2e_3c_3e(v_t_241979, v_t_241980));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_a_241988 = args[0];
  V v_one_241987 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241989 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241988));
  V v_x1_241990 = heff_get_n(v_t_241989, 6, 9);
  V v_t_241991;
  if ((heff_dup(v_x1_241990) == NTAG(TAG_True))) {
    heff_drop(v_x1_241990);
    v_t_241991 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241990);
    v_t_241991 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241992 = heff_tr(heff_call(v_one_241987, 1, (V[]){v_a_241988}));
  return (g_std_2edoc_2e_3c_3e(v_t_241991, v_t_241992));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_a_242001 = args[0];
  V v_one_242000 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242002 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242001));
  V v_x1_242003 = heff_get_n(v_t_242002, 6, 9);
  V v_t_242004;
  if ((heff_dup(v_x1_242003) == NTAG(TAG_True))) {
    heff_drop(v_x1_242003);
    v_t_242004 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242003);
    v_t_242004 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242005 = heff_tr(heff_call(v_one_242000, 1, (V[]){v_a_242001}));
  return (g_std_2edoc_2e_3c_3e(v_t_242004, v_t_242005));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args) {
  V v_a_242013 = args[0];
  V v_one_242012 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242014 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242013));
  V v_x1_242015 = heff_get_n(v_t_242014, 6, 9);
  V v_t_242016;
  if ((heff_dup(v_x1_242015) == NTAG(TAG_True))) {
    heff_drop(v_x1_242015);
    v_t_242016 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242015);
    v_t_242016 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242017 = heff_tr(heff_call(v_one_242012, 1, (V[]){v_a_242013}));
  return (g_std_2edoc_2e_3c_3e(v_t_242016, v_t_242017));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args) {
  V v_a_242027 = args[0];
  V v_one_242026 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242028 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242027));
  V v_x1_242029 = heff_get_n(v_t_242028, 6, 9);
  V v_t_242030;
  if ((heff_dup(v_x1_242029) == NTAG(TAG_True))) {
    heff_drop(v_x1_242029);
    v_t_242030 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242029);
    v_t_242030 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242031 = heff_tr(heff_call(v_one_242026, 1, (V[]){v_a_242027}));
  return (g_std_2edoc_2e_3c_3e(v_t_242030, v_t_242031));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args) {
  V v_a_242039 = args[0];
  V v_one_242038 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242040 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242039));
  V v_x1_242041 = heff_get_n(v_t_242040, 6, 9);
  V v_t_242042;
  if ((heff_dup(v_x1_242041) == NTAG(TAG_True))) {
    heff_drop(v_x1_242041);
    v_t_242042 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242041);
    v_t_242042 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242043 = heff_tr(heff_call(v_one_242038, 1, (V[]){v_a_242039}));
  return (g_std_2edoc_2e_3c_3e(v_t_242042, v_t_242043));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args) {
  V v_a_242055 = args[0];
  V v_one_242054 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242056 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242055));
  V v_x1_242057 = heff_get_n(v_t_242056, 6, 9);
  V v_t_242058;
  if ((heff_dup(v_x1_242057) == NTAG(TAG_True))) {
    heff_drop(v_x1_242057);
    v_t_242058 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242057);
    v_t_242058 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242059 = heff_tr(heff_call(v_one_242054, 1, (V[]){v_a_242055}));
  return (g_std_2edoc_2e_3c_3e(v_t_242058, v_t_242059));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args) {
  V v_a_242067 = args[0];
  V v_one_242066 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242068 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242067));
  V v_x1_242069 = heff_get_n(v_t_242068, 6, 9);
  V v_t_242070;
  if ((heff_dup(v_x1_242069) == NTAG(TAG_True))) {
    heff_drop(v_x1_242069);
    v_t_242070 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242069);
    v_t_242070 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242071 = heff_tr(heff_call(v_one_242066, 1, (V[]){v_a_242067}));
  return (g_std_2edoc_2e_3c_3e(v_t_242070, v_t_242071));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args) {
  V v_a_242078 = args[0];
  V v_one_242077 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242079 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242078));
  V v_x1_242080 = heff_get_n(v_t_242079, 6, 9);
  V v_t_242081;
  if ((heff_dup(v_x1_242080) == NTAG(TAG_True))) {
    heff_drop(v_x1_242080);
    v_t_242081 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242080);
    v_t_242081 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242082 = heff_tr(heff_call(v_one_242077, 1, (V[]){v_a_242078}));
  return (g_std_2edoc_2e_3c_3e(v_t_242081, v_t_242082));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args) {
  V v_a_242090 = args[0];
  V v_one_242089 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242091 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242090));
  V v_x1_242092 = heff_get_n(v_t_242091, 6, 9);
  V v_t_242093;
  if ((heff_dup(v_x1_242092) == NTAG(TAG_True))) {
    heff_drop(v_x1_242092);
    v_t_242093 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242092);
    v_t_242093 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242094 = heff_tr(heff_call(v_one_242089, 1, (V[]){v_a_242090}));
  return (g_std_2edoc_2e_3c_3e(v_t_242093, v_t_242094));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args) {
  V v_a_242102 = args[0];
  V v_one_242101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242103 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242102));
  V v_x1_242104 = heff_get_n(v_t_242103, 6, 9);
  V v_t_242105;
  if ((heff_dup(v_x1_242104) == NTAG(TAG_True))) {
    heff_drop(v_x1_242104);
    v_t_242105 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242104);
    v_t_242105 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242106 = heff_tr(heff_call(v_one_242101, 1, (V[]){v_a_242102}));
  return (g_std_2edoc_2e_3c_3e(v_t_242105, v_t_242106));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args) {
  V v_a_242114 = args[0];
  V v_one_242113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242115 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242114));
  V v_x1_242116 = heff_get_n(v_t_242115, 6, 9);
  V v_t_242117;
  if ((heff_dup(v_x1_242116) == NTAG(TAG_True))) {
    heff_drop(v_x1_242116);
    v_t_242117 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242116);
    v_t_242117 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242118 = heff_tr(heff_call(v_one_242113, 1, (V[]){v_a_242114}));
  return (g_std_2edoc_2e_3c_3e(v_t_242117, v_t_242118));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args) {
  V v_a_242128 = args[0];
  V v_one_242127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242129 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242128));
  V v_x1_242130 = heff_get_n(v_t_242129, 6, 9);
  V v_t_242131;
  if ((heff_dup(v_x1_242130) == NTAG(TAG_True))) {
    heff_drop(v_x1_242130);
    v_t_242131 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242130);
    v_t_242131 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242132 = heff_tr(heff_call(v_one_242127, 1, (V[]){v_a_242128}));
  return (g_std_2edoc_2e_3c_3e(v_t_242131, v_t_242132));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args) {
  V v_a_242140 = args[0];
  V v_one_242139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242141 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242140));
  V v_x1_242142 = heff_get_n(v_t_242141, 6, 9);
  V v_t_242143;
  if ((heff_dup(v_x1_242142) == NTAG(TAG_True))) {
    heff_drop(v_x1_242142);
    v_t_242143 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242142);
    v_t_242143 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242144 = heff_tr(heff_call(v_one_242139, 1, (V[]){v_a_242140}));
  return (g_std_2edoc_2e_3c_3e(v_t_242143, v_t_242144));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args) {
  V v_a_242154 = args[0];
  V v_one_242153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242155 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242154));
  V v_x1_242156 = heff_get_n(v_t_242155, 6, 9);
  V v_t_242157;
  if ((heff_dup(v_x1_242156) == NTAG(TAG_True))) {
    heff_drop(v_x1_242156);
    v_t_242157 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242156);
    v_t_242157 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242158 = heff_tr(heff_call(v_one_242153, 1, (V[]){v_a_242154}));
  return (g_std_2edoc_2e_3c_3e(v_t_242157, v_t_242158));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args) {
  V v_a_242166 = args[0];
  V v_one_242165 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242167 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242166));
  V v_x1_242168 = heff_get_n(v_t_242167, 6, 9);
  V v_t_242169;
  if ((heff_dup(v_x1_242168) == NTAG(TAG_True))) {
    heff_drop(v_x1_242168);
    v_t_242169 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242168);
    v_t_242169 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242170 = heff_tr(heff_call(v_one_242165, 1, (V[]){v_a_242166}));
  return (g_std_2edoc_2e_3c_3e(v_t_242169, v_t_242170));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args) {
  V v_a_242180 = args[0];
  V v_one_242179 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242181 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242180));
  V v_x1_242182 = heff_get_n(v_t_242181, 6, 9);
  V v_t_242183;
  if ((heff_dup(v_x1_242182) == NTAG(TAG_True))) {
    heff_drop(v_x1_242182);
    v_t_242183 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242182);
    v_t_242183 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242184 = heff_tr(heff_call(v_one_242179, 1, (V[]){v_a_242180}));
  return (g_std_2edoc_2e_3c_3e(v_t_242183, v_t_242184));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args) {
  V v_a_242192 = args[0];
  V v_one_242191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242193 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242192));
  V v_x1_242194 = heff_get_n(v_t_242193, 6, 9);
  V v_t_242195;
  if ((heff_dup(v_x1_242194) == NTAG(TAG_True))) {
    heff_drop(v_x1_242194);
    v_t_242195 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242194);
    v_t_242195 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242196 = heff_tr(heff_call(v_one_242191, 1, (V[]){v_a_242192}));
  return (g_std_2edoc_2e_3c_3e(v_t_242195, v_t_242196));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args) {
  V v_a_242206 = args[0];
  V v_one_242205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242207 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242206));
  V v_x1_242208 = heff_get_n(v_t_242207, 6, 9);
  V v_t_242209;
  if ((heff_dup(v_x1_242208) == NTAG(TAG_True))) {
    heff_drop(v_x1_242208);
    v_t_242209 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242208);
    v_t_242209 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242210 = heff_tr(heff_call(v_one_242205, 1, (V[]){v_a_242206}));
  return (g_std_2edoc_2e_3c_3e(v_t_242209, v_t_242210));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args) {
  V v_a_242218 = args[0];
  V v_one_242217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242219 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242218));
  V v_x1_242220 = heff_get_n(v_t_242219, 6, 9);
  V v_t_242221;
  if ((heff_dup(v_x1_242220) == NTAG(TAG_True))) {
    heff_drop(v_x1_242220);
    v_t_242221 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242220);
    v_t_242221 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242222 = heff_tr(heff_call(v_one_242217, 1, (V[]){v_a_242218}));
  return (g_std_2edoc_2e_3c_3e(v_t_242221, v_t_242222));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args) {
  V v_a_242232 = args[0];
  V v_one_242231 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242233 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242232));
  V v_x1_242234 = heff_get_n(v_t_242233, 6, 9);
  V v_t_242235;
  if ((heff_dup(v_x1_242234) == NTAG(TAG_True))) {
    heff_drop(v_x1_242234);
    v_t_242235 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242234);
    v_t_242235 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242236 = heff_tr(heff_call(v_one_242231, 1, (V[]){v_a_242232}));
  return (g_std_2edoc_2e_3c_3e(v_t_242235, v_t_242236));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args) {
  V v_a_242244 = args[0];
  V v_one_242243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242245 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242244));
  V v_x1_242246 = heff_get_n(v_t_242245, 6, 9);
  V v_t_242247;
  if ((heff_dup(v_x1_242246) == NTAG(TAG_True))) {
    heff_drop(v_x1_242246);
    v_t_242247 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242246);
    v_t_242247 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242248 = heff_tr(heff_call(v_one_242243, 1, (V[]){v_a_242244}));
  return (g_std_2edoc_2e_3c_3e(v_t_242247, v_t_242248));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_env_241196 = args[0];
  V v_h_241197 = args[1];
  V v_args_241198 = args[2];
  V v_x1_241199 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_241198)));
  switch (heff_tag_of(v_x1_241199)) {
  case TAG_Nil: {
    heff_drop(v_args_241198);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241196;
    args[1] = v_h_241197;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_241200 = heff_field(v_x1_241199, 0);
    V v_rev_241201 = heff_field(v_x1_241199, 1);
    V v_ru_24x1_241199_24Cons = heff_take_reuse_n(v_x1_241199, 3ULL, 2);
    V v_t_241202 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241201));
    switch (heff_tag_of(v_x_241200)) {
    case TAG_Atom: {
      V v_t_241204 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241204) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241204);
        V v_t_241205 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241212 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_one_241206}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241213 = (g_std_2edoc_2e_3c_3e(v_t_241205, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241212})));
        V v_a_241214 = (g_std_2edoc_2egroup(v_t_241213));
        V v_b_241215 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241216 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), v_b_241215));
        return (g_std_2edoc_2e_3c_3e(v_a_241214, v_t_241216));
      } else {
        heff_drop_tag(v_x_241200, 1);
        heff_drop(v_t_241202);
        heff_drop(v_t_241204);
        V v_t_241217 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241218 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241224 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_one_241218}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241225 = (g_std_2edoc_2e_3c_3e(v_t_241217, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241224})));
        return (g_std_2edoc_2egroup(v_t_241225));
      }
    }
    case TAG_EParen: {
      V v_o_241226 = heff_field(v_x_241200, 0);
      V v_e_241227 = heff_field(v_x_241200, 1);
      V v_c_241228 = heff_field(v_x_241200, 2);
      heff_take_n(v_x_241200, 7ULL, 3);
      V v_t_241229 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_241227));
      if ((heff_dup(v_t_241229) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241229);
        V v_t_241230 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241231 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241237 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241231}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241238 = (g_std_2edoc_2e_3c_3e(v_t_241230, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241237})));
        V v_a_241239 = (g_std_2edoc_2egroup(v_t_241238));
        V v_b_241240 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241196), v_o_241226));
        V v_t_241241 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), v_b_241240));
        V v_t_241242 = (g_std_2edoc_2e_3c_3e(v_a_241239, v_t_241241));
        V v_t_241243 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_e_241227}));
        V v_t_241244 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241196, v_c_241228));
        V v_t_241245 = (g_std_2edoc_2e_3c_3e(v_t_241243, v_t_241244));
        return (g_std_2edoc_2e_3c_3e(v_t_241242, v_t_241245));
      } else {
        heff_drop(v_t_241202);
        heff_drop(v_o_241226);
        heff_drop(v_e_241227);
        heff_drop(v_c_241228);
        heff_drop(v_t_241229);
        V v_t_241246 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241253 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241247}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241254 = (g_std_2edoc_2e_3c_3e(v_t_241246, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241253})));
        return (g_std_2edoc_2egroup(v_t_241254));
      }
    }
    case TAG_Named: {
      V v_t_241260 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241260) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241260);
        V v_t_241261 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241262 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241268 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241262}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241269 = (g_std_2edoc_2e_3c_3e(v_t_241261, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241268})));
        V v_a_241270 = (g_std_2edoc_2egroup(v_t_241269));
        V v_b_241271 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241272 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), v_b_241271));
        return (g_std_2edoc_2e_3c_3e(v_a_241270, v_t_241272));
      } else {
        heff_drop_tag(v_x_241200, 5);
        heff_drop(v_t_241202);
        heff_drop(v_t_241260);
        V v_t_241273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241274 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241280 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241274}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241281 = (g_std_2edoc_2e_3c_3e(v_t_241273, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241280})));
        return (g_std_2edoc_2egroup(v_t_241281));
      }
    }
    case TAG_Tup: {
      V v_t_241286 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241286) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241286);
        V v_t_241287 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241288 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241294 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241288}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241295 = (g_std_2edoc_2e_3c_3e(v_t_241287, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241294})));
        V v_a_241296 = (g_std_2edoc_2egroup(v_t_241295));
        V v_b_241297 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241298 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), v_b_241297));
        return (g_std_2edoc_2e_3c_3e(v_a_241296, v_t_241298));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_241286);
        V v_t_241299 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241300 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241306 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241300}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241307 = (g_std_2edoc_2e_3c_3e(v_t_241299, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241306})));
        return (g_std_2edoc_2egroup(v_t_241307));
      }
    }
    case TAG_Seg: {
      V v_t_241311 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241311) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241311);
        V v_t_241312 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241319 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241313}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241320 = (g_std_2edoc_2e_3c_3e(v_t_241312, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241319})));
        V v_a_241321 = (g_std_2edoc_2egroup(v_t_241320));
        V v_b_241322 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241323 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), v_b_241322));
        return (g_std_2edoc_2e_3c_3e(v_a_241321, v_t_241323));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241311);
        V v_t_241324 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241325 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241331 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241325}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241332 = (g_std_2edoc_2e_3c_3e(v_t_241324, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241331})));
        return (g_std_2edoc_2egroup(v_t_241332));
      }
    }
    case TAG_Braces: {
      V v_t_241337 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241337) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241337);
        V v_t_241338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241345 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241339}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241346 = (g_std_2edoc_2e_3c_3e(v_t_241338, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241345})));
        V v_a_241347 = (g_std_2edoc_2egroup(v_t_241346));
        V v_b_241348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241349 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), v_b_241348));
        return (g_std_2edoc_2e_3c_3e(v_a_241347, v_t_241349));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_241337);
        V v_t_241350 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241351 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241357 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241351}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241358 = (g_std_2edoc_2e_3c_3e(v_t_241350, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241357})));
        return (g_std_2edoc_2egroup(v_t_241358));
      }
    }
    case TAG_Update: {
      V v_t_241365 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241365) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241365);
        V v_t_241366 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241367 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241373 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241367}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241374 = (g_std_2edoc_2e_3c_3e(v_t_241366, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241373})));
        V v_a_241375 = (g_std_2edoc_2egroup(v_t_241374));
        V v_b_241376 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241377 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), v_b_241376));
        return (g_std_2edoc_2e_3c_3e(v_a_241375, v_t_241377));
      } else {
        heff_drop_tag(v_x_241200, 6);
        heff_drop(v_t_241202);
        heff_drop(v_t_241365);
        V v_t_241378 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241379 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241385 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241379}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241386 = (g_std_2edoc_2e_3c_3e(v_t_241378, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241385})));
        return (g_std_2edoc_2egroup(v_t_241386));
      }
    }
    case TAG_EUSet: {
      V v_t_241390 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241390) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241390);
        V v_t_241391 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241398 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241392}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241399 = (g_std_2edoc_2e_3c_3e(v_t_241391, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241398})));
        V v_a_241400 = (g_std_2edoc_2egroup(v_t_241399));
        V v_b_241401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241402 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_241401));
        return (g_std_2edoc_2e_3c_3e(v_a_241400, v_t_241402));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241390);
        V v_t_241403 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241404 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241410 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241404}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241411 = (g_std_2edoc_2e_3c_3e(v_t_241403, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241410})));
        return (g_std_2edoc_2egroup(v_t_241411));
      }
    }
    case TAG_InstB: {
      V v_t_241417 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241417) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241417);
        V v_t_241418 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241419 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241419}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241426 = (g_std_2edoc_2e_3c_3e(v_t_241418, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241425})));
        V v_a_241427 = (g_std_2edoc_2egroup(v_t_241426));
        V v_b_241428 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241429 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), v_b_241428));
        return (g_std_2edoc_2e_3c_3e(v_a_241427, v_t_241429));
      } else {
        heff_drop_tag(v_x_241200, 5);
        heff_drop(v_t_241202);
        heff_drop(v_t_241417);
        V v_t_241430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241431 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241437 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241431}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241438 = (g_std_2edoc_2e_3c_3e(v_t_241430, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241437})));
        return (g_std_2edoc_2egroup(v_t_241438));
      }
    }
    case TAG_EFSet: {
      V v_t_241442 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241442) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241442);
        V v_t_241443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241444 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241450 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241444}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241451 = (g_std_2edoc_2e_3c_3e(v_t_241443, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241450})));
        V v_a_241452 = (g_std_2edoc_2egroup(v_t_241451));
        V v_b_241453 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_241453));
        return (g_std_2edoc_2e_3c_3e(v_a_241452, v_t_241454));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241442);
        V v_t_241455 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241456 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241462 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241456}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241463 = (g_std_2edoc_2e_3c_3e(v_t_241455, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241462})));
        return (g_std_2edoc_2egroup(v_t_241463));
      }
    }
    case TAG_EFDefault: {
      V v_t_241467 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241467) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241467);
        V v_t_241468 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241469 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241469}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241476 = (g_std_2edoc_2e_3c_3e(v_t_241468, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241475})));
        V v_a_241477 = (g_std_2edoc_2egroup(v_t_241476));
        V v_b_241478 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241479 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str111)}), v_b_241478));
        return (g_std_2edoc_2e_3c_3e(v_a_241477, v_t_241479));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241467);
        V v_t_241480 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241481 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241487 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241481}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241488 = (g_std_2edoc_2e_3c_3e(v_t_241480, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241487})));
        return (g_std_2edoc_2egroup(v_t_241488));
      }
    }
    case TAG_Sum: {
      V v_t_241494 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241494) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241494);
        V v_t_241495 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241496 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241502 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241496}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241503 = (g_std_2edoc_2e_3c_3e(v_t_241495, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241502})));
        V v_a_241504 = (g_std_2edoc_2egroup(v_t_241503));
        V v_b_241505 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241506 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str112)}), v_b_241505));
        return (g_std_2edoc_2e_3c_3e(v_a_241504, v_t_241506));
      } else {
        heff_drop_tag(v_x_241200, 5);
        heff_drop(v_t_241202);
        heff_drop(v_t_241494);
        V v_t_241507 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241508 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241514 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241508}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241515 = (g_std_2edoc_2e_3c_3e(v_t_241507, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241514})));
        return (g_std_2edoc_2egroup(v_t_241515));
      }
    }
    case TAG_ECon: {
      V v_t_241518 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241518) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241518);
        V v_t_241519 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241520 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241526 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241520}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241527 = (g_std_2edoc_2e_3c_3e(v_t_241519, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241526})));
        V v_a_241528 = (g_std_2edoc_2egroup(v_t_241527));
        V v_b_241529 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241530 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str113)}), v_b_241529));
        return (g_std_2edoc_2e_3c_3e(v_a_241528, v_t_241530));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241518);
        V v_t_241531 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241532 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241538 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241532}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241539 = (g_std_2edoc_2e_3c_3e(v_t_241531, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241538})));
        return (g_std_2edoc_2egroup(v_t_241539));
      }
    }
    case TAG_EField: {
      V v_t_241542 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241542) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241542);
        V v_t_241543 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241544 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241550 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241544}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241551 = (g_std_2edoc_2e_3c_3e(v_t_241543, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241550})));
        V v_a_241552 = (g_std_2edoc_2egroup(v_t_241551));
        V v_b_241553 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241554 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str114)}), v_b_241553));
        return (g_std_2edoc_2e_3c_3e(v_a_241552, v_t_241554));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241542);
        V v_t_241555 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241556 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241562 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241556}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241563 = (g_std_2edoc_2e_3c_3e(v_t_241555, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241562})));
        return (g_std_2edoc_2egroup(v_t_241563));
      }
    }
    case TAG_ENeg: {
      V v_t_241566 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241566) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241566);
        V v_t_241567 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241568 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241574 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241568}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241575 = (g_std_2edoc_2e_3c_3e(v_t_241567, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241574})));
        V v_a_241576 = (g_std_2edoc_2egroup(v_t_241575));
        V v_b_241577 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241578 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str115)}), v_b_241577));
        return (g_std_2edoc_2e_3c_3e(v_a_241576, v_t_241578));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241566);
        V v_t_241579 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241580 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241586 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241580}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241587 = (g_std_2edoc_2e_3c_3e(v_t_241579, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241586})));
        return (g_std_2edoc_2egroup(v_t_241587));
      }
    }
    case TAG_App: {
      V v_t_241590 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241590) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241590);
        V v_t_241591 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241592 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241598 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241592}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241599 = (g_std_2edoc_2e_3c_3e(v_t_241591, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241598})));
        V v_a_241600 = (g_std_2edoc_2egroup(v_t_241599));
        V v_b_241601 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241602 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str116)}), v_b_241601));
        return (g_std_2edoc_2e_3c_3e(v_a_241600, v_t_241602));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241590);
        V v_t_241603 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241604 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241610 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241604}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241611 = (g_std_2edoc_2e_3c_3e(v_t_241603, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241610})));
        return (g_std_2edoc_2egroup(v_t_241611));
      }
    }
    case TAG_Op: {
      V v_t_241615 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241615) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241615);
        V v_t_241616 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241617 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241623 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241617}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241624 = (g_std_2edoc_2e_3c_3e(v_t_241616, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241623})));
        V v_a_241625 = (g_std_2edoc_2egroup(v_t_241624));
        V v_b_241626 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241627 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str117)}), v_b_241626));
        return (g_std_2edoc_2e_3c_3e(v_a_241625, v_t_241627));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241615);
        V v_t_241628 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241629 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241635 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241629}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241636 = (g_std_2edoc_2e_3c_3e(v_t_241628, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241635})));
        return (g_std_2edoc_2egroup(v_t_241636));
      }
    }
    case TAG_Ops: {
      V v_t_241639 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241639) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241639);
        V v_t_241640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241641 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241647 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241641}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241648 = (g_std_2edoc_2e_3c_3e(v_t_241640, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241647})));
        V v_a_241649 = (g_std_2edoc_2egroup(v_t_241648));
        V v_b_241650 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241651 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str118)}), v_b_241650));
        return (g_std_2edoc_2e_3c_3e(v_a_241649, v_t_241651));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241639);
        V v_t_241652 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241653 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241659 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241653}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241660 = (g_std_2edoc_2e_3c_3e(v_t_241652, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241659})));
        return (g_std_2edoc_2egroup(v_t_241660));
      }
    }
    case TAG_OpRhs: {
      V v_t_241663 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241663) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241663);
        V v_t_241664 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241665 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241671 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241665}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241672 = (g_std_2edoc_2e_3c_3e(v_t_241664, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241671})));
        V v_a_241673 = (g_std_2edoc_2egroup(v_t_241672));
        V v_b_241674 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241675 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str119)}), v_b_241674));
        return (g_std_2edoc_2e_3c_3e(v_a_241673, v_t_241675));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241663);
        V v_t_241676 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241677 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241683 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241677}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241684 = (g_std_2edoc_2e_3c_3e(v_t_241676, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241683})));
        return (g_std_2edoc_2egroup(v_t_241684));
      }
    }
    case TAG_Ann: {
      V v_t_241688 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241688) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241688);
        V v_t_241689 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241690 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241696 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241690}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241697 = (g_std_2edoc_2e_3c_3e(v_t_241689, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241696})));
        V v_a_241698 = (g_std_2edoc_2egroup(v_t_241697));
        V v_b_241699 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241700 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str120)}), v_b_241699));
        return (g_std_2edoc_2e_3c_3e(v_a_241698, v_t_241700));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241688);
        V v_t_241701 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241702 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241708 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241702}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241709 = (g_std_2edoc_2e_3c_3e(v_t_241701, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241708})));
        return (g_std_2edoc_2egroup(v_t_241709));
      }
    }
    case TAG_BVar: {
      V v_t_241711 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241711) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241711);
        V v_t_241712 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241713 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241719 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241713}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241720 = (g_std_2edoc_2e_3c_3e(v_t_241712, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241719})));
        V v_a_241721 = (g_std_2edoc_2egroup(v_t_241720));
        V v_b_241722 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241723 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str121)}), v_b_241722));
        return (g_std_2edoc_2e_3c_3e(v_a_241721, v_t_241723));
      } else {
        heff_drop_tag(v_x_241200, 1);
        heff_drop(v_t_241202);
        heff_drop(v_t_241711);
        V v_t_241724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241725 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241731 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241725}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241732 = (g_std_2edoc_2e_3c_3e(v_t_241724, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241731})));
        return (g_std_2edoc_2egroup(v_t_241732));
      }
    }
    case TAG_BImp: {
      V v_t_241736 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241736) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241736);
        V v_t_241737 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241738 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241744 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241738}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241745 = (g_std_2edoc_2e_3c_3e(v_t_241737, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241744})));
        V v_a_241746 = (g_std_2edoc_2egroup(v_t_241745));
        V v_b_241747 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241748 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str122)}), v_b_241747));
        return (g_std_2edoc_2e_3c_3e(v_a_241746, v_t_241748));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241736);
        V v_t_241749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241750 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241756 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241750}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241757 = (g_std_2edoc_2e_3c_3e(v_t_241749, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241756})));
        return (g_std_2edoc_2egroup(v_t_241757));
      }
    }
    case TAG_BAnn: {
      V v_t_241763 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241763) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241763);
        V v_t_241764 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241765 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241771 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241765}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241772 = (g_std_2edoc_2e_3c_3e(v_t_241764, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241771})));
        V v_a_241773 = (g_std_2edoc_2egroup(v_t_241772));
        V v_b_241774 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241775 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str123)}), v_b_241774));
        return (g_std_2edoc_2e_3c_3e(v_a_241773, v_t_241775));
      } else {
        heff_drop_tag(v_x_241200, 5);
        heff_drop(v_t_241202);
        heff_drop(v_t_241763);
        V v_t_241776 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241777 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241783 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241777}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241784 = (g_std_2edoc_2e_3c_3e(v_t_241776, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241783})));
        return (g_std_2edoc_2egroup(v_t_241784));
      }
    }
    case TAG_Lam: {
      V v_t_241789 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241789) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241789);
        V v_t_241790 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241791 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241797 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241791}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241798 = (g_std_2edoc_2e_3c_3e(v_t_241790, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241797})));
        V v_a_241799 = (g_std_2edoc_2egroup(v_t_241798));
        V v_b_241800 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241801 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str124)}), v_b_241800));
        return (g_std_2edoc_2e_3c_3e(v_a_241799, v_t_241801));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_241789);
        V v_t_241802 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241803 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241809 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241803}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241810 = (g_std_2edoc_2e_3c_3e(v_t_241802, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241809})));
        return (g_std_2edoc_2egroup(v_t_241810));
      }
    }
    case TAG_Case: {
      V v_t_241815 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241815) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241815);
        V v_t_241816 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241817 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241823 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241817}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241824 = (g_std_2edoc_2e_3c_3e(v_t_241816, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241823})));
        V v_a_241825 = (g_std_2edoc_2egroup(v_t_241824));
        V v_b_241826 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241827 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str125)}), v_b_241826));
        return (g_std_2edoc_2e_3c_3e(v_a_241825, v_t_241827));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_241815);
        V v_t_241828 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241829 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241835 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241829}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241836 = (g_std_2edoc_2e_3c_3e(v_t_241828, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241835})));
        return (g_std_2edoc_2egroup(v_t_241836));
      }
    }
    case TAG_EAlt: {
      V v_t_241840 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241840) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241840);
        V v_t_241841 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241842 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241848 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241842}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241849 = (g_std_2edoc_2e_3c_3e(v_t_241841, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241848})));
        V v_a_241850 = (g_std_2edoc_2egroup(v_t_241849));
        V v_b_241851 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241852 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str126)}), v_b_241851));
        return (g_std_2edoc_2e_3c_3e(v_a_241850, v_t_241852));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241840);
        V v_t_241853 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241854 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241860 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241854}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241861 = (g_std_2edoc_2e_3c_3e(v_t_241853, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241860})));
        return (g_std_2edoc_2egroup(v_t_241861));
      }
    }
    case TAG_If: {
      V v_t_241868 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241868) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241868);
        V v_t_241869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241870 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241876 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 1, 1, (V[]){v_one_241870}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241877 = (g_std_2edoc_2e_3c_3e(v_t_241869, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241876})));
        V v_a_241878 = (g_std_2edoc_2egroup(v_t_241877));
        V v_b_241879 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241880 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str127)}), v_b_241879));
        return (g_std_2edoc_2e_3c_3e(v_a_241878, v_t_241880));
      } else {
        heff_drop_tag(v_x_241200, 6);
        heff_drop(v_t_241202);
        heff_drop(v_t_241868);
        V v_t_241881 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241882 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241888 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 1, 1, (V[]){v_one_241882}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241889 = (g_std_2edoc_2e_3c_3e(v_t_241881, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241888})));
        return (g_std_2edoc_2egroup(v_t_241889));
      }
    }
    case TAG_Do: {
      V v_t_241892 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241892) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241892);
        V v_t_241893 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241894 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241900 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_one_241894}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241901 = (g_std_2edoc_2e_3c_3e(v_t_241893, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241900})));
        V v_a_241902 = (g_std_2edoc_2egroup(v_t_241901));
        V v_b_241903 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241904 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str128)}), v_b_241903));
        return (g_std_2edoc_2e_3c_3e(v_a_241902, v_t_241904));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_241892);
        V v_t_241905 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241906 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241912 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_one_241906}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241913 = (g_std_2edoc_2e_3c_3e(v_t_241905, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241912})));
        return (g_std_2edoc_2egroup(v_t_241913));
      }
    }
    case TAG_ESBind: {
      V v_t_241917 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241917) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241917);
        V v_t_241918 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241919 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241925 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 1, 1, (V[]){v_one_241919}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241926 = (g_std_2edoc_2e_3c_3e(v_t_241918, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241925})));
        V v_a_241927 = (g_std_2edoc_2egroup(v_t_241926));
        V v_b_241928 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241929 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str129)}), v_b_241928));
        return (g_std_2edoc_2e_3c_3e(v_a_241927, v_t_241929));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241917);
        V v_t_241930 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241931 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241937 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_one_241931}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241938 = (g_std_2edoc_2e_3c_3e(v_t_241930, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241937})));
        return (g_std_2edoc_2egroup(v_t_241938));
      }
    }
    case TAG_ELet: {
      V v_t_241945 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241945) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241945);
        V v_t_241946 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241953 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_one_241947}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241954 = (g_std_2edoc_2e_3c_3e(v_t_241946, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241953})));
        V v_a_241955 = (g_std_2edoc_2egroup(v_t_241954));
        V v_b_241956 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241957 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str130)}), v_b_241956));
        return (g_std_2edoc_2e_3c_3e(v_a_241955, v_t_241957));
      } else {
        heff_drop_tag(v_x_241200, 6);
        heff_drop(v_t_241202);
        heff_drop(v_t_241945);
        V v_t_241958 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241959 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241965 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 1, 1, (V[]){v_one_241959}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241966 = (g_std_2edoc_2e_3c_3e(v_t_241958, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241965})));
        return (g_std_2edoc_2egroup(v_t_241966));
      }
    }
    case TAG_ELetMut: {
      V v_t_241973 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241973) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241973);
        V v_t_241974 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241975 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_241981 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 1, 1, (V[]){v_one_241975}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_241982 = (g_std_2edoc_2e_3c_3e(v_t_241974, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241981})));
        V v_a_241983 = (g_std_2edoc_2egroup(v_t_241982));
        V v_b_241984 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_241985 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str131)}), v_b_241984));
        return (g_std_2edoc_2e_3c_3e(v_a_241983, v_t_241985));
      } else {
        heff_drop_tag(v_x_241200, 6);
        heff_drop(v_t_241202);
        heff_drop(v_t_241973);
        V v_t_241986 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_241987 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_241993 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 1, 1, (V[]){v_one_241987}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_241994 = (g_std_2edoc_2e_3c_3e(v_t_241986, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241993})));
        return (g_std_2edoc_2egroup(v_t_241994));
      }
    }
    case TAG_EAssign: {
      V v_t_241998 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_241998) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_241998);
        V v_t_241999 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242000 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242006 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 1, 1, (V[]){v_one_242000}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242007 = (g_std_2edoc_2e_3c_3e(v_t_241999, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242006})));
        V v_a_242008 = (g_std_2edoc_2egroup(v_t_242007));
        V v_b_242009 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242010 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str132)}), v_b_242009));
        return (g_std_2edoc_2e_3c_3e(v_a_242008, v_t_242010));
      } else {
        heff_drop_tag(v_x_241200, 3);
        heff_drop(v_t_241202);
        heff_drop(v_t_241998);
        V v_t_242011 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242012 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242018 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam97, 1, 1, (V[]){v_one_242012}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242019 = (g_std_2edoc_2e_3c_3e(v_t_242011, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242018})));
        return (g_std_2edoc_2egroup(v_t_242019));
      }
    }
    case TAG_EWhile: {
      V v_t_242024 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242024) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242024);
        V v_t_242025 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242026 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242032 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam98, 1, 1, (V[]){v_one_242026}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242033 = (g_std_2edoc_2e_3c_3e(v_t_242025, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242032})));
        V v_a_242034 = (g_std_2edoc_2egroup(v_t_242033));
        V v_b_242035 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242036 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str133)}), v_b_242035));
        return (g_std_2edoc_2e_3c_3e(v_a_242034, v_t_242036));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_242024);
        V v_t_242037 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242038 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242044 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam99, 1, 1, (V[]){v_one_242038}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242045 = (g_std_2edoc_2e_3c_3e(v_t_242037, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242044})));
        return (g_std_2edoc_2egroup(v_t_242045));
      }
    }
    case TAG_EFor: {
      V v_t_242052 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242052) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242052);
        V v_t_242053 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242054 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242060 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam100, 1, 1, (V[]){v_one_242054}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242061 = (g_std_2edoc_2e_3c_3e(v_t_242053, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242060})));
        V v_a_242062 = (g_std_2edoc_2egroup(v_t_242061));
        V v_b_242063 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242064 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str134)}), v_b_242063));
        return (g_std_2edoc_2e_3c_3e(v_a_242062, v_t_242064));
      } else {
        heff_drop_tag(v_x_241200, 6);
        heff_drop(v_t_241202);
        heff_drop(v_t_242052);
        V v_t_242065 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242066 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242072 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam101, 1, 1, (V[]){v_one_242066}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242073 = (g_std_2edoc_2e_3c_3e(v_t_242065, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242072})));
        return (g_std_2edoc_2egroup(v_t_242073));
      }
    }
    case TAG_EJump: {
      V v_t_242075 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242075) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242075);
        V v_t_242076 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242077 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242083 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam102, 1, 1, (V[]){v_one_242077}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242084 = (g_std_2edoc_2e_3c_3e(v_t_242076, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242083})));
        V v_a_242085 = (g_std_2edoc_2egroup(v_t_242084));
        V v_b_242086 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242087 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str135)}), v_b_242086));
        return (g_std_2edoc_2e_3c_3e(v_a_242085, v_t_242087));
      } else {
        heff_drop_tag(v_x_241200, 1);
        heff_drop(v_t_241202);
        heff_drop(v_t_242075);
        V v_t_242088 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242089 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242095 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam103, 1, 1, (V[]){v_one_242089}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242096 = (g_std_2edoc_2e_3c_3e(v_t_242088, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242095})));
        return (g_std_2edoc_2egroup(v_t_242096));
      }
    }
    case TAG_EReturn: {
      V v_t_242099 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242099) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242099);
        V v_t_242100 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242101 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242107 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam104, 1, 1, (V[]){v_one_242101}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242108 = (g_std_2edoc_2e_3c_3e(v_t_242100, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242107})));
        V v_a_242109 = (g_std_2edoc_2egroup(v_t_242108));
        V v_b_242110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242111 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str136)}), v_b_242110));
        return (g_std_2edoc_2e_3c_3e(v_a_242109, v_t_242111));
      } else {
        heff_drop_tag(v_x_241200, 2);
        heff_drop(v_t_241202);
        heff_drop(v_t_242099);
        V v_t_242112 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242119 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam105, 1, 1, (V[]){v_one_242113}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242120 = (g_std_2edoc_2e_3c_3e(v_t_242112, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242119})));
        return (g_std_2edoc_2egroup(v_t_242120));
      }
    }
    case TAG_ENest: {
      V v_t_242125 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242125) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242125);
        V v_t_242126 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242127 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242133 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam106, 1, 1, (V[]){v_one_242127}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242134 = (g_std_2edoc_2e_3c_3e(v_t_242126, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242133})));
        V v_a_242135 = (g_std_2edoc_2egroup(v_t_242134));
        V v_b_242136 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242137 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str137)}), v_b_242136));
        return (g_std_2edoc_2e_3c_3e(v_a_242135, v_t_242137));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_242125);
        V v_t_242138 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242139 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242145 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam107, 1, 1, (V[]){v_one_242139}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242146 = (g_std_2edoc_2e_3c_3e(v_t_242138, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242145})));
        return (g_std_2edoc_2egroup(v_t_242146));
      }
    }
    case TAG_IfThen: {
      V v_t_242151 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242151) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242151);
        V v_t_242152 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242159 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam108, 1, 1, (V[]){v_one_242153}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242160 = (g_std_2edoc_2e_3c_3e(v_t_242152, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242159})));
        V v_a_242161 = (g_std_2edoc_2egroup(v_t_242160));
        V v_b_242162 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242163 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str138)}), v_b_242162));
        return (g_std_2edoc_2e_3c_3e(v_a_242161, v_t_242163));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_242151);
        V v_t_242164 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242171 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam109, 1, 1, (V[]){v_one_242165}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242172 = (g_std_2edoc_2e_3c_3e(v_t_242164, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242171})));
        return (g_std_2edoc_2egroup(v_t_242172));
      }
    }
    case TAG_ELetCond: {
      V v_t_242177 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242177) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242177);
        V v_t_242178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242179 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242185 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam110, 1, 1, (V[]){v_one_242179}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242186 = (g_std_2edoc_2e_3c_3e(v_t_242178, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242185})));
        V v_a_242187 = (g_std_2edoc_2egroup(v_t_242186));
        V v_b_242188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242189 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str139)}), v_b_242188));
        return (g_std_2edoc_2e_3c_3e(v_a_242187, v_t_242189));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_242177);
        V v_t_242190 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242191 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242197 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam111, 1, 1, (V[]){v_one_242191}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242198 = (g_std_2edoc_2e_3c_3e(v_t_242190, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242197})));
        return (g_std_2edoc_2egroup(v_t_242198));
      }
    }
    case TAG_ETry: {
      V v_t_242203 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242203) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242203);
        V v_t_242204 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242205 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242211 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam112, 1, 1, (V[]){v_one_242205}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242212 = (g_std_2edoc_2e_3c_3e(v_t_242204, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242211})));
        V v_a_242213 = (g_std_2edoc_2egroup(v_t_242212));
        V v_b_242214 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242215 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str140)}), v_b_242214));
        return (g_std_2edoc_2e_3c_3e(v_a_242213, v_t_242215));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_242203);
        V v_t_242216 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242217 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242223 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam113, 1, 1, (V[]){v_one_242217}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242224 = (g_std_2edoc_2e_3c_3e(v_t_242216, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242223})));
        return (g_std_2edoc_2egroup(v_t_242224));
      }
    }
    case TAG_ECatch: {
      V v_t_242229 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241200));
      if ((heff_dup(v_t_242229) == NTAG(TAG_True))) {
        heff_drop(v_args_241198);
        heff_drop(v_t_242229);
        V v_t_242230 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242231 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241196)}));
        V v_d_242237 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam114, 1, 1, (V[]){v_one_242231}); V a_2 = v_t_241202; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241202); r_; });
        V v_t_242238 = (g_std_2edoc_2e_3c_3e(v_t_242230, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242237})));
        V v_a_242239 = (g_std_2edoc_2egroup(v_t_242238));
        V v_b_242240 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241196, v_x_241200}));
        V v_t_242241 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str141)}), v_b_242240));
        return (g_std_2edoc_2e_3c_3e(v_a_242239, v_t_242241));
      } else {
        heff_drop_tag(v_x_241200, 4);
        heff_drop(v_t_241202);
        heff_drop(v_t_242229);
        V v_t_242242 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241196), v_h_241197}));
        V v_one_242243 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241196}));
        V v_d_242249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam115, 1, 1, (V[]){v_one_242243}); V a_2 = v_args_241198; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241198); r_; });
        V v_t_242250 = (g_std_2edoc_2e_3c_3e(v_t_242242, heff_tag_at_n(v_ru_24x1_241199_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242249})));
        return (g_std_2edoc_2egroup(v_t_242250));
      }
    }
    default: return heff_nomatch(v_x_241200);
    }
  }
  default: return heff_nomatch(v_x1_241199);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args) {
  V v_env_242251 = args[0];
  V v_rest_242252 = args[1];
  V v_e_242253 = args[2];
  switch (heff_tag_of(v_e_242253)) {
  case TAG_Atom: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_242270 = heff_field(v_e_242253, 0);
    V v_fs_242271 = heff_field(v_e_242253, 1);
    V v_commas_242272 = heff_field(v_e_242253, 2);
    V v_c_242273 = heff_field(v_e_242253, 3);
    heff_take_n(v_e_242253, 15ULL, 4);
    switch (heff_tag_of(v_fs_242271)) {
    case TAG_Nil: {
      heff_drop(v_rest_242252);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_242251;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242270, v_fs_242271, v_commas_242272, v_c_242273});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_242274 = heff_dup(heff_field(v_fs_242271, 0));
      V v_rest2_242275 = heff_dup(heff_field(v_fs_242271, 1));
      switch (heff_tag_of(v_rest2_242275)) {
      case TAG_Nil: {
        V v_t_242276 = ({ V a_0 = v_rest_242252; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_242252); r_; });
        if ((heff_dup(v_t_242276) == NTAG(TAG_True))) {
          heff_drop(v_t_242276);
          V v_x1_242277 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_242274));
          if ((heff_dup(v_x1_242277) == NTAG(TAG_True))) {
            heff_drop(v_d_242274);
            heff_drop(v_x1_242277);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_242251;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242270, v_fs_242271, v_commas_242272, v_c_242273});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_242277);
            switch (heff_tag_of(v_commas_242272)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_242271, 2);
              V v_t_242278 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242251), v_o_242270));
              V v_t_242279 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242251), v_d_242274}));
              V v_t_242280 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242251, v_c_242273));
              V v_t_242281 = (g_std_2edoc_2e_3c_3e(v_t_242279, v_t_242280));
              return (g_std_2edoc_2e_3c_3e(v_t_242278, v_t_242281));
            }
            case TAG_Cons: {
              heff_drop(v_d_242274);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_242251;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242270, v_fs_242271, v_commas_242272, v_c_242273});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_242272);
            }
          }
        } else {
          heff_drop(v_d_242274);
          heff_drop(v_t_242276);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_242251;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242270, v_fs_242271, v_commas_242272, v_c_242273});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_242275, 0ULL, 2);
        heff_drop(v_rest_242252);
        heff_drop(v_d_242274);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_242251;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242270, v_fs_242271, v_commas_242272, v_c_242273});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_242275);
      }
    }
    default: return heff_nomatch(v_fs_242271);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242252);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242251;
    args[1] = v_e_242253;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_242253);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args) {
  V v_env_242408 = args[0];
  V v_b_242409 = args[1];
  switch (heff_tag_of(v_b_242409)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_242473 = heff_field(v_b_242409, 0);
    heff_take_n(v_b_242409, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242408, v_t_242473));
  }
  case TAG_BImp: {
    V v_o_242474 = heff_field(v_b_242409, 0);
    V v_x_242475 = heff_field(v_b_242409, 1);
    V v_c_242476 = heff_field(v_b_242409, 2);
    heff_take_n(v_b_242409, 7ULL, 3);
    V v_t_242477 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242408), v_o_242474));
    V v_t_242478 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242408), v_x_242475));
    V v_t_242479 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242408, v_c_242476));
    V v_t_242480 = (g_std_2edoc_2e_3c_3e(v_t_242478, v_t_242479));
    return (g_std_2edoc_2e_3c_3e(v_t_242477, v_t_242480));
  }
  case TAG_BAnn: {
    V v_o_242481 = heff_field(v_b_242409, 0);
    V v_x_242482 = heff_field(v_b_242409, 1);
    V v_cc_242483 = heff_field(v_b_242409, 2);
    V v_ty_242484 = heff_field(v_b_242409, 3);
    V v_c_242485 = heff_field(v_b_242409, 4);
    heff_take_n(v_b_242409, 31ULL, 5);
    V v_t_242486 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242408), v_o_242481));
    V v_a_242487 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242408), v_x_242482));
    V v_a_242488 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242408), v_cc_242483));
    V v_b_242489 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242408), v_ty_242484}));
    V v_t_242490 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str142)}), v_b_242489));
    V v_t_242491 = (g_std_2edoc_2e_3c_3e(v_a_242488, v_t_242490));
    V v_t_242492 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str143)}), v_t_242491));
    V v_t_242493 = (g_std_2edoc_2e_3c_3e(v_a_242487, v_t_242492));
    V v_t_242494 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242408, v_c_242485));
    V v_t_242495 = (g_std_2edoc_2e_3c_3e(v_t_242493, v_t_242494));
    return (g_std_2edoc_2e_3c_3e(v_t_242486, v_t_242495));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242408;
    args[1] = v_b_242409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_242409);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args) {
  V v_env_242566 = args[0];
  V v_rest_242567 = args[1];
  V v_r_242568 = args[2];
  switch (heff_tag_of(v_r_242568)) {
  case TAG_Atom: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242627 = heff_field(v_r_242568, 0);
    V v_e_242628 = heff_field(v_r_242568, 1);
    heff_take_n(v_r_242568, 3ULL, 2);
    V v_a_242629 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242566), v_op_242627));
    V v_b_242630 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_242566, v_rest_242567, v_e_242628}));
    V v_t_242631 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str144)}), v_b_242630));
    return (g_std_2edoc_2e_3c_3e(v_a_242629, v_t_242631));
  }
  case TAG_Ann: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242567);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242566;
    args[1] = v_r_242568;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242568);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args) {
  V v_env_242714 = args[0];
  V v_r_242715 = args[1];
  switch (heff_tag_of(v_r_242715)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242774 = heff_field(v_r_242715, 0);
    V v_e_242775 = heff_field(v_r_242715, 1);
    heff_take_n(v_r_242715, 3ULL, 2);
    V v_a_242776 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242714), v_op_242774));
    V v_b_242777 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_242714, v_e_242775}));
    V v_t_242778 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str145)}), v_b_242777));
    return (g_std_2edoc_2e_3c_3e(v_a_242776, v_t_242778));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242714;
    args[1] = v_r_242715;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242715);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args) {
  V v_r_242874 = args[0];
  V v_env_242861 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242875 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242874));
  V v_t_242876;
  if ((heff_dup(v_x1_242875) == NTAG(TAG_True))) {
    heff_drop(v_x1_242875);
    v_t_242876 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242875);
    v_t_242876 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242877 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242861, v_r_242874}));
  return (g_std_2edoc_2e_3c_3e(v_t_242876, v_t_242877));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args) {
  V v_r_242883 = args[0];
  V v_env_242861 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242884 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242883));
  V v_t_242885;
  if ((heff_dup(v_x1_242884) == NTAG(TAG_True))) {
    heff_drop(v_x1_242884);
    v_t_242885 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242884);
    v_t_242885 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242886 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242861, v_r_242883}));
  return (g_std_2edoc_2e_3c_3e(v_t_242885, v_t_242886));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args) {
  V v_env_242861 = args[0];
  V v_first_242862 = args[1];
  V v_rest_242863 = args[2];
  V v_f_242864 = heff_dup(heff_rfield(v_env_242861, 6));
  HeffT2 v_t_242865 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_242864), heff_dup(v_rest_242863)));
  {
    V v_field_242867 = v_t_242865.f[1];
    int64_t v_tag_242866 = ((int64_t)v_t_242865.f[0]);
    V v_t_242872;
    if ((v_tag_242866 == ((int64_t)0ULL))) {
      V v_it1_242869 = v_field_242867;
      switch (heff_tag_of(v_it1_242869)) {
      case TAG_Nil: {
        heff_drop(v_f_242864);
        v_t_242872 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_242870 = heff_field(v_it1_242869, 0);
        V v_os_242871 = heff_field(v_it1_242869, 1);
        heff_take_n(v_it1_242869, 3ULL, 2);
        v_t_242872 = ({ V a_0 = v_f_242864; V a_1 = v_o_242870; V a_2 = v_os_242871; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_242871); r_; });
        break;
      }
      default: heff_nomatch(v_it1_242869);
      }
    } else {
      heff_drop(v_f_242864);
      heff_drop(v_field_242867);
      v_t_242872 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_242872)) {
    case TAG_Nothing: {
      V v_t_242873 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242861), v_first_242862}));
      V v_t_242878 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam121, 1, 1, (V[]){v_env_242861}); V a_2 = v_rest_242863; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242863); r_; });
      V v_t_242879 = (g_std_2edoc_2e_3c_3e(v_t_242873, v_t_242878));
      return (g_std_2edoc_2egroup(v_t_242879));
    }
    case TAG_Just: {
      V v_m_242880 = heff_field(v_t_242872, 0);
      heff_take_n(v_t_242872, 1ULL, 1);
      V v_t_242881 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_242861, 6)), heff_dup(v_m_242880), v_rest_242863));
      if ((heff_dup(v_t_242881) == NTAG(TAG_True))) {
        heff_drop(v_m_242880);
        heff_drop(v_t_242881);
        V v_t_242882 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242861), v_first_242862}));
        V v_t_242887 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam122, 1, 1, (V[]){v_env_242861}); V a_2 = v_rest_242863; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242863); r_; });
        V v_t_242888 = (g_std_2edoc_2e_3c_3e(v_t_242882, v_t_242887));
        return (g_std_2edoc_2egroup(v_t_242888));
      } else {
        heff_drop(v_t_242881);
        V v_t_242889 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242861, v_m_242880, v_first_242862, NTAG(TAG_Nil), v_rest_242863}));
        return (g_std_2edoc_2egroup(v_t_242889));
      }
    }
    default: return heff_nomatch(v_t_242872);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args) {
  V v_env_242890 = args[0];
  V v_m_242891 = args[1];
  V v_f_242892 = args[2];
  V v_acc_242893 = args[3];
  V v_rs_242894 = args[4];
  switch (heff_tag_of(v_rs_242894)) {
  case TAG_Nil: {
    heff_drop(v_m_242891);
    V v_t_242895 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242893));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_242890;
    args[1] = v_f_242892;
    args[2] = v_t_242895;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_242896 = heff_field(v_rs_242894, 0);
    V v_rest2_242897 = heff_field(v_rs_242894, 1);
    heff_take_n(v_rs_242894, 3ULL, 2);
    switch (heff_tag_of(v_r_242896)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_242956 = heff_dup(heff_field(v_r_242896, 0));
      V v_e_242957 = heff_dup(heff_field(v_r_242896, 1));
      V v_t_242958 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_242890, 6)), heff_dup(v_m_242891), heff_dup(heff_rfield(v_op_242956, 1))));
      switch (heff_tag_of(v_t_242958)) {
      case TAG_Tighter: {
        heff_drop_rec(v_op_242956, 9);
        heff_drop(v_e_242957);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242890;
        args[1] = v_m_242891;
        args[2] = v_f_242892;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
        args[4] = v_rest2_242897;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_rec(v_op_242956, 9);
        heff_drop(v_e_242957);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242890;
        args[1] = v_m_242891;
        args[2] = v_f_242892;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
        args[4] = v_rest2_242897;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_242958_24Same = heff_take_reuse_n(v_t_242958, 0ULL, 1);
        V v_t_242960 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242893));
        V v_t_242961 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_242890), v_f_242892, v_t_242960}));
        V v_x1_242962 = ({ V a_0 = v_r_242896; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_242896, 2); r_; });
        V v_t_242963;
        if ((heff_dup(v_x1_242962) == NTAG(TAG_True))) {
          heff_drop(v_x1_242962);
          v_t_242963 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_242962);
          v_t_242963 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_242964 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242890), v_op_242956));
        V v_b_242965 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242890, v_m_242891, v_e_242957, NTAG(TAG_Nil), v_rest2_242897}));
        V v_t_242966 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_242958_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str146)}), v_b_242965));
        V v_t_242967 = (g_std_2edoc_2e_3c_3e(v_a_242964, v_t_242966));
        V v_t_242968 = (g_std_2edoc_2e_3c_3e(v_t_242963, v_t_242967));
        return (g_std_2edoc_2e_3c_3e(v_t_242961, v_t_242968));
      }
      case TAG_Unrelated: {
        heff_drop_rec(v_op_242956, 9);
        heff_drop(v_e_242957);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242890;
        args[1] = v_m_242891;
        args[2] = v_f_242892;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
        args[4] = v_rest2_242897;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_242958, 0ULL, 1);
        heff_drop_rec(v_op_242956, 9);
        heff_drop(v_e_242957);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242890;
        args[1] = v_m_242891;
        args[2] = v_f_242892;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
        args[4] = v_rest2_242897;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_242958);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetMut: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAssign: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWhile: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFor: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EJump: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EReturn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENest: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_IfThen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetCond: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETry: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECatch: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242890;
      args[1] = v_m_242891;
      args[2] = v_f_242892;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242896, v_acc_242893});
      args[4] = v_rest2_242897;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_242896);
    }
  }
  default: return heff_nomatch(v_rs_242894);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args) {
  V v_env_243052 = args[0];
  V v_a_243053 = args[1];
  switch (heff_tag_of(v_a_243053)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_243134 = heff_field(v_a_243053, 0);
    V v_arrow_243135 = heff_field(v_a_243053, 1);
    V v_body_243136 = heff_field(v_a_243053, 2);
    heff_take_n(v_a_243053, 7ULL, 3);
    V v_a_243137 = ({ V a_0 = heff_dup(v_env_243052); V a_1 = v_p_243134; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_243134); r_; });
    V v_b_243138 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243052), v_arrow_243135));
    V v_t_243139 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str147)}), v_b_243138));
    V v_t_243140 = (g_std_2edoc_2e_3c_3e(v_a_243137, v_t_243139));
    V v_t_243141 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243052, v_body_243136}));
    return (g_std_2edoc_2e_3c_3e(v_t_243140, v_t_243141));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243052;
    args[1] = v_a_243053;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_243053);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args) {
  V v_env_243201 = args[0];
  V v_s_243202 = args[1];
  switch (heff_tag_of(v_s_243202)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_243294 = heff_field(v_s_243202, 0);
    V v_arrow_243295 = heff_field(v_s_243202, 1);
    V v_e_243296 = heff_field(v_s_243202, 2);
    heff_take_n(v_s_243202, 7ULL, 3);
    V v_a_243297 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243201), v_x_243294));
    V v_b_243298 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243201), v_arrow_243295));
    V v_t_243299 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str148)}), v_b_243298));
    V v_t_243300 = (g_std_2edoc_2e_3c_3e(v_a_243297, v_t_243299));
    V v_t_243301 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243201, v_e_243296}));
    return (g_std_2edoc_2e_3c_3e(v_t_243300, v_t_243301));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243201;
    args[1] = v_s_243202;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_243202);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args) {
  V v_env_243350 = args[0];
  V v_f_243351 = args[1];
  switch (heff_tag_of(v_f_243351)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_243378 = heff_field(v_f_243351, 0);
    V v_eq_243379 = heff_field(v_f_243351, 1);
    V v_e_243380 = heff_field(v_f_243351, 2);
    heff_take_n(v_f_243351, 7ULL, 3);
    V v_a_243381 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243350), v_x_243378}));
    V v_b_243382 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243350), v_eq_243379));
    V v_t_243383 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str149)}), v_b_243382));
    V v_t_243384 = (g_std_2edoc_2e_3c_3e(v_a_243381, v_t_243383));
    V v_t_243385 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243350, v_e_243380}));
    return (g_std_2edoc_2e_3c_3e(v_t_243384, v_t_243385));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_243391 = heff_field(v_f_243351, 0);
    V v_eq_243392 = heff_field(v_f_243351, 1);
    V v_e_243393 = heff_field(v_f_243351, 2);
    heff_take_n(v_f_243351, 7ULL, 3);
    V v_a_243394 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243350), v_x_243391));
    V v_b_243395 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243350), v_eq_243392));
    V v_t_243396 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str150)}), v_b_243395));
    V v_t_243397 = (g_std_2edoc_2e_3c_3e(v_a_243394, v_t_243396));
    V v_t_243398 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243350, v_e_243393}));
    return (g_std_2edoc_2e_3c_3e(v_t_243397, v_t_243398));
  }
  case TAG_EFDefault: {
    V v_d_243399 = heff_field(v_f_243351, 0);
    V v_eq_243400 = heff_field(v_f_243351, 1);
    V v_e_243401 = heff_field(v_f_243351, 2);
    heff_take_n(v_f_243351, 7ULL, 3);
    V v_a_243402 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243350), v_d_243399}));
    V v_b_243403 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243350), v_eq_243400));
    V v_t_243404 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str151)}), v_b_243403));
    V v_t_243405 = (g_std_2edoc_2e_3c_3e(v_a_243402, v_t_243404));
    V v_t_243406 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243350, v_e_243401}));
    return (g_std_2edoc_2e_3c_3e(v_t_243405, v_t_243406));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetCond: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243350;
    args[1] = v_f_243351;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_243351);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = heff_take_field(v_t_244, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2412;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = heff_get_n(v_t_244, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop_rec(v_t_244, 9);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2412 = heff_get_n(v_t_244, 8, 9);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str14, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DInstance: {
    V v_n_2411 = heff_field(v_d_240, 1);
    V v_x2_2414 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_DEqn: {
    V v_n_2417 = heff_field(v_d_240, 0);
    V v_x2_2422 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2417)));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DMutual: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str14);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0, 7, "doctest");
Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DFixity: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DSig: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DInstance: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DEqn: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DData: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DType: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTheory: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DMutual: {
    V v_ds_2433 = heff_field(v_d_241, 1);
    V v_x1_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ds_2433)));
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 7);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_x1_2434, 0);
      heff_take_n(v_x1_2434, 1ULL, 2);
      switch (heff_tag_of(v_x_2435)) {
      case TAG_DImport: {
        heff_take_n(v_x_2435, 0ULL, 1);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DFixity: {
        heff_take_n(v_x_2435, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DSig: {
        heff_take_n(v_x_2435, 0ULL, 3);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DInstance: {
        heff_take_n(v_x_2435, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DEqn: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DData: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DType: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTheory: {
        heff_take_n(v_x_2435, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DMutual: {
        heff_take_n(v_x_2435, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DPrimitive: {
        heff_take_n(v_x_2435, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTest: {
        heff_take_n(v_x_2435, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DWatch: {
        V v_w_2475 = heff_field(v_x_2435, 0);
        V v_e_2476 = heff_field(v_x_2435, 1);
        heff_take_n(v_x_2435, 3ULL, 2);
        V v_t_2477 = heff_strEq(heff_get_n(v_w_2475, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0));
        V v_t_2478 = (g_heff_2esyntax_2ecst_2elastE(v_e_2476));
        V v_t_2479 = heff_intAdd(heff_get_n(v_t_2478, 7, 9), MK_INT(1LL));
        HeffT2 v_t_2480 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_t_2479; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2485;
        {
          V v_field_2482 = v_t_2480.f[1];
          int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
          if ((v_tag_2481 == ((int64_t)0ULL))) {
            V v_x_2484 = v_field_2482;
            v_t_2485 = v_x_2484;
          } else {
            heff_drop(v_field_2482);
            v_t_2485 = NTAG(TAG_Nil);
          }
        }
        return ({ V a_0 = v_t_2477; V a_1 = v_t_2485; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines(a_0, a_1)); heff_drop(v_t_2477); r_; });
      }
      default: return heff_nomatch(v_x_2435);
      }
    }
    default: return heff_nomatch(v_x1_2434);
    }
  }
  case TAG_DPrimitive: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTest: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DWatch: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eblockExpect(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_eof_243, 7, 9)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_247);
        v_t_2410 = NTAG(TAG_Nil);
      }
    }
    return ({ V a_0 = v_env_240; V a_1 = v_t_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_2410); r_; });
  }
  case TAG_Cons: {
    V v_d_2411 = heff_field(v_x5_244, 0);
    V v_ds_2412 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2411));
    V v_t_2454;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_DImport: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2452 = heff_dup(heff_field(v_d_2411, 0));
      v_t_2454 = heff_strEq(heff_get_n(v_w_2452, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2482;
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
      V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2455, v_t_2456, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2411)})));
      V v_t_2459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2411); r_; });
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2459, v_eof_243, v_ds_2412));
      v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2460));
    } else {
      heff_drop(v_t_2454);
      V v_t_2461 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2461);
        V v_t_2462 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2411));
        V v_t_2464 = ({ V a_0 = v_t_2463; V a_1 = heff_dup(v_d_2411); V a_2 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
        V v_t_2465 = (g_heff_2esyntax_2ecst_2elastD(v_t_2464));
        V v_t_2466 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2462, v_t_2465));
        V v_t_2467 = ({ V a_0 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2411); r_; });
        V v_t_2468 = ({ V a_0 = v_t_2467; V a_1 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2467); r_; });
        V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2468));
        v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2466, v_t_2469));
      } else {
        heff_drop(v_t_2461);
        V v_expect_2470 = (g_heff_2esyntax_2efmt_2elayout_2eblockExpect(heff_dup(v_env_240), v_d_2411));
        V v_t_2471 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2472 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
        V v_t_2474 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2471, v_t_2472, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2411)})));
        V v_d_2475 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_2470));
        V v_t_2476 = (g_heff_2esyntax_2ecst_2elastD(v_d_2411));
        V v_t_2477 = heff_intAdd(heff_get_n(v_t_2476, 7, 9), MK_INT(1LL));
        V v_t_2478 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_2470; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_2470); r_; });
        V v_t_2479 = (g_heff_2esyntax_2efmt_2elayout_2eleadLaid(v_env_240, v_t_2477, v_t_2478));
        V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_2479, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2412));
        V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2475}), v_t_2480));
        v_t_2482 = (g_std_2edoc_2e_3c_3e(v_t_2474, v_t_2481));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2482));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2457 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2457; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2473 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2473; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = ({ V b_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5); V a_2 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  return heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    V v_t_245 = (g_heff_2esyntax_2efmt_2eimports_2eexposingToks(heff_rfield(v_hdr_242, 1)));
    V v_t_246 = (g_list_2emap_24s1845612977x612508518(heff_get_n(v_hdr_242, 0, 3)));
    V v_t_247 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_take_field(v_l_243, 0), v_t_245, v_t_246));
    V v_t_248 = (g_list_2esortBy_24s88152486x2058486153(v_t_247));
    HeffT2 v_t_249 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_248, heff_get_n(v_l_243, 2, 3)));
    V v_t_2413;
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_t_2412 = ({ V rv_6 = v_f_240; V rr_ = heff_rec_reuse_nf(v_field_2411, 63ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      v_t_2413 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2410, v_t_2412});
    }
    return (g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(v_t_2413));
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_hdr_242, 3);
    heff_drop_rec(v_l_243, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_244)}});
  }
}