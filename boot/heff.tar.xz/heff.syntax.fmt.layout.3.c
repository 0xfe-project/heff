// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkChain 10459
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_elseOf 646984731
#define LBL_env 310119
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_ifLink 754803170
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_ops 319788
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2echain(V);
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V, V);
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1221903513x233153387(V);
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a);
extern Clo g_list_2emap_24s1221903513x233153387_clo;
V g_list_2emap_24s422923909x1655406376(V);
V g_list_2emap_24s422923909x1655406376_entry(V self, V *a);
extern Clo g_list_2emap_24s422923909x1655406376_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s650596433x61515523(V, V);
V g_std_2edoc_2econcatWith_24s650596433x61515523_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s650596433x61515523_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_x1_245;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_x1_245 = NTAG(TAG_Nil);
  } else {
    V v_x2_243 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_x1_245 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      v_x1_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
  }
  V v_t_2414;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    V v_t_2411;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
      v_t_2411 = NTAG(TAG_Nil);
    } else {
      V v_x2_249 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
    }
    V v_ds_2412 = (g_list_2emap_24s1221903513x233153387(v_t_2411));
    V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2412; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2412); r_; });
    v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_x2_2415 = (g_map_2elookup_24s567992785x1569911877(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 2)));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_ds_2418 = (g_list_2emap_24s422923909x1655406376(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2418; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2418); r_; });
  V v_s_2420 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2422;
  if (heff_strEq_c(heff_dup(v_s_2420), ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0))) {
    heff_drop(v_s_2420);
    v_t_2422 = NTAG(TAG_None);
  } else {
    v_t_2422 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2420});
  }
  V v_t_2424;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2424 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2424 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2424));
  V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2425));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2426);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str2, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_x2_247 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str0), heff_dup(heff_rfield(v_c_242, 0)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_s_2410 = ((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_s_2410 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2412;
    if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2esyntax_2efmt_2elayout_2eleadDocs_str2))) {
      heff_drop(v_s_2410);
      v_t_2412 = NTAG(TAG_None);
    } else {
      v_t_2412 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2410});
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
    V v_t_2415 = (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_2414));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2415);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2473 = heff_field(v_e_240, 3);
    V t_0 = v_body_2473;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2436 = heff_field(v_e_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2436, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2echain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2echain_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2echain(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EParen: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Named: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Tup: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Braces: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Update: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EUSet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_InstB: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFSet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFDefault: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Sum: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECon: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EField: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ENeg: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_App: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Op: {
    V v_a_2451 = heff_field(v_e_240, 0);
    V v_op_2452 = heff_field(v_e_240, 1);
    V v_b_2453 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_x4_2454 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_dup(v_b_2453)));
    switch (heff_tag_of(v_x4_2454)) {
    case TAG_MkChain: {
      V v_bf_2455 = heff_field(v_x4_2454, 0);
      V v_rest_2456 = heff_field(v_x4_2454, 1);
      V v_ru_24x4_2454_24MkChain = heff_take_reuse_n(v_x4_2454, 3ULL, 2);
      V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2452), v_rest_2456));
      if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
        heff_drop(v_b_2453);
        heff_drop(v_t_2457);
        V v_t_2458 = heff_tag_at_n(v_ru_24x4_2454_24MkChain, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2452, v_bf_2455}), v_rest_2456});
        return heff_tag_n(TAG_MkChain, 2, (V[]){v_a_2451, v_t_2458});
      } else {
        heff_drop(v_bf_2455);
        heff_drop(v_rest_2456);
        heff_drop(v_t_2457);
        V v_t_2459 = heff_tag_at_n(v_ru_24x4_2454_24MkChain, TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2452, v_b_2453}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_MkChain, 2, (V[]){v_a_2451, v_t_2459});
      }
    }
    default: return heff_nomatch(v_x4_2454);
    }
  }
  case TAG_Ops: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_OpRhs: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Ann: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BVar: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BImp: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_BAnn: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Lam: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Case: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAlt: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_If: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Do: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ESBind: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkChain, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2echain_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2echain(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2458 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2458, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = (g_list_2edrop(MK_INT(1LL), v_commas_243));
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eopsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopsOf(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_f_240, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Atom: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EParen: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Named: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Tup: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Braces: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Update: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EUSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_InstB: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFSet: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFDefault: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Sum: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECon: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EField: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ENeg: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_App: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Op: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Ops: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRhs: {
      V v_op_2459 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2463 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0, 1, 1, (V[]){heff_dup(v_op_2459)}), heff_rfield(v_f_240, 0)));
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nothing: {
        heff_drop_rec(v_f_240, 2);
        heff_drop(v_rs_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_rec(v_op_2459, 9);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ru_24t_2463_24Just = heff_take_reuse_n(v_t_2463, 0ULL, 1);
        V v_x2_2465 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(v_f_240, v_rs_243));
        switch (heff_tag_of(v_x2_2465)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop_rec(v_op_2459, 9);
          heff_drop_cell(v_ru_24t_2463_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_ops_2466 = heff_field(v_x2_2465, 0);
          heff_take_n(v_x2_2465, 1ULL, 1);
          V v_t_2467 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_op_2459, 1, 9), v_ops_2466});
          return heff_tag_at_n(v_ru_24t_2463_24Just, TAG_Just, 1, (V[]){v_t_2467});
        }
        default: return heff_nomatch(v_x2_2465);
        }
      }
      default: return heff_nomatch(v_t_2463);
      }
    }
    case TAG_Ann: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BImp: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_BAnn: {
      heff_take_n(v_x21_242, 0ULL, 5);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Lam: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Case: {
      heff_take_n(v_x21_242, 0ULL, 4);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAlt: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_If: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Do: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ESBind: {
      heff_take_n(v_x21_242, 0ULL, 3);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x21_242, 0ULL, 6);
      heff_drop_rec(v_f_240, 2);
      heff_drop(v_rs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2eopsOf(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2eopsOf_lam0(V self, V *args) {
  V v_g_2461 = args[0];
  V v_op_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_op_2459, 1, 9)}));
  return ({ V a_0 = v_t_2462; V b_1 = heff_get_n(v_g_2461, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2458 = heff_field(v_r_242, 0);
    V v_t_2460 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2458, 1))));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2460, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2460, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2413;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      V v_x1_249;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        v_x1_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        v_x1_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_Nil: {
        v_t_2412 = heff_get_n(v_t_246, 8, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        heff_drop_rec(v_t_246, 9);
        v_t_2412 = heff_get_n(v_x_2410, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2414 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2415 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2417 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2414, v_t_2415, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2418 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2417, v_t_2418));
    V v_t_2420 = (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2419));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2420));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2416 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2416;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam92_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam19_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam22_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam23_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam83_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam84_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam85_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam86_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam87_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam90_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam91_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam92_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam93_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c(heff_dup(v_i_2411), MK_INT(0LL))) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2440 = args[0];
  V v_e_2441 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2440));
  V v_b_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_2441}));
  V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2443));
  V v_t_2445 = (g_std_2edoc_2e_3c_3e(v_a_2442, v_t_2444));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2445));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  V v_d_2453 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2456 = heff_intSub(v_k_2454, v_i_2455);
  if (heff_intEq_c(heff_dup(v_i_2456), MK_INT(0LL))) {
    heff_drop(v_i_2456);
    return v_d_2453;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2456, v_d_2453});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2454 = args[0];
  V v_d_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2454, v_d_2453})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_comma_2470 = args[0];
  V v_f_2471 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2472 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2470));
  V v_d_2473 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2471}));
  V v_t_2474 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2473})));
  V v_t_2475 = (g_std_2edoc_2e_3c_3e(v_a_2472, v_t_2474));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2475));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_i_2483 = args[0];
  V v_k_2482 = heff_env(self)[0];
  V v_d_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2484 = heff_intSub(v_k_2482, v_i_2483);
  if (heff_intEq_c(heff_dup(v_i_2484), MK_INT(0LL))) {
    heff_drop(v_i_2484);
    return v_d_2481;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2484, v_d_2481});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_k_2482 = args[0];
  V v_d_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 2, (V[]){v_k_2482, v_d_2481})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_comma_24111 = args[0];
  V v_f_24112 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24113 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24111));
  V v_d_24114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24112}));
  V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24114})));
  V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24115));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24116));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_i_24126 = args[0];
  V v_k_24125 = heff_env(self)[0];
  V v_d_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24127 = heff_intSub(v_k_24125, v_i_24126);
  if (heff_intEq_c(heff_dup(v_i_24127), MK_INT(0LL))) {
    heff_drop(v_i_24127);
    return v_d_24124;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24127, v_d_24124});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_k_24125 = args[0];
  V v_d_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 2, (V[]){v_k_24125, v_d_24124})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_bar_24184 = args[0];
  V v_a_24185 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24186 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24184));
  V v_b_24187 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24185}));
  V v_t_24188 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24187));
  V v_t_24189 = (g_std_2edoc_2e_3c_3e(v_a_24186, v_t_24188));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24189));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_i_24197 = args[0];
  V v_k_24196 = heff_env(self)[0];
  V v_d_24195 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24198 = heff_intSub(v_k_24196, v_i_24197);
  if (heff_intEq_c(heff_dup(v_i_24198), MK_INT(0LL))) {
    heff_drop(v_i_24198);
    return v_d_24195;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24198, v_d_24195});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_k_24196 = args[0];
  V v_d_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 2, (V[]){v_k_24196, v_d_24195})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_a_24205 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24206 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24205}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24206));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_r_24226 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24224 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24224, v_r_24226}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24227));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_i_24341 = args[0];
  V v_k_24340 = heff_env(self)[0];
  V v_d_24339 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24342 = heff_intSub(v_k_24340, v_i_24341);
  if (heff_intEq_c(heff_dup(v_i_24342), MK_INT(0LL))) {
    heff_drop(v_i_24342);
    return v_d_24339;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24342, v_d_24339});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_k_24340 = args[0];
  V v_d_24339 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 2, (V[]){v_k_24340, v_d_24339})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_b_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_b_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e1_2435}));
      V v_ds_2446 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2431, v_more_2436));
      V v_t_2447 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2446; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2446); r_; });
      V v_t_2448 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2449 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2448));
      V v_t_2450 = (g_std_2edoc_2e_3c_3e(v_t_2447, v_t_2449));
      V v_t_2451 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2450));
      V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2451));
      V v_d_2453 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2452));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2453})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Braces: {
    V v_o_2458 = heff_field(v_e0_241, 0);
    V v_fs_2459 = heff_field(v_e0_241, 1);
    V v_commas_2460 = heff_field(v_e0_241, 2);
    V v_c_2461 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2459)) {
    case TAG_Nil: {
      heff_drop(v_commas_2460);
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      return (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2463));
    }
    case TAG_Cons: {
      V v_f1_2464 = heff_field(v_fs_2459, 0);
      V v_more_2465 = heff_field(v_fs_2459, 1);
      V v_ru_24fs_2459_24Cons = heff_take_reuse_n(v_fs_2459, 3ULL, 2);
      V v_a_2466 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2458));
      V v_d_2467 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2464}));
      V v_t_2468 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2459_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2467})));
      V v_t_2469 = (g_std_2edoc_2e_3c_3e(v_a_2466, v_t_2468));
      V v_ds_2476 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2460, v_more_2465));
      V v_t_2477 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2476; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2476); r_; });
      V v_t_2478 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2461));
      V v_t_2479 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_2478));
      V v_t_2480 = (g_std_2edoc_2e_3c_3e(v_t_2477, v_t_2479));
      V v_d_2481 = (g_std_2edoc_2e_3c_3e(v_t_2469, v_t_2480));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 1, 1, (V[]){v_d_2481})})));
    }
    default: return heff_nomatch(v_fs_2459);
    }
  }
  case TAG_Update: {
    V v_o_2486 = heff_field(v_e0_241, 0);
    V v_r_2487 = heff_field(v_e0_241, 1);
    V v_bar_2488 = heff_field(v_e0_241, 2);
    V v_fs_2489 = heff_field(v_e0_241, 3);
    V v_commas_2490 = heff_field(v_e0_241, 4);
    V v_c_2491 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_2489)) {
    case TAG_Nil: {
      heff_drop(v_commas_2490);
      V v_a_2492 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2486));
      V v_a_2493 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_2487}));
      V v_a_2494 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2488));
      V v_b_2495 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2491));
      V v_t_2496 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_2495));
      V v_b_2497 = (g_std_2edoc_2e_3c_3e(v_a_2494, v_t_2496));
      V v_t_2498 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_b_2497));
      V v_b_2499 = (g_std_2edoc_2e_3c_3e(v_a_2493, v_t_2498));
      V v_t_24100 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_b_2499));
      return (g_std_2edoc_2e_3c_3e(v_a_2492, v_t_24100));
    }
    case TAG_Cons: {
      V v_f1_24101 = heff_field(v_fs_2489, 0);
      V v_more_24102 = heff_field(v_fs_2489, 1);
      V v_ru_24fs_2489_24Cons = heff_take_reuse_n(v_fs_2489, 3ULL, 2);
      V v_a_24103 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2486));
      V v_d_24104 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_2487}));
      V v_t_24105 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_2489_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24104})));
      V v_t_24106 = (g_std_2edoc_2e_3c_3e(v_a_24103, v_t_24105));
      V v_a_24107 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2488));
      V v_d_24108 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24101}));
      V v_t_24109 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24108})));
      V v_t_24110 = (g_std_2edoc_2e_3c_3e(v_a_24107, v_t_24109));
      V v_ds_24117 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 2, 1, (V[]){heff_dup(v_env_240)}), v_commas_2490, v_more_24102));
      V v_t_24118 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24117; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24117); r_; });
      V v_t_24119 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2491));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24119));
      V v_t_24121 = (g_std_2edoc_2e_3c_3e(v_t_24118, v_t_24120));
      V v_t_24122 = (g_std_2edoc_2e_3c_3e(v_t_24110, v_t_24121));
      V v_t_24123 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24122));
      V v_d_24124 = (g_std_2edoc_2e_3c_3e(v_t_24106, v_t_24123));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 1, 1, (V[]){v_d_24124})})));
    }
    default: return heff_nomatch(v_fs_2489);
    }
  }
  case TAG_EUSet: {
    V v_x_24129 = heff_field(v_e0_241, 0);
    V v_eq_24130 = heff_field(v_e0_241, 1);
    V v_e_24131 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24132 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24129}));
    V v_b_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24130));
    V v_t_24134 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24133));
    V v_t_24135 = (g_std_2edoc_2e_3c_3e(v_a_24132, v_t_24134));
    V v_t_24136 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24131}));
    return (g_std_2edoc_2e_3c_3e(v_t_24135, v_t_24136));
  }
  case TAG_InstB: {
    V v_o_24137 = heff_field(v_e0_241, 0);
    V v_o2_24138 = heff_field(v_e0_241, 1);
    V v_d_24139 = heff_field(v_e0_241, 2);
    V v_c1_24140 = heff_field(v_e0_241, 3);
    V v_c_24141 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24142 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24137));
    V v_t_24143 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24138));
    V v_t_24144 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24139}));
    V v_t_24145 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24140));
    V v_t_24146 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24141));
    V v_t_24147 = (g_std_2edoc_2e_3c_3e(v_t_24145, v_t_24146));
    V v_t_24148 = (g_std_2edoc_2e_3c_3e(v_t_24144, v_t_24147));
    V v_t_24149 = (g_std_2edoc_2e_3c_3e(v_t_24143, v_t_24148));
    return (g_std_2edoc_2e_3c_3e(v_t_24142, v_t_24149));
  }
  case TAG_EFSet: {
    V v_x_24150 = heff_field(v_e0_241, 0);
    V v_eq_24151 = heff_field(v_e0_241, 1);
    V v_e_24152 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24153 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24150));
    V v_b_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24151));
    V v_t_24155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24154));
    V v_t_24156 = (g_std_2edoc_2e_3c_3e(v_a_24153, v_t_24155));
    V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24152}));
    return (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
  }
  case TAG_EFDefault: {
    V v_d_24158 = heff_field(v_e0_241, 0);
    V v_eq_24159 = heff_field(v_e0_241, 1);
    V v_e_24160 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24158}));
    V v_b_24162 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24159));
    V v_t_24163 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24162));
    V v_t_24164 = (g_std_2edoc_2e_3c_3e(v_a_24161, v_t_24163));
    V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24160}));
    return (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24165));
  }
  case TAG_Sum: {
    V v_kw_24166 = heff_field(v_e0_241, 0);
    V v_o_24167 = heff_field(v_e0_241, 1);
    V v_alts_24168 = heff_field(v_e0_241, 2);
    V v_bars_24169 = heff_field(v_e0_241, 3);
    V v_c_24170 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24168)) {
    case TAG_Nil: {
      heff_drop(v_bars_24169);
      V v_a_24171 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24166));
      V v_a_24172 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24167));
      V v_b_24173 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24170));
      V v_t_24174 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24173));
      V v_b_24175 = (g_std_2edoc_2e_3c_3e(v_a_24172, v_t_24174));
      V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_b_24175));
      return (g_std_2edoc_2e_3c_3e(v_a_24171, v_t_24176));
    }
    case TAG_Cons: {
      V v_a1_24177 = heff_field(v_alts_24168, 0);
      V v_more_24178 = heff_field(v_alts_24168, 1);
      heff_take_n(v_alts_24168, 3ULL, 2);
      V v_a_24179 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24166));
      V v_a_24180 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24167));
      V v_b_24181 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24177}));
      V v_t_24182 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24181));
      V v_t_24183 = (g_std_2edoc_2e_3c_3e(v_a_24180, v_t_24182));
      V v_ds_24190 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 2, 1, (V[]){heff_dup(v_env_240)}), v_bars_24169, v_more_24178));
      V v_a_24191 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24190; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24190); r_; });
      V v_b_24192 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24170));
      V v_t_24193 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24192));
      V v_t_24194 = (g_std_2edoc_2e_3c_3e(v_a_24191, v_t_24193));
      V v_d_24195 = (g_std_2edoc_2e_3c_3e(v_t_24183, v_t_24194));
      V v_b_24200 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 1, 1, (V[]){v_d_24195})})));
      V v_t_24201 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24200));
      return (g_std_2edoc_2e_3c_3e(v_a_24179, v_t_24201));
    }
    default: return heff_nomatch(v_alts_24168);
    }
  }
  case TAG_ECon: {
    V v_c_24202 = heff_field(v_e0_241, 0);
    V v_args_24203 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24204 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24202));
    V v_ds_24207 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 1, (V[]){v_env_240}), v_args_24203));
    V v_t_24208 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24207; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24207); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24208));
  }
  case TAG_EField: {
    V v_e_24209 = heff_field(v_e0_241, 0);
    V v_f_24210 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24211 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24209}));
    V v_t_24212 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24210));
    return (g_std_2edoc_2e_3c_3e(v_t_24211, v_t_24212));
  }
  case TAG_ENeg: {
    V v_m_24213 = heff_field(v_e0_241, 0);
    V v_e_24214 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24215 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24213));
    V v_t_24216 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24214}));
    return (g_std_2edoc_2e_3c_3e(v_t_24215, v_t_24216));
  }
  case TAG_App: {
    V v_h_24217 = heff_field(v_e0_241, 0);
    V v_args_24218 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24217;
    heff_room[2] = v_args_24218;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24219 = heff_field(v_e0_241, 0);
    V v_op_24220 = heff_field(v_e0_241, 1);
    V v_b_24221 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    V v_t_24222 = (g_heff_2esyntax_2efmt_2elayout_2echain(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24219, v_op_24220, v_b_24221})));
    switch (heff_tag_of(v_t_24222)) {
    case TAG_MkChain: {
      V v_first_24223 = heff_field(v_t_24222, 0);
      V v_rest_24224 = heff_field(v_t_24222, 1);
      heff_take_n(v_t_24222, 3ULL, 2);
      V v_t_24225 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24224), v_first_24223}));
      V v_ds_24228 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24224)}), v_rest_24224));
      V v_t_24229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24228; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24228); r_; });
      V v_t_24230 = (g_std_2edoc_2e_3c_3e(v_t_24225, v_t_24229));
      return (g_std_2edoc_2egroup(v_t_24230));
    }
    default: return heff_nomatch(v_t_24222);
    }
  }
  case TAG_Ops: {
    V v_a_24231 = heff_field(v_e0_241, 0);
    V v_rest_24232 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24231;
    heff_room[2] = v_rest_24232;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24233 = heff_field(v_e0_241, 0);
    V v_e_24234 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24235 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24233));
    V v_b_24236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24234}));
    V v_t_24237 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24236));
    return (g_std_2edoc_2e_3c_3e(v_a_24235, v_t_24237));
  }
  case TAG_Ann: {
    V v_e_24238 = heff_field(v_e0_241, 0);
    V v_cc_24239 = heff_field(v_e0_241, 1);
    V v_ty_24240 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24241 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24238}));
    V v_b_24242 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24239));
    V v_t_24243 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24242));
    V v_t_24244 = (g_std_2edoc_2e_3c_3e(v_a_24241, v_t_24243));
    V v_t_24245 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24240}));
    V v_d_24246 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24245));
    V v_t_24247 = (g_std_2edoc_2e_3c_3e(v_t_24244, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24246})));
    return (g_std_2edoc_2egroup(v_t_24247));
  }
  case TAG_BVar: {
    V v_t_24248 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24248));
  }
  case TAG_BImp: {
    V v_o_24249 = heff_field(v_e0_241, 0);
    V v_x_24250 = heff_field(v_e0_241, 1);
    V v_c_24251 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24252 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24249));
    V v_t_24253 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24250));
    V v_t_24254 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24251));
    V v_t_24255 = (g_std_2edoc_2e_3c_3e(v_t_24253, v_t_24254));
    return (g_std_2edoc_2e_3c_3e(v_t_24252, v_t_24255));
  }
  case TAG_BAnn: {
    V v_o_24256 = heff_field(v_e0_241, 0);
    V v_x_24257 = heff_field(v_e0_241, 1);
    V v_cc_24258 = heff_field(v_e0_241, 2);
    V v_ty_24259 = heff_field(v_e0_241, 3);
    V v_c_24260 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24261 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24256));
    V v_a_24262 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24257));
    V v_a_24263 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24258));
    V v_b_24264 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24259}));
    V v_t_24265 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24264));
    V v_b_24266 = (g_std_2edoc_2e_3c_3e(v_a_24263, v_t_24265));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_b_24266));
    V v_t_24268 = (g_std_2edoc_2e_3c_3e(v_a_24262, v_t_24267));
    V v_t_24269 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24260));
    V v_t_24270 = (g_std_2edoc_2e_3c_3e(v_t_24268, v_t_24269));
    return (g_std_2edoc_2e_3c_3e(v_t_24261, v_t_24270));
  }
  case TAG_Lam: {
    V v_bs_24271 = heff_field(v_e0_241, 0);
    V v_binders_24272 = heff_field(v_e0_241, 1);
    V v_arrow_24273 = heff_field(v_e0_241, 2);
    V v_body_24274 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24275 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24271));
    V v_t_24276 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24277 = (g_list_2emap(v_t_24276, v_binders_24272));
    V v_a_24278 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24277; V r_ = (g_std_2edoc_2econcatWith_24s650596433x61515523(a_0, a_1)); heff_drop(v_t_24277); r_; });
    V v_b_24279 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24273));
    V v_t_24280 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24279));
    V v_t_24281 = (g_std_2edoc_2e_3c_3e(v_a_24278, v_t_24280));
    V v_t_24282 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24274));
    V v_t_24286;
    if ((heff_dup(v_t_24282) == NTAG(TAG_True))) {
      heff_drop(v_t_24282);
      V v_t_24283 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24274}));
      v_t_24286 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24283));
    } else {
      heff_drop(v_t_24282);
      V v_t_24284 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24274}));
      V v_d_24285 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24284));
      v_t_24286 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24285})));
    }
    V v_t_24287 = (g_std_2edoc_2e_3c_3e(v_t_24281, v_t_24286));
    return (g_std_2edoc_2e_3c_3e(v_t_24275, v_t_24287));
  }
  case TAG_Case: {
    V v_kw_24288 = heff_field(v_e0_241, 0);
    V v_scrut_24289 = heff_field(v_e0_241, 1);
    V v_of2_24290 = heff_field(v_e0_241, 2);
    V v_alts_24291 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24292 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24288));
    V v_a_24293 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24289}));
    V v_b_24294 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24290));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24294));
    V v_b_24296 = (g_std_2edoc_2e_3c_3e(v_a_24293, v_t_24295));
    V v_t_24297 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_b_24296));
    V v_t_24298 = (g_std_2edoc_2e_3c_3e(v_a_24292, v_t_24297));
    V v_t_24299 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24291; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24291); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24298, v_t_24299));
  }
  case TAG_EAlt: {
    V v_p_24300 = heff_field(v_e0_241, 0);
    V v_arrow_24301 = heff_field(v_e0_241, 1);
    V v_body_24302 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24303 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24300; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24300); r_; });
    V v_b_24304 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24301));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24304));
    V v_t_24306 = (g_std_2edoc_2e_3c_3e(v_a_24303, v_t_24305));
    V v_t_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24302}));
    return (g_std_2edoc_2e_3c_3e(v_t_24306, v_t_24307));
  }
  case TAG_If: {
    V v_kw_24308 = heff_field(v_e0_241, 0);
    V v_c_24309 = heff_field(v_e0_241, 1);
    V v_th_24310 = heff_field(v_e0_241, 2);
    V v_a_24311 = heff_field(v_e0_241, 3);
    V v_el_24312 = heff_field(v_e0_241, 4);
    V v_b_24313 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24314 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24308, v_c_24309, v_th_24310, v_a_24311}));
    V v_t_24315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24312, v_b_24313}));
    V v_t_24316 = (g_std_2edoc_2e_3c_3e(v_t_24314, v_t_24315));
    return (g_std_2edoc_2egroup(v_t_24316));
  }
  case TAG_Do: {
    V v_kw_24317 = heff_field(v_e0_241, 0);
    V v_stmts_24318 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24319 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24317));
    V v_t_24320 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24318; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24318); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24319, v_t_24320));
  }
  case TAG_ESBind: {
    V v_x_24321 = heff_field(v_e0_241, 0);
    V v_arrow_24322 = heff_field(v_e0_241, 1);
    V v_e_24323 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24324 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24321));
    V v_b_24325 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24322));
    V v_t_24326 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24325));
    V v_t_24327 = (g_std_2edoc_2e_3c_3e(v_a_24324, v_t_24326));
    V v_t_24328 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24323}));
    return (g_std_2edoc_2e_3c_3e(v_t_24327, v_t_24328));
  }
  case TAG_ELet: {
    V v_kw_24329 = heff_field(v_e0_241, 0);
    V v_p_24330 = heff_field(v_e0_241, 1);
    V v_ann_24331 = heff_field(v_e0_241, 2);
    V v_eq_24332 = heff_field(v_e0_241, 3);
    V v_e_24333 = heff_field(v_e0_241, 4);
    V v_body_24334 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24334)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24329, v_p_24330, v_ann_24331, v_eq_24332, v_e_24333});
    }
    case TAG_Just: {
      V v_it1_24335 = heff_field(v_body_24334, 0);
      V v_ru_24body_24334_24Just = heff_take_reuse_n(v_body_24334, 1ULL, 1);
      switch (heff_tag_of(v_it1_24335)) {
      case TAG_MkPair: {
        V v_i_24336 = heff_field(v_it1_24335, 0);
        V v_b_24337 = heff_field(v_it1_24335, 1);
        heff_take_n(v_it1_24335, 3ULL, 2);
        V v_t_24338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24329, v_p_24330, v_ann_24331, v_eq_24332, v_e_24333, v_i_24336, v_b_24337}));
        V v_d_24339 = (g_std_2edoc_2egroup(v_t_24338));
        return heff_tag_at_n(v_ru_24body_24334_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 1, (V[]){v_d_24339})});
      }
      default: return heff_nomatch(v_it1_24335);
      }
    }
    default: return heff_nomatch(v_body_24334);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_env_24344 = args[0];
  V v_e_24345 = args[1];
  V v_t_24346 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24345));
  if ((heff_dup(v_t_24346) == NTAG(TAG_True))) {
    heff_drop(v_t_24346);
    V v_t_24347 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24344, v_e_24345}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_t_24347));
  } else {
    heff_drop(v_t_24346);
    V v_t_24348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24344, v_e_24345}));
    V v_t_24349 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24348));
    return (g_std_2edoc_2egroup(v_t_24349));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_env_24350 = args[0];
  V v_kw_24351 = args[1];
  V v_p_24352 = args[2];
  V v_ann_24353 = args[3];
  V v_eq_24354 = args[4];
  V v_e_24355 = args[5];
  V v_a_24356 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24350), v_kw_24351));
  V v_b_24357 = ({ V a_0 = heff_dup(v_env_24350); V a_1 = v_p_24352; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24352); r_; });
  V v_t_24358 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_b_24357));
  V v_t_24359 = (g_std_2edoc_2e_3c_3e(v_a_24356, v_t_24358));
  V v_a_24367;
  switch (heff_tag_of(v_ann_24353)) {
  case TAG_Nothing: {
    v_a_24367 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24360 = heff_field(v_ann_24353, 0);
    V v_ru_24ann_24353_24Just = heff_take_reuse_n(v_ann_24353, 1ULL, 1);
    switch (heff_tag_of(v_it1_24360)) {
    case TAG_MkPair: {
      V v_cc_24361 = heff_field(v_it1_24360, 0);
      V v_ty_24362 = heff_field(v_it1_24360, 1);
      heff_take_n(v_it1_24360, 3ULL, 2);
      V v_a_24363 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24350), v_cc_24361));
      V v_b_24364 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24350), v_ty_24362}));
      V v_t_24365 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24353_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24364));
      V v_t_24366 = (g_std_2edoc_2e_3c_3e(v_a_24363, v_t_24365));
      v_a_24367 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24366));
      break;
    }
    default: heff_nomatch(v_it1_24360);
    }
    break;
  }
  default: heff_nomatch(v_ann_24353);
  }
  V v_b_24368 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24350), v_eq_24354));
  V v_t_24369 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24368));
  V v_t_24370 = (g_std_2edoc_2e_3c_3e(v_a_24367, v_t_24369));
  V v_t_24371 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24350, v_e_24355}));
  V v_t_24372 = (g_std_2edoc_2e_3c_3e(v_t_24370, v_t_24371));
  return (g_std_2edoc_2e_3c_3e(v_t_24359, v_t_24372));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_env_24373 = args[0];
  V v_kw_24374 = args[1];
  V v_p_24375 = args[2];
  V v_ann_24376 = args[3];
  V v_eq_24377 = args[4];
  V v_e_24378 = args[5];
  V v_i_24379 = args[6];
  V v_b_24380 = args[7];
  V v_d_24381 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24373), v_kw_24374, v_p_24375, v_ann_24376, v_eq_24377, v_e_24378}));
  V v_a_24382 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24373), v_i_24379));
  V v_b_24483;
  switch (heff_tag_of(v_b_24380)) {
  case TAG_Atom: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_EParen: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Named: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Tup: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Braces: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Update: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_EUSet: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_InstB: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_EFSet: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Sum: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_ECon: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_EField: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_ENeg: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_App: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Op: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Ops: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Ann: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_BVar: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_BImp: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_BAnn: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Lam: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Case: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_EAlt: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_If: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_Do: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_ESBind: {
    v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24474 = heff_dup(heff_field(v_b_24380, 0));
    V v_p2_24475 = heff_dup(heff_field(v_b_24380, 1));
    V v_ann2_24476 = heff_dup(heff_field(v_b_24380, 2));
    V v_eq2_24477 = heff_dup(heff_field(v_b_24380, 3));
    V v_e2_24478 = heff_dup(heff_field(v_b_24380, 4));
    V v_it6_24479 = heff_dup(heff_field(v_b_24380, 5));
    switch (heff_tag_of(v_it6_24479)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24474);
      heff_drop(v_p2_24475);
      heff_drop(v_ann2_24476);
      heff_drop(v_eq2_24477);
      heff_drop(v_e2_24478);
      v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24373, v_b_24380}));
      break;
    }
    case TAG_Just: {
      V v_it61_24480 = heff_field(v_it6_24479, 0);
      heff_take_n(v_it6_24479, 1ULL, 1);
      heff_drop_tag(v_b_24380, 6);
      switch (heff_tag_of(v_it61_24480)) {
      case TAG_MkPair: {
        V v_i2_24481 = heff_field(v_it61_24480, 0);
        V v_b2_24482 = heff_field(v_it61_24480, 1);
        heff_take_n(v_it61_24480, 3ULL, 2);
        v_b_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24373, v_kw2_24474, v_p2_24475, v_ann2_24476, v_eq2_24477, v_e2_24478, v_i2_24481, v_b2_24482}));
        break;
      }
      default: heff_nomatch(v_it61_24480);
      }
      break;
    }
    default: heff_nomatch(v_it6_24479);
    }
    break;
  }
  default: heff_nomatch(v_b_24380);
  }
  V v_t_24484 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24483));
  V v_t_24485 = (g_std_2edoc_2e_3c_3e(v_a_24382, v_t_24484));
  V v_t_24486 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24485));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24381}), v_t_24486));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_env_24487 = args[0];
  V v_kw_24488 = args[1];
  V v_c_24489 = args[2];
  V v_th_24490 = args[3];
  V v_a_24491 = args[4];
  V v_a_24492 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24487), v_kw_24488));
  V v_b_24493 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24487), v_c_24489}));
  V v_t_24494 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24493));
  V v_t_24495 = (g_std_2edoc_2e_3c_3e(v_a_24492, v_t_24494));
  V v_a_24496 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24487), v_th_24490));
  V v_d_24497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24487, v_a_24491}));
  V v_t_24498 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24497})));
  V v_t_24499 = (g_std_2edoc_2e_3c_3e(v_a_24496, v_t_24498));
  V v_d_24500 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24499));
  V v_t_24501 = (g_std_2edoc_2e_3c_3e(v_t_24495, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24500})));
  return (g_std_2edoc_2egroup(v_t_24501));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_env_24502 = args[0];
  V v_el_24503 = args[1];
  V v_b_24504 = args[2];
  switch (heff_tag_of(v_b_24504)) {
  case TAG_Atom: {
    V v_a_24506 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24507 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24508 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24507})));
    V v_t_24509 = (g_std_2edoc_2e_3c_3e(v_a_24506, v_t_24508));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24509));
  }
  case TAG_EParen: {
    V v_a_24513 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24514 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24515 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24514})));
    V v_t_24516 = (g_std_2edoc_2e_3c_3e(v_a_24513, v_t_24515));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24516));
  }
  case TAG_Named: {
    V v_a_24522 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24523 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24524 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24523})));
    V v_t_24525 = (g_std_2edoc_2e_3c_3e(v_a_24522, v_t_24524));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24525));
  }
  case TAG_Tup: {
    V v_a_24530 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24531 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24532 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24531})));
    V v_t_24533 = (g_std_2edoc_2e_3c_3e(v_a_24530, v_t_24532));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24533));
  }
  case TAG_Braces: {
    V v_a_24538 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24539 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24540 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24539})));
    V v_t_24541 = (g_std_2edoc_2e_3c_3e(v_a_24538, v_t_24540));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24541));
  }
  case TAG_Update: {
    V v_a_24548 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24549 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24550 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24549})));
    V v_t_24551 = (g_std_2edoc_2e_3c_3e(v_a_24548, v_t_24550));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24551));
  }
  case TAG_EUSet: {
    V v_a_24555 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24556 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24557 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24556})));
    V v_t_24558 = (g_std_2edoc_2e_3c_3e(v_a_24555, v_t_24557));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24558));
  }
  case TAG_InstB: {
    V v_a_24564 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24565 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24566 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24565})));
    V v_t_24567 = (g_std_2edoc_2e_3c_3e(v_a_24564, v_t_24566));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24567));
  }
  case TAG_EFSet: {
    V v_a_24571 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24572 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24573 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24572})));
    V v_t_24574 = (g_std_2edoc_2e_3c_3e(v_a_24571, v_t_24573));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24574));
  }
  case TAG_EFDefault: {
    V v_a_24578 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24579 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24580 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24579})));
    V v_t_24581 = (g_std_2edoc_2e_3c_3e(v_a_24578, v_t_24580));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24581));
  }
  case TAG_Sum: {
    V v_a_24587 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24588 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24589 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24588})));
    V v_t_24590 = (g_std_2edoc_2e_3c_3e(v_a_24587, v_t_24589));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24590));
  }
  case TAG_ECon: {
    V v_a_24593 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24594 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24595 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24594})));
    V v_t_24596 = (g_std_2edoc_2e_3c_3e(v_a_24593, v_t_24595));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24596));
  }
  case TAG_EField: {
    V v_a_24599 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24600 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24601 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24600})));
    V v_t_24602 = (g_std_2edoc_2e_3c_3e(v_a_24599, v_t_24601));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24602));
  }
  case TAG_ENeg: {
    V v_a_24605 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24606 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24607 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24606})));
    V v_t_24608 = (g_std_2edoc_2e_3c_3e(v_a_24605, v_t_24607));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24608));
  }
  case TAG_App: {
    V v_a_24611 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24612 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24613 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24612})));
    V v_t_24614 = (g_std_2edoc_2e_3c_3e(v_a_24611, v_t_24613));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24614));
  }
  case TAG_Op: {
    V v_a_24618 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24619 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24620 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24619})));
    V v_t_24621 = (g_std_2edoc_2e_3c_3e(v_a_24618, v_t_24620));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24621));
  }
  case TAG_Ops: {
    V v_a_24624 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24625 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24626 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24625})));
    V v_t_24627 = (g_std_2edoc_2e_3c_3e(v_a_24624, v_t_24626));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24627));
  }
  case TAG_OpRhs: {
    V v_a_24630 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24631 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24632 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24631})));
    V v_t_24633 = (g_std_2edoc_2e_3c_3e(v_a_24630, v_t_24632));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24633));
  }
  case TAG_Ann: {
    V v_a_24637 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24638 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24639 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24638})));
    V v_t_24640 = (g_std_2edoc_2e_3c_3e(v_a_24637, v_t_24639));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24640));
  }
  case TAG_BVar: {
    V v_a_24642 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24643 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24644 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24643})));
    V v_t_24645 = (g_std_2edoc_2e_3c_3e(v_a_24642, v_t_24644));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24645));
  }
  case TAG_BImp: {
    V v_a_24649 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24650 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24651 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24650})));
    V v_t_24652 = (g_std_2edoc_2e_3c_3e(v_a_24649, v_t_24651));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24652));
  }
  case TAG_BAnn: {
    V v_a_24658 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24659 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24660 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24659})));
    V v_t_24661 = (g_std_2edoc_2e_3c_3e(v_a_24658, v_t_24660));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24661));
  }
  case TAG_Lam: {
    V v_a_24666 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24667 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24668 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24667})));
    V v_t_24669 = (g_std_2edoc_2e_3c_3e(v_a_24666, v_t_24668));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24669));
  }
  case TAG_Case: {
    V v_a_24674 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24675 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24676 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24675})));
    V v_t_24677 = (g_std_2edoc_2e_3c_3e(v_a_24674, v_t_24676));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24677));
  }
  case TAG_EAlt: {
    V v_a_24681 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24682 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24683 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24682})));
    V v_t_24684 = (g_std_2edoc_2e_3c_3e(v_a_24681, v_t_24683));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24684));
  }
  case TAG_If: {
    V v_kw_24685 = heff_field(v_b_24504, 0);
    V v_c_24686 = heff_field(v_b_24504, 1);
    V v_th_24687 = heff_field(v_b_24504, 2);
    V v_a_24688 = heff_field(v_b_24504, 3);
    V v_el2_24689 = heff_field(v_b_24504, 4);
    V v_b2_24690 = heff_field(v_b_24504, 5);
    heff_take_n(v_b_24504, 63ULL, 6);
    V v_a_24691 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_b_24692 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24502), v_kw_24685, v_c_24686, v_th_24687, v_a_24688}));
    V v_t_24693 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), v_b_24692));
    V v_t_24694 = (g_std_2edoc_2e_3c_3e(v_a_24691, v_t_24693));
    V v_t_24695 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24502, v_el2_24689, v_b2_24690}));
    V v_t_24696 = (g_std_2edoc_2e_3c_3e(v_t_24694, v_t_24695));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24696));
  }
  case TAG_Do: {
    V v_a_24699 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24700 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24701 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24700})));
    V v_t_24702 = (g_std_2edoc_2e_3c_3e(v_a_24699, v_t_24701));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24702));
  }
  case TAG_ESBind: {
    V v_a_24706 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24707 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24708 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24707})));
    V v_t_24709 = (g_std_2edoc_2e_3c_3e(v_a_24706, v_t_24708));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24709));
  }
  case TAG_ELet: {
    V v_a_24716 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24502), v_el_24503));
    V v_d_24717 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24502, v_b_24504}));
    V v_t_24718 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24717})));
    V v_t_24719 = (g_std_2edoc_2e_3c_3e(v_a_24716, v_t_24718));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24719));
  }
  default: return heff_nomatch(v_b_24504);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_a_24734 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24735 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24734}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24735));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_a_24743 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24744 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24743}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24744));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_a_24753 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24754 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24753}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24754));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_a_24766 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24767 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24766}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24767));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_a_24778 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24779 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24778}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24779));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_a_24787 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24788 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24787}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24788));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_a_24798 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24799 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24798}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24799));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_24807 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24808 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24807}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24808));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_24818 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24819 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24818}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24819));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_24827 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24828 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24827}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24828));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_24840 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24841 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24840}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24841));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_24849 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24850 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24849}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24850));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_24859 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24860 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24859}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24860));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_24868 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24868}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24869));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_24880 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24881 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24880}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24881));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_24889 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24890 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24889}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24890));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_24899 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24900 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24899}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24900));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_24908 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24909 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24908}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24909));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_24918 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24919 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24918}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24919));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_24927 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24928 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24927}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24928));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_24939 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24940 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24939}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24940));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_24948 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24949 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24948}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24949));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_24957 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24958 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24957}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24958));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_24966 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24967 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24966}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24967));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_24975 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24976 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24975}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24976));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_24984 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24985 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24984}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24985));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_24993 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24994 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_24993}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24994));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241002 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241003 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241002}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241003));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241011 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241012 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241011}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241012));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241020 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241021 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241020}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241021));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241030 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241031 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241030}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241031));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241039 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241040 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241039}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241040));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241048 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241049 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241048}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241049));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241057 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241058 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241057}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241058));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241066 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241067 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241066}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241067));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241075 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241076 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241075}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241076));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241085 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241086 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241085}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241086));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241094 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241095 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241094}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241095));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241102 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241102}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241103));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241111 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241112 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241111}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241112));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241121 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241122 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241121}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241122));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241130 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241130}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241131));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241142 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241143 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241142}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241143));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241151 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241152 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241151}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241152));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241162 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241163 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241162}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241163));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241171 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241171}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241172));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241182 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241183 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241182}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241183));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241191 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241192 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241191}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241192));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241201 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241201}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241202));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241210 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241211 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241210}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241211));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241223 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241224 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241223}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241224));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241232 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241233 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241232}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241233));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241241 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241242 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241241}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241242));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241250 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241251 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241250}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241251));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241260 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241261 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241260}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241261));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241269 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241270 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241269}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241270));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241282 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241283 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241282}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241283));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241291 = args[0];
  V v_env_24720 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241292 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_a_241291}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241292));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_env_24720 = args[0];
  V v_h_24721 = args[1];
  V v_args_24722 = args[2];
  V v_x1_24723 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24722)));
  V v_t_24727;
  switch (heff_tag_of(v_x1_24723)) {
  case TAG_Nil: {
    v_t_24727 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_24724 = heff_field(v_x1_24723, 0);
    V v_rev_24725 = heff_field(v_x1_24723, 1);
    V v_ru_24x1_24723_24Cons = heff_take_reuse_n(v_x1_24723, 3ULL, 2);
    V v_t_24726 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24725));
    v_t_24727 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_24723_24Cons, TAG_MkPair, 2, (V[]){v_t_24726, v_x_24724})});
    break;
  }
  default: heff_nomatch(v_x1_24723);
  }
  switch (heff_tag_of(v_t_24727)) {
  case TAG_Nothing: {
    heff_drop(v_args_24722);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24720;
    args[1] = v_h_24721;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Just: {
    V v_pr_24728 = heff_field(v_t_24727, 0);
    V v_ru_24t_24727_24Just = heff_take_reuse_n(v_t_24727, 1ULL, 1);
    switch (heff_tag_of(v_pr_24728)) {
    case TAG_MkPair: {
      V v_init2_24729 = heff_field(v_pr_24728, 0);
      V v_lastA_24730 = heff_field(v_pr_24728, 1);
      V v_ru_24pr_24728_24MkPair = heff_take_reuse_n(v_pr_24728, 3ULL, 2);
      switch (heff_tag_of(v_lastA_24730)) {
      case TAG_Atom: {
        V v_t_24732 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24732) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24732);
          V v_t_24733 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24736 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24737 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24736; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24736); r_; });
          V v_t_24738 = (g_std_2edoc_2e_3c_3e(v_t_24733, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24737})));
          V v_a_24739 = (g_std_2edoc_2egroup(v_t_24738));
          V v_b_24740 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24741 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), v_b_24740));
          return (g_std_2edoc_2e_3c_3e(v_a_24739, v_t_24741));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 1);
          heff_drop(v_t_24732);
          V v_t_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24745 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24746 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24745; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24745); r_; });
          V v_t_24747 = (g_std_2edoc_2e_3c_3e(v_t_24742, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24746})));
          return (g_std_2edoc_2egroup(v_t_24747));
        }
      }
      case TAG_EParen: {
        V v_o_24748 = heff_field(v_lastA_24730, 0);
        V v_e_24749 = heff_field(v_lastA_24730, 1);
        V v_c_24750 = heff_field(v_lastA_24730, 2);
        heff_take_n(v_lastA_24730, 7ULL, 3);
        V v_t_24751 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24749));
        if ((heff_dup(v_t_24751) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24751);
          V v_t_24752 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24755 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24756 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24755; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24755); r_; });
          V v_t_24757 = (g_std_2edoc_2e_3c_3e(v_t_24752, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24756})));
          V v_a_24758 = (g_std_2edoc_2egroup(v_t_24757));
          V v_b_24759 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24720), v_o_24748));
          V v_t_24760 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_b_24759));
          V v_t_24761 = (g_std_2edoc_2e_3c_3e(v_a_24758, v_t_24760));
          V v_t_24762 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_e_24749}));
          V v_t_24763 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24720, v_c_24750));
          V v_t_24764 = (g_std_2edoc_2e_3c_3e(v_t_24762, v_t_24763));
          return (g_std_2edoc_2e_3c_3e(v_t_24761, v_t_24764));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop(v_o_24748);
          heff_drop(v_e_24749);
          heff_drop(v_c_24750);
          heff_drop(v_t_24751);
          V v_t_24765 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24768 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24769 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24768; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24768); r_; });
          V v_t_24770 = (g_std_2edoc_2e_3c_3e(v_t_24765, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24769})));
          return (g_std_2edoc_2egroup(v_t_24770));
        }
      }
      case TAG_Named: {
        V v_t_24776 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24776) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24776);
          V v_t_24777 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24780 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24781 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24780; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24780); r_; });
          V v_t_24782 = (g_std_2edoc_2e_3c_3e(v_t_24777, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24781})));
          V v_a_24783 = (g_std_2edoc_2egroup(v_t_24782));
          V v_b_24784 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24785 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_b_24784));
          return (g_std_2edoc_2e_3c_3e(v_a_24783, v_t_24785));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 5);
          heff_drop(v_t_24776);
          V v_t_24786 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24789 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24790 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24789; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24789); r_; });
          V v_t_24791 = (g_std_2edoc_2e_3c_3e(v_t_24786, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24790})));
          return (g_std_2edoc_2egroup(v_t_24791));
        }
      }
      case TAG_Tup: {
        V v_t_24796 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24796) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24796);
          V v_t_24797 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24800 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24801 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24800; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24800); r_; });
          V v_t_24802 = (g_std_2edoc_2e_3c_3e(v_t_24797, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24801})));
          V v_a_24803 = (g_std_2edoc_2egroup(v_t_24802));
          V v_b_24804 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24805 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24804));
          return (g_std_2edoc_2e_3c_3e(v_a_24803, v_t_24805));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 4);
          heff_drop(v_t_24796);
          V v_t_24806 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24809 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24810 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24809; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24809); r_; });
          V v_t_24811 = (g_std_2edoc_2e_3c_3e(v_t_24806, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24810})));
          return (g_std_2edoc_2egroup(v_t_24811));
        }
      }
      case TAG_Braces: {
        V v_t_24816 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24816) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24816);
          V v_t_24817 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24820 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24821 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24820; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24820); r_; });
          V v_t_24822 = (g_std_2edoc_2e_3c_3e(v_t_24817, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24821})));
          V v_a_24823 = (g_std_2edoc_2egroup(v_t_24822));
          V v_b_24824 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24825 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24824));
          return (g_std_2edoc_2e_3c_3e(v_a_24823, v_t_24825));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 4);
          heff_drop(v_t_24816);
          V v_t_24826 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24829 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24830 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24829; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24829); r_; });
          V v_t_24831 = (g_std_2edoc_2e_3c_3e(v_t_24826, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24830})));
          return (g_std_2edoc_2egroup(v_t_24831));
        }
      }
      case TAG_Update: {
        V v_t_24838 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24838) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24838);
          V v_t_24839 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24842 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24843 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24842; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24842); r_; });
          V v_t_24844 = (g_std_2edoc_2e_3c_3e(v_t_24839, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24843})));
          V v_a_24845 = (g_std_2edoc_2egroup(v_t_24844));
          V v_b_24846 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24847 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_b_24846));
          return (g_std_2edoc_2e_3c_3e(v_a_24845, v_t_24847));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 6);
          heff_drop(v_t_24838);
          V v_t_24848 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24851 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24852 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24851; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24851); r_; });
          V v_t_24853 = (g_std_2edoc_2e_3c_3e(v_t_24848, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24852})));
          return (g_std_2edoc_2egroup(v_t_24853));
        }
      }
      case TAG_EUSet: {
        V v_t_24857 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24857) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24857);
          V v_t_24858 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24861 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24862 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24861; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24861); r_; });
          V v_t_24863 = (g_std_2edoc_2e_3c_3e(v_t_24858, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24862})));
          V v_a_24864 = (g_std_2edoc_2egroup(v_t_24863));
          V v_b_24865 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24866 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_24865));
          return (g_std_2edoc_2e_3c_3e(v_a_24864, v_t_24866));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_24857);
          V v_t_24867 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24870 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24871 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24870; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24870); r_; });
          V v_t_24872 = (g_std_2edoc_2e_3c_3e(v_t_24867, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24871})));
          return (g_std_2edoc_2egroup(v_t_24872));
        }
      }
      case TAG_InstB: {
        V v_t_24878 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24878) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24878);
          V v_t_24879 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24882 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24883 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24882; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24882); r_; });
          V v_t_24884 = (g_std_2edoc_2e_3c_3e(v_t_24879, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24883})));
          V v_a_24885 = (g_std_2edoc_2egroup(v_t_24884));
          V v_b_24886 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24887 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_24886));
          return (g_std_2edoc_2e_3c_3e(v_a_24885, v_t_24887));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 5);
          heff_drop(v_t_24878);
          V v_t_24888 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24891 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24892 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24891; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24891); r_; });
          V v_t_24893 = (g_std_2edoc_2e_3c_3e(v_t_24888, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24892})));
          return (g_std_2edoc_2egroup(v_t_24893));
        }
      }
      case TAG_EFSet: {
        V v_t_24897 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24897) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24897);
          V v_t_24898 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24901 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24902 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24901; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24901); r_; });
          V v_t_24903 = (g_std_2edoc_2e_3c_3e(v_t_24898, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24902})));
          V v_a_24904 = (g_std_2edoc_2egroup(v_t_24903));
          V v_b_24905 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24906 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_24905));
          return (g_std_2edoc_2e_3c_3e(v_a_24904, v_t_24906));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_24897);
          V v_t_24907 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24910 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24911 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24910; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24910); r_; });
          V v_t_24912 = (g_std_2edoc_2e_3c_3e(v_t_24907, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24911})));
          return (g_std_2edoc_2egroup(v_t_24912));
        }
      }
      case TAG_EFDefault: {
        V v_t_24916 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24916) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24916);
          V v_t_24917 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24920 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24921 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24920; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24920); r_; });
          V v_t_24922 = (g_std_2edoc_2e_3c_3e(v_t_24917, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24921})));
          V v_a_24923 = (g_std_2edoc_2egroup(v_t_24922));
          V v_b_24924 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24925 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_24924));
          return (g_std_2edoc_2e_3c_3e(v_a_24923, v_t_24925));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_24916);
          V v_t_24926 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24929 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24930 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24929; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24929); r_; });
          V v_t_24931 = (g_std_2edoc_2e_3c_3e(v_t_24926, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24930})));
          return (g_std_2edoc_2egroup(v_t_24931));
        }
      }
      case TAG_Sum: {
        V v_t_24937 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24937) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24937);
          V v_t_24938 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24941 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24942 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24941; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24941); r_; });
          V v_t_24943 = (g_std_2edoc_2e_3c_3e(v_t_24938, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24942})));
          V v_a_24944 = (g_std_2edoc_2egroup(v_t_24943));
          V v_b_24945 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24946 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_24945));
          return (g_std_2edoc_2e_3c_3e(v_a_24944, v_t_24946));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 5);
          heff_drop(v_t_24937);
          V v_t_24947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24950 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24951 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24950; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24950); r_; });
          V v_t_24952 = (g_std_2edoc_2e_3c_3e(v_t_24947, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24951})));
          return (g_std_2edoc_2egroup(v_t_24952));
        }
      }
      case TAG_ECon: {
        V v_t_24955 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24955) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24955);
          V v_t_24956 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24959 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24960 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24959; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24959); r_; });
          V v_t_24961 = (g_std_2edoc_2e_3c_3e(v_t_24956, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24960})));
          V v_a_24962 = (g_std_2edoc_2egroup(v_t_24961));
          V v_b_24963 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24964 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_24963));
          return (g_std_2edoc_2e_3c_3e(v_a_24962, v_t_24964));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_24955);
          V v_t_24965 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24968 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24969 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24968; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24968); r_; });
          V v_t_24970 = (g_std_2edoc_2e_3c_3e(v_t_24965, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24969})));
          return (g_std_2edoc_2egroup(v_t_24970));
        }
      }
      case TAG_EField: {
        V v_t_24973 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24973) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24973);
          V v_t_24974 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24977 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24978 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24977; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24977); r_; });
          V v_t_24979 = (g_std_2edoc_2e_3c_3e(v_t_24974, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24978})));
          V v_a_24980 = (g_std_2edoc_2egroup(v_t_24979));
          V v_b_24981 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_24982 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), v_b_24981));
          return (g_std_2edoc_2e_3c_3e(v_a_24980, v_t_24982));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_24973);
          V v_t_24983 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24986 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_24987 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24986; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24986); r_; });
          V v_t_24988 = (g_std_2edoc_2e_3c_3e(v_t_24983, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24987})));
          return (g_std_2edoc_2egroup(v_t_24988));
        }
      }
      case TAG_ENeg: {
        V v_t_24991 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_24991) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_24991);
          V v_t_24992 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_24995 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_24996 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24995; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_24995); r_; });
          V v_t_24997 = (g_std_2edoc_2e_3c_3e(v_t_24992, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24996})));
          V v_a_24998 = (g_std_2edoc_2egroup(v_t_24997));
          V v_b_24999 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241000 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_24999));
          return (g_std_2edoc_2e_3c_3e(v_a_24998, v_t_241000));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_24991);
          V v_t_241001 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241004 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241005 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241004; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241004); r_; });
          V v_t_241006 = (g_std_2edoc_2e_3c_3e(v_t_241001, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241005})));
          return (g_std_2edoc_2egroup(v_t_241006));
        }
      }
      case TAG_App: {
        V v_t_241009 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241009) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241009);
          V v_t_241010 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241013 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241014 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241013; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241013); r_; });
          V v_t_241015 = (g_std_2edoc_2e_3c_3e(v_t_241010, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241014})));
          V v_a_241016 = (g_std_2edoc_2egroup(v_t_241015));
          V v_b_241017 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241018 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), v_b_241017));
          return (g_std_2edoc_2e_3c_3e(v_a_241016, v_t_241018));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_241009);
          V v_t_241019 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241022 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241023 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241022; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241022); r_; });
          V v_t_241024 = (g_std_2edoc_2e_3c_3e(v_t_241019, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241023})));
          return (g_std_2edoc_2egroup(v_t_241024));
        }
      }
      case TAG_Op: {
        V v_t_241028 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241028) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241028);
          V v_t_241029 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241032 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241033 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241032; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241032); r_; });
          V v_t_241034 = (g_std_2edoc_2e_3c_3e(v_t_241029, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241033})));
          V v_a_241035 = (g_std_2edoc_2egroup(v_t_241034));
          V v_b_241036 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241037 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), v_b_241036));
          return (g_std_2edoc_2e_3c_3e(v_a_241035, v_t_241037));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_241028);
          V v_t_241038 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241041 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241042 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241041; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241041); r_; });
          V v_t_241043 = (g_std_2edoc_2e_3c_3e(v_t_241038, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241042})));
          return (g_std_2edoc_2egroup(v_t_241043));
        }
      }
      case TAG_Ops: {
        V v_t_241046 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241046) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241046);
          V v_t_241047 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241050 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241051 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241050; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241050); r_; });
          V v_t_241052 = (g_std_2edoc_2e_3c_3e(v_t_241047, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241051})));
          V v_a_241053 = (g_std_2edoc_2egroup(v_t_241052));
          V v_b_241054 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241055 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241054));
          return (g_std_2edoc_2e_3c_3e(v_a_241053, v_t_241055));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_241046);
          V v_t_241056 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241059 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241060 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241059; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241059); r_; });
          V v_t_241061 = (g_std_2edoc_2e_3c_3e(v_t_241056, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241060})));
          return (g_std_2edoc_2egroup(v_t_241061));
        }
      }
      case TAG_OpRhs: {
        V v_t_241064 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241064) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241064);
          V v_t_241065 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241068 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241069 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241068; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241068); r_; });
          V v_t_241070 = (g_std_2edoc_2e_3c_3e(v_t_241065, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241069})));
          V v_a_241071 = (g_std_2edoc_2egroup(v_t_241070));
          V v_b_241072 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241073 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), v_b_241072));
          return (g_std_2edoc_2e_3c_3e(v_a_241071, v_t_241073));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_241064);
          V v_t_241074 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241077 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241078 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241077; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241077); r_; });
          V v_t_241079 = (g_std_2edoc_2e_3c_3e(v_t_241074, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241078})));
          return (g_std_2edoc_2egroup(v_t_241079));
        }
      }
      case TAG_Ann: {
        V v_t_241083 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241083) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241083);
          V v_t_241084 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241087 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241088 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241087; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241087); r_; });
          V v_t_241089 = (g_std_2edoc_2e_3c_3e(v_t_241084, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241088})));
          V v_a_241090 = (g_std_2edoc_2egroup(v_t_241089));
          V v_b_241091 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241092 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), v_b_241091));
          return (g_std_2edoc_2e_3c_3e(v_a_241090, v_t_241092));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_241083);
          V v_t_241093 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241096 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241097 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241096; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241096); r_; });
          V v_t_241098 = (g_std_2edoc_2e_3c_3e(v_t_241093, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241097})));
          return (g_std_2edoc_2egroup(v_t_241098));
        }
      }
      case TAG_BVar: {
        V v_t_241100 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241100) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241100);
          V v_t_241101 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241104 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241105 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241104; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241104); r_; });
          V v_t_241106 = (g_std_2edoc_2e_3c_3e(v_t_241101, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241105})));
          V v_a_241107 = (g_std_2edoc_2egroup(v_t_241106));
          V v_b_241108 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241109 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), v_b_241108));
          return (g_std_2edoc_2e_3c_3e(v_a_241107, v_t_241109));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 1);
          heff_drop(v_t_241100);
          V v_t_241110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241113 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241114 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241113; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241113); r_; });
          V v_t_241115 = (g_std_2edoc_2e_3c_3e(v_t_241110, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241114})));
          return (g_std_2edoc_2egroup(v_t_241115));
        }
      }
      case TAG_BImp: {
        V v_t_241119 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241119) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241119);
          V v_t_241120 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241123 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241124 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241123; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241123); r_; });
          V v_t_241125 = (g_std_2edoc_2e_3c_3e(v_t_241120, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241124})));
          V v_a_241126 = (g_std_2edoc_2egroup(v_t_241125));
          V v_b_241127 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241128 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241127));
          return (g_std_2edoc_2e_3c_3e(v_a_241126, v_t_241128));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_241119);
          V v_t_241129 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241132 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241133 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241132; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241132); r_; });
          V v_t_241134 = (g_std_2edoc_2e_3c_3e(v_t_241129, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241133})));
          return (g_std_2edoc_2egroup(v_t_241134));
        }
      }
      case TAG_BAnn: {
        V v_t_241140 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241140) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241140);
          V v_t_241141 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241144 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241145 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241144; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241144); r_; });
          V v_t_241146 = (g_std_2edoc_2e_3c_3e(v_t_241141, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241145})));
          V v_a_241147 = (g_std_2edoc_2egroup(v_t_241146));
          V v_b_241148 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241149 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), v_b_241148));
          return (g_std_2edoc_2e_3c_3e(v_a_241147, v_t_241149));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 5);
          heff_drop(v_t_241140);
          V v_t_241150 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241153 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241154 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241153; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241153); r_; });
          V v_t_241155 = (g_std_2edoc_2e_3c_3e(v_t_241150, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241154})));
          return (g_std_2edoc_2egroup(v_t_241155));
        }
      }
      case TAG_Lam: {
        V v_t_241160 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241160) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241160);
          V v_t_241161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241164 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241165 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241164; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241164); r_; });
          V v_t_241166 = (g_std_2edoc_2e_3c_3e(v_t_241161, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241165})));
          V v_a_241167 = (g_std_2edoc_2egroup(v_t_241166));
          V v_b_241168 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241169 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241168));
          return (g_std_2edoc_2e_3c_3e(v_a_241167, v_t_241169));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 4);
          heff_drop(v_t_241160);
          V v_t_241170 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241173 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241174 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241173; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241173); r_; });
          V v_t_241175 = (g_std_2edoc_2e_3c_3e(v_t_241170, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241174})));
          return (g_std_2edoc_2egroup(v_t_241175));
        }
      }
      case TAG_Case: {
        V v_t_241180 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241180) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241180);
          V v_t_241181 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241184 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241185 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241184; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241184); r_; });
          V v_t_241186 = (g_std_2edoc_2e_3c_3e(v_t_241181, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241185})));
          V v_a_241187 = (g_std_2edoc_2egroup(v_t_241186));
          V v_b_241188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241189 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241188));
          return (g_std_2edoc_2e_3c_3e(v_a_241187, v_t_241189));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 4);
          heff_drop(v_t_241180);
          V v_t_241190 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241193 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241194 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241193; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241193); r_; });
          V v_t_241195 = (g_std_2edoc_2e_3c_3e(v_t_241190, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241194})));
          return (g_std_2edoc_2egroup(v_t_241195));
        }
      }
      case TAG_EAlt: {
        V v_t_241199 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241199) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241199);
          V v_t_241200 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241203 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241204 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241203; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241203); r_; });
          V v_t_241205 = (g_std_2edoc_2e_3c_3e(v_t_241200, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241204})));
          V v_a_241206 = (g_std_2edoc_2egroup(v_t_241205));
          V v_b_241207 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241208 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), v_b_241207));
          return (g_std_2edoc_2e_3c_3e(v_a_241206, v_t_241208));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_241199);
          V v_t_241209 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241212 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241213 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241212; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241212); r_; });
          V v_t_241214 = (g_std_2edoc_2e_3c_3e(v_t_241209, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241213})));
          return (g_std_2edoc_2egroup(v_t_241214));
        }
      }
      case TAG_If: {
        V v_t_241221 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241221) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241221);
          V v_t_241222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241225 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241226 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241225; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241225); r_; });
          V v_t_241227 = (g_std_2edoc_2e_3c_3e(v_t_241222, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241226})));
          V v_a_241228 = (g_std_2edoc_2egroup(v_t_241227));
          V v_b_241229 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241230 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), v_b_241229));
          return (g_std_2edoc_2e_3c_3e(v_a_241228, v_t_241230));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 6);
          heff_drop(v_t_241221);
          V v_t_241231 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241234 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241235 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241234; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241234); r_; });
          V v_t_241236 = (g_std_2edoc_2e_3c_3e(v_t_241231, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241235})));
          return (g_std_2edoc_2egroup(v_t_241236));
        }
      }
      case TAG_Do: {
        V v_t_241239 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241239) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241239);
          V v_t_241240 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241243 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241244 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241243; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241243); r_; });
          V v_t_241245 = (g_std_2edoc_2e_3c_3e(v_t_241240, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241244})));
          V v_a_241246 = (g_std_2edoc_2egroup(v_t_241245));
          V v_b_241247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241248 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), v_b_241247));
          return (g_std_2edoc_2e_3c_3e(v_a_241246, v_t_241248));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 2);
          heff_drop(v_t_241239);
          V v_t_241249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241252 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241253 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241252; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241252); r_; });
          V v_t_241254 = (g_std_2edoc_2e_3c_3e(v_t_241249, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241253})));
          return (g_std_2edoc_2egroup(v_t_241254));
        }
      }
      case TAG_ESBind: {
        V v_t_241258 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241258) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241258);
          V v_t_241259 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241262 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241263 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241262; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241262); r_; });
          V v_t_241264 = (g_std_2edoc_2e_3c_3e(v_t_241259, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241263})));
          V v_a_241265 = (g_std_2edoc_2egroup(v_t_241264));
          V v_b_241266 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241267 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), v_b_241266));
          return (g_std_2edoc_2e_3c_3e(v_a_241265, v_t_241267));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 3);
          heff_drop(v_t_241258);
          V v_t_241268 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241271 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241272 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241271; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241271); r_; });
          V v_t_241273 = (g_std_2edoc_2e_3c_3e(v_t_241268, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241272})));
          return (g_std_2edoc_2egroup(v_t_241273));
        }
      }
      case TAG_ELet: {
        V v_t_241280 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24730));
        if ((heff_dup(v_t_241280) == NTAG(TAG_True))) {
          heff_drop(v_args_24722);
          heff_drop(v_t_241280);
          V v_t_241281 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241284 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){heff_dup(v_env_24720)}), v_init2_24729));
          V v_d_241285 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241284; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241284); r_; });
          V v_t_241286 = (g_std_2edoc_2e_3c_3e(v_t_241281, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241285})));
          V v_a_241287 = (g_std_2edoc_2egroup(v_t_241286));
          V v_b_241288 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24720, v_lastA_24730}));
          V v_t_241289 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24727_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), v_b_241288));
          return (g_std_2edoc_2e_3c_3e(v_a_241287, v_t_241289));
        } else {
          heff_drop_cell(v_ru_24t_24727_24Just, 1);
          heff_drop(v_init2_24729);
          heff_drop_tag(v_lastA_24730, 6);
          heff_drop(v_t_241280);
          V v_t_241290 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24720), v_h_24721}));
          V v_ds_241293 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_env_24720}), v_args_24722));
          V v_d_241294 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241293; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241293); r_; });
          V v_t_241295 = (g_std_2edoc_2e_3c_3e(v_t_241290, heff_tag_at_n(v_ru_24pr_24728_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241294})));
          return (g_std_2edoc_2egroup(v_t_241295));
        }
      }
      default: return heff_nomatch(v_lastA_24730);
      }
    }
    default: return heff_nomatch(v_pr_24728);
    }
  }
  default: return heff_nomatch(v_t_24727);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_env_241296 = args[0];
  V v_rest_241297 = args[1];
  V v_e_241298 = args[2];
  switch (heff_tag_of(v_e_241298)) {
  case TAG_Atom: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_241312 = heff_field(v_e_241298, 0);
    V v_fs_241313 = heff_field(v_e_241298, 1);
    V v_commas_241314 = heff_field(v_e_241298, 2);
    V v_c_241315 = heff_field(v_e_241298, 3);
    heff_take_n(v_e_241298, 15ULL, 4);
    switch (heff_tag_of(v_fs_241313)) {
    case TAG_Nil: {
      heff_drop(v_rest_241297);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_241296;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241312, v_fs_241313, v_commas_241314, v_c_241315});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_241316 = heff_dup(heff_field(v_fs_241313, 0));
      V v_rest2_241317 = heff_dup(heff_field(v_fs_241313, 1));
      switch (heff_tag_of(v_rest2_241317)) {
      case TAG_Nil: {
        V v_t_241318 = ({ V a_0 = v_rest_241297; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_241297); r_; });
        if ((heff_dup(v_t_241318) == NTAG(TAG_True))) {
          heff_drop(v_t_241318);
          V v_x1_241319 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_241316));
          if ((heff_dup(v_x1_241319) == NTAG(TAG_True))) {
            heff_drop(v_d_241316);
            heff_drop(v_x1_241319);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_241296;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241312, v_fs_241313, v_commas_241314, v_c_241315});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_241319);
            switch (heff_tag_of(v_commas_241314)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_241313, 2);
              V v_t_241320 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241296), v_o_241312));
              V v_t_241321 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241296), v_d_241316}));
              V v_t_241322 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241296, v_c_241315));
              V v_t_241323 = (g_std_2edoc_2e_3c_3e(v_t_241321, v_t_241322));
              return (g_std_2edoc_2e_3c_3e(v_t_241320, v_t_241323));
            }
            case TAG_Cons: {
              heff_drop(v_d_241316);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_241296;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241312, v_fs_241313, v_commas_241314, v_c_241315});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_241314);
            }
          }
        } else {
          heff_drop(v_d_241316);
          heff_drop(v_t_241318);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_241296;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241312, v_fs_241313, v_commas_241314, v_c_241315});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_241317, 0ULL, 2);
        heff_drop(v_rest_241297);
        heff_drop(v_d_241316);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_241296;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241312, v_fs_241313, v_commas_241314, v_c_241315});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_241317);
      }
    }
    default: return heff_nomatch(v_fs_241313);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241297);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241296;
    args[1] = v_e_241298;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_241298);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_env_241408 = args[0];
  V v_b_241409 = args[1];
  switch (heff_tag_of(v_b_241409)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_241470 = heff_field(v_b_241409, 0);
    heff_take_n(v_b_241409, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241408, v_t_241470));
  }
  case TAG_BImp: {
    V v_o_241471 = heff_field(v_b_241409, 0);
    V v_x_241472 = heff_field(v_b_241409, 1);
    V v_c_241473 = heff_field(v_b_241409, 2);
    heff_take_n(v_b_241409, 7ULL, 3);
    V v_t_241474 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241408), v_o_241471));
    V v_t_241475 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241408), v_x_241472));
    V v_t_241476 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241408, v_c_241473));
    V v_t_241477 = (g_std_2edoc_2e_3c_3e(v_t_241475, v_t_241476));
    return (g_std_2edoc_2e_3c_3e(v_t_241474, v_t_241477));
  }
  case TAG_BAnn: {
    V v_o_241478 = heff_field(v_b_241409, 0);
    V v_x_241479 = heff_field(v_b_241409, 1);
    V v_cc_241480 = heff_field(v_b_241409, 2);
    V v_ty_241481 = heff_field(v_b_241409, 3);
    V v_c_241482 = heff_field(v_b_241409, 4);
    heff_take_n(v_b_241409, 31ULL, 5);
    V v_t_241483 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241408), v_o_241478));
    V v_a_241484 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241408), v_x_241479));
    V v_a_241485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241408), v_cc_241480));
    V v_b_241486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241408), v_ty_241481}));
    V v_t_241487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), v_b_241486));
    V v_b_241488 = (g_std_2edoc_2e_3c_3e(v_a_241485, v_t_241487));
    V v_t_241489 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), v_b_241488));
    V v_t_241490 = (g_std_2edoc_2e_3c_3e(v_a_241484, v_t_241489));
    V v_t_241491 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241408, v_c_241482));
    V v_t_241492 = (g_std_2edoc_2e_3c_3e(v_t_241490, v_t_241491));
    return (g_std_2edoc_2e_3c_3e(v_t_241483, v_t_241492));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241408;
    args[1] = v_b_241409;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_241409);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_env_241521 = args[0];
  V v_rest_241522 = args[1];
  V v_r_241523 = args[2];
  switch (heff_tag_of(v_r_241523)) {
  case TAG_Atom: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241579 = heff_field(v_r_241523, 0);
    V v_e_241580 = heff_field(v_r_241523, 1);
    heff_take_n(v_r_241523, 3ULL, 2);
    V v_a_241581 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241521), v_op_241579));
    V v_b_241582 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_241521, v_rest_241522, v_e_241580}));
    V v_t_241583 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), v_b_241582));
    return (g_std_2edoc_2e_3c_3e(v_a_241581, v_t_241583));
  }
  case TAG_Ann: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241522);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241521;
    args[1] = v_r_241523;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241523);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_env_241624 = args[0];
  V v_r_241625 = args[1];
  switch (heff_tag_of(v_r_241625)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241681 = heff_field(v_r_241625, 0);
    V v_e_241682 = heff_field(v_r_241625, 1);
    heff_take_n(v_r_241625, 3ULL, 2);
    V v_a_241683 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241624), v_op_241681));
    V v_b_241684 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241624, v_e_241682}));
    V v_t_241685 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), v_b_241684));
    return (g_std_2edoc_2e_3c_3e(v_a_241683, v_t_241685));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241624;
    args[1] = v_r_241625;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241625);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_r_241736 = args[0];
  V v_env_241726 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241737 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_241726, v_r_241736}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241737));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_r_241745 = args[0];
  V v_env_241726 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241746 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_241726, v_r_241745}));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241746));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_env_241726 = args[0];
  V v_first_241727 = args[1];
  V v_rest_241728 = args[2];
  V v_f_241729 = heff_dup(heff_rfield(v_env_241726, 6));
  V v_it_241730 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf(heff_dup(v_f_241729), heff_dup(v_rest_241728)));
  V v_t_241734;
  switch (heff_tag_of(v_it_241730)) {
  case TAG_Nothing: {
    heff_drop(v_f_241729);
    v_t_241734 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_it1_241731 = heff_field(v_it_241730, 0);
    heff_take_n(v_it_241730, 1ULL, 1);
    switch (heff_tag_of(v_it1_241731)) {
    case TAG_Nil: {
      heff_drop(v_f_241729);
      v_t_241734 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_o_241732 = heff_field(v_it1_241731, 0);
      V v_os_241733 = heff_field(v_it1_241731, 1);
      heff_take_n(v_it1_241731, 3ULL, 2);
      v_t_241734 = ({ V a_0 = v_f_241729; V a_1 = v_o_241732; V a_2 = v_os_241733; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_241733); r_; });
      break;
    }
    default: heff_nomatch(v_it1_241731);
    }
    break;
  }
  default: heff_nomatch(v_it_241730);
  }
  switch (heff_tag_of(v_t_241734)) {
  case TAG_Nothing: {
    V v_t_241735 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241726), v_first_241727}));
    V v_ds_241738 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_env_241726}), v_rest_241728));
    V v_t_241739 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241738; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241738); r_; });
    V v_t_241740 = (g_std_2edoc_2e_3c_3e(v_t_241735, v_t_241739));
    return (g_std_2edoc_2egroup(v_t_241740));
  }
  case TAG_Just: {
    V v_m_241741 = heff_field(v_t_241734, 0);
    heff_take_n(v_t_241734, 1ULL, 1);
    V v_t_241742 = heff_tr(heff_call(((V)&g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo), 2, (V[]){heff_dup(heff_rfield(v_env_241726, 6)), heff_dup(v_m_241741)}));
    V v_t_241743 = (g_list_2eall(v_t_241742, v_rest_241728));
    if ((heff_dup(v_t_241743) == NTAG(TAG_True))) {
      heff_drop(v_m_241741);
      heff_drop(v_t_241743);
      V v_t_241744 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241726), v_first_241727}));
      V v_ds_241747 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_env_241726}), v_rest_241728));
      V v_t_241748 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_241747; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_241747); r_; });
      V v_t_241749 = (g_std_2edoc_2e_3c_3e(v_t_241744, v_t_241748));
      return (g_std_2edoc_2egroup(v_t_241749));
    } else {
      heff_drop(v_t_241743);
      V v_t_241750 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_241726, v_m_241741, v_first_241727, NTAG(TAG_Nil), v_rest_241728}));
      return (g_std_2edoc_2egroup(v_t_241750));
    }
  }
  default: return heff_nomatch(v_t_241734);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_env_241751 = args[0];
  V v_m_241752 = args[1];
  V v_f_241753 = args[2];
  V v_acc_241754 = args[3];
  V v_rs_241755 = args[4];
  switch (heff_tag_of(v_rs_241755)) {
  case TAG_Nil: {
    heff_drop(v_m_241752);
    V v_t_241756 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241754));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_241751;
    args[1] = v_f_241753;
    args[2] = v_t_241756;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_241757 = heff_field(v_rs_241755, 0);
    V v_rest2_241758 = heff_field(v_rs_241755, 1);
    heff_take_n(v_rs_241755, 3ULL, 2);
    switch (heff_tag_of(v_r_241757)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_241814 = heff_dup(heff_field(v_r_241757, 0));
      V v_e_241815 = heff_dup(heff_field(v_r_241757, 1));
      V v_t_241816 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_241751, 6)), heff_dup(v_m_241752), heff_dup(heff_rfield(v_op_241814, 1))));
      V v_t_241819;
      switch (heff_tag_of(v_t_241816)) {
      case TAG_Tighter: {
        v_t_241819 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_241819 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_241816, 0ULL, 1);
        v_t_241819 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_241819 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_241816, 0ULL, 1);
        v_t_241819 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_241816);
      }
      if ((heff_dup(v_t_241819) == NTAG(TAG_True))) {
        heff_drop_tag(v_r_241757, 2);
        heff_drop(v_t_241819);
        V v_t_241820 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241754));
        V v_t_241821 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_241751), v_f_241753, v_t_241820}));
        V v_a_241822 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241751), v_op_241814));
        V v_b_241823 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_241751, v_m_241752, v_e_241815, NTAG(TAG_Nil), v_rest2_241758}));
        V v_t_241824 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), v_b_241823));
        V v_t_241825 = (g_std_2edoc_2e_3c_3e(v_a_241822, v_t_241824));
        V v_t_241826 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_241825));
        return (g_std_2edoc_2e_3c_3e(v_t_241821, v_t_241826));
      } else {
        heff_drop_rec(v_op_241814, 9);
        heff_drop(v_e_241815);
        heff_drop(v_t_241819);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_241751;
        args[1] = v_m_241752;
        args[2] = v_f_241753;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
        args[4] = v_rest2_241758;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_241751;
      args[1] = v_m_241752;
      args[2] = v_f_241753;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241757, v_acc_241754});
      args[4] = v_rest2_241758;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_241757);
    }
  }
  default: return heff_nomatch(v_rs_241755);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_env_241867 = args[0];
  V v_a_241868 = args[1];
  switch (heff_tag_of(v_a_241868)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_241946 = heff_field(v_a_241868, 0);
    V v_arrow_241947 = heff_field(v_a_241868, 1);
    V v_body_241948 = heff_field(v_a_241868, 2);
    heff_take_n(v_a_241868, 7ULL, 3);
    V v_a_241949 = ({ V a_0 = heff_dup(v_env_241867); V a_1 = v_p_241946; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241946); r_; });
    V v_b_241950 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241867), v_arrow_241947));
    V v_t_241951 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), v_b_241950));
    V v_t_241952 = (g_std_2edoc_2e_3c_3e(v_a_241949, v_t_241951));
    V v_t_241953 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241867, v_body_241948}));
    return (g_std_2edoc_2e_3c_3e(v_t_241952, v_t_241953));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241867;
    args[1] = v_a_241868;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_241868);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_env_241971 = args[0];
  V v_s_241972 = args[1];
  switch (heff_tag_of(v_s_241972)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_242061 = heff_field(v_s_241972, 0);
    V v_arrow_242062 = heff_field(v_s_241972, 1);
    V v_e_242063 = heff_field(v_s_241972, 2);
    heff_take_n(v_s_241972, 7ULL, 3);
    V v_a_242064 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241971), v_x_242061));
    V v_b_242065 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241971), v_arrow_242062));
    V v_t_242066 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), v_b_242065));
    V v_t_242067 = (g_std_2edoc_2e_3c_3e(v_a_242064, v_t_242066));
    V v_t_242068 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_241971, v_e_242063}));
    return (g_std_2edoc_2e_3c_3e(v_t_242067, v_t_242068));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241971;
    args[1] = v_s_241972;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_241972);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_env_242075 = args[0];
  V v_f_242076 = args[1];
  switch (heff_tag_of(v_f_242076)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_242100 = heff_field(v_f_242076, 0);
    V v_eq_242101 = heff_field(v_f_242076, 1);
    V v_e_242102 = heff_field(v_f_242076, 2);
    heff_take_n(v_f_242076, 7ULL, 3);
    V v_a_242103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242075), v_x_242100}));
    V v_b_242104 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242075), v_eq_242101));
    V v_t_242105 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), v_b_242104));
    V v_t_242106 = (g_std_2edoc_2e_3c_3e(v_a_242103, v_t_242105));
    V v_t_242107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242075, v_e_242102}));
    return (g_std_2edoc_2e_3c_3e(v_t_242106, v_t_242107));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_242113 = heff_field(v_f_242076, 0);
    V v_eq_242114 = heff_field(v_f_242076, 1);
    V v_e_242115 = heff_field(v_f_242076, 2);
    heff_take_n(v_f_242076, 7ULL, 3);
    V v_a_242116 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242075), v_x_242113));
    V v_b_242117 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242075), v_eq_242114));
    V v_t_242118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), v_b_242117));
    V v_t_242119 = (g_std_2edoc_2e_3c_3e(v_a_242116, v_t_242118));
    V v_t_242120 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242075, v_e_242115}));
    return (g_std_2edoc_2e_3c_3e(v_t_242119, v_t_242120));
  }
  case TAG_EFDefault: {
    V v_d_242121 = heff_field(v_f_242076, 0);
    V v_eq_242122 = heff_field(v_f_242076, 1);
    V v_e_242123 = heff_field(v_f_242076, 2);
    heff_take_n(v_f_242076, 7ULL, 3);
    V v_a_242124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242075), v_d_242121}));
    V v_b_242125 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242075), v_eq_242122));
    V v_t_242126 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_242125));
    V v_t_242127 = (g_std_2edoc_2e_3c_3e(v_a_242124, v_t_242126));
    V v_t_242128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242075, v_e_242123}));
    return (g_std_2edoc_2e_3c_3e(v_t_242127, v_t_242128));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242075;
    args[1] = v_f_242076;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_242076);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_ds_2424 = (g_list_2ezipWith(heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}), v_bars_245, v_more_247));
        V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_2424; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop(v_ds_2424); r_; });
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2425));
        V v_t_2427 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2426));
        return (g_std_2edoc_2egroup(v_t_2427));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_x2_245 = ({ V a_0 = heff_take_field(v_t_244, 7); V b_1 = heff_get_n(v_env_240, 1, 7); V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x1_247;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_x1_247 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_x1_247 = v_x_246;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2410 = heff_get_n(v_t_244, 8, 9);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      heff_drop_rec(v_t_244, 9);
      v_t_2410 = heff_get_n(v_x_248, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_2411;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      v_t_2411 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
    } else {
      heff_drop(v_t_2410);
      v_t_2411 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2411));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DInstance: {
    V v_n_2411 = heff_field(v_d_240, 1);
    V v_x2_2414 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_DEqn: {
    V v_n_2417 = heff_field(v_d_240, 0);
    V v_x2_2422 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2417)));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_244));
    V v_t_2445;
    switch (heff_tag_of(v_d_244)) {
    case TAG_DImport: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2443 = heff_dup(heff_field(v_d_244, 0));
      v_t_2445 = heff_strEq(heff_get_n(v_w_2443, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_t_2466;
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
      V v_t_2447 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
      V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2446, v_t_2447, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_244)})));
      V v_t_2450 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_244); r_; });
      V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2450, v_ds_245));
      v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2451));
    } else {
      heff_drop(v_t_2445);
      V v_t_2452 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_t_2452);
        V v_t_2453 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2454 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_244));
        V v_t_2455 = (g_heff_2esyntax_2efmt_2elayout_2edefLast(v_t_2454, heff_dup(v_d_244), v_ds_245));
        V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(v_t_2455));
        V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2453, v_t_2456));
        V v_t_2458 = ({ V a_0 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_244); r_; });
        V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(v_t_2458, v_ds_245));
        V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_t_2459));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460));
      } else {
        heff_drop(v_t_2452);
        V v_t_2461 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2462 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
        V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2461, v_t_2462, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){v_d_244})));
        V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_ds_245));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2465));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2466));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2448 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2448; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2463 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2463; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1), v_s_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_s_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_s_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x2_2411;
  if (heff_intEq_c(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get())), MK_INT(0LL))) {
    v_x2_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_249, NTAG(TAG_Nil)});
  } else {
    v_x2_2411 = (g_prelude_2esplitFrom(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), v_s_249, MK_INT(0LL), NTAG(TAG_Nil)));
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2efmtParsed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2efmtParsed(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Left = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_at_240, 2);
    return heff_tag_at_n(v_ru_24x2_241_24Left, TAG_Left, 1, (V[]){v_e_242});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Right = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_env_244 = heff_take_field(v_at_240, 1);
    V v_eof_245 = (g_heff_2esyntax_2efmt_2elayout_2eeofOf(heff_get_n(v_at_240, 0, 2)));
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_dup(v_env_244), MK_INT(0LL), NTAG(TAG_False), v_ds_243));
    V v_x2_247 = (g_map_2elookup_24s567992785x1569911877(heff_get_n(v_eof_245, 7, 9), heff_rfield(v_env_244, 1)));
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2410 = ({ V a_0 = v_env_244; V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410));
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2411));
    return heff_tag_at_n(v_ru_24x2_241_24Right, TAG_Right, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2efmtParsed_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2efmtParsed(a[0], a[1]);
}