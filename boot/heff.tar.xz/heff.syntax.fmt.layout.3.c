// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_i 323
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtParsed_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_prelude_2e_2b_2b_24f201610143x1454021782(V, V);
V g_prelude_2e_2b_2b_24f201610143x1454021782_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f201610143x1454021782_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_x1_248;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_x1_248 = NTAG(TAG_Nil);
  } else {
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        v_x1_248 = v_x_247;
      } else {
        heff_drop(v_field_245);
        v_x1_248 = NTAG(TAG_Nil);
      }
    }
  }
  V v_t_2419;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    V v_t_2417;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
      v_t_2417 = NTAG(TAG_Nil);
    } else {
      HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2416 = v_field_2414;
          v_t_2417 = v_x_2416;
        } else {
          heff_drop(v_field_2414);
          v_t_2417 = NTAG(TAG_Nil);
        }
      }
    }
    V v_t_2418 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2417); r_; });
    v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2418, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  HeffT2 v_t_2420 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 2), heff_dup(heff_rfield(v_t_241, 7))));
  V v_t_2425;
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_x_2424 = v_field_2422;
      v_t_2425 = v_x_2424;
    } else {
      heff_drop(v_field_2422);
      v_t_2425 = NTAG(TAG_Nil);
    }
  }
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2425); r_; });
  V v_s_2427 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2429;
  if (heff_strEq_c_lent(v_s_2427, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2427);
    v_t_2429 = NTAG(TAG_None);
  } else {
    v_t_2429 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2427});
  }
  V v_t_2431;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2431 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2431 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_t_2429, v_t_2431));
  V v_t_2433 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2432));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2433);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_c_242, 0)));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2453));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2453));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2476 = heff_field(v_e_240, 3);
    V t_0 = v_body_2476;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2439 = heff_field(v_x1_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2439, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EField: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_App: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Op: {
    V v_a_2454 = heff_field(v_e_240, 0);
    V v_op_2455 = heff_field(v_e_240, 1);
    V v_b_2456 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_2456)));
    {
      V v_field_2458 = v_t_2457.f[0];
      V v_field_2459 = v_t_2457.f[1];
      V v_bf_2460 = v_field_2458;
      V v_rest_2461 = v_field_2459;
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2455), v_rest_2461));
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop(v_b_2456);
        heff_drop(v_t_2462);
        V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_bf_2460}), v_rest_2461});
        return ((HeffT2){{v_a_2454, v_t_2463}});
      } else {
        heff_drop(v_bf_2460);
        heff_drop(v_rest_2461);
        heff_drop(v_t_2462);
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_b_2456}), NTAG(TAG_Nil)});
        return ((HeffT2){{v_a_2454, v_t_2464}});
      }
    }
  }
  case TAG_Ops: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_If: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2461 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2461, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetMut: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAssign: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFor: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EJump: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EReturn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_IfThen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_r_242, 0);
    V v_t_2463 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2461, 1))));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2453 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24App = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    V v_x1_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2453));
    V v_it_2458;
    switch (heff_tag_of(v_x1_2454)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24App, 2);
      v_it_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x1_2454, 0);
      V v_rev_2456 = heff_field(v_x1_2454, 1);
      heff_take_n(v_x1_2454, 3ULL, 2);
      V v_t_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2456));
      v_it_2458 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24App, TAG_MkPair, 2, (V[]){v_t_2457, v_x_2455})});
      break;
    }
    default: heff_nomatch(v_x1_2454);
    }
    switch (heff_tag_of(v_it_2458)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_it1_2459 = heff_field(v_it_2458, 0);
      heff_take_n(v_it_2458, 1ULL, 1);
      switch (heff_tag_of(v_it1_2459)) {
      case TAG_MkPair: {
        V v_it12_2461 = heff_field(v_it1_2459, 1);
        heff_take_n(v_it1_2459, 2ULL, 2);
        switch (heff_tag_of(v_it12_2461)) {
        case TAG_Atom: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 1); r_; });
        }
        case TAG_EParen: {
          V v_e_2464 = heff_field(v_it12_2461, 1);
          heff_take_n(v_it12_2461, 2ULL, 3);
          return ({ V a_0 = v_e_2464; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2464); r_; });
        }
        case TAG_Named: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 5); r_; });
        }
        case TAG_Tup: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        case TAG_Seg: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_Braces: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        case TAG_Update: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 6); r_; });
        }
        case TAG_EUSet: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_InstB: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 5); r_; });
        }
        case TAG_EFSet: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_EFDefault: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_Sum: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 5); r_; });
        }
        case TAG_ECon: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_EField: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_ENeg: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_App: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_Op: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_Ops: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_OpRhs: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_Ann: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_BVar: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 1); r_; });
        }
        case TAG_BImp: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_BAnn: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 5); r_; });
        }
        case TAG_Lam: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        case TAG_Case: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        case TAG_EAlt: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_If: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 6); r_; });
        }
        case TAG_Do: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_ESBind: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_ELet: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 6); r_; });
        }
        case TAG_ELetMut: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 6); r_; });
        }
        case TAG_EAssign: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 3); r_; });
        }
        case TAG_EWhile: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        case TAG_EFor: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 6); r_; });
        }
        case TAG_EJump: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 1); r_; });
        }
        case TAG_EReturn: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 2); r_; });
        }
        case TAG_ENest: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        case TAG_IfThen: {
          return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_it12_2461, 4); r_; });
        }
        default: return heff_nomatch(v_it12_2461);
        }
      }
      default: return heff_nomatch(v_it1_2459);
      }
    }
    default: return heff_nomatch(v_it_2458);
    }
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a[0]);
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_take_field(v_t_246, 7)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = heff_get_n(v_t_246, 8, 9);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop_rec(v_t_246, 9);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_249);
          v_t_2414 = heff_get_n(v_t_246, 8, 9);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str111, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str113, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str115, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str116, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str117, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str118, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str119, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str122, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str123, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str125, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str126, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str127, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str128, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str129, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str131, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str132, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str133, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str135, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str136, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str137, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str138, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str140, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam108, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam109, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam110, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam111, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam112, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam115, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam116, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam117, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam118, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam25_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam26_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam27_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam108_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam109_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam110_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam111_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam112_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam115_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam116_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam117_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam118_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2445 = args[0];
  V v_e_2446 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2445));
  V v_one_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2446));
  V v_b_2453;
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_t_2449);
    V v_d_2450 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2450});
  } else {
    heff_drop(v_t_2449);
    V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(heff_dup(v_e_2446)));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      V v_d_2452 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
      v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2452});
    } else {
      heff_drop(v_t_2451);
      v_b_2453 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    }
  }
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2453));
  V v_t_2455 = (g_std_2edoc_2e_3c_3e(v_a_2447, v_t_2454));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2455));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  V v_d_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2467 = heff_intSub(v_k_2465, v_i_2466);
  if (heff_intEq_c_lent(v_i_2467, MK_INT(0LL), 2)) {
    heff_drop(v_i_2467);
    return v_d_2464;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2467, v_d_2464});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2465 = args[0];
  V v_d_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2465, v_d_2464})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2474 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2489 = args[0];
  V v_f_2490 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2489));
  V v_d_2492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2490}));
  V v_t_2493 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2492})));
  V v_t_2494 = (g_std_2edoc_2e_3c_3e(v_a_2491, v_t_2493));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2494));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24103 = args[0];
  V v_k_24102 = heff_env(self)[0];
  V v_d_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24104 = heff_intSub(v_k_24102, v_i_24103);
  if (heff_intEq_c_lent(v_i_24104, MK_INT(0LL), 2)) {
    heff_drop(v_i_24104);
    return v_d_24101;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24104, v_d_24101});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24102 = args[0];
  V v_d_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24102, v_d_24101})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24131 = args[0];
  V v_f_24132 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24131));
  V v_d_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24132}));
  V v_t_24135 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24134})));
  V v_t_24136 = (g_std_2edoc_2e_3c_3e(v_a_24133, v_t_24135));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24147 = args[0];
  V v_k_24146 = heff_env(self)[0];
  V v_d_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24148 = heff_intSub(v_k_24146, v_i_24147);
  if (heff_intEq_c_lent(v_i_24148, MK_INT(0LL), 2)) {
    heff_drop(v_i_24148);
    return v_d_24145;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24148, v_d_24145});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24146 = args[0];
  V v_d_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24146, v_d_24145})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24205 = args[0];
  V v_a_24206 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24188 = heff_env(self)[1];
  V v_c_24191 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24207 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24188, 4, 9), heff_get_n(v_c_24191, 3, 9)));
  V v_t_24208;
  if ((heff_dup(v_x1_24207) == NTAG(TAG_True))) {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24209 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24205));
  V v_b_24210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24206}));
  V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24210));
  V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
  return (g_std_2edoc_2e_3c_3e(v_t_24208, v_t_24212));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24219 = args[0];
  V v_k_24218 = heff_env(self)[0];
  V v_d_24217 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24220 = heff_intSub(v_k_24218, v_i_24219);
  if (heff_intEq_c_lent(v_i_24220, MK_INT(0LL), 2)) {
    heff_drop(v_i_24220);
    return v_d_24217;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24220, v_d_24217});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24218 = args[0];
  V v_d_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24218, v_d_24217})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24227 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24227}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24249 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24250 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24249));
  V v_t_24251;
  if ((heff_dup(v_x1_24250) == NTAG(TAG_True))) {
    heff_drop(v_x1_24250);
    v_t_24251 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24250);
    v_t_24251 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24247, v_r_24249}));
  return (g_std_2edoc_2e_3c_3e(v_t_24251, v_t_24252));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24365 = args[0];
  V v_k_24364 = heff_env(self)[0];
  V v_d_24363 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24366 = heff_intSub(v_k_24364, v_i_24365);
  if (heff_intEq_c_lent(v_i_24366, MK_INT(0LL), 2)) {
    heff_drop(v_i_24366);
    return v_d_24363;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24366, v_d_24363});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24364 = args[0];
  V v_d_24363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24364, v_d_24363})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24411 = args[0];
  V v_k_24410 = heff_env(self)[0];
  V v_d_24407 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24412 = heff_intSub(v_k_24410, v_i_24411);
  if (heff_intEq_c_lent(v_i_24412, MK_INT(0LL), 2)) {
    heff_drop(v_i_24412);
    return v_d_24407;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24412, v_d_24407});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24410 = args[0];
  V v_d_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24410, v_d_24407})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24431 = args[0];
  V v_k_24430 = heff_env(self)[0];
  V v_d_24427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24432 = heff_intSub(v_k_24430, v_i_24431);
  if (heff_intEq_c_lent(v_i_24432, MK_INT(0LL), 2)) {
    heff_drop(v_i_24432);
    return v_d_24427;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24432, v_d_24427});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24430 = args[0];
  V v_d_24427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24430, v_d_24427})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2435));
      V v_t_2444;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        V v_d_2441 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2441});
      } else {
        heff_drop(v_t_2440);
        V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(heff_dup(v_e1_2435)));
        if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
          heff_drop(v_t_2442);
          V v_d_2443 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
          v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2443});
        } else {
          heff_drop(v_t_2442);
          v_t_2444 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        }
      }
      V v_t_2456 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2457 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2458;
      if ((heff_dup(v_x1_2457) == NTAG(TAG_True))) {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2444, v_t_2461));
      V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2462));
      V v_d_2464 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2463));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2464})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2469 = heff_field(v_e0_241, 0);
    V v_cc_2470 = heff_field(v_e0_241, 1);
    V v_spec_2471 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2469}));
    V v_t_2473 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2470));
    V v_t_2475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2471; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2471); r_; });
    V v_t_2476 = (g_std_2edoc_2e_3c_3e(v_t_2473, v_t_2475));
    return (g_std_2edoc_2e_3c_3e(v_t_2472, v_t_2476));
  }
  case TAG_Braces: {
    V v_o_2477 = heff_field(v_e0_241, 0);
    V v_fs_2478 = heff_field(v_e0_241, 1);
    V v_commas_2479 = heff_field(v_e0_241, 2);
    V v_c_2480 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2478)) {
    case TAG_Nil: {
      heff_drop(v_commas_2479);
      V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2477));
      V v_t_2482 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      return (g_std_2edoc_2e_3c_3e(v_t_2481, v_t_2482));
    }
    case TAG_Cons: {
      V v_f1_2483 = heff_field(v_fs_2478, 0);
      V v_more_2484 = heff_field(v_fs_2478, 1);
      V v_ru_24fs_2478_24Cons = heff_take_reuse_n(v_fs_2478, 3ULL, 2);
      V v_a_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2477)));
      V v_d_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2483}));
      V v_t_2487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2478_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2486})));
      V v_t_2488 = (g_std_2edoc_2e_3c_3e(v_a_2485, v_t_2487));
      V v_t_2495 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2479; V a_3 = v_more_2484; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2479); heff_drop(v_more_2484); r_; });
      V v_x1_2496 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2477, 4, 9), heff_dup(heff_rfield(v_c_2480, 3))));
      V v_t_2497;
      if ((heff_dup(v_x1_2496) == NTAG(TAG_True))) {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2498 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2497, v_t_2498));
      V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2499));
      V v_d_24101 = (g_std_2edoc_2e_3c_3e(v_t_2488, v_t_24100));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_24101})})));
    }
    default: return heff_nomatch(v_fs_2478);
    }
  }
  case TAG_Update: {
    V v_o_24106 = heff_field(v_e0_241, 0);
    V v_r_24107 = heff_field(v_e0_241, 1);
    V v_bar_24108 = heff_field(v_e0_241, 2);
    V v_fs_24109 = heff_field(v_e0_241, 3);
    V v_commas_24110 = heff_field(v_e0_241, 4);
    V v_c_24111 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24109)) {
    case TAG_Nil: {
      heff_drop(v_commas_24110);
      V v_a_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24106));
      V v_a_24113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_a_24114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_b_24115 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24116));
      V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24117));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24118));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24119));
      return (g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24120));
    }
    case TAG_Cons: {
      V v_f1_24121 = heff_field(v_fs_24109, 0);
      V v_more_24122 = heff_field(v_fs_24109, 1);
      V v_ru_24fs_24109_24Cons = heff_take_reuse_n(v_fs_24109, 3ULL, 2);
      V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24106)));
      V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24109_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24124})));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_a_24127 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_d_24128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24121}));
      V v_t_24129 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24128})));
      V v_t_24130 = (g_std_2edoc_2e_3c_3e(v_a_24127, v_t_24129));
      V v_t_24137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24110; V a_3 = v_more_24122; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24110); heff_drop(v_more_24122); r_; });
      V v_x1_24138 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24106, 4, 9), heff_dup(heff_rfield(v_c_24111, 3))));
      V v_t_24139;
      if ((heff_dup(v_x1_24138) == NTAG(TAG_True))) {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24140 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(v_t_24139, v_t_24140));
      V v_t_24142 = (g_std_2edoc_2e_3c_3e(v_t_24137, v_t_24141));
      V v_t_24143 = (g_std_2edoc_2e_3c_3e(v_t_24130, v_t_24142));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24143));
      V v_d_24145 = (g_std_2edoc_2e_3c_3e(v_t_24126, v_t_24144));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24145})})));
    }
    default: return heff_nomatch(v_fs_24109);
    }
  }
  case TAG_EUSet: {
    V v_x_24150 = heff_field(v_e0_241, 0);
    V v_eq_24151 = heff_field(v_e0_241, 1);
    V v_e_24152 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24150}));
    V v_b_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24151));
    V v_t_24155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24154));
    V v_t_24156 = (g_std_2edoc_2e_3c_3e(v_a_24153, v_t_24155));
    V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24152}));
    return (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
  }
  case TAG_InstB: {
    V v_o_24158 = heff_field(v_e0_241, 0);
    V v_o2_24159 = heff_field(v_e0_241, 1);
    V v_d_24160 = heff_field(v_e0_241, 2);
    V v_c1_24161 = heff_field(v_e0_241, 3);
    V v_c_24162 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24158));
    V v_t_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24159));
    V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24160}));
    V v_t_24166 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24161));
    V v_t_24167 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24162));
    V v_t_24168 = (g_std_2edoc_2e_3c_3e(v_t_24166, v_t_24167));
    V v_t_24169 = (g_std_2edoc_2e_3c_3e(v_t_24165, v_t_24168));
    V v_t_24170 = (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24169));
    return (g_std_2edoc_2e_3c_3e(v_t_24163, v_t_24170));
  }
  case TAG_EFSet: {
    V v_x_24171 = heff_field(v_e0_241, 0);
    V v_eq_24172 = heff_field(v_e0_241, 1);
    V v_e_24173 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24174 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24171));
    V v_b_24175 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24172));
    V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24175));
    V v_t_24177 = (g_std_2edoc_2e_3c_3e(v_a_24174, v_t_24176));
    V v_t_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24173}));
    return (g_std_2edoc_2e_3c_3e(v_t_24177, v_t_24178));
  }
  case TAG_EFDefault: {
    V v_d_24179 = heff_field(v_e0_241, 0);
    V v_eq_24180 = heff_field(v_e0_241, 1);
    V v_e_24181 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24179}));
    V v_b_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24180));
    V v_t_24184 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24183));
    V v_t_24185 = (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24184));
    V v_t_24186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24181}));
    return (g_std_2edoc_2e_3c_3e(v_t_24185, v_t_24186));
  }
  case TAG_Sum: {
    V v_kw_24187 = heff_field(v_e0_241, 0);
    V v_o_24188 = heff_field(v_e0_241, 1);
    V v_alts_24189 = heff_field(v_e0_241, 2);
    V v_bars_24190 = heff_field(v_e0_241, 3);
    V v_c_24191 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24189)) {
    case TAG_Nil: {
      heff_drop(v_bars_24190);
      V v_a_24192 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24193 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24188));
      V v_b_24194 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24195 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24194));
      V v_t_24196 = (g_std_2edoc_2e_3c_3e(v_a_24193, v_t_24195));
      V v_t_24197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24196));
      return (g_std_2edoc_2e_3c_3e(v_a_24192, v_t_24197));
    }
    case TAG_Cons: {
      V v_a1_24198 = heff_field(v_alts_24189, 0);
      V v_more_24199 = heff_field(v_alts_24189, 1);
      heff_take_n(v_alts_24189, 3ULL, 2);
      V v_a_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24201 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24188)));
      V v_b_24202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24198}));
      V v_t_24203 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24202));
      V v_t_24204 = (g_std_2edoc_2e_3c_3e(v_a_24201, v_t_24203));
      V v_a_24213 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24188, heff_dup(v_c_24191)}); V a_2 = v_bars_24190; V a_3 = v_more_24199; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24190); heff_drop(v_more_24199); r_; });
      V v_b_24214 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24215 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24214));
      V v_t_24216 = (g_std_2edoc_2e_3c_3e(v_a_24213, v_t_24215));
      V v_d_24217 = (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24216));
      V v_b_24222 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24217})})));
      V v_t_24223 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24222));
      return (g_std_2edoc_2e_3c_3e(v_a_24200, v_t_24223));
    }
    default: return heff_nomatch(v_alts_24189);
    }
  }
  case TAG_ECon: {
    V v_c_24224 = heff_field(v_e0_241, 0);
    V v_args_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24224));
    V v_t_24229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24225; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24225); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24229));
  }
  case TAG_EField: {
    V v_e_24230 = heff_field(v_e0_241, 0);
    V v_f_24231 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24230}));
    V v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24231));
    return (g_std_2edoc_2e_3c_3e(v_t_24232, v_t_24233));
  }
  case TAG_ENeg: {
    V v_m_24234 = heff_field(v_e0_241, 0);
    V v_e_24235 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24236 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24234));
    V v_t_24237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24235}));
    return (g_std_2edoc_2e_3c_3e(v_t_24236, v_t_24237));
  }
  case TAG_App: {
    V v_h_24238 = heff_field(v_e0_241, 0);
    V v_args_24239 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24238;
    heff_room[2] = v_args_24239;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24240 = heff_field(v_e0_241, 0);
    V v_op_24241 = heff_field(v_e0_241, 1);
    V v_b_24242 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24243 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24240, v_op_24241, v_b_24242})));
    {
      V v_field_24244 = v_t_24243.f[0];
      V v_field_24245 = v_t_24243.f[1];
      V v_first_24246 = v_field_24244;
      V v_rest_24247 = v_field_24245;
      V v_t_24248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24247), v_first_24246}));
      V v_t_24253 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24247)}); V a_2 = v_rest_24247; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24247); r_; });
      V v_t_24254 = (g_std_2edoc_2e_3c_3e(v_t_24248, v_t_24253));
      return (g_std_2edoc_2egroup(v_t_24254));
    }
  }
  case TAG_Ops: {
    V v_a_24255 = heff_field(v_e0_241, 0);
    V v_rest_24256 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24255;
    heff_room[2] = v_rest_24256;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24257 = heff_field(v_e0_241, 0);
    V v_e_24258 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24259 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24257));
    V v_b_24260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24258}));
    V v_t_24261 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24260));
    return (g_std_2edoc_2e_3c_3e(v_a_24259, v_t_24261));
  }
  case TAG_Ann: {
    V v_e_24262 = heff_field(v_e0_241, 0);
    V v_cc_24263 = heff_field(v_e0_241, 1);
    V v_ty_24264 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24265 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24262}));
    V v_b_24266 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24263));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24266));
    V v_t_24268 = (g_std_2edoc_2e_3c_3e(v_a_24265, v_t_24267));
    V v_t_24269 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24264}));
    V v_d_24270 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24269));
    V v_t_24271 = (g_std_2edoc_2e_3c_3e(v_t_24268, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24270})));
    return (g_std_2edoc_2egroup(v_t_24271));
  }
  case TAG_BVar: {
    V v_t_24272 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24272));
  }
  case TAG_BImp: {
    V v_o_24273 = heff_field(v_e0_241, 0);
    V v_x_24274 = heff_field(v_e0_241, 1);
    V v_c_24275 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24276 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24273));
    V v_t_24277 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24274));
    V v_t_24278 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24275));
    V v_t_24279 = (g_std_2edoc_2e_3c_3e(v_t_24277, v_t_24278));
    return (g_std_2edoc_2e_3c_3e(v_t_24276, v_t_24279));
  }
  case TAG_BAnn: {
    V v_o_24280 = heff_field(v_e0_241, 0);
    V v_x_24281 = heff_field(v_e0_241, 1);
    V v_cc_24282 = heff_field(v_e0_241, 2);
    V v_ty_24283 = heff_field(v_e0_241, 3);
    V v_c_24284 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24285 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24280));
    V v_a_24286 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24281));
    V v_a_24287 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24282));
    V v_b_24288 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24283}));
    V v_t_24289 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24288));
    V v_t_24290 = (g_std_2edoc_2e_3c_3e(v_a_24287, v_t_24289));
    V v_t_24291 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24290));
    V v_t_24292 = (g_std_2edoc_2e_3c_3e(v_a_24286, v_t_24291));
    V v_t_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24284));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(v_t_24292, v_t_24293));
    return (g_std_2edoc_2e_3c_3e(v_t_24285, v_t_24294));
  }
  case TAG_Lam: {
    V v_bs_24295 = heff_field(v_e0_241, 0);
    V v_binders_24296 = heff_field(v_e0_241, 1);
    V v_arrow_24297 = heff_field(v_e0_241, 2);
    V v_body_24298 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24299 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24295));
    V v_t_24300 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24301 = (g_list_2emap(v_t_24300, v_binders_24296));
    V v_a_24302 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24301; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24301); r_; });
    V v_b_24303 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24297));
    V v_t_24304 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24303));
    V v_t_24305 = (g_std_2edoc_2e_3c_3e(v_a_24302, v_t_24304));
    V v_t_24306 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24298));
    V v_t_24310;
    if ((heff_dup(v_t_24306) == NTAG(TAG_True))) {
      heff_drop(v_t_24306);
      V v_t_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      v_t_24310 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24307));
    } else {
      heff_drop(v_t_24306);
      V v_t_24308 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24298}));
      V v_d_24309 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24308));
      v_t_24310 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24309})));
    }
    V v_t_24311 = (g_std_2edoc_2e_3c_3e(v_t_24305, v_t_24310));
    return (g_std_2edoc_2e_3c_3e(v_t_24299, v_t_24311));
  }
  case TAG_Case: {
    V v_kw_24312 = heff_field(v_e0_241, 0);
    V v_scrut_24313 = heff_field(v_e0_241, 1);
    V v_of2_24314 = heff_field(v_e0_241, 2);
    V v_alts_24315 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24316 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24312));
    V v_a_24317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24313}));
    V v_b_24318 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24314));
    V v_t_24319 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24318));
    V v_t_24320 = (g_std_2edoc_2e_3c_3e(v_a_24317, v_t_24319));
    V v_t_24321 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24320));
    V v_t_24322 = (g_std_2edoc_2e_3c_3e(v_a_24316, v_t_24321));
    V v_t_24323 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24315; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24315); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24322, v_t_24323));
  }
  case TAG_EAlt: {
    V v_p_24324 = heff_field(v_e0_241, 0);
    V v_arrow_24325 = heff_field(v_e0_241, 1);
    V v_body_24326 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24327 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24324; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24324); r_; });
    V v_b_24328 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24325));
    V v_t_24329 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24328));
    V v_t_24330 = (g_std_2edoc_2e_3c_3e(v_a_24327, v_t_24329));
    V v_t_24331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24326}));
    return (g_std_2edoc_2e_3c_3e(v_t_24330, v_t_24331));
  }
  case TAG_If: {
    V v_kw_24332 = heff_field(v_e0_241, 0);
    V v_c_24333 = heff_field(v_e0_241, 1);
    V v_th_24334 = heff_field(v_e0_241, 2);
    V v_a_24335 = heff_field(v_e0_241, 3);
    V v_el_24336 = heff_field(v_e0_241, 4);
    V v_b_24337 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24332, v_c_24333, v_th_24334, v_a_24335}));
    V v_t_24339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24336, v_b_24337}));
    V v_t_24340 = (g_std_2edoc_2e_3c_3e(v_t_24338, v_t_24339));
    return (g_std_2edoc_2egroup(v_t_24340));
  }
  case TAG_Do: {
    V v_kw_24341 = heff_field(v_e0_241, 0);
    V v_stmts_24342 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24343 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24341));
    V v_t_24344 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24342; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24342); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
  }
  case TAG_ESBind: {
    V v_x_24345 = heff_field(v_e0_241, 0);
    V v_arrow_24346 = heff_field(v_e0_241, 1);
    V v_e_24347 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24348 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24345));
    V v_b_24349 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24346));
    V v_t_24350 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24349));
    V v_t_24351 = (g_std_2edoc_2e_3c_3e(v_a_24348, v_t_24350));
    V v_t_24352 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24347}));
    return (g_std_2edoc_2e_3c_3e(v_t_24351, v_t_24352));
  }
  case TAG_ELet: {
    V v_kw_24353 = heff_field(v_e0_241, 0);
    V v_p_24354 = heff_field(v_e0_241, 1);
    V v_ann_24355 = heff_field(v_e0_241, 2);
    V v_eq_24356 = heff_field(v_e0_241, 3);
    V v_e_24357 = heff_field(v_e0_241, 4);
    V v_body_24358 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24358)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357});
    }
    case TAG_Just: {
      V v_it1_24359 = heff_field(v_body_24358, 0);
      V v_ru_24body_24358_24Just = heff_take_reuse_n(v_body_24358, 1ULL, 1);
      switch (heff_tag_of(v_it1_24359)) {
      case TAG_MkPair: {
        V v_i_24360 = heff_field(v_it1_24359, 0);
        V v_b_24361 = heff_field(v_it1_24359, 1);
        heff_take_n(v_it1_24359, 3ULL, 2);
        V v_t_24362 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24353, v_p_24354, v_ann_24355, v_eq_24356, v_e_24357, v_i_24360, v_b_24361}));
        V v_d_24363 = (g_std_2edoc_2egroup(v_t_24362));
        return heff_tag_at_n(v_ru_24body_24358_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24363})});
      }
      default: return heff_nomatch(v_it1_24359);
      }
    }
    default: return heff_nomatch(v_body_24358);
    }
  }
  case TAG_ELetMut: {
    V v_kw_24368 = heff_field(v_e0_241, 0);
    V v_m_24369 = heff_field(v_e0_241, 1);
    V v_x_24370 = heff_field(v_e0_241, 2);
    V v_ann_24371 = heff_field(v_e0_241, 3);
    V v_eq_24372 = heff_field(v_e0_241, 4);
    V v_e_24373 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24374 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24368));
    V v_a_24375 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24369));
    V v_b_24376 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24370));
    V v_t_24377 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24376));
    V v_t_24378 = (g_std_2edoc_2e_3c_3e(v_a_24375, v_t_24377));
    V v_t_24379 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24378));
    V v_t_24380 = (g_std_2edoc_2e_3c_3e(v_a_24374, v_t_24379));
    V v_a_24388;
    switch (heff_tag_of(v_ann_24371)) {
    case TAG_Nothing: {
      v_a_24388 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24381 = heff_field(v_ann_24371, 0);
      V v_ru_24ann_24371_24Just = heff_take_reuse_n(v_ann_24371, 1ULL, 1);
      switch (heff_tag_of(v_it1_24381)) {
      case TAG_MkPair: {
        V v_cc_24382 = heff_field(v_it1_24381, 0);
        V v_ty_24383 = heff_field(v_it1_24381, 1);
        heff_take_n(v_it1_24381, 3ULL, 2);
        V v_a_24384 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24382));
        V v_b_24385 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24383}));
        V v_t_24386 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24371_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24385));
        V v_t_24387 = (g_std_2edoc_2e_3c_3e(v_a_24384, v_t_24386));
        v_a_24388 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24387));
        break;
      }
      default: heff_nomatch(v_it1_24381);
      }
      break;
    }
    default: heff_nomatch(v_ann_24371);
    }
    V v_b_24389 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24372));
    V v_t_24390 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24389));
    V v_t_24391 = (g_std_2edoc_2e_3c_3e(v_a_24388, v_t_24390));
    V v_t_24392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24373}));
    V v_t_24393 = (g_std_2edoc_2e_3c_3e(v_t_24391, v_t_24392));
    return (g_std_2edoc_2e_3c_3e(v_t_24380, v_t_24393));
  }
  case TAG_EAssign: {
    V v_x_24394 = heff_field(v_e0_241, 0);
    V v_k_24395 = heff_field(v_e0_241, 1);
    V v_e_24396 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24397 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24394));
    V v_b_24398 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24395));
    V v_t_24399 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24398));
    V v_t_24400 = (g_std_2edoc_2e_3c_3e(v_a_24397, v_t_24399));
    V v_t_24401 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24396}));
    return (g_std_2edoc_2e_3c_3e(v_t_24400, v_t_24401));
  }
  case TAG_EWhile: {
    V v_kw_24402 = heff_field(v_e0_241, 0);
    V v_c_24403 = heff_field(v_e0_241, 1);
    V v_d_24404 = heff_field(v_e0_241, 2);
    V v_body_24405 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24406 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24402));
    V v_d_24407 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24403}));
    V v_b_24408 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24404));
    V v_t_24409 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24408));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24407})}), v_t_24409));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_t_24414));
    V v_t_24416 = (g_std_2edoc_2e_3c_3e(v_a_24406, v_t_24415));
    V v_t_24417 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24405; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24405); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24416, v_t_24417));
  }
  case TAG_EFor: {
    V v_kw_24418 = heff_field(v_e0_241, 0);
    V v_p_24419 = heff_field(v_e0_241, 1);
    V v_i_24420 = heff_field(v_e0_241, 2);
    V v_c_24421 = heff_field(v_e0_241, 3);
    V v_d_24422 = heff_field(v_e0_241, 4);
    V v_body_24423 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24418));
    V v_a_24425 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24419; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24419); r_; });
    V v_a_24426 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24420));
    V v_d_24427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24421}));
    V v_b_24428 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24422));
    V v_t_24429 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24428));
    V v_t_24434 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24427})}), v_t_24429));
    V v_t_24435 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24434));
    V v_t_24436 = (g_std_2edoc_2e_3c_3e(v_a_24426, v_t_24435));
    V v_t_24437 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_t_24436));
    V v_t_24438 = (g_std_2edoc_2e_3c_3e(v_a_24425, v_t_24437));
    V v_t_24439 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24438));
    V v_t_24440 = (g_std_2edoc_2e_3c_3e(v_a_24424, v_t_24439));
    V v_t_24441 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24423; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24423); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24440, v_t_24441));
  }
  case TAG_EJump: {
    V v_kw_24442 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_kw_24442));
  }
  case TAG_EReturn: {
    V v_kw_24443 = heff_field(v_e0_241, 0);
    V v_e_24444 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24445 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24443));
    V v_d_24446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24444}));
    V v_t_24447 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24446})));
    return (g_std_2edoc_2e_3c_3e(v_a_24445, v_t_24447));
  }
  case TAG_ENest: {
    V v_o_24448 = heff_field(v_e0_241, 0);
    V v_arrow_24449 = heff_field(v_e0_241, 1);
    V v_e_24450 = heff_field(v_e0_241, 2);
    V v_c_24451 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24452 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24448));
    V v_a_24453 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24449));
    V v_b_24454 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24450}));
    V v_t_24455 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_b_24454));
    V v_t_24456 = (g_std_2edoc_2e_3c_3e(v_a_24453, v_t_24455));
    V v_t_24457 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24451));
    V v_t_24458 = (g_std_2edoc_2e_3c_3e(v_t_24456, v_t_24457));
    return (g_std_2edoc_2e_3c_3e(v_t_24452, v_t_24458));
  }
  case TAG_IfThen: {
    V v_kw_24459 = heff_field(v_e0_241, 0);
    V v_c_24460 = heff_field(v_e0_241, 1);
    V v_th_24461 = heff_field(v_e0_241, 2);
    V v_a_24462 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24459, v_c_24460, v_th_24461, v_a_24462}));
    return (g_std_2edoc_2egroup(v_t_24463));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_env_24464 = args[0];
  V v_e_24465 = args[1];
  V v_t_24466 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24465));
  if ((heff_dup(v_t_24466) == NTAG(TAG_True))) {
    heff_drop(v_t_24466);
    V v_t_24467 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24464, v_e_24465}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), v_t_24467));
  } else {
    heff_drop(v_t_24466);
    V v_t_24468 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24464, v_e_24465}));
    V v_t_24469 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24468));
    return (g_std_2edoc_2egroup(v_t_24469));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_env_24470 = args[0];
  V v_kw_24471 = args[1];
  V v_p_24472 = args[2];
  V v_ann_24473 = args[3];
  V v_eq_24474 = args[4];
  V v_e_24475 = args[5];
  V v_a_24476 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24470), v_kw_24471));
  V v_b_24477 = ({ V a_0 = heff_dup(v_env_24470); V a_1 = v_p_24472; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24472); r_; });
  V v_t_24478 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24477));
  V v_t_24479 = (g_std_2edoc_2e_3c_3e(v_a_24476, v_t_24478));
  V v_a_24487;
  switch (heff_tag_of(v_ann_24473)) {
  case TAG_Nothing: {
    v_a_24487 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24480 = heff_field(v_ann_24473, 0);
    V v_ru_24ann_24473_24Just = heff_take_reuse_n(v_ann_24473, 1ULL, 1);
    switch (heff_tag_of(v_it1_24480)) {
    case TAG_MkPair: {
      V v_cc_24481 = heff_field(v_it1_24480, 0);
      V v_ty_24482 = heff_field(v_it1_24480, 1);
      heff_take_n(v_it1_24480, 3ULL, 2);
      V v_a_24483 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24470), v_cc_24481));
      V v_b_24484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24470), v_ty_24482}));
      V v_t_24485 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24473_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24484));
      V v_t_24486 = (g_std_2edoc_2e_3c_3e(v_a_24483, v_t_24485));
      v_a_24487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_t_24486));
      break;
    }
    default: heff_nomatch(v_it1_24480);
    }
    break;
  }
  default: heff_nomatch(v_ann_24473);
  }
  V v_b_24488 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24470), v_eq_24474));
  V v_t_24489 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24488));
  V v_t_24490 = (g_std_2edoc_2e_3c_3e(v_a_24487, v_t_24489));
  V v_t_24491 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24470, v_e_24475}));
  V v_t_24492 = (g_std_2edoc_2e_3c_3e(v_t_24490, v_t_24491));
  return (g_std_2edoc_2e_3c_3e(v_t_24479, v_t_24492));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_env_24493 = args[0];
  V v_kw_24494 = args[1];
  V v_p_24495 = args[2];
  V v_ann_24496 = args[3];
  V v_eq_24497 = args[4];
  V v_e_24498 = args[5];
  V v_i_24499 = args[6];
  V v_b_24500 = args[7];
  V v_d_24501 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24493), v_kw_24494, v_p_24495, v_ann_24496, v_eq_24497, v_e_24498}));
  V v_t_24502 = heff_dup(heff_rfield(v_i_24499, 6));
  V v_x1_24504;
  if ((heff_dup(v_t_24502) == NTAG(TAG_True))) {
    heff_drop(v_t_24502);
    v_x1_24504 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_24502);
    V v_t_24503 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24500));
    v_x1_24504 = heff_get_n(v_t_24503, 6, 9);
  }
  V v_t_24505;
  if ((heff_dup(v_x1_24504) == NTAG(TAG_True))) {
    heff_drop(v_x1_24504);
    v_t_24505 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24504);
    v_t_24505 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24506 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24493), v_i_24499));
  V v_b_24640;
  switch (heff_tag_of(v_b_24500)) {
  case TAG_Atom: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EParen: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Named: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Tup: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Seg: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Braces: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Update: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EUSet: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_InstB: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EFSet: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Sum: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_ECon: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EField: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_ENeg: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_App: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Op: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Ops: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Ann: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_BVar: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_BImp: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_BAnn: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Lam: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Case: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EAlt: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_If: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_Do: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_ESBind: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24601 = heff_dup(heff_field(v_b_24500, 0));
    V v_p2_24602 = heff_dup(heff_field(v_b_24500, 1));
    V v_ann2_24603 = heff_dup(heff_field(v_b_24500, 2));
    V v_eq2_24604 = heff_dup(heff_field(v_b_24500, 3));
    V v_e2_24605 = heff_dup(heff_field(v_b_24500, 4));
    V v_it6_24606 = heff_dup(heff_field(v_b_24500, 5));
    switch (heff_tag_of(v_it6_24606)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24601);
      heff_drop(v_p2_24602);
      heff_drop(v_ann2_24603);
      heff_drop(v_eq2_24604);
      heff_drop(v_e2_24605);
      v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
      break;
    }
    case TAG_Just: {
      V v_it61_24607 = heff_field(v_it6_24606, 0);
      heff_take_n(v_it6_24606, 1ULL, 1);
      heff_drop_tag(v_b_24500, 6);
      switch (heff_tag_of(v_it61_24607)) {
      case TAG_MkPair: {
        V v_i2_24608 = heff_field(v_it61_24607, 0);
        V v_b2_24609 = heff_field(v_it61_24607, 1);
        heff_take_n(v_it61_24607, 3ULL, 2);
        v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24493, v_kw2_24601, v_p2_24602, v_ann2_24603, v_eq2_24604, v_e2_24605, v_i2_24608, v_b2_24609}));
        break;
      }
      default: heff_nomatch(v_it61_24607);
      }
      break;
    }
    default: heff_nomatch(v_it6_24606);
    }
    break;
  }
  case TAG_ELetMut: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EAssign: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EWhile: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EFor: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EJump: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_EReturn: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_ENest: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  case TAG_IfThen: {
    v_b_24640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24493, v_b_24500}));
    break;
  }
  default: heff_nomatch(v_b_24500);
  }
  V v_t_24641 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_b_24640));
  V v_t_24642 = (g_std_2edoc_2e_3c_3e(v_a_24506, v_t_24641));
  V v_t_24643 = (g_std_2edoc_2e_3c_3e(v_t_24505, v_t_24642));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24501}), v_t_24643));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_i_24652 = args[0];
  V v_k_24651 = heff_env(self)[0];
  V v_d_24650 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24653 = heff_intSub(v_k_24651, v_i_24652);
  if (heff_intEq_c_lent(v_i_24653, MK_INT(0LL), 2)) {
    heff_drop(v_i_24653);
    return v_d_24650;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24653, v_d_24650});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_k_24651 = args[0];
  V v_d_24650 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 2, (V[]){v_k_24651, v_d_24650})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_env_24644 = args[0];
  V v_kw_24645 = args[1];
  V v_c_24646 = args[2];
  V v_th_24647 = args[3];
  V v_a_24648 = args[4];
  V v_a_24649 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24644), v_kw_24645));
  V v_d_24650 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24644), v_c_24646}));
  V v_t_24655 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){v_d_24650})})));
  V v_t_24656 = (g_std_2edoc_2e_3c_3e(v_a_24649, v_t_24655));
  V v_t_24657 = heff_dup(heff_rfield(v_th_24647, 6));
  V v_x1_24659;
  if ((heff_dup(v_t_24657) == NTAG(TAG_True))) {
    heff_drop(v_t_24657);
    v_x1_24659 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_24657);
    V v_t_24658 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24648));
    v_x1_24659 = heff_get_n(v_t_24658, 6, 9);
  }
  V v_t_24660;
  if ((heff_dup(v_x1_24659) == NTAG(TAG_True))) {
    heff_drop(v_x1_24659);
    v_t_24660 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24659);
    v_t_24660 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24661 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24644), v_th_24647));
  V v_d_24662 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24644, v_a_24648}));
  V v_t_24663 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24662})));
  V v_t_24664 = (g_std_2edoc_2e_3c_3e(v_a_24661, v_t_24663));
  V v_t_24665 = (g_std_2edoc_2e_3c_3e(v_t_24660, v_t_24664));
  V v_t_24666 = (g_std_2edoc_2e_3c_3e(v_t_24656, v_t_24665));
  return (g_std_2edoc_2egroup(v_t_24666));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_env_24667 = args[0];
  V v_el_24668 = args[1];
  V v_b_24669 = args[2];
  switch (heff_tag_of(v_b_24669)) {
  case TAG_Atom: {
    V v_t_24671 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24673;
    if ((heff_dup(v_t_24671) == NTAG(TAG_True))) {
      heff_drop(v_t_24671);
      v_x1_24673 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24671);
      V v_t_24672 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24673 = heff_get_n(v_t_24672, 6, 9);
    }
    V v_t_24674;
    if ((heff_dup(v_x1_24673) == NTAG(TAG_True))) {
      heff_drop(v_x1_24673);
      v_t_24674 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24673);
      v_t_24674 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24675 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24676 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24677 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24676})));
    V v_t_24678 = (g_std_2edoc_2e_3c_3e(v_a_24675, v_t_24677));
    return (g_std_2edoc_2e_3c_3e(v_t_24674, v_t_24678));
  }
  case TAG_EParen: {
    V v_t_24682 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24684;
    if ((heff_dup(v_t_24682) == NTAG(TAG_True))) {
      heff_drop(v_t_24682);
      v_x1_24684 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24682);
      V v_t_24683 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24684 = heff_get_n(v_t_24683, 6, 9);
    }
    V v_t_24685;
    if ((heff_dup(v_x1_24684) == NTAG(TAG_True))) {
      heff_drop(v_x1_24684);
      v_t_24685 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24684);
      v_t_24685 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24686 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24687 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24688 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24687})));
    V v_t_24689 = (g_std_2edoc_2e_3c_3e(v_a_24686, v_t_24688));
    return (g_std_2edoc_2e_3c_3e(v_t_24685, v_t_24689));
  }
  case TAG_Named: {
    V v_t_24695 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24697;
    if ((heff_dup(v_t_24695) == NTAG(TAG_True))) {
      heff_drop(v_t_24695);
      v_x1_24697 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24695);
      V v_t_24696 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24697 = heff_get_n(v_t_24696, 6, 9);
    }
    V v_t_24698;
    if ((heff_dup(v_x1_24697) == NTAG(TAG_True))) {
      heff_drop(v_x1_24697);
      v_t_24698 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24697);
      v_t_24698 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24699 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24700 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24701 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24700})));
    V v_t_24702 = (g_std_2edoc_2e_3c_3e(v_a_24699, v_t_24701));
    return (g_std_2edoc_2e_3c_3e(v_t_24698, v_t_24702));
  }
  case TAG_Tup: {
    V v_t_24707 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24709;
    if ((heff_dup(v_t_24707) == NTAG(TAG_True))) {
      heff_drop(v_t_24707);
      v_x1_24709 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24707);
      V v_t_24708 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24709 = heff_get_n(v_t_24708, 6, 9);
    }
    V v_t_24710;
    if ((heff_dup(v_x1_24709) == NTAG(TAG_True))) {
      heff_drop(v_x1_24709);
      v_t_24710 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24709);
      v_t_24710 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24711 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24712 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24713 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24712})));
    V v_t_24714 = (g_std_2edoc_2e_3c_3e(v_a_24711, v_t_24713));
    return (g_std_2edoc_2e_3c_3e(v_t_24710, v_t_24714));
  }
  case TAG_Seg: {
    V v_t_24718 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24720;
    if ((heff_dup(v_t_24718) == NTAG(TAG_True))) {
      heff_drop(v_t_24718);
      v_x1_24720 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24718);
      V v_t_24719 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24720 = heff_get_n(v_t_24719, 6, 9);
    }
    V v_t_24721;
    if ((heff_dup(v_x1_24720) == NTAG(TAG_True))) {
      heff_drop(v_x1_24720);
      v_t_24721 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24720);
      v_t_24721 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24722 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24723 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24724 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24723})));
    V v_t_24725 = (g_std_2edoc_2e_3c_3e(v_a_24722, v_t_24724));
    return (g_std_2edoc_2e_3c_3e(v_t_24721, v_t_24725));
  }
  case TAG_Braces: {
    V v_t_24730 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24732;
    if ((heff_dup(v_t_24730) == NTAG(TAG_True))) {
      heff_drop(v_t_24730);
      v_x1_24732 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24730);
      V v_t_24731 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24732 = heff_get_n(v_t_24731, 6, 9);
    }
    V v_t_24733;
    if ((heff_dup(v_x1_24732) == NTAG(TAG_True))) {
      heff_drop(v_x1_24732);
      v_t_24733 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24732);
      v_t_24733 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24734 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24735 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24736 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24735})));
    V v_t_24737 = (g_std_2edoc_2e_3c_3e(v_a_24734, v_t_24736));
    return (g_std_2edoc_2e_3c_3e(v_t_24733, v_t_24737));
  }
  case TAG_Update: {
    V v_t_24744 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24746;
    if ((heff_dup(v_t_24744) == NTAG(TAG_True))) {
      heff_drop(v_t_24744);
      v_x1_24746 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24744);
      V v_t_24745 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24746 = heff_get_n(v_t_24745, 6, 9);
    }
    V v_t_24747;
    if ((heff_dup(v_x1_24746) == NTAG(TAG_True))) {
      heff_drop(v_x1_24746);
      v_t_24747 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24746);
      v_t_24747 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24748 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24750 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24749})));
    V v_t_24751 = (g_std_2edoc_2e_3c_3e(v_a_24748, v_t_24750));
    return (g_std_2edoc_2e_3c_3e(v_t_24747, v_t_24751));
  }
  case TAG_EUSet: {
    V v_t_24755 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24757;
    if ((heff_dup(v_t_24755) == NTAG(TAG_True))) {
      heff_drop(v_t_24755);
      v_x1_24757 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24755);
      V v_t_24756 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24757 = heff_get_n(v_t_24756, 6, 9);
    }
    V v_t_24758;
    if ((heff_dup(v_x1_24757) == NTAG(TAG_True))) {
      heff_drop(v_x1_24757);
      v_t_24758 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24757);
      v_t_24758 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24759 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24760 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24761 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24760})));
    V v_t_24762 = (g_std_2edoc_2e_3c_3e(v_a_24759, v_t_24761));
    return (g_std_2edoc_2e_3c_3e(v_t_24758, v_t_24762));
  }
  case TAG_InstB: {
    V v_t_24768 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24770;
    if ((heff_dup(v_t_24768) == NTAG(TAG_True))) {
      heff_drop(v_t_24768);
      v_x1_24770 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24768);
      V v_t_24769 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24770 = heff_get_n(v_t_24769, 6, 9);
    }
    V v_t_24771;
    if ((heff_dup(v_x1_24770) == NTAG(TAG_True))) {
      heff_drop(v_x1_24770);
      v_t_24771 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24770);
      v_t_24771 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24772 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24773 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24774 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24773})));
    V v_t_24775 = (g_std_2edoc_2e_3c_3e(v_a_24772, v_t_24774));
    return (g_std_2edoc_2e_3c_3e(v_t_24771, v_t_24775));
  }
  case TAG_EFSet: {
    V v_t_24779 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24781;
    if ((heff_dup(v_t_24779) == NTAG(TAG_True))) {
      heff_drop(v_t_24779);
      v_x1_24781 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24779);
      V v_t_24780 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24781 = heff_get_n(v_t_24780, 6, 9);
    }
    V v_t_24782;
    if ((heff_dup(v_x1_24781) == NTAG(TAG_True))) {
      heff_drop(v_x1_24781);
      v_t_24782 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24781);
      v_t_24782 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24783 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24784 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24785 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24784})));
    V v_t_24786 = (g_std_2edoc_2e_3c_3e(v_a_24783, v_t_24785));
    return (g_std_2edoc_2e_3c_3e(v_t_24782, v_t_24786));
  }
  case TAG_EFDefault: {
    V v_t_24790 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24792;
    if ((heff_dup(v_t_24790) == NTAG(TAG_True))) {
      heff_drop(v_t_24790);
      v_x1_24792 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24790);
      V v_t_24791 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24792 = heff_get_n(v_t_24791, 6, 9);
    }
    V v_t_24793;
    if ((heff_dup(v_x1_24792) == NTAG(TAG_True))) {
      heff_drop(v_x1_24792);
      v_t_24793 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24792);
      v_t_24793 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24794 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24795 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24796 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24795})));
    V v_t_24797 = (g_std_2edoc_2e_3c_3e(v_a_24794, v_t_24796));
    return (g_std_2edoc_2e_3c_3e(v_t_24793, v_t_24797));
  }
  case TAG_Sum: {
    V v_t_24803 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24805;
    if ((heff_dup(v_t_24803) == NTAG(TAG_True))) {
      heff_drop(v_t_24803);
      v_x1_24805 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24803);
      V v_t_24804 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24805 = heff_get_n(v_t_24804, 6, 9);
    }
    V v_t_24806;
    if ((heff_dup(v_x1_24805) == NTAG(TAG_True))) {
      heff_drop(v_x1_24805);
      v_t_24806 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24805);
      v_t_24806 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24807 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24808 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24809 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24808})));
    V v_t_24810 = (g_std_2edoc_2e_3c_3e(v_a_24807, v_t_24809));
    return (g_std_2edoc_2e_3c_3e(v_t_24806, v_t_24810));
  }
  case TAG_ECon: {
    V v_t_24813 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24815;
    if ((heff_dup(v_t_24813) == NTAG(TAG_True))) {
      heff_drop(v_t_24813);
      v_x1_24815 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24813);
      V v_t_24814 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24815 = heff_get_n(v_t_24814, 6, 9);
    }
    V v_t_24816;
    if ((heff_dup(v_x1_24815) == NTAG(TAG_True))) {
      heff_drop(v_x1_24815);
      v_t_24816 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24815);
      v_t_24816 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24817 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24818 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24819 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24818})));
    V v_t_24820 = (g_std_2edoc_2e_3c_3e(v_a_24817, v_t_24819));
    return (g_std_2edoc_2e_3c_3e(v_t_24816, v_t_24820));
  }
  case TAG_EField: {
    V v_t_24823 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24825;
    if ((heff_dup(v_t_24823) == NTAG(TAG_True))) {
      heff_drop(v_t_24823);
      v_x1_24825 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24823);
      V v_t_24824 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24825 = heff_get_n(v_t_24824, 6, 9);
    }
    V v_t_24826;
    if ((heff_dup(v_x1_24825) == NTAG(TAG_True))) {
      heff_drop(v_x1_24825);
      v_t_24826 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24825);
      v_t_24826 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24827 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24828 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24829 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24828})));
    V v_t_24830 = (g_std_2edoc_2e_3c_3e(v_a_24827, v_t_24829));
    return (g_std_2edoc_2e_3c_3e(v_t_24826, v_t_24830));
  }
  case TAG_ENeg: {
    V v_t_24833 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24835;
    if ((heff_dup(v_t_24833) == NTAG(TAG_True))) {
      heff_drop(v_t_24833);
      v_x1_24835 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24833);
      V v_t_24834 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24835 = heff_get_n(v_t_24834, 6, 9);
    }
    V v_t_24836;
    if ((heff_dup(v_x1_24835) == NTAG(TAG_True))) {
      heff_drop(v_x1_24835);
      v_t_24836 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24835);
      v_t_24836 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24837 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24838 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24839 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24838})));
    V v_t_24840 = (g_std_2edoc_2e_3c_3e(v_a_24837, v_t_24839));
    return (g_std_2edoc_2e_3c_3e(v_t_24836, v_t_24840));
  }
  case TAG_App: {
    V v_t_24843 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24845;
    if ((heff_dup(v_t_24843) == NTAG(TAG_True))) {
      heff_drop(v_t_24843);
      v_x1_24845 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24843);
      V v_t_24844 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24845 = heff_get_n(v_t_24844, 6, 9);
    }
    V v_t_24846;
    if ((heff_dup(v_x1_24845) == NTAG(TAG_True))) {
      heff_drop(v_x1_24845);
      v_t_24846 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24845);
      v_t_24846 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24847 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24848 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24849 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24848})));
    V v_t_24850 = (g_std_2edoc_2e_3c_3e(v_a_24847, v_t_24849));
    return (g_std_2edoc_2e_3c_3e(v_t_24846, v_t_24850));
  }
  case TAG_Op: {
    V v_t_24854 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24856;
    if ((heff_dup(v_t_24854) == NTAG(TAG_True))) {
      heff_drop(v_t_24854);
      v_x1_24856 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24854);
      V v_t_24855 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24856 = heff_get_n(v_t_24855, 6, 9);
    }
    V v_t_24857;
    if ((heff_dup(v_x1_24856) == NTAG(TAG_True))) {
      heff_drop(v_x1_24856);
      v_t_24857 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24856);
      v_t_24857 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24858 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24859 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24860 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24859})));
    V v_t_24861 = (g_std_2edoc_2e_3c_3e(v_a_24858, v_t_24860));
    return (g_std_2edoc_2e_3c_3e(v_t_24857, v_t_24861));
  }
  case TAG_Ops: {
    V v_t_24864 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24866;
    if ((heff_dup(v_t_24864) == NTAG(TAG_True))) {
      heff_drop(v_t_24864);
      v_x1_24866 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24864);
      V v_t_24865 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24866 = heff_get_n(v_t_24865, 6, 9);
    }
    V v_t_24867;
    if ((heff_dup(v_x1_24866) == NTAG(TAG_True))) {
      heff_drop(v_x1_24866);
      v_t_24867 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24866);
      v_t_24867 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24868 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24870 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24869})));
    V v_t_24871 = (g_std_2edoc_2e_3c_3e(v_a_24868, v_t_24870));
    return (g_std_2edoc_2e_3c_3e(v_t_24867, v_t_24871));
  }
  case TAG_OpRhs: {
    V v_t_24874 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24876;
    if ((heff_dup(v_t_24874) == NTAG(TAG_True))) {
      heff_drop(v_t_24874);
      v_x1_24876 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24874);
      V v_t_24875 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24876 = heff_get_n(v_t_24875, 6, 9);
    }
    V v_t_24877;
    if ((heff_dup(v_x1_24876) == NTAG(TAG_True))) {
      heff_drop(v_x1_24876);
      v_t_24877 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24876);
      v_t_24877 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24878 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24879 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24880 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24879})));
    V v_t_24881 = (g_std_2edoc_2e_3c_3e(v_a_24878, v_t_24880));
    return (g_std_2edoc_2e_3c_3e(v_t_24877, v_t_24881));
  }
  case TAG_Ann: {
    V v_t_24885 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24887;
    if ((heff_dup(v_t_24885) == NTAG(TAG_True))) {
      heff_drop(v_t_24885);
      v_x1_24887 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24885);
      V v_t_24886 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24887 = heff_get_n(v_t_24886, 6, 9);
    }
    V v_t_24888;
    if ((heff_dup(v_x1_24887) == NTAG(TAG_True))) {
      heff_drop(v_x1_24887);
      v_t_24888 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24887);
      v_t_24888 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24889 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24890 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24891 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24890})));
    V v_t_24892 = (g_std_2edoc_2e_3c_3e(v_a_24889, v_t_24891));
    return (g_std_2edoc_2e_3c_3e(v_t_24888, v_t_24892));
  }
  case TAG_BVar: {
    V v_t_24894 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24896;
    if ((heff_dup(v_t_24894) == NTAG(TAG_True))) {
      heff_drop(v_t_24894);
      v_x1_24896 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24894);
      V v_t_24895 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24896 = heff_get_n(v_t_24895, 6, 9);
    }
    V v_t_24897;
    if ((heff_dup(v_x1_24896) == NTAG(TAG_True))) {
      heff_drop(v_x1_24896);
      v_t_24897 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24896);
      v_t_24897 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24898 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24899 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24900 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24899})));
    V v_t_24901 = (g_std_2edoc_2e_3c_3e(v_a_24898, v_t_24900));
    return (g_std_2edoc_2e_3c_3e(v_t_24897, v_t_24901));
  }
  case TAG_BImp: {
    V v_t_24905 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24907;
    if ((heff_dup(v_t_24905) == NTAG(TAG_True))) {
      heff_drop(v_t_24905);
      v_x1_24907 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24905);
      V v_t_24906 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24907 = heff_get_n(v_t_24906, 6, 9);
    }
    V v_t_24908;
    if ((heff_dup(v_x1_24907) == NTAG(TAG_True))) {
      heff_drop(v_x1_24907);
      v_t_24908 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24907);
      v_t_24908 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24909 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24910 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24911 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24910})));
    V v_t_24912 = (g_std_2edoc_2e_3c_3e(v_a_24909, v_t_24911));
    return (g_std_2edoc_2e_3c_3e(v_t_24908, v_t_24912));
  }
  case TAG_BAnn: {
    V v_t_24918 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24920;
    if ((heff_dup(v_t_24918) == NTAG(TAG_True))) {
      heff_drop(v_t_24918);
      v_x1_24920 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24918);
      V v_t_24919 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24920 = heff_get_n(v_t_24919, 6, 9);
    }
    V v_t_24921;
    if ((heff_dup(v_x1_24920) == NTAG(TAG_True))) {
      heff_drop(v_x1_24920);
      v_t_24921 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24920);
      v_t_24921 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24922 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24923 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24924 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24923})));
    V v_t_24925 = (g_std_2edoc_2e_3c_3e(v_a_24922, v_t_24924));
    return (g_std_2edoc_2e_3c_3e(v_t_24921, v_t_24925));
  }
  case TAG_Lam: {
    V v_t_24930 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24932;
    if ((heff_dup(v_t_24930) == NTAG(TAG_True))) {
      heff_drop(v_t_24930);
      v_x1_24932 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24930);
      V v_t_24931 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24932 = heff_get_n(v_t_24931, 6, 9);
    }
    V v_t_24933;
    if ((heff_dup(v_x1_24932) == NTAG(TAG_True))) {
      heff_drop(v_x1_24932);
      v_t_24933 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24932);
      v_t_24933 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24934 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24935 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24936 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24935})));
    V v_t_24937 = (g_std_2edoc_2e_3c_3e(v_a_24934, v_t_24936));
    return (g_std_2edoc_2e_3c_3e(v_t_24933, v_t_24937));
  }
  case TAG_Case: {
    V v_t_24942 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24944;
    if ((heff_dup(v_t_24942) == NTAG(TAG_True))) {
      heff_drop(v_t_24942);
      v_x1_24944 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24942);
      V v_t_24943 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24944 = heff_get_n(v_t_24943, 6, 9);
    }
    V v_t_24945;
    if ((heff_dup(v_x1_24944) == NTAG(TAG_True))) {
      heff_drop(v_x1_24944);
      v_t_24945 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24944);
      v_t_24945 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24946 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24948 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24947})));
    V v_t_24949 = (g_std_2edoc_2e_3c_3e(v_a_24946, v_t_24948));
    return (g_std_2edoc_2e_3c_3e(v_t_24945, v_t_24949));
  }
  case TAG_EAlt: {
    V v_t_24953 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24955;
    if ((heff_dup(v_t_24953) == NTAG(TAG_True))) {
      heff_drop(v_t_24953);
      v_x1_24955 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24953);
      V v_t_24954 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24955 = heff_get_n(v_t_24954, 6, 9);
    }
    V v_t_24956;
    if ((heff_dup(v_x1_24955) == NTAG(TAG_True))) {
      heff_drop(v_x1_24955);
      v_t_24956 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24955);
      v_t_24956 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24957 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24958 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24959 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24958})));
    V v_t_24960 = (g_std_2edoc_2e_3c_3e(v_a_24957, v_t_24959));
    return (g_std_2edoc_2e_3c_3e(v_t_24956, v_t_24960));
  }
  case TAG_If: {
    V v_kw_24961 = heff_dup(heff_field(v_b_24669, 0));
    V v_c_24962 = heff_dup(heff_field(v_b_24669, 1));
    V v_th_24963 = heff_dup(heff_field(v_b_24669, 2));
    V v_a_24964 = heff_dup(heff_field(v_b_24669, 3));
    V v_el2_24965 = heff_dup(heff_field(v_b_24669, 4));
    V v_b2_24966 = heff_dup(heff_field(v_b_24669, 5));
    V v_t_24967 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24969;
    if ((heff_dup(v_t_24967) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24669, 6);
      heff_drop(v_t_24967);
      v_x1_24969 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24967);
      V v_t_24968 = ({ V a_0 = v_b_24669; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24669, 6); r_; });
      v_x1_24969 = heff_get_n(v_t_24968, 6, 9);
    }
    V v_t_24970;
    if ((heff_dup(v_x1_24969) == NTAG(TAG_True))) {
      heff_drop(v_x1_24969);
      v_t_24970 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24969);
      v_t_24970 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24971 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_b_24972 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24667), v_kw_24961, v_c_24962, v_th_24963, v_a_24964}));
    V v_t_24973 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_24972));
    V v_t_24974 = (g_std_2edoc_2e_3c_3e(v_a_24971, v_t_24973));
    V v_t_24975 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24667, v_el2_24965, v_b2_24966}));
    V v_t_24976 = (g_std_2edoc_2e_3c_3e(v_t_24974, v_t_24975));
    return (g_std_2edoc_2e_3c_3e(v_t_24970, v_t_24976));
  }
  case TAG_Do: {
    V v_t_24979 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24981;
    if ((heff_dup(v_t_24979) == NTAG(TAG_True))) {
      heff_drop(v_t_24979);
      v_x1_24981 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24979);
      V v_t_24980 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24981 = heff_get_n(v_t_24980, 6, 9);
    }
    V v_t_24982;
    if ((heff_dup(v_x1_24981) == NTAG(TAG_True))) {
      heff_drop(v_x1_24981);
      v_t_24982 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24981);
      v_t_24982 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24983 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24984 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24985 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24984})));
    V v_t_24986 = (g_std_2edoc_2e_3c_3e(v_a_24983, v_t_24985));
    return (g_std_2edoc_2e_3c_3e(v_t_24982, v_t_24986));
  }
  case TAG_ESBind: {
    V v_t_24990 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_24992;
    if ((heff_dup(v_t_24990) == NTAG(TAG_True))) {
      heff_drop(v_t_24990);
      v_x1_24992 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24990);
      V v_t_24991 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_24992 = heff_get_n(v_t_24991, 6, 9);
    }
    V v_t_24993;
    if ((heff_dup(v_x1_24992) == NTAG(TAG_True))) {
      heff_drop(v_x1_24992);
      v_t_24993 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24992);
      v_t_24993 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24994 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_24995 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_24996 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24995})));
    V v_t_24997 = (g_std_2edoc_2e_3c_3e(v_a_24994, v_t_24996));
    return (g_std_2edoc_2e_3c_3e(v_t_24993, v_t_24997));
  }
  case TAG_ELet: {
    V v_t_241004 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241006;
    if ((heff_dup(v_t_241004) == NTAG(TAG_True))) {
      heff_drop(v_t_241004);
      v_x1_241006 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241004);
      V v_t_241005 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241006 = heff_get_n(v_t_241005, 6, 9);
    }
    V v_t_241007;
    if ((heff_dup(v_x1_241006) == NTAG(TAG_True))) {
      heff_drop(v_x1_241006);
      v_t_241007 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241006);
      v_t_241007 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241008 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241009 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241010 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241009})));
    V v_t_241011 = (g_std_2edoc_2e_3c_3e(v_a_241008, v_t_241010));
    return (g_std_2edoc_2e_3c_3e(v_t_241007, v_t_241011));
  }
  case TAG_ELetMut: {
    V v_t_241018 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241020;
    if ((heff_dup(v_t_241018) == NTAG(TAG_True))) {
      heff_drop(v_t_241018);
      v_x1_241020 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241018);
      V v_t_241019 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241020 = heff_get_n(v_t_241019, 6, 9);
    }
    V v_t_241021;
    if ((heff_dup(v_x1_241020) == NTAG(TAG_True))) {
      heff_drop(v_x1_241020);
      v_t_241021 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241020);
      v_t_241021 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241022 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241023 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241024 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241023})));
    V v_t_241025 = (g_std_2edoc_2e_3c_3e(v_a_241022, v_t_241024));
    return (g_std_2edoc_2e_3c_3e(v_t_241021, v_t_241025));
  }
  case TAG_EAssign: {
    V v_t_241029 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241031;
    if ((heff_dup(v_t_241029) == NTAG(TAG_True))) {
      heff_drop(v_t_241029);
      v_x1_241031 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241029);
      V v_t_241030 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241031 = heff_get_n(v_t_241030, 6, 9);
    }
    V v_t_241032;
    if ((heff_dup(v_x1_241031) == NTAG(TAG_True))) {
      heff_drop(v_x1_241031);
      v_t_241032 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241031);
      v_t_241032 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241033 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241034 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241035 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241034})));
    V v_t_241036 = (g_std_2edoc_2e_3c_3e(v_a_241033, v_t_241035));
    return (g_std_2edoc_2e_3c_3e(v_t_241032, v_t_241036));
  }
  case TAG_EWhile: {
    V v_t_241041 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241043;
    if ((heff_dup(v_t_241041) == NTAG(TAG_True))) {
      heff_drop(v_t_241041);
      v_x1_241043 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241041);
      V v_t_241042 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241043 = heff_get_n(v_t_241042, 6, 9);
    }
    V v_t_241044;
    if ((heff_dup(v_x1_241043) == NTAG(TAG_True))) {
      heff_drop(v_x1_241043);
      v_t_241044 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241043);
      v_t_241044 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241045 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241046 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241047 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241046})));
    V v_t_241048 = (g_std_2edoc_2e_3c_3e(v_a_241045, v_t_241047));
    return (g_std_2edoc_2e_3c_3e(v_t_241044, v_t_241048));
  }
  case TAG_EFor: {
    V v_t_241055 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241057;
    if ((heff_dup(v_t_241055) == NTAG(TAG_True))) {
      heff_drop(v_t_241055);
      v_x1_241057 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241055);
      V v_t_241056 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241057 = heff_get_n(v_t_241056, 6, 9);
    }
    V v_t_241058;
    if ((heff_dup(v_x1_241057) == NTAG(TAG_True))) {
      heff_drop(v_x1_241057);
      v_t_241058 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241057);
      v_t_241058 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241059 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241060 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241061 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241060})));
    V v_t_241062 = (g_std_2edoc_2e_3c_3e(v_a_241059, v_t_241061));
    return (g_std_2edoc_2e_3c_3e(v_t_241058, v_t_241062));
  }
  case TAG_EJump: {
    V v_t_241064 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241066;
    if ((heff_dup(v_t_241064) == NTAG(TAG_True))) {
      heff_drop(v_t_241064);
      v_x1_241066 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241064);
      V v_t_241065 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241066 = heff_get_n(v_t_241065, 6, 9);
    }
    V v_t_241067;
    if ((heff_dup(v_x1_241066) == NTAG(TAG_True))) {
      heff_drop(v_x1_241066);
      v_t_241067 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241066);
      v_t_241067 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241068 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241069 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241070 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241069})));
    V v_t_241071 = (g_std_2edoc_2e_3c_3e(v_a_241068, v_t_241070));
    return (g_std_2edoc_2e_3c_3e(v_t_241067, v_t_241071));
  }
  case TAG_EReturn: {
    V v_t_241074 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241076;
    if ((heff_dup(v_t_241074) == NTAG(TAG_True))) {
      heff_drop(v_t_241074);
      v_x1_241076 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241074);
      V v_t_241075 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241076 = heff_get_n(v_t_241075, 6, 9);
    }
    V v_t_241077;
    if ((heff_dup(v_x1_241076) == NTAG(TAG_True))) {
      heff_drop(v_x1_241076);
      v_t_241077 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241076);
      v_t_241077 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241078 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241080 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241079})));
    V v_t_241081 = (g_std_2edoc_2e_3c_3e(v_a_241078, v_t_241080));
    return (g_std_2edoc_2e_3c_3e(v_t_241077, v_t_241081));
  }
  case TAG_ENest: {
    V v_t_241086 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241088;
    if ((heff_dup(v_t_241086) == NTAG(TAG_True))) {
      heff_drop(v_t_241086);
      v_x1_241088 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241086);
      V v_t_241087 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241088 = heff_get_n(v_t_241087, 6, 9);
    }
    V v_t_241089;
    if ((heff_dup(v_x1_241088) == NTAG(TAG_True))) {
      heff_drop(v_x1_241088);
      v_t_241089 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241088);
      v_t_241089 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241090 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241091 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241092 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241091})));
    V v_t_241093 = (g_std_2edoc_2e_3c_3e(v_a_241090, v_t_241092));
    return (g_std_2edoc_2e_3c_3e(v_t_241089, v_t_241093));
  }
  case TAG_IfThen: {
    V v_t_241098 = heff_dup(heff_rfield(v_el_24668, 6));
    V v_x1_241100;
    if ((heff_dup(v_t_241098) == NTAG(TAG_True))) {
      heff_drop(v_t_241098);
      v_x1_241100 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_241098);
      V v_t_241099 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24669));
      v_x1_241100 = heff_get_n(v_t_241099, 6, 9);
    }
    V v_t_241101;
    if ((heff_dup(v_x1_241100) == NTAG(TAG_True))) {
      heff_drop(v_x1_241100);
      v_t_241101 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_241100);
      v_t_241101 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_241102 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24667), v_el_24668));
    V v_d_241103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24667, v_b_24669}));
    V v_t_241104 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241103})));
    V v_t_241105 = (g_std_2edoc_2e_3c_3e(v_a_241102, v_t_241104));
    return (g_std_2edoc_2e_3c_3e(v_t_241101, v_t_241105));
  }
  default: return heff_nomatch(v_b_24669);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_241121 = args[0];
  V v_one_241120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241122 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241121));
  V v_x1_241123 = heff_get_n(v_t_241122, 6, 9);
  V v_t_241124;
  if ((heff_dup(v_x1_241123) == NTAG(TAG_True))) {
    heff_drop(v_x1_241123);
    v_t_241124 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241123);
    v_t_241124 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241125 = heff_tr(heff_call(v_one_241120, 1, (V[]){v_a_241121}));
  return (g_std_2edoc_2e_3c_3e(v_t_241124, v_t_241125));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_241133 = args[0];
  V v_one_241132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241134 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241133));
  V v_x1_241135 = heff_get_n(v_t_241134, 6, 9);
  V v_t_241136;
  if ((heff_dup(v_x1_241135) == NTAG(TAG_True))) {
    heff_drop(v_x1_241135);
    v_t_241136 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241135);
    v_t_241136 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241137 = heff_tr(heff_call(v_one_241132, 1, (V[]){v_a_241133}));
  return (g_std_2edoc_2e_3c_3e(v_t_241136, v_t_241137));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_241146 = args[0];
  V v_one_241145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241147 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241146));
  V v_x1_241148 = heff_get_n(v_t_241147, 6, 9);
  V v_t_241149;
  if ((heff_dup(v_x1_241148) == NTAG(TAG_True))) {
    heff_drop(v_x1_241148);
    v_t_241149 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241148);
    v_t_241149 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241150 = heff_tr(heff_call(v_one_241145, 1, (V[]){v_a_241146}));
  return (g_std_2edoc_2e_3c_3e(v_t_241149, v_t_241150));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_241162 = args[0];
  V v_one_241161 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241163 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241162));
  V v_x1_241164 = heff_get_n(v_t_241163, 6, 9);
  V v_t_241165;
  if ((heff_dup(v_x1_241164) == NTAG(TAG_True))) {
    heff_drop(v_x1_241164);
    v_t_241165 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241164);
    v_t_241165 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241166 = heff_tr(heff_call(v_one_241161, 1, (V[]){v_a_241162}));
  return (g_std_2edoc_2e_3c_3e(v_t_241165, v_t_241166));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241177 = args[0];
  V v_one_241176 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241178 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241177));
  V v_x1_241179 = heff_get_n(v_t_241178, 6, 9);
  V v_t_241180;
  if ((heff_dup(v_x1_241179) == NTAG(TAG_True))) {
    heff_drop(v_x1_241179);
    v_t_241180 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241179);
    v_t_241180 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241181 = heff_tr(heff_call(v_one_241176, 1, (V[]){v_a_241177}));
  return (g_std_2edoc_2e_3c_3e(v_t_241180, v_t_241181));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241189 = args[0];
  V v_one_241188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241190 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241189));
  V v_x1_241191 = heff_get_n(v_t_241190, 6, 9);
  V v_t_241192;
  if ((heff_dup(v_x1_241191) == NTAG(TAG_True))) {
    heff_drop(v_x1_241191);
    v_t_241192 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241191);
    v_t_241192 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241193 = heff_tr(heff_call(v_one_241188, 1, (V[]){v_a_241189}));
  return (g_std_2edoc_2e_3c_3e(v_t_241192, v_t_241193));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241203 = args[0];
  V v_one_241202 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241204 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241203));
  V v_x1_241205 = heff_get_n(v_t_241204, 6, 9);
  V v_t_241206;
  if ((heff_dup(v_x1_241205) == NTAG(TAG_True))) {
    heff_drop(v_x1_241205);
    v_t_241206 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241205);
    v_t_241206 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241207 = heff_tr(heff_call(v_one_241202, 1, (V[]){v_a_241203}));
  return (g_std_2edoc_2e_3c_3e(v_t_241206, v_t_241207));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241215 = args[0];
  V v_one_241214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241216 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241215));
  V v_x1_241217 = heff_get_n(v_t_241216, 6, 9);
  V v_t_241218;
  if ((heff_dup(v_x1_241217) == NTAG(TAG_True))) {
    heff_drop(v_x1_241217);
    v_t_241218 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241217);
    v_t_241218 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241219 = heff_tr(heff_call(v_one_241214, 1, (V[]){v_a_241215}));
  return (g_std_2edoc_2e_3c_3e(v_t_241218, v_t_241219));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241228 = args[0];
  V v_one_241227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241229 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241228));
  V v_x1_241230 = heff_get_n(v_t_241229, 6, 9);
  V v_t_241231;
  if ((heff_dup(v_x1_241230) == NTAG(TAG_True))) {
    heff_drop(v_x1_241230);
    v_t_241231 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241230);
    v_t_241231 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241232 = heff_tr(heff_call(v_one_241227, 1, (V[]){v_a_241228}));
  return (g_std_2edoc_2e_3c_3e(v_t_241231, v_t_241232));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241240 = args[0];
  V v_one_241239 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241241 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241240));
  V v_x1_241242 = heff_get_n(v_t_241241, 6, 9);
  V v_t_241243;
  if ((heff_dup(v_x1_241242) == NTAG(TAG_True))) {
    heff_drop(v_x1_241242);
    v_t_241243 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241242);
    v_t_241243 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241244 = heff_tr(heff_call(v_one_241239, 1, (V[]){v_a_241240}));
  return (g_std_2edoc_2e_3c_3e(v_t_241243, v_t_241244));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241254 = args[0];
  V v_one_241253 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241255 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241254));
  V v_x1_241256 = heff_get_n(v_t_241255, 6, 9);
  V v_t_241257;
  if ((heff_dup(v_x1_241256) == NTAG(TAG_True))) {
    heff_drop(v_x1_241256);
    v_t_241257 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241256);
    v_t_241257 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241258 = heff_tr(heff_call(v_one_241253, 1, (V[]){v_a_241254}));
  return (g_std_2edoc_2e_3c_3e(v_t_241257, v_t_241258));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241266 = args[0];
  V v_one_241265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241267 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241266));
  V v_x1_241268 = heff_get_n(v_t_241267, 6, 9);
  V v_t_241269;
  if ((heff_dup(v_x1_241268) == NTAG(TAG_True))) {
    heff_drop(v_x1_241268);
    v_t_241269 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241268);
    v_t_241269 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241270 = heff_tr(heff_call(v_one_241265, 1, (V[]){v_a_241266}));
  return (g_std_2edoc_2e_3c_3e(v_t_241269, v_t_241270));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241282 = args[0];
  V v_one_241281 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241283 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241282));
  V v_x1_241284 = heff_get_n(v_t_241283, 6, 9);
  V v_t_241285;
  if ((heff_dup(v_x1_241284) == NTAG(TAG_True))) {
    heff_drop(v_x1_241284);
    v_t_241285 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241284);
    v_t_241285 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241286 = heff_tr(heff_call(v_one_241281, 1, (V[]){v_a_241282}));
  return (g_std_2edoc_2e_3c_3e(v_t_241285, v_t_241286));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241294 = args[0];
  V v_one_241293 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241295 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241294));
  V v_x1_241296 = heff_get_n(v_t_241295, 6, 9);
  V v_t_241297;
  if ((heff_dup(v_x1_241296) == NTAG(TAG_True))) {
    heff_drop(v_x1_241296);
    v_t_241297 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241296);
    v_t_241297 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241298 = heff_tr(heff_call(v_one_241293, 1, (V[]){v_a_241294}));
  return (g_std_2edoc_2e_3c_3e(v_t_241297, v_t_241298));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241307 = args[0];
  V v_one_241306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241308 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241307));
  V v_x1_241309 = heff_get_n(v_t_241308, 6, 9);
  V v_t_241310;
  if ((heff_dup(v_x1_241309) == NTAG(TAG_True))) {
    heff_drop(v_x1_241309);
    v_t_241310 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241309);
    v_t_241310 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241311 = heff_tr(heff_call(v_one_241306, 1, (V[]){v_a_241307}));
  return (g_std_2edoc_2e_3c_3e(v_t_241310, v_t_241311));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241319 = args[0];
  V v_one_241318 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241320 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241319));
  V v_x1_241321 = heff_get_n(v_t_241320, 6, 9);
  V v_t_241322;
  if ((heff_dup(v_x1_241321) == NTAG(TAG_True))) {
    heff_drop(v_x1_241321);
    v_t_241322 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241321);
    v_t_241322 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241323 = heff_tr(heff_call(v_one_241318, 1, (V[]){v_a_241319}));
  return (g_std_2edoc_2e_3c_3e(v_t_241322, v_t_241323));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241334 = args[0];
  V v_one_241333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241335 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241334));
  V v_x1_241336 = heff_get_n(v_t_241335, 6, 9);
  V v_t_241337;
  if ((heff_dup(v_x1_241336) == NTAG(TAG_True))) {
    heff_drop(v_x1_241336);
    v_t_241337 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241336);
    v_t_241337 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241338 = heff_tr(heff_call(v_one_241333, 1, (V[]){v_a_241334}));
  return (g_std_2edoc_2e_3c_3e(v_t_241337, v_t_241338));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241346 = args[0];
  V v_one_241345 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241347 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241346));
  V v_x1_241348 = heff_get_n(v_t_241347, 6, 9);
  V v_t_241349;
  if ((heff_dup(v_x1_241348) == NTAG(TAG_True))) {
    heff_drop(v_x1_241348);
    v_t_241349 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241348);
    v_t_241349 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241350 = heff_tr(heff_call(v_one_241345, 1, (V[]){v_a_241346}));
  return (g_std_2edoc_2e_3c_3e(v_t_241349, v_t_241350));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241359 = args[0];
  V v_one_241358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241360 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241359));
  V v_x1_241361 = heff_get_n(v_t_241360, 6, 9);
  V v_t_241362;
  if ((heff_dup(v_x1_241361) == NTAG(TAG_True))) {
    heff_drop(v_x1_241361);
    v_t_241362 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241361);
    v_t_241362 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241363 = heff_tr(heff_call(v_one_241358, 1, (V[]){v_a_241359}));
  return (g_std_2edoc_2e_3c_3e(v_t_241362, v_t_241363));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241371 = args[0];
  V v_one_241370 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241372 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241371));
  V v_x1_241373 = heff_get_n(v_t_241372, 6, 9);
  V v_t_241374;
  if ((heff_dup(v_x1_241373) == NTAG(TAG_True))) {
    heff_drop(v_x1_241373);
    v_t_241374 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241373);
    v_t_241374 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241375 = heff_tr(heff_call(v_one_241370, 1, (V[]){v_a_241371}));
  return (g_std_2edoc_2e_3c_3e(v_t_241374, v_t_241375));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241384 = args[0];
  V v_one_241383 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241385 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241384));
  V v_x1_241386 = heff_get_n(v_t_241385, 6, 9);
  V v_t_241387;
  if ((heff_dup(v_x1_241386) == NTAG(TAG_True))) {
    heff_drop(v_x1_241386);
    v_t_241387 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241386);
    v_t_241387 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241388 = heff_tr(heff_call(v_one_241383, 1, (V[]){v_a_241384}));
  return (g_std_2edoc_2e_3c_3e(v_t_241387, v_t_241388));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241396 = args[0];
  V v_one_241395 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241397 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241396));
  V v_x1_241398 = heff_get_n(v_t_241397, 6, 9);
  V v_t_241399;
  if ((heff_dup(v_x1_241398) == NTAG(TAG_True))) {
    heff_drop(v_x1_241398);
    v_t_241399 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241398);
    v_t_241399 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241400 = heff_tr(heff_call(v_one_241395, 1, (V[]){v_a_241396}));
  return (g_std_2edoc_2e_3c_3e(v_t_241399, v_t_241400));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241411 = args[0];
  V v_one_241410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241412 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241411));
  V v_x1_241413 = heff_get_n(v_t_241412, 6, 9);
  V v_t_241414;
  if ((heff_dup(v_x1_241413) == NTAG(TAG_True))) {
    heff_drop(v_x1_241413);
    v_t_241414 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241413);
    v_t_241414 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241415 = heff_tr(heff_call(v_one_241410, 1, (V[]){v_a_241411}));
  return (g_std_2edoc_2e_3c_3e(v_t_241414, v_t_241415));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241423 = args[0];
  V v_one_241422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241424 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241423));
  V v_x1_241425 = heff_get_n(v_t_241424, 6, 9);
  V v_t_241426;
  if ((heff_dup(v_x1_241425) == NTAG(TAG_True))) {
    heff_drop(v_x1_241425);
    v_t_241426 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241425);
    v_t_241426 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241427 = heff_tr(heff_call(v_one_241422, 1, (V[]){v_a_241423}));
  return (g_std_2edoc_2e_3c_3e(v_t_241426, v_t_241427));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241435 = args[0];
  V v_one_241434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241436 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241435));
  V v_x1_241437 = heff_get_n(v_t_241436, 6, 9);
  V v_t_241438;
  if ((heff_dup(v_x1_241437) == NTAG(TAG_True))) {
    heff_drop(v_x1_241437);
    v_t_241438 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241437);
    v_t_241438 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241439 = heff_tr(heff_call(v_one_241434, 1, (V[]){v_a_241435}));
  return (g_std_2edoc_2e_3c_3e(v_t_241438, v_t_241439));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241447 = args[0];
  V v_one_241446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241448 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241447));
  V v_x1_241449 = heff_get_n(v_t_241448, 6, 9);
  V v_t_241450;
  if ((heff_dup(v_x1_241449) == NTAG(TAG_True))) {
    heff_drop(v_x1_241449);
    v_t_241450 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241449);
    v_t_241450 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241451 = heff_tr(heff_call(v_one_241446, 1, (V[]){v_a_241447}));
  return (g_std_2edoc_2e_3c_3e(v_t_241450, v_t_241451));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241459 = args[0];
  V v_one_241458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241460 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241459));
  V v_x1_241461 = heff_get_n(v_t_241460, 6, 9);
  V v_t_241462;
  if ((heff_dup(v_x1_241461) == NTAG(TAG_True))) {
    heff_drop(v_x1_241461);
    v_t_241462 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241461);
    v_t_241462 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241463 = heff_tr(heff_call(v_one_241458, 1, (V[]){v_a_241459}));
  return (g_std_2edoc_2e_3c_3e(v_t_241462, v_t_241463));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241471 = args[0];
  V v_one_241470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241472 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241471));
  V v_x1_241473 = heff_get_n(v_t_241472, 6, 9);
  V v_t_241474;
  if ((heff_dup(v_x1_241473) == NTAG(TAG_True))) {
    heff_drop(v_x1_241473);
    v_t_241474 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241473);
    v_t_241474 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241475 = heff_tr(heff_call(v_one_241470, 1, (V[]){v_a_241471}));
  return (g_std_2edoc_2e_3c_3e(v_t_241474, v_t_241475));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241483 = args[0];
  V v_one_241482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241484 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241483));
  V v_x1_241485 = heff_get_n(v_t_241484, 6, 9);
  V v_t_241486;
  if ((heff_dup(v_x1_241485) == NTAG(TAG_True))) {
    heff_drop(v_x1_241485);
    v_t_241486 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241485);
    v_t_241486 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241487 = heff_tr(heff_call(v_one_241482, 1, (V[]){v_a_241483}));
  return (g_std_2edoc_2e_3c_3e(v_t_241486, v_t_241487));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241495 = args[0];
  V v_one_241494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241496 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241495));
  V v_x1_241497 = heff_get_n(v_t_241496, 6, 9);
  V v_t_241498;
  if ((heff_dup(v_x1_241497) == NTAG(TAG_True))) {
    heff_drop(v_x1_241497);
    v_t_241498 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241497);
    v_t_241498 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241499 = heff_tr(heff_call(v_one_241494, 1, (V[]){v_a_241495}));
  return (g_std_2edoc_2e_3c_3e(v_t_241498, v_t_241499));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241507 = args[0];
  V v_one_241506 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241508 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241507));
  V v_x1_241509 = heff_get_n(v_t_241508, 6, 9);
  V v_t_241510;
  if ((heff_dup(v_x1_241509) == NTAG(TAG_True))) {
    heff_drop(v_x1_241509);
    v_t_241510 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241509);
    v_t_241510 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241511 = heff_tr(heff_call(v_one_241506, 1, (V[]){v_a_241507}));
  return (g_std_2edoc_2e_3c_3e(v_t_241510, v_t_241511));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241519 = args[0];
  V v_one_241518 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241520 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241519));
  V v_x1_241521 = heff_get_n(v_t_241520, 6, 9);
  V v_t_241522;
  if ((heff_dup(v_x1_241521) == NTAG(TAG_True))) {
    heff_drop(v_x1_241521);
    v_t_241522 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241521);
    v_t_241522 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241523 = heff_tr(heff_call(v_one_241518, 1, (V[]){v_a_241519}));
  return (g_std_2edoc_2e_3c_3e(v_t_241522, v_t_241523));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241532 = args[0];
  V v_one_241531 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241533 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241532));
  V v_x1_241534 = heff_get_n(v_t_241533, 6, 9);
  V v_t_241535;
  if ((heff_dup(v_x1_241534) == NTAG(TAG_True))) {
    heff_drop(v_x1_241534);
    v_t_241535 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241534);
    v_t_241535 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241536 = heff_tr(heff_call(v_one_241531, 1, (V[]){v_a_241532}));
  return (g_std_2edoc_2e_3c_3e(v_t_241535, v_t_241536));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241544 = args[0];
  V v_one_241543 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241545 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241544));
  V v_x1_241546 = heff_get_n(v_t_241545, 6, 9);
  V v_t_241547;
  if ((heff_dup(v_x1_241546) == NTAG(TAG_True))) {
    heff_drop(v_x1_241546);
    v_t_241547 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241546);
    v_t_241547 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241548 = heff_tr(heff_call(v_one_241543, 1, (V[]){v_a_241544}));
  return (g_std_2edoc_2e_3c_3e(v_t_241547, v_t_241548));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241556 = args[0];
  V v_one_241555 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241557 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241556));
  V v_x1_241558 = heff_get_n(v_t_241557, 6, 9);
  V v_t_241559;
  if ((heff_dup(v_x1_241558) == NTAG(TAG_True))) {
    heff_drop(v_x1_241558);
    v_t_241559 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241558);
    v_t_241559 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241560 = heff_tr(heff_call(v_one_241555, 1, (V[]){v_a_241556}));
  return (g_std_2edoc_2e_3c_3e(v_t_241559, v_t_241560));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241568 = args[0];
  V v_one_241567 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241569 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241568));
  V v_x1_241570 = heff_get_n(v_t_241569, 6, 9);
  V v_t_241571;
  if ((heff_dup(v_x1_241570) == NTAG(TAG_True))) {
    heff_drop(v_x1_241570);
    v_t_241571 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241570);
    v_t_241571 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241572 = heff_tr(heff_call(v_one_241567, 1, (V[]){v_a_241568}));
  return (g_std_2edoc_2e_3c_3e(v_t_241571, v_t_241572));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241580 = args[0];
  V v_one_241579 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241581 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241580));
  V v_x1_241582 = heff_get_n(v_t_241581, 6, 9);
  V v_t_241583;
  if ((heff_dup(v_x1_241582) == NTAG(TAG_True))) {
    heff_drop(v_x1_241582);
    v_t_241583 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241582);
    v_t_241583 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241584 = heff_tr(heff_call(v_one_241579, 1, (V[]){v_a_241580}));
  return (g_std_2edoc_2e_3c_3e(v_t_241583, v_t_241584));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241592 = args[0];
  V v_one_241591 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241593 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241592));
  V v_x1_241594 = heff_get_n(v_t_241593, 6, 9);
  V v_t_241595;
  if ((heff_dup(v_x1_241594) == NTAG(TAG_True))) {
    heff_drop(v_x1_241594);
    v_t_241595 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241594);
    v_t_241595 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241596 = heff_tr(heff_call(v_one_241591, 1, (V[]){v_a_241592}));
  return (g_std_2edoc_2e_3c_3e(v_t_241595, v_t_241596));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241605 = args[0];
  V v_one_241604 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241606 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241605));
  V v_x1_241607 = heff_get_n(v_t_241606, 6, 9);
  V v_t_241608;
  if ((heff_dup(v_x1_241607) == NTAG(TAG_True))) {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241609 = heff_tr(heff_call(v_one_241604, 1, (V[]){v_a_241605}));
  return (g_std_2edoc_2e_3c_3e(v_t_241608, v_t_241609));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241617 = args[0];
  V v_one_241616 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241618 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241617));
  V v_x1_241619 = heff_get_n(v_t_241618, 6, 9);
  V v_t_241620;
  if ((heff_dup(v_x1_241619) == NTAG(TAG_True))) {
    heff_drop(v_x1_241619);
    v_t_241620 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241619);
    v_t_241620 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241621 = heff_tr(heff_call(v_one_241616, 1, (V[]){v_a_241617}));
  return (g_std_2edoc_2e_3c_3e(v_t_241620, v_t_241621));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241628 = args[0];
  V v_one_241627 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241629 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241628));
  V v_x1_241630 = heff_get_n(v_t_241629, 6, 9);
  V v_t_241631;
  if ((heff_dup(v_x1_241630) == NTAG(TAG_True))) {
    heff_drop(v_x1_241630);
    v_t_241631 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241630);
    v_t_241631 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241632 = heff_tr(heff_call(v_one_241627, 1, (V[]){v_a_241628}));
  return (g_std_2edoc_2e_3c_3e(v_t_241631, v_t_241632));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241640 = args[0];
  V v_one_241639 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241641 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241640));
  V v_x1_241642 = heff_get_n(v_t_241641, 6, 9);
  V v_t_241643;
  if ((heff_dup(v_x1_241642) == NTAG(TAG_True))) {
    heff_drop(v_x1_241642);
    v_t_241643 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241642);
    v_t_241643 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241644 = heff_tr(heff_call(v_one_241639, 1, (V[]){v_a_241640}));
  return (g_std_2edoc_2e_3c_3e(v_t_241643, v_t_241644));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241653 = args[0];
  V v_one_241652 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241654 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241653));
  V v_x1_241655 = heff_get_n(v_t_241654, 6, 9);
  V v_t_241656;
  if ((heff_dup(v_x1_241655) == NTAG(TAG_True))) {
    heff_drop(v_x1_241655);
    v_t_241656 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241655);
    v_t_241656 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241657 = heff_tr(heff_call(v_one_241652, 1, (V[]){v_a_241653}));
  return (g_std_2edoc_2e_3c_3e(v_t_241656, v_t_241657));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241665 = args[0];
  V v_one_241664 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241666 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241665));
  V v_x1_241667 = heff_get_n(v_t_241666, 6, 9);
  V v_t_241668;
  if ((heff_dup(v_x1_241667) == NTAG(TAG_True))) {
    heff_drop(v_x1_241667);
    v_t_241668 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241667);
    v_t_241668 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241669 = heff_tr(heff_call(v_one_241664, 1, (V[]){v_a_241665}));
  return (g_std_2edoc_2e_3c_3e(v_t_241668, v_t_241669));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241680 = args[0];
  V v_one_241679 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241681 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241680));
  V v_x1_241682 = heff_get_n(v_t_241681, 6, 9);
  V v_t_241683;
  if ((heff_dup(v_x1_241682) == NTAG(TAG_True))) {
    heff_drop(v_x1_241682);
    v_t_241683 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241682);
    v_t_241683 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241684 = heff_tr(heff_call(v_one_241679, 1, (V[]){v_a_241680}));
  return (g_std_2edoc_2e_3c_3e(v_t_241683, v_t_241684));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241692 = args[0];
  V v_one_241691 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241693 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241692));
  V v_x1_241694 = heff_get_n(v_t_241693, 6, 9);
  V v_t_241695;
  if ((heff_dup(v_x1_241694) == NTAG(TAG_True))) {
    heff_drop(v_x1_241694);
    v_t_241695 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241694);
    v_t_241695 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241696 = heff_tr(heff_call(v_one_241691, 1, (V[]){v_a_241692}));
  return (g_std_2edoc_2e_3c_3e(v_t_241695, v_t_241696));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241706 = args[0];
  V v_one_241705 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241707 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241706));
  V v_x1_241708 = heff_get_n(v_t_241707, 6, 9);
  V v_t_241709;
  if ((heff_dup(v_x1_241708) == NTAG(TAG_True))) {
    heff_drop(v_x1_241708);
    v_t_241709 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241708);
    v_t_241709 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241710 = heff_tr(heff_call(v_one_241705, 1, (V[]){v_a_241706}));
  return (g_std_2edoc_2e_3c_3e(v_t_241709, v_t_241710));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241718 = args[0];
  V v_one_241717 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241719 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241718));
  V v_x1_241720 = heff_get_n(v_t_241719, 6, 9);
  V v_t_241721;
  if ((heff_dup(v_x1_241720) == NTAG(TAG_True))) {
    heff_drop(v_x1_241720);
    v_t_241721 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241720);
    v_t_241721 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241722 = heff_tr(heff_call(v_one_241717, 1, (V[]){v_a_241718}));
  return (g_std_2edoc_2e_3c_3e(v_t_241721, v_t_241722));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241732 = args[0];
  V v_one_241731 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241733 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241732));
  V v_x1_241734 = heff_get_n(v_t_241733, 6, 9);
  V v_t_241735;
  if ((heff_dup(v_x1_241734) == NTAG(TAG_True))) {
    heff_drop(v_x1_241734);
    v_t_241735 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241734);
    v_t_241735 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241736 = heff_tr(heff_call(v_one_241731, 1, (V[]){v_a_241732}));
  return (g_std_2edoc_2e_3c_3e(v_t_241735, v_t_241736));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241744 = args[0];
  V v_one_241743 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241745 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241744));
  V v_x1_241746 = heff_get_n(v_t_241745, 6, 9);
  V v_t_241747;
  if ((heff_dup(v_x1_241746) == NTAG(TAG_True))) {
    heff_drop(v_x1_241746);
    v_t_241747 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241746);
    v_t_241747 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241748 = heff_tr(heff_call(v_one_241743, 1, (V[]){v_a_241744}));
  return (g_std_2edoc_2e_3c_3e(v_t_241747, v_t_241748));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241757 = args[0];
  V v_one_241756 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241758 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241757));
  V v_x1_241759 = heff_get_n(v_t_241758, 6, 9);
  V v_t_241760;
  if ((heff_dup(v_x1_241759) == NTAG(TAG_True))) {
    heff_drop(v_x1_241759);
    v_t_241760 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241759);
    v_t_241760 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241761 = heff_tr(heff_call(v_one_241756, 1, (V[]){v_a_241757}));
  return (g_std_2edoc_2e_3c_3e(v_t_241760, v_t_241761));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241769 = args[0];
  V v_one_241768 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241770 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241769));
  V v_x1_241771 = heff_get_n(v_t_241770, 6, 9);
  V v_t_241772;
  if ((heff_dup(v_x1_241771) == NTAG(TAG_True))) {
    heff_drop(v_x1_241771);
    v_t_241772 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241771);
    v_t_241772 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241773 = heff_tr(heff_call(v_one_241768, 1, (V[]){v_a_241769}));
  return (g_std_2edoc_2e_3c_3e(v_t_241772, v_t_241773));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241785 = args[0];
  V v_one_241784 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241786 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241785));
  V v_x1_241787 = heff_get_n(v_t_241786, 6, 9);
  V v_t_241788;
  if ((heff_dup(v_x1_241787) == NTAG(TAG_True))) {
    heff_drop(v_x1_241787);
    v_t_241788 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241787);
    v_t_241788 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241789 = heff_tr(heff_call(v_one_241784, 1, (V[]){v_a_241785}));
  return (g_std_2edoc_2e_3c_3e(v_t_241788, v_t_241789));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241797 = args[0];
  V v_one_241796 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241798 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241797));
  V v_x1_241799 = heff_get_n(v_t_241798, 6, 9);
  V v_t_241800;
  if ((heff_dup(v_x1_241799) == NTAG(TAG_True))) {
    heff_drop(v_x1_241799);
    v_t_241800 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241799);
    v_t_241800 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241801 = heff_tr(heff_call(v_one_241796, 1, (V[]){v_a_241797}));
  return (g_std_2edoc_2e_3c_3e(v_t_241800, v_t_241801));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_a_241809 = args[0];
  V v_one_241808 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241810 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241809));
  V v_x1_241811 = heff_get_n(v_t_241810, 6, 9);
  V v_t_241812;
  if ((heff_dup(v_x1_241811) == NTAG(TAG_True))) {
    heff_drop(v_x1_241811);
    v_t_241812 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241811);
    v_t_241812 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241813 = heff_tr(heff_call(v_one_241808, 1, (V[]){v_a_241809}));
  return (g_std_2edoc_2e_3c_3e(v_t_241812, v_t_241813));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_a_241821 = args[0];
  V v_one_241820 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241822 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241821));
  V v_x1_241823 = heff_get_n(v_t_241822, 6, 9);
  V v_t_241824;
  if ((heff_dup(v_x1_241823) == NTAG(TAG_True))) {
    heff_drop(v_x1_241823);
    v_t_241824 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241823);
    v_t_241824 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241825 = heff_tr(heff_call(v_one_241820, 1, (V[]){v_a_241821}));
  return (g_std_2edoc_2e_3c_3e(v_t_241824, v_t_241825));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_a_241834 = args[0];
  V v_one_241833 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241835 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241834));
  V v_x1_241836 = heff_get_n(v_t_241835, 6, 9);
  V v_t_241837;
  if ((heff_dup(v_x1_241836) == NTAG(TAG_True))) {
    heff_drop(v_x1_241836);
    v_t_241837 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241836);
    v_t_241837 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241838 = heff_tr(heff_call(v_one_241833, 1, (V[]){v_a_241834}));
  return (g_std_2edoc_2e_3c_3e(v_t_241837, v_t_241838));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_a_241846 = args[0];
  V v_one_241845 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241847 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241846));
  V v_x1_241848 = heff_get_n(v_t_241847, 6, 9);
  V v_t_241849;
  if ((heff_dup(v_x1_241848) == NTAG(TAG_True))) {
    heff_drop(v_x1_241848);
    v_t_241849 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241848);
    v_t_241849 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241850 = heff_tr(heff_call(v_one_241845, 1, (V[]){v_a_241846}));
  return (g_std_2edoc_2e_3c_3e(v_t_241849, v_t_241850));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_a_241862 = args[0];
  V v_one_241861 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241863 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241862));
  V v_x1_241864 = heff_get_n(v_t_241863, 6, 9);
  V v_t_241865;
  if ((heff_dup(v_x1_241864) == NTAG(TAG_True))) {
    heff_drop(v_x1_241864);
    v_t_241865 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241864);
    v_t_241865 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241866 = heff_tr(heff_call(v_one_241861, 1, (V[]){v_a_241862}));
  return (g_std_2edoc_2e_3c_3e(v_t_241865, v_t_241866));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_a_241874 = args[0];
  V v_one_241873 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241875 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241874));
  V v_x1_241876 = heff_get_n(v_t_241875, 6, 9);
  V v_t_241877;
  if ((heff_dup(v_x1_241876) == NTAG(TAG_True))) {
    heff_drop(v_x1_241876);
    v_t_241877 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241876);
    v_t_241877 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241878 = heff_tr(heff_call(v_one_241873, 1, (V[]){v_a_241874}));
  return (g_std_2edoc_2e_3c_3e(v_t_241877, v_t_241878));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_a_241890 = args[0];
  V v_one_241889 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241891 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241890));
  V v_x1_241892 = heff_get_n(v_t_241891, 6, 9);
  V v_t_241893;
  if ((heff_dup(v_x1_241892) == NTAG(TAG_True))) {
    heff_drop(v_x1_241892);
    v_t_241893 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241892);
    v_t_241893 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241894 = heff_tr(heff_call(v_one_241889, 1, (V[]){v_a_241890}));
  return (g_std_2edoc_2e_3c_3e(v_t_241893, v_t_241894));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_a_241902 = args[0];
  V v_one_241901 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241903 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241902));
  V v_x1_241904 = heff_get_n(v_t_241903, 6, 9);
  V v_t_241905;
  if ((heff_dup(v_x1_241904) == NTAG(TAG_True))) {
    heff_drop(v_x1_241904);
    v_t_241905 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241904);
    v_t_241905 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241906 = heff_tr(heff_call(v_one_241901, 1, (V[]){v_a_241902}));
  return (g_std_2edoc_2e_3c_3e(v_t_241905, v_t_241906));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_a_241915 = args[0];
  V v_one_241914 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241916 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241915));
  V v_x1_241917 = heff_get_n(v_t_241916, 6, 9);
  V v_t_241918;
  if ((heff_dup(v_x1_241917) == NTAG(TAG_True))) {
    heff_drop(v_x1_241917);
    v_t_241918 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241917);
    v_t_241918 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241919 = heff_tr(heff_call(v_one_241914, 1, (V[]){v_a_241915}));
  return (g_std_2edoc_2e_3c_3e(v_t_241918, v_t_241919));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_a_241927 = args[0];
  V v_one_241926 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241928 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241927));
  V v_x1_241929 = heff_get_n(v_t_241928, 6, 9);
  V v_t_241930;
  if ((heff_dup(v_x1_241929) == NTAG(TAG_True))) {
    heff_drop(v_x1_241929);
    v_t_241930 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241929);
    v_t_241930 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241931 = heff_tr(heff_call(v_one_241926, 1, (V[]){v_a_241927}));
  return (g_std_2edoc_2e_3c_3e(v_t_241930, v_t_241931));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_a_241941 = args[0];
  V v_one_241940 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241942 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241941));
  V v_x1_241943 = heff_get_n(v_t_241942, 6, 9);
  V v_t_241944;
  if ((heff_dup(v_x1_241943) == NTAG(TAG_True))) {
    heff_drop(v_x1_241943);
    v_t_241944 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241943);
    v_t_241944 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241945 = heff_tr(heff_call(v_one_241940, 1, (V[]){v_a_241941}));
  return (g_std_2edoc_2e_3c_3e(v_t_241944, v_t_241945));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args) {
  V v_a_241953 = args[0];
  V v_one_241952 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241954 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241953));
  V v_x1_241955 = heff_get_n(v_t_241954, 6, 9);
  V v_t_241956;
  if ((heff_dup(v_x1_241955) == NTAG(TAG_True))) {
    heff_drop(v_x1_241955);
    v_t_241956 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241955);
    v_t_241956 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241957 = heff_tr(heff_call(v_one_241952, 1, (V[]){v_a_241953}));
  return (g_std_2edoc_2e_3c_3e(v_t_241956, v_t_241957));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args) {
  V v_a_241969 = args[0];
  V v_one_241968 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241970 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241969));
  V v_x1_241971 = heff_get_n(v_t_241970, 6, 9);
  V v_t_241972;
  if ((heff_dup(v_x1_241971) == NTAG(TAG_True))) {
    heff_drop(v_x1_241971);
    v_t_241972 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241971);
    v_t_241972 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241973 = heff_tr(heff_call(v_one_241968, 1, (V[]){v_a_241969}));
  return (g_std_2edoc_2e_3c_3e(v_t_241972, v_t_241973));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args) {
  V v_a_241981 = args[0];
  V v_one_241980 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241982 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241981));
  V v_x1_241983 = heff_get_n(v_t_241982, 6, 9);
  V v_t_241984;
  if ((heff_dup(v_x1_241983) == NTAG(TAG_True))) {
    heff_drop(v_x1_241983);
    v_t_241984 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241983);
    v_t_241984 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241985 = heff_tr(heff_call(v_one_241980, 1, (V[]){v_a_241981}));
  return (g_std_2edoc_2e_3c_3e(v_t_241984, v_t_241985));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args) {
  V v_a_241992 = args[0];
  V v_one_241991 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241993 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241992));
  V v_x1_241994 = heff_get_n(v_t_241993, 6, 9);
  V v_t_241995;
  if ((heff_dup(v_x1_241994) == NTAG(TAG_True))) {
    heff_drop(v_x1_241994);
    v_t_241995 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241994);
    v_t_241995 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241996 = heff_tr(heff_call(v_one_241991, 1, (V[]){v_a_241992}));
  return (g_std_2edoc_2e_3c_3e(v_t_241995, v_t_241996));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args) {
  V v_a_242004 = args[0];
  V v_one_242003 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242005 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242004));
  V v_x1_242006 = heff_get_n(v_t_242005, 6, 9);
  V v_t_242007;
  if ((heff_dup(v_x1_242006) == NTAG(TAG_True))) {
    heff_drop(v_x1_242006);
    v_t_242007 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242006);
    v_t_242007 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242008 = heff_tr(heff_call(v_one_242003, 1, (V[]){v_a_242004}));
  return (g_std_2edoc_2e_3c_3e(v_t_242007, v_t_242008));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args) {
  V v_a_242016 = args[0];
  V v_one_242015 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242017 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242016));
  V v_x1_242018 = heff_get_n(v_t_242017, 6, 9);
  V v_t_242019;
  if ((heff_dup(v_x1_242018) == NTAG(TAG_True))) {
    heff_drop(v_x1_242018);
    v_t_242019 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242018);
    v_t_242019 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242020 = heff_tr(heff_call(v_one_242015, 1, (V[]){v_a_242016}));
  return (g_std_2edoc_2e_3c_3e(v_t_242019, v_t_242020));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args) {
  V v_a_242028 = args[0];
  V v_one_242027 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242029 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242028));
  V v_x1_242030 = heff_get_n(v_t_242029, 6, 9);
  V v_t_242031;
  if ((heff_dup(v_x1_242030) == NTAG(TAG_True))) {
    heff_drop(v_x1_242030);
    v_t_242031 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242030);
    v_t_242031 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242032 = heff_tr(heff_call(v_one_242027, 1, (V[]){v_a_242028}));
  return (g_std_2edoc_2e_3c_3e(v_t_242031, v_t_242032));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args) {
  V v_a_242042 = args[0];
  V v_one_242041 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242043 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242042));
  V v_x1_242044 = heff_get_n(v_t_242043, 6, 9);
  V v_t_242045;
  if ((heff_dup(v_x1_242044) == NTAG(TAG_True))) {
    heff_drop(v_x1_242044);
    v_t_242045 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242044);
    v_t_242045 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242046 = heff_tr(heff_call(v_one_242041, 1, (V[]){v_a_242042}));
  return (g_std_2edoc_2e_3c_3e(v_t_242045, v_t_242046));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args) {
  V v_a_242054 = args[0];
  V v_one_242053 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242055 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242054));
  V v_x1_242056 = heff_get_n(v_t_242055, 6, 9);
  V v_t_242057;
  if ((heff_dup(v_x1_242056) == NTAG(TAG_True))) {
    heff_drop(v_x1_242056);
    v_t_242057 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242056);
    v_t_242057 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242058 = heff_tr(heff_call(v_one_242053, 1, (V[]){v_a_242054}));
  return (g_std_2edoc_2e_3c_3e(v_t_242057, v_t_242058));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args) {
  V v_a_242068 = args[0];
  V v_one_242067 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242069 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242068));
  V v_x1_242070 = heff_get_n(v_t_242069, 6, 9);
  V v_t_242071;
  if ((heff_dup(v_x1_242070) == NTAG(TAG_True))) {
    heff_drop(v_x1_242070);
    v_t_242071 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242070);
    v_t_242071 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242072 = heff_tr(heff_call(v_one_242067, 1, (V[]){v_a_242068}));
  return (g_std_2edoc_2e_3c_3e(v_t_242071, v_t_242072));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args) {
  V v_a_242080 = args[0];
  V v_one_242079 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242081 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242080));
  V v_x1_242082 = heff_get_n(v_t_242081, 6, 9);
  V v_t_242083;
  if ((heff_dup(v_x1_242082) == NTAG(TAG_True))) {
    heff_drop(v_x1_242082);
    v_t_242083 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242082);
    v_t_242083 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242084 = heff_tr(heff_call(v_one_242079, 1, (V[]){v_a_242080}));
  return (g_std_2edoc_2e_3c_3e(v_t_242083, v_t_242084));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_env_241106 = args[0];
  V v_h_241107 = args[1];
  V v_args_241108 = args[2];
  V v_x1_241109 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_241108)));
  V v_t_241113;
  switch (heff_tag_of(v_x1_241109)) {
  case TAG_Nil: {
    v_t_241113 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_241110 = heff_field(v_x1_241109, 0);
    V v_rev_241111 = heff_field(v_x1_241109, 1);
    V v_ru_24x1_241109_24Cons = heff_take_reuse_n(v_x1_241109, 3ULL, 2);
    V v_t_241112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241111));
    v_t_241113 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_241109_24Cons, TAG_MkPair, 2, (V[]){v_t_241112, v_x_241110})});
    break;
  }
  default: heff_nomatch(v_x1_241109);
  }
  switch (heff_tag_of(v_t_241113)) {
  case TAG_Nothing: {
    heff_drop(v_args_241108);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241106;
    args[1] = v_h_241107;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Just: {
    V v_pr_241114 = heff_field(v_t_241113, 0);
    V v_ru_24t_241113_24Just = heff_take_reuse_n(v_t_241113, 1ULL, 1);
    switch (heff_tag_of(v_pr_241114)) {
    case TAG_MkPair: {
      V v_init2_241115 = heff_field(v_pr_241114, 0);
      V v_lastA_241116 = heff_field(v_pr_241114, 1);
      V v_ru_24pr_241114_24MkPair = heff_take_reuse_n(v_pr_241114, 3ULL, 2);
      switch (heff_tag_of(v_lastA_241116)) {
      case TAG_Atom: {
        V v_t_241118 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241118) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241118);
          V v_t_241119 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241120 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241126 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_one_241120}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241127 = (g_std_2edoc_2e_3c_3e(v_t_241119, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241126})));
          V v_a_241128 = (g_std_2edoc_2egroup(v_t_241127));
          V v_b_241129 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241130 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241129));
          return (g_std_2edoc_2e_3c_3e(v_a_241128, v_t_241130));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 1);
          heff_drop(v_t_241118);
          V v_t_241131 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241132 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241138 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){v_one_241132}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241139 = (g_std_2edoc_2e_3c_3e(v_t_241131, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241138})));
          return (g_std_2edoc_2egroup(v_t_241139));
        }
      }
      case TAG_EParen: {
        V v_o_241140 = heff_field(v_lastA_241116, 0);
        V v_e_241141 = heff_field(v_lastA_241116, 1);
        V v_c_241142 = heff_field(v_lastA_241116, 2);
        heff_take_n(v_lastA_241116, 7ULL, 3);
        V v_t_241143 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_241141));
        if ((heff_dup(v_t_241143) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241143);
          V v_t_241144 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241145 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241151 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_one_241145}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241152 = (g_std_2edoc_2e_3c_3e(v_t_241144, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241151})));
          V v_a_241153 = (g_std_2edoc_2egroup(v_t_241152));
          V v_b_241154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241106), v_o_241140));
          V v_t_241155 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), v_b_241154));
          V v_t_241156 = (g_std_2edoc_2e_3c_3e(v_a_241153, v_t_241155));
          V v_t_241157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_e_241141}));
          V v_t_241158 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241106, v_c_241142));
          V v_t_241159 = (g_std_2edoc_2e_3c_3e(v_t_241157, v_t_241158));
          return (g_std_2edoc_2e_3c_3e(v_t_241156, v_t_241159));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop(v_o_241140);
          heff_drop(v_e_241141);
          heff_drop(v_c_241142);
          heff_drop(v_t_241143);
          V v_t_241160 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241167 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_one_241161}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241168 = (g_std_2edoc_2e_3c_3e(v_t_241160, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241167})));
          return (g_std_2edoc_2egroup(v_t_241168));
        }
      }
      case TAG_Named: {
        V v_t_241174 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241174) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241174);
          V v_t_241175 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241176 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241182 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241176}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241183 = (g_std_2edoc_2e_3c_3e(v_t_241175, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241182})));
          V v_a_241184 = (g_std_2edoc_2egroup(v_t_241183));
          V v_b_241185 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241186 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), v_b_241185));
          return (g_std_2edoc_2e_3c_3e(v_a_241184, v_t_241186));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 5);
          heff_drop(v_t_241174);
          V v_t_241187 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241194 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241188}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241195 = (g_std_2edoc_2e_3c_3e(v_t_241187, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241194})));
          return (g_std_2edoc_2egroup(v_t_241195));
        }
      }
      case TAG_Tup: {
        V v_t_241200 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241200) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241200);
          V v_t_241201 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241208 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241202}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241209 = (g_std_2edoc_2e_3c_3e(v_t_241201, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241208})));
          V v_a_241210 = (g_std_2edoc_2egroup(v_t_241209));
          V v_b_241211 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241212 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), v_b_241211));
          return (g_std_2edoc_2e_3c_3e(v_a_241210, v_t_241212));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_241200);
          V v_t_241213 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241214 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241220 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241214}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241221 = (g_std_2edoc_2e_3c_3e(v_t_241213, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241220})));
          return (g_std_2edoc_2egroup(v_t_241221));
        }
      }
      case TAG_Seg: {
        V v_t_241225 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241225) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241225);
          V v_t_241226 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241233 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241227}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241234 = (g_std_2edoc_2e_3c_3e(v_t_241226, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241233})));
          V v_a_241235 = (g_std_2edoc_2egroup(v_t_241234));
          V v_b_241236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241237 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), v_b_241236));
          return (g_std_2edoc_2e_3c_3e(v_a_241235, v_t_241237));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241225);
          V v_t_241238 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241239 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241245 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241239}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241246 = (g_std_2edoc_2e_3c_3e(v_t_241238, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241245})));
          return (g_std_2edoc_2egroup(v_t_241246));
        }
      }
      case TAG_Braces: {
        V v_t_241251 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241251) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241251);
          V v_t_241252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241253 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241259 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241253}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241260 = (g_std_2edoc_2e_3c_3e(v_t_241252, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241259})));
          V v_a_241261 = (g_std_2edoc_2egroup(v_t_241260));
          V v_b_241262 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241263 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), v_b_241262));
          return (g_std_2edoc_2e_3c_3e(v_a_241261, v_t_241263));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_241251);
          V v_t_241264 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241265 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241271 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241265}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241272 = (g_std_2edoc_2e_3c_3e(v_t_241264, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241271})));
          return (g_std_2edoc_2egroup(v_t_241272));
        }
      }
      case TAG_Update: {
        V v_t_241279 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241279) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241279);
          V v_t_241280 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241281 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241287 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241281}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241288 = (g_std_2edoc_2e_3c_3e(v_t_241280, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241287})));
          V v_a_241289 = (g_std_2edoc_2egroup(v_t_241288));
          V v_b_241290 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241291 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), v_b_241290));
          return (g_std_2edoc_2e_3c_3e(v_a_241289, v_t_241291));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 6);
          heff_drop(v_t_241279);
          V v_t_241292 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241293 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241299 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241293}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241300 = (g_std_2edoc_2e_3c_3e(v_t_241292, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241299})));
          return (g_std_2edoc_2egroup(v_t_241300));
        }
      }
      case TAG_EUSet: {
        V v_t_241304 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241304) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241304);
          V v_t_241305 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241306 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241312 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241306}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241313 = (g_std_2edoc_2e_3c_3e(v_t_241305, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241312})));
          V v_a_241314 = (g_std_2edoc_2egroup(v_t_241313));
          V v_b_241315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241316 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), v_b_241315));
          return (g_std_2edoc_2e_3c_3e(v_a_241314, v_t_241316));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241304);
          V v_t_241317 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241318 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241324 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241318}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241325 = (g_std_2edoc_2e_3c_3e(v_t_241317, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241324})));
          return (g_std_2edoc_2egroup(v_t_241325));
        }
      }
      case TAG_InstB: {
        V v_t_241331 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241331) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241331);
          V v_t_241332 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241333 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241339 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241333}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241340 = (g_std_2edoc_2e_3c_3e(v_t_241332, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241339})));
          V v_a_241341 = (g_std_2edoc_2egroup(v_t_241340));
          V v_b_241342 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241343 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), v_b_241342));
          return (g_std_2edoc_2e_3c_3e(v_a_241341, v_t_241343));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 5);
          heff_drop(v_t_241331);
          V v_t_241344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241345 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241351 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241345}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241352 = (g_std_2edoc_2e_3c_3e(v_t_241344, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241351})));
          return (g_std_2edoc_2egroup(v_t_241352));
        }
      }
      case TAG_EFSet: {
        V v_t_241356 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241356) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241356);
          V v_t_241357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241358 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241364 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241358}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241365 = (g_std_2edoc_2e_3c_3e(v_t_241357, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241364})));
          V v_a_241366 = (g_std_2edoc_2egroup(v_t_241365));
          V v_b_241367 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241368 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), v_b_241367));
          return (g_std_2edoc_2e_3c_3e(v_a_241366, v_t_241368));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241356);
          V v_t_241369 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241370 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241376 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241370}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241377 = (g_std_2edoc_2e_3c_3e(v_t_241369, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241376})));
          return (g_std_2edoc_2egroup(v_t_241377));
        }
      }
      case TAG_EFDefault: {
        V v_t_241381 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241381) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241381);
          V v_t_241382 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241383 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241389 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241383}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241390 = (g_std_2edoc_2e_3c_3e(v_t_241382, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241389})));
          V v_a_241391 = (g_std_2edoc_2egroup(v_t_241390));
          V v_b_241392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241393 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), v_b_241392));
          return (g_std_2edoc_2e_3c_3e(v_a_241391, v_t_241393));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241381);
          V v_t_241394 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241395 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241401 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241395}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241402 = (g_std_2edoc_2e_3c_3e(v_t_241394, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241401})));
          return (g_std_2edoc_2egroup(v_t_241402));
        }
      }
      case TAG_Sum: {
        V v_t_241408 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241408) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241408);
          V v_t_241409 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241416 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241410}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241417 = (g_std_2edoc_2e_3c_3e(v_t_241409, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241416})));
          V v_a_241418 = (g_std_2edoc_2egroup(v_t_241417));
          V v_b_241419 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241420 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), v_b_241419));
          return (g_std_2edoc_2e_3c_3e(v_a_241418, v_t_241420));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 5);
          heff_drop(v_t_241408);
          V v_t_241421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241428 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241422}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241429 = (g_std_2edoc_2e_3c_3e(v_t_241421, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241428})));
          return (g_std_2edoc_2egroup(v_t_241429));
        }
      }
      case TAG_ECon: {
        V v_t_241432 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241432) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241432);
          V v_t_241433 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241434 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241440 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241434}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241441 = (g_std_2edoc_2e_3c_3e(v_t_241433, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241440})));
          V v_a_241442 = (g_std_2edoc_2egroup(v_t_241441));
          V v_b_241443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241444 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), v_b_241443));
          return (g_std_2edoc_2e_3c_3e(v_a_241442, v_t_241444));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241432);
          V v_t_241445 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241452 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241446}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241453 = (g_std_2edoc_2e_3c_3e(v_t_241445, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241452})));
          return (g_std_2edoc_2egroup(v_t_241453));
        }
      }
      case TAG_EField: {
        V v_t_241456 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241456) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241456);
          V v_t_241457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241458 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241464 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241458}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241465 = (g_std_2edoc_2e_3c_3e(v_t_241457, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241464})));
          V v_a_241466 = (g_std_2edoc_2egroup(v_t_241465));
          V v_b_241467 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241468 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), v_b_241467));
          return (g_std_2edoc_2e_3c_3e(v_a_241466, v_t_241468));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241456);
          V v_t_241469 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241476 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241470}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241477 = (g_std_2edoc_2e_3c_3e(v_t_241469, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241476})));
          return (g_std_2edoc_2egroup(v_t_241477));
        }
      }
      case TAG_ENeg: {
        V v_t_241480 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241480) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241480);
          V v_t_241481 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241488 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241482}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241489 = (g_std_2edoc_2e_3c_3e(v_t_241481, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241488})));
          V v_a_241490 = (g_std_2edoc_2egroup(v_t_241489));
          V v_b_241491 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241492 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), v_b_241491));
          return (g_std_2edoc_2e_3c_3e(v_a_241490, v_t_241492));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241480);
          V v_t_241493 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241494 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241500 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241494}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241501 = (g_std_2edoc_2e_3c_3e(v_t_241493, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241500})));
          return (g_std_2edoc_2egroup(v_t_241501));
        }
      }
      case TAG_App: {
        V v_t_241504 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241504) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241504);
          V v_t_241505 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241506 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241512 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241506}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241513 = (g_std_2edoc_2e_3c_3e(v_t_241505, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241512})));
          V v_a_241514 = (g_std_2edoc_2egroup(v_t_241513));
          V v_b_241515 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241516 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_241515));
          return (g_std_2edoc_2e_3c_3e(v_a_241514, v_t_241516));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241504);
          V v_t_241517 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241518 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241524 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241518}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241525 = (g_std_2edoc_2e_3c_3e(v_t_241517, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241524})));
          return (g_std_2edoc_2egroup(v_t_241525));
        }
      }
      case TAG_Op: {
        V v_t_241529 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241529) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241529);
          V v_t_241530 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241531 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241537 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241531}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241538 = (g_std_2edoc_2e_3c_3e(v_t_241530, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241537})));
          V v_a_241539 = (g_std_2edoc_2egroup(v_t_241538));
          V v_b_241540 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241541 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), v_b_241540));
          return (g_std_2edoc_2e_3c_3e(v_a_241539, v_t_241541));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241529);
          V v_t_241542 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241543 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241549 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241543}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241550 = (g_std_2edoc_2e_3c_3e(v_t_241542, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241549})));
          return (g_std_2edoc_2egroup(v_t_241550));
        }
      }
      case TAG_Ops: {
        V v_t_241553 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241553) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241553);
          V v_t_241554 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241555 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241561 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241555}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241562 = (g_std_2edoc_2e_3c_3e(v_t_241554, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241561})));
          V v_a_241563 = (g_std_2edoc_2egroup(v_t_241562));
          V v_b_241564 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241565 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_241564));
          return (g_std_2edoc_2e_3c_3e(v_a_241563, v_t_241565));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241553);
          V v_t_241566 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241567 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241573 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241567}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241574 = (g_std_2edoc_2e_3c_3e(v_t_241566, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241573})));
          return (g_std_2edoc_2egroup(v_t_241574));
        }
      }
      case TAG_OpRhs: {
        V v_t_241577 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241577) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241577);
          V v_t_241578 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241579 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241585 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241579}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241586 = (g_std_2edoc_2e_3c_3e(v_t_241578, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241585})));
          V v_a_241587 = (g_std_2edoc_2egroup(v_t_241586));
          V v_b_241588 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241589 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str111)}), v_b_241588));
          return (g_std_2edoc_2e_3c_3e(v_a_241587, v_t_241589));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241577);
          V v_t_241590 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241591 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241597 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241591}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241598 = (g_std_2edoc_2e_3c_3e(v_t_241590, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241597})));
          return (g_std_2edoc_2egroup(v_t_241598));
        }
      }
      case TAG_Ann: {
        V v_t_241602 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241602) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241602);
          V v_t_241603 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241604 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241610 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241604}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241611 = (g_std_2edoc_2e_3c_3e(v_t_241603, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241610})));
          V v_a_241612 = (g_std_2edoc_2egroup(v_t_241611));
          V v_b_241613 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241614 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str112)}), v_b_241613));
          return (g_std_2edoc_2e_3c_3e(v_a_241612, v_t_241614));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241602);
          V v_t_241615 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241616 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241622 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241616}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241623 = (g_std_2edoc_2e_3c_3e(v_t_241615, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241622})));
          return (g_std_2edoc_2egroup(v_t_241623));
        }
      }
      case TAG_BVar: {
        V v_t_241625 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241625) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241625);
          V v_t_241626 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241627 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241633 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241627}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241634 = (g_std_2edoc_2e_3c_3e(v_t_241626, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241633})));
          V v_a_241635 = (g_std_2edoc_2egroup(v_t_241634));
          V v_b_241636 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241637 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str113)}), v_b_241636));
          return (g_std_2edoc_2e_3c_3e(v_a_241635, v_t_241637));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 1);
          heff_drop(v_t_241625);
          V v_t_241638 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241639 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241645 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241639}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241646 = (g_std_2edoc_2e_3c_3e(v_t_241638, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241645})));
          return (g_std_2edoc_2egroup(v_t_241646));
        }
      }
      case TAG_BImp: {
        V v_t_241650 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241650) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241650);
          V v_t_241651 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241652 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241658 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241652}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241659 = (g_std_2edoc_2e_3c_3e(v_t_241651, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241658})));
          V v_a_241660 = (g_std_2edoc_2egroup(v_t_241659));
          V v_b_241661 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241662 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str114)}), v_b_241661));
          return (g_std_2edoc_2e_3c_3e(v_a_241660, v_t_241662));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241650);
          V v_t_241663 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241664 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241670 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241664}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241671 = (g_std_2edoc_2e_3c_3e(v_t_241663, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241670})));
          return (g_std_2edoc_2egroup(v_t_241671));
        }
      }
      case TAG_BAnn: {
        V v_t_241677 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241677) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241677);
          V v_t_241678 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241679 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241685 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241679}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241686 = (g_std_2edoc_2e_3c_3e(v_t_241678, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241685})));
          V v_a_241687 = (g_std_2edoc_2egroup(v_t_241686));
          V v_b_241688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241689 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str115)}), v_b_241688));
          return (g_std_2edoc_2e_3c_3e(v_a_241687, v_t_241689));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 5);
          heff_drop(v_t_241677);
          V v_t_241690 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241691 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241697 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241691}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241698 = (g_std_2edoc_2e_3c_3e(v_t_241690, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241697})));
          return (g_std_2edoc_2egroup(v_t_241698));
        }
      }
      case TAG_Lam: {
        V v_t_241703 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241703) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241703);
          V v_t_241704 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241705 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241711 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241705}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241712 = (g_std_2edoc_2e_3c_3e(v_t_241704, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241711})));
          V v_a_241713 = (g_std_2edoc_2egroup(v_t_241712));
          V v_b_241714 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241715 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str116)}), v_b_241714));
          return (g_std_2edoc_2e_3c_3e(v_a_241713, v_t_241715));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_241703);
          V v_t_241716 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241717 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241723 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241717}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241724 = (g_std_2edoc_2e_3c_3e(v_t_241716, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241723})));
          return (g_std_2edoc_2egroup(v_t_241724));
        }
      }
      case TAG_Case: {
        V v_t_241729 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241729) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241729);
          V v_t_241730 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241731 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241737 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241731}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241738 = (g_std_2edoc_2e_3c_3e(v_t_241730, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241737})));
          V v_a_241739 = (g_std_2edoc_2egroup(v_t_241738));
          V v_b_241740 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241741 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str117)}), v_b_241740));
          return (g_std_2edoc_2e_3c_3e(v_a_241739, v_t_241741));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_241729);
          V v_t_241742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241743 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241749 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241743}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241750 = (g_std_2edoc_2e_3c_3e(v_t_241742, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241749})));
          return (g_std_2edoc_2egroup(v_t_241750));
        }
      }
      case TAG_EAlt: {
        V v_t_241754 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241754) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241754);
          V v_t_241755 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241756 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241762 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241756}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241763 = (g_std_2edoc_2e_3c_3e(v_t_241755, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241762})));
          V v_a_241764 = (g_std_2edoc_2egroup(v_t_241763));
          V v_b_241765 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241766 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str118)}), v_b_241765));
          return (g_std_2edoc_2e_3c_3e(v_a_241764, v_t_241766));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241754);
          V v_t_241767 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241768 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241774 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241768}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241775 = (g_std_2edoc_2e_3c_3e(v_t_241767, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241774})));
          return (g_std_2edoc_2egroup(v_t_241775));
        }
      }
      case TAG_If: {
        V v_t_241782 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241782) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241782);
          V v_t_241783 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241784 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241790 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241784}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241791 = (g_std_2edoc_2e_3c_3e(v_t_241783, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241790})));
          V v_a_241792 = (g_std_2edoc_2egroup(v_t_241791));
          V v_b_241793 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241794 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str119)}), v_b_241793));
          return (g_std_2edoc_2e_3c_3e(v_a_241792, v_t_241794));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 6);
          heff_drop(v_t_241782);
          V v_t_241795 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241796 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241802 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241796}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241803 = (g_std_2edoc_2e_3c_3e(v_t_241795, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241802})));
          return (g_std_2edoc_2egroup(v_t_241803));
        }
      }
      case TAG_Do: {
        V v_t_241806 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241806) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241806);
          V v_t_241807 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241808 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241814 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 1, 1, (V[]){v_one_241808}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241815 = (g_std_2edoc_2e_3c_3e(v_t_241807, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241814})));
          V v_a_241816 = (g_std_2edoc_2egroup(v_t_241815));
          V v_b_241817 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241818 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str120)}), v_b_241817));
          return (g_std_2edoc_2e_3c_3e(v_a_241816, v_t_241818));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_241806);
          V v_t_241819 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241820 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241826 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 1, 1, (V[]){v_one_241820}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241827 = (g_std_2edoc_2e_3c_3e(v_t_241819, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241826})));
          return (g_std_2edoc_2egroup(v_t_241827));
        }
      }
      case TAG_ESBind: {
        V v_t_241831 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241831) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241831);
          V v_t_241832 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241839 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_one_241833}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241840 = (g_std_2edoc_2e_3c_3e(v_t_241832, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241839})));
          V v_a_241841 = (g_std_2edoc_2egroup(v_t_241840));
          V v_b_241842 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241843 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str121)}), v_b_241842));
          return (g_std_2edoc_2e_3c_3e(v_a_241841, v_t_241843));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241831);
          V v_t_241844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241845 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241851 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_one_241845}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241852 = (g_std_2edoc_2e_3c_3e(v_t_241844, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241851})));
          return (g_std_2edoc_2egroup(v_t_241852));
        }
      }
      case TAG_ELet: {
        V v_t_241859 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241859) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241859);
          V v_t_241860 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241861 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241867 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 1, 1, (V[]){v_one_241861}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241868 = (g_std_2edoc_2e_3c_3e(v_t_241860, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241867})));
          V v_a_241869 = (g_std_2edoc_2egroup(v_t_241868));
          V v_b_241870 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241871 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str122)}), v_b_241870));
          return (g_std_2edoc_2e_3c_3e(v_a_241869, v_t_241871));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 6);
          heff_drop(v_t_241859);
          V v_t_241872 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241873 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241879 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_one_241873}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241880 = (g_std_2edoc_2e_3c_3e(v_t_241872, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241879})));
          return (g_std_2edoc_2egroup(v_t_241880));
        }
      }
      case TAG_ELetMut: {
        V v_t_241887 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241887) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241887);
          V v_t_241888 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241889 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241895 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_one_241889}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241896 = (g_std_2edoc_2e_3c_3e(v_t_241888, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241895})));
          V v_a_241897 = (g_std_2edoc_2egroup(v_t_241896));
          V v_b_241898 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241899 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str123)}), v_b_241898));
          return (g_std_2edoc_2e_3c_3e(v_a_241897, v_t_241899));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 6);
          heff_drop(v_t_241887);
          V v_t_241900 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241901 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241907 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 1, 1, (V[]){v_one_241901}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241908 = (g_std_2edoc_2e_3c_3e(v_t_241900, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241907})));
          return (g_std_2edoc_2egroup(v_t_241908));
        }
      }
      case TAG_EAssign: {
        V v_t_241912 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241912) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241912);
          V v_t_241913 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241914 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241920 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 1, 1, (V[]){v_one_241914}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241921 = (g_std_2edoc_2e_3c_3e(v_t_241913, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241920})));
          V v_a_241922 = (g_std_2edoc_2egroup(v_t_241921));
          V v_b_241923 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241924 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str124)}), v_b_241923));
          return (g_std_2edoc_2e_3c_3e(v_a_241922, v_t_241924));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 3);
          heff_drop(v_t_241912);
          V v_t_241925 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241926 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241932 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 1, 1, (V[]){v_one_241926}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241933 = (g_std_2edoc_2e_3c_3e(v_t_241925, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241932})));
          return (g_std_2edoc_2egroup(v_t_241933));
        }
      }
      case TAG_EWhile: {
        V v_t_241938 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241938) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241938);
          V v_t_241939 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241940 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241946 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 1, 1, (V[]){v_one_241940}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241947 = (g_std_2edoc_2e_3c_3e(v_t_241939, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241946})));
          V v_a_241948 = (g_std_2edoc_2egroup(v_t_241947));
          V v_b_241949 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241950 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str125)}), v_b_241949));
          return (g_std_2edoc_2e_3c_3e(v_a_241948, v_t_241950));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_241938);
          V v_t_241951 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241952 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241958 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam97, 1, 1, (V[]){v_one_241952}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241959 = (g_std_2edoc_2e_3c_3e(v_t_241951, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241958})));
          return (g_std_2edoc_2egroup(v_t_241959));
        }
      }
      case TAG_EFor: {
        V v_t_241966 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241966) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241966);
          V v_t_241967 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241968 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241974 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam98, 1, 1, (V[]){v_one_241968}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241975 = (g_std_2edoc_2e_3c_3e(v_t_241967, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241974})));
          V v_a_241976 = (g_std_2edoc_2egroup(v_t_241975));
          V v_b_241977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_241978 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str126)}), v_b_241977));
          return (g_std_2edoc_2e_3c_3e(v_a_241976, v_t_241978));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 6);
          heff_drop(v_t_241966);
          V v_t_241979 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241980 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_241986 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam99, 1, 1, (V[]){v_one_241980}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_241987 = (g_std_2edoc_2e_3c_3e(v_t_241979, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241986})));
          return (g_std_2edoc_2egroup(v_t_241987));
        }
      }
      case TAG_EJump: {
        V v_t_241989 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_241989) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_241989);
          V v_t_241990 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_241991 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_241997 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam100, 1, 1, (V[]){v_one_241991}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_241998 = (g_std_2edoc_2e_3c_3e(v_t_241990, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241997})));
          V v_a_241999 = (g_std_2edoc_2egroup(v_t_241998));
          V v_b_242000 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_242001 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str127)}), v_b_242000));
          return (g_std_2edoc_2e_3c_3e(v_a_241999, v_t_242001));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 1);
          heff_drop(v_t_241989);
          V v_t_242002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242003 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_242009 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam101, 1, 1, (V[]){v_one_242003}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_242010 = (g_std_2edoc_2e_3c_3e(v_t_242002, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242009})));
          return (g_std_2edoc_2egroup(v_t_242010));
        }
      }
      case TAG_EReturn: {
        V v_t_242013 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_242013) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_242013);
          V v_t_242014 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242015 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_242021 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam102, 1, 1, (V[]){v_one_242015}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_242022 = (g_std_2edoc_2e_3c_3e(v_t_242014, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242021})));
          V v_a_242023 = (g_std_2edoc_2egroup(v_t_242022));
          V v_b_242024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_242025 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str128)}), v_b_242024));
          return (g_std_2edoc_2e_3c_3e(v_a_242023, v_t_242025));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 2);
          heff_drop(v_t_242013);
          V v_t_242026 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242027 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_242033 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam103, 1, 1, (V[]){v_one_242027}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_242034 = (g_std_2edoc_2e_3c_3e(v_t_242026, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242033})));
          return (g_std_2edoc_2egroup(v_t_242034));
        }
      }
      case TAG_ENest: {
        V v_t_242039 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_242039) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_242039);
          V v_t_242040 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242041 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_242047 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam104, 1, 1, (V[]){v_one_242041}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_242048 = (g_std_2edoc_2e_3c_3e(v_t_242040, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242047})));
          V v_a_242049 = (g_std_2edoc_2egroup(v_t_242048));
          V v_b_242050 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_242051 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str129)}), v_b_242050));
          return (g_std_2edoc_2e_3c_3e(v_a_242049, v_t_242051));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_242039);
          V v_t_242052 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242053 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_242059 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam105, 1, 1, (V[]){v_one_242053}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_242060 = (g_std_2edoc_2e_3c_3e(v_t_242052, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242059})));
          return (g_std_2edoc_2egroup(v_t_242060));
        }
      }
      case TAG_IfThen: {
        V v_t_242065 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_241116));
        if ((heff_dup(v_t_242065) == NTAG(TAG_True))) {
          heff_drop(v_args_241108);
          heff_drop(v_t_242065);
          V v_t_242066 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242067 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241106)}));
          V v_d_242073 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam106, 1, 1, (V[]){v_one_242067}); V a_2 = v_init2_241115; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_241115); r_; });
          V v_t_242074 = (g_std_2edoc_2e_3c_3e(v_t_242066, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242073})));
          V v_a_242075 = (g_std_2edoc_2egroup(v_t_242074));
          V v_b_242076 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241106, v_lastA_241116}));
          V v_t_242077 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_241113_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str130)}), v_b_242076));
          return (g_std_2edoc_2e_3c_3e(v_a_242075, v_t_242077));
        } else {
          heff_drop_cell(v_ru_24t_241113_24Just, 1);
          heff_drop(v_init2_241115);
          heff_drop_tag(v_lastA_241116, 4);
          heff_drop(v_t_242065);
          V v_t_242078 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241106), v_h_241107}));
          V v_one_242079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241106}));
          V v_d_242085 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam107, 1, 1, (V[]){v_one_242079}); V a_2 = v_args_241108; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241108); r_; });
          V v_t_242086 = (g_std_2edoc_2e_3c_3e(v_t_242078, heff_tag_at_n(v_ru_24pr_241114_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242085})));
          return (g_std_2edoc_2egroup(v_t_242086));
        }
      }
      default: return heff_nomatch(v_lastA_241116);
      }
    }
    default: return heff_nomatch(v_pr_241114);
    }
  }
  default: return heff_nomatch(v_t_241113);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args) {
  V v_env_242087 = args[0];
  V v_rest_242088 = args[1];
  V v_e_242089 = args[2];
  switch (heff_tag_of(v_e_242089)) {
  case TAG_Atom: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_242106 = heff_field(v_e_242089, 0);
    V v_fs_242107 = heff_field(v_e_242089, 1);
    V v_commas_242108 = heff_field(v_e_242089, 2);
    V v_c_242109 = heff_field(v_e_242089, 3);
    heff_take_n(v_e_242089, 15ULL, 4);
    switch (heff_tag_of(v_fs_242107)) {
    case TAG_Nil: {
      heff_drop(v_rest_242088);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_242087;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242106, v_fs_242107, v_commas_242108, v_c_242109});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_242110 = heff_dup(heff_field(v_fs_242107, 0));
      V v_rest2_242111 = heff_dup(heff_field(v_fs_242107, 1));
      switch (heff_tag_of(v_rest2_242111)) {
      case TAG_Nil: {
        V v_t_242112 = ({ V a_0 = v_rest_242088; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_242088); r_; });
        if ((heff_dup(v_t_242112) == NTAG(TAG_True))) {
          heff_drop(v_t_242112);
          V v_x1_242113 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_242110));
          if ((heff_dup(v_x1_242113) == NTAG(TAG_True))) {
            heff_drop(v_d_242110);
            heff_drop(v_x1_242113);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_242087;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242106, v_fs_242107, v_commas_242108, v_c_242109});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_242113);
            switch (heff_tag_of(v_commas_242108)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_242107, 2);
              V v_t_242114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242087), v_o_242106));
              V v_t_242115 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242087), v_d_242110}));
              V v_t_242116 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242087, v_c_242109));
              V v_t_242117 = (g_std_2edoc_2e_3c_3e(v_t_242115, v_t_242116));
              return (g_std_2edoc_2e_3c_3e(v_t_242114, v_t_242117));
            }
            case TAG_Cons: {
              heff_drop(v_d_242110);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_242087;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242106, v_fs_242107, v_commas_242108, v_c_242109});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_242108);
            }
          }
        } else {
          heff_drop(v_d_242110);
          heff_drop(v_t_242112);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_242087;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242106, v_fs_242107, v_commas_242108, v_c_242109});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_242111, 0ULL, 2);
        heff_drop(v_rest_242088);
        heff_drop(v_d_242110);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_242087;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242106, v_fs_242107, v_commas_242108, v_c_242109});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_242111);
      }
    }
    default: return heff_nomatch(v_fs_242107);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242088);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242087;
    args[1] = v_e_242089;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_242089);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args) {
  V v_env_242232 = args[0];
  V v_b_242233 = args[1];
  switch (heff_tag_of(v_b_242233)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_242297 = heff_field(v_b_242233, 0);
    heff_take_n(v_b_242233, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242232, v_t_242297));
  }
  case TAG_BImp: {
    V v_o_242298 = heff_field(v_b_242233, 0);
    V v_x_242299 = heff_field(v_b_242233, 1);
    V v_c_242300 = heff_field(v_b_242233, 2);
    heff_take_n(v_b_242233, 7ULL, 3);
    V v_t_242301 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242232), v_o_242298));
    V v_t_242302 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242232), v_x_242299));
    V v_t_242303 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242232, v_c_242300));
    V v_t_242304 = (g_std_2edoc_2e_3c_3e(v_t_242302, v_t_242303));
    return (g_std_2edoc_2e_3c_3e(v_t_242301, v_t_242304));
  }
  case TAG_BAnn: {
    V v_o_242305 = heff_field(v_b_242233, 0);
    V v_x_242306 = heff_field(v_b_242233, 1);
    V v_cc_242307 = heff_field(v_b_242233, 2);
    V v_ty_242308 = heff_field(v_b_242233, 3);
    V v_c_242309 = heff_field(v_b_242233, 4);
    heff_take_n(v_b_242233, 31ULL, 5);
    V v_t_242310 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242232), v_o_242305));
    V v_a_242311 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242232), v_x_242306));
    V v_a_242312 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242232), v_cc_242307));
    V v_b_242313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242232), v_ty_242308}));
    V v_t_242314 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str131)}), v_b_242313));
    V v_t_242315 = (g_std_2edoc_2e_3c_3e(v_a_242312, v_t_242314));
    V v_t_242316 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str132)}), v_t_242315));
    V v_t_242317 = (g_std_2edoc_2e_3c_3e(v_a_242311, v_t_242316));
    V v_t_242318 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242232, v_c_242309));
    V v_t_242319 = (g_std_2edoc_2e_3c_3e(v_t_242317, v_t_242318));
    return (g_std_2edoc_2e_3c_3e(v_t_242310, v_t_242319));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242232;
    args[1] = v_b_242233;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_242233);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args) {
  V v_env_242378 = args[0];
  V v_rest_242379 = args[1];
  V v_r_242380 = args[2];
  switch (heff_tag_of(v_r_242380)) {
  case TAG_Atom: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242439 = heff_field(v_r_242380, 0);
    V v_e_242440 = heff_field(v_r_242380, 1);
    heff_take_n(v_r_242380, 3ULL, 2);
    V v_a_242441 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242378), v_op_242439));
    V v_b_242442 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_242378, v_rest_242379, v_e_242440}));
    V v_t_242443 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str133)}), v_b_242442));
    return (g_std_2edoc_2e_3c_3e(v_a_242441, v_t_242443));
  }
  case TAG_Ann: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242379);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242378;
    args[1] = v_r_242380;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242380);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args) {
  V v_env_242514 = args[0];
  V v_r_242515 = args[1];
  switch (heff_tag_of(v_r_242515)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242574 = heff_field(v_r_242515, 0);
    V v_e_242575 = heff_field(v_r_242515, 1);
    heff_take_n(v_r_242515, 3ULL, 2);
    V v_a_242576 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242514), v_op_242574));
    V v_b_242577 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_242514, v_e_242575}));
    V v_t_242578 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str134)}), v_b_242577));
    return (g_std_2edoc_2e_3c_3e(v_a_242576, v_t_242578));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242514;
    args[1] = v_r_242515;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242515);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args) {
  V v_r_242662 = args[0];
  V v_env_242649 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242663 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242662));
  V v_t_242664;
  if ((heff_dup(v_x1_242663) == NTAG(TAG_True))) {
    heff_drop(v_x1_242663);
    v_t_242664 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242663);
    v_t_242664 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242665 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242649, v_r_242662}));
  return (g_std_2edoc_2e_3c_3e(v_t_242664, v_t_242665));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args) {
  V v_r_242671 = args[0];
  V v_env_242649 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242672 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242671));
  V v_t_242673;
  if ((heff_dup(v_x1_242672) == NTAG(TAG_True))) {
    heff_drop(v_x1_242672);
    v_t_242673 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242672);
    v_t_242673 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242674 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242649, v_r_242671}));
  return (g_std_2edoc_2e_3c_3e(v_t_242673, v_t_242674));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args) {
  V v_env_242649 = args[0];
  V v_first_242650 = args[1];
  V v_rest_242651 = args[2];
  V v_f_242652 = heff_dup(heff_rfield(v_env_242649, 6));
  HeffT2 v_t_242653 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_242652), heff_dup(v_rest_242651)));
  {
    V v_field_242655 = v_t_242653.f[1];
    int64_t v_tag_242654 = ((int64_t)v_t_242653.f[0]);
    V v_t_242660;
    if ((v_tag_242654 == ((int64_t)0ULL))) {
      V v_it1_242657 = v_field_242655;
      switch (heff_tag_of(v_it1_242657)) {
      case TAG_Nil: {
        heff_drop(v_f_242652);
        v_t_242660 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_242658 = heff_field(v_it1_242657, 0);
        V v_os_242659 = heff_field(v_it1_242657, 1);
        heff_take_n(v_it1_242657, 3ULL, 2);
        v_t_242660 = ({ V a_0 = v_f_242652; V a_1 = v_o_242658; V a_2 = v_os_242659; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_242659); r_; });
        break;
      }
      default: heff_nomatch(v_it1_242657);
      }
    } else {
      heff_drop(v_f_242652);
      heff_drop(v_field_242655);
      v_t_242660 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_242660)) {
    case TAG_Nothing: {
      V v_t_242661 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242649), v_first_242650}));
      V v_t_242666 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam113, 1, 1, (V[]){v_env_242649}); V a_2 = v_rest_242651; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242651); r_; });
      V v_t_242667 = (g_std_2edoc_2e_3c_3e(v_t_242661, v_t_242666));
      return (g_std_2edoc_2egroup(v_t_242667));
    }
    case TAG_Just: {
      V v_m_242668 = heff_field(v_t_242660, 0);
      heff_take_n(v_t_242660, 1ULL, 1);
      V v_t_242669 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_242649, 6)), heff_dup(v_m_242668), v_rest_242651));
      if ((heff_dup(v_t_242669) == NTAG(TAG_True))) {
        heff_drop(v_m_242668);
        heff_drop(v_t_242669);
        V v_t_242670 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242649), v_first_242650}));
        V v_t_242675 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam114, 1, 1, (V[]){v_env_242649}); V a_2 = v_rest_242651; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242651); r_; });
        V v_t_242676 = (g_std_2edoc_2e_3c_3e(v_t_242670, v_t_242675));
        return (g_std_2edoc_2egroup(v_t_242676));
      } else {
        heff_drop(v_t_242669);
        V v_t_242677 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242649, v_m_242668, v_first_242650, NTAG(TAG_Nil), v_rest_242651}));
        return (g_std_2edoc_2egroup(v_t_242677));
      }
    }
    default: return heff_nomatch(v_t_242660);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args) {
  V v_env_242678 = args[0];
  V v_m_242679 = args[1];
  V v_f_242680 = args[2];
  V v_acc_242681 = args[3];
  V v_rs_242682 = args[4];
  switch (heff_tag_of(v_rs_242682)) {
  case TAG_Nil: {
    heff_drop(v_m_242679);
    V v_t_242683 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242681));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_242678;
    args[1] = v_f_242680;
    args[2] = v_t_242683;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_242684 = heff_field(v_rs_242682, 0);
    V v_rest2_242685 = heff_field(v_rs_242682, 1);
    heff_take_n(v_rs_242682, 3ULL, 2);
    switch (heff_tag_of(v_r_242684)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_242744 = heff_dup(heff_field(v_r_242684, 0));
      V v_e_242745 = heff_dup(heff_field(v_r_242684, 1));
      V v_t_242746 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_242678, 6)), heff_dup(v_m_242679), heff_dup(heff_rfield(v_op_242744, 1))));
      V v_t_242749;
      switch (heff_tag_of(v_t_242746)) {
      case TAG_Tighter: {
        v_t_242749 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_242749 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_242746, 0ULL, 1);
        v_t_242749 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_242749 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_242746, 0ULL, 1);
        v_t_242749 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_242746);
      }
      if ((heff_dup(v_t_242749) == NTAG(TAG_True))) {
        heff_drop(v_t_242749);
        V v_t_242750 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242681));
        V v_t_242751 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_242678), v_f_242680, v_t_242750}));
        V v_x1_242752 = ({ V a_0 = v_r_242684; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_242684, 2); r_; });
        V v_t_242753;
        if ((heff_dup(v_x1_242752) == NTAG(TAG_True))) {
          heff_drop(v_x1_242752);
          v_t_242753 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_242752);
          v_t_242753 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_242754 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242678), v_op_242744));
        V v_b_242755 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242678, v_m_242679, v_e_242745, NTAG(TAG_Nil), v_rest2_242685}));
        V v_t_242756 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str135)}), v_b_242755));
        V v_t_242757 = (g_std_2edoc_2e_3c_3e(v_a_242754, v_t_242756));
        V v_t_242758 = (g_std_2edoc_2e_3c_3e(v_t_242753, v_t_242757));
        return (g_std_2edoc_2e_3c_3e(v_t_242751, v_t_242758));
      } else {
        heff_drop_rec(v_op_242744, 9);
        heff_drop(v_e_242745);
        heff_drop(v_t_242749);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242678;
        args[1] = v_m_242679;
        args[2] = v_f_242680;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
        args[4] = v_rest2_242685;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetMut: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAssign: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWhile: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFor: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EJump: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EReturn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENest: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_IfThen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242678;
      args[1] = v_m_242679;
      args[2] = v_f_242680;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242684, v_acc_242681});
      args[4] = v_rest2_242685;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_242684);
    }
  }
  default: return heff_nomatch(v_rs_242682);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args) {
  V v_env_242829 = args[0];
  V v_a_242830 = args[1];
  switch (heff_tag_of(v_a_242830)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_242911 = heff_field(v_a_242830, 0);
    V v_arrow_242912 = heff_field(v_a_242830, 1);
    V v_body_242913 = heff_field(v_a_242830, 2);
    heff_take_n(v_a_242830, 7ULL, 3);
    V v_a_242914 = ({ V a_0 = heff_dup(v_env_242829); V a_1 = v_p_242911; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_242911); r_; });
    V v_b_242915 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242829), v_arrow_242912));
    V v_t_242916 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str136)}), v_b_242915));
    V v_t_242917 = (g_std_2edoc_2e_3c_3e(v_a_242914, v_t_242916));
    V v_t_242918 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242829, v_body_242913}));
    return (g_std_2edoc_2e_3c_3e(v_t_242917, v_t_242918));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242829;
    args[1] = v_a_242830;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_242830);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args) {
  V v_env_242966 = args[0];
  V v_s_242967 = args[1];
  switch (heff_tag_of(v_s_242967)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_243059 = heff_field(v_s_242967, 0);
    V v_arrow_243060 = heff_field(v_s_242967, 1);
    V v_e_243061 = heff_field(v_s_242967, 2);
    heff_take_n(v_s_242967, 7ULL, 3);
    V v_a_243062 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242966), v_x_243059));
    V v_b_243063 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242966), v_arrow_243060));
    V v_t_243064 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str137)}), v_b_243063));
    V v_t_243065 = (g_std_2edoc_2e_3c_3e(v_a_243062, v_t_243064));
    V v_t_243066 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242966, v_e_243061}));
    return (g_std_2edoc_2e_3c_3e(v_t_243065, v_t_243066));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242966;
    args[1] = v_s_242967;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_242967);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args) {
  V v_env_243103 = args[0];
  V v_f_243104 = args[1];
  switch (heff_tag_of(v_f_243104)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_243131 = heff_field(v_f_243104, 0);
    V v_eq_243132 = heff_field(v_f_243104, 1);
    V v_e_243133 = heff_field(v_f_243104, 2);
    heff_take_n(v_f_243104, 7ULL, 3);
    V v_a_243134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243103), v_x_243131}));
    V v_b_243135 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243103), v_eq_243132));
    V v_t_243136 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str138)}), v_b_243135));
    V v_t_243137 = (g_std_2edoc_2e_3c_3e(v_a_243134, v_t_243136));
    V v_t_243138 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243103, v_e_243133}));
    return (g_std_2edoc_2e_3c_3e(v_t_243137, v_t_243138));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_243144 = heff_field(v_f_243104, 0);
    V v_eq_243145 = heff_field(v_f_243104, 1);
    V v_e_243146 = heff_field(v_f_243104, 2);
    heff_take_n(v_f_243104, 7ULL, 3);
    V v_a_243147 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243103), v_x_243144));
    V v_b_243148 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243103), v_eq_243145));
    V v_t_243149 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str139)}), v_b_243148));
    V v_t_243150 = (g_std_2edoc_2e_3c_3e(v_a_243147, v_t_243149));
    V v_t_243151 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243103, v_e_243146}));
    return (g_std_2edoc_2e_3c_3e(v_t_243150, v_t_243151));
  }
  case TAG_EFDefault: {
    V v_d_243152 = heff_field(v_f_243104, 0);
    V v_eq_243153 = heff_field(v_f_243104, 1);
    V v_e_243154 = heff_field(v_f_243104, 2);
    heff_take_n(v_f_243104, 7ULL, 3);
    V v_a_243155 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243103), v_d_243152}));
    V v_b_243156 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243103), v_eq_243153));
    V v_t_243157 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str140)}), v_b_243156));
    V v_t_243158 = (g_std_2edoc_2e_3c_3e(v_a_243155, v_t_243157));
    V v_t_243159 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243103, v_e_243154}));
    return (g_std_2edoc_2e_3c_3e(v_t_243158, v_t_243159));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243103;
    args[1] = v_f_243104;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_243104);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = heff_take_field(v_t_244, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2412;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = heff_get_n(v_t_244, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop_rec(v_t_244, 9);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2412 = heff_get_n(v_t_244, 8, 9);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DInstance: {
    V v_n_2411 = heff_field(v_d_240, 1);
    V v_x2_2414 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_DEqn: {
    V v_n_2417 = heff_field(v_d_240, 0);
    V v_x2_2422 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2417)));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_244));
    V v_t_2445;
    switch (heff_tag_of(v_d_244)) {
    case TAG_DImport: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2443 = heff_dup(heff_field(v_d_244, 0));
      v_t_2445 = heff_strEq(heff_get_n(v_w_2443, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_t_2466;
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
      V v_t_2447 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
      V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2446, v_t_2447, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_244)})));
      V v_t_2450 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_244); r_; });
      V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2450, v_ds_245));
      v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2451));
    } else {
      heff_drop(v_t_2445);
      V v_t_2452 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_t_2452);
        V v_t_2453 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2454 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_244));
        V v_t_2455 = ({ V a_0 = v_t_2454; V a_1 = heff_dup(v_d_244); V a_2 = v_ds_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2454); r_; });
        V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(v_t_2455));
        V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2453, v_t_2456));
        V v_t_2458 = ({ V a_0 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_244); r_; });
        V v_t_2459 = ({ V a_0 = v_t_2458; V a_1 = v_ds_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2458); r_; });
        V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_t_2459));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460));
      } else {
        heff_drop(v_t_2452);
        V v_t_2461 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2462 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
        V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2461, v_t_2462, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){v_d_244})));
        V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_ds_245));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2465));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2466));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2448 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2448; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2463 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2463; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str7, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_s_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_s_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x2_2411;
  if ((heff_unbox_word(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()))) == ((int64_t)0ULL))) {
    v_x2_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_249, NTAG(TAG_Nil)});
  } else {
    v_x2_2411 = ({ V b_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_s_249; V a_2 = MK_INT(0LL); V a_3 = heff_strFind(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), heff_dup(v_s_249), MK_INT(0LL)); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_249); r_; });
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str7));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtParsed_24cpr(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_at_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_e_242)}});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_env_244 = heff_take_field(v_at_240, 1);
    V v_eof_245 = ({ V b_0 = heff_get_n(v_at_240, 0, 2); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofOf(b_0)); heff_drop(b_0); r_; });
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_dup(v_env_244), MK_INT(0LL), NTAG(TAG_False), heff_dup(v_ds_243)));
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_244, 1), heff_get_n(v_eof_245, 7, 9)));
    V v_t_2412;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_249;
        v_t_2412 = v_x_2411;
      } else {
        heff_drop(v_field_249);
        v_t_2412 = NTAG(TAG_Nil);
      }
    }
    V v_t_2413 = ({ V a_0 = v_env_244; V a_1 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
    V v_f_2415 = (g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2414));
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_247 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_hdr_242, 2);
    heff_drop_rec(v_l_243, 3);
    heff_drop(v_t_247);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  } else {
    heff_drop(v_t_247);
    V v_t_248 = (g_prelude_2e_2b_2b_24f201610143x1454021782(heff_take_field(v_l_243, 0), heff_get_n(v_hdr_242, 0, 2)));
    V v_t_249 = (g_list_2esortBy_24s88152486x2058486153(v_t_248));
    HeffT2 v_t_2410 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_249, heff_get_n(v_l_243, 2, 3)));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_t_2413 = ({ V rv_6 = v_f_240; V rr_ = heff_rec_reuse_nf(v_field_2412, 63ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      V v_at_2414 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2411, v_t_2413});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      V v_t_2416 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_at_2414, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2415, MK_INT(0LL)});
      V v_t_2417 = (g_heff_2esyntax_2ecst_2eprogramGo(v_t_2416, NTAG(TAG_Nil)));
      return ({ V a_0 = v_at_2414; V a_1 = v_t_2417; HeffT2 r_ = (g_heff_2esyntax_2efmt_2elayout_2efmtParsed_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    }
  }
}