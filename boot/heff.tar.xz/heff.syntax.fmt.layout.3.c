// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinding 25795
#define TAG_EBindingP 13114
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_Fail 27959
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Union 35751
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_bare 9511801
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_hungOn 741036848
#define LBL_ifLink 754803170
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsLaid 1128065381
#define LBL_opsPiece 614217098
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsAfter 876174640
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_trail 311979552
static uint32_t shape_pE__bare__rhsOf__rhsAfter__letHead__letLink__ifLink__elseOf__appDoc__hungOn__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsLaid__opsChainDoc__opsPiece__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_bare, LBL_rhsOf, LBL_rhsAfter, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_hungOn, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsLaid, LBL_opsChainDoc, LBL_opsPiece, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblockOperand(V);
V g_heff_2esyntax_2efmt_2elayout_2eblockOperand_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockOperand_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblockRhs(V);
V g_heff_2esyntax_2efmt_2elayout_2eblockRhs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockRhs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eelemDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eelemDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eelemDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1043390301x1507959231(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1043390301x1507959231_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1043390301x1507959231_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1839936600x1555050891(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1839936600x1555050891_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1839936600x1555050891_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eleadOut(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadOut_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_24tok1_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailEnd_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1854884545x892082821(V, V);
V g_list_2efoldl_24s1854884545x892082821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854884545x892082821_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2egroup_24tok2(V, V);
V g_std_2edoc_2egroup_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_24tok2_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_2414;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_rfield(v_t_241, 7)));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_245 = v_field_244;
        switch (heff_tag_of(v_x_245)) {
        case TAG_Nil: {
          v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
          break;
        }
        case TAG_Cons: {
          V v_ru_24x_245_24Cons = heff_take_reuse_n(v_x_245, 0ULL, 2);
          V v_t_2412;
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
            v_t_2412 = NTAG(TAG_Nil);
          } else {
            HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_rfield(v_t_241, 7)));
            {
              V v_field_2410 = v_t_248.f[1];
              int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
              if ((v_tag_249 == ((int64_t)0ULL))) {
                V v_x_2411 = v_field_2410;
                v_t_2412 = v_x_2411;
              } else {
                heff_drop(v_field_2410);
                v_t_2412 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2413 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2412); r_; });
          v_t_2414 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x_245_24Cons, v_t_2413, heff_dup(g_std_2edoc_2ehardline_get())));
          break;
        }
        default: heff_nomatch(v_x_245);
        }
      } else {
        heff_drop(v_field_244);
        v_t_2414 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
  }
  HeffT2 v_t_2415 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 2), heff_rfield(v_t_241, 7)));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_t_2419;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2417);
      v_t_2419 = NTAG(TAG_Nil);
    }
    V v_t_2420 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2419); r_; });
    V v_s_2421 = heff_dup(heff_rfield(v_t_241, 2));
    V v_t_2422;
    if (heff_strEq_c_lent(v_s_2421, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
      heff_drop(v_s_2421);
      v_t_2422 = NTAG(TAG_None);
    } else {
      v_t_2422 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2421});
    }
    V v_t_2423;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
      heff_drop_rec(v_env_240, 7);
      heff_drop_rec(v_t_241, 9);
      v_t_2423 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      v_t_2423 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
    }
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2420, v_t_2424));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2425);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_blank_244 = heff_dup(heff_rfield(v_c_242, 1));
    V v_text_245 = heff_dup(heff_rfield(v_c_242, 0));
    V v_t_247;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = v_blank_244;
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_246);
        v_t_247 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      heff_drop(v_blank_244);
      v_t_247 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_248 = ({ V a_0 = v_text_245; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(a_0)); heff_drop(v_text_245); r_; });
    V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_249));
    V v_t_2411 = (g_std_2edoc_2e_3c_3e(v_t_248, v_t_2410));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_247, v_t_2411);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2479 = heff_field(v_e_240, 3);
    V t_0 = v_body_2479;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Op: {
    V v_a_241 = heff_field(v_e_240, 0);
    V v_op_242 = heff_field(v_e_240, 1);
    V v_b_243 = heff_field(v_e_240, 2);
    HeffT2 v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(v_b_243));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_bf_247 = v_field_245;
      V v_rest_248 = v_field_246;
      V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_242), v_rest_248));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_242), v_bf_247}), v_rest_248});
        return ((HeffT2){{heff_dup(v_a_241), v_t_2410}});
      } else {
        heff_drop(v_bf_247);
        heff_drop(v_rest_248);
        heff_drop(v_t_249);
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_242), heff_dup(v_b_243)}), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_dup(v_a_241), v_t_2411}});
      }
    }
  }
  default: {
    return ((HeffT2){{heff_dup(v_e_240), NTAG(TAG_Nil)}});
  }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_OpRhs: {
      V v_op_243 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    default: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_commas_243);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2412 = v_commas_243;
    } else {
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_x1_240, 1);
    V v_x1_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2455)));
    switch (heff_tag_of(v_x1_2456)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x1_2456, 0);
      V v_rev_2458 = heff_field(v_x1_2456, 1);
      heff_take_n(v_x1_2456, 3ULL, 2);
      V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2458));
      V v_init2_2460 = v_t_2459;
      heff_drop(v_init2_2460);
      V v_it12_2461 = v_x_2457;
      switch (heff_tag_of(v_it12_2461)) {
      case TAG_EParen: {
        V v_e_2463 = heff_field(v_it12_2461, 1);
        heff_take_n(v_it12_2461, 2ULL, 3);
        return ({ V a_0 = v_e_2463; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2463); r_; });
      }
      default: {
        return ({ V a_0 = v_it12_2461; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_it12_2461); r_; });
      }
      }
    }
    default: return heff_nomatch(v_x1_2456);
    }
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_True);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  case TAG_EWithBound: {
    return NTAG(TAG_False);
  }
  case TAG_EBinding: {
    return NTAG(TAG_False);
  }
  case TAG_EBindingP: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}

static V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_st;
static V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_init(void) {
  return heff_tag_n(TAG_FlatAlt, 2, (V[]){heff_dup(g_std_2edoc_2eemptyDoc_get()), NTAG(TAG_Fail)});
}
V g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_st)) return g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_val, &g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_st, g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, "=");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 4, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam55_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 4, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam67_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(21, shape_pE__bare__rhsOf__rhsAfter__letHead__letLink__ifLink__elseOf__appDoc__hungOn__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsLaid__opsChainDoc__opsPiece__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam2_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam38_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam40_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam41_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam42_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam43_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam46_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam47_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam50_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam51_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam52_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam53_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam54_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam55_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam58_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam61_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam64_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam65_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam66_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam67_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_env2_243 = args[0];
  V v_e0_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1));
  heff_room[0] = v_env2_243;
  heff_room[1] = v_e0_241;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  V v_t_242 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
  return (g_heff_2esyntax_2efmt_2elayout_2eleadOut(v_env_240, v_t_242, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_e0_241})));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_i_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_d_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2415 = heff_intSub(v_k_2413, v_i_2414);
  if (heff_intEq_c_lent(v_i_2415, MK_INT(0LL), 2)) {
    heff_drop(v_i_2415);
    return v_d_2411;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2415, v_d_2411});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_k_2413 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 2, (V[]){v_k_2413, v_d_2411})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_comma_2443 = args[0];
  V v_e_2444 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_a_2445 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_comma_2443));
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_244}));
  V v_b_2447 = heff_tr(g_heff_2esyntax_2efmt_2elayout_2eelemDoc(v_t_2446, v_e_2444));
  V v_t_2448 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), v_b_2447));
  V v_t_2449 = (g_std_2edoc_2e_3c_3e(v_a_2445, v_t_2448));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2449));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_i_2461 = args[0];
  V v_k_2460 = heff_env(self)[0];
  V v_d_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2462 = heff_intSub(v_k_2460, v_i_2461);
  if (heff_intEq_c_lent(v_i_2462, MK_INT(0LL), 2)) {
    heff_drop(v_i_2462);
    return v_d_2459;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2462, v_d_2459});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_k_2460 = args[0];
  V v_d_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 1, 2, (V[]){v_k_2460, v_d_2459})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_t_2468 = args[0];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_t_2468));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_comma_2483 = args[0];
  V v_f_2484 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_a_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_comma_2483));
  heff_clo_take(self, 1);
  V v_d_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 20)), 2, (V[]){v_env_244, v_f_2484}));
  V v_t_2487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2486})));
  V v_t_2488 = (g_std_2edoc_2e_3c_3e(v_a_2485, v_t_2487));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2488));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_i_2497 = args[0];
  V v_k_2496 = heff_env(self)[0];
  V v_d_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2498 = heff_intSub(v_k_2496, v_i_2497);
  if (heff_intEq_c_lent(v_i_2498, MK_INT(0LL), 2)) {
    heff_drop(v_i_2498);
    return v_d_2495;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2498, v_d_2495});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_k_2496 = args[0];
  V v_d_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 2, (V[]){v_k_2496, v_d_2495})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_comma_24124 = args[0];
  V v_f_24125 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_a_24126 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_comma_24124));
  heff_clo_take(self, 1);
  V v_d_24127 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 20)), 2, (V[]){v_env_244, v_f_24125}));
  V v_t_24128 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24127})));
  V v_t_24129 = (g_std_2edoc_2e_3c_3e(v_a_24126, v_t_24128));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24129));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_i_24140 = args[0];
  V v_k_24139 = heff_env(self)[0];
  V v_d_24138 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24141 = heff_intSub(v_k_24139, v_i_24140);
  if (heff_intEq_c_lent(v_i_24141, MK_INT(0LL), 2)) {
    heff_drop(v_i_24141);
    return v_d_24138;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24141, v_d_24138});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_k_24139 = args[0];
  V v_d_24138 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 2, (V[]){v_k_24139, v_d_24138})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_bar_24191 = args[0];
  V v_a_24192 = args[1];
  V v_env_244 = heff_env(self)[0];
  V v_o_24174 = heff_env(self)[1];
  V v_c_24177 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24193 = ({ V a_0 = heff_rfield(v_env_244, 0); V a_1 = heff_get_n(v_o_24174, 4, 9); V b_2 = heff_get_n(v_c_24177, 3, 9); V r_ = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_24194;
  if ((heff_dup(v_x1_24193) == NTAG(TAG_True))) {
    heff_drop(v_x1_24193);
    v_t_24194 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24193);
    v_t_24194 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24195 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_bar_24191));
  V v_b_24196 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_a_24192}));
  V v_t_24197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24196));
  V v_t_24198 = (g_std_2edoc_2e_3c_3e(v_a_24195, v_t_24197));
  return (g_std_2edoc_2e_3c_3e(v_t_24194, v_t_24198));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_i_24205 = args[0];
  V v_k_24204 = heff_env(self)[0];
  V v_d_24203 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24206 = heff_intSub(v_k_24204, v_i_24205);
  if (heff_intEq_c_lent(v_i_24206, MK_INT(0LL), 2)) {
    heff_drop(v_i_24206);
    return v_d_24203;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24206, v_d_24203});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_k_24204 = args[0];
  V v_d_24203 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_k_24204, v_d_24203})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_a_24212 = args[0];
  V v_env_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24213 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_a_24212}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24213));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_r_24240 = args[0];
  V v_op_24230 = heff_env(self)[0];
  V v_bf_24235 = heff_env(self)[1];
  V v_rest_24236 = heff_env(self)[2];
  V v_env_244 = heff_env(self)[3];
  V v_x1_24241 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24240));
  V v_t_24242;
  if ((heff_dup(v_x1_24241) == NTAG(TAG_True))) {
    heff_drop(v_x1_24241);
    v_t_24242 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24241);
    v_t_24242 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 4);
  V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24230, v_bf_24235}), v_rest_24236});
  V v_t_24244 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 3, (V[]){v_env_244, v_t_24243, v_r_24240}));
  return (g_std_2edoc_2e_3c_3e(v_t_24242, v_t_24244));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24368 = args[0];
  V v_k_24367 = heff_env(self)[0];
  V v_d_24366 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24369 = heff_intSub(v_k_24367, v_i_24368);
  if (heff_intEq_c_lent(v_i_24369, MK_INT(0LL), 2)) {
    heff_drop(v_i_24369);
    return v_d_24366;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24369, v_d_24366});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24367 = args[0];
  V v_d_24366 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24367, v_d_24366})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24428 = args[0];
  V v_k_24427 = heff_env(self)[0];
  V v_d_24424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24429 = heff_intSub(v_k_24427, v_i_24428);
  if (heff_intEq_c_lent(v_i_24429, MK_INT(0LL), 2)) {
    heff_drop(v_i_24429);
    return v_d_24424;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24429, v_d_24424});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24427 = args[0];
  V v_d_24424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24427, v_d_24424})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24447 = args[0];
  V v_k_24446 = heff_env(self)[0];
  V v_d_24443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24448 = heff_intSub(v_k_24446, v_i_24447);
  if (heff_intEq_c_lent(v_i_24448, MK_INT(0LL), 2)) {
    heff_drop(v_i_24448);
    return v_d_24443;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24448, v_d_24443});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24446 = args[0];
  V v_d_24443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24446, v_d_24443})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24499 = args[0];
  V v_k_24498 = heff_env(self)[0];
  V v_d_24497 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24500 = heff_intSub(v_k_24498, v_i_24499);
  if (heff_intEq_c_lent(v_i_24500, MK_INT(0LL), 2)) {
    heff_drop(v_i_24500);
    return v_d_24497;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24500, v_d_24497});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24498 = args[0];
  V v_d_24497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24498, v_d_24497})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_i_24530 = args[0];
  V v_k_24529 = heff_env(self)[0];
  V v_d_24520 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24531 = heff_intSub(v_k_24529, v_i_24530);
  if (heff_intEq_c_lent(v_i_24531, MK_INT(0LL), 2)) {
    heff_drop(v_i_24531);
    return v_d_24520;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24531, v_d_24520});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_k_24529 = args[0];
  V v_d_24520 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 2, (V[]){v_k_24529, v_d_24520})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_i_24538 = args[0];
  V v_k_24537 = heff_env(self)[0];
  V v_d_24536 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24539 = heff_intSub(v_k_24537, v_i_24538);
  if (heff_intEq_c_lent(v_i_24539, MK_INT(0LL), 2)) {
    heff_drop(v_i_24539);
    return v_d_24536;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24539, v_d_24536});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_k_24537 = args[0];
  V v_d_24536 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 2, (V[]){v_k_24537, v_d_24536})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24559 = args[0];
  V v_k_24558 = heff_env(self)[0];
  V v_d_24557 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24560 = heff_intSub(v_k_24558, v_i_24559);
  if (heff_intEq_c_lent(v_i_24560, MK_INT(0LL), 2)) {
    heff_drop(v_i_24560);
    return v_d_24557;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24560, v_d_24557});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24558 = args[0];
  V v_d_24557 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24558, v_d_24557})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_i_24567 = args[0];
  V v_k_24566 = heff_env(self)[0];
  V v_d_24565 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24568 = heff_intSub(v_k_24566, v_i_24567);
  if (heff_intEq_c_lent(v_i_24568, MK_INT(0LL), 2)) {
    heff_drop(v_i_24568);
    return v_d_24565;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24568, v_d_24565});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_k_24566 = args[0];
  V v_d_24565 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 2, (V[]){v_k_24566, v_d_24565})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_i_24577 = args[0];
  V v_k_24576 = heff_env(self)[0];
  V v_d_24575 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24578 = heff_intSub(v_k_24576, v_i_24577);
  if (heff_intEq_c_lent(v_i_24578, MK_INT(0LL), 2)) {
    heff_drop(v_i_24578);
    return v_d_24575;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24578, v_d_24575});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_k_24576 = args[0];
  V v_d_24575 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 2, (V[]){v_k_24576, v_d_24575})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_env_244 = args[0];
  V v_e0_245 = args[1];
  switch (heff_tag_of(v_e0_245)) {
  case TAG_Atom: {
    V v_t_246 = heff_field(v_e0_245, 0);
    V v_ru_24e0_245_24Atom = heff_take_reuse_n(v_e0_245, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_245_24Atom, v_env_244, v_t_246));
  }
  case TAG_EParen: {
    V v_o_247 = heff_field(v_e0_245, 0);
    V v_e_248 = heff_field(v_e0_245, 1);
    V v_c_249 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_t_2410 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_247));
    V v_d_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_e_248}));
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_249));
    V v_t_2416 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 1, 1, (V[]){v_d_2411})}), v_t_2412));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2416));
  }
  case TAG_Named: {
    V v_o_2417 = heff_field(v_e0_245, 0);
    V v_x_2418 = heff_field(v_e0_245, 1);
    V v_k_2419 = heff_field(v_e0_245, 2);
    V v_e_2420 = heff_field(v_e0_245, 3);
    V v_c_2421 = heff_field(v_e0_245, 4);
    heff_take_n(v_e0_245, 31ULL, 5);
    V v_t_2422 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_2417));
    V v_a_2423 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_2418));
    V v_a_2424 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_k_2419));
    V v_b_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_e_2420}));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2425));
    V v_t_2427 = (g_std_2edoc_2e_3c_3e(v_a_2424, v_t_2426));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2427));
    V v_t_2429 = (g_std_2edoc_2e_3c_3e(v_a_2423, v_t_2428));
    V v_t_2430 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_2421));
    V v_t_2431 = (g_std_2edoc_2e_3c_3e(v_t_2429, v_t_2430));
    return (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2431));
  }
  case TAG_Tup: {
    V v_o_2432 = heff_field(v_e0_245, 0);
    V v_es_2433 = heff_field(v_e0_245, 1);
    V v_commas_2434 = heff_field(v_e0_245, 2);
    V v_c_2435 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    switch (heff_tag_of(v_es_2433)) {
    case TAG_Nil: {
      heff_drop(v_commas_2434);
      V v_t_2436 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_2432));
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_2435));
      return (g_std_2edoc_2e_3c_3e(v_t_2436, v_t_2437));
    }
    case TAG_Cons: {
      V v_e1_2438 = heff_field(v_es_2433, 0);
      V v_more_2439 = heff_field(v_es_2433, 1);
      V v_ru_24es_2433_24Cons = heff_take_reuse_n(v_es_2433, 3ULL, 2);
      V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), heff_dup(v_o_2432)));
      V v_t_2441 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_244)}));
      V v_t_2442 = heff_tr(g_heff_2esyntax_2efmt_2elayout_2eelemDoc(v_t_2441, v_e1_2438));
      V v_t_2450 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 2, 1, (V[]){heff_dup(v_env_244)}); V a_2 = v_commas_2434; V a_3 = v_more_2439; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_commas_2434); heff_drop(v_more_2439); r_; });
      V v_x1_2451 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_244, 0), heff_get_n(v_o_2432, 4, 9), heff_rfield(v_c_2435, 3)));
      V v_t_2452;
      if ((heff_dup(v_x1_2451) == NTAG(TAG_True))) {
        heff_drop(v_x1_2451);
        v_t_2452 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2451);
        v_t_2452 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2453 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_2435));
      V v_t_2454 = (g_std_2edoc_2e_3c_3e(v_t_2452, v_t_2453));
      V v_t_2455 = (g_std_2edoc_2e_3c_3e(v_t_2450, v_t_2454));
      V v_t_2456 = (g_std_2edoc_2e_3c_3e(v_t_2442, v_t_2455));
      V v_t_2457 = heff_tag_at_n(v_ru_24es_2433_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2458 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2456));
      V v_d_2459 = (g_std_2edoc_2e_3c_3e(v_t_2440, v_t_2458));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_d_2459})})));
    }
    default: return heff_nomatch(v_es_2433);
    }
  }
  case TAG_Seg: {
    V v_v_2463 = heff_field(v_e0_245, 0);
    V v_cc_2464 = heff_field(v_e0_245, 1);
    V v_spec_2465 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_v_2463}));
    V v_t_2467 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_cc_2464));
    V v_t_2469 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_env_244}); V a_2 = v_spec_2465; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_spec_2465); r_; });
    V v_t_2470 = (g_std_2edoc_2e_3c_3e(v_t_2467, v_t_2469));
    return (g_std_2edoc_2e_3c_3e(v_t_2466, v_t_2470));
  }
  case TAG_Braces: {
    V v_o_2471 = heff_field(v_e0_245, 0);
    V v_fs_2472 = heff_field(v_e0_245, 1);
    V v_commas_2473 = heff_field(v_e0_245, 2);
    V v_c_2474 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    switch (heff_tag_of(v_fs_2472)) {
    case TAG_Nil: {
      heff_drop(v_commas_2473);
      V v_t_2475 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_2471));
      V v_t_2476 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_2474));
      return (g_std_2edoc_2e_3c_3e(v_t_2475, v_t_2476));
    }
    case TAG_Cons: {
      V v_f1_2477 = heff_field(v_fs_2472, 0);
      V v_more_2478 = heff_field(v_fs_2472, 1);
      V v_ru_24fs_2472_24Cons = heff_take_reuse_n(v_fs_2472, 3ULL, 2);
      V v_a_2479 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), heff_dup(v_o_2471)));
      V v_d_2480 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 20)), 2, (V[]){heff_dup(v_env_244), v_f1_2477}));
      V v_t_2481 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2472_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2480})));
      V v_t_2482 = (g_std_2edoc_2e_3c_3e(v_a_2479, v_t_2481));
      V v_t_2489 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 2, 1, (V[]){heff_dup(v_env_244)}); V a_2 = v_commas_2473; V a_3 = v_more_2478; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_commas_2473); heff_drop(v_more_2478); r_; });
      V v_x1_2490 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_244, 0), heff_get_n(v_o_2471, 4, 9), heff_rfield(v_c_2474, 3)));
      V v_t_2491;
      if ((heff_dup(v_x1_2490) == NTAG(TAG_True))) {
        heff_drop(v_x1_2490);
        v_t_2491 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2490);
        v_t_2491 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2492 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_2474));
      V v_t_2493 = (g_std_2edoc_2e_3c_3e(v_t_2491, v_t_2492));
      V v_t_2494 = (g_std_2edoc_2e_3c_3e(v_t_2489, v_t_2493));
      V v_d_2495 = (g_std_2edoc_2e_3c_3e(v_t_2482, v_t_2494));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 1, 1, (V[]){v_d_2495})})));
    }
    default: return heff_nomatch(v_fs_2472);
    }
  }
  case TAG_Update: {
    V v_o_2499 = heff_field(v_e0_245, 0);
    V v_r_24100 = heff_field(v_e0_245, 1);
    V v_bar_24101 = heff_field(v_e0_245, 2);
    V v_fs_24102 = heff_field(v_e0_245, 3);
    V v_commas_24103 = heff_field(v_e0_245, 4);
    V v_c_24104 = heff_field(v_e0_245, 5);
    heff_take_n(v_e0_245, 63ULL, 6);
    switch (heff_tag_of(v_fs_24102)) {
    case TAG_Nil: {
      heff_drop(v_commas_24103);
      V v_a_24105 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_2499));
      V v_a_24106 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_r_24100}));
      V v_a_24107 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_bar_24101));
      V v_b_24108 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24104));
      V v_t_24109 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24108));
      V v_t_24110 = (g_std_2edoc_2e_3c_3e(v_a_24107, v_t_24109));
      V v_t_24111 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24110));
      V v_t_24112 = (g_std_2edoc_2e_3c_3e(v_a_24106, v_t_24111));
      V v_t_24113 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24112));
      return (g_std_2edoc_2e_3c_3e(v_a_24105, v_t_24113));
    }
    case TAG_Cons: {
      V v_f1_24114 = heff_field(v_fs_24102, 0);
      V v_more_24115 = heff_field(v_fs_24102, 1);
      V v_ru_24fs_24102_24Cons = heff_take_reuse_n(v_fs_24102, 3ULL, 2);
      V v_a_24116 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), heff_dup(v_o_2499)));
      V v_d_24117 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_r_24100}));
      V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24102_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24117})));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(v_a_24116, v_t_24118));
      V v_a_24120 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_bar_24101));
      V v_d_24121 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 20)), 2, (V[]){heff_dup(v_env_244), v_f1_24114}));
      V v_t_24122 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24121})));
      V v_t_24123 = (g_std_2edoc_2e_3c_3e(v_a_24120, v_t_24122));
      V v_t_24130 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 2, 1, (V[]){heff_dup(v_env_244)}); V a_2 = v_commas_24103; V a_3 = v_more_24115; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_commas_24103); heff_drop(v_more_24115); r_; });
      V v_x1_24131 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_244, 0), heff_get_n(v_o_2499, 4, 9), heff_rfield(v_c_24104, 3)));
      V v_t_24132;
      if ((heff_dup(v_x1_24131) == NTAG(TAG_True))) {
        heff_drop(v_x1_24131);
        v_t_24132 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24131);
        v_t_24132 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24104));
      V v_t_24134 = (g_std_2edoc_2e_3c_3e(v_t_24132, v_t_24133));
      V v_t_24135 = (g_std_2edoc_2e_3c_3e(v_t_24130, v_t_24134));
      V v_t_24136 = (g_std_2edoc_2e_3c_3e(v_t_24123, v_t_24135));
      V v_t_24137 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24136));
      V v_d_24138 = (g_std_2edoc_2e_3c_3e(v_t_24119, v_t_24137));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 1, 1, (V[]){v_d_24138})})));
    }
    default: return heff_nomatch(v_fs_24102);
    }
  }
  case TAG_EUSet: {
    V v_x_24142 = heff_field(v_e0_245, 0);
    V v_eq_24143 = heff_field(v_e0_245, 1);
    V v_e_24144 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24145 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_x_24142}));
    V v_b_24146 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_eq_24143, v_e_24144}));
    V v_t_24147 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24146));
    return (g_std_2edoc_2e_3c_3e(v_a_24145, v_t_24147));
  }
  case TAG_InstB: {
    V v_o_24148 = heff_field(v_e0_245, 0);
    V v_o2_24149 = heff_field(v_e0_245, 1);
    V v_d_24150 = heff_field(v_e0_245, 2);
    V v_c1_24151 = heff_field(v_e0_245, 3);
    V v_c_24152 = heff_field(v_e0_245, 4);
    heff_take_n(v_e0_245, 31ULL, 5);
    V v_t_24153 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_24148));
    V v_t_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o2_24149));
    V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_d_24150}));
    V v_t_24156 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_c1_24151));
    V v_t_24157 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24152));
    V v_t_24158 = (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
    V v_t_24159 = (g_std_2edoc_2e_3c_3e(v_t_24155, v_t_24158));
    V v_t_24160 = (g_std_2edoc_2e_3c_3e(v_t_24154, v_t_24159));
    return (g_std_2edoc_2e_3c_3e(v_t_24153, v_t_24160));
  }
  case TAG_EFSet: {
    V v_x_24161 = heff_field(v_e0_245, 0);
    V v_eq_24162 = heff_field(v_e0_245, 1);
    V v_e_24163 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_24161));
    V v_b_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_eq_24162, v_e_24163}));
    V v_t_24166 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24165));
    return (g_std_2edoc_2e_3c_3e(v_a_24164, v_t_24166));
  }
  case TAG_EFDefault: {
    V v_d_24167 = heff_field(v_e0_245, 0);
    V v_eq_24168 = heff_field(v_e0_245, 1);
    V v_e_24169 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24170 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_d_24167}));
    V v_b_24171 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_eq_24168, v_e_24169}));
    V v_t_24172 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24171));
    return (g_std_2edoc_2e_3c_3e(v_a_24170, v_t_24172));
  }
  case TAG_Sum: {
    V v_kw_24173 = heff_field(v_e0_245, 0);
    V v_o_24174 = heff_field(v_e0_245, 1);
    V v_alts_24175 = heff_field(v_e0_245, 2);
    V v_bars_24176 = heff_field(v_e0_245, 3);
    V v_c_24177 = heff_field(v_e0_245, 4);
    heff_take_n(v_e0_245, 31ULL, 5);
    switch (heff_tag_of(v_alts_24175)) {
    case TAG_Nil: {
      heff_drop(v_bars_24176);
      V v_a_24178 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24173));
      V v_a_24179 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_24174));
      V v_b_24180 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24177));
      V v_t_24181 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24180));
      V v_t_24182 = (g_std_2edoc_2e_3c_3e(v_a_24179, v_t_24181));
      V v_t_24183 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24182));
      return (g_std_2edoc_2e_3c_3e(v_a_24178, v_t_24183));
    }
    case TAG_Cons: {
      V v_a1_24184 = heff_field(v_alts_24175, 0);
      V v_more_24185 = heff_field(v_alts_24175, 1);
      V v_ru_24alts_24175_24Cons = heff_take_reuse_n(v_alts_24175, 3ULL, 2);
      V v_a_24186 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24173));
      V v_a_24187 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), heff_dup(v_o_24174)));
      V v_b_24188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_a1_24184}));
      V v_t_24189 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24alts_24175_24Cons, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24188));
      V v_t_24190 = (g_std_2edoc_2e_3c_3e(v_a_24187, v_t_24189));
      V v_a_24199 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 2, 3, (V[]){heff_dup(v_env_244), v_o_24174, heff_dup(v_c_24177)}); V a_2 = v_bars_24176; V a_3 = v_more_24185; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_bars_24176); heff_drop(v_more_24185); r_; });
      V v_b_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24177));
      V v_t_24201 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24200));
      V v_t_24202 = (g_std_2edoc_2e_3c_3e(v_a_24199, v_t_24201));
      V v_d_24203 = (g_std_2edoc_2e_3c_3e(v_t_24190, v_t_24202));
      V v_b_24207 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_d_24203})})));
      V v_t_24208 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24207));
      return (g_std_2edoc_2e_3c_3e(v_a_24186, v_t_24208));
    }
    default: return heff_nomatch(v_alts_24175);
    }
  }
  case TAG_ECon: {
    V v_c_24209 = heff_field(v_e0_245, 0);
    V v_args_24210 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24ECon = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_t_24211 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_c_24209));
    V v_t_24214 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_env_244}); V a_2 = v_args_24210; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_args_24210); r_; });
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24ECon, v_t_24211, v_t_24214));
  }
  case TAG_EField: {
    V v_e_24215 = heff_field(v_e0_245, 0);
    V v_f_24216 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24EField = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_t_24217 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_e_24215}));
    V v_t_24218 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_f_24216));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24EField, v_t_24217, v_t_24218));
  }
  case TAG_ENeg: {
    V v_m_24219 = heff_field(v_e0_245, 0);
    V v_e_24220 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24ENeg = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_t_24221 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_m_24219));
    V v_t_24222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_e_24220}));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24ENeg, v_t_24221, v_t_24222));
  }
  case TAG_ETilde: {
    V v_m_24223 = heff_field(v_e0_245, 0);
    V v_e_24224 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24ETilde = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_t_24225 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_m_24223));
    V v_t_24226 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_e_24224}));
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24ETilde, v_t_24225, v_t_24226));
  }
  case TAG_App: {
    V v_h_24227 = heff_field(v_e0_245, 0);
    V v_args_24228 = heff_field(v_e0_245, 1);
    heff_take_n(v_e0_245, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8));
    heff_room[0] = v_env_244;
    heff_room[1] = MK_INT(0LL);
    heff_room[2] = v_h_24227;
    heff_room[3] = v_args_24228;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  case TAG_Op: {
    V v_a_24229 = heff_field(v_e0_245, 0);
    V v_op_24230 = heff_field(v_e0_245, 1);
    V v_b_24231 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    HeffT2 v_t_24232 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(v_b_24231));
    {
      V v_field_24233 = v_t_24232.f[0];
      V v_field_24234 = v_t_24232.f[1];
      V v_bf_24235 = v_field_24233;
      V v_rest_24236 = v_field_24234;
      V v_t_24237 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_24230), v_rest_24236));
      if ((heff_dup(v_t_24237) == NTAG(TAG_True))) {
        heff_drop(v_b_24231);
        heff_drop(v_t_24237);
        V v_t_24238 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24230), heff_dup(v_bf_24235)}), heff_dup(v_rest_24236)});
        V v_t_24239 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){heff_dup(v_env_244), v_t_24238, v_a_24229}));
        V v_f_24245 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 4, (V[]){heff_dup(v_op_24230), heff_dup(v_bf_24235), heff_dup(v_rest_24236), v_env_244});
        V v_t_24246 = heff_tr(heff_call(heff_dup(v_f_24245), 1, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24230, v_bf_24235})}));
        V v_t_24247 = (g_list_2emap(v_f_24245, v_rest_24236));
        V v_ds_24248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24246, v_t_24247});
        V v_t_24249 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24248; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop_tag(v_ds_24248, 2); r_; });
        V v_t_24250 = (g_std_2edoc_2e_3c_3e(v_t_24239, v_t_24249));
        return (g_std_2edoc_2egroup(v_t_24250));
      } else {
        heff_drop(v_bf_24235);
        heff_drop(v_rest_24236);
        heff_drop(v_t_24237);
        V v_t_24251 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24230), heff_dup(v_b_24231)}), NTAG(TAG_Nil)});
        V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){heff_dup(v_env_244), v_t_24251, v_a_24229}));
        V v_x1_24253 = ({ V b_0 = heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24230), heff_dup(v_b_24231)}); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(b_0)); heff_drop(b_0); r_; });
        V v_t_24254;
        if ((heff_dup(v_x1_24253) == NTAG(TAG_True))) {
          heff_drop(v_x1_24253);
          v_t_24254 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_24253);
          v_t_24254 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_t_24255 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){heff_dup(v_op_24230), heff_dup(v_b_24231)}), NTAG(TAG_Nil)});
        V v_t_24256 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 3, (V[]){v_env_244, v_t_24255, heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_24230, v_b_24231})}));
        V v_t_24257 = (g_std_2edoc_2e_3c_3e(v_t_24254, v_t_24256));
        V v_ds_24258 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24257, NTAG(TAG_Nil)});
        V v_t_24259 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_ds_24258; V r_ = (g_list_2efoldl_24s1854884545x892082821(a_0, a_1)); heff_drop_tag(v_ds_24258, 2); r_; });
        V v_t_24260 = (g_std_2edoc_2e_3c_3e(v_t_24252, v_t_24259));
        return (g_std_2edoc_2egroup(v_t_24260));
      }
    }
  }
  case TAG_Ops: {
    V v_a_24261 = heff_field(v_e0_245, 0);
    V v_rest_24262 = heff_field(v_e0_245, 1);
    heff_take_n(v_e0_245, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15));
    heff_room[0] = v_env_244;
    heff_room[1] = v_a_24261;
    heff_room[2] = v_rest_24262;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24263 = heff_field(v_e0_245, 0);
    V v_e_24264 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24OpRhs = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_a_24265 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_op_24263));
    V v_b_24266 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_e_24264}));
    V v_t_24267 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24266));
    return (g_std_2edoc_2e_3c_3e(v_a_24265, v_t_24267));
  }
  case TAG_Ann: {
    V v_e_24268 = heff_field(v_e0_245, 0);
    V v_cc_24269 = heff_field(v_e0_245, 1);
    V v_ty_24270 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24271 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_e_24268}));
    V v_b_24272 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_cc_24269));
    V v_t_24273 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24272));
    V v_t_24274 = (g_std_2edoc_2e_3c_3e(v_a_24271, v_t_24273));
    V v_t_24275 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_ty_24270}));
    V v_d_24276 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24275));
    V v_t_24277 = (g_std_2edoc_2e_3c_3e(v_t_24274, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24276})));
    return (g_std_2edoc_2egroup(v_t_24277));
  }
  case TAG_BVar: {
    V v_t_24278 = heff_field(v_e0_245, 0);
    V v_ru_24e0_245_24BVar = heff_take_reuse_n(v_e0_245, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_245_24BVar, v_env_244, v_t_24278));
  }
  case TAG_BImp: {
    V v_o_24279 = heff_field(v_e0_245, 0);
    V v_x_24280 = heff_field(v_e0_245, 1);
    V v_c_24281 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_t_24282 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_24279));
    V v_t_24283 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_24280));
    V v_t_24284 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24281));
    V v_t_24285 = (g_std_2edoc_2e_3c_3e(v_t_24283, v_t_24284));
    return (g_std_2edoc_2e_3c_3e(v_t_24282, v_t_24285));
  }
  case TAG_BAnn: {
    V v_o_24286 = heff_field(v_e0_245, 0);
    V v_x_24287 = heff_field(v_e0_245, 1);
    V v_cc_24288 = heff_field(v_e0_245, 2);
    V v_ty_24289 = heff_field(v_e0_245, 3);
    V v_c_24290 = heff_field(v_e0_245, 4);
    heff_take_n(v_e0_245, 31ULL, 5);
    V v_t_24291 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_24286));
    V v_a_24292 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_24287));
    V v_a_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_cc_24288));
    V v_b_24294 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_ty_24289}));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24294));
    V v_t_24296 = (g_std_2edoc_2e_3c_3e(v_a_24293, v_t_24295));
    V v_t_24297 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24296));
    V v_t_24298 = (g_std_2edoc_2e_3c_3e(v_a_24292, v_t_24297));
    V v_t_24299 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24290));
    V v_t_24300 = (g_std_2edoc_2e_3c_3e(v_t_24298, v_t_24299));
    return (g_std_2edoc_2e_3c_3e(v_t_24291, v_t_24300));
  }
  case TAG_BPat: {
    V v_p_24301 = heff_field(v_e0_245, 0);
    heff_take_n(v_e0_245, 1ULL, 1);
    return ({ V a_0 = v_env_244; V a_1 = v_p_24301; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_p_24301); r_; });
  }
  case TAG_Lam: {
    V v_bs_24302 = heff_field(v_e0_245, 0);
    V v_binders_24303 = heff_field(v_e0_245, 1);
    V v_arrow_24304 = heff_field(v_e0_245, 2);
    V v_body_24305 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_t_24306 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_bs_24302));
    V v_t_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 1, (V[]){heff_dup(v_env_244)}));
    V v_t_24308 = (g_list_2emap(v_t_24307, v_binders_24303));
    V v_a_24309 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24308; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24308); r_; });
    V v_b_24310 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_arrow_24304));
    V v_t_24311 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24310));
    V v_t_24312 = (g_std_2edoc_2e_3c_3e(v_a_24309, v_t_24311));
    V v_t_24313 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24305));
    V v_t_24317;
    if ((heff_dup(v_t_24313) == NTAG(TAG_True))) {
      heff_drop(v_t_24313);
      V v_t_24314 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_body_24305}));
      v_t_24317 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24314));
    } else {
      heff_drop(v_t_24313);
      V v_t_24315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 2, (V[]){v_env_244, v_body_24305}));
      V v_d_24316 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24315));
      v_t_24317 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24316})));
    }
    V v_t_24318 = (g_std_2edoc_2e_3c_3e(v_t_24312, v_t_24317));
    return (g_std_2edoc_2e_3c_3e(v_t_24306, v_t_24318));
  }
  case TAG_Case: {
    V v_kw_24319 = heff_field(v_e0_245, 0);
    V v_scrut_24320 = heff_field(v_e0_245, 1);
    V v_of2_24321 = heff_field(v_e0_245, 2);
    V v_alts_24322 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_a_24323 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24319));
    V v_a_24324 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_scrut_24320}));
    V v_b_24325 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_of2_24321));
    V v_t_24326 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24325));
    V v_t_24327 = (g_std_2edoc_2e_3c_3e(v_a_24324, v_t_24326));
    V v_t_24328 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24327));
    V v_t_24329 = (g_std_2edoc_2e_3c_3e(v_a_24323, v_t_24328));
    V v_t_24330 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_alts_24322; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1043390301x1507959231(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_alts_24322); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24329, v_t_24330));
  }
  case TAG_EAlt: {
    V v_p_24331 = heff_field(v_e0_245, 0);
    V v_arrow_24332 = heff_field(v_e0_245, 1);
    V v_body_24333 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24334 = ({ V a_0 = v_env_244; V a_1 = v_p_24331; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24331); r_; });
    V v_b_24335 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_arrow_24332, v_body_24333}));
    V v_t_24336 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24335));
    return (g_std_2edoc_2e_3c_3e(v_a_24334, v_t_24336));
  }
  case TAG_If: {
    V v_kw_24337 = heff_field(v_e0_245, 0);
    V v_c_24338 = heff_field(v_e0_245, 1);
    V v_th_24339 = heff_field(v_e0_245, 2);
    V v_a_24340 = heff_field(v_e0_245, 3);
    V v_el_24341 = heff_field(v_e0_245, 4);
    V v_b_24342 = heff_field(v_e0_245, 5);
    heff_take_n(v_e0_245, 63ULL, 6);
    V v_t_24343 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6)), 5, (V[]){heff_dup(v_env_244), v_kw_24337, v_c_24338, v_th_24339, v_a_24340}));
    V v_t_24344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_244, v_el_24341, v_b_24342}));
    V v_t_24345 = (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
    return (g_std_2edoc_2egroup(v_t_24345));
  }
  case TAG_Do: {
    V v_kw_24346 = heff_field(v_e0_245, 0);
    V v_stmts_24347 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24Do = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_t_24348 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24346));
    V v_t_24349 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24347; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_stmts_24347); r_; });
    return (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24Do, v_t_24348, v_t_24349));
  }
  case TAG_ESBind: {
    V v_x_24350 = heff_field(v_e0_245, 0);
    V v_arrow_24351 = heff_field(v_e0_245, 1);
    V v_e_24352 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24353 = ({ V a_0 = v_env_244; V a_1 = v_x_24350; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24350); r_; });
    V v_b_24354 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_arrow_24351, v_e_24352}));
    V v_t_24355 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24354));
    return (g_std_2edoc_2e_3c_3e(v_a_24353, v_t_24355));
  }
  case TAG_ELet: {
    V v_kw_24356 = heff_field(v_e0_245, 0);
    V v_p_24357 = heff_field(v_e0_245, 1);
    V v_ann_24358 = heff_field(v_e0_245, 2);
    V v_eq_24359 = heff_field(v_e0_245, 3);
    V v_e_24360 = heff_field(v_e0_245, 4);
    V v_body_24361 = heff_field(v_e0_245, 5);
    heff_take_n(v_e0_245, 63ULL, 6);
    switch (heff_tag_of(v_body_24361)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 6, (V[]){v_env_244, v_kw_24356, v_p_24357, v_ann_24358, v_eq_24359, v_e_24360});
    }
    case TAG_Just: {
      V v_it1_24362 = heff_field(v_body_24361, 0);
      V v_ru_24body_24361_24Just = heff_take_reuse_n(v_body_24361, 1ULL, 1);
      switch (heff_tag_of(v_it1_24362)) {
      case TAG_MkPair: {
        V v_i_24363 = heff_field(v_it1_24362, 0);
        V v_b_24364 = heff_field(v_it1_24362, 1);
        V v_ru_24it1_24362_24MkPair = heff_take_reuse_n(v_it1_24362, 3ULL, 2);
        V v_t_24365 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 8, (V[]){v_env_244, v_kw_24356, v_p_24357, v_ann_24358, v_eq_24359, v_e_24360, v_i_24363, v_b_24364}));
        V v_d_24366 = (g_std_2edoc_2egroup_24tok2(v_ru_24it1_24362_24MkPair, v_t_24365));
        return heff_tag_at_n(v_ru_24body_24361_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24366})});
      }
      default: return heff_nomatch(v_it1_24362);
      }
    }
    default: return heff_nomatch(v_body_24361);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24370 = heff_field(v_e0_245, 0);
    V v_p_24371 = heff_field(v_e0_245, 1);
    V v_ann_24372 = heff_field(v_e0_245, 2);
    V v_eq_24373 = heff_field(v_e0_245, 3);
    V v_e_24374 = heff_field(v_e0_245, 4);
    V v_el_24375 = heff_field(v_e0_245, 5);
    V v_ss_24376 = heff_field(v_e0_245, 6);
    heff_take_n(v_e0_245, 127ULL, 7);
    V v_a_24377 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 6, (V[]){heff_dup(v_env_244), v_kw_24370, v_p_24371, v_ann_24372, v_eq_24373, v_e_24374}));
    V v_b_24378 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_el_24375));
    V v_t_24379 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24378));
    V v_t_24380 = (g_std_2edoc_2e_3c_3e(v_a_24377, v_t_24379));
    V v_t_24388;
    switch (heff_tag_of(v_ss_24376)) {
    case TAG_Nil: {
      v_t_24388 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_ss_24376; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); r_; });
      break;
    }
    case TAG_Cons: {
      V v_s1_24381 = heff_dup(heff_field(v_ss_24376, 0));
      V v_it2_24382 = heff_dup(heff_field(v_ss_24376, 1));
      switch (heff_tag_of(v_it2_24382)) {
      case TAG_Nil: {
        V v_t_24383 = (g_heff_2esyntax_2ecst_2efirstE(v_s1_24381));
        V v_t_24384 = heff_get_n(v_t_24383, 6, 9);
        if ((heff_dup(v_t_24384) == NTAG(TAG_True))) {
          heff_drop(v_s1_24381);
          heff_drop(v_t_24384);
          v_t_24388 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_ss_24376; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop_tag(v_ss_24376, 2); r_; });
        } else {
          heff_drop_tag(v_ss_24376, 2);
          heff_drop(v_t_24384);
          V v_t_24385 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 19)), 2, (V[]){v_env_244, v_s1_24381}));
          v_t_24388 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24385));
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it2_24382, 0ULL, 2);
        heff_drop(v_s1_24381);
        v_t_24388 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_ss_24376; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop_tag(v_ss_24376, 2); r_; });
        break;
      }
      default: heff_nomatch(v_it2_24382);
      }
      break;
    }
    default: heff_nomatch(v_ss_24376);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24380, v_t_24388));
  }
  case TAG_ELetMut: {
    V v_kw_24389 = heff_field(v_e0_245, 0);
    V v_m_24390 = heff_field(v_e0_245, 1);
    V v_x_24391 = heff_field(v_e0_245, 2);
    V v_ann_24392 = heff_field(v_e0_245, 3);
    V v_eq_24393 = heff_field(v_e0_245, 4);
    V v_e_24394 = heff_field(v_e0_245, 5);
    heff_take_n(v_e0_245, 63ULL, 6);
    V v_a_24395 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24389));
    V v_a_24396 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_m_24390));
    V v_b_24397 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_24391));
    V v_t_24398 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24397));
    V v_t_24399 = (g_std_2edoc_2e_3c_3e(v_a_24396, v_t_24398));
    V v_t_24400 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24399));
    V v_t_24401 = (g_std_2edoc_2e_3c_3e(v_a_24395, v_t_24400));
    V v_a_24409;
    switch (heff_tag_of(v_ann_24392)) {
    case TAG_Nothing: {
      v_a_24409 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24402 = heff_field(v_ann_24392, 0);
      V v_ru_24ann_24392_24Just = heff_take_reuse_n(v_ann_24392, 1ULL, 1);
      switch (heff_tag_of(v_it1_24402)) {
      case TAG_MkPair: {
        V v_cc_24403 = heff_field(v_it1_24402, 0);
        V v_ty_24404 = heff_field(v_it1_24402, 1);
        V v_ru_24it1_24402_24MkPair = heff_take_reuse_n(v_it1_24402, 3ULL, 2);
        V v_a_24405 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_cc_24403));
        V v_b_24406 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_ty_24404}));
        V v_t_24407 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24402_24MkPair, heff_tag_at_n(v_ru_24ann_24392_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24406));
        V v_t_24408 = (g_std_2edoc_2e_3c_3e(v_a_24405, v_t_24407));
        v_a_24409 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_t_24408));
        break;
      }
      default: heff_nomatch(v_it1_24402);
      }
      break;
    }
    default: heff_nomatch(v_ann_24392);
    }
    V v_b_24410 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_eq_24393, v_e_24394}));
    V v_t_24411 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24410));
    V v_t_24412 = (g_std_2edoc_2e_3c_3e(v_a_24409, v_t_24411));
    return (g_std_2edoc_2e_3c_3e(v_t_24401, v_t_24412));
  }
  case TAG_EAssign: {
    V v_x_24413 = heff_field(v_e0_245, 0);
    V v_k_24414 = heff_field(v_e0_245, 1);
    V v_e_24415 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24416 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_24413));
    V v_b_24417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_k_24414, v_e_24415}));
    V v_t_24418 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24417));
    return (g_std_2edoc_2e_3c_3e(v_a_24416, v_t_24418));
  }
  case TAG_EWhile: {
    V v_kw_24419 = heff_field(v_e0_245, 0);
    V v_c_24420 = heff_field(v_e0_245, 1);
    V v_d_24421 = heff_field(v_e0_245, 2);
    V v_body_24422 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_a_24423 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24419));
    V v_d_24424 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_c_24420}));
    V v_b_24425 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_d_24421));
    V v_t_24426 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24425));
    V v_t_24430 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24424})}), v_t_24426));
    V v_t_24431 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24430));
    V v_t_24432 = (g_std_2edoc_2e_3c_3e(v_a_24423, v_t_24431));
    V v_t_24433 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_body_24422; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_body_24422); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24432, v_t_24433));
  }
  case TAG_EFor: {
    V v_kw_24434 = heff_field(v_e0_245, 0);
    V v_p_24435 = heff_field(v_e0_245, 1);
    V v_i_24436 = heff_field(v_e0_245, 2);
    V v_c_24437 = heff_field(v_e0_245, 3);
    V v_d_24438 = heff_field(v_e0_245, 4);
    V v_body_24439 = heff_field(v_e0_245, 5);
    heff_take_n(v_e0_245, 63ULL, 6);
    V v_a_24440 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24434));
    V v_a_24441 = ({ V a_0 = v_env_244; V a_1 = v_p_24435; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24435); r_; });
    V v_a_24442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_i_24436));
    V v_d_24443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_c_24437}));
    V v_b_24444 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_d_24438));
    V v_t_24445 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24444));
    V v_t_24449 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24443})}), v_t_24445));
    V v_t_24450 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24449));
    V v_t_24451 = (g_std_2edoc_2e_3c_3e(v_a_24442, v_t_24450));
    V v_t_24452 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_t_24451));
    V v_t_24453 = (g_std_2edoc_2e_3c_3e(v_a_24441, v_t_24452));
    V v_t_24454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_t_24453));
    V v_t_24455 = (g_std_2edoc_2e_3c_3e(v_a_24440, v_t_24454));
    V v_t_24456 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_body_24439; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_body_24439); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24455, v_t_24456));
  }
  case TAG_EJump: {
    V v_kw_24457 = heff_field(v_e0_245, 0);
    V v_ru_24e0_245_24EJump = heff_take_reuse_n(v_e0_245, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24e0_245_24EJump, v_env_244, v_kw_24457));
  }
  case TAG_EReturn: {
    V v_kw_24458 = heff_field(v_e0_245, 0);
    V v_e_24459 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24EReturn = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_a_24460 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24458));
    V v_d_24461 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_e_24459}));
    V v_t_24462 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_at_n(v_ru_24e0_245_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24461})));
    return (g_std_2edoc_2e_3c_3e(v_a_24460, v_t_24462));
  }
  case TAG_ENest: {
    V v_o_24463 = heff_field(v_e0_245, 0);
    V v_arrow_24464 = heff_field(v_e0_245, 1);
    V v_e_24465 = heff_field(v_e0_245, 2);
    V v_c_24466 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_t_24467 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_o_24463));
    V v_a_24468 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_arrow_24464));
    V v_b_24469 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_e_24465}));
    V v_t_24470 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24469));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(v_a_24468, v_t_24470));
    V v_t_24472 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_244, v_c_24466));
    V v_t_24473 = (g_std_2edoc_2e_3c_3e(v_t_24471, v_t_24472));
    return (g_std_2edoc_2e_3c_3e(v_t_24467, v_t_24473));
  }
  case TAG_EArrow: {
    V v_arrow_24474 = heff_field(v_e0_245, 0);
    V v_e_24475 = heff_field(v_e0_245, 1);
    V v_ru_24e0_245_24EArrow = heff_take_reuse_n(v_e0_245, 3ULL, 2);
    V v_a_24476 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_arrow_24474));
    V v_b_24477 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_e_24475}));
    V v_t_24478 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24e0_245_24EArrow, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_b_24477));
    return (g_std_2edoc_2e_3c_3e(v_a_24476, v_t_24478));
  }
  case TAG_IfThen: {
    V v_kw_24479 = heff_field(v_e0_245, 0);
    V v_c_24480 = heff_field(v_e0_245, 1);
    V v_th_24481 = heff_field(v_e0_245, 2);
    V v_a_24482 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_t_24483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6)), 5, (V[]){v_env_244, v_kw_24479, v_c_24480, v_th_24481, v_a_24482}));
    return (g_std_2edoc_2egroup(v_t_24483));
  }
  case TAG_ETry: {
    V v_kw_24484 = heff_field(v_e0_245, 0);
    V v_ty_24485 = heff_field(v_e0_245, 1);
    V v_body_24486 = heff_field(v_e0_245, 2);
    V v_c_24487 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_t_24488 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24484));
    V v_t_24491;
    switch (heff_tag_of(v_ty_24485)) {
    case TAG_Nothing: {
      v_t_24491 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24489 = heff_field(v_ty_24485, 0);
      V v_ru_24ty_24485_24Just = heff_take_reuse_n(v_ty_24485, 1ULL, 1);
      V v_t_24490 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_t_24489}));
      v_t_24491 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24485_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_t_24490));
      break;
    }
    default: heff_nomatch(v_ty_24485);
    }
    V v_d_24492 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_body_24486; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop(v_body_24486); r_; });
    V v_t_24493 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_244, v_c_24487}));
    V v_t_24494 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24493));
    V v_t_24495 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24492}), v_t_24494));
    V v_t_24496 = (g_std_2edoc_2e_3c_3e(v_t_24491, v_t_24495));
    V v_d_24497 = (g_std_2edoc_2e_3c_3e(v_t_24488, v_t_24496));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24497})});
  }
  case TAG_ECatch: {
    V v_kw_24501 = heff_field(v_e0_245, 0);
    V v_b_24502 = heff_field(v_e0_245, 1);
    V v_arrow_24503 = heff_field(v_e0_245, 2);
    V v_body_24504 = heff_field(v_e0_245, 3);
    heff_take_n(v_e0_245, 15ULL, 4);
    V v_a_24505 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24501));
    V v_a_24506 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 2, (V[]){heff_dup(v_env_244), v_b_24502}));
    V v_b_24507 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_arrow_24503));
    V v_t_24508 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_b_24507));
    V v_t_24509 = (g_std_2edoc_2e_3c_3e(v_a_24506, v_t_24508));
    V v_t_24510 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_t_24509));
    V v_t_24511 = (g_std_2edoc_2e_3c_3e(v_a_24505, v_t_24510));
    V v_d_24512 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_body_24504; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_body_24504); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24511, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24512})));
  }
  case TAG_EWith: {
    V v_kw_24513 = heff_field(v_e0_245, 0);
    V v_e_24514 = heff_field(v_e0_245, 1);
    V v_a_24515 = heff_field(v_e0_245, 2);
    V v_x_24516 = heff_field(v_e0_245, 3);
    V v_d_24517 = heff_field(v_e0_245, 4);
    V v_body_24518 = heff_field(v_e0_245, 5);
    heff_take_n(v_e0_245, 63ULL, 6);
    V v_a_24519 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24513));
    V v_d_24520 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_e_24514}));
    V v_a_24521 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_a_24515));
    V v_a_24522 = ({ V a_0 = v_env_244; V a_1 = v_x_24516; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24516); r_; });
    V v_b_24523 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_d_24517));
    V v_t_24524 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_b_24523));
    V v_t_24525 = (g_std_2edoc_2e_3c_3e(v_a_24522, v_t_24524));
    V v_t_24526 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24525));
    V v_t_24527 = (g_std_2edoc_2e_3c_3e(v_a_24521, v_t_24526));
    V v_t_24528 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24527));
    V v_t_24532 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){v_d_24520})}), v_t_24528));
    V v_t_24533 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24532));
    V v_t_24534 = (g_std_2edoc_2e_3c_3e(v_a_24519, v_t_24533));
    V v_d_24535 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_body_24518; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_body_24518); r_; });
    V v_d_24536 = (g_std_2edoc_2e_3c_3e(v_t_24534, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24535})));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){v_d_24536})});
  }
  case TAG_EWithBound: {
    V v_kw_24540 = heff_field(v_e0_245, 0);
    V v_bs_24541 = heff_field(v_e0_245, 1);
    V v_w_24542 = heff_field(v_e0_245, 2);
    V v_d_24543 = heff_field(v_e0_245, 3);
    V v_body_24544 = heff_field(v_e0_245, 4);
    heff_take_n(v_e0_245, 31ULL, 5);
    V v_a_24545 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_kw_24540));
    V v_d_24565;
    switch (heff_tag_of(v_bs_24541)) {
    case TAG_Nil: {
      heff_drop(v_w_24542);
      v_d_24565 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Cons: {
      V v_b1_24546 = heff_field(v_bs_24541, 0);
      V v_rest_24547 = heff_field(v_bs_24541, 1);
      V v_ru_24bs_24541_24Cons = heff_take_reuse_n(v_bs_24541, 3ULL, 2);
      V v_t_24548 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 19)), 2, (V[]){heff_dup(v_env_244), v_b1_24546}));
      V v_t_24549 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1839936600x1555050891(v_env_244, MK_INT(1LL), v_rest_24547));
      V v_t_24563;
      switch (heff_tag_of(v_w_24542)) {
      case TAG_Nothing: {
        heff_drop(v_rest_24547);
        heff_drop_cell(v_ru_24bs_24541_24Cons, 2);
        v_t_24563 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Just: {
        V v_it1_24550 = heff_field(v_w_24542, 0);
        V v_ru_24w_24542_24Just = heff_take_reuse_n(v_w_24542, 1ULL, 1);
        switch (heff_tag_of(v_it1_24550)) {
        case TAG_MkPair: {
          V v_wk_24551 = heff_field(v_it1_24550, 0);
          V v_c_24552 = heff_field(v_it1_24550, 1);
          V v_ru_24it1_24550_24MkPair = heff_take_reuse_n(v_it1_24550, 3ULL, 2);
          V v_t_24555;
          switch (heff_tag_of(v_rest_24547)) {
          case TAG_Nil: {
            v_t_24555 = heff_tag_at_n(v_ru_24w_24542_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_rest_24547, 0ULL, 2);
            heff_drop_cell(v_ru_24w_24542_24Just, 1);
            v_t_24555 = heff_dup(g_std_2edoc_2ehardline_get());
            break;
          }
          default: heff_nomatch(v_rest_24547);
          }
          V v_a_24556 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_wk_24551));
          V v_d_24557 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_244), v_c_24552}));
          V v_t_24561 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24bs_24541_24Cons, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24557})})));
          V v_t_24562 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24550_24MkPair, v_a_24556, v_t_24561));
          v_t_24563 = (g_std_2edoc_2e_3c_3e(v_t_24555, v_t_24562));
          break;
        }
        default: heff_nomatch(v_it1_24550);
        }
        break;
      }
      default: heff_nomatch(v_w_24542);
      }
      V v_t_24564 = (g_std_2edoc_2e_3c_3e(v_t_24549, v_t_24563));
      v_d_24565 = (g_std_2edoc_2e_3c_3e(v_t_24548, v_t_24564));
      break;
    }
    default: heff_nomatch(v_bs_24541);
    }
    V v_t_24569 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_d_24565})})));
    V v_t_24570 = (g_std_2edoc_2e_3c_3e(v_a_24545, v_t_24569));
    V v_t_24571 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_d_24543));
    V v_d_24572 = ({ V a_0 = v_env_244; V a_1 = MK_INT(0LL); V a_2 = v_body_24544; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s2111199817x471344413(a_0, a_1, a_2)); heff_drop_rec(v_env_244, 7); heff_drop(v_body_24544); r_; });
    V v_t_24573 = (g_std_2edoc_2e_3c_3e(v_t_24571, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24572})));
    V v_t_24574 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_t_24573));
    V v_d_24575 = (g_std_2edoc_2e_3c_3e(v_t_24570, v_t_24574));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_d_24575})});
  }
  case TAG_EBinding: {
    V v_x_24579 = heff_field(v_e0_245, 0);
    V v_k_24580 = heff_field(v_e0_245, 1);
    V v_e_24581 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24582 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_244), v_x_24579));
    V v_b_24583 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_k_24580, v_e_24581}));
    V v_t_24584 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24583));
    V v_t_24585 = (g_std_2edoc_2e_3c_3e(v_a_24582, v_t_24584));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_t_24585});
  }
  case TAG_EBindingP: {
    V v_p_24586 = heff_field(v_e0_245, 0);
    V v_k_24587 = heff_field(v_e0_245, 1);
    V v_e_24588 = heff_field(v_e0_245, 2);
    heff_take_n(v_e0_245, 7ULL, 3);
    V v_a_24589 = ({ V a_0 = v_env_244; V a_1 = v_p_24586; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24586); r_; });
    V v_b_24590 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_244, v_k_24587, v_e_24588}));
    V v_t_24591 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), v_b_24590));
    V v_t_24592 = (g_std_2edoc_2e_3c_3e(v_a_24589, v_t_24591));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_t_24592});
  }
  default: return heff_nomatch(v_e0_245);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_env2_24606 = args[0];
  V v_e_24594 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_24607 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env2_24606, v_e_24594}));
  return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24607});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_env_24593 = args[0];
  V v_e_24594 = args[1];
  V v_t_24595 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24594));
  if ((heff_dup(v_t_24595) == NTAG(TAG_True))) {
    heff_drop(v_t_24595);
    V v_t_24596 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24594));
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_24596, 7)), heff_dup(heff_rfield(v_env_24593, 4)))) {
      heff_drop_rec(v_t_24596, 9);
      V v_t_24597 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24593, v_e_24594}));
      return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), v_t_24597));
    } else {
      HeffT2 v_t_24598 = ({ V a_0 = heff_rfield(v_env_24593, 1); V b_1 = heff_get_n(v_t_24596, 7, 9); HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_24600 = v_t_24598.f[1];
        int64_t v_tag_24599 = ((int64_t)v_t_24598.f[0]);
        if ((v_tag_24599 == ((int64_t)0ULL))) {
          V v_x_24601 = v_field_24600;
          switch (heff_tag_of(v_x_24601)) {
          case TAG_Nil: {
            V v_t_24602 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24593, v_e_24594}));
            return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), v_t_24602));
          }
          case TAG_Cons: {
            heff_take_n(v_x_24601, 0ULL, 2);
            V v_t_24605 = (g_heff_2esyntax_2ecst_2efirstE(v_e_24594));
            return (g_heff_2esyntax_2efmt_2elayout_2eleadOut(v_env_24593, v_t_24605, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_e_24594})));
          }
          default: return heff_nomatch(v_x_24601);
          }
        } else {
          heff_drop(v_field_24600);
          V v_t_24608 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24593, v_e_24594}));
          return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), v_t_24608));
        }
      }
    }
  } else {
    heff_drop(v_t_24595);
    switch (heff_tag_of(v_e_24594)) {
    case TAG_Ops: {
      V v_a_24609 = heff_dup(heff_field(v_e_24594, 0));
      V v_rest_24610 = heff_dup(heff_field(v_e_24594, 1));
      V v_e_24611 = heff_dup(v_e_24594);
      V v_t_24786;
      switch (heff_tag_of(v_e_24611)) {
      case TAG_Atom: {
        heff_take_n(v_e_24611, 0ULL, 1);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EParen: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Named: {
        heff_take_n(v_e_24611, 0ULL, 5);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Tup: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Seg: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Braces: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Update: {
        heff_take_n(v_e_24611, 0ULL, 6);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EUSet: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_InstB: {
        heff_take_n(v_e_24611, 0ULL, 5);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFSet: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFDefault: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Sum: {
        heff_take_n(v_e_24611, 0ULL, 5);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ECon: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EField: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ENeg: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ETilde: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_App: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Op: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Ops: {
        V v_rest_24671 = heff_field(v_e_24611, 1);
        heff_take_n(v_e_24611, 2ULL, 2);
        V v_x1_24672 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_24671));
        switch (heff_tag_of(v_x1_24672)) {
        case TAG_Nil: {
          v_t_24786 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_24673 = heff_field(v_x1_24672, 0);
          V v_rev_24674 = heff_field(v_x1_24672, 1);
          heff_take_n(v_x1_24672, 3ULL, 2);
          V v_t_24675 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24674));
          V v_init2_24676 = v_t_24675;
          V v_r_24677 = v_x_24673;
          V v_t_24678 = ({ V a_0 = v_r_24677; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eblockRhs(a_0)); heff_drop(v_r_24677); r_; });
          if ((heff_dup(v_t_24678) == NTAG(TAG_True))) {
            heff_drop(v_t_24678);
            v_t_24786 = heff_tag_n(TAG_Just, 1, (V[]){v_init2_24676});
          } else {
            heff_drop(v_init2_24676);
            heff_drop(v_t_24678);
            v_t_24786 = NTAG(TAG_Nothing);
          }
          break;
        }
        default: heff_nomatch(v_x1_24672);
        }
        break;
      }
      case TAG_OpRhs: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Ann: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_BVar: {
        heff_take_n(v_e_24611, 0ULL, 1);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_BImp: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_BAnn: {
        heff_take_n(v_e_24611, 0ULL, 5);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_BPat: {
        heff_take_n(v_e_24611, 0ULL, 1);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Lam: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Case: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EAlt: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_If: {
        heff_take_n(v_e_24611, 0ULL, 6);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Do: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ESBind: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_e_24611, 0ULL, 6);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELetElse: {
        heff_take_n(v_e_24611, 0ULL, 7);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ELetMut: {
        heff_take_n(v_e_24611, 0ULL, 6);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EAssign: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EWhile: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EFor: {
        heff_take_n(v_e_24611, 0ULL, 6);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EJump: {
        heff_take_n(v_e_24611, 0ULL, 1);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EReturn: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ENest: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EArrow: {
        heff_take_n(v_e_24611, 0ULL, 2);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_IfThen: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ETry: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_ECatch: {
        heff_take_n(v_e_24611, 0ULL, 4);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EWith: {
        heff_take_n(v_e_24611, 0ULL, 6);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EWithBound: {
        heff_take_n(v_e_24611, 0ULL, 5);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBinding: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_EBindingP: {
        heff_take_n(v_e_24611, 0ULL, 3);
        v_t_24786 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_24611);
      }
      switch (heff_tag_of(v_t_24786)) {
      case TAG_Nothing: {
        heff_drop(v_a_24609);
        heff_drop(v_rest_24610);
        V v_t_24787 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 2, (V[]){v_env_24593, v_e_24594}));
        V v_t_24788 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24787));
        return (g_std_2edoc_2egroup(v_t_24788));
      }
      case TAG_Just: {
        V v_init2_24789 = heff_field(v_t_24786, 0);
        V v_ru_24t_24786_24Just = heff_take_reuse_n(v_t_24786, 1ULL, 1);
        V v_t_24790 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 3, (V[]){heff_dup(v_env_24593), v_a_24609, v_init2_24789}));
        V v_a_24791 = (g_std_2edoc_2eflatten(v_t_24790));
        V v_x1_24792 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_24610));
        V v_t_24795;
        switch (heff_tag_of(v_x1_24792)) {
        case TAG_Nil: {
          v_t_24795 = heff_dup(v_e_24594);
          break;
        }
        case TAG_Cons: {
          V v_x_24793 = heff_field(v_x1_24792, 0);
          heff_take_n(v_x1_24792, 1ULL, 2);
          v_t_24795 = v_x_24793;
          break;
        }
        default: heff_nomatch(v_x1_24792);
        }
        V v_b_24796 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24593), v_t_24795}));
        V v_t_24797 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24786_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), v_b_24796));
        V v_t_24798 = (g_std_2edoc_2e_3c_3e(v_a_24791, v_t_24797));
        V v_t_24799 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_t_24798));
        V v_t_24800 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24593, v_e_24594}));
        V v_t_24801 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24800));
        return (g_std_2edoc_2e_3c_3e(heff_dup(g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get()), heff_tag_n(TAG_Union, 2, (V[]){v_t_24799, v_t_24801})));
      }
      default: return heff_nomatch(v_t_24786);
      }
    }
    default: {
      V v_t_24802 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 2, (V[]){v_env_24593, v_e_24594}));
      V v_t_24803 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24802));
      return (g_std_2edoc_2egroup(v_t_24803));
    }
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_env_24804 = args[0];
  V v_t_24805 = args[1];
  V v_e_24806 = args[2];
  if (!heff_intEq_c(heff_dup(heff_rfield(v_t_24805, 7)), heff_dup(heff_rfield(v_env_24804, 5)))) {
    HeffT2 v_t_24807 = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(heff_rfield(v_env_24804, 3), heff_rfield(v_t_24805, 7)));
    {
      V v_field_24809 = v_t_24807.f[1];
      int64_t v_tag_24808 = ((int64_t)v_t_24807.f[0]);
      if ((v_tag_24808 == ((int64_t)0ULL))) {
        V v_x_24810 = v_field_24809;
        heff_drop(v_x_24810);
        V v_env_24811 = heff_dup(v_env_24804);
        V v_t_24812 = v_t_24805;
        HeffT2 v_t_24813 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_24811, 3), heff_rfield(v_t_24812, 7)));
        {
          V v_field_24815 = v_t_24813.f[1];
          int64_t v_tag_24814 = ((int64_t)v_t_24813.f[0]);
          V v_t_24826;
          if ((v_tag_24814 == ((int64_t)0ULL))) {
            V v_c_24816 = v_field_24815;
            V v_t_24817 = ({ V rv_5 = heff_dup(heff_rfield(v_t_24812, 7)); V rr_ = heff_rec_reuse_nf(v_env_24811, 95ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 13311u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
            V v_t_24818 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_t_24817, v_t_24812));
            V v_x2_24819 = ({ V a_0 = v_c_24816; V a_1 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69), v_c_24816, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_c_24816); r_; });
            V v_s_24822;
            switch (heff_tag_of(v_x2_24819)) {
            case TAG_Nil: {
              v_s_24822 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70);
              break;
            }
            case TAG_Cons: {
              V v_x_24820 = heff_field(v_x2_24819, 0);
              V v_xs_24821 = heff_field(v_x2_24819, 1);
              heff_take_n(v_x2_24819, 3ULL, 2);
              v_s_24822 = ({ V b_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_24820; V a_2 = v_xs_24821; V r_ = (g_prelude_2ejoinWith_2eafter_240(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_xs_24821); r_; });
              break;
            }
            default: heff_nomatch(v_x2_24819);
            }
            V v_t_24823;
            if (heff_strEq_c_lent(v_s_24822, ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71), 2)) {
              heff_drop(v_s_24822);
              v_t_24823 = NTAG(TAG_None);
            } else {
              v_t_24823 = heff_tag_n(TAG_Text, 1, (V[]){v_s_24822});
            }
            V v_t_24824 = (g_std_2edoc_2e_3c_3e(v_t_24823, heff_dup(g_std_2edoc_2ehardline_get())));
            V v_t_24825 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_t_24824));
            v_t_24826 = (g_std_2edoc_2e_3c_3e(v_t_24818, v_t_24825));
          } else {
            heff_drop(v_field_24815);
            v_t_24826 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24811, v_t_24812));
          }
          V v_t_24827 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24806));
          V v_t_24829;
          if ((heff_dup(v_t_24827) == NTAG(TAG_True))) {
            heff_drop(v_t_24827);
            V v_d_24828 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24804, v_e_24806}));
            v_t_24829 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24828});
          } else {
            heff_drop(v_t_24827);
            v_t_24829 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 2, (V[]){v_env_24804, v_e_24806}));
          }
          return (g_std_2edoc_2e_3c_3e(v_t_24826, v_t_24829));
        }
      } else {
        heff_drop(v_field_24809);
        V v_t_24830 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24804), v_t_24805));
        V v_t_24831 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 2, (V[]){v_env_24804, v_e_24806}));
        return (g_std_2edoc_2e_3c_3e(v_t_24830, v_t_24831));
      }
    }
  } else {
    V v_t_24832 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24804), v_t_24805));
    V v_t_24833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 2, (V[]){v_env_24804, v_e_24806}));
    return (g_std_2edoc_2e_3c_3e(v_t_24832, v_t_24833));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_env_24834 = args[0];
  V v_kw_24835 = args[1];
  V v_p_24836 = args[2];
  V v_ann_24837 = args[3];
  V v_eq_24838 = args[4];
  V v_e_24839 = args[5];
  V v_a_24840 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24834), v_kw_24835));
  V v_b_24841 = ({ V a_0 = v_env_24834; V a_1 = v_p_24836; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24836); r_; });
  V v_t_24842 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24841));
  V v_t_24843 = (g_std_2edoc_2e_3c_3e(v_a_24840, v_t_24842));
  V v_a_24851;
  switch (heff_tag_of(v_ann_24837)) {
  case TAG_Nothing: {
    v_a_24851 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24844 = heff_field(v_ann_24837, 0);
    V v_ru_24ann_24837_24Just = heff_take_reuse_n(v_ann_24837, 1ULL, 1);
    switch (heff_tag_of(v_it1_24844)) {
    case TAG_MkPair: {
      V v_cc_24845 = heff_field(v_it1_24844, 0);
      V v_ty_24846 = heff_field(v_it1_24844, 1);
      V v_ru_24it1_24844_24MkPair = heff_take_reuse_n(v_it1_24844, 3ULL, 2);
      V v_a_24847 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24834), v_cc_24845));
      V v_b_24848 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24834), v_ty_24846}));
      V v_t_24849 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24it1_24844_24MkPair, heff_tag_at_n(v_ru_24ann_24837_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24848));
      V v_t_24850 = (g_std_2edoc_2e_3c_3e(v_a_24847, v_t_24849));
      v_a_24851 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_t_24850));
      break;
    }
    default: heff_nomatch(v_it1_24844);
    }
    break;
  }
  default: heff_nomatch(v_ann_24837);
  }
  V v_b_24852 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_24834, v_eq_24838, v_e_24839}));
  V v_t_24853 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_24852));
  V v_t_24854 = (g_std_2edoc_2e_3c_3e(v_a_24851, v_t_24853));
  return (g_std_2edoc_2e_3c_3e(v_t_24843, v_t_24854));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_env_24855 = args[0];
  V v_kw_24856 = args[1];
  V v_p_24857 = args[2];
  V v_ann_24858 = args[3];
  V v_eq_24859 = args[4];
  V v_e_24860 = args[5];
  V v_i_24861 = args[6];
  V v_b_24862 = args[7];
  V v_d_24863 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 6, (V[]){heff_dup(v_env_24855), v_kw_24856, v_p_24857, v_ann_24858, v_eq_24859, v_e_24860}));
  V v_t_24864 = heff_dup(heff_rfield(v_i_24861, 6));
  V v_t_24867;
  if ((heff_dup(v_t_24864) == NTAG(TAG_True))) {
    heff_drop(v_t_24864);
    v_t_24867 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24864);
    V v_t_24865 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24862));
    V v_x1_24866 = heff_get_n(v_t_24865, 6, 9);
    if ((heff_dup(v_x1_24866) == NTAG(TAG_True))) {
      heff_drop(v_x1_24866);
      v_t_24867 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24866);
      v_t_24867 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24868 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24855), v_i_24861));
  V v_b_24884;
  switch (heff_tag_of(v_b_24862)) {
  case TAG_ELet: {
    V v_it6_24874 = heff_dup(heff_field(v_b_24862, 5));
    switch (heff_tag_of(v_it6_24874)) {
    case TAG_Nothing: {
      v_b_24884 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24855, v_b_24862}));
      break;
    }
    case TAG_Just: {
      V v_it61_24875 = heff_field(v_it6_24874, 0);
      heff_take_n(v_it6_24874, 1ULL, 1);
      switch (heff_tag_of(v_b_24862)) {
      case TAG_ELet: {
        V v_kw2_24876 = heff_field(v_b_24862, 0);
        V v_p2_24877 = heff_field(v_b_24862, 1);
        V v_ann2_24878 = heff_field(v_b_24862, 2);
        V v_eq2_24879 = heff_field(v_b_24862, 3);
        V v_e2_24880 = heff_field(v_b_24862, 4);
        heff_take_n(v_b_24862, 31ULL, 6);
        switch (heff_tag_of(v_it61_24875)) {
        case TAG_MkPair: {
          V v_i2_24882 = heff_field(v_it61_24875, 0);
          V v_b2_24883 = heff_field(v_it61_24875, 1);
          heff_take_n(v_it61_24875, 3ULL, 2);
          v_b_24884 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 8, (V[]){v_env_24855, v_kw2_24876, v_p2_24877, v_ann2_24878, v_eq2_24879, v_e2_24880, v_i2_24882, v_b2_24883}));
          break;
        }
        default: heff_nomatch(v_it61_24875);
        }
        break;
      }
      default: heff_nomatch(v_b_24862);
      }
      break;
    }
    default: heff_nomatch(v_it6_24874);
    }
    break;
  }
  default: {
    v_b_24884 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24855, v_b_24862}));
    break;
  }
  }
  V v_t_24885 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_24884));
  V v_t_24886 = (g_std_2edoc_2e_3c_3e(v_a_24868, v_t_24885));
  V v_t_24887 = (g_std_2edoc_2e_3c_3e(v_t_24867, v_t_24886));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24863}), v_t_24887));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_i_24896 = args[0];
  V v_k_24895 = heff_env(self)[0];
  V v_d_24894 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24897 = heff_intSub(v_k_24895, v_i_24896);
  if (heff_intEq_c_lent(v_i_24897, MK_INT(0LL), 2)) {
    heff_drop(v_i_24897);
    return v_d_24894;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24897, v_d_24894});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_k_24895 = args[0];
  V v_d_24894 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 2, (V[]){v_k_24895, v_d_24894})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_env_24888 = args[0];
  V v_kw_24889 = args[1];
  V v_c_24890 = args[2];
  V v_th_24891 = args[3];
  V v_a_24892 = args[4];
  V v_a_24893 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24888), v_kw_24889));
  V v_d_24894 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24888), v_c_24890}));
  V v_t_24898 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_d_24894})})));
  V v_t_24899 = (g_std_2edoc_2e_3c_3e(v_a_24893, v_t_24898));
  V v_t_24900 = heff_dup(heff_rfield(v_th_24891, 6));
  V v_t_24903;
  if ((heff_dup(v_t_24900) == NTAG(TAG_True))) {
    heff_drop(v_t_24900);
    v_t_24903 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24900);
    V v_t_24901 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24892));
    V v_x1_24902 = heff_get_n(v_t_24901, 6, 9);
    if ((heff_dup(v_x1_24902) == NTAG(TAG_True))) {
      heff_drop(v_x1_24902);
      v_t_24903 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24902);
      v_t_24903 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24904 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24888), v_th_24891));
  V v_d_24905 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24888, v_a_24892}));
  V v_t_24906 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24905})));
  V v_t_24907 = (g_std_2edoc_2e_3c_3e(v_a_24904, v_t_24906));
  V v_t_24908 = (g_std_2edoc_2e_3c_3e(v_t_24903, v_t_24907));
  V v_t_24909 = (g_std_2edoc_2e_3c_3e(v_t_24899, v_t_24908));
  return (g_std_2edoc_2egroup(v_t_24909));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_env_24910 = args[0];
  V v_el_24911 = args[1];
  V v_b_24912 = args[2];
  switch (heff_tag_of(v_b_24912)) {
  case TAG_If: {
    V v_kw_24913 = heff_dup(heff_field(v_b_24912, 0));
    V v_c_24914 = heff_dup(heff_field(v_b_24912, 1));
    V v_th_24915 = heff_dup(heff_field(v_b_24912, 2));
    V v_a_24916 = heff_dup(heff_field(v_b_24912, 3));
    V v_el2_24917 = heff_dup(heff_field(v_b_24912, 4));
    V v_b2_24918 = heff_dup(heff_field(v_b_24912, 5));
    V v_t_24919 = heff_dup(heff_rfield(v_el_24911, 6));
    V v_t_24922;
    if ((heff_dup(v_t_24919) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24912, 6);
      heff_drop(v_t_24919);
      v_t_24922 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24919);
      V v_t_24920 = ({ V a_0 = v_b_24912; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24912, 6); r_; });
      V v_x1_24921 = heff_get_n(v_t_24920, 6, 9);
      if ((heff_dup(v_x1_24921) == NTAG(TAG_True))) {
        heff_drop(v_x1_24921);
        v_t_24922 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24921);
        v_t_24922 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24923 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24910), v_el_24911));
    V v_b_24924 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6)), 5, (V[]){heff_dup(v_env_24910), v_kw_24913, v_c_24914, v_th_24915, v_a_24916}));
    V v_t_24925 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_24924));
    V v_t_24926 = (g_std_2edoc_2e_3c_3e(v_a_24923, v_t_24925));
    V v_t_24927 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_24910, v_el2_24917, v_b2_24918}));
    V v_t_24928 = (g_std_2edoc_2e_3c_3e(v_t_24926, v_t_24927));
    return (g_std_2edoc_2e_3c_3e(v_t_24922, v_t_24928));
  }
  default: {
    V v_t_24929 = heff_dup(heff_rfield(v_el_24911, 6));
    V v_t_24932;
    if ((heff_dup(v_t_24929) == NTAG(TAG_True))) {
      heff_drop(v_t_24929);
      v_t_24932 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24929);
      V v_t_24930 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24912));
      V v_x1_24931 = heff_get_n(v_t_24930, 6, 9);
      if ((heff_dup(v_x1_24931) == NTAG(TAG_True))) {
        heff_drop(v_x1_24931);
        v_t_24932 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24931);
        v_t_24932 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24933 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24910), v_el_24911));
    V v_d_24934 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24910, v_b_24912}));
    V v_t_24935 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24934})));
    V v_t_24936 = (g_std_2edoc_2e_3c_3e(v_a_24933, v_t_24935));
    return (g_std_2edoc_2e_3c_3e(v_t_24932, v_t_24936));
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_24958 = args[0];
  V v_one_24957 = heff_env(self)[0];
  V v_t_24959 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24958));
  V v_x1_24960 = heff_get_n(v_t_24959, 6, 9);
  V v_t_24961;
  if ((heff_dup(v_x1_24960) == NTAG(TAG_True))) {
    heff_drop(v_x1_24960);
    v_t_24961 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24960);
    v_t_24961 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_24962 = heff_tr(heff_call(v_one_24957, 1, (V[]){v_a_24958}));
  return (g_std_2edoc_2e_3c_3e(v_t_24961, v_t_24962));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_24971 = args[0];
  V v_one_24970 = heff_env(self)[0];
  V v_t_24972 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24971));
  V v_x1_24973 = heff_get_n(v_t_24972, 6, 9);
  V v_t_24974;
  if ((heff_dup(v_x1_24973) == NTAG(TAG_True))) {
    heff_drop(v_x1_24973);
    v_t_24974 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24973);
    v_t_24974 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_24975 = heff_tr(heff_call(v_one_24970, 1, (V[]){v_a_24971}));
  return (g_std_2edoc_2e_3c_3e(v_t_24974, v_t_24975));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_env_24937 = args[0];
  V v_hang_24938 = args[1];
  V v_h_24939 = args[2];
  V v_args_24940 = args[3];
  V v_x1_24941 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24940)));
  switch (heff_tag_of(v_x1_24941)) {
  case TAG_Nil: {
    heff_drop(v_hang_24938);
    heff_drop(v_args_24940);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24937;
    args[1] = v_h_24939;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_24942 = heff_field(v_x1_24941, 0);
    V v_rev_24943 = heff_field(v_x1_24941, 1);
    V v_ru_24x1_24941_24Cons = heff_take_reuse_n(v_x1_24941, 3ULL, 2);
    V v_init2_24944 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24943));
    switch (heff_tag_of(v_x_24942)) {
    case TAG_EParen: {
      V v_o_24945 = heff_field(v_x_24942, 0);
      V v_e_24946 = heff_field(v_x_24942, 1);
      V v_c_24947 = heff_field(v_x_24942, 2);
      heff_take_n(v_x_24942, 7ULL, 3);
      V v_t_24948 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24946));
      if ((heff_dup(v_t_24948) == NTAG(TAG_True))) {
        heff_drop(v_args_24940);
        heff_drop(v_t_24948);
        V v_t_24949 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24937), v_h_24939}));
        V v_t_24950 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24937)}));
        V v_t_24951 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24937), v_o_24945));
        V v_t_24952 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24937), v_e_24946}));
        V v_t_24953 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24937, v_c_24947));
        V v_t_24954 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x1_24941_24Cons, v_t_24952, v_t_24953));
        V v_t_24955 = (g_std_2edoc_2e_3c_3e(v_t_24951, v_t_24954));
        return (g_heff_2esyntax_2efmt_2elayout_2eblockLast(v_hang_24938, v_t_24949, v_t_24950, v_init2_24944, v_t_24955));
      } else {
        heff_drop(v_hang_24938);
        heff_drop(v_init2_24944);
        heff_drop(v_o_24945);
        heff_drop(v_e_24946);
        heff_drop(v_c_24947);
        heff_drop(v_t_24948);
        V v_t_24956 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24937), v_h_24939}));
        V v_one_24957 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24937}));
        V v_d_24963 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_24957}); V a_2 = v_args_24940; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_args_24940); r_; });
        V v_t_24964 = (g_std_2edoc_2e_3c_3e(v_t_24956, heff_tag_at_n(v_ru_24x1_24941_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24963})));
        return (g_std_2edoc_2egroup(v_t_24964));
      }
    }
    default: {
      V v_t_24965 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_24942));
      if ((heff_dup(v_t_24965) == NTAG(TAG_True))) {
        heff_drop(v_args_24940);
        heff_drop_cell(v_ru_24x1_24941_24Cons, 2);
        heff_drop(v_t_24965);
        V v_t_24966 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24937), v_h_24939}));
        V v_t_24967 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24937)}));
        V v_t_24968 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24937, v_x_24942}));
        return (g_heff_2esyntax_2efmt_2elayout_2eblockLast(v_hang_24938, v_t_24966, v_t_24967, v_init2_24944, v_t_24968));
      } else {
        heff_drop(v_hang_24938);
        heff_drop(v_x_24942);
        heff_drop(v_init2_24944);
        heff_drop(v_t_24965);
        V v_t_24969 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24937), v_h_24939}));
        V v_one_24970 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24937}));
        V v_d_24976 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_24970}); V a_2 = v_args_24940; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_args_24940); r_; });
        V v_t_24977 = (g_std_2edoc_2e_3c_3e(v_t_24969, heff_tag_at_n(v_ru_24x1_24941_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24976})));
        return (g_std_2edoc_2egroup(v_t_24977));
      }
    }
    }
  }
  default: return heff_nomatch(v_x1_24941);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_env_24978 = args[0];
  V v_e_24979 = args[1];
  switch (heff_tag_of(v_e_24979)) {
  case TAG_App: {
    V v_h_24980 = heff_dup(heff_field(v_e_24979, 0));
    V v_args_24981 = heff_dup(heff_field(v_e_24979, 1));
    V v_t_24982 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_24979));
    if ((heff_dup(v_t_24982) == NTAG(TAG_True))) {
      heff_drop_tag(v_e_24979, 2);
      heff_drop(v_t_24982);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8));
      heff_room[0] = v_env_24978;
      heff_room[1] = MK_INT(2LL);
      heff_room[2] = v_h_24980;
      heff_room[3] = v_args_24981;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    } else {
      heff_drop(v_h_24980);
      heff_drop(v_args_24981);
      heff_drop(v_t_24982);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_24978;
      args[1] = v_e_24979;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24978;
    args[1] = v_e_24979;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_env_24983 = args[0];
  V v_rest_24984 = args[1];
  V v_e_24985 = args[2];
  switch (heff_tag_of(v_e_24985)) {
  case TAG_Braces: {
    V v_o_24986 = heff_field(v_e_24985, 0);
    V v_fs_24987 = heff_field(v_e_24985, 1);
    V v_commas_24988 = heff_field(v_e_24985, 2);
    V v_c_24989 = heff_field(v_e_24985, 3);
    heff_take_n(v_e_24985, 15ULL, 4);
    switch (heff_tag_of(v_fs_24987)) {
    case TAG_Nil: {
      heff_drop(v_rest_24984);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_24983;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24986, v_fs_24987, v_commas_24988, v_c_24989});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_24990 = heff_dup(heff_field(v_fs_24987, 0));
      V v_rest2_24991 = heff_dup(heff_field(v_fs_24987, 1));
      switch (heff_tag_of(v_rest2_24991)) {
      case TAG_Nil: {
        V v_t_24992 = ({ V a_0 = v_rest_24984; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_24984); r_; });
        if ((heff_dup(v_t_24992) == NTAG(TAG_True))) {
          heff_drop(v_t_24992);
          V v_x1_24993 = heff_dup(v_d_24990);
          V v_x1_241161;
          switch (heff_tag_of(v_x1_24993)) {
          case TAG_Atom: {
            heff_take_n(v_x1_24993, 0ULL, 1);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EParen: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Named: {
            heff_take_n(v_x1_24993, 0ULL, 5);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Tup: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Seg: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Braces: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Update: {
            heff_take_n(v_x1_24993, 0ULL, 6);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EUSet: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_InstB: {
            heff_take_n(v_x1_24993, 0ULL, 5);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EFSet: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_True);
            break;
          }
          case TAG_EFDefault: {
            V v_eq_241032 = heff_field(v_x1_24993, 1);
            heff_take_n(v_x1_24993, 2ULL, 3);
            v_x1_241161 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_eq_241032, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)));
            heff_drop_rec(v_eq_241032, 9);
            break;
          }
          case TAG_Sum: {
            heff_take_n(v_x1_24993, 0ULL, 5);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ECon: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EField: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ENeg: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ETilde: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_App: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Op: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Ops: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_OpRhs: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Ann: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_BVar: {
            heff_take_n(v_x1_24993, 0ULL, 1);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_BImp: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_BAnn: {
            heff_take_n(v_x1_24993, 0ULL, 5);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_BPat: {
            heff_take_n(v_x1_24993, 0ULL, 1);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Lam: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Case: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EAlt: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_If: {
            heff_take_n(v_x1_24993, 0ULL, 6);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_Do: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ESBind: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ELet: {
            heff_take_n(v_x1_24993, 0ULL, 6);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ELetElse: {
            heff_take_n(v_x1_24993, 0ULL, 7);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ELetMut: {
            heff_take_n(v_x1_24993, 0ULL, 6);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EAssign: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EWhile: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EFor: {
            heff_take_n(v_x1_24993, 0ULL, 6);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EJump: {
            heff_take_n(v_x1_24993, 0ULL, 1);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EReturn: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ENest: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EArrow: {
            heff_take_n(v_x1_24993, 0ULL, 2);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_IfThen: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ETry: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_ECatch: {
            heff_take_n(v_x1_24993, 0ULL, 4);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EWith: {
            heff_take_n(v_x1_24993, 0ULL, 6);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EWithBound: {
            heff_take_n(v_x1_24993, 0ULL, 5);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EBinding: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          case TAG_EBindingP: {
            heff_take_n(v_x1_24993, 0ULL, 3);
            v_x1_241161 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x1_24993);
          }
          if (!(heff_dup(v_x1_241161) == NTAG(TAG_True))) {
            heff_drop(v_x1_241161);
            switch (heff_tag_of(v_commas_24988)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_24987, 2);
              V v_t_241162 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24983), v_o_24986));
              V v_t_241163 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24983), v_d_24990}));
              V v_t_241164 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24983, v_c_24989));
              V v_t_241165 = (g_std_2edoc_2e_3c_3e(v_t_241163, v_t_241164));
              return (g_std_2edoc_2e_3c_3e(v_t_241162, v_t_241165));
            }
            case TAG_Cons: {
              heff_drop(v_d_24990);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_24983;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24986, v_fs_24987, v_commas_24988, v_c_24989});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_24988);
            }
          } else {
            heff_drop(v_d_24990);
            heff_drop(v_x1_241161);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_24983;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24986, v_fs_24987, v_commas_24988, v_c_24989});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
        } else {
          heff_drop(v_d_24990);
          heff_drop(v_t_24992);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_24983;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24986, v_fs_24987, v_commas_24988, v_c_24989});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_24991, 0ULL, 2);
        heff_drop(v_rest_24984);
        heff_drop(v_d_24990);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_24983;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_24986, v_fs_24987, v_commas_24988, v_c_24989});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_24991);
      }
    }
    default: return heff_nomatch(v_fs_24987);
    }
  }
  default: {
    heff_drop(v_rest_24984);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24983;
    args[1] = v_e_24985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_env_241170 = args[0];
  V v_b_241171 = args[1];
  switch (heff_tag_of(v_b_241171)) {
  case TAG_BVar: {
    V v_t_241172 = heff_field(v_b_241171, 0);
    V v_ru_24b_241171_24BVar = heff_take_reuse_n(v_b_241171, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok_24tok1(v_ru_24b_241171_24BVar, v_env_241170, v_t_241172));
  }
  case TAG_BImp: {
    V v_o_241173 = heff_field(v_b_241171, 0);
    V v_x_241174 = heff_field(v_b_241171, 1);
    V v_c_241175 = heff_field(v_b_241171, 2);
    heff_take_n(v_b_241171, 7ULL, 3);
    V v_t_241176 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241170), v_o_241173));
    V v_t_241177 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241170), v_x_241174));
    V v_t_241178 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241170, v_c_241175));
    V v_t_241179 = (g_std_2edoc_2e_3c_3e(v_t_241177, v_t_241178));
    return (g_std_2edoc_2e_3c_3e(v_t_241176, v_t_241179));
  }
  case TAG_BAnn: {
    V v_o_241180 = heff_field(v_b_241171, 0);
    V v_x_241181 = heff_field(v_b_241171, 1);
    V v_cc_241182 = heff_field(v_b_241171, 2);
    V v_ty_241183 = heff_field(v_b_241171, 3);
    V v_c_241184 = heff_field(v_b_241171, 4);
    heff_take_n(v_b_241171, 31ULL, 5);
    V v_t_241185 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241170), v_o_241180));
    V v_a_241186 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241170), v_x_241181));
    V v_a_241187 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241170), v_cc_241182));
    V v_b_241188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241170), v_ty_241183}));
    V v_t_241189 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_241188));
    V v_t_241190 = (g_std_2edoc_2e_3c_3e(v_a_241187, v_t_241189));
    V v_t_241191 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), v_t_241190));
    V v_t_241192 = (g_std_2edoc_2e_3c_3e(v_a_241186, v_t_241191));
    V v_t_241193 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241170, v_c_241184));
    V v_t_241194 = (g_std_2edoc_2e_3c_3e(v_t_241192, v_t_241193));
    return (g_std_2edoc_2e_3c_3e(v_t_241185, v_t_241194));
  }
  case TAG_BPat: {
    V v_p_241195 = heff_field(v_b_241171, 0);
    heff_take_n(v_b_241171, 1ULL, 1);
    return ({ V a_0 = v_env_241170; V a_1 = v_p_241195; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_env_241170); heff_drop(v_p_241195); r_; });
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241170;
    args[1] = v_b_241171;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_env_241196 = args[0];
  V v_rest_241197 = args[1];
  V v_r_241198 = args[2];
  switch (heff_tag_of(v_r_241198)) {
  case TAG_OpRhs: {
    V v_op_241199 = heff_field(v_r_241198, 0);
    V v_e_241200 = heff_field(v_r_241198, 1);
    V v_ru_24r_241198_24OpRhs = heff_take_reuse_n(v_r_241198, 3ULL, 2);
    V v_a_241201 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241196), v_op_241199));
    V v_b_241202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 3, (V[]){v_env_241196, v_rest_241197, v_e_241200}));
    V v_t_241203 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24r_241198_24OpRhs, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), v_b_241202));
    return (g_std_2edoc_2e_3c_3e(v_a_241201, v_t_241203));
  }
  default: {
    heff_drop(v_rest_241197);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241196;
    args[1] = v_r_241198;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_env_241204 = args[0];
  V v_r_241205 = args[1];
  switch (heff_tag_of(v_r_241205)) {
  case TAG_OpRhs: {
    V v_op_241206 = heff_field(v_r_241205, 0);
    V v_e_241207 = heff_field(v_r_241205, 1);
    V v_ru_24r_241205_24OpRhs = heff_take_reuse_n(v_r_241205, 3ULL, 2);
    V v_a_241208 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241204), v_op_241206));
    V v_t_241209 = (g_heff_2esyntax_2efmt_2elayout_2eblockOperand(v_e_241207));
    V v_b_241211;
    if ((heff_dup(v_t_241209) == NTAG(TAG_True))) {
      heff_drop(v_t_241209);
      V v_d_241210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241204, v_e_241207}));
      v_b_241211 = heff_tag_at_n(v_ru_24r_241205_24OpRhs, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241210});
    } else {
      heff_drop_cell(v_ru_24r_241205_24OpRhs, 2);
      heff_drop(v_t_241209);
      v_b_241211 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241204, v_e_241207}));
    }
    V v_t_241212 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241211));
    return (g_std_2edoc_2e_3c_3e(v_a_241208, v_t_241212));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241204;
    args[1] = v_r_241205;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_r_241225 = args[0];
  V v_env_241213 = heff_env(self)[0];
  V v_x1_241226 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_241225));
  V v_t_241227;
  if ((heff_dup(v_x1_241226) == NTAG(TAG_True))) {
    heff_drop(v_x1_241226);
    v_t_241227 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241226);
    v_t_241227 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_241228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 2, (V[]){v_env_241213, v_r_241225}));
  return (g_std_2edoc_2e_3c_3e(v_t_241227, v_t_241228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_r_241234 = args[0];
  V v_env_241213 = heff_env(self)[0];
  V v_x1_241235 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_241234));
  V v_t_241236;
  if ((heff_dup(v_x1_241235) == NTAG(TAG_True))) {
    heff_drop(v_x1_241235);
    v_t_241236 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241235);
    v_t_241236 = heff_dup(g_std_2edoc_2eline_get());
  }
  heff_clo_take(self, 1);
  V v_t_241237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 2, (V[]){v_env_241213, v_r_241234}));
  return (g_std_2edoc_2e_3c_3e(v_t_241236, v_t_241237));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_env_241213 = args[0];
  V v_first_241214 = args[1];
  V v_rest_241215 = args[2];
  V v_f_241216 = heff_dup(heff_rfield(v_env_241213, 6));
  HeffT2 v_t_241217 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(v_f_241216, heff_dup(v_rest_241215)));
  {
    V v_field_241219 = v_t_241217.f[1];
    int64_t v_tag_241218 = ((int64_t)v_t_241217.f[0]);
    V v_t_241223;
    if ((v_tag_241218 == ((int64_t)0ULL))) {
      V v_it1_241220 = v_field_241219;
      switch (heff_tag_of(v_it1_241220)) {
      case TAG_Nil: {
        heff_drop(v_f_241216);
        v_t_241223 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_241221 = heff_field(v_it1_241220, 0);
        V v_os_241222 = heff_field(v_it1_241220, 1);
        heff_take_n(v_it1_241220, 3ULL, 2);
        v_t_241223 = ({ V a_0 = v_f_241216; V a_1 = v_o_241221; V a_2 = v_os_241222; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_f_241216); heff_drop(v_o_241221); heff_drop(v_os_241222); r_; });
        break;
      }
      default: heff_nomatch(v_it1_241220);
      }
    } else {
      heff_drop(v_f_241216);
      heff_drop(v_field_241219);
      v_t_241223 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_241223)) {
    case TAG_Nothing: {
      V v_t_241224 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241213), v_first_241214}));
      V v_t_241229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_env_241213}); V a_2 = v_rest_241215; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_rest_241215); r_; });
      V v_t_241230 = (g_std_2edoc_2e_3c_3e(v_t_241224, v_t_241229));
      return (g_std_2edoc_2egroup(v_t_241230));
    }
    case TAG_Just: {
      V v_m_241231 = heff_field(v_t_241223, 0);
      heff_take_n(v_t_241223, 1ULL, 1);
      V v_t_241232 = (g_list_2eall_24s78096928x1476871221(heff_rfield(v_env_241213, 6), v_m_241231, v_rest_241215));
      if ((heff_dup(v_t_241232) == NTAG(TAG_True))) {
        heff_drop(v_m_241231);
        heff_drop(v_t_241232);
        V v_t_241233 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241213), v_first_241214}));
        V v_t_241238 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_env_241213}); V a_2 = v_rest_241215; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_rest_241215); r_; });
        V v_t_241239 = (g_std_2edoc_2e_3c_3e(v_t_241233, v_t_241238));
        return (g_std_2edoc_2egroup(v_t_241239));
      } else {
        heff_drop(v_t_241232);
        V v_t_241240 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17)), 6, (V[]){v_env_241213, v_m_241231, NTAG(TAG_False), v_first_241214, NTAG(TAG_Nil), v_rest_241215}));
        return (g_std_2edoc_2egroup(v_t_241240));
      }
    }
    default: return heff_nomatch(v_t_241223);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_i_241262 = args[0];
  V v_k_241261 = heff_env(self)[0];
  V v_d_241259 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_241263 = heff_intSub(v_k_241261, v_i_241262);
  if (heff_intEq_c_lent(v_i_241263, MK_INT(0LL), 2)) {
    heff_drop(v_i_241263);
    return v_d_241259;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_241263, v_d_241259});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_k_241261 = args[0];
  V v_d_241259 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 2, (V[]){v_k_241261, v_d_241259})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_env_241241 = args[0];
  V v_first_241242 = args[1];
  V v_rest_241243 = args[2];
  V v_x1_241244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_rest_241243)));
  switch (heff_tag_of(v_x1_241244)) {
  case TAG_Nil: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
    args[0] = v_env_241241;
    args[1] = v_first_241242;
    args[2] = v_rest_241243;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_x_241245 = heff_field(v_x1_241244, 0);
    V v_rev_241246 = heff_field(v_x1_241244, 1);
    V v_ru_24x1_241244_24Cons = heff_take_reuse_n(v_x1_241244, 3ULL, 2);
    V v_t_241247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241246));
    V v_init2_241248 = v_t_241247;
    V v_r_241249 = v_x_241245;
    V v_t_241250 = ({ V a_0 = v_r_241249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eblockRhs(a_0)); heff_drop(v_r_241249); r_; });
    if ((heff_dup(v_t_241250) == NTAG(TAG_True))) {
      heff_drop(v_t_241250);
      V v_t_241251 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 3, (V[]){heff_dup(v_env_241241), heff_dup(v_first_241242), v_init2_241248}));
      V v_a_241252 = (g_std_2edoc_2eflatten(v_t_241251));
      V v_x1_241253 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_rest_241243)));
      V v_t_241256;
      switch (heff_tag_of(v_x1_241253)) {
      case TAG_Nil: {
        v_t_241256 = heff_dup(v_first_241242);
        break;
      }
      case TAG_Cons: {
        V v_x_241254 = heff_field(v_x1_241253, 0);
        heff_take_n(v_x1_241253, 1ULL, 2);
        v_t_241256 = v_x_241254;
        break;
      }
      default: heff_nomatch(v_x1_241253);
      }
      V v_b_241257 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13)), 2, (V[]){heff_dup(v_env_241241), v_t_241256}));
      V v_t_241258 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), v_b_241257));
      V v_d_241259 = (g_std_2edoc_2e_3c_3e(v_a_241252, v_t_241258));
      V v_t_241260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 3, (V[]){v_env_241241, v_first_241242, v_rest_241243}));
      V v_t_241264 = heff_tag_at_n(v_ru_24x1_241244_24Cons, TAG_Union, 2, (V[]){heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_d_241259})}), v_t_241260});
      return (g_std_2edoc_2e_3c_3e(heff_dup(g_heff_2esyntax_2efmt_2elayout_2ebreaksGroup_get()), v_t_241264));
    } else {
      heff_drop_cell(v_ru_24x1_241244_24Cons, 2);
      heff_drop(v_init2_241248);
      heff_drop(v_t_241250);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14));
      args[0] = v_env_241241;
      args[1] = v_first_241242;
      args[2] = v_rest_241243;
      if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 3, args);
    }
  }
  default: return heff_nomatch(v_x1_241244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_i_241275 = args[0];
  V v_k_241274 = heff_env(self)[0];
  V v_d_241273 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_241276 = heff_intSub(v_k_241274, v_i_241275);
  if (heff_intEq_c_lent(v_i_241276, MK_INT(0LL), 2)) {
    heff_drop(v_i_241276);
    return v_d_241273;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_241276, v_d_241273});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_k_241274 = args[0];
  V v_d_241273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 2, (V[]){v_k_241274, v_d_241273})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_env_241265 = args[0];
  V v_inner_241266 = args[1];
  V v_f_241267 = args[2];
  V v_acc_241268 = args[3];
  if (!(heff_dup(v_inner_241266) == NTAG(TAG_True))) {
    heff_drop(v_inner_241266);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15));
    args[0] = v_env_241265;
    args[1] = v_f_241267;
    args[2] = v_acc_241268;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  } else {
    heff_drop(v_inner_241266);
    switch (heff_tag_of(v_acc_241268)) {
    case TAG_Nil: {
      V v_t_241269 = (g_heff_2esyntax_2efmt_2elayout_2eblockOperand(v_f_241267));
      if ((heff_dup(v_t_241269) == NTAG(TAG_True))) {
        heff_drop(v_t_241269);
        V v_d_241270 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241265, v_f_241267}));
        return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241270});
      } else {
        heff_drop(v_t_241269);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_241265;
        args[1] = v_f_241267;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
    }
    case TAG_Cons: {
      V v_d_241273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 3, (V[]){v_env_241265, v_f_241267, v_acc_241268}));
      return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_d_241273})});
    }
    default: return heff_nomatch(v_acc_241268);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_env_241277 = args[0];
  V v_m_241278 = args[1];
  V v_inner_241279 = args[2];
  V v_f_241280 = args[3];
  V v_acc_241281 = args[4];
  V v_rs_241282 = args[5];
  switch (heff_tag_of(v_rs_241282)) {
  case TAG_Nil: {
    heff_drop(v_m_241278);
    V v_t_241283 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241281));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16));
    args[0] = v_env_241277;
    args[1] = v_inner_241279;
    args[2] = v_f_241280;
    args[3] = v_t_241283;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Cons: {
    V v_r_241284 = heff_field(v_rs_241282, 0);
    V v_rest2_241285 = heff_field(v_rs_241282, 1);
    V v_ru_24rs_241282_24Cons = heff_take_reuse_n(v_rs_241282, 3ULL, 2);
    switch (heff_tag_of(v_r_241284)) {
    case TAG_OpRhs: {
      V v_op_241286 = heff_dup(heff_field(v_r_241284, 0));
      V v_e_241287 = heff_dup(heff_field(v_r_241284, 1));
      V v_t_241288 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_241277, 6)), heff_dup(v_m_241278), heff_dup(heff_rfield(v_op_241286, 1))));
      switch (heff_tag_of(v_t_241288)) {
      case TAG_Tighter: {
        heff_drop_cell(v_ru_24rs_241282_24Cons, 2);
        heff_drop_rec(v_op_241286, 9);
        heff_drop(v_e_241287);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17));
        args[0] = v_env_241277;
        args[1] = v_m_241278;
        args[2] = v_inner_241279;
        args[3] = v_f_241280;
        args[4] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241284, v_acc_241281});
        args[5] = v_rest2_241285;
        if (heff_exact(f_, 6, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 6, args);
      }
      case TAG_Looser: {
        heff_drop_cell(v_ru_24rs_241282_24Cons, 2);
        heff_drop_rec(v_op_241286, 9);
        heff_drop(v_e_241287);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17));
        args[0] = v_env_241277;
        args[1] = v_m_241278;
        args[2] = v_inner_241279;
        args[3] = v_f_241280;
        args[4] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241284, v_acc_241281});
        args[5] = v_rest2_241285;
        if (heff_exact(f_, 6, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 6, args);
      }
      case TAG_Same: {
        V v_ru_24t_241288_24Same = heff_take_reuse_n(v_t_241288, 0ULL, 1);
        V v_t_241290 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241281));
        V v_t_241291 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 16)), 4, (V[]){heff_dup(v_env_241277), v_inner_241279, v_f_241280, v_t_241290}));
        V v_x1_241292 = ({ V a_0 = v_r_241284; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_241284, 2); r_; });
        V v_t_241293;
        if ((heff_dup(v_x1_241292) == NTAG(TAG_True))) {
          heff_drop(v_x1_241292);
          v_t_241293 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_241292);
          v_t_241293 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_241294 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241277), v_op_241286));
        V v_b_241295 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17)), 6, (V[]){v_env_241277, v_m_241278, NTAG(TAG_True), v_e_241287, NTAG(TAG_Nil), v_rest2_241285}));
        V v_t_241296 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24rs_241282_24Cons, heff_tag_at_n(v_ru_24t_241288_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), v_b_241295));
        V v_t_241297 = (g_std_2edoc_2e_3c_3e(v_a_241294, v_t_241296));
        V v_t_241298 = (g_std_2edoc_2e_3c_3e(v_t_241293, v_t_241297));
        return (g_std_2edoc_2e_3c_3e(v_t_241291, v_t_241298));
      }
      case TAG_Unrelated: {
        heff_drop_cell(v_ru_24rs_241282_24Cons, 2);
        heff_drop_rec(v_op_241286, 9);
        heff_drop(v_e_241287);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17));
        args[0] = v_env_241277;
        args[1] = v_m_241278;
        args[2] = v_inner_241279;
        args[3] = v_f_241280;
        args[4] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241284, v_acc_241281});
        args[5] = v_rest2_241285;
        if (heff_exact(f_, 6, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 6, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_241288, 0ULL, 1);
        heff_drop_cell(v_ru_24rs_241282_24Cons, 2);
        heff_drop_rec(v_op_241286, 9);
        heff_drop(v_e_241287);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17));
        args[0] = v_env_241277;
        args[1] = v_m_241278;
        args[2] = v_inner_241279;
        args[3] = v_f_241280;
        args[4] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241284, v_acc_241281});
        args[5] = v_rest2_241285;
        if (heff_exact(f_, 6, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 6, args);
      }
      default: return heff_nomatch(v_t_241288);
      }
    }
    default: {
      heff_drop_cell(v_ru_24rs_241282_24Cons, 2);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 17));
      args[0] = v_env_241277;
      args[1] = v_m_241278;
      args[2] = v_inner_241279;
      args[3] = v_f_241280;
      args[4] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_241284, v_acc_241281});
      args[5] = v_rest2_241285;
      if (heff_exact(f_, 6, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 6, args);
    }
    }
  }
  default: return heff_nomatch(v_rs_241282);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_env_241300 = args[0];
  V v_a_241301 = args[1];
  switch (heff_tag_of(v_a_241301)) {
  case TAG_EAlt: {
    V v_p_241302 = heff_field(v_a_241301, 0);
    V v_arrow_241303 = heff_field(v_a_241301, 1);
    V v_body_241304 = heff_field(v_a_241301, 2);
    heff_take_n(v_a_241301, 7ULL, 3);
    V v_a_241305 = ({ V a_0 = v_env_241300; V a_1 = v_p_241302; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_241302); r_; });
    V v_b_241306 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_241300, v_arrow_241303, v_body_241304}));
    V v_t_241307 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), v_b_241306));
    return (g_std_2edoc_2e_3c_3e(v_a_241305, v_t_241307));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241300;
    args[1] = v_a_241301;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_env_241308 = args[0];
  V v_s_241309 = args[1];
  switch (heff_tag_of(v_s_241309)) {
  case TAG_If: {
    V v_d_241316 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241308, v_s_241309}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_241316});
  }
  case TAG_ESBind: {
    V v_x_241317 = heff_field(v_s_241309, 0);
    V v_arrow_241318 = heff_field(v_s_241309, 1);
    V v_e_241319 = heff_field(v_s_241309, 2);
    heff_take_n(v_s_241309, 7ULL, 3);
    V v_a_241320 = ({ V a_0 = v_env_241308; V a_1 = v_x_241317; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_241317); r_; });
    V v_b_241321 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_241308, v_arrow_241318, v_e_241319}));
    V v_t_241322 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241321));
    return (g_std_2edoc_2e_3c_3e(v_a_241320, v_t_241322));
  }
  case TAG_IfThen: {
    V v_d_241327 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241308, v_s_241309}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_241327});
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241308;
    args[1] = v_s_241309;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_env_241328 = args[0];
  V v_f_241329 = args[1];
  switch (heff_tag_of(v_f_241329)) {
  case TAG_EUSet: {
    V v_x_241330 = heff_field(v_f_241329, 0);
    V v_eq_241331 = heff_field(v_f_241329, 1);
    V v_e_241332 = heff_field(v_f_241329, 2);
    heff_take_n(v_f_241329, 7ULL, 3);
    V v_a_241333 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241328), v_x_241330}));
    V v_b_241334 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_241328, v_eq_241331, v_e_241332}));
    V v_t_241335 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), v_b_241334));
    return (g_std_2edoc_2e_3c_3e(v_a_241333, v_t_241335));
  }
  case TAG_EFSet: {
    V v_x_241336 = heff_field(v_f_241329, 0);
    V v_eq_241337 = heff_field(v_f_241329, 1);
    V v_e_241338 = heff_field(v_f_241329, 2);
    heff_take_n(v_f_241329, 7ULL, 3);
    V v_a_241339 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241328), v_x_241336));
    V v_b_241340 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_241328, v_eq_241337, v_e_241338}));
    V v_t_241341 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241340));
    return (g_std_2edoc_2e_3c_3e(v_a_241339, v_t_241341));
  }
  case TAG_EFDefault: {
    V v_d_241342 = heff_field(v_f_241329, 0);
    V v_eq_241343 = heff_field(v_f_241329, 1);
    V v_e_241344 = heff_field(v_f_241329, 2);
    heff_take_n(v_f_241329, 7ULL, 3);
    V v_a_241345 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241328), v_d_241342}));
    V v_b_241346 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 3, (V[]){v_env_241328, v_eq_241343, v_e_241344}));
    V v_t_241347 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241346));
    return (g_std_2edoc_2e_3c_3e(v_a_241345, v_t_241347));
  }
  default: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241328;
    args[1] = v_f_241329;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        V v_ru_24x212_244_24Cons = heff_take_reuse_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e_24tok2(v_ru_24x212_244_24Cons, heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V b_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, b_1, a_2, a_3)); heff_drop(b_1); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    V v_ix_244 = heff_take_field(v_t_243, 7);
    V v_blank_245 = heff_get_n(v_t_243, 8, 9);
    HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_ix_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_ix_244); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2412;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = v_blank_245;
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop(v_blank_245);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_248);
        v_t_2412 = v_blank_245;
      }
      V v_t_2413;
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
    }
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str16, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_d1_244 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_244)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_d1_244, 0);
      V v_d12_249 = heff_field(v_d1_244, 1);
      switch (heff_tag_of(v_d12_249)) {
      case TAG_Nil: {
        V v_x2_2410 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_248)));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3);
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      case TAG_Cons: {
        return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5);
      }
      default: return heff_nomatch(v_d12_249);
      }
    }
    default: return heff_nomatch(v_d1_244);
    }
  }
  case TAG_DInstance: {
    V v_n_2416 = heff_field(v_d_240, 1);
    V v_x2_2419 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2416)));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  case TAG_DEqn: {
    V v_n_2422 = heff_field(v_d_240, 0);
    V v_x2_2427 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2422)));
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
    }
    default: return heff_nomatch(v_x2_2427);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DMutual: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str14);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str15);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str16);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str1, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_240, 1), heff_rfield(v_eof_243, 7)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_249;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        v_t_249 = v_x_248;
      } else {
        heff_drop(v_field_247);
        v_t_249 = NTAG(TAG_Nil);
      }
      return ({ V a_0 = v_env_240; V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_249); r_; });
    }
  }
  case TAG_Cons: {
    V v_d_2410 = heff_field(v_x5_244, 0);
    V v_ds_2411 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2410));
    V v_t_2454;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_DImport: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2454 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2452 = heff_dup(heff_field(v_d_2410, 0));
      v_t_2454 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_2452, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0)));
      heff_drop_rec(v_w_2452, 9);
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    V v_t_24206;
    if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2454);
      V v_t_2455 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
      V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
      V v_t_2458 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2455, v_t_2456, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2410)})));
      V v_t_2459 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2410); r_; });
      V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2459, v_eof_243, v_ds_2411));
      v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2460));
    } else {
      heff_drop(v_t_2454);
      V v_t_2461 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2461);
        V v_env_2462 = heff_dup(v_env_240);
        V v_lead_2463 = heff_take_field(v_env_2462, 1);
        V v_inline_2464 = heff_take_field(v_env_2462, 2);
        V v_src_2465 = heff_get_n(v_env_2462, 0, 7);
        V v_first_2466 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_ix_2467 = heff_take_field(v_first_2466, 7);
        V v_start_2468 = heff_get_n(v_first_2466, 3, 9);
        V v_t_2469 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2410));
        V v_t_2470 = ({ V a_0 = v_t_2469; V a_1 = v_d_2410; V a_2 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2469); r_; });
        V v_last2_2471 = (g_heff_2esyntax_2ecst_2elastD(v_t_2470));
        HeffT2 v_t_2472 = ({ V a_0 = v_lead_2463; V a_1 = v_ix_2467; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_lead_2463); r_; });
        {
          V v_field_2474 = v_t_2472.f[1];
          int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
          V v_t_2476;
          if ((v_tag_2473 == ((int64_t)0ULL))) {
            V v_x_2475 = v_field_2474;
            v_t_2476 = v_x_2475;
          } else {
            heff_drop(v_field_2474);
            v_t_2476 = NTAG(TAG_Nil);
          }
          V v_t_2477 = ({ V a_0 = v_t_2476; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a_0, a_1)); heff_drop(v_t_2476); r_; });
          HeffT2 v_t_2478 = ({ V a_0 = v_inline_2464; V a_1 = v_ix_2467; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_inline_2464); heff_drop(v_ix_2467); r_; });
          {
            V v_field_2480 = v_t_2478.f[1];
            int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
            V v_t_2482;
            if ((v_tag_2479 == ((int64_t)0ULL))) {
              V v_x_2481 = v_field_2480;
              v_t_2482 = v_x_2481;
            } else {
              heff_drop(v_field_2480);
              v_t_2482 = NTAG(TAG_Nil);
            }
            V v_t_2483 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2482; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2482); r_; });
            V v_b_2484 = (g_heff_2esyntax_2efmt_2elayout_2etrailEnd(v_src_2465, heff_get_n(v_last2_2471, 4, 9)));
            V v_t_2485 = ({ V b_0 = heff_strSlice(v_src_2465, v_start_2468, v_b_2484); V r_ = (g_heff_2esyntax_2efmt_2elayout_2ecomment(b_0)); heff_drop(b_0); r_; });
            V v_t_2486 = (g_std_2edoc_2e_3c_3e(v_t_2483, v_t_2485));
            V v_t_2487 = (g_std_2edoc_2e_3c_3e(v_t_2477, v_t_2486));
            V v_t_2488 = ({ V a_0 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2410); r_; });
            V v_t_2489 = ({ V a_0 = v_t_2488; V a_1 = v_ds_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2488); r_; });
            V v_t_2490 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2489));
            v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_2487, v_t_2490));
          }
        }
      } else {
        heff_drop(v_t_2461);
        V v_env_2491 = heff_dup(v_env_240);
        V v_d_2492 = heff_dup(v_d_2410);
        V v_expect_24186;
        switch (heff_tag_of(v_d_2492)) {
        case TAG_DImport: {
          heff_take_n(v_d_2492, 0ULL, 1);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DFixity: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DSig: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DInstance: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DEqn: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DData: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DType: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DTheory: {
          heff_take_n(v_d_2492, 0ULL, 5);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DMutual: {
          V v_ds_24125 = heff_field(v_d_2492, 1);
          V v_ru_24d_2492_24DMutual = heff_take_reuse_n(v_d_2492, 2ULL, 2);
          V v_x1_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_24125));
          switch (heff_tag_of(v_x1_24126)) {
          case TAG_Nil: {
            heff_drop_rec(v_env_2491, 7);
            heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
            v_expect_24186 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_x_24127 = heff_field(v_x1_24126, 0);
            heff_take_n(v_x1_24126, 1ULL, 2);
            switch (heff_tag_of(v_x_24127)) {
            case TAG_DImport: {
              heff_take_n(v_x_24127, 0ULL, 1);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DFixity: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DSig: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DInstance: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DEqn: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DData: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DType: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DTheory: {
              heff_take_n(v_x_24127, 0ULL, 5);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DMutual: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DPrimitive: {
              heff_take_n(v_x_24127, 0ULL, 4);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DTest: {
              heff_take_n(v_x_24127, 0ULL, 2);
              heff_drop_rec(v_env_2491, 7);
              heff_drop_cell(v_ru_24d_2492_24DMutual, 2);
              v_expect_24186 = NTAG(TAG_Nil);
              break;
            }
            case TAG_DWatch: {
              V v_w_24168 = heff_field(v_x_24127, 0);
              V v_e_24169 = heff_field(v_x_24127, 1);
              heff_take_n(v_x_24127, 3ULL, 2);
              V v_t_24170 = (g_heff_2esyntax_2ecst_2elastE(v_e_24169));
              V v_t_24171 = heff_intAdd(heff_get_n(v_t_24170, 7, 9), MK_INT(1LL));
              HeffT2 v_t_24172 = ({ V b_0 = heff_get_n(v_env_2491, 1, 7); V a_1 = v_t_24171; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24171); r_; });
              {
                V v_field_24174 = v_t_24172.f[1];
                int64_t v_tag_24173 = ((int64_t)v_t_24172.f[0]);
                V v_t_24176;
                if ((v_tag_24173 == ((int64_t)0ULL))) {
                  V v_x_24175 = v_field_24174;
                  v_t_24176 = v_x_24175;
                } else {
                  heff_drop(v_field_24174);
                  v_t_24176 = NTAG(TAG_Nil);
                }
                V v_t_24177 = heff_bool(heff_strEq_c(heff_dup(heff_rfield(v_w_24168, 0)), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str1)));
                heff_drop_rec(v_w_24168, 9);
                v_expect_24186 = ({ V a_0 = v_ru_24d_2492_24DMutual; V a_1 = v_t_24177; V a_2 = v_t_24176; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines_24tok2(a_0, a_1, a_2)); heff_drop(v_t_24177); r_; });
              }
              break;
            }
            default: heff_nomatch(v_x_24127);
            }
            break;
          }
          default: heff_nomatch(v_x1_24126);
          }
          break;
        }
        case TAG_DPrimitive: {
          heff_take_n(v_d_2492, 0ULL, 4);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DTest: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        case TAG_DWatch: {
          heff_take_n(v_d_2492, 0ULL, 2);
          heff_drop_rec(v_env_2491, 7);
          v_expect_24186 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_d_2492);
        }
        V v_t_24187 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2410));
        V v_t_24188 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2410)));
        V v_t_24190 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_24187, v_t_24188, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2410)})));
        V v_d_24191 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_24186));
        V v_env_24192 = v_env_240;
        V v_t_24193 = (g_heff_2esyntax_2ecst_2elastD(v_d_2410));
        V v_ix_24194 = heff_intAdd(heff_get_n(v_t_24193, 7, 9), MK_INT(1LL));
        V v_n_24195 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_24186; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_24186); r_; });
        V v_t_24203;
        if (heff_intEq_c_lent(v_n_24195, MK_INT(0LL), 2)) {
          heff_drop(v_ix_24194);
          heff_drop(v_n_24195);
          v_t_24203 = v_env_24192;
        } else {
          HeffT2 v_t_24196 = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(heff_rfield(v_env_24192, 1), v_ix_24194));
          {
            V v_field_24198 = v_t_24196.f[1];
            int64_t v_tag_24197 = ((int64_t)v_t_24196.f[0]);
            V v_t_24200;
            if ((v_tag_24197 == ((int64_t)0ULL))) {
              V v_x_24199 = v_field_24198;
              v_t_24200 = v_x_24199;
            } else {
              heff_drop(v_field_24198);
              v_t_24200 = NTAG(TAG_Nil);
            }
            V v_t_24201 = ({ V a_0 = v_n_24195; V a_1 = v_t_24200; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24200); r_; });
            V v_t_24202 = ({ V a_0 = heff_take_field(v_env_24192, 1); V a_1 = v_ix_24194; V a_2 = v_t_24201; V r_ = (g_std_2eordmap_2einsert_24s1703101629x493626677(a_0, a_1, a_2)); heff_drop(v_ix_24194); heff_drop(v_t_24201); r_; });
            v_t_24203 = ({ V rv_1 = v_t_24202; V rr_ = heff_rec_reuse_nf(v_env_24192, 125ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          }
        }
        V v_t_24204 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_24203, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2411));
        V v_t_24205 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24191}), v_t_24204));
        v_t_24206 = (g_std_2edoc_2e_3c_3e(v_t_24190, v_t_24205));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2412, v_t_24206));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2457 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2457; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_24189 = args[0];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_24189; V a_1 = v_d_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2410); r_; });
}