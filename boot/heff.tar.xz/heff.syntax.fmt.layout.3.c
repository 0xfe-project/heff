// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DMutual 35008
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_exposing 966605106
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks(V);
V g_heff_2esyntax_2efmt_2eimports_2eexposingToks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2eexposingToks_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo;
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo(V);
V g_heff_2esyntax_2efmt_2elayout_2eendsInDo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eendsInDo_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLines_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadLaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadLaid_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ereplaceAll_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_t_2418;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        switch (heff_tag_of(v_x_247)) {
        case TAG_Nil: {
          v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x_247, 0ULL, 2);
          V v_t_2416;
          if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
            v_t_2416 = NTAG(TAG_Nil);
          } else {
            HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_dup(heff_rfield(v_t_241, 7))));
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                V v_x_2415 = v_field_2413;
                v_t_2416 = v_x_2415;
              } else {
                heff_drop(v_field_2413);
                v_t_2416 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2417 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2416); r_; });
          v_t_2418 = (g_std_2edoc_2e_3c_3e(v_t_2417, heff_dup(g_std_2edoc_2ehardline_get())));
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_field_245);
        v_t_2418 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
  }
  HeffT2 v_t_2419 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 2), heff_dup(heff_rfield(v_t_241, 7))));
  V v_t_2424;
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2423 = v_field_2421;
      v_t_2424 = v_x_2423;
    } else {
      heff_drop(v_field_2421);
      v_t_2424 = NTAG(TAG_Nil);
    }
  }
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2424; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2424); r_; });
  V v_s_2426 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2428;
  if (heff_strEq_c_lent(v_s_2426, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2426);
    v_t_2428 = NTAG(TAG_None);
  } else {
    v_t_2428 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2426});
  }
  V v_t_2430;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2430 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2430 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2431 = (g_std_2edoc_2e_3c_3e(v_t_2428, v_t_2430));
  V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_t_2425, v_t_2431));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2418, v_t_2432);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_c_242, 0)));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2esyntax_2efmt_2elayout_2eendsInDo(heff_dup(v_args_2455));
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2479 = heff_field(v_e_240, 3);
    V t_0 = v_body_2479;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2439 = heff_field(v_x1_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2439, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EField: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETilde: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_App: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Op: {
    V v_a_2456 = heff_field(v_e_240, 0);
    V v_op_2457 = heff_field(v_e_240, 1);
    V v_b_2458 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_2458)));
    {
      V v_field_2460 = v_t_2459.f[0];
      V v_field_2461 = v_t_2459.f[1];
      V v_bf_2462 = v_field_2460;
      V v_rest_2463 = v_field_2461;
      V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2457), v_rest_2463));
      if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
        heff_drop(v_b_2458);
        heff_drop(v_t_2464);
        V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2457, v_bf_2462}), v_rest_2463});
        return ((HeffT2){{v_a_2456, v_t_2465}});
      } else {
        heff_drop(v_bf_2462);
        heff_drop(v_rest_2463);
        heff_drop(v_t_2464);
        V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2457, v_b_2458}), NTAG(TAG_Nil)});
        return ((HeffT2){{v_a_2456, v_t_2466}});
      }
    }
  }
  case TAG_Ops: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BPat: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_If: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetElse: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ETilde: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2463 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2463, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BPat: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetElse: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELetMut: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAssign: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFor: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EJump: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EReturn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_IfThen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ETry: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECatch: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EWith: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2463 = heff_field(v_r_242, 0);
    V v_t_2465 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2463, 1))));
    switch (heff_tag_of(v_t_2465)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2465, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2465, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2465);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangsLast(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    V v_args_2455 = heff_field(v_x1_240, 1);
    V v_x1_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2455)));
    switch (heff_tag_of(v_x1_2456)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x1_2456, 0);
      V v_rev_2458 = heff_field(v_x1_2456, 1);
      heff_take_n(v_x1_2456, 3ULL, 2);
      V v_t_2459 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_2458));
      heff_drop(v_t_2459);
      switch (heff_tag_of(v_x_2457)) {
      case TAG_Atom: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 1); r_; });
      }
      case TAG_EParen: {
        V v_e_2462 = heff_field(v_x_2457, 1);
        heff_take_n(v_x_2457, 2ULL, 3);
        return ({ V a_0 = v_e_2462; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop(v_e_2462); r_; });
      }
      case TAG_Named: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 5); r_; });
      }
      case TAG_Tup: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_Seg: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_Braces: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_Update: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 6); r_; });
      }
      case TAG_EUSet: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_InstB: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 5); r_; });
      }
      case TAG_EFSet: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_EFDefault: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_Sum: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 5); r_; });
      }
      case TAG_ECon: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_EField: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_ENeg: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_ETilde: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_App: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_Op: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_Ops: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_OpRhs: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_Ann: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_BVar: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 1); r_; });
      }
      case TAG_BImp: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_BAnn: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 5); r_; });
      }
      case TAG_BPat: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 1); r_; });
      }
      case TAG_Lam: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_Case: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_EAlt: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_If: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 6); r_; });
      }
      case TAG_Do: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_ESBind: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_ELet: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 6); r_; });
      }
      case TAG_ELetElse: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 7); r_; });
      }
      case TAG_ELetMut: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 6); r_; });
      }
      case TAG_EAssign: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 3); r_; });
      }
      case TAG_EWhile: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_EFor: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 6); r_; });
      }
      case TAG_EJump: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 1); r_; });
      }
      case TAG_EReturn: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 2); r_; });
      }
      case TAG_ENest: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_IfThen: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_ETry: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_ECatch: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 4); r_; });
      }
      case TAG_EWith: {
        return ({ V a_0 = v_x_2457; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ehangs(a_0)); heff_drop_tag(v_x_2457, 6); r_; });
      }
      default: return heff_nomatch(v_x_2457);
      }
    }
    default: return heff_nomatch(v_x1_2456);
    }
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangsLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangsLast(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_take_field(v_t_246, 7)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = heff_get_n(v_t_246, 8, 9);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop_rec(v_t_246, 9);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_249);
          v_t_2414 = heff_get_n(v_t_246, 8, 9);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str111, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str113, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str115, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str116, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str117, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str118, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str119, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str122, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str123, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str125, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str126, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str127, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str128, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str129, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str131, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str132, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str133, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str135, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str136, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str137, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str138, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str140, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str141, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str142, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str143, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str145, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str146, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str147, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str149, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str151, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str152, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str153, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str154, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str155, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str156, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str157, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str158, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str159, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str160, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str161, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam124, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam125, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam126, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam127, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam128, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam131(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam131, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam132(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam132, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam133(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam133, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam134(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam134, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam28_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam29_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam30_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam31_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam34_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam35_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam124_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam125_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam126_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam127_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam128_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam131_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam132_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam133_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam134_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c_lent(v_i_2411, MK_INT(0LL), 2)) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2445 = args[0];
  V v_e_2446 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2447 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2445));
  V v_one_2448 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_240}));
  V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_2446));
  V v_b_2453;
  if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
    heff_drop(v_t_2449);
    V v_d_2450 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2450});
  } else {
    heff_drop(v_t_2449);
    V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e_2446));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      V v_d_2452 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
      v_b_2453 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2452});
    } else {
      heff_drop(v_t_2451);
      v_b_2453 = heff_tr(heff_call(v_one_2448, 1, (V[]){v_e_2446}));
    }
  }
  V v_t_2454 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2453));
  V v_t_2455 = (g_std_2edoc_2e_3c_3e(v_a_2447, v_t_2454));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2455));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2466 = args[0];
  V v_k_2465 = heff_env(self)[0];
  V v_d_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2467 = heff_intSub(v_k_2465, v_i_2466);
  if (heff_intEq_c_lent(v_i_2467, MK_INT(0LL), 2)) {
    heff_drop(v_i_2467);
    return v_d_2464;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2467, v_d_2464});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2465 = args[0];
  V v_d_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2465, v_d_2464})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2474 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2474));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2489 = args[0];
  V v_f_2490 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2491 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2489));
  V v_d_2492 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2490}));
  V v_t_2493 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2492})));
  V v_t_2494 = (g_std_2edoc_2e_3c_3e(v_a_2491, v_t_2493));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2494));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_24103 = args[0];
  V v_k_24102 = heff_env(self)[0];
  V v_d_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24104 = heff_intSub(v_k_24102, v_i_24103);
  if (heff_intEq_c_lent(v_i_24104, MK_INT(0LL), 2)) {
    heff_drop(v_i_24104);
    return v_d_24101;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24104, v_d_24101});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_24102 = args[0];
  V v_d_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_24102, v_d_24101})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24131 = args[0];
  V v_f_24132 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24133 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24131));
  V v_d_24134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24132}));
  V v_t_24135 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24134})));
  V v_t_24136 = (g_std_2edoc_2e_3c_3e(v_a_24133, v_t_24135));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24136));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24147 = args[0];
  V v_k_24146 = heff_env(self)[0];
  V v_d_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24148 = heff_intSub(v_k_24146, v_i_24147);
  if (heff_intEq_c_lent(v_i_24148, MK_INT(0LL), 2)) {
    heff_drop(v_i_24148);
    return v_d_24145;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24148, v_d_24145});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24146 = args[0];
  V v_d_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24146, v_d_24145})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24205 = args[0];
  V v_a_24206 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24188 = heff_env(self)[1];
  V v_c_24191 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24207 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24188, 4, 9), heff_get_n(v_c_24191, 3, 9)));
  V v_t_24208;
  if ((heff_dup(v_x1_24207) == NTAG(TAG_True))) {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24207);
    v_t_24208 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24209 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24205));
  V v_b_24210 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24206}));
  V v_t_24211 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24210));
  V v_t_24212 = (g_std_2edoc_2e_3c_3e(v_a_24209, v_t_24211));
  return (g_std_2edoc_2e_3c_3e(v_t_24208, v_t_24212));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24219 = args[0];
  V v_k_24218 = heff_env(self)[0];
  V v_d_24217 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24220 = heff_intSub(v_k_24218, v_i_24219);
  if (heff_intEq_c_lent(v_i_24220, MK_INT(0LL), 2)) {
    heff_drop(v_i_24220);
    return v_d_24217;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24220, v_d_24217});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24218 = args[0];
  V v_d_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24218, v_d_24217})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24227 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24227}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24228));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24253 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24251 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24254 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24253));
  V v_t_24255;
  if ((heff_dup(v_x1_24254) == NTAG(TAG_True))) {
    heff_drop(v_x1_24254);
    v_t_24255 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24254);
    v_t_24255 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24256 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24251, v_r_24253}));
  return (g_std_2edoc_2e_3c_3e(v_t_24255, v_t_24256));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24370 = args[0];
  V v_k_24369 = heff_env(self)[0];
  V v_d_24368 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24371 = heff_intSub(v_k_24369, v_i_24370);
  if (heff_intEq_c_lent(v_i_24371, MK_INT(0LL), 2)) {
    heff_drop(v_i_24371);
    return v_d_24368;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24371, v_d_24368});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24369 = args[0];
  V v_d_24368 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24369, v_d_24368})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_i_24435 = args[0];
  V v_k_24434 = heff_env(self)[0];
  V v_d_24431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24436 = heff_intSub(v_k_24434, v_i_24435);
  if (heff_intEq_c_lent(v_i_24436, MK_INT(0LL), 2)) {
    heff_drop(v_i_24436);
    return v_d_24431;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24436, v_d_24431});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_k_24434 = args[0];
  V v_d_24431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 1, 2, (V[]){v_k_24434, v_d_24431})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_i_24455 = args[0];
  V v_k_24454 = heff_env(self)[0];
  V v_d_24451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24456 = heff_intSub(v_k_24454, v_i_24455);
  if (heff_intEq_c_lent(v_i_24456, MK_INT(0LL), 2)) {
    heff_drop(v_i_24456);
    return v_d_24451;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24456, v_d_24451});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_k_24454 = args[0];
  V v_d_24451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 1, 2, (V[]){v_k_24454, v_d_24451})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_i_24503 = args[0];
  V v_k_24502 = heff_env(self)[0];
  V v_d_24501 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24504 = heff_intSub(v_k_24502, v_i_24503);
  if (heff_intEq_c_lent(v_i_24504, MK_INT(0LL), 2)) {
    heff_drop(v_i_24504);
    return v_d_24501;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24504, v_d_24501});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_k_24502 = args[0];
  V v_d_24501 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 1, 2, (V[]){v_k_24502, v_d_24501})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_i_24535 = args[0];
  V v_k_24534 = heff_env(self)[0];
  V v_d_24525 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24536 = heff_intSub(v_k_24534, v_i_24535);
  if (heff_intEq_c_lent(v_i_24536, MK_INT(0LL), 2)) {
    heff_drop(v_i_24536);
    return v_d_24525;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24536, v_d_24525});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_k_24534 = args[0];
  V v_d_24525 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 2, (V[]){v_k_24534, v_d_24525})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_one_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_240)}));
      V v_t_2440 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e1_2435));
      V v_t_2444;
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_t_2440);
        V v_d_2441 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2441});
      } else {
        heff_drop(v_t_2440);
        V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2ehangsLast(v_e1_2435));
        if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
          heff_drop(v_t_2442);
          V v_d_2443 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
          v_t_2444 = heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2443});
        } else {
          heff_drop(v_t_2442);
          v_t_2444 = heff_tr(heff_call(v_one_2439, 1, (V[]){v_e1_2435}));
        }
      }
      V v_t_2456 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2457 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2458;
      if ((heff_dup(v_x1_2457) == NTAG(TAG_True))) {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2457);
        v_t_2458 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2460 = (g_std_2edoc_2e_3c_3e(v_t_2458, v_t_2459));
      V v_t_2461 = (g_std_2edoc_2e_3c_3e(v_t_2456, v_t_2460));
      V v_t_2462 = (g_std_2edoc_2e_3c_3e(v_t_2444, v_t_2461));
      V v_t_2463 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2462));
      V v_d_2464 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2463));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2464})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2469 = heff_field(v_e0_241, 0);
    V v_cc_2470 = heff_field(v_e0_241, 1);
    V v_spec_2471 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2472 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2469}));
    V v_t_2473 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2470));
    V v_t_2475 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2471; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2471); r_; });
    V v_t_2476 = (g_std_2edoc_2e_3c_3e(v_t_2473, v_t_2475));
    return (g_std_2edoc_2e_3c_3e(v_t_2472, v_t_2476));
  }
  case TAG_Braces: {
    V v_o_2477 = heff_field(v_e0_241, 0);
    V v_fs_2478 = heff_field(v_e0_241, 1);
    V v_commas_2479 = heff_field(v_e0_241, 2);
    V v_c_2480 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2478)) {
    case TAG_Nil: {
      heff_drop(v_commas_2479);
      V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2477));
      V v_t_2482 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      return (g_std_2edoc_2e_3c_3e(v_t_2481, v_t_2482));
    }
    case TAG_Cons: {
      V v_f1_2483 = heff_field(v_fs_2478, 0);
      V v_more_2484 = heff_field(v_fs_2478, 1);
      V v_ru_24fs_2478_24Cons = heff_take_reuse_n(v_fs_2478, 3ULL, 2);
      V v_a_2485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2477)));
      V v_d_2486 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2483}));
      V v_t_2487 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2478_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2486})));
      V v_t_2488 = (g_std_2edoc_2e_3c_3e(v_a_2485, v_t_2487));
      V v_t_2495 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2479; V a_3 = v_more_2484; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2479); heff_drop(v_more_2484); r_; });
      V v_x1_2496 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_2477, 4, 9), heff_dup(heff_rfield(v_c_2480, 3))));
      V v_t_2497;
      if ((heff_dup(v_x1_2496) == NTAG(TAG_True))) {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2496);
        v_t_2497 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2498 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2480));
      V v_t_2499 = (g_std_2edoc_2e_3c_3e(v_t_2497, v_t_2498));
      V v_t_24100 = (g_std_2edoc_2e_3c_3e(v_t_2495, v_t_2499));
      V v_d_24101 = (g_std_2edoc_2e_3c_3e(v_t_2488, v_t_24100));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_24101})})));
    }
    default: return heff_nomatch(v_fs_2478);
    }
  }
  case TAG_Update: {
    V v_o_24106 = heff_field(v_e0_241, 0);
    V v_r_24107 = heff_field(v_e0_241, 1);
    V v_bar_24108 = heff_field(v_e0_241, 2);
    V v_fs_24109 = heff_field(v_e0_241, 3);
    V v_commas_24110 = heff_field(v_e0_241, 4);
    V v_c_24111 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_24109)) {
    case TAG_Nil: {
      heff_drop(v_commas_24110);
      V v_a_24112 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24106));
      V v_a_24113 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_a_24114 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_b_24115 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24115));
      V v_t_24117 = (g_std_2edoc_2e_3c_3e(v_a_24114, v_t_24116));
      V v_t_24118 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24117));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24118));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24119));
      return (g_std_2edoc_2e_3c_3e(v_a_24112, v_t_24120));
    }
    case TAG_Cons: {
      V v_f1_24121 = heff_field(v_fs_24109, 0);
      V v_more_24122 = heff_field(v_fs_24109, 1);
      V v_ru_24fs_24109_24Cons = heff_take_reuse_n(v_fs_24109, 3ULL, 2);
      V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24106)));
      V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_24107}));
      V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_24109_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24124})));
      V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
      V v_a_24127 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24108));
      V v_d_24128 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24121}));
      V v_t_24129 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24128})));
      V v_t_24130 = (g_std_2edoc_2e_3c_3e(v_a_24127, v_t_24129));
      V v_t_24137 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24110; V a_3 = v_more_24122; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24110); heff_drop(v_more_24122); r_; });
      V v_x1_24138 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_rfield(v_env_240, 0), heff_get_n(v_o_24106, 4, 9), heff_dup(heff_rfield(v_c_24111, 3))));
      V v_t_24139;
      if ((heff_dup(v_x1_24138) == NTAG(TAG_True))) {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24138);
        v_t_24139 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24140 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24111));
      V v_t_24141 = (g_std_2edoc_2e_3c_3e(v_t_24139, v_t_24140));
      V v_t_24142 = (g_std_2edoc_2e_3c_3e(v_t_24137, v_t_24141));
      V v_t_24143 = (g_std_2edoc_2e_3c_3e(v_t_24130, v_t_24142));
      V v_t_24144 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24143));
      V v_d_24145 = (g_std_2edoc_2e_3c_3e(v_t_24126, v_t_24144));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24145})})));
    }
    default: return heff_nomatch(v_fs_24109);
    }
  }
  case TAG_EUSet: {
    V v_x_24150 = heff_field(v_e0_241, 0);
    V v_eq_24151 = heff_field(v_e0_241, 1);
    V v_e_24152 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24153 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24150}));
    V v_b_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24151));
    V v_t_24155 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24154));
    V v_t_24156 = (g_std_2edoc_2e_3c_3e(v_a_24153, v_t_24155));
    V v_t_24157 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24152}));
    return (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
  }
  case TAG_InstB: {
    V v_o_24158 = heff_field(v_e0_241, 0);
    V v_o2_24159 = heff_field(v_e0_241, 1);
    V v_d_24160 = heff_field(v_e0_241, 2);
    V v_c1_24161 = heff_field(v_e0_241, 3);
    V v_c_24162 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24163 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24158));
    V v_t_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24159));
    V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24160}));
    V v_t_24166 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24161));
    V v_t_24167 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24162));
    V v_t_24168 = (g_std_2edoc_2e_3c_3e(v_t_24166, v_t_24167));
    V v_t_24169 = (g_std_2edoc_2e_3c_3e(v_t_24165, v_t_24168));
    V v_t_24170 = (g_std_2edoc_2e_3c_3e(v_t_24164, v_t_24169));
    return (g_std_2edoc_2e_3c_3e(v_t_24163, v_t_24170));
  }
  case TAG_EFSet: {
    V v_x_24171 = heff_field(v_e0_241, 0);
    V v_eq_24172 = heff_field(v_e0_241, 1);
    V v_e_24173 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24174 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24171));
    V v_b_24175 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24172));
    V v_t_24176 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24175));
    V v_t_24177 = (g_std_2edoc_2e_3c_3e(v_a_24174, v_t_24176));
    V v_t_24178 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24173}));
    return (g_std_2edoc_2e_3c_3e(v_t_24177, v_t_24178));
  }
  case TAG_EFDefault: {
    V v_d_24179 = heff_field(v_e0_241, 0);
    V v_eq_24180 = heff_field(v_e0_241, 1);
    V v_e_24181 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24179}));
    V v_b_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24180));
    V v_t_24184 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24183));
    V v_t_24185 = (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24184));
    V v_t_24186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24181}));
    return (g_std_2edoc_2e_3c_3e(v_t_24185, v_t_24186));
  }
  case TAG_Sum: {
    V v_kw_24187 = heff_field(v_e0_241, 0);
    V v_o_24188 = heff_field(v_e0_241, 1);
    V v_alts_24189 = heff_field(v_e0_241, 2);
    V v_bars_24190 = heff_field(v_e0_241, 3);
    V v_c_24191 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24189)) {
    case TAG_Nil: {
      heff_drop(v_bars_24190);
      V v_a_24192 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24193 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24188));
      V v_b_24194 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24195 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24194));
      V v_t_24196 = (g_std_2edoc_2e_3c_3e(v_a_24193, v_t_24195));
      V v_t_24197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24196));
      return (g_std_2edoc_2e_3c_3e(v_a_24192, v_t_24197));
    }
    case TAG_Cons: {
      V v_a1_24198 = heff_field(v_alts_24189, 0);
      V v_more_24199 = heff_field(v_alts_24189, 1);
      heff_take_n(v_alts_24189, 3ULL, 2);
      V v_a_24200 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24187));
      V v_a_24201 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24188)));
      V v_b_24202 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24198}));
      V v_t_24203 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24202));
      V v_t_24204 = (g_std_2edoc_2e_3c_3e(v_a_24201, v_t_24203));
      V v_a_24213 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24188, heff_dup(v_c_24191)}); V a_2 = v_bars_24190; V a_3 = v_more_24199; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24190); heff_drop(v_more_24199); r_; });
      V v_b_24214 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24191));
      V v_t_24215 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24214));
      V v_t_24216 = (g_std_2edoc_2e_3c_3e(v_a_24213, v_t_24215));
      V v_d_24217 = (g_std_2edoc_2e_3c_3e(v_t_24204, v_t_24216));
      V v_b_24222 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24217})})));
      V v_t_24223 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24222));
      return (g_std_2edoc_2e_3c_3e(v_a_24200, v_t_24223));
    }
    default: return heff_nomatch(v_alts_24189);
    }
  }
  case TAG_ECon: {
    V v_c_24224 = heff_field(v_e0_241, 0);
    V v_args_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24224));
    V v_t_24229 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24225; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24225); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24229));
  }
  case TAG_EField: {
    V v_e_24230 = heff_field(v_e0_241, 0);
    V v_f_24231 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24232 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24230}));
    V v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24231));
    return (g_std_2edoc_2e_3c_3e(v_t_24232, v_t_24233));
  }
  case TAG_ENeg: {
    V v_m_24234 = heff_field(v_e0_241, 0);
    V v_e_24235 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24236 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24234));
    V v_t_24237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24235}));
    return (g_std_2edoc_2e_3c_3e(v_t_24236, v_t_24237));
  }
  case TAG_ETilde: {
    V v_m_24238 = heff_field(v_e0_241, 0);
    V v_e_24239 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24240 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24238));
    V v_t_24241 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24239}));
    return (g_std_2edoc_2e_3c_3e(v_t_24240, v_t_24241));
  }
  case TAG_App: {
    V v_h_24242 = heff_field(v_e0_241, 0);
    V v_args_24243 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24242;
    heff_room[2] = v_args_24243;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24244 = heff_field(v_e0_241, 0);
    V v_op_24245 = heff_field(v_e0_241, 1);
    V v_b_24246 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24247 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24244, v_op_24245, v_b_24246})));
    {
      V v_field_24248 = v_t_24247.f[0];
      V v_field_24249 = v_t_24247.f[1];
      V v_first_24250 = v_field_24248;
      V v_rest_24251 = v_field_24249;
      V v_t_24252 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24251), v_first_24250}));
      V v_t_24257 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24251)}); V a_2 = v_rest_24251; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24251); r_; });
      V v_t_24258 = (g_std_2edoc_2e_3c_3e(v_t_24252, v_t_24257));
      return (g_std_2edoc_2egroup(v_t_24258));
    }
  }
  case TAG_Ops: {
    V v_a_24259 = heff_field(v_e0_241, 0);
    V v_rest_24260 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24259;
    heff_room[2] = v_rest_24260;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24261 = heff_field(v_e0_241, 0);
    V v_e_24262 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24263 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24261));
    V v_b_24264 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24262}));
    V v_t_24265 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24264));
    return (g_std_2edoc_2e_3c_3e(v_a_24263, v_t_24265));
  }
  case TAG_Ann: {
    V v_e_24266 = heff_field(v_e0_241, 0);
    V v_cc_24267 = heff_field(v_e0_241, 1);
    V v_ty_24268 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24269 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24266}));
    V v_b_24270 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24267));
    V v_t_24271 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24270));
    V v_t_24272 = (g_std_2edoc_2e_3c_3e(v_a_24269, v_t_24271));
    V v_t_24273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24268}));
    V v_d_24274 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24273));
    V v_t_24275 = (g_std_2edoc_2e_3c_3e(v_t_24272, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24274})));
    return (g_std_2edoc_2egroup(v_t_24275));
  }
  case TAG_BVar: {
    V v_t_24276 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24276));
  }
  case TAG_BImp: {
    V v_o_24277 = heff_field(v_e0_241, 0);
    V v_x_24278 = heff_field(v_e0_241, 1);
    V v_c_24279 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24280 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24277));
    V v_t_24281 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24278));
    V v_t_24282 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24279));
    V v_t_24283 = (g_std_2edoc_2e_3c_3e(v_t_24281, v_t_24282));
    return (g_std_2edoc_2e_3c_3e(v_t_24280, v_t_24283));
  }
  case TAG_BAnn: {
    V v_o_24284 = heff_field(v_e0_241, 0);
    V v_x_24285 = heff_field(v_e0_241, 1);
    V v_cc_24286 = heff_field(v_e0_241, 2);
    V v_ty_24287 = heff_field(v_e0_241, 3);
    V v_c_24288 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24289 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24284));
    V v_a_24290 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24285));
    V v_a_24291 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24286));
    V v_b_24292 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24287}));
    V v_t_24293 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24292));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(v_a_24291, v_t_24293));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24294));
    V v_t_24296 = (g_std_2edoc_2e_3c_3e(v_a_24290, v_t_24295));
    V v_t_24297 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24288));
    V v_t_24298 = (g_std_2edoc_2e_3c_3e(v_t_24296, v_t_24297));
    return (g_std_2edoc_2e_3c_3e(v_t_24289, v_t_24298));
  }
  case TAG_BPat: {
    V v_p_24299 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return ({ V a_0 = v_env_240; V a_1 = v_p_24299; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24299); r_; });
  }
  case TAG_Lam: {
    V v_bs_24300 = heff_field(v_e0_241, 0);
    V v_binders_24301 = heff_field(v_e0_241, 1);
    V v_arrow_24302 = heff_field(v_e0_241, 2);
    V v_body_24303 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24304 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24300));
    V v_t_24305 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24306 = (g_list_2emap(v_t_24305, v_binders_24301));
    V v_a_24307 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24306; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24306); r_; });
    V v_b_24308 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24302));
    V v_t_24309 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24308));
    V v_t_24310 = (g_std_2edoc_2e_3c_3e(v_a_24307, v_t_24309));
    V v_t_24311 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24303));
    V v_t_24315;
    if ((heff_dup(v_t_24311) == NTAG(TAG_True))) {
      heff_drop(v_t_24311);
      V v_t_24312 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24303}));
      v_t_24315 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24312));
    } else {
      heff_drop(v_t_24311);
      V v_t_24313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24303}));
      V v_d_24314 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24313));
      v_t_24315 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24314})));
    }
    V v_t_24316 = (g_std_2edoc_2e_3c_3e(v_t_24310, v_t_24315));
    return (g_std_2edoc_2e_3c_3e(v_t_24304, v_t_24316));
  }
  case TAG_Case: {
    V v_kw_24317 = heff_field(v_e0_241, 0);
    V v_scrut_24318 = heff_field(v_e0_241, 1);
    V v_of2_24319 = heff_field(v_e0_241, 2);
    V v_alts_24320 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24321 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24317));
    V v_a_24322 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24318}));
    V v_b_24323 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24319));
    V v_t_24324 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24323));
    V v_t_24325 = (g_std_2edoc_2e_3c_3e(v_a_24322, v_t_24324));
    V v_t_24326 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24325));
    V v_t_24327 = (g_std_2edoc_2e_3c_3e(v_a_24321, v_t_24326));
    V v_t_24328 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24320; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24320); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24327, v_t_24328));
  }
  case TAG_EAlt: {
    V v_p_24329 = heff_field(v_e0_241, 0);
    V v_arrow_24330 = heff_field(v_e0_241, 1);
    V v_body_24331 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24332 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24329; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24329); r_; });
    V v_b_24333 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24330));
    V v_t_24334 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24333));
    V v_t_24335 = (g_std_2edoc_2e_3c_3e(v_a_24332, v_t_24334));
    V v_t_24336 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24331}));
    return (g_std_2edoc_2e_3c_3e(v_t_24335, v_t_24336));
  }
  case TAG_If: {
    V v_kw_24337 = heff_field(v_e0_241, 0);
    V v_c_24338 = heff_field(v_e0_241, 1);
    V v_th_24339 = heff_field(v_e0_241, 2);
    V v_a_24340 = heff_field(v_e0_241, 3);
    V v_el_24341 = heff_field(v_e0_241, 4);
    V v_b_24342 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24343 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24337, v_c_24338, v_th_24339, v_a_24340}));
    V v_t_24344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24341, v_b_24342}));
    V v_t_24345 = (g_std_2edoc_2e_3c_3e(v_t_24343, v_t_24344));
    return (g_std_2edoc_2egroup(v_t_24345));
  }
  case TAG_Do: {
    V v_kw_24346 = heff_field(v_e0_241, 0);
    V v_stmts_24347 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24348 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24346));
    V v_t_24349 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24347; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24347); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24348, v_t_24349));
  }
  case TAG_ESBind: {
    V v_x_24350 = heff_field(v_e0_241, 0);
    V v_arrow_24351 = heff_field(v_e0_241, 1);
    V v_e_24352 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24353 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24350; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24350); r_; });
    V v_b_24354 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24351));
    V v_t_24355 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24354));
    V v_t_24356 = (g_std_2edoc_2e_3c_3e(v_a_24353, v_t_24355));
    V v_t_24357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24352}));
    return (g_std_2edoc_2e_3c_3e(v_t_24356, v_t_24357));
  }
  case TAG_ELet: {
    V v_kw_24358 = heff_field(v_e0_241, 0);
    V v_p_24359 = heff_field(v_e0_241, 1);
    V v_ann_24360 = heff_field(v_e0_241, 2);
    V v_eq_24361 = heff_field(v_e0_241, 3);
    V v_e_24362 = heff_field(v_e0_241, 4);
    V v_body_24363 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24363)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24358, v_p_24359, v_ann_24360, v_eq_24361, v_e_24362});
    }
    case TAG_Just: {
      V v_it1_24364 = heff_field(v_body_24363, 0);
      V v_ru_24body_24363_24Just = heff_take_reuse_n(v_body_24363, 1ULL, 1);
      switch (heff_tag_of(v_it1_24364)) {
      case TAG_MkPair: {
        V v_i_24365 = heff_field(v_it1_24364, 0);
        V v_b_24366 = heff_field(v_it1_24364, 1);
        heff_take_n(v_it1_24364, 3ULL, 2);
        V v_t_24367 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24358, v_p_24359, v_ann_24360, v_eq_24361, v_e_24362, v_i_24365, v_b_24366}));
        V v_d_24368 = (g_std_2edoc_2egroup(v_t_24367));
        return heff_tag_at_n(v_ru_24body_24363_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24368})});
      }
      default: return heff_nomatch(v_it1_24364);
      }
    }
    default: return heff_nomatch(v_body_24363);
    }
  }
  case TAG_ELetElse: {
    V v_kw_24373 = heff_field(v_e0_241, 0);
    V v_p_24374 = heff_field(v_e0_241, 1);
    V v_ann_24375 = heff_field(v_e0_241, 2);
    V v_eq_24376 = heff_field(v_e0_241, 3);
    V v_e_24377 = heff_field(v_e0_241, 4);
    V v_el_24378 = heff_field(v_e0_241, 5);
    V v_ss_24379 = heff_field(v_e0_241, 6);
    heff_take_n(v_e0_241, 127ULL, 7);
    V v_a_24380 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_240), v_kw_24373, v_p_24374, v_ann_24375, v_eq_24376, v_e_24377}));
    V v_b_24381 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_el_24378));
    V v_t_24382 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_b_24381));
    V v_t_24383 = (g_std_2edoc_2e_3c_3e(v_a_24380, v_t_24382));
    V v_t_24391;
    switch (heff_tag_of(v_ss_24379)) {
    case TAG_Nil: {
      v_t_24391 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(v_env_240, MK_INT(0LL), v_ss_24379));
      break;
    }
    case TAG_Cons: {
      V v_s1_24384 = heff_dup(heff_field(v_ss_24379, 0));
      V v_it2_24385 = heff_dup(heff_field(v_ss_24379, 1));
      switch (heff_tag_of(v_it2_24385)) {
      case TAG_Nil: {
        V v_t_24386 = (g_heff_2esyntax_2ecst_2efirstE(v_s1_24384));
        V v_t_24387 = heff_get_n(v_t_24386, 6, 9);
        if ((heff_dup(v_t_24387) == NTAG(TAG_True))) {
          heff_drop(v_s1_24384);
          heff_drop(v_t_24387);
          v_t_24391 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24379; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop_tag(v_ss_24379, 2); r_; });
        } else {
          heff_drop_tag(v_ss_24379, 2);
          heff_drop(v_t_24387);
          V v_t_24388 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 14)), 2, (V[]){v_env_240, v_s1_24384}));
          v_t_24391 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_t_24388));
        }
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it2_24385, 0ULL, 2);
        heff_drop(v_s1_24384);
        v_t_24391 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_ss_24379; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop_tag(v_ss_24379, 2); r_; });
        break;
      }
      default: heff_nomatch(v_it2_24385);
      }
      break;
    }
    default: heff_nomatch(v_ss_24379);
    }
    return (g_std_2edoc_2e_3c_3e(v_t_24383, v_t_24391));
  }
  case TAG_ELetMut: {
    V v_kw_24392 = heff_field(v_e0_241, 0);
    V v_m_24393 = heff_field(v_e0_241, 1);
    V v_x_24394 = heff_field(v_e0_241, 2);
    V v_ann_24395 = heff_field(v_e0_241, 3);
    V v_eq_24396 = heff_field(v_e0_241, 4);
    V v_e_24397 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24398 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24392));
    V v_a_24399 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24393));
    V v_b_24400 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24394));
    V v_t_24401 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24400));
    V v_t_24402 = (g_std_2edoc_2e_3c_3e(v_a_24399, v_t_24401));
    V v_t_24403 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24402));
    V v_t_24404 = (g_std_2edoc_2e_3c_3e(v_a_24398, v_t_24403));
    V v_a_24412;
    switch (heff_tag_of(v_ann_24395)) {
    case TAG_Nothing: {
      v_a_24412 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_it1_24405 = heff_field(v_ann_24395, 0);
      V v_ru_24ann_24395_24Just = heff_take_reuse_n(v_ann_24395, 1ULL, 1);
      switch (heff_tag_of(v_it1_24405)) {
      case TAG_MkPair: {
        V v_cc_24406 = heff_field(v_it1_24405, 0);
        V v_ty_24407 = heff_field(v_it1_24405, 1);
        heff_take_n(v_it1_24405, 3ULL, 2);
        V v_a_24408 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24406));
        V v_b_24409 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24407}));
        V v_t_24410 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24395_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24409));
        V v_t_24411 = (g_std_2edoc_2e_3c_3e(v_a_24408, v_t_24410));
        v_a_24412 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_t_24411));
        break;
      }
      default: heff_nomatch(v_it1_24405);
      }
      break;
    }
    default: heff_nomatch(v_ann_24395);
    }
    V v_b_24413 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24396));
    V v_t_24414 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24413));
    V v_t_24415 = (g_std_2edoc_2e_3c_3e(v_a_24412, v_t_24414));
    V v_t_24416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24397}));
    V v_t_24417 = (g_std_2edoc_2e_3c_3e(v_t_24415, v_t_24416));
    return (g_std_2edoc_2e_3c_3e(v_t_24404, v_t_24417));
  }
  case TAG_EAssign: {
    V v_x_24418 = heff_field(v_e0_241, 0);
    V v_k_24419 = heff_field(v_e0_241, 1);
    V v_e_24420 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24418));
    V v_b_24422 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_24419));
    V v_t_24423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), v_b_24422));
    V v_t_24424 = (g_std_2edoc_2e_3c_3e(v_a_24421, v_t_24423));
    V v_t_24425 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24420}));
    return (g_std_2edoc_2e_3c_3e(v_t_24424, v_t_24425));
  }
  case TAG_EWhile: {
    V v_kw_24426 = heff_field(v_e0_241, 0);
    V v_c_24427 = heff_field(v_e0_241, 1);
    V v_d_24428 = heff_field(v_e0_241, 2);
    V v_body_24429 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24430 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24426));
    V v_d_24431 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24427}));
    V v_b_24432 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24428));
    V v_t_24433 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), v_b_24432));
    V v_t_24438 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 1, 1, (V[]){v_d_24431})}), v_t_24433));
    V v_t_24439 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), v_t_24438));
    V v_t_24440 = (g_std_2edoc_2e_3c_3e(v_a_24430, v_t_24439));
    V v_t_24441 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24429; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24429); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24440, v_t_24441));
  }
  case TAG_EFor: {
    V v_kw_24442 = heff_field(v_e0_241, 0);
    V v_p_24443 = heff_field(v_e0_241, 1);
    V v_i_24444 = heff_field(v_e0_241, 2);
    V v_c_24445 = heff_field(v_e0_241, 3);
    V v_d_24446 = heff_field(v_e0_241, 4);
    V v_body_24447 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24448 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24442));
    V v_a_24449 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24443; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24443); r_; });
    V v_a_24450 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_i_24444));
    V v_d_24451 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_c_24445}));
    V v_b_24452 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24446));
    V v_t_24453 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), v_b_24452));
    V v_t_24458 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 1, 1, (V[]){v_d_24451})}), v_t_24453));
    V v_t_24459 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), v_t_24458));
    V v_t_24460 = (g_std_2edoc_2e_3c_3e(v_a_24450, v_t_24459));
    V v_t_24461 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), v_t_24460));
    V v_t_24462 = (g_std_2edoc_2e_3c_3e(v_a_24449, v_t_24461));
    V v_t_24463 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), v_t_24462));
    V v_t_24464 = (g_std_2edoc_2e_3c_3e(v_a_24448, v_t_24463));
    V v_t_24465 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24447; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24447); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24464, v_t_24465));
  }
  case TAG_EJump: {
    V v_kw_24466 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_kw_24466));
  }
  case TAG_EReturn: {
    V v_kw_24467 = heff_field(v_e0_241, 0);
    V v_e_24468 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_a_24469 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24467));
    V v_d_24470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24468}));
    V v_t_24471 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24470})));
    return (g_std_2edoc_2e_3c_3e(v_a_24469, v_t_24471));
  }
  case TAG_ENest: {
    V v_o_24472 = heff_field(v_e0_241, 0);
    V v_arrow_24473 = heff_field(v_e0_241, 1);
    V v_e_24474 = heff_field(v_e0_241, 2);
    V v_c_24475 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24476 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24472));
    V v_a_24477 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24473));
    V v_b_24478 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24474}));
    V v_t_24479 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), v_b_24478));
    V v_t_24480 = (g_std_2edoc_2e_3c_3e(v_a_24477, v_t_24479));
    V v_t_24481 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24475));
    V v_t_24482 = (g_std_2edoc_2e_3c_3e(v_t_24480, v_t_24481));
    return (g_std_2edoc_2e_3c_3e(v_t_24476, v_t_24482));
  }
  case TAG_IfThen: {
    V v_kw_24483 = heff_field(v_e0_241, 0);
    V v_c_24484 = heff_field(v_e0_241, 1);
    V v_th_24485 = heff_field(v_e0_241, 2);
    V v_a_24486 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24487 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){v_env_240, v_kw_24483, v_c_24484, v_th_24485, v_a_24486}));
    return (g_std_2edoc_2egroup(v_t_24487));
  }
  case TAG_ETry: {
    V v_kw_24488 = heff_field(v_e0_241, 0);
    V v_ty_24489 = heff_field(v_e0_241, 1);
    V v_body_24490 = heff_field(v_e0_241, 2);
    V v_c_24491 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24492 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24488));
    V v_t_24495;
    switch (heff_tag_of(v_ty_24489)) {
    case TAG_Nothing: {
      v_t_24495 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      break;
    }
    case TAG_Just: {
      V v_t_24493 = heff_field(v_ty_24489, 0);
      V v_ru_24ty_24489_24Just = heff_take_reuse_n(v_ty_24489, 1ULL, 1);
      V v_t_24494 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_t_24493}));
      v_t_24495 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ty_24489_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), v_t_24494));
      break;
    }
    default: heff_nomatch(v_ty_24489);
    }
    V v_d_24496 = ({ V a_0 = heff_dup(v_env_240); V a_1 = MK_INT(0LL); V a_2 = v_body_24490; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24490); r_; });
    V v_t_24497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_c_24491}));
    V v_t_24498 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_24497));
    V v_t_24499 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24496}), v_t_24498));
    V v_t_24500 = (g_std_2edoc_2e_3c_3e(v_t_24495, v_t_24499));
    V v_d_24501 = (g_std_2edoc_2e_3c_3e(v_t_24492, v_t_24500));
    return heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 1, 1, (V[]){v_d_24501})});
  }
  case TAG_ECatch: {
    V v_kw_24506 = heff_field(v_e0_241, 0);
    V v_b_24507 = heff_field(v_e0_241, 1);
    V v_arrow_24508 = heff_field(v_e0_241, 2);
    V v_body_24509 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24510 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24506));
    V v_a_24511 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 2, (V[]){heff_dup(v_env_240), v_b_24507}));
    V v_b_24512 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24508));
    V v_t_24513 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), v_b_24512));
    V v_t_24514 = (g_std_2edoc_2e_3c_3e(v_a_24511, v_t_24513));
    V v_t_24515 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), v_t_24514));
    V v_t_24516 = (g_std_2edoc_2e_3c_3e(v_a_24510, v_t_24515));
    V v_d_24517 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24509; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24509); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24516, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24517})));
  }
  case TAG_EWith: {
    V v_kw_24518 = heff_field(v_e0_241, 0);
    V v_e_24519 = heff_field(v_e0_241, 1);
    V v_a_24520 = heff_field(v_e0_241, 2);
    V v_x_24521 = heff_field(v_e0_241, 3);
    V v_d_24522 = heff_field(v_e0_241, 4);
    V v_body_24523 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_a_24524 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24518));
    V v_d_24525 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24519}));
    V v_a_24526 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_a_24520));
    V v_a_24527 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_x_24521; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_24521); r_; });
    V v_b_24528 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_d_24522));
    V v_t_24529 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), v_b_24528));
    V v_t_24530 = (g_std_2edoc_2e_3c_3e(v_a_24527, v_t_24529));
    V v_t_24531 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), v_t_24530));
    V v_t_24532 = (g_std_2edoc_2e_3c_3e(v_a_24526, v_t_24531));
    V v_t_24533 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), v_t_24532));
    V v_t_24538 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_d_24525})}), v_t_24533));
    V v_t_24539 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), v_t_24538));
    V v_t_24540 = (g_std_2edoc_2e_3c_3e(v_a_24524, v_t_24539));
    V v_t_24541 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_body_24523; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_body_24523); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24540, v_t_24541));
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_env_24542 = args[0];
  V v_e_24543 = args[1];
  V v_t_24544 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24543));
  if ((heff_dup(v_t_24544) == NTAG(TAG_True))) {
    heff_drop(v_t_24544);
    V v_t_24545 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24542, v_e_24543}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), v_t_24545));
  } else {
    heff_drop(v_t_24544);
    V v_t_24546 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24542, v_e_24543}));
    V v_t_24547 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24546));
    return (g_std_2edoc_2egroup(v_t_24547));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_env_24548 = args[0];
  V v_kw_24549 = args[1];
  V v_p_24550 = args[2];
  V v_ann_24551 = args[3];
  V v_eq_24552 = args[4];
  V v_e_24553 = args[5];
  V v_a_24554 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24548), v_kw_24549));
  V v_b_24555 = ({ V a_0 = heff_dup(v_env_24548); V a_1 = v_p_24550; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24550); r_; });
  V v_t_24556 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), v_b_24555));
  V v_t_24557 = (g_std_2edoc_2e_3c_3e(v_a_24554, v_t_24556));
  V v_a_24565;
  switch (heff_tag_of(v_ann_24551)) {
  case TAG_Nothing: {
    v_a_24565 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24558 = heff_field(v_ann_24551, 0);
    V v_ru_24ann_24551_24Just = heff_take_reuse_n(v_ann_24551, 1ULL, 1);
    switch (heff_tag_of(v_it1_24558)) {
    case TAG_MkPair: {
      V v_cc_24559 = heff_field(v_it1_24558, 0);
      V v_ty_24560 = heff_field(v_it1_24558, 1);
      heff_take_n(v_it1_24558, 3ULL, 2);
      V v_a_24561 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24548), v_cc_24559));
      V v_b_24562 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24548), v_ty_24560}));
      V v_t_24563 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24551_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), v_b_24562));
      V v_t_24564 = (g_std_2edoc_2e_3c_3e(v_a_24561, v_t_24563));
      v_a_24565 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), v_t_24564));
      break;
    }
    default: heff_nomatch(v_it1_24558);
    }
    break;
  }
  default: heff_nomatch(v_ann_24551);
  }
  V v_b_24566 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24548), v_eq_24552));
  V v_t_24567 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), v_b_24566));
  V v_t_24568 = (g_std_2edoc_2e_3c_3e(v_a_24565, v_t_24567));
  V v_t_24569 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24548, v_e_24553}));
  V v_t_24570 = (g_std_2edoc_2e_3c_3e(v_t_24568, v_t_24569));
  return (g_std_2edoc_2e_3c_3e(v_t_24557, v_t_24570));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_env_24571 = args[0];
  V v_kw_24572 = args[1];
  V v_p_24573 = args[2];
  V v_ann_24574 = args[3];
  V v_eq_24575 = args[4];
  V v_e_24576 = args[5];
  V v_i_24577 = args[6];
  V v_b_24578 = args[7];
  V v_d_24579 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24571), v_kw_24572, v_p_24573, v_ann_24574, v_eq_24575, v_e_24576}));
  V v_t_24580 = heff_dup(heff_rfield(v_i_24577, 6));
  V v_t_24583;
  if ((heff_dup(v_t_24580) == NTAG(TAG_True))) {
    heff_drop(v_t_24580);
    v_t_24583 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24580);
    V v_t_24581 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24578));
    V v_x1_24582 = heff_get_n(v_t_24581, 6, 9);
    if ((heff_dup(v_x1_24582) == NTAG(TAG_True))) {
      heff_drop(v_x1_24582);
      v_t_24583 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24582);
      v_t_24583 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24584 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24571), v_i_24577));
  V v_b_24742;
  switch (heff_tag_of(v_b_24578)) {
  case TAG_Atom: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EParen: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Named: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Tup: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Seg: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Braces: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Update: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EUSet: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_InstB: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EFSet: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Sum: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ECon: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EField: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ENeg: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ETilde: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_App: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Op: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Ops: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Ann: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_BVar: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_BImp: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_BAnn: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_BPat: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Lam: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Case: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EAlt: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_If: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_Do: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ESBind: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24682 = heff_dup(heff_field(v_b_24578, 0));
    V v_p2_24683 = heff_dup(heff_field(v_b_24578, 1));
    V v_ann2_24684 = heff_dup(heff_field(v_b_24578, 2));
    V v_eq2_24685 = heff_dup(heff_field(v_b_24578, 3));
    V v_e2_24686 = heff_dup(heff_field(v_b_24578, 4));
    V v_it6_24687 = heff_dup(heff_field(v_b_24578, 5));
    switch (heff_tag_of(v_it6_24687)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24682);
      heff_drop(v_p2_24683);
      heff_drop(v_ann2_24684);
      heff_drop(v_eq2_24685);
      heff_drop(v_e2_24686);
      v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
      break;
    }
    case TAG_Just: {
      V v_it61_24688 = heff_field(v_it6_24687, 0);
      heff_take_n(v_it6_24687, 1ULL, 1);
      heff_drop_tag(v_b_24578, 6);
      switch (heff_tag_of(v_it61_24688)) {
      case TAG_MkPair: {
        V v_i2_24689 = heff_field(v_it61_24688, 0);
        V v_b2_24690 = heff_field(v_it61_24688, 1);
        heff_take_n(v_it61_24688, 3ULL, 2);
        v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24571, v_kw2_24682, v_p2_24683, v_ann2_24684, v_eq2_24685, v_e2_24686, v_i2_24689, v_b2_24690}));
        break;
      }
      default: heff_nomatch(v_it61_24688);
      }
      break;
    }
    default: heff_nomatch(v_it6_24687);
    }
    break;
  }
  case TAG_ELetElse: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ELetMut: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EAssign: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EWhile: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EFor: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EJump: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EReturn: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ENest: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_IfThen: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ETry: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_ECatch: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  case TAG_EWith: {
    v_b_24742 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24571, v_b_24578}));
    break;
  }
  default: heff_nomatch(v_b_24578);
  }
  V v_t_24743 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), v_b_24742));
  V v_t_24744 = (g_std_2edoc_2e_3c_3e(v_a_24584, v_t_24743));
  V v_t_24745 = (g_std_2edoc_2e_3c_3e(v_t_24583, v_t_24744));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24579}), v_t_24745));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_i_24754 = args[0];
  V v_k_24753 = heff_env(self)[0];
  V v_d_24752 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24755 = heff_intSub(v_k_24753, v_i_24754);
  if (heff_intEq_c_lent(v_i_24755, MK_INT(0LL), 2)) {
    heff_drop(v_i_24755);
    return v_d_24752;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24755, v_d_24752});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_k_24753 = args[0];
  V v_d_24752 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 2, (V[]){v_k_24753, v_d_24752})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_env_24746 = args[0];
  V v_kw_24747 = args[1];
  V v_c_24748 = args[2];
  V v_th_24749 = args[3];
  V v_a_24750 = args[4];
  V v_a_24751 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24746), v_kw_24747));
  V v_d_24752 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24746), v_c_24748}));
  V v_t_24757 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_d_24752})})));
  V v_t_24758 = (g_std_2edoc_2e_3c_3e(v_a_24751, v_t_24757));
  V v_t_24759 = heff_dup(heff_rfield(v_th_24749, 6));
  V v_t_24762;
  if ((heff_dup(v_t_24759) == NTAG(TAG_True))) {
    heff_drop(v_t_24759);
    v_t_24762 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_24759);
    V v_t_24760 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24750));
    V v_x1_24761 = heff_get_n(v_t_24760, 6, 9);
    if ((heff_dup(v_x1_24761) == NTAG(TAG_True))) {
      heff_drop(v_x1_24761);
      v_t_24762 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24761);
      v_t_24762 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_24763 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24746), v_th_24749));
  V v_d_24764 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24746, v_a_24750}));
  V v_t_24765 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24764})));
  V v_t_24766 = (g_std_2edoc_2e_3c_3e(v_a_24763, v_t_24765));
  V v_t_24767 = (g_std_2edoc_2e_3c_3e(v_t_24762, v_t_24766));
  V v_t_24768 = (g_std_2edoc_2e_3c_3e(v_t_24758, v_t_24767));
  return (g_std_2edoc_2egroup(v_t_24768));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_env_24769 = args[0];
  V v_el_24770 = args[1];
  V v_b_24771 = args[2];
  switch (heff_tag_of(v_b_24771)) {
  case TAG_Atom: {
    V v_t_24773 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24776;
    if ((heff_dup(v_t_24773) == NTAG(TAG_True))) {
      heff_drop(v_t_24773);
      v_t_24776 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24773);
      V v_t_24774 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24775 = heff_get_n(v_t_24774, 6, 9);
      if ((heff_dup(v_x1_24775) == NTAG(TAG_True))) {
        heff_drop(v_x1_24775);
        v_t_24776 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24775);
        v_t_24776 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24777 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24778 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24779 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24778})));
    V v_t_24780 = (g_std_2edoc_2e_3c_3e(v_a_24777, v_t_24779));
    return (g_std_2edoc_2e_3c_3e(v_t_24776, v_t_24780));
  }
  case TAG_EParen: {
    V v_t_24784 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24787;
    if ((heff_dup(v_t_24784) == NTAG(TAG_True))) {
      heff_drop(v_t_24784);
      v_t_24787 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24784);
      V v_t_24785 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24786 = heff_get_n(v_t_24785, 6, 9);
      if ((heff_dup(v_x1_24786) == NTAG(TAG_True))) {
        heff_drop(v_x1_24786);
        v_t_24787 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24786);
        v_t_24787 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24788 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24789 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24790 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24789})));
    V v_t_24791 = (g_std_2edoc_2e_3c_3e(v_a_24788, v_t_24790));
    return (g_std_2edoc_2e_3c_3e(v_t_24787, v_t_24791));
  }
  case TAG_Named: {
    V v_t_24797 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24800;
    if ((heff_dup(v_t_24797) == NTAG(TAG_True))) {
      heff_drop(v_t_24797);
      v_t_24800 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24797);
      V v_t_24798 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24799 = heff_get_n(v_t_24798, 6, 9);
      if ((heff_dup(v_x1_24799) == NTAG(TAG_True))) {
        heff_drop(v_x1_24799);
        v_t_24800 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24799);
        v_t_24800 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24801 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24802 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24803 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24802})));
    V v_t_24804 = (g_std_2edoc_2e_3c_3e(v_a_24801, v_t_24803));
    return (g_std_2edoc_2e_3c_3e(v_t_24800, v_t_24804));
  }
  case TAG_Tup: {
    V v_t_24809 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24812;
    if ((heff_dup(v_t_24809) == NTAG(TAG_True))) {
      heff_drop(v_t_24809);
      v_t_24812 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24809);
      V v_t_24810 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24811 = heff_get_n(v_t_24810, 6, 9);
      if ((heff_dup(v_x1_24811) == NTAG(TAG_True))) {
        heff_drop(v_x1_24811);
        v_t_24812 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24811);
        v_t_24812 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24813 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24814 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24815 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24814})));
    V v_t_24816 = (g_std_2edoc_2e_3c_3e(v_a_24813, v_t_24815));
    return (g_std_2edoc_2e_3c_3e(v_t_24812, v_t_24816));
  }
  case TAG_Seg: {
    V v_t_24820 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24823;
    if ((heff_dup(v_t_24820) == NTAG(TAG_True))) {
      heff_drop(v_t_24820);
      v_t_24823 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24820);
      V v_t_24821 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24822 = heff_get_n(v_t_24821, 6, 9);
      if ((heff_dup(v_x1_24822) == NTAG(TAG_True))) {
        heff_drop(v_x1_24822);
        v_t_24823 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24822);
        v_t_24823 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24824 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24825 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24826 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24825})));
    V v_t_24827 = (g_std_2edoc_2e_3c_3e(v_a_24824, v_t_24826));
    return (g_std_2edoc_2e_3c_3e(v_t_24823, v_t_24827));
  }
  case TAG_Braces: {
    V v_t_24832 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24835;
    if ((heff_dup(v_t_24832) == NTAG(TAG_True))) {
      heff_drop(v_t_24832);
      v_t_24835 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24832);
      V v_t_24833 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24834 = heff_get_n(v_t_24833, 6, 9);
      if ((heff_dup(v_x1_24834) == NTAG(TAG_True))) {
        heff_drop(v_x1_24834);
        v_t_24835 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24834);
        v_t_24835 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24836 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24837 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24838 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24837})));
    V v_t_24839 = (g_std_2edoc_2e_3c_3e(v_a_24836, v_t_24838));
    return (g_std_2edoc_2e_3c_3e(v_t_24835, v_t_24839));
  }
  case TAG_Update: {
    V v_t_24846 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24849;
    if ((heff_dup(v_t_24846) == NTAG(TAG_True))) {
      heff_drop(v_t_24846);
      v_t_24849 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24846);
      V v_t_24847 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24848 = heff_get_n(v_t_24847, 6, 9);
      if ((heff_dup(v_x1_24848) == NTAG(TAG_True))) {
        heff_drop(v_x1_24848);
        v_t_24849 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24848);
        v_t_24849 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24850 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24851 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24852 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24851})));
    V v_t_24853 = (g_std_2edoc_2e_3c_3e(v_a_24850, v_t_24852));
    return (g_std_2edoc_2e_3c_3e(v_t_24849, v_t_24853));
  }
  case TAG_EUSet: {
    V v_t_24857 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24860;
    if ((heff_dup(v_t_24857) == NTAG(TAG_True))) {
      heff_drop(v_t_24857);
      v_t_24860 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24857);
      V v_t_24858 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24859 = heff_get_n(v_t_24858, 6, 9);
      if ((heff_dup(v_x1_24859) == NTAG(TAG_True))) {
        heff_drop(v_x1_24859);
        v_t_24860 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24859);
        v_t_24860 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24861 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24862 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24863 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24862})));
    V v_t_24864 = (g_std_2edoc_2e_3c_3e(v_a_24861, v_t_24863));
    return (g_std_2edoc_2e_3c_3e(v_t_24860, v_t_24864));
  }
  case TAG_InstB: {
    V v_t_24870 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24873;
    if ((heff_dup(v_t_24870) == NTAG(TAG_True))) {
      heff_drop(v_t_24870);
      v_t_24873 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24870);
      V v_t_24871 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24872 = heff_get_n(v_t_24871, 6, 9);
      if ((heff_dup(v_x1_24872) == NTAG(TAG_True))) {
        heff_drop(v_x1_24872);
        v_t_24873 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24872);
        v_t_24873 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24874 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24875 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24876 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24875})));
    V v_t_24877 = (g_std_2edoc_2e_3c_3e(v_a_24874, v_t_24876));
    return (g_std_2edoc_2e_3c_3e(v_t_24873, v_t_24877));
  }
  case TAG_EFSet: {
    V v_t_24881 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24884;
    if ((heff_dup(v_t_24881) == NTAG(TAG_True))) {
      heff_drop(v_t_24881);
      v_t_24884 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24881);
      V v_t_24882 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24883 = heff_get_n(v_t_24882, 6, 9);
      if ((heff_dup(v_x1_24883) == NTAG(TAG_True))) {
        heff_drop(v_x1_24883);
        v_t_24884 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24883);
        v_t_24884 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24885 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24886 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24887 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24886})));
    V v_t_24888 = (g_std_2edoc_2e_3c_3e(v_a_24885, v_t_24887));
    return (g_std_2edoc_2e_3c_3e(v_t_24884, v_t_24888));
  }
  case TAG_EFDefault: {
    V v_t_24892 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24895;
    if ((heff_dup(v_t_24892) == NTAG(TAG_True))) {
      heff_drop(v_t_24892);
      v_t_24895 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24892);
      V v_t_24893 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24894 = heff_get_n(v_t_24893, 6, 9);
      if ((heff_dup(v_x1_24894) == NTAG(TAG_True))) {
        heff_drop(v_x1_24894);
        v_t_24895 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24894);
        v_t_24895 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24896 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24897 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24898 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24897})));
    V v_t_24899 = (g_std_2edoc_2e_3c_3e(v_a_24896, v_t_24898));
    return (g_std_2edoc_2e_3c_3e(v_t_24895, v_t_24899));
  }
  case TAG_Sum: {
    V v_t_24905 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24908;
    if ((heff_dup(v_t_24905) == NTAG(TAG_True))) {
      heff_drop(v_t_24905);
      v_t_24908 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24905);
      V v_t_24906 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24907 = heff_get_n(v_t_24906, 6, 9);
      if ((heff_dup(v_x1_24907) == NTAG(TAG_True))) {
        heff_drop(v_x1_24907);
        v_t_24908 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24907);
        v_t_24908 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24909 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24910 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24911 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24910})));
    V v_t_24912 = (g_std_2edoc_2e_3c_3e(v_a_24909, v_t_24911));
    return (g_std_2edoc_2e_3c_3e(v_t_24908, v_t_24912));
  }
  case TAG_ECon: {
    V v_t_24915 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24918;
    if ((heff_dup(v_t_24915) == NTAG(TAG_True))) {
      heff_drop(v_t_24915);
      v_t_24918 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24915);
      V v_t_24916 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24917 = heff_get_n(v_t_24916, 6, 9);
      if ((heff_dup(v_x1_24917) == NTAG(TAG_True))) {
        heff_drop(v_x1_24917);
        v_t_24918 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24917);
        v_t_24918 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24919 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24920 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24921 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24920})));
    V v_t_24922 = (g_std_2edoc_2e_3c_3e(v_a_24919, v_t_24921));
    return (g_std_2edoc_2e_3c_3e(v_t_24918, v_t_24922));
  }
  case TAG_EField: {
    V v_t_24925 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24928;
    if ((heff_dup(v_t_24925) == NTAG(TAG_True))) {
      heff_drop(v_t_24925);
      v_t_24928 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24925);
      V v_t_24926 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24927 = heff_get_n(v_t_24926, 6, 9);
      if ((heff_dup(v_x1_24927) == NTAG(TAG_True))) {
        heff_drop(v_x1_24927);
        v_t_24928 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24927);
        v_t_24928 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24929 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24930 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24931 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24930})));
    V v_t_24932 = (g_std_2edoc_2e_3c_3e(v_a_24929, v_t_24931));
    return (g_std_2edoc_2e_3c_3e(v_t_24928, v_t_24932));
  }
  case TAG_ENeg: {
    V v_t_24935 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24938;
    if ((heff_dup(v_t_24935) == NTAG(TAG_True))) {
      heff_drop(v_t_24935);
      v_t_24938 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24935);
      V v_t_24936 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24937 = heff_get_n(v_t_24936, 6, 9);
      if ((heff_dup(v_x1_24937) == NTAG(TAG_True))) {
        heff_drop(v_x1_24937);
        v_t_24938 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24937);
        v_t_24938 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24939 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24940 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24941 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24940})));
    V v_t_24942 = (g_std_2edoc_2e_3c_3e(v_a_24939, v_t_24941));
    return (g_std_2edoc_2e_3c_3e(v_t_24938, v_t_24942));
  }
  case TAG_ETilde: {
    V v_t_24945 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24948;
    if ((heff_dup(v_t_24945) == NTAG(TAG_True))) {
      heff_drop(v_t_24945);
      v_t_24948 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24945);
      V v_t_24946 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24947 = heff_get_n(v_t_24946, 6, 9);
      if ((heff_dup(v_x1_24947) == NTAG(TAG_True))) {
        heff_drop(v_x1_24947);
        v_t_24948 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24947);
        v_t_24948 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24949 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24950 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24951 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24950})));
    V v_t_24952 = (g_std_2edoc_2e_3c_3e(v_a_24949, v_t_24951));
    return (g_std_2edoc_2e_3c_3e(v_t_24948, v_t_24952));
  }
  case TAG_App: {
    V v_t_24955 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24958;
    if ((heff_dup(v_t_24955) == NTAG(TAG_True))) {
      heff_drop(v_t_24955);
      v_t_24958 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24955);
      V v_t_24956 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24957 = heff_get_n(v_t_24956, 6, 9);
      if ((heff_dup(v_x1_24957) == NTAG(TAG_True))) {
        heff_drop(v_x1_24957);
        v_t_24958 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24957);
        v_t_24958 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24959 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24960 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24961 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24960})));
    V v_t_24962 = (g_std_2edoc_2e_3c_3e(v_a_24959, v_t_24961));
    return (g_std_2edoc_2e_3c_3e(v_t_24958, v_t_24962));
  }
  case TAG_Op: {
    V v_t_24966 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24969;
    if ((heff_dup(v_t_24966) == NTAG(TAG_True))) {
      heff_drop(v_t_24966);
      v_t_24969 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24966);
      V v_t_24967 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24968 = heff_get_n(v_t_24967, 6, 9);
      if ((heff_dup(v_x1_24968) == NTAG(TAG_True))) {
        heff_drop(v_x1_24968);
        v_t_24969 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24968);
        v_t_24969 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24970 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24971 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24972 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24971})));
    V v_t_24973 = (g_std_2edoc_2e_3c_3e(v_a_24970, v_t_24972));
    return (g_std_2edoc_2e_3c_3e(v_t_24969, v_t_24973));
  }
  case TAG_Ops: {
    V v_t_24976 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24979;
    if ((heff_dup(v_t_24976) == NTAG(TAG_True))) {
      heff_drop(v_t_24976);
      v_t_24979 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24976);
      V v_t_24977 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24978 = heff_get_n(v_t_24977, 6, 9);
      if ((heff_dup(v_x1_24978) == NTAG(TAG_True))) {
        heff_drop(v_x1_24978);
        v_t_24979 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24978);
        v_t_24979 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24980 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24981 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24982 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24981})));
    V v_t_24983 = (g_std_2edoc_2e_3c_3e(v_a_24980, v_t_24982));
    return (g_std_2edoc_2e_3c_3e(v_t_24979, v_t_24983));
  }
  case TAG_OpRhs: {
    V v_t_24986 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_24989;
    if ((heff_dup(v_t_24986) == NTAG(TAG_True))) {
      heff_drop(v_t_24986);
      v_t_24989 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24986);
      V v_t_24987 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24988 = heff_get_n(v_t_24987, 6, 9);
      if ((heff_dup(v_x1_24988) == NTAG(TAG_True))) {
        heff_drop(v_x1_24988);
        v_t_24989 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24988);
        v_t_24989 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_24990 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_24991 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_24992 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24991})));
    V v_t_24993 = (g_std_2edoc_2e_3c_3e(v_a_24990, v_t_24992));
    return (g_std_2edoc_2e_3c_3e(v_t_24989, v_t_24993));
  }
  case TAG_Ann: {
    V v_t_24997 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241000;
    if ((heff_dup(v_t_24997) == NTAG(TAG_True))) {
      heff_drop(v_t_24997);
      v_t_241000 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_24997);
      V v_t_24998 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_24999 = heff_get_n(v_t_24998, 6, 9);
      if ((heff_dup(v_x1_24999) == NTAG(TAG_True))) {
        heff_drop(v_x1_24999);
        v_t_241000 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24999);
        v_t_241000 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241001 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241003 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241002})));
    V v_t_241004 = (g_std_2edoc_2e_3c_3e(v_a_241001, v_t_241003));
    return (g_std_2edoc_2e_3c_3e(v_t_241000, v_t_241004));
  }
  case TAG_BVar: {
    V v_t_241006 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241009;
    if ((heff_dup(v_t_241006) == NTAG(TAG_True))) {
      heff_drop(v_t_241006);
      v_t_241009 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241006);
      V v_t_241007 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241008 = heff_get_n(v_t_241007, 6, 9);
      if ((heff_dup(v_x1_241008) == NTAG(TAG_True))) {
        heff_drop(v_x1_241008);
        v_t_241009 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241008);
        v_t_241009 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241010 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241011 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241012 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241011})));
    V v_t_241013 = (g_std_2edoc_2e_3c_3e(v_a_241010, v_t_241012));
    return (g_std_2edoc_2e_3c_3e(v_t_241009, v_t_241013));
  }
  case TAG_BImp: {
    V v_t_241017 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241020;
    if ((heff_dup(v_t_241017) == NTAG(TAG_True))) {
      heff_drop(v_t_241017);
      v_t_241020 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241017);
      V v_t_241018 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241019 = heff_get_n(v_t_241018, 6, 9);
      if ((heff_dup(v_x1_241019) == NTAG(TAG_True))) {
        heff_drop(v_x1_241019);
        v_t_241020 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241019);
        v_t_241020 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241021 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241022 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241023 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241022})));
    V v_t_241024 = (g_std_2edoc_2e_3c_3e(v_a_241021, v_t_241023));
    return (g_std_2edoc_2e_3c_3e(v_t_241020, v_t_241024));
  }
  case TAG_BAnn: {
    V v_t_241030 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241033;
    if ((heff_dup(v_t_241030) == NTAG(TAG_True))) {
      heff_drop(v_t_241030);
      v_t_241033 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241030);
      V v_t_241031 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241032 = heff_get_n(v_t_241031, 6, 9);
      if ((heff_dup(v_x1_241032) == NTAG(TAG_True))) {
        heff_drop(v_x1_241032);
        v_t_241033 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241032);
        v_t_241033 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241034 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241035 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241036 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241035})));
    V v_t_241037 = (g_std_2edoc_2e_3c_3e(v_a_241034, v_t_241036));
    return (g_std_2edoc_2e_3c_3e(v_t_241033, v_t_241037));
  }
  case TAG_BPat: {
    V v_t_241039 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241042;
    if ((heff_dup(v_t_241039) == NTAG(TAG_True))) {
      heff_drop(v_t_241039);
      v_t_241042 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241039);
      V v_t_241040 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241041 = heff_get_n(v_t_241040, 6, 9);
      if ((heff_dup(v_x1_241041) == NTAG(TAG_True))) {
        heff_drop(v_x1_241041);
        v_t_241042 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241041);
        v_t_241042 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241043 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241044 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241045 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241044})));
    V v_t_241046 = (g_std_2edoc_2e_3c_3e(v_a_241043, v_t_241045));
    return (g_std_2edoc_2e_3c_3e(v_t_241042, v_t_241046));
  }
  case TAG_Lam: {
    V v_t_241051 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241054;
    if ((heff_dup(v_t_241051) == NTAG(TAG_True))) {
      heff_drop(v_t_241051);
      v_t_241054 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241051);
      V v_t_241052 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241053 = heff_get_n(v_t_241052, 6, 9);
      if ((heff_dup(v_x1_241053) == NTAG(TAG_True))) {
        heff_drop(v_x1_241053);
        v_t_241054 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241053);
        v_t_241054 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241055 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241056 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241057 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241056})));
    V v_t_241058 = (g_std_2edoc_2e_3c_3e(v_a_241055, v_t_241057));
    return (g_std_2edoc_2e_3c_3e(v_t_241054, v_t_241058));
  }
  case TAG_Case: {
    V v_t_241063 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241066;
    if ((heff_dup(v_t_241063) == NTAG(TAG_True))) {
      heff_drop(v_t_241063);
      v_t_241066 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241063);
      V v_t_241064 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241065 = heff_get_n(v_t_241064, 6, 9);
      if ((heff_dup(v_x1_241065) == NTAG(TAG_True))) {
        heff_drop(v_x1_241065);
        v_t_241066 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241065);
        v_t_241066 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241067 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241068 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241069 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241068})));
    V v_t_241070 = (g_std_2edoc_2e_3c_3e(v_a_241067, v_t_241069));
    return (g_std_2edoc_2e_3c_3e(v_t_241066, v_t_241070));
  }
  case TAG_EAlt: {
    V v_t_241074 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241077;
    if ((heff_dup(v_t_241074) == NTAG(TAG_True))) {
      heff_drop(v_t_241074);
      v_t_241077 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241074);
      V v_t_241075 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241076 = heff_get_n(v_t_241075, 6, 9);
      if ((heff_dup(v_x1_241076) == NTAG(TAG_True))) {
        heff_drop(v_x1_241076);
        v_t_241077 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241076);
        v_t_241077 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241078 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241079 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241080 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241079})));
    V v_t_241081 = (g_std_2edoc_2e_3c_3e(v_a_241078, v_t_241080));
    return (g_std_2edoc_2e_3c_3e(v_t_241077, v_t_241081));
  }
  case TAG_If: {
    V v_kw_241082 = heff_dup(heff_field(v_b_24771, 0));
    V v_c_241083 = heff_dup(heff_field(v_b_24771, 1));
    V v_th_241084 = heff_dup(heff_field(v_b_24771, 2));
    V v_a_241085 = heff_dup(heff_field(v_b_24771, 3));
    V v_el2_241086 = heff_dup(heff_field(v_b_24771, 4));
    V v_b2_241087 = heff_dup(heff_field(v_b_24771, 5));
    V v_t_241088 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241091;
    if ((heff_dup(v_t_241088) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24771, 6);
      heff_drop(v_t_241088);
      v_t_241091 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241088);
      V v_t_241089 = ({ V a_0 = v_b_24771; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24771, 6); r_; });
      V v_x1_241090 = heff_get_n(v_t_241089, 6, 9);
      if ((heff_dup(v_x1_241090) == NTAG(TAG_True))) {
        heff_drop(v_x1_241090);
        v_t_241091 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241090);
        v_t_241091 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241092 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_b_241093 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24769), v_kw_241082, v_c_241083, v_th_241084, v_a_241085}));
    V v_t_241094 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241093));
    V v_t_241095 = (g_std_2edoc_2e_3c_3e(v_a_241092, v_t_241094));
    V v_t_241096 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24769, v_el2_241086, v_b2_241087}));
    V v_t_241097 = (g_std_2edoc_2e_3c_3e(v_t_241095, v_t_241096));
    return (g_std_2edoc_2e_3c_3e(v_t_241091, v_t_241097));
  }
  case TAG_Do: {
    V v_t_241100 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241103;
    if ((heff_dup(v_t_241100) == NTAG(TAG_True))) {
      heff_drop(v_t_241100);
      v_t_241103 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241100);
      V v_t_241101 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241102 = heff_get_n(v_t_241101, 6, 9);
      if ((heff_dup(v_x1_241102) == NTAG(TAG_True))) {
        heff_drop(v_x1_241102);
        v_t_241103 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241102);
        v_t_241103 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241104 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241105 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241106 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241105})));
    V v_t_241107 = (g_std_2edoc_2e_3c_3e(v_a_241104, v_t_241106));
    return (g_std_2edoc_2e_3c_3e(v_t_241103, v_t_241107));
  }
  case TAG_ESBind: {
    V v_t_241111 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241114;
    if ((heff_dup(v_t_241111) == NTAG(TAG_True))) {
      heff_drop(v_t_241111);
      v_t_241114 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241111);
      V v_t_241112 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241113 = heff_get_n(v_t_241112, 6, 9);
      if ((heff_dup(v_x1_241113) == NTAG(TAG_True))) {
        heff_drop(v_x1_241113);
        v_t_241114 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241113);
        v_t_241114 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241115 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241116 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241116})));
    V v_t_241118 = (g_std_2edoc_2e_3c_3e(v_a_241115, v_t_241117));
    return (g_std_2edoc_2e_3c_3e(v_t_241114, v_t_241118));
  }
  case TAG_ELet: {
    V v_t_241125 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241128;
    if ((heff_dup(v_t_241125) == NTAG(TAG_True))) {
      heff_drop(v_t_241125);
      v_t_241128 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241125);
      V v_t_241126 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241127 = heff_get_n(v_t_241126, 6, 9);
      if ((heff_dup(v_x1_241127) == NTAG(TAG_True))) {
        heff_drop(v_x1_241127);
        v_t_241128 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241127);
        v_t_241128 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241129 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241130 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241131 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241130})));
    V v_t_241132 = (g_std_2edoc_2e_3c_3e(v_a_241129, v_t_241131));
    return (g_std_2edoc_2e_3c_3e(v_t_241128, v_t_241132));
  }
  case TAG_ELetElse: {
    V v_t_241140 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241143;
    if ((heff_dup(v_t_241140) == NTAG(TAG_True))) {
      heff_drop(v_t_241140);
      v_t_241143 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241140);
      V v_t_241141 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241142 = heff_get_n(v_t_241141, 6, 9);
      if ((heff_dup(v_x1_241142) == NTAG(TAG_True))) {
        heff_drop(v_x1_241142);
        v_t_241143 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241142);
        v_t_241143 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241144 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241145 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241146 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241145})));
    V v_t_241147 = (g_std_2edoc_2e_3c_3e(v_a_241144, v_t_241146));
    return (g_std_2edoc_2e_3c_3e(v_t_241143, v_t_241147));
  }
  case TAG_ELetMut: {
    V v_t_241154 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241157;
    if ((heff_dup(v_t_241154) == NTAG(TAG_True))) {
      heff_drop(v_t_241154);
      v_t_241157 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241154);
      V v_t_241155 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241156 = heff_get_n(v_t_241155, 6, 9);
      if ((heff_dup(v_x1_241156) == NTAG(TAG_True))) {
        heff_drop(v_x1_241156);
        v_t_241157 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241156);
        v_t_241157 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241158 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241159 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241160 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241159})));
    V v_t_241161 = (g_std_2edoc_2e_3c_3e(v_a_241158, v_t_241160));
    return (g_std_2edoc_2e_3c_3e(v_t_241157, v_t_241161));
  }
  case TAG_EAssign: {
    V v_t_241165 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241168;
    if ((heff_dup(v_t_241165) == NTAG(TAG_True))) {
      heff_drop(v_t_241165);
      v_t_241168 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241165);
      V v_t_241166 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241167 = heff_get_n(v_t_241166, 6, 9);
      if ((heff_dup(v_x1_241167) == NTAG(TAG_True))) {
        heff_drop(v_x1_241167);
        v_t_241168 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241167);
        v_t_241168 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241169 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241170 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241171 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241170})));
    V v_t_241172 = (g_std_2edoc_2e_3c_3e(v_a_241169, v_t_241171));
    return (g_std_2edoc_2e_3c_3e(v_t_241168, v_t_241172));
  }
  case TAG_EWhile: {
    V v_t_241177 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241180;
    if ((heff_dup(v_t_241177) == NTAG(TAG_True))) {
      heff_drop(v_t_241177);
      v_t_241180 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241177);
      V v_t_241178 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241179 = heff_get_n(v_t_241178, 6, 9);
      if ((heff_dup(v_x1_241179) == NTAG(TAG_True))) {
        heff_drop(v_x1_241179);
        v_t_241180 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241179);
        v_t_241180 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241181 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241182 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241183 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241182})));
    V v_t_241184 = (g_std_2edoc_2e_3c_3e(v_a_241181, v_t_241183));
    return (g_std_2edoc_2e_3c_3e(v_t_241180, v_t_241184));
  }
  case TAG_EFor: {
    V v_t_241191 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241194;
    if ((heff_dup(v_t_241191) == NTAG(TAG_True))) {
      heff_drop(v_t_241191);
      v_t_241194 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241191);
      V v_t_241192 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241193 = heff_get_n(v_t_241192, 6, 9);
      if ((heff_dup(v_x1_241193) == NTAG(TAG_True))) {
        heff_drop(v_x1_241193);
        v_t_241194 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241193);
        v_t_241194 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241195 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241196 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241197 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241196})));
    V v_t_241198 = (g_std_2edoc_2e_3c_3e(v_a_241195, v_t_241197));
    return (g_std_2edoc_2e_3c_3e(v_t_241194, v_t_241198));
  }
  case TAG_EJump: {
    V v_t_241200 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241203;
    if ((heff_dup(v_t_241200) == NTAG(TAG_True))) {
      heff_drop(v_t_241200);
      v_t_241203 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241200);
      V v_t_241201 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241202 = heff_get_n(v_t_241201, 6, 9);
      if ((heff_dup(v_x1_241202) == NTAG(TAG_True))) {
        heff_drop(v_x1_241202);
        v_t_241203 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241202);
        v_t_241203 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241204 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241205 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241206 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241205})));
    V v_t_241207 = (g_std_2edoc_2e_3c_3e(v_a_241204, v_t_241206));
    return (g_std_2edoc_2e_3c_3e(v_t_241203, v_t_241207));
  }
  case TAG_EReturn: {
    V v_t_241210 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241213;
    if ((heff_dup(v_t_241210) == NTAG(TAG_True))) {
      heff_drop(v_t_241210);
      v_t_241213 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241210);
      V v_t_241211 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241212 = heff_get_n(v_t_241211, 6, 9);
      if ((heff_dup(v_x1_241212) == NTAG(TAG_True))) {
        heff_drop(v_x1_241212);
        v_t_241213 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241212);
        v_t_241213 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241214 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241215 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241216 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241215})));
    V v_t_241217 = (g_std_2edoc_2e_3c_3e(v_a_241214, v_t_241216));
    return (g_std_2edoc_2e_3c_3e(v_t_241213, v_t_241217));
  }
  case TAG_ENest: {
    V v_t_241222 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241225;
    if ((heff_dup(v_t_241222) == NTAG(TAG_True))) {
      heff_drop(v_t_241222);
      v_t_241225 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241222);
      V v_t_241223 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241224 = heff_get_n(v_t_241223, 6, 9);
      if ((heff_dup(v_x1_241224) == NTAG(TAG_True))) {
        heff_drop(v_x1_241224);
        v_t_241225 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241224);
        v_t_241225 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241228 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241227})));
    V v_t_241229 = (g_std_2edoc_2e_3c_3e(v_a_241226, v_t_241228));
    return (g_std_2edoc_2e_3c_3e(v_t_241225, v_t_241229));
  }
  case TAG_IfThen: {
    V v_t_241234 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241237;
    if ((heff_dup(v_t_241234) == NTAG(TAG_True))) {
      heff_drop(v_t_241234);
      v_t_241237 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241234);
      V v_t_241235 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241236 = heff_get_n(v_t_241235, 6, 9);
      if ((heff_dup(v_x1_241236) == NTAG(TAG_True))) {
        heff_drop(v_x1_241236);
        v_t_241237 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241236);
        v_t_241237 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241238 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241239 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241240 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241239})));
    V v_t_241241 = (g_std_2edoc_2e_3c_3e(v_a_241238, v_t_241240));
    return (g_std_2edoc_2e_3c_3e(v_t_241237, v_t_241241));
  }
  case TAG_ETry: {
    V v_t_241246 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241249;
    if ((heff_dup(v_t_241246) == NTAG(TAG_True))) {
      heff_drop(v_t_241246);
      v_t_241249 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241246);
      V v_t_241247 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241248 = heff_get_n(v_t_241247, 6, 9);
      if ((heff_dup(v_x1_241248) == NTAG(TAG_True))) {
        heff_drop(v_x1_241248);
        v_t_241249 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241248);
        v_t_241249 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241250 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241251 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241252 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241251})));
    V v_t_241253 = (g_std_2edoc_2e_3c_3e(v_a_241250, v_t_241252));
    return (g_std_2edoc_2e_3c_3e(v_t_241249, v_t_241253));
  }
  case TAG_ECatch: {
    V v_t_241258 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241261;
    if ((heff_dup(v_t_241258) == NTAG(TAG_True))) {
      heff_drop(v_t_241258);
      v_t_241261 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241258);
      V v_t_241259 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241260 = heff_get_n(v_t_241259, 6, 9);
      if ((heff_dup(v_x1_241260) == NTAG(TAG_True))) {
        heff_drop(v_x1_241260);
        v_t_241261 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241260);
        v_t_241261 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241262 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241263 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241264 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241263})));
    V v_t_241265 = (g_std_2edoc_2e_3c_3e(v_a_241262, v_t_241264));
    return (g_std_2edoc_2e_3c_3e(v_t_241261, v_t_241265));
  }
  case TAG_EWith: {
    V v_t_241272 = heff_dup(heff_rfield(v_el_24770, 6));
    V v_t_241275;
    if ((heff_dup(v_t_241272) == NTAG(TAG_True))) {
      heff_drop(v_t_241272);
      v_t_241275 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_241272);
      V v_t_241273 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24771));
      V v_x1_241274 = heff_get_n(v_t_241273, 6, 9);
      if ((heff_dup(v_x1_241274) == NTAG(TAG_True))) {
        heff_drop(v_x1_241274);
        v_t_241275 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_241274);
        v_t_241275 = heff_dup(g_std_2edoc_2eline_get());
      }
    }
    V v_a_241276 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24769), v_el_24770));
    V v_d_241277 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24769, v_b_24771}));
    V v_t_241278 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241277})));
    V v_t_241279 = (g_std_2edoc_2e_3c_3e(v_a_241276, v_t_241278));
    return (g_std_2edoc_2e_3c_3e(v_t_241275, v_t_241279));
  }
  default: return heff_nomatch(v_b_24771);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241291 = args[0];
  V v_one_241290 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241292 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241291));
  V v_x1_241293 = heff_get_n(v_t_241292, 6, 9);
  V v_t_241294;
  if ((heff_dup(v_x1_241293) == NTAG(TAG_True))) {
    heff_drop(v_x1_241293);
    v_t_241294 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241293);
    v_t_241294 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241295 = heff_tr(heff_call(v_one_241290, 1, (V[]){v_a_241291}));
  return (g_std_2edoc_2e_3c_3e(v_t_241294, v_t_241295));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241303 = args[0];
  V v_one_241302 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241304 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241303));
  V v_x1_241305 = heff_get_n(v_t_241304, 6, 9);
  V v_t_241306;
  if ((heff_dup(v_x1_241305) == NTAG(TAG_True))) {
    heff_drop(v_x1_241305);
    v_t_241306 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241305);
    v_t_241306 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241307 = heff_tr(heff_call(v_one_241302, 1, (V[]){v_a_241303}));
  return (g_std_2edoc_2e_3c_3e(v_t_241306, v_t_241307));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241316 = args[0];
  V v_one_241315 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241317 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241316));
  V v_x1_241318 = heff_get_n(v_t_241317, 6, 9);
  V v_t_241319;
  if ((heff_dup(v_x1_241318) == NTAG(TAG_True))) {
    heff_drop(v_x1_241318);
    v_t_241319 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241318);
    v_t_241319 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241320 = heff_tr(heff_call(v_one_241315, 1, (V[]){v_a_241316}));
  return (g_std_2edoc_2e_3c_3e(v_t_241319, v_t_241320));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241332 = args[0];
  V v_one_241331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241333 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241332));
  V v_x1_241334 = heff_get_n(v_t_241333, 6, 9);
  V v_t_241335;
  if ((heff_dup(v_x1_241334) == NTAG(TAG_True))) {
    heff_drop(v_x1_241334);
    v_t_241335 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241334);
    v_t_241335 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241336 = heff_tr(heff_call(v_one_241331, 1, (V[]){v_a_241332}));
  return (g_std_2edoc_2e_3c_3e(v_t_241335, v_t_241336));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241347 = args[0];
  V v_one_241346 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241348 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241347));
  V v_x1_241349 = heff_get_n(v_t_241348, 6, 9);
  V v_t_241350;
  if ((heff_dup(v_x1_241349) == NTAG(TAG_True))) {
    heff_drop(v_x1_241349);
    v_t_241350 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241349);
    v_t_241350 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241351 = heff_tr(heff_call(v_one_241346, 1, (V[]){v_a_241347}));
  return (g_std_2edoc_2e_3c_3e(v_t_241350, v_t_241351));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241359 = args[0];
  V v_one_241358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241360 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241359));
  V v_x1_241361 = heff_get_n(v_t_241360, 6, 9);
  V v_t_241362;
  if ((heff_dup(v_x1_241361) == NTAG(TAG_True))) {
    heff_drop(v_x1_241361);
    v_t_241362 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241361);
    v_t_241362 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241363 = heff_tr(heff_call(v_one_241358, 1, (V[]){v_a_241359}));
  return (g_std_2edoc_2e_3c_3e(v_t_241362, v_t_241363));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241373 = args[0];
  V v_one_241372 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241374 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241373));
  V v_x1_241375 = heff_get_n(v_t_241374, 6, 9);
  V v_t_241376;
  if ((heff_dup(v_x1_241375) == NTAG(TAG_True))) {
    heff_drop(v_x1_241375);
    v_t_241376 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241375);
    v_t_241376 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241377 = heff_tr(heff_call(v_one_241372, 1, (V[]){v_a_241373}));
  return (g_std_2edoc_2e_3c_3e(v_t_241376, v_t_241377));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241385 = args[0];
  V v_one_241384 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241386 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241385));
  V v_x1_241387 = heff_get_n(v_t_241386, 6, 9);
  V v_t_241388;
  if ((heff_dup(v_x1_241387) == NTAG(TAG_True))) {
    heff_drop(v_x1_241387);
    v_t_241388 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241387);
    v_t_241388 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241389 = heff_tr(heff_call(v_one_241384, 1, (V[]){v_a_241385}));
  return (g_std_2edoc_2e_3c_3e(v_t_241388, v_t_241389));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241398 = args[0];
  V v_one_241397 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241399 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241398));
  V v_x1_241400 = heff_get_n(v_t_241399, 6, 9);
  V v_t_241401;
  if ((heff_dup(v_x1_241400) == NTAG(TAG_True))) {
    heff_drop(v_x1_241400);
    v_t_241401 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241400);
    v_t_241401 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241402 = heff_tr(heff_call(v_one_241397, 1, (V[]){v_a_241398}));
  return (g_std_2edoc_2e_3c_3e(v_t_241401, v_t_241402));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241410 = args[0];
  V v_one_241409 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241411 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241410));
  V v_x1_241412 = heff_get_n(v_t_241411, 6, 9);
  V v_t_241413;
  if ((heff_dup(v_x1_241412) == NTAG(TAG_True))) {
    heff_drop(v_x1_241412);
    v_t_241413 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241412);
    v_t_241413 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241414 = heff_tr(heff_call(v_one_241409, 1, (V[]){v_a_241410}));
  return (g_std_2edoc_2e_3c_3e(v_t_241413, v_t_241414));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241424 = args[0];
  V v_one_241423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241425 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241424));
  V v_x1_241426 = heff_get_n(v_t_241425, 6, 9);
  V v_t_241427;
  if ((heff_dup(v_x1_241426) == NTAG(TAG_True))) {
    heff_drop(v_x1_241426);
    v_t_241427 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241426);
    v_t_241427 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241428 = heff_tr(heff_call(v_one_241423, 1, (V[]){v_a_241424}));
  return (g_std_2edoc_2e_3c_3e(v_t_241427, v_t_241428));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241436 = args[0];
  V v_one_241435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241437 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241436));
  V v_x1_241438 = heff_get_n(v_t_241437, 6, 9);
  V v_t_241439;
  if ((heff_dup(v_x1_241438) == NTAG(TAG_True))) {
    heff_drop(v_x1_241438);
    v_t_241439 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241438);
    v_t_241439 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241440 = heff_tr(heff_call(v_one_241435, 1, (V[]){v_a_241436}));
  return (g_std_2edoc_2e_3c_3e(v_t_241439, v_t_241440));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241452 = args[0];
  V v_one_241451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241453 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241452));
  V v_x1_241454 = heff_get_n(v_t_241453, 6, 9);
  V v_t_241455;
  if ((heff_dup(v_x1_241454) == NTAG(TAG_True))) {
    heff_drop(v_x1_241454);
    v_t_241455 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241454);
    v_t_241455 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241456 = heff_tr(heff_call(v_one_241451, 1, (V[]){v_a_241452}));
  return (g_std_2edoc_2e_3c_3e(v_t_241455, v_t_241456));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241464 = args[0];
  V v_one_241463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241465 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241464));
  V v_x1_241466 = heff_get_n(v_t_241465, 6, 9);
  V v_t_241467;
  if ((heff_dup(v_x1_241466) == NTAG(TAG_True))) {
    heff_drop(v_x1_241466);
    v_t_241467 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241466);
    v_t_241467 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241468 = heff_tr(heff_call(v_one_241463, 1, (V[]){v_a_241464}));
  return (g_std_2edoc_2e_3c_3e(v_t_241467, v_t_241468));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241477 = args[0];
  V v_one_241476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241478 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241477));
  V v_x1_241479 = heff_get_n(v_t_241478, 6, 9);
  V v_t_241480;
  if ((heff_dup(v_x1_241479) == NTAG(TAG_True))) {
    heff_drop(v_x1_241479);
    v_t_241480 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241479);
    v_t_241480 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241481 = heff_tr(heff_call(v_one_241476, 1, (V[]){v_a_241477}));
  return (g_std_2edoc_2e_3c_3e(v_t_241480, v_t_241481));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241489 = args[0];
  V v_one_241488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241490 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241489));
  V v_x1_241491 = heff_get_n(v_t_241490, 6, 9);
  V v_t_241492;
  if ((heff_dup(v_x1_241491) == NTAG(TAG_True))) {
    heff_drop(v_x1_241491);
    v_t_241492 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241491);
    v_t_241492 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241493 = heff_tr(heff_call(v_one_241488, 1, (V[]){v_a_241489}));
  return (g_std_2edoc_2e_3c_3e(v_t_241492, v_t_241493));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241504 = args[0];
  V v_one_241503 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241505 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241504));
  V v_x1_241506 = heff_get_n(v_t_241505, 6, 9);
  V v_t_241507;
  if ((heff_dup(v_x1_241506) == NTAG(TAG_True))) {
    heff_drop(v_x1_241506);
    v_t_241507 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241506);
    v_t_241507 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241508 = heff_tr(heff_call(v_one_241503, 1, (V[]){v_a_241504}));
  return (g_std_2edoc_2e_3c_3e(v_t_241507, v_t_241508));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241516 = args[0];
  V v_one_241515 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241517 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241516));
  V v_x1_241518 = heff_get_n(v_t_241517, 6, 9);
  V v_t_241519;
  if ((heff_dup(v_x1_241518) == NTAG(TAG_True))) {
    heff_drop(v_x1_241518);
    v_t_241519 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241518);
    v_t_241519 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241520 = heff_tr(heff_call(v_one_241515, 1, (V[]){v_a_241516}));
  return (g_std_2edoc_2e_3c_3e(v_t_241519, v_t_241520));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241529 = args[0];
  V v_one_241528 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241530 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241529));
  V v_x1_241531 = heff_get_n(v_t_241530, 6, 9);
  V v_t_241532;
  if ((heff_dup(v_x1_241531) == NTAG(TAG_True))) {
    heff_drop(v_x1_241531);
    v_t_241532 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241531);
    v_t_241532 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241533 = heff_tr(heff_call(v_one_241528, 1, (V[]){v_a_241529}));
  return (g_std_2edoc_2e_3c_3e(v_t_241532, v_t_241533));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241541 = args[0];
  V v_one_241540 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241542 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241541));
  V v_x1_241543 = heff_get_n(v_t_241542, 6, 9);
  V v_t_241544;
  if ((heff_dup(v_x1_241543) == NTAG(TAG_True))) {
    heff_drop(v_x1_241543);
    v_t_241544 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241543);
    v_t_241544 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241545 = heff_tr(heff_call(v_one_241540, 1, (V[]){v_a_241541}));
  return (g_std_2edoc_2e_3c_3e(v_t_241544, v_t_241545));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241554 = args[0];
  V v_one_241553 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241555 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241554));
  V v_x1_241556 = heff_get_n(v_t_241555, 6, 9);
  V v_t_241557;
  if ((heff_dup(v_x1_241556) == NTAG(TAG_True))) {
    heff_drop(v_x1_241556);
    v_t_241557 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241556);
    v_t_241557 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241558 = heff_tr(heff_call(v_one_241553, 1, (V[]){v_a_241554}));
  return (g_std_2edoc_2e_3c_3e(v_t_241557, v_t_241558));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241566 = args[0];
  V v_one_241565 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241567 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241566));
  V v_x1_241568 = heff_get_n(v_t_241567, 6, 9);
  V v_t_241569;
  if ((heff_dup(v_x1_241568) == NTAG(TAG_True))) {
    heff_drop(v_x1_241568);
    v_t_241569 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241568);
    v_t_241569 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241570 = heff_tr(heff_call(v_one_241565, 1, (V[]){v_a_241566}));
  return (g_std_2edoc_2e_3c_3e(v_t_241569, v_t_241570));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241581 = args[0];
  V v_one_241580 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241582 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241581));
  V v_x1_241583 = heff_get_n(v_t_241582, 6, 9);
  V v_t_241584;
  if ((heff_dup(v_x1_241583) == NTAG(TAG_True))) {
    heff_drop(v_x1_241583);
    v_t_241584 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241583);
    v_t_241584 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241585 = heff_tr(heff_call(v_one_241580, 1, (V[]){v_a_241581}));
  return (g_std_2edoc_2e_3c_3e(v_t_241584, v_t_241585));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241593 = args[0];
  V v_one_241592 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241594 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241593));
  V v_x1_241595 = heff_get_n(v_t_241594, 6, 9);
  V v_t_241596;
  if ((heff_dup(v_x1_241595) == NTAG(TAG_True))) {
    heff_drop(v_x1_241595);
    v_t_241596 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241595);
    v_t_241596 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241597 = heff_tr(heff_call(v_one_241592, 1, (V[]){v_a_241593}));
  return (g_std_2edoc_2e_3c_3e(v_t_241596, v_t_241597));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241605 = args[0];
  V v_one_241604 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241606 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241605));
  V v_x1_241607 = heff_get_n(v_t_241606, 6, 9);
  V v_t_241608;
  if ((heff_dup(v_x1_241607) == NTAG(TAG_True))) {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241607);
    v_t_241608 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241609 = heff_tr(heff_call(v_one_241604, 1, (V[]){v_a_241605}));
  return (g_std_2edoc_2e_3c_3e(v_t_241608, v_t_241609));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241617 = args[0];
  V v_one_241616 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241618 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241617));
  V v_x1_241619 = heff_get_n(v_t_241618, 6, 9);
  V v_t_241620;
  if ((heff_dup(v_x1_241619) == NTAG(TAG_True))) {
    heff_drop(v_x1_241619);
    v_t_241620 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241619);
    v_t_241620 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241621 = heff_tr(heff_call(v_one_241616, 1, (V[]){v_a_241617}));
  return (g_std_2edoc_2e_3c_3e(v_t_241620, v_t_241621));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241629 = args[0];
  V v_one_241628 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241630 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241629));
  V v_x1_241631 = heff_get_n(v_t_241630, 6, 9);
  V v_t_241632;
  if ((heff_dup(v_x1_241631) == NTAG(TAG_True))) {
    heff_drop(v_x1_241631);
    v_t_241632 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241631);
    v_t_241632 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241633 = heff_tr(heff_call(v_one_241628, 1, (V[]){v_a_241629}));
  return (g_std_2edoc_2e_3c_3e(v_t_241632, v_t_241633));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241641 = args[0];
  V v_one_241640 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241642 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241641));
  V v_x1_241643 = heff_get_n(v_t_241642, 6, 9);
  V v_t_241644;
  if ((heff_dup(v_x1_241643) == NTAG(TAG_True))) {
    heff_drop(v_x1_241643);
    v_t_241644 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241643);
    v_t_241644 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241645 = heff_tr(heff_call(v_one_241640, 1, (V[]){v_a_241641}));
  return (g_std_2edoc_2e_3c_3e(v_t_241644, v_t_241645));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241653 = args[0];
  V v_one_241652 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241654 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241653));
  V v_x1_241655 = heff_get_n(v_t_241654, 6, 9);
  V v_t_241656;
  if ((heff_dup(v_x1_241655) == NTAG(TAG_True))) {
    heff_drop(v_x1_241655);
    v_t_241656 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241655);
    v_t_241656 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241657 = heff_tr(heff_call(v_one_241652, 1, (V[]){v_a_241653}));
  return (g_std_2edoc_2e_3c_3e(v_t_241656, v_t_241657));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241665 = args[0];
  V v_one_241664 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241666 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241665));
  V v_x1_241667 = heff_get_n(v_t_241666, 6, 9);
  V v_t_241668;
  if ((heff_dup(v_x1_241667) == NTAG(TAG_True))) {
    heff_drop(v_x1_241667);
    v_t_241668 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241667);
    v_t_241668 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241669 = heff_tr(heff_call(v_one_241664, 1, (V[]){v_a_241665}));
  return (g_std_2edoc_2e_3c_3e(v_t_241668, v_t_241669));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241677 = args[0];
  V v_one_241676 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241678 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241677));
  V v_x1_241679 = heff_get_n(v_t_241678, 6, 9);
  V v_t_241680;
  if ((heff_dup(v_x1_241679) == NTAG(TAG_True))) {
    heff_drop(v_x1_241679);
    v_t_241680 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241679);
    v_t_241680 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241681 = heff_tr(heff_call(v_one_241676, 1, (V[]){v_a_241677}));
  return (g_std_2edoc_2e_3c_3e(v_t_241680, v_t_241681));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241689 = args[0];
  V v_one_241688 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241690 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241689));
  V v_x1_241691 = heff_get_n(v_t_241690, 6, 9);
  V v_t_241692;
  if ((heff_dup(v_x1_241691) == NTAG(TAG_True))) {
    heff_drop(v_x1_241691);
    v_t_241692 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241691);
    v_t_241692 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241693 = heff_tr(heff_call(v_one_241688, 1, (V[]){v_a_241689}));
  return (g_std_2edoc_2e_3c_3e(v_t_241692, v_t_241693));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241701 = args[0];
  V v_one_241700 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241702 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241701));
  V v_x1_241703 = heff_get_n(v_t_241702, 6, 9);
  V v_t_241704;
  if ((heff_dup(v_x1_241703) == NTAG(TAG_True))) {
    heff_drop(v_x1_241703);
    v_t_241704 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241703);
    v_t_241704 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241705 = heff_tr(heff_call(v_one_241700, 1, (V[]){v_a_241701}));
  return (g_std_2edoc_2e_3c_3e(v_t_241704, v_t_241705));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241713 = args[0];
  V v_one_241712 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241714 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241713));
  V v_x1_241715 = heff_get_n(v_t_241714, 6, 9);
  V v_t_241716;
  if ((heff_dup(v_x1_241715) == NTAG(TAG_True))) {
    heff_drop(v_x1_241715);
    v_t_241716 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241715);
    v_t_241716 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241717 = heff_tr(heff_call(v_one_241712, 1, (V[]){v_a_241713}));
  return (g_std_2edoc_2e_3c_3e(v_t_241716, v_t_241717));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241726 = args[0];
  V v_one_241725 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241727 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241726));
  V v_x1_241728 = heff_get_n(v_t_241727, 6, 9);
  V v_t_241729;
  if ((heff_dup(v_x1_241728) == NTAG(TAG_True))) {
    heff_drop(v_x1_241728);
    v_t_241729 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241728);
    v_t_241729 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241730 = heff_tr(heff_call(v_one_241725, 1, (V[]){v_a_241726}));
  return (g_std_2edoc_2e_3c_3e(v_t_241729, v_t_241730));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241738 = args[0];
  V v_one_241737 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241739 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241738));
  V v_x1_241740 = heff_get_n(v_t_241739, 6, 9);
  V v_t_241741;
  if ((heff_dup(v_x1_241740) == NTAG(TAG_True))) {
    heff_drop(v_x1_241740);
    v_t_241741 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241740);
    v_t_241741 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241742 = heff_tr(heff_call(v_one_241737, 1, (V[]){v_a_241738}));
  return (g_std_2edoc_2e_3c_3e(v_t_241741, v_t_241742));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241750 = args[0];
  V v_one_241749 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241751 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241750));
  V v_x1_241752 = heff_get_n(v_t_241751, 6, 9);
  V v_t_241753;
  if ((heff_dup(v_x1_241752) == NTAG(TAG_True))) {
    heff_drop(v_x1_241752);
    v_t_241753 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241752);
    v_t_241753 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241754 = heff_tr(heff_call(v_one_241749, 1, (V[]){v_a_241750}));
  return (g_std_2edoc_2e_3c_3e(v_t_241753, v_t_241754));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241762 = args[0];
  V v_one_241761 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241763 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241762));
  V v_x1_241764 = heff_get_n(v_t_241763, 6, 9);
  V v_t_241765;
  if ((heff_dup(v_x1_241764) == NTAG(TAG_True))) {
    heff_drop(v_x1_241764);
    v_t_241765 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241764);
    v_t_241765 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241766 = heff_tr(heff_call(v_one_241761, 1, (V[]){v_a_241762}));
  return (g_std_2edoc_2e_3c_3e(v_t_241765, v_t_241766));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241774 = args[0];
  V v_one_241773 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241775 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241774));
  V v_x1_241776 = heff_get_n(v_t_241775, 6, 9);
  V v_t_241777;
  if ((heff_dup(v_x1_241776) == NTAG(TAG_True))) {
    heff_drop(v_x1_241776);
    v_t_241777 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241776);
    v_t_241777 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241778 = heff_tr(heff_call(v_one_241773, 1, (V[]){v_a_241774}));
  return (g_std_2edoc_2e_3c_3e(v_t_241777, v_t_241778));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241786 = args[0];
  V v_one_241785 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241787 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241786));
  V v_x1_241788 = heff_get_n(v_t_241787, 6, 9);
  V v_t_241789;
  if ((heff_dup(v_x1_241788) == NTAG(TAG_True))) {
    heff_drop(v_x1_241788);
    v_t_241789 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241788);
    v_t_241789 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241790 = heff_tr(heff_call(v_one_241785, 1, (V[]){v_a_241786}));
  return (g_std_2edoc_2e_3c_3e(v_t_241789, v_t_241790));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241799 = args[0];
  V v_one_241798 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241800 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241799));
  V v_x1_241801 = heff_get_n(v_t_241800, 6, 9);
  V v_t_241802;
  if ((heff_dup(v_x1_241801) == NTAG(TAG_True))) {
    heff_drop(v_x1_241801);
    v_t_241802 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241801);
    v_t_241802 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241803 = heff_tr(heff_call(v_one_241798, 1, (V[]){v_a_241799}));
  return (g_std_2edoc_2e_3c_3e(v_t_241802, v_t_241803));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241811 = args[0];
  V v_one_241810 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241812 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241811));
  V v_x1_241813 = heff_get_n(v_t_241812, 6, 9);
  V v_t_241814;
  if ((heff_dup(v_x1_241813) == NTAG(TAG_True))) {
    heff_drop(v_x1_241813);
    v_t_241814 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241813);
    v_t_241814 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241815 = heff_tr(heff_call(v_one_241810, 1, (V[]){v_a_241811}));
  return (g_std_2edoc_2e_3c_3e(v_t_241814, v_t_241815));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241822 = args[0];
  V v_one_241821 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241823 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241822));
  V v_x1_241824 = heff_get_n(v_t_241823, 6, 9);
  V v_t_241825;
  if ((heff_dup(v_x1_241824) == NTAG(TAG_True))) {
    heff_drop(v_x1_241824);
    v_t_241825 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241824);
    v_t_241825 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241826 = heff_tr(heff_call(v_one_241821, 1, (V[]){v_a_241822}));
  return (g_std_2edoc_2e_3c_3e(v_t_241825, v_t_241826));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241834 = args[0];
  V v_one_241833 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241835 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241834));
  V v_x1_241836 = heff_get_n(v_t_241835, 6, 9);
  V v_t_241837;
  if ((heff_dup(v_x1_241836) == NTAG(TAG_True))) {
    heff_drop(v_x1_241836);
    v_t_241837 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241836);
    v_t_241837 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241838 = heff_tr(heff_call(v_one_241833, 1, (V[]){v_a_241834}));
  return (g_std_2edoc_2e_3c_3e(v_t_241837, v_t_241838));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241847 = args[0];
  V v_one_241846 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241848 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241847));
  V v_x1_241849 = heff_get_n(v_t_241848, 6, 9);
  V v_t_241850;
  if ((heff_dup(v_x1_241849) == NTAG(TAG_True))) {
    heff_drop(v_x1_241849);
    v_t_241850 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241849);
    v_t_241850 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241851 = heff_tr(heff_call(v_one_241846, 1, (V[]){v_a_241847}));
  return (g_std_2edoc_2e_3c_3e(v_t_241850, v_t_241851));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241859 = args[0];
  V v_one_241858 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241860 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241859));
  V v_x1_241861 = heff_get_n(v_t_241860, 6, 9);
  V v_t_241862;
  if ((heff_dup(v_x1_241861) == NTAG(TAG_True))) {
    heff_drop(v_x1_241861);
    v_t_241862 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241861);
    v_t_241862 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241863 = heff_tr(heff_call(v_one_241858, 1, (V[]){v_a_241859}));
  return (g_std_2edoc_2e_3c_3e(v_t_241862, v_t_241863));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241874 = args[0];
  V v_one_241873 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241875 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241874));
  V v_x1_241876 = heff_get_n(v_t_241875, 6, 9);
  V v_t_241877;
  if ((heff_dup(v_x1_241876) == NTAG(TAG_True))) {
    heff_drop(v_x1_241876);
    v_t_241877 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241876);
    v_t_241877 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241878 = heff_tr(heff_call(v_one_241873, 1, (V[]){v_a_241874}));
  return (g_std_2edoc_2e_3c_3e(v_t_241877, v_t_241878));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241886 = args[0];
  V v_one_241885 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241887 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241886));
  V v_x1_241888 = heff_get_n(v_t_241887, 6, 9);
  V v_t_241889;
  if ((heff_dup(v_x1_241888) == NTAG(TAG_True))) {
    heff_drop(v_x1_241888);
    v_t_241889 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241888);
    v_t_241889 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241890 = heff_tr(heff_call(v_one_241885, 1, (V[]){v_a_241886}));
  return (g_std_2edoc_2e_3c_3e(v_t_241889, v_t_241890));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241897 = args[0];
  V v_one_241896 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241898 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241897));
  V v_x1_241899 = heff_get_n(v_t_241898, 6, 9);
  V v_t_241900;
  if ((heff_dup(v_x1_241899) == NTAG(TAG_True))) {
    heff_drop(v_x1_241899);
    v_t_241900 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241899);
    v_t_241900 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241901 = heff_tr(heff_call(v_one_241896, 1, (V[]){v_a_241897}));
  return (g_std_2edoc_2e_3c_3e(v_t_241900, v_t_241901));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241909 = args[0];
  V v_one_241908 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241910 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241909));
  V v_x1_241911 = heff_get_n(v_t_241910, 6, 9);
  V v_t_241912;
  if ((heff_dup(v_x1_241911) == NTAG(TAG_True))) {
    heff_drop(v_x1_241911);
    v_t_241912 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241911);
    v_t_241912 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241913 = heff_tr(heff_call(v_one_241908, 1, (V[]){v_a_241909}));
  return (g_std_2edoc_2e_3c_3e(v_t_241912, v_t_241913));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_a_241923 = args[0];
  V v_one_241922 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241924 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241923));
  V v_x1_241925 = heff_get_n(v_t_241924, 6, 9);
  V v_t_241926;
  if ((heff_dup(v_x1_241925) == NTAG(TAG_True))) {
    heff_drop(v_x1_241925);
    v_t_241926 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241925);
    v_t_241926 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241927 = heff_tr(heff_call(v_one_241922, 1, (V[]){v_a_241923}));
  return (g_std_2edoc_2e_3c_3e(v_t_241926, v_t_241927));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_a_241935 = args[0];
  V v_one_241934 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241936 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241935));
  V v_x1_241937 = heff_get_n(v_t_241936, 6, 9);
  V v_t_241938;
  if ((heff_dup(v_x1_241937) == NTAG(TAG_True))) {
    heff_drop(v_x1_241937);
    v_t_241938 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241937);
    v_t_241938 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241939 = heff_tr(heff_call(v_one_241934, 1, (V[]){v_a_241935}));
  return (g_std_2edoc_2e_3c_3e(v_t_241938, v_t_241939));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_a_241949 = args[0];
  V v_one_241948 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241950 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241949));
  V v_x1_241951 = heff_get_n(v_t_241950, 6, 9);
  V v_t_241952;
  if ((heff_dup(v_x1_241951) == NTAG(TAG_True))) {
    heff_drop(v_x1_241951);
    v_t_241952 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241951);
    v_t_241952 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241953 = heff_tr(heff_call(v_one_241948, 1, (V[]){v_a_241949}));
  return (g_std_2edoc_2e_3c_3e(v_t_241952, v_t_241953));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_a_241961 = args[0];
  V v_one_241960 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241962 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241961));
  V v_x1_241963 = heff_get_n(v_t_241962, 6, 9);
  V v_t_241964;
  if ((heff_dup(v_x1_241963) == NTAG(TAG_True))) {
    heff_drop(v_x1_241963);
    v_t_241964 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241963);
    v_t_241964 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241965 = heff_tr(heff_call(v_one_241960, 1, (V[]){v_a_241961}));
  return (g_std_2edoc_2e_3c_3e(v_t_241964, v_t_241965));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_a_241974 = args[0];
  V v_one_241973 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241975 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241974));
  V v_x1_241976 = heff_get_n(v_t_241975, 6, 9);
  V v_t_241977;
  if ((heff_dup(v_x1_241976) == NTAG(TAG_True))) {
    heff_drop(v_x1_241976);
    v_t_241977 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241976);
    v_t_241977 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241978 = heff_tr(heff_call(v_one_241973, 1, (V[]){v_a_241974}));
  return (g_std_2edoc_2e_3c_3e(v_t_241977, v_t_241978));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_a_241986 = args[0];
  V v_one_241985 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241987 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241986));
  V v_x1_241988 = heff_get_n(v_t_241987, 6, 9);
  V v_t_241989;
  if ((heff_dup(v_x1_241988) == NTAG(TAG_True))) {
    heff_drop(v_x1_241988);
    v_t_241989 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241988);
    v_t_241989 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241990 = heff_tr(heff_call(v_one_241985, 1, (V[]){v_a_241986}));
  return (g_std_2edoc_2e_3c_3e(v_t_241989, v_t_241990));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_a_242002 = args[0];
  V v_one_242001 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242003 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242002));
  V v_x1_242004 = heff_get_n(v_t_242003, 6, 9);
  V v_t_242005;
  if ((heff_dup(v_x1_242004) == NTAG(TAG_True))) {
    heff_drop(v_x1_242004);
    v_t_242005 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242004);
    v_t_242005 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242006 = heff_tr(heff_call(v_one_242001, 1, (V[]){v_a_242002}));
  return (g_std_2edoc_2e_3c_3e(v_t_242005, v_t_242006));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_a_242014 = args[0];
  V v_one_242013 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242015 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242014));
  V v_x1_242016 = heff_get_n(v_t_242015, 6, 9);
  V v_t_242017;
  if ((heff_dup(v_x1_242016) == NTAG(TAG_True))) {
    heff_drop(v_x1_242016);
    v_t_242017 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242016);
    v_t_242017 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242018 = heff_tr(heff_call(v_one_242013, 1, (V[]){v_a_242014}));
  return (g_std_2edoc_2e_3c_3e(v_t_242017, v_t_242018));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_a_242026 = args[0];
  V v_one_242025 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242027 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242026));
  V v_x1_242028 = heff_get_n(v_t_242027, 6, 9);
  V v_t_242029;
  if ((heff_dup(v_x1_242028) == NTAG(TAG_True))) {
    heff_drop(v_x1_242028);
    v_t_242029 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242028);
    v_t_242029 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242030 = heff_tr(heff_call(v_one_242025, 1, (V[]){v_a_242026}));
  return (g_std_2edoc_2e_3c_3e(v_t_242029, v_t_242030));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_a_242038 = args[0];
  V v_one_242037 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242039 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242038));
  V v_x1_242040 = heff_get_n(v_t_242039, 6, 9);
  V v_t_242041;
  if ((heff_dup(v_x1_242040) == NTAG(TAG_True))) {
    heff_drop(v_x1_242040);
    v_t_242041 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242040);
    v_t_242041 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242042 = heff_tr(heff_call(v_one_242037, 1, (V[]){v_a_242038}));
  return (g_std_2edoc_2e_3c_3e(v_t_242041, v_t_242042));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_a_242051 = args[0];
  V v_one_242050 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242052 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242051));
  V v_x1_242053 = heff_get_n(v_t_242052, 6, 9);
  V v_t_242054;
  if ((heff_dup(v_x1_242053) == NTAG(TAG_True))) {
    heff_drop(v_x1_242053);
    v_t_242054 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242053);
    v_t_242054 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242055 = heff_tr(heff_call(v_one_242050, 1, (V[]){v_a_242051}));
  return (g_std_2edoc_2e_3c_3e(v_t_242054, v_t_242055));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam97(V self, V *args) {
  V v_a_242063 = args[0];
  V v_one_242062 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242064 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242063));
  V v_x1_242065 = heff_get_n(v_t_242064, 6, 9);
  V v_t_242066;
  if ((heff_dup(v_x1_242065) == NTAG(TAG_True))) {
    heff_drop(v_x1_242065);
    v_t_242066 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242065);
    v_t_242066 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242067 = heff_tr(heff_call(v_one_242062, 1, (V[]){v_a_242063}));
  return (g_std_2edoc_2e_3c_3e(v_t_242066, v_t_242067));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam98(V self, V *args) {
  V v_a_242079 = args[0];
  V v_one_242078 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242080 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242079));
  V v_x1_242081 = heff_get_n(v_t_242080, 6, 9);
  V v_t_242082;
  if ((heff_dup(v_x1_242081) == NTAG(TAG_True))) {
    heff_drop(v_x1_242081);
    v_t_242082 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242081);
    v_t_242082 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242083 = heff_tr(heff_call(v_one_242078, 1, (V[]){v_a_242079}));
  return (g_std_2edoc_2e_3c_3e(v_t_242082, v_t_242083));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam99(V self, V *args) {
  V v_a_242091 = args[0];
  V v_one_242090 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242092 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242091));
  V v_x1_242093 = heff_get_n(v_t_242092, 6, 9);
  V v_t_242094;
  if ((heff_dup(v_x1_242093) == NTAG(TAG_True))) {
    heff_drop(v_x1_242093);
    v_t_242094 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242093);
    v_t_242094 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242095 = heff_tr(heff_call(v_one_242090, 1, (V[]){v_a_242091}));
  return (g_std_2edoc_2e_3c_3e(v_t_242094, v_t_242095));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam100(V self, V *args) {
  V v_a_242108 = args[0];
  V v_one_242107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242109 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242108));
  V v_x1_242110 = heff_get_n(v_t_242109, 6, 9);
  V v_t_242111;
  if ((heff_dup(v_x1_242110) == NTAG(TAG_True))) {
    heff_drop(v_x1_242110);
    v_t_242111 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242110);
    v_t_242111 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242112 = heff_tr(heff_call(v_one_242107, 1, (V[]){v_a_242108}));
  return (g_std_2edoc_2e_3c_3e(v_t_242111, v_t_242112));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam101(V self, V *args) {
  V v_a_242120 = args[0];
  V v_one_242119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242121 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242120));
  V v_x1_242122 = heff_get_n(v_t_242121, 6, 9);
  V v_t_242123;
  if ((heff_dup(v_x1_242122) == NTAG(TAG_True))) {
    heff_drop(v_x1_242122);
    v_t_242123 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242122);
    v_t_242123 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242124 = heff_tr(heff_call(v_one_242119, 1, (V[]){v_a_242120}));
  return (g_std_2edoc_2e_3c_3e(v_t_242123, v_t_242124));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam102(V self, V *args) {
  V v_a_242136 = args[0];
  V v_one_242135 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242137 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242136));
  V v_x1_242138 = heff_get_n(v_t_242137, 6, 9);
  V v_t_242139;
  if ((heff_dup(v_x1_242138) == NTAG(TAG_True))) {
    heff_drop(v_x1_242138);
    v_t_242139 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242138);
    v_t_242139 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242140 = heff_tr(heff_call(v_one_242135, 1, (V[]){v_a_242136}));
  return (g_std_2edoc_2e_3c_3e(v_t_242139, v_t_242140));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam103(V self, V *args) {
  V v_a_242148 = args[0];
  V v_one_242147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242149 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242148));
  V v_x1_242150 = heff_get_n(v_t_242149, 6, 9);
  V v_t_242151;
  if ((heff_dup(v_x1_242150) == NTAG(TAG_True))) {
    heff_drop(v_x1_242150);
    v_t_242151 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242150);
    v_t_242151 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242152 = heff_tr(heff_call(v_one_242147, 1, (V[]){v_a_242148}));
  return (g_std_2edoc_2e_3c_3e(v_t_242151, v_t_242152));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam104(V self, V *args) {
  V v_a_242161 = args[0];
  V v_one_242160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242162 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242161));
  V v_x1_242163 = heff_get_n(v_t_242162, 6, 9);
  V v_t_242164;
  if ((heff_dup(v_x1_242163) == NTAG(TAG_True))) {
    heff_drop(v_x1_242163);
    v_t_242164 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242163);
    v_t_242164 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242165 = heff_tr(heff_call(v_one_242160, 1, (V[]){v_a_242161}));
  return (g_std_2edoc_2e_3c_3e(v_t_242164, v_t_242165));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam105(V self, V *args) {
  V v_a_242173 = args[0];
  V v_one_242172 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242174 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242173));
  V v_x1_242175 = heff_get_n(v_t_242174, 6, 9);
  V v_t_242176;
  if ((heff_dup(v_x1_242175) == NTAG(TAG_True))) {
    heff_drop(v_x1_242175);
    v_t_242176 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242175);
    v_t_242176 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242177 = heff_tr(heff_call(v_one_242172, 1, (V[]){v_a_242173}));
  return (g_std_2edoc_2e_3c_3e(v_t_242176, v_t_242177));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam106(V self, V *args) {
  V v_a_242187 = args[0];
  V v_one_242186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242188 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242187));
  V v_x1_242189 = heff_get_n(v_t_242188, 6, 9);
  V v_t_242190;
  if ((heff_dup(v_x1_242189) == NTAG(TAG_True))) {
    heff_drop(v_x1_242189);
    v_t_242190 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242189);
    v_t_242190 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242191 = heff_tr(heff_call(v_one_242186, 1, (V[]){v_a_242187}));
  return (g_std_2edoc_2e_3c_3e(v_t_242190, v_t_242191));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam107(V self, V *args) {
  V v_a_242199 = args[0];
  V v_one_242198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242200 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242199));
  V v_x1_242201 = heff_get_n(v_t_242200, 6, 9);
  V v_t_242202;
  if ((heff_dup(v_x1_242201) == NTAG(TAG_True))) {
    heff_drop(v_x1_242201);
    v_t_242202 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242201);
    v_t_242202 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242203 = heff_tr(heff_call(v_one_242198, 1, (V[]){v_a_242199}));
  return (g_std_2edoc_2e_3c_3e(v_t_242202, v_t_242203));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam108(V self, V *args) {
  V v_a_242215 = args[0];
  V v_one_242214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242216 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242215));
  V v_x1_242217 = heff_get_n(v_t_242216, 6, 9);
  V v_t_242218;
  if ((heff_dup(v_x1_242217) == NTAG(TAG_True))) {
    heff_drop(v_x1_242217);
    v_t_242218 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242217);
    v_t_242218 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242219 = heff_tr(heff_call(v_one_242214, 1, (V[]){v_a_242215}));
  return (g_std_2edoc_2e_3c_3e(v_t_242218, v_t_242219));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam109(V self, V *args) {
  V v_a_242227 = args[0];
  V v_one_242226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242228 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242227));
  V v_x1_242229 = heff_get_n(v_t_242228, 6, 9);
  V v_t_242230;
  if ((heff_dup(v_x1_242229) == NTAG(TAG_True))) {
    heff_drop(v_x1_242229);
    v_t_242230 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242229);
    v_t_242230 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242231 = heff_tr(heff_call(v_one_242226, 1, (V[]){v_a_242227}));
  return (g_std_2edoc_2e_3c_3e(v_t_242230, v_t_242231));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam110(V self, V *args) {
  V v_a_242238 = args[0];
  V v_one_242237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242239 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242238));
  V v_x1_242240 = heff_get_n(v_t_242239, 6, 9);
  V v_t_242241;
  if ((heff_dup(v_x1_242240) == NTAG(TAG_True))) {
    heff_drop(v_x1_242240);
    v_t_242241 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242240);
    v_t_242241 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242242 = heff_tr(heff_call(v_one_242237, 1, (V[]){v_a_242238}));
  return (g_std_2edoc_2e_3c_3e(v_t_242241, v_t_242242));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam111(V self, V *args) {
  V v_a_242250 = args[0];
  V v_one_242249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242251 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242250));
  V v_x1_242252 = heff_get_n(v_t_242251, 6, 9);
  V v_t_242253;
  if ((heff_dup(v_x1_242252) == NTAG(TAG_True))) {
    heff_drop(v_x1_242252);
    v_t_242253 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242252);
    v_t_242253 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242254 = heff_tr(heff_call(v_one_242249, 1, (V[]){v_a_242250}));
  return (g_std_2edoc_2e_3c_3e(v_t_242253, v_t_242254));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam112(V self, V *args) {
  V v_a_242262 = args[0];
  V v_one_242261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242263 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242262));
  V v_x1_242264 = heff_get_n(v_t_242263, 6, 9);
  V v_t_242265;
  if ((heff_dup(v_x1_242264) == NTAG(TAG_True))) {
    heff_drop(v_x1_242264);
    v_t_242265 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242264);
    v_t_242265 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242266 = heff_tr(heff_call(v_one_242261, 1, (V[]){v_a_242262}));
  return (g_std_2edoc_2e_3c_3e(v_t_242265, v_t_242266));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam113(V self, V *args) {
  V v_a_242274 = args[0];
  V v_one_242273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242275 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242274));
  V v_x1_242276 = heff_get_n(v_t_242275, 6, 9);
  V v_t_242277;
  if ((heff_dup(v_x1_242276) == NTAG(TAG_True))) {
    heff_drop(v_x1_242276);
    v_t_242277 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242276);
    v_t_242277 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242278 = heff_tr(heff_call(v_one_242273, 1, (V[]){v_a_242274}));
  return (g_std_2edoc_2e_3c_3e(v_t_242277, v_t_242278));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam114(V self, V *args) {
  V v_a_242288 = args[0];
  V v_one_242287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242289 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242288));
  V v_x1_242290 = heff_get_n(v_t_242289, 6, 9);
  V v_t_242291;
  if ((heff_dup(v_x1_242290) == NTAG(TAG_True))) {
    heff_drop(v_x1_242290);
    v_t_242291 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242290);
    v_t_242291 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242292 = heff_tr(heff_call(v_one_242287, 1, (V[]){v_a_242288}));
  return (g_std_2edoc_2e_3c_3e(v_t_242291, v_t_242292));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam115(V self, V *args) {
  V v_a_242300 = args[0];
  V v_one_242299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242301 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242300));
  V v_x1_242302 = heff_get_n(v_t_242301, 6, 9);
  V v_t_242303;
  if ((heff_dup(v_x1_242302) == NTAG(TAG_True))) {
    heff_drop(v_x1_242302);
    v_t_242303 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242302);
    v_t_242303 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242304 = heff_tr(heff_call(v_one_242299, 1, (V[]){v_a_242300}));
  return (g_std_2edoc_2e_3c_3e(v_t_242303, v_t_242304));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam116(V self, V *args) {
  V v_a_242314 = args[0];
  V v_one_242313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242315 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242314));
  V v_x1_242316 = heff_get_n(v_t_242315, 6, 9);
  V v_t_242317;
  if ((heff_dup(v_x1_242316) == NTAG(TAG_True))) {
    heff_drop(v_x1_242316);
    v_t_242317 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242316);
    v_t_242317 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242318 = heff_tr(heff_call(v_one_242313, 1, (V[]){v_a_242314}));
  return (g_std_2edoc_2e_3c_3e(v_t_242317, v_t_242318));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam117(V self, V *args) {
  V v_a_242326 = args[0];
  V v_one_242325 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242327 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242326));
  V v_x1_242328 = heff_get_n(v_t_242327, 6, 9);
  V v_t_242329;
  if ((heff_dup(v_x1_242328) == NTAG(TAG_True))) {
    heff_drop(v_x1_242328);
    v_t_242329 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242328);
    v_t_242329 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242330 = heff_tr(heff_call(v_one_242325, 1, (V[]){v_a_242326}));
  return (g_std_2edoc_2e_3c_3e(v_t_242329, v_t_242330));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam118(V self, V *args) {
  V v_a_242340 = args[0];
  V v_one_242339 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242341 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242340));
  V v_x1_242342 = heff_get_n(v_t_242341, 6, 9);
  V v_t_242343;
  if ((heff_dup(v_x1_242342) == NTAG(TAG_True))) {
    heff_drop(v_x1_242342);
    v_t_242343 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242342);
    v_t_242343 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242344 = heff_tr(heff_call(v_one_242339, 1, (V[]){v_a_242340}));
  return (g_std_2edoc_2e_3c_3e(v_t_242343, v_t_242344));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam119(V self, V *args) {
  V v_a_242352 = args[0];
  V v_one_242351 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242353 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242352));
  V v_x1_242354 = heff_get_n(v_t_242353, 6, 9);
  V v_t_242355;
  if ((heff_dup(v_x1_242354) == NTAG(TAG_True))) {
    heff_drop(v_x1_242354);
    v_t_242355 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242354);
    v_t_242355 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242356 = heff_tr(heff_call(v_one_242351, 1, (V[]){v_a_242352}));
  return (g_std_2edoc_2e_3c_3e(v_t_242355, v_t_242356));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam120(V self, V *args) {
  V v_a_242366 = args[0];
  V v_one_242365 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242367 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242366));
  V v_x1_242368 = heff_get_n(v_t_242367, 6, 9);
  V v_t_242369;
  if ((heff_dup(v_x1_242368) == NTAG(TAG_True))) {
    heff_drop(v_x1_242368);
    v_t_242369 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242368);
    v_t_242369 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242370 = heff_tr(heff_call(v_one_242365, 1, (V[]){v_a_242366}));
  return (g_std_2edoc_2e_3c_3e(v_t_242369, v_t_242370));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam121(V self, V *args) {
  V v_a_242378 = args[0];
  V v_one_242377 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242379 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242378));
  V v_x1_242380 = heff_get_n(v_t_242379, 6, 9);
  V v_t_242381;
  if ((heff_dup(v_x1_242380) == NTAG(TAG_True))) {
    heff_drop(v_x1_242380);
    v_t_242381 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242380);
    v_t_242381 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242382 = heff_tr(heff_call(v_one_242377, 1, (V[]){v_a_242378}));
  return (g_std_2edoc_2e_3c_3e(v_t_242381, v_t_242382));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam122(V self, V *args) {
  V v_a_242394 = args[0];
  V v_one_242393 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242395 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242394));
  V v_x1_242396 = heff_get_n(v_t_242395, 6, 9);
  V v_t_242397;
  if ((heff_dup(v_x1_242396) == NTAG(TAG_True))) {
    heff_drop(v_x1_242396);
    v_t_242397 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242396);
    v_t_242397 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242398 = heff_tr(heff_call(v_one_242393, 1, (V[]){v_a_242394}));
  return (g_std_2edoc_2e_3c_3e(v_t_242397, v_t_242398));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam123(V self, V *args) {
  V v_a_242406 = args[0];
  V v_one_242405 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242407 = (g_heff_2esyntax_2ecst_2efirstE(v_a_242406));
  V v_x1_242408 = heff_get_n(v_t_242407, 6, 9);
  V v_t_242409;
  if ((heff_dup(v_x1_242408) == NTAG(TAG_True))) {
    heff_drop(v_x1_242408);
    v_t_242409 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242408);
    v_t_242409 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242410 = heff_tr(heff_call(v_one_242405, 1, (V[]){v_a_242406}));
  return (g_std_2edoc_2e_3c_3e(v_t_242409, v_t_242410));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_env_241280 = args[0];
  V v_h_241281 = args[1];
  V v_args_241282 = args[2];
  V v_x1_241283 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_241282)));
  switch (heff_tag_of(v_x1_241283)) {
  case TAG_Nil: {
    heff_drop(v_args_241282);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241280;
    args[1] = v_h_241281;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_x_241284 = heff_field(v_x1_241283, 0);
    V v_rev_241285 = heff_field(v_x1_241283, 1);
    V v_ru_24x1_241283_24Cons = heff_take_reuse_n(v_x1_241283, 3ULL, 2);
    V v_t_241286 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_241285));
    switch (heff_tag_of(v_x_241284)) {
    case TAG_Atom: {
      V v_t_241288 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241288) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241288);
        V v_t_241289 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241290 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241296 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241290}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241297 = (g_std_2edoc_2e_3c_3e(v_t_241289, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241296})));
        V v_a_241298 = (g_std_2edoc_2egroup(v_t_241297));
        V v_b_241299 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241300 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_241299));
        return (g_std_2edoc_2e_3c_3e(v_a_241298, v_t_241300));
      } else {
        heff_drop_tag(v_x_241284, 1);
        heff_drop(v_t_241286);
        heff_drop(v_t_241288);
        V v_t_241301 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241302 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241308 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241302}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241309 = (g_std_2edoc_2e_3c_3e(v_t_241301, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241308})));
        return (g_std_2edoc_2egroup(v_t_241309));
      }
    }
    case TAG_EParen: {
      V v_o_241310 = heff_field(v_x_241284, 0);
      V v_e_241311 = heff_field(v_x_241284, 1);
      V v_c_241312 = heff_field(v_x_241284, 2);
      heff_take_n(v_x_241284, 7ULL, 3);
      V v_t_241313 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_241311));
      if ((heff_dup(v_t_241313) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241313);
        V v_t_241314 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241315 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241321 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241315}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241322 = (g_std_2edoc_2e_3c_3e(v_t_241314, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241321})));
        V v_a_241323 = (g_std_2edoc_2egroup(v_t_241322));
        V v_b_241324 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241280), v_o_241310));
        V v_t_241325 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), v_b_241324));
        V v_t_241326 = (g_std_2edoc_2e_3c_3e(v_a_241323, v_t_241325));
        V v_t_241327 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_e_241311}));
        V v_t_241328 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241280, v_c_241312));
        V v_t_241329 = (g_std_2edoc_2e_3c_3e(v_t_241327, v_t_241328));
        return (g_std_2edoc_2e_3c_3e(v_t_241326, v_t_241329));
      } else {
        heff_drop(v_t_241286);
        heff_drop(v_o_241310);
        heff_drop(v_e_241311);
        heff_drop(v_c_241312);
        heff_drop(v_t_241313);
        V v_t_241330 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241331 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241337 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241331}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241338 = (g_std_2edoc_2e_3c_3e(v_t_241330, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241337})));
        return (g_std_2edoc_2egroup(v_t_241338));
      }
    }
    case TAG_Named: {
      V v_t_241344 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241344) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241344);
        V v_t_241345 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241346 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241352 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241346}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241353 = (g_std_2edoc_2e_3c_3e(v_t_241345, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241352})));
        V v_a_241354 = (g_std_2edoc_2egroup(v_t_241353));
        V v_b_241355 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241356 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_241355));
        return (g_std_2edoc_2e_3c_3e(v_a_241354, v_t_241356));
      } else {
        heff_drop_tag(v_x_241284, 5);
        heff_drop(v_t_241286);
        heff_drop(v_t_241344);
        V v_t_241357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241358 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241364 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241358}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241365 = (g_std_2edoc_2e_3c_3e(v_t_241357, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241364})));
        return (g_std_2edoc_2egroup(v_t_241365));
      }
    }
    case TAG_Tup: {
      V v_t_241370 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241370) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241370);
        V v_t_241371 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241372 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241378 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241372}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241379 = (g_std_2edoc_2e_3c_3e(v_t_241371, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241378})));
        V v_a_241380 = (g_std_2edoc_2egroup(v_t_241379));
        V v_b_241381 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241382 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str111)}), v_b_241381));
        return (g_std_2edoc_2e_3c_3e(v_a_241380, v_t_241382));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_241370);
        V v_t_241383 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241384 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241390 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241384}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241391 = (g_std_2edoc_2e_3c_3e(v_t_241383, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241390})));
        return (g_std_2edoc_2egroup(v_t_241391));
      }
    }
    case TAG_Seg: {
      V v_t_241395 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241395) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241395);
        V v_t_241396 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241397 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241403 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241397}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241404 = (g_std_2edoc_2e_3c_3e(v_t_241396, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241403})));
        V v_a_241405 = (g_std_2edoc_2egroup(v_t_241404));
        V v_b_241406 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241407 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str112)}), v_b_241406));
        return (g_std_2edoc_2e_3c_3e(v_a_241405, v_t_241407));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241395);
        V v_t_241408 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241409 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241415 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241409}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241416 = (g_std_2edoc_2e_3c_3e(v_t_241408, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241415})));
        return (g_std_2edoc_2egroup(v_t_241416));
      }
    }
    case TAG_Braces: {
      V v_t_241421 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241421) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241421);
        V v_t_241422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241423 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241429 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241423}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241430 = (g_std_2edoc_2e_3c_3e(v_t_241422, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241429})));
        V v_a_241431 = (g_std_2edoc_2egroup(v_t_241430));
        V v_b_241432 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241433 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str113)}), v_b_241432));
        return (g_std_2edoc_2e_3c_3e(v_a_241431, v_t_241433));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_241421);
        V v_t_241434 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241435 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241441 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241435}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241442 = (g_std_2edoc_2e_3c_3e(v_t_241434, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241441})));
        return (g_std_2edoc_2egroup(v_t_241442));
      }
    }
    case TAG_Update: {
      V v_t_241449 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241449) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241449);
        V v_t_241450 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241451 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241457 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241451}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241458 = (g_std_2edoc_2e_3c_3e(v_t_241450, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241457})));
        V v_a_241459 = (g_std_2edoc_2egroup(v_t_241458));
        V v_b_241460 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241461 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str114)}), v_b_241460));
        return (g_std_2edoc_2e_3c_3e(v_a_241459, v_t_241461));
      } else {
        heff_drop_tag(v_x_241284, 6);
        heff_drop(v_t_241286);
        heff_drop(v_t_241449);
        V v_t_241462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241463 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241469 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241463}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241470 = (g_std_2edoc_2e_3c_3e(v_t_241462, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241469})));
        return (g_std_2edoc_2egroup(v_t_241470));
      }
    }
    case TAG_EUSet: {
      V v_t_241474 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241474) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241474);
        V v_t_241475 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241476 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241482 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241476}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241483 = (g_std_2edoc_2e_3c_3e(v_t_241475, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241482})));
        V v_a_241484 = (g_std_2edoc_2egroup(v_t_241483));
        V v_b_241485 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241486 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str115)}), v_b_241485));
        return (g_std_2edoc_2e_3c_3e(v_a_241484, v_t_241486));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241474);
        V v_t_241487 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241488 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241494 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241488}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241495 = (g_std_2edoc_2e_3c_3e(v_t_241487, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241494})));
        return (g_std_2edoc_2egroup(v_t_241495));
      }
    }
    case TAG_InstB: {
      V v_t_241501 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241501) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241501);
        V v_t_241502 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241503 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241509 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241503}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241510 = (g_std_2edoc_2e_3c_3e(v_t_241502, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241509})));
        V v_a_241511 = (g_std_2edoc_2egroup(v_t_241510));
        V v_b_241512 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241513 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str116)}), v_b_241512));
        return (g_std_2edoc_2e_3c_3e(v_a_241511, v_t_241513));
      } else {
        heff_drop_tag(v_x_241284, 5);
        heff_drop(v_t_241286);
        heff_drop(v_t_241501);
        V v_t_241514 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241515 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241521 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241515}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241522 = (g_std_2edoc_2e_3c_3e(v_t_241514, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241521})));
        return (g_std_2edoc_2egroup(v_t_241522));
      }
    }
    case TAG_EFSet: {
      V v_t_241526 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241526) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241526);
        V v_t_241527 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241528 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241534 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241528}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241535 = (g_std_2edoc_2e_3c_3e(v_t_241527, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241534})));
        V v_a_241536 = (g_std_2edoc_2egroup(v_t_241535));
        V v_b_241537 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241538 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str117)}), v_b_241537));
        return (g_std_2edoc_2e_3c_3e(v_a_241536, v_t_241538));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241526);
        V v_t_241539 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241540 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241546 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241540}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241547 = (g_std_2edoc_2e_3c_3e(v_t_241539, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241546})));
        return (g_std_2edoc_2egroup(v_t_241547));
      }
    }
    case TAG_EFDefault: {
      V v_t_241551 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241551) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241551);
        V v_t_241552 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241553 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241559 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241553}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241560 = (g_std_2edoc_2e_3c_3e(v_t_241552, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241559})));
        V v_a_241561 = (g_std_2edoc_2egroup(v_t_241560));
        V v_b_241562 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241563 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str118)}), v_b_241562));
        return (g_std_2edoc_2e_3c_3e(v_a_241561, v_t_241563));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241551);
        V v_t_241564 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241565 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241571 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241565}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241572 = (g_std_2edoc_2e_3c_3e(v_t_241564, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241571})));
        return (g_std_2edoc_2egroup(v_t_241572));
      }
    }
    case TAG_Sum: {
      V v_t_241578 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241578) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241578);
        V v_t_241579 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241580 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241586 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241580}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241587 = (g_std_2edoc_2e_3c_3e(v_t_241579, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241586})));
        V v_a_241588 = (g_std_2edoc_2egroup(v_t_241587));
        V v_b_241589 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241590 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str119)}), v_b_241589));
        return (g_std_2edoc_2e_3c_3e(v_a_241588, v_t_241590));
      } else {
        heff_drop_tag(v_x_241284, 5);
        heff_drop(v_t_241286);
        heff_drop(v_t_241578);
        V v_t_241591 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241592 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241598 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241592}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241599 = (g_std_2edoc_2e_3c_3e(v_t_241591, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241598})));
        return (g_std_2edoc_2egroup(v_t_241599));
      }
    }
    case TAG_ECon: {
      V v_t_241602 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241602) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241602);
        V v_t_241603 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241604 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241610 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241604}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241611 = (g_std_2edoc_2e_3c_3e(v_t_241603, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241610})));
        V v_a_241612 = (g_std_2edoc_2egroup(v_t_241611));
        V v_b_241613 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241614 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str120)}), v_b_241613));
        return (g_std_2edoc_2e_3c_3e(v_a_241612, v_t_241614));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241602);
        V v_t_241615 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241616 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241622 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241616}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241623 = (g_std_2edoc_2e_3c_3e(v_t_241615, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241622})));
        return (g_std_2edoc_2egroup(v_t_241623));
      }
    }
    case TAG_EField: {
      V v_t_241626 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241626) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241626);
        V v_t_241627 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241628 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241634 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241628}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241635 = (g_std_2edoc_2e_3c_3e(v_t_241627, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241634})));
        V v_a_241636 = (g_std_2edoc_2egroup(v_t_241635));
        V v_b_241637 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241638 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str121)}), v_b_241637));
        return (g_std_2edoc_2e_3c_3e(v_a_241636, v_t_241638));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241626);
        V v_t_241639 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241640 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241646 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241640}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241647 = (g_std_2edoc_2e_3c_3e(v_t_241639, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241646})));
        return (g_std_2edoc_2egroup(v_t_241647));
      }
    }
    case TAG_ENeg: {
      V v_t_241650 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241650) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241650);
        V v_t_241651 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241652 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241658 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241652}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241659 = (g_std_2edoc_2e_3c_3e(v_t_241651, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241658})));
        V v_a_241660 = (g_std_2edoc_2egroup(v_t_241659));
        V v_b_241661 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241662 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str122)}), v_b_241661));
        return (g_std_2edoc_2e_3c_3e(v_a_241660, v_t_241662));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241650);
        V v_t_241663 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241664 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241670 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241664}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241671 = (g_std_2edoc_2e_3c_3e(v_t_241663, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241670})));
        return (g_std_2edoc_2egroup(v_t_241671));
      }
    }
    case TAG_ETilde: {
      V v_t_241674 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241674) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241674);
        V v_t_241675 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241676 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241682 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241676}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241683 = (g_std_2edoc_2e_3c_3e(v_t_241675, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241682})));
        V v_a_241684 = (g_std_2edoc_2egroup(v_t_241683));
        V v_b_241685 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241686 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str123)}), v_b_241685));
        return (g_std_2edoc_2e_3c_3e(v_a_241684, v_t_241686));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241674);
        V v_t_241687 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241694 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241688}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241695 = (g_std_2edoc_2e_3c_3e(v_t_241687, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241694})));
        return (g_std_2edoc_2egroup(v_t_241695));
      }
    }
    case TAG_App: {
      V v_t_241698 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241698) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241698);
        V v_t_241699 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241700 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241706 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241700}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241707 = (g_std_2edoc_2e_3c_3e(v_t_241699, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241706})));
        V v_a_241708 = (g_std_2edoc_2egroup(v_t_241707));
        V v_b_241709 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241710 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str124)}), v_b_241709));
        return (g_std_2edoc_2e_3c_3e(v_a_241708, v_t_241710));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241698);
        V v_t_241711 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241712 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241718 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241712}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241719 = (g_std_2edoc_2e_3c_3e(v_t_241711, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241718})));
        return (g_std_2edoc_2egroup(v_t_241719));
      }
    }
    case TAG_Op: {
      V v_t_241723 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241723) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241723);
        V v_t_241724 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241725 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241731 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241725}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241732 = (g_std_2edoc_2e_3c_3e(v_t_241724, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241731})));
        V v_a_241733 = (g_std_2edoc_2egroup(v_t_241732));
        V v_b_241734 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241735 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str125)}), v_b_241734));
        return (g_std_2edoc_2e_3c_3e(v_a_241733, v_t_241735));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241723);
        V v_t_241736 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241737 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241743 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241737}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241744 = (g_std_2edoc_2e_3c_3e(v_t_241736, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241743})));
        return (g_std_2edoc_2egroup(v_t_241744));
      }
    }
    case TAG_Ops: {
      V v_t_241747 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241747) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241747);
        V v_t_241748 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241749 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241755 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241749}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241756 = (g_std_2edoc_2e_3c_3e(v_t_241748, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241755})));
        V v_a_241757 = (g_std_2edoc_2egroup(v_t_241756));
        V v_b_241758 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241759 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str126)}), v_b_241758));
        return (g_std_2edoc_2e_3c_3e(v_a_241757, v_t_241759));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241747);
        V v_t_241760 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241761 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241767 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241761}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241768 = (g_std_2edoc_2e_3c_3e(v_t_241760, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241767})));
        return (g_std_2edoc_2egroup(v_t_241768));
      }
    }
    case TAG_OpRhs: {
      V v_t_241771 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241771) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241771);
        V v_t_241772 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241773 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241779 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241773}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241780 = (g_std_2edoc_2e_3c_3e(v_t_241772, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241779})));
        V v_a_241781 = (g_std_2edoc_2egroup(v_t_241780));
        V v_b_241782 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241783 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str127)}), v_b_241782));
        return (g_std_2edoc_2e_3c_3e(v_a_241781, v_t_241783));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_241771);
        V v_t_241784 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241785 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241791 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241785}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241792 = (g_std_2edoc_2e_3c_3e(v_t_241784, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241791})));
        return (g_std_2edoc_2egroup(v_t_241792));
      }
    }
    case TAG_Ann: {
      V v_t_241796 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241796) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241796);
        V v_t_241797 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241798 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241804 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241798}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241805 = (g_std_2edoc_2e_3c_3e(v_t_241797, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241804})));
        V v_a_241806 = (g_std_2edoc_2egroup(v_t_241805));
        V v_b_241807 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241808 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str128)}), v_b_241807));
        return (g_std_2edoc_2e_3c_3e(v_a_241806, v_t_241808));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241796);
        V v_t_241809 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241810 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241816 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241810}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241817 = (g_std_2edoc_2e_3c_3e(v_t_241809, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241816})));
        return (g_std_2edoc_2egroup(v_t_241817));
      }
    }
    case TAG_BVar: {
      V v_t_241819 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241819) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241819);
        V v_t_241820 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241821 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241827 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241821}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241828 = (g_std_2edoc_2e_3c_3e(v_t_241820, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241827})));
        V v_a_241829 = (g_std_2edoc_2egroup(v_t_241828));
        V v_b_241830 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241831 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str129)}), v_b_241830));
        return (g_std_2edoc_2e_3c_3e(v_a_241829, v_t_241831));
      } else {
        heff_drop_tag(v_x_241284, 1);
        heff_drop(v_t_241286);
        heff_drop(v_t_241819);
        V v_t_241832 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241833 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241839 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241833}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241840 = (g_std_2edoc_2e_3c_3e(v_t_241832, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241839})));
        return (g_std_2edoc_2egroup(v_t_241840));
      }
    }
    case TAG_BImp: {
      V v_t_241844 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241844) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241844);
        V v_t_241845 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241846 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241852 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241846}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241853 = (g_std_2edoc_2e_3c_3e(v_t_241845, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241852})));
        V v_a_241854 = (g_std_2edoc_2egroup(v_t_241853));
        V v_b_241855 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241856 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str130)}), v_b_241855));
        return (g_std_2edoc_2e_3c_3e(v_a_241854, v_t_241856));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241844);
        V v_t_241857 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241858 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241864 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241858}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241865 = (g_std_2edoc_2e_3c_3e(v_t_241857, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241864})));
        return (g_std_2edoc_2egroup(v_t_241865));
      }
    }
    case TAG_BAnn: {
      V v_t_241871 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241871) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241871);
        V v_t_241872 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241873 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241879 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241873}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241880 = (g_std_2edoc_2e_3c_3e(v_t_241872, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241879})));
        V v_a_241881 = (g_std_2edoc_2egroup(v_t_241880));
        V v_b_241882 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241883 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str131)}), v_b_241882));
        return (g_std_2edoc_2e_3c_3e(v_a_241881, v_t_241883));
      } else {
        heff_drop_tag(v_x_241284, 5);
        heff_drop(v_t_241286);
        heff_drop(v_t_241871);
        V v_t_241884 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241885 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241891 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241885}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241892 = (g_std_2edoc_2e_3c_3e(v_t_241884, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241891})));
        return (g_std_2edoc_2egroup(v_t_241892));
      }
    }
    case TAG_BPat: {
      V v_t_241894 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241894) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241894);
        V v_t_241895 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241896 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241902 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241896}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241903 = (g_std_2edoc_2e_3c_3e(v_t_241895, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241902})));
        V v_a_241904 = (g_std_2edoc_2egroup(v_t_241903));
        V v_b_241905 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241906 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str132)}), v_b_241905));
        return (g_std_2edoc_2e_3c_3e(v_a_241904, v_t_241906));
      } else {
        heff_drop_tag(v_x_241284, 1);
        heff_drop(v_t_241286);
        heff_drop(v_t_241894);
        V v_t_241907 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241908 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241914 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241908}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241915 = (g_std_2edoc_2e_3c_3e(v_t_241907, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241914})));
        return (g_std_2edoc_2egroup(v_t_241915));
      }
    }
    case TAG_Lam: {
      V v_t_241920 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241920) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241920);
        V v_t_241921 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241922 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241928 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 1, 1, (V[]){v_one_241922}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241929 = (g_std_2edoc_2e_3c_3e(v_t_241921, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241928})));
        V v_a_241930 = (g_std_2edoc_2egroup(v_t_241929));
        V v_b_241931 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241932 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str133)}), v_b_241931));
        return (g_std_2edoc_2e_3c_3e(v_a_241930, v_t_241932));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_241920);
        V v_t_241933 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241934 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241940 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 1, 1, (V[]){v_one_241934}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241941 = (g_std_2edoc_2e_3c_3e(v_t_241933, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241940})));
        return (g_std_2edoc_2egroup(v_t_241941));
      }
    }
    case TAG_Case: {
      V v_t_241946 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241946) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241946);
        V v_t_241947 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241948 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241954 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 1, 1, (V[]){v_one_241948}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241955 = (g_std_2edoc_2e_3c_3e(v_t_241947, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241954})));
        V v_a_241956 = (g_std_2edoc_2egroup(v_t_241955));
        V v_b_241957 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241958 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str134)}), v_b_241957));
        return (g_std_2edoc_2e_3c_3e(v_a_241956, v_t_241958));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_241946);
        V v_t_241959 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241960 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241966 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 1, 1, (V[]){v_one_241960}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241967 = (g_std_2edoc_2e_3c_3e(v_t_241959, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241966})));
        return (g_std_2edoc_2egroup(v_t_241967));
      }
    }
    case TAG_EAlt: {
      V v_t_241971 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241971) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241971);
        V v_t_241972 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241973 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_241979 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 1, 1, (V[]){v_one_241973}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_241980 = (g_std_2edoc_2e_3c_3e(v_t_241972, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241979})));
        V v_a_241981 = (g_std_2edoc_2egroup(v_t_241980));
        V v_b_241982 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_241983 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str135)}), v_b_241982));
        return (g_std_2edoc_2e_3c_3e(v_a_241981, v_t_241983));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_241971);
        V v_t_241984 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_241985 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_241991 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_one_241985}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_241992 = (g_std_2edoc_2e_3c_3e(v_t_241984, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241991})));
        return (g_std_2edoc_2egroup(v_t_241992));
      }
    }
    case TAG_If: {
      V v_t_241999 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_241999) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_241999);
        V v_t_242000 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242001 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242007 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_one_242001}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242008 = (g_std_2edoc_2e_3c_3e(v_t_242000, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242007})));
        V v_a_242009 = (g_std_2edoc_2egroup(v_t_242008));
        V v_b_242010 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242011 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str136)}), v_b_242010));
        return (g_std_2edoc_2e_3c_3e(v_a_242009, v_t_242011));
      } else {
        heff_drop_tag(v_x_241284, 6);
        heff_drop(v_t_241286);
        heff_drop(v_t_241999);
        V v_t_242012 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242013 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242019 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 1, 1, (V[]){v_one_242013}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242020 = (g_std_2edoc_2e_3c_3e(v_t_242012, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242019})));
        return (g_std_2edoc_2egroup(v_t_242020));
      }
    }
    case TAG_Do: {
      V v_t_242023 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242023) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242023);
        V v_t_242024 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242025 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242031 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 1, 1, (V[]){v_one_242025}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242032 = (g_std_2edoc_2e_3c_3e(v_t_242024, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242031})));
        V v_a_242033 = (g_std_2edoc_2egroup(v_t_242032));
        V v_b_242034 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242035 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str137)}), v_b_242034));
        return (g_std_2edoc_2e_3c_3e(v_a_242033, v_t_242035));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_242023);
        V v_t_242036 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242037 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242043 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 1, 1, (V[]){v_one_242037}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242044 = (g_std_2edoc_2e_3c_3e(v_t_242036, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242043})));
        return (g_std_2edoc_2egroup(v_t_242044));
      }
    }
    case TAG_ESBind: {
      V v_t_242048 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242048) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242048);
        V v_t_242049 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242050 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242056 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 1, 1, (V[]){v_one_242050}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242057 = (g_std_2edoc_2e_3c_3e(v_t_242049, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242056})));
        V v_a_242058 = (g_std_2edoc_2egroup(v_t_242057));
        V v_b_242059 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242060 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str138)}), v_b_242059));
        return (g_std_2edoc_2e_3c_3e(v_a_242058, v_t_242060));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_242048);
        V v_t_242061 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242062 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242068 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam97, 1, 1, (V[]){v_one_242062}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242069 = (g_std_2edoc_2e_3c_3e(v_t_242061, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242068})));
        return (g_std_2edoc_2egroup(v_t_242069));
      }
    }
    case TAG_ELet: {
      V v_t_242076 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242076) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242076);
        V v_t_242077 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242078 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242084 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam98, 1, 1, (V[]){v_one_242078}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242085 = (g_std_2edoc_2e_3c_3e(v_t_242077, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242084})));
        V v_a_242086 = (g_std_2edoc_2egroup(v_t_242085));
        V v_b_242087 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242088 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str139)}), v_b_242087));
        return (g_std_2edoc_2e_3c_3e(v_a_242086, v_t_242088));
      } else {
        heff_drop_tag(v_x_241284, 6);
        heff_drop(v_t_241286);
        heff_drop(v_t_242076);
        V v_t_242089 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242090 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242096 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam99, 1, 1, (V[]){v_one_242090}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242097 = (g_std_2edoc_2e_3c_3e(v_t_242089, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242096})));
        return (g_std_2edoc_2egroup(v_t_242097));
      }
    }
    case TAG_ELetElse: {
      V v_t_242105 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242105) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242105);
        V v_t_242106 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242107 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242113 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam100, 1, 1, (V[]){v_one_242107}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242114 = (g_std_2edoc_2e_3c_3e(v_t_242106, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242113})));
        V v_a_242115 = (g_std_2edoc_2egroup(v_t_242114));
        V v_b_242116 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242117 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str140)}), v_b_242116));
        return (g_std_2edoc_2e_3c_3e(v_a_242115, v_t_242117));
      } else {
        heff_drop_tag(v_x_241284, 7);
        heff_drop(v_t_241286);
        heff_drop(v_t_242105);
        V v_t_242118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242119 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242125 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam101, 1, 1, (V[]){v_one_242119}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242126 = (g_std_2edoc_2e_3c_3e(v_t_242118, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242125})));
        return (g_std_2edoc_2egroup(v_t_242126));
      }
    }
    case TAG_ELetMut: {
      V v_t_242133 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242133) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242133);
        V v_t_242134 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242135 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242141 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam102, 1, 1, (V[]){v_one_242135}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242142 = (g_std_2edoc_2e_3c_3e(v_t_242134, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242141})));
        V v_a_242143 = (g_std_2edoc_2egroup(v_t_242142));
        V v_b_242144 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242145 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str141)}), v_b_242144));
        return (g_std_2edoc_2e_3c_3e(v_a_242143, v_t_242145));
      } else {
        heff_drop_tag(v_x_241284, 6);
        heff_drop(v_t_241286);
        heff_drop(v_t_242133);
        V v_t_242146 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242153 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam103, 1, 1, (V[]){v_one_242147}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242154 = (g_std_2edoc_2e_3c_3e(v_t_242146, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242153})));
        return (g_std_2edoc_2egroup(v_t_242154));
      }
    }
    case TAG_EAssign: {
      V v_t_242158 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242158) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242158);
        V v_t_242159 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242160 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242166 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam104, 1, 1, (V[]){v_one_242160}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242167 = (g_std_2edoc_2e_3c_3e(v_t_242159, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242166})));
        V v_a_242168 = (g_std_2edoc_2egroup(v_t_242167));
        V v_b_242169 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242170 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str142)}), v_b_242169));
        return (g_std_2edoc_2e_3c_3e(v_a_242168, v_t_242170));
      } else {
        heff_drop_tag(v_x_241284, 3);
        heff_drop(v_t_241286);
        heff_drop(v_t_242158);
        V v_t_242171 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242178 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam105, 1, 1, (V[]){v_one_242172}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242179 = (g_std_2edoc_2e_3c_3e(v_t_242171, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242178})));
        return (g_std_2edoc_2egroup(v_t_242179));
      }
    }
    case TAG_EWhile: {
      V v_t_242184 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242184) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242184);
        V v_t_242185 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242186 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242192 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam106, 1, 1, (V[]){v_one_242186}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242193 = (g_std_2edoc_2e_3c_3e(v_t_242185, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242192})));
        V v_a_242194 = (g_std_2edoc_2egroup(v_t_242193));
        V v_b_242195 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242196 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str143)}), v_b_242195));
        return (g_std_2edoc_2e_3c_3e(v_a_242194, v_t_242196));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_242184);
        V v_t_242197 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242198 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242204 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam107, 1, 1, (V[]){v_one_242198}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242205 = (g_std_2edoc_2e_3c_3e(v_t_242197, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242204})));
        return (g_std_2edoc_2egroup(v_t_242205));
      }
    }
    case TAG_EFor: {
      V v_t_242212 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242212) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242212);
        V v_t_242213 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242214 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242220 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam108, 1, 1, (V[]){v_one_242214}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242221 = (g_std_2edoc_2e_3c_3e(v_t_242213, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242220})));
        V v_a_242222 = (g_std_2edoc_2egroup(v_t_242221));
        V v_b_242223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242224 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str144)}), v_b_242223));
        return (g_std_2edoc_2e_3c_3e(v_a_242222, v_t_242224));
      } else {
        heff_drop_tag(v_x_241284, 6);
        heff_drop(v_t_241286);
        heff_drop(v_t_242212);
        V v_t_242225 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242226 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242232 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam109, 1, 1, (V[]){v_one_242226}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242233 = (g_std_2edoc_2e_3c_3e(v_t_242225, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242232})));
        return (g_std_2edoc_2egroup(v_t_242233));
      }
    }
    case TAG_EJump: {
      V v_t_242235 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242235) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242235);
        V v_t_242236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242237 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242243 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam110, 1, 1, (V[]){v_one_242237}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242244 = (g_std_2edoc_2e_3c_3e(v_t_242236, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242243})));
        V v_a_242245 = (g_std_2edoc_2egroup(v_t_242244));
        V v_b_242246 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242247 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str145)}), v_b_242246));
        return (g_std_2edoc_2e_3c_3e(v_a_242245, v_t_242247));
      } else {
        heff_drop_tag(v_x_241284, 1);
        heff_drop(v_t_241286);
        heff_drop(v_t_242235);
        V v_t_242248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242249 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242255 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam111, 1, 1, (V[]){v_one_242249}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242256 = (g_std_2edoc_2e_3c_3e(v_t_242248, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242255})));
        return (g_std_2edoc_2egroup(v_t_242256));
      }
    }
    case TAG_EReturn: {
      V v_t_242259 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242259) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242259);
        V v_t_242260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242261 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242267 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam112, 1, 1, (V[]){v_one_242261}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242268 = (g_std_2edoc_2e_3c_3e(v_t_242260, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242267})));
        V v_a_242269 = (g_std_2edoc_2egroup(v_t_242268));
        V v_b_242270 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242271 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str146)}), v_b_242270));
        return (g_std_2edoc_2e_3c_3e(v_a_242269, v_t_242271));
      } else {
        heff_drop_tag(v_x_241284, 2);
        heff_drop(v_t_241286);
        heff_drop(v_t_242259);
        V v_t_242272 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242273 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242279 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam113, 1, 1, (V[]){v_one_242273}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242280 = (g_std_2edoc_2e_3c_3e(v_t_242272, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242279})));
        return (g_std_2edoc_2egroup(v_t_242280));
      }
    }
    case TAG_ENest: {
      V v_t_242285 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242285) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242285);
        V v_t_242286 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242287 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242293 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam114, 1, 1, (V[]){v_one_242287}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242294 = (g_std_2edoc_2e_3c_3e(v_t_242286, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242293})));
        V v_a_242295 = (g_std_2edoc_2egroup(v_t_242294));
        V v_b_242296 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242297 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str147)}), v_b_242296));
        return (g_std_2edoc_2e_3c_3e(v_a_242295, v_t_242297));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_242285);
        V v_t_242298 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242299 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242305 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam115, 1, 1, (V[]){v_one_242299}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242306 = (g_std_2edoc_2e_3c_3e(v_t_242298, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242305})));
        return (g_std_2edoc_2egroup(v_t_242306));
      }
    }
    case TAG_IfThen: {
      V v_t_242311 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242311) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242311);
        V v_t_242312 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242313 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242319 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam116, 1, 1, (V[]){v_one_242313}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242320 = (g_std_2edoc_2e_3c_3e(v_t_242312, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242319})));
        V v_a_242321 = (g_std_2edoc_2egroup(v_t_242320));
        V v_b_242322 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242323 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str148)}), v_b_242322));
        return (g_std_2edoc_2e_3c_3e(v_a_242321, v_t_242323));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_242311);
        V v_t_242324 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242325 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242331 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam117, 1, 1, (V[]){v_one_242325}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242332 = (g_std_2edoc_2e_3c_3e(v_t_242324, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242331})));
        return (g_std_2edoc_2egroup(v_t_242332));
      }
    }
    case TAG_ETry: {
      V v_t_242337 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242337) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242337);
        V v_t_242338 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242339 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242345 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam118, 1, 1, (V[]){v_one_242339}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242346 = (g_std_2edoc_2e_3c_3e(v_t_242338, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242345})));
        V v_a_242347 = (g_std_2edoc_2egroup(v_t_242346));
        V v_b_242348 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242349 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str149)}), v_b_242348));
        return (g_std_2edoc_2e_3c_3e(v_a_242347, v_t_242349));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_242337);
        V v_t_242350 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242351 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242357 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam119, 1, 1, (V[]){v_one_242351}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242358 = (g_std_2edoc_2e_3c_3e(v_t_242350, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242357})));
        return (g_std_2edoc_2egroup(v_t_242358));
      }
    }
    case TAG_ECatch: {
      V v_t_242363 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242363) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242363);
        V v_t_242364 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242365 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242371 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam120, 1, 1, (V[]){v_one_242365}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242372 = (g_std_2edoc_2e_3c_3e(v_t_242364, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242371})));
        V v_a_242373 = (g_std_2edoc_2egroup(v_t_242372));
        V v_b_242374 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242375 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str150)}), v_b_242374));
        return (g_std_2edoc_2e_3c_3e(v_a_242373, v_t_242375));
      } else {
        heff_drop_tag(v_x_241284, 4);
        heff_drop(v_t_241286);
        heff_drop(v_t_242363);
        V v_t_242376 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242377 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242383 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam121, 1, 1, (V[]){v_one_242377}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242384 = (g_std_2edoc_2e_3c_3e(v_t_242376, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242383})));
        return (g_std_2edoc_2egroup(v_t_242384));
      }
    }
    case TAG_EWith: {
      V v_t_242391 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_x_241284));
      if ((heff_dup(v_t_242391) == NTAG(TAG_True))) {
        heff_drop(v_args_241282);
        heff_drop(v_t_242391);
        V v_t_242392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242393 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_241280)}));
        V v_d_242399 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam122, 1, 1, (V[]){v_one_242393}); V a_2 = v_t_241286; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_t_241286); r_; });
        V v_t_242400 = (g_std_2edoc_2e_3c_3e(v_t_242392, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242399})));
        V v_a_242401 = (g_std_2edoc_2egroup(v_t_242400));
        V v_b_242402 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241280, v_x_241284}));
        V v_t_242403 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str151)}), v_b_242402));
        return (g_std_2edoc_2e_3c_3e(v_a_242401, v_t_242403));
      } else {
        heff_drop_tag(v_x_241284, 6);
        heff_drop(v_t_241286);
        heff_drop(v_t_242391);
        V v_t_242404 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241280), v_h_241281}));
        V v_one_242405 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_241280}));
        V v_d_242411 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam123, 1, 1, (V[]){v_one_242405}); V a_2 = v_args_241282; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_241282); r_; });
        V v_t_242412 = (g_std_2edoc_2e_3c_3e(v_t_242404, heff_tag_at_n(v_ru_24x1_241283_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_242411})));
        return (g_std_2edoc_2egroup(v_t_242412));
      }
    }
    default: return heff_nomatch(v_x_241284);
    }
  }
  default: return heff_nomatch(v_x1_241283);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam124(V self, V *args) {
  V v_env_242413 = args[0];
  V v_rest_242414 = args[1];
  V v_e_242415 = args[2];
  switch (heff_tag_of(v_e_242415)) {
  case TAG_Atom: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_242432 = heff_field(v_e_242415, 0);
    V v_fs_242433 = heff_field(v_e_242415, 1);
    V v_commas_242434 = heff_field(v_e_242415, 2);
    V v_c_242435 = heff_field(v_e_242415, 3);
    heff_take_n(v_e_242415, 15ULL, 4);
    switch (heff_tag_of(v_fs_242433)) {
    case TAG_Nil: {
      heff_drop(v_rest_242414);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_242413;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242432, v_fs_242433, v_commas_242434, v_c_242435});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_242436 = heff_dup(heff_field(v_fs_242433, 0));
      V v_rest2_242437 = heff_dup(heff_field(v_fs_242433, 1));
      switch (heff_tag_of(v_rest2_242437)) {
      case TAG_Nil: {
        V v_t_242438 = ({ V a_0 = v_rest_242414; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_242414); r_; });
        if ((heff_dup(v_t_242438) == NTAG(TAG_True))) {
          heff_drop(v_t_242438);
          V v_x1_242439 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_242436));
          if ((heff_dup(v_x1_242439) == NTAG(TAG_True))) {
            heff_drop(v_d_242436);
            heff_drop(v_x1_242439);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_242413;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242432, v_fs_242433, v_commas_242434, v_c_242435});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_242439);
            switch (heff_tag_of(v_commas_242434)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_242433, 2);
              V v_t_242440 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242413), v_o_242432));
              V v_t_242441 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242413), v_d_242436}));
              V v_t_242442 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242413, v_c_242435));
              V v_t_242443 = (g_std_2edoc_2e_3c_3e(v_t_242441, v_t_242442));
              return (g_std_2edoc_2e_3c_3e(v_t_242440, v_t_242443));
            }
            case TAG_Cons: {
              heff_drop(v_d_242436);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_242413;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242432, v_fs_242433, v_commas_242434, v_c_242435});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_242434);
            }
          }
        } else {
          heff_drop(v_d_242436);
          heff_drop(v_t_242438);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_242413;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242432, v_fs_242433, v_commas_242434, v_c_242435});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_242437, 0ULL, 2);
        heff_drop(v_rest_242414);
        heff_drop(v_d_242436);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_242413;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_242432, v_fs_242433, v_commas_242434, v_c_242435});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_242437);
      }
    }
    default: return heff_nomatch(v_fs_242433);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242414);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242413;
    args[1] = v_e_242415;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_242415);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam125(V self, V *args) {
  V v_env_242582 = args[0];
  V v_b_242583 = args[1];
  switch (heff_tag_of(v_b_242583)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_242649 = heff_field(v_b_242583, 0);
    heff_take_n(v_b_242583, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242582, v_t_242649));
  }
  case TAG_BImp: {
    V v_o_242650 = heff_field(v_b_242583, 0);
    V v_x_242651 = heff_field(v_b_242583, 1);
    V v_c_242652 = heff_field(v_b_242583, 2);
    heff_take_n(v_b_242583, 7ULL, 3);
    V v_t_242653 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242582), v_o_242650));
    V v_t_242654 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242582), v_x_242651));
    V v_t_242655 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242582, v_c_242652));
    V v_t_242656 = (g_std_2edoc_2e_3c_3e(v_t_242654, v_t_242655));
    return (g_std_2edoc_2e_3c_3e(v_t_242653, v_t_242656));
  }
  case TAG_BAnn: {
    V v_o_242657 = heff_field(v_b_242583, 0);
    V v_x_242658 = heff_field(v_b_242583, 1);
    V v_cc_242659 = heff_field(v_b_242583, 2);
    V v_ty_242660 = heff_field(v_b_242583, 3);
    V v_c_242661 = heff_field(v_b_242583, 4);
    heff_take_n(v_b_242583, 31ULL, 5);
    V v_t_242662 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242582), v_o_242657));
    V v_a_242663 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242582), v_x_242658));
    V v_a_242664 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242582), v_cc_242659));
    V v_b_242665 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242582), v_ty_242660}));
    V v_t_242666 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str152)}), v_b_242665));
    V v_t_242667 = (g_std_2edoc_2e_3c_3e(v_a_242664, v_t_242666));
    V v_t_242668 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str153)}), v_t_242667));
    V v_t_242669 = (g_std_2edoc_2e_3c_3e(v_a_242663, v_t_242668));
    V v_t_242670 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_242582, v_c_242661));
    V v_t_242671 = (g_std_2edoc_2e_3c_3e(v_t_242669, v_t_242670));
    return (g_std_2edoc_2e_3c_3e(v_t_242662, v_t_242671));
  }
  case TAG_BPat: {
    V v_p_242672 = heff_field(v_b_242583, 0);
    heff_take_n(v_b_242583, 1ULL, 1);
    return ({ V a_0 = v_env_242582; V a_1 = v_p_242672; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_242672); r_; });
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242582;
    args[1] = v_b_242583;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_242583);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam126(V self, V *args) {
  V v_env_242752 = args[0];
  V v_rest_242753 = args[1];
  V v_r_242754 = args[2];
  switch (heff_tag_of(v_r_242754)) {
  case TAG_Atom: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242815 = heff_field(v_r_242754, 0);
    V v_e_242816 = heff_field(v_r_242754, 1);
    heff_take_n(v_r_242754, 3ULL, 2);
    V v_a_242817 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242752), v_op_242815));
    V v_b_242818 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_242752, v_rest_242753, v_e_242816}));
    V v_t_242819 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str154)}), v_b_242818));
    return (g_std_2edoc_2e_3c_3e(v_a_242817, v_t_242819));
  }
  case TAG_Ann: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    heff_drop(v_rest_242753);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242752;
    args[1] = v_r_242754;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242754);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam127(V self, V *args) {
  V v_env_242912 = args[0];
  V v_r_242913 = args[1];
  switch (heff_tag_of(v_r_242913)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242974 = heff_field(v_r_242913, 0);
    V v_e_242975 = heff_field(v_r_242913, 1);
    heff_take_n(v_r_242913, 3ULL, 2);
    V v_a_242976 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242912), v_op_242974));
    V v_b_242977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_242912, v_e_242975}));
    V v_t_242978 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str155)}), v_b_242977));
    return (g_std_2edoc_2e_3c_3e(v_a_242976, v_t_242978));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242912;
    args[1] = v_r_242913;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_242913);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam129(V self, V *args) {
  V v_r_243084 = args[0];
  V v_env_243071 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243085 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_243084));
  V v_t_243086;
  if ((heff_dup(v_x1_243085) == NTAG(TAG_True))) {
    heff_drop(v_x1_243085);
    v_t_243086 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_243085);
    v_t_243086 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_243087 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_243071, v_r_243084}));
  return (g_std_2edoc_2e_3c_3e(v_t_243086, v_t_243087));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam130(V self, V *args) {
  V v_r_243093 = args[0];
  V v_env_243071 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243094 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_243093));
  V v_t_243095;
  if ((heff_dup(v_x1_243094) == NTAG(TAG_True))) {
    heff_drop(v_x1_243094);
    v_t_243095 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_243094);
    v_t_243095 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_243096 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_243071, v_r_243093}));
  return (g_std_2edoc_2e_3c_3e(v_t_243095, v_t_243096));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam128(V self, V *args) {
  V v_env_243071 = args[0];
  V v_first_243072 = args[1];
  V v_rest_243073 = args[2];
  V v_f_243074 = heff_dup(heff_rfield(v_env_243071, 6));
  HeffT2 v_t_243075 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_243074), heff_dup(v_rest_243073)));
  {
    V v_field_243077 = v_t_243075.f[1];
    int64_t v_tag_243076 = ((int64_t)v_t_243075.f[0]);
    V v_t_243082;
    if ((v_tag_243076 == ((int64_t)0ULL))) {
      V v_it1_243079 = v_field_243077;
      switch (heff_tag_of(v_it1_243079)) {
      case TAG_Nil: {
        heff_drop(v_f_243074);
        v_t_243082 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_243080 = heff_field(v_it1_243079, 0);
        V v_os_243081 = heff_field(v_it1_243079, 1);
        heff_take_n(v_it1_243079, 3ULL, 2);
        v_t_243082 = ({ V a_0 = v_f_243074; V a_1 = v_o_243080; V a_2 = v_os_243081; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_243081); r_; });
        break;
      }
      default: heff_nomatch(v_it1_243079);
      }
    } else {
      heff_drop(v_f_243074);
      heff_drop(v_field_243077);
      v_t_243082 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_243082)) {
    case TAG_Nothing: {
      V v_t_243083 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243071), v_first_243072}));
      V v_t_243088 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam129, 1, 1, (V[]){v_env_243071}); V a_2 = v_rest_243073; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_243073); r_; });
      V v_t_243089 = (g_std_2edoc_2e_3c_3e(v_t_243083, v_t_243088));
      return (g_std_2edoc_2egroup(v_t_243089));
    }
    case TAG_Just: {
      V v_m_243090 = heff_field(v_t_243082, 0);
      heff_take_n(v_t_243082, 1ULL, 1);
      V v_t_243091 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_243071, 6)), heff_dup(v_m_243090), v_rest_243073));
      if ((heff_dup(v_t_243091) == NTAG(TAG_True))) {
        heff_drop(v_m_243090);
        heff_drop(v_t_243091);
        V v_t_243092 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243071), v_first_243072}));
        V v_t_243097 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam130, 1, 1, (V[]){v_env_243071}); V a_2 = v_rest_243073; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_243073); r_; });
        V v_t_243098 = (g_std_2edoc_2e_3c_3e(v_t_243092, v_t_243097));
        return (g_std_2edoc_2egroup(v_t_243098));
      } else {
        heff_drop(v_t_243091);
        V v_t_243099 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_243071, v_m_243090, v_first_243072, NTAG(TAG_Nil), v_rest_243073}));
        return (g_std_2edoc_2egroup(v_t_243099));
      }
    }
    default: return heff_nomatch(v_t_243082);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam131(V self, V *args) {
  V v_env_243100 = args[0];
  V v_m_243101 = args[1];
  V v_f_243102 = args[2];
  V v_acc_243103 = args[3];
  V v_rs_243104 = args[4];
  switch (heff_tag_of(v_rs_243104)) {
  case TAG_Nil: {
    heff_drop(v_m_243101);
    V v_t_243105 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243103));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_243100;
    args[1] = v_f_243102;
    args[2] = v_t_243105;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_243106 = heff_field(v_rs_243104, 0);
    V v_rest2_243107 = heff_field(v_rs_243104, 1);
    heff_take_n(v_rs_243104, 3ULL, 2);
    switch (heff_tag_of(v_r_243106)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETilde: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_243168 = heff_dup(heff_field(v_r_243106, 0));
      V v_e_243169 = heff_dup(heff_field(v_r_243106, 1));
      V v_t_243170 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_243100, 6)), heff_dup(v_m_243101), heff_dup(heff_rfield(v_op_243168, 1))));
      switch (heff_tag_of(v_t_243170)) {
      case TAG_Tighter: {
        heff_drop_rec(v_op_243168, 9);
        heff_drop(v_e_243169);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243100;
        args[1] = v_m_243101;
        args[2] = v_f_243102;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
        args[4] = v_rest2_243107;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Looser: {
        heff_drop_rec(v_op_243168, 9);
        heff_drop(v_e_243169);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243100;
        args[1] = v_m_243101;
        args[2] = v_f_243102;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
        args[4] = v_rest2_243107;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Same: {
        V v_ru_24t_243170_24Same = heff_take_reuse_n(v_t_243170, 0ULL, 1);
        V v_t_243172 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243103));
        V v_t_243173 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_243100), v_f_243102, v_t_243172}));
        V v_x1_243174 = ({ V a_0 = v_r_243106; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_243106, 2); r_; });
        V v_t_243175;
        if ((heff_dup(v_x1_243174) == NTAG(TAG_True))) {
          heff_drop(v_x1_243174);
          v_t_243175 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_243174);
          v_t_243175 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_243176 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243100), v_op_243168));
        V v_b_243177 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_243100, v_m_243101, v_e_243169, NTAG(TAG_Nil), v_rest2_243107}));
        V v_t_243178 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_243170_24Same, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str156)}), v_b_243177));
        V v_t_243179 = (g_std_2edoc_2e_3c_3e(v_a_243176, v_t_243178));
        V v_t_243180 = (g_std_2edoc_2e_3c_3e(v_t_243175, v_t_243179));
        return (g_std_2edoc_2e_3c_3e(v_t_243173, v_t_243180));
      }
      case TAG_Unrelated: {
        heff_drop_rec(v_op_243168, 9);
        heff_drop(v_e_243169);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243100;
        args[1] = v_m_243101;
        args[2] = v_f_243102;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
        args[4] = v_rest2_243107;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_243170, 0ULL, 1);
        heff_drop_rec(v_op_243168, 9);
        heff_drop(v_e_243169);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_243100;
        args[1] = v_m_243101;
        args[2] = v_f_243102;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
        args[4] = v_rest2_243107;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
      default: return heff_nomatch(v_t_243170);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BPat: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetElse: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELetMut: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAssign: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWhile: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFor: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EJump: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EReturn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENest: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_IfThen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ETry: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECatch: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EWith: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_243100;
      args[1] = v_m_243101;
      args[2] = v_f_243102;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243106, v_acc_243103});
      args[4] = v_rest2_243107;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_243106);
    }
  }
  default: return heff_nomatch(v_rs_243104);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam132(V self, V *args) {
  V v_env_243274 = args[0];
  V v_a_243275 = args[1];
  switch (heff_tag_of(v_a_243275)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_243359 = heff_field(v_a_243275, 0);
    V v_arrow_243360 = heff_field(v_a_243275, 1);
    V v_body_243361 = heff_field(v_a_243275, 2);
    heff_take_n(v_a_243275, 7ULL, 3);
    V v_a_243362 = ({ V a_0 = heff_dup(v_env_243274); V a_1 = v_p_243359; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_243359); r_; });
    V v_b_243363 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243274), v_arrow_243360));
    V v_t_243364 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str157)}), v_b_243363));
    V v_t_243365 = (g_std_2edoc_2e_3c_3e(v_a_243362, v_t_243364));
    V v_t_243366 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243274, v_body_243361}));
    return (g_std_2edoc_2e_3c_3e(v_t_243365, v_t_243366));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243274;
    args[1] = v_a_243275;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_243275);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam133(V self, V *args) {
  V v_env_243435 = args[0];
  V v_s_243436 = args[1];
  switch (heff_tag_of(v_s_243436)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V v_d_243529 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_243435, v_s_243436}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_243529});
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_243532 = heff_field(v_s_243436, 0);
    V v_arrow_243533 = heff_field(v_s_243436, 1);
    V v_e_243534 = heff_field(v_s_243436, 2);
    heff_take_n(v_s_243436, 7ULL, 3);
    V v_a_243535 = ({ V a_0 = heff_dup(v_env_243435); V a_1 = v_x_243532; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_x_243532); r_; });
    V v_b_243536 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243435), v_arrow_243533));
    V v_t_243537 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str158)}), v_b_243536));
    V v_t_243538 = (g_std_2edoc_2e_3c_3e(v_a_243535, v_t_243537));
    V v_t_243539 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243435, v_e_243534}));
    return (g_std_2edoc_2e_3c_3e(v_t_243538, v_t_243539));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V v_d_243583 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_243435, v_s_243436}));
    return heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(-2LL), v_d_243583});
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243435;
    args[1] = v_s_243436;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_243436);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam134(V self, V *args) {
  V v_env_243598 = args[0];
  V v_f_243599 = args[1];
  switch (heff_tag_of(v_f_243599)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_243626 = heff_field(v_f_243599, 0);
    V v_eq_243627 = heff_field(v_f_243599, 1);
    V v_e_243628 = heff_field(v_f_243599, 2);
    heff_take_n(v_f_243599, 7ULL, 3);
    V v_a_243629 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243598), v_x_243626}));
    V v_b_243630 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243598), v_eq_243627));
    V v_t_243631 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str159)}), v_b_243630));
    V v_t_243632 = (g_std_2edoc_2e_3c_3e(v_a_243629, v_t_243631));
    V v_t_243633 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243598, v_e_243628}));
    return (g_std_2edoc_2e_3c_3e(v_t_243632, v_t_243633));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_243639 = heff_field(v_f_243599, 0);
    V v_eq_243640 = heff_field(v_f_243599, 1);
    V v_e_243641 = heff_field(v_f_243599, 2);
    heff_take_n(v_f_243599, 7ULL, 3);
    V v_a_243642 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243598), v_x_243639));
    V v_b_243643 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243598), v_eq_243640));
    V v_t_243644 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str160)}), v_b_243643));
    V v_t_243645 = (g_std_2edoc_2e_3c_3e(v_a_243642, v_t_243644));
    V v_t_243646 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243598, v_e_243641}));
    return (g_std_2edoc_2e_3c_3e(v_t_243645, v_t_243646));
  }
  case TAG_EFDefault: {
    V v_d_243647 = heff_field(v_f_243599, 0);
    V v_eq_243648 = heff_field(v_f_243599, 1);
    V v_e_243649 = heff_field(v_f_243599, 2);
    heff_take_n(v_f_243599, 7ULL, 3);
    V v_a_243650 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_243598), v_d_243647}));
    V v_b_243651 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_243598), v_eq_243648));
    V v_t_243652 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str161)}), v_b_243651));
    V v_t_243653 = (g_std_2edoc_2e_3c_3e(v_a_243650, v_t_243652));
    V v_t_243654 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_243598, v_e_243649}));
    return (g_std_2edoc_2e_3c_3e(v_t_243653, v_t_243654));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETilde: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BPat: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetElse: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELetMut: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAssign: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWhile: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFor: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EJump: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EReturn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENest: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_IfThen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ETry: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECatch: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EWith: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_243598;
    args[1] = v_f_243599;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_243599);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = heff_take_field(v_t_244, 7); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2412;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = heff_get_n(v_t_244, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop_rec(v_t_244, 9);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2412 = heff_get_n(v_t_244, 8, 9);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str16, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_d1_244 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_244)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_d1_244, 0);
      V v_d12_249 = heff_field(v_d1_244, 1);
      switch (heff_tag_of(v_d12_249)) {
      case TAG_Nil: {
        V v_x2_2410 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_248)));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3);
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      case TAG_Cons: {
        return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5);
      }
      default: return heff_nomatch(v_d12_249);
      }
    }
    default: return heff_nomatch(v_d1_244);
    }
  }
  case TAG_DInstance: {
    V v_n_2416 = heff_field(v_d_240, 1);
    V v_x2_2419 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2416)));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  case TAG_DEqn: {
    V v_n_2422 = heff_field(v_d_240, 0);
    V v_x2_2427 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2422)));
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
    }
    default: return heff_nomatch(v_x2_2427);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DMutual: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str14);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str15);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str16);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0, 7, "doctest");
Clo g_heff_2esyntax_2efmt_2elayout_2eblockExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eblockExpect(V v_env_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DImport: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DFixity: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DSig: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DInstance: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DEqn: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DData: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DType: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTheory: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DMutual: {
    V v_ds_2434 = heff_field(v_d_241, 1);
    V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ds_2434)));
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 7);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x1_2435, 0);
      heff_take_n(v_x1_2435, 1ULL, 2);
      switch (heff_tag_of(v_x_2436)) {
      case TAG_DImport: {
        heff_take_n(v_x_2436, 0ULL, 1);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DFixity: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DSig: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DInstance: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DEqn: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DData: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DType: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTheory: {
        heff_take_n(v_x_2436, 0ULL, 5);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DMutual: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DPrimitive: {
        heff_take_n(v_x_2436, 0ULL, 4);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DTest: {
        heff_take_n(v_x_2436, 0ULL, 2);
        heff_drop_rec(v_env_240, 7);
        return NTAG(TAG_Nil);
      }
      case TAG_DWatch: {
        V v_w_2477 = heff_field(v_x_2436, 0);
        V v_e_2478 = heff_field(v_x_2436, 1);
        heff_take_n(v_x_2436, 3ULL, 2);
        V v_t_2479 = heff_strEq(heff_get_n(v_w_2477, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2eblockExpect_str0));
        V v_t_2480 = (g_heff_2esyntax_2ecst_2elastE(v_e_2478));
        V v_t_2481 = heff_intAdd(heff_get_n(v_t_2480, 7, 9), MK_INT(1LL));
        HeffT2 v_t_2482 = ({ V b_0 = heff_get_n(v_env_240, 1, 7); V a_1 = v_t_2481; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2487;
        {
          V v_field_2484 = v_t_2482.f[1];
          int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
          if ((v_tag_2483 == ((int64_t)0ULL))) {
            V v_x_2486 = v_field_2484;
            v_t_2487 = v_x_2486;
          } else {
            heff_drop(v_field_2484);
            v_t_2487 = NTAG(TAG_Nil);
          }
        }
        return ({ V a_0 = v_t_2479; V a_1 = v_t_2487; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eexpectLines(a_0, a_1)); heff_drop(v_t_2479); r_; });
      }
      default: return heff_nomatch(v_x_2436);
      }
    }
    default: return heff_nomatch(v_x1_2435);
    }
  }
  case TAG_DPrimitive: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DTest: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  case TAG_DWatch: {
    heff_drop_rec(v_env_240, 7);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eblockExpect_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2efmt_2elayout_2eblockExpect(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_eof_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), heff_get_n(v_eof_243, 7, 9)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        v_t_2410 = v_x_249;
      } else {
        heff_drop(v_field_247);
        v_t_2410 = NTAG(TAG_Nil);
      }
    }
    return ({ V a_0 = v_env_240; V a_1 = v_t_2410; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_240, 7); heff_drop(v_t_2410); r_; });
  }
  case TAG_Cons: {
    V v_d_2411 = heff_field(v_x5_244, 0);
    V v_ds_2412 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_2411));
    V v_t_2455;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_DImport: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DMutual: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2455 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2453 = heff_dup(heff_field(v_d_2411, 0));
      v_t_2455 = heff_strEq(heff_get_n(v_w_2453, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2483;
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      heff_drop(v_t_2455);
      V v_t_2456 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
      V v_t_2457 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
      V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2456, v_t_2457, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_2411)})));
      V v_t_2460 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_2411); r_; });
      V v_t_2461 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2460, v_eof_243, v_ds_2412));
      v_t_2483 = (g_std_2edoc_2e_3c_3e(v_t_2459, v_t_2461));
    } else {
      heff_drop(v_t_2455);
      V v_t_2462 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_t_2462);
        V v_t_2463 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_2411));
        V v_t_2465 = ({ V a_0 = v_t_2464; V a_1 = heff_dup(v_d_2411); V a_2 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefLast(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
        V v_t_2466 = (g_heff_2esyntax_2ecst_2elastD(v_t_2465));
        V v_t_2467 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2463, v_t_2466));
        V v_t_2468 = ({ V a_0 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_2411); r_; });
        V v_t_2469 = ({ V a_0 = v_t_2468; V a_1 = v_ds_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(a_0, a_1)); heff_drop(v_t_2468); r_; });
        V v_t_2470 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_t_2469));
        v_t_2483 = (g_std_2edoc_2e_3c_3e(v_t_2467, v_t_2470));
      } else {
        heff_drop(v_t_2462);
        V v_expect_2471 = (g_heff_2esyntax_2efmt_2elayout_2eblockExpect(heff_dup(v_env_240), v_d_2411));
        V v_t_2472 = (g_heff_2esyntax_2ecst_2efirstD(v_d_2411));
        V v_t_2473 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_2411)));
        V v_t_2475 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2472, v_t_2473, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){heff_dup(v_d_2411)})));
        V v_d_2476 = (g_list_2efoldl_24f1134152647x940271785(heff_dup(g_std_2edoc_2eemptyDoc_get()), v_expect_2471));
        V v_t_2477 = (g_heff_2esyntax_2ecst_2elastD(v_d_2411));
        V v_t_2478 = heff_intAdd(heff_get_n(v_t_2477, 7, 9), MK_INT(1LL));
        V v_t_2479 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_expect_2471; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_expect_2471); r_; });
        V v_t_2480 = (g_heff_2esyntax_2efmt_2elayout_2eleadLaid(v_env_240, v_t_2478, v_t_2479));
        V v_t_2481 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_t_2480, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_eof_243, v_ds_2412));
        V v_t_2482 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_2476}), v_t_2481));
        v_t_2483 = (g_std_2edoc_2e_3c_3e(v_t_2475, v_t_2482));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_2413, v_t_2483));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2458 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2458; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2474 = args[0];
  V v_d_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2474; V a_1 = v_d_2411; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_2411); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = ({ V b_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1); V a_1 = v_s_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2), v_s_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_243); r_; });
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = ({ V b_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5); V a_2 = v_t_249; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ereplaceAll(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  return heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_claim_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    V v_t_245 = (g_heff_2esyntax_2efmt_2eimports_2eexposingToks(heff_rfield(v_claim_242, 1)));
    V v_t_246 = (g_list_2emap_24s1845612977x612508518(heff_get_n(v_claim_242, 0, 3)));
    V v_t_247 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_take_field(v_l_243, 0), v_t_245, v_t_246));
    V v_t_248 = (g_list_2esortBy_24s88152486x2058486153(v_t_247));
    HeffT2 v_t_249 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_248, heff_get_n(v_l_243, 2, 3)));
    V v_t_2413;
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_t_2412 = ({ V rv_6 = v_f_240; V rr_ = heff_rec_reuse_nf(v_field_2411, 63ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      v_t_2413 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2410, v_t_2412});
    }
    return (g_heff_2esyntax_2efmt_2elayout_2efmtAttached_24cpr(v_t_2413));
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_claim_242, 3);
    heff_drop_rec(v_l_243, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_244)}});
  }
}