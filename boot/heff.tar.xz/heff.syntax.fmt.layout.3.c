// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Column 1635
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DInstance 19095
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_EUSet 22856
#define TAG_FlatAlt 51908
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkDAlts 45152
#define TAG_Named 2049
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_None 17785
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Right 62770
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Text 56194
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_altDoc 532467194
#define LBL_appDoc 536042114
#define LBL_binderDoc 699885123
#define LBL_blank 295177582
#define LBL_chainOperand 1014709036
#define LBL_comments 142722952
#define LBL_elseOf 646984731
#define LBL_end 310101
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_i 323
#define LBL_ifLink 754803170
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_letHead 298925277
#define LBL_letLink 299048695
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_opRhsDoc 1839369833
#define LBL_opsChainDoc 1550538525
#define LBL_opsCut 936938843
#define LBL_opsRhsDoc 1917583336
#define LBL_pE 10300
#define LBL_raw 322210
#define LBL_rhsField 880867406
#define LBL_rhsOf 309851086
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmtDoc 493252245
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField[] = {LBL_pE, LBL_rhsOf, LBL_letHead, LBL_letLink, LBL_ifLink, LBL_elseOf, LBL_appDoc, LBL_chainOperand, LBL_binderDoc, LBL_opRhsDoc, LBL_opsRhsDoc, LBL_opsChainDoc, LBL_opsCut, LBL_altDoc, LBL_stmtDoc, LBL_rhsField};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2efmt_2elayout_2eafterDef(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eafterDef_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eafterDef_clo;
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V);
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo;
V g_heff_2esyntax_2efmt_2elayout_2easWritten(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2easWritten_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2easWritten_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo;
V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefLast(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2edefLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefLast_clo;
V g_heff_2esyntax_2efmt_2elayout_2edefName(V);
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtParsed_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs(V);
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V);
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo;
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo;
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo;
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eloosestGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eloosestGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2enewlineIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enewlineIn_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V);
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epD_clo;
V g_heff_2esyntax_2efmt_2elayout_2epListGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2epP(V, V);
V g_heff_2esyntax_2efmt_2elayout_2epP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2epP_clo;
V g_heff_2esyntax_2efmt_2elayout_2erender2(V);
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo;
V g_heff_2esyntax_2efmt_2elayout_2esameOp(V, V);
V g_heff_2esyntax_2efmt_2elayout_2esameOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2esameOp_clo;
V g_heff_2esyntax_2efmt_2elayout_2eskipped(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eskipped_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eskipped_clo;
V g_heff_2esyntax_2efmt_2elayout_2etok(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo;
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etrailOf(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etrailOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etrailOf_clo;
HeffT2 g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(V, V, V);
V g_list_2eall_24s78096928x1476871221(V, V, V);
V g_list_2eall_24s78096928x1476871221_entry(V self, V *a);
extern Clo g_list_2eall_24s78096928x1476871221_clo;
V g_list_2eany_24s1092144743x1559898298(V);
V g_list_2eany_24s1092144743x1559898298_entry(V self, V *a);
extern Clo g_list_2eany_24s1092144743x1559898298_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1160581125x508466714(V, V);
V g_list_2efoldl_24f1160581125x508466714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1160581125x508466714_clo;
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s759871588x920431471(V);
V g_list_2emap_24s759871588x920431471_entry(V self, V *a);
extern Clo g_list_2emap_24s759871588x920431471_clo;
V g_list_2esortBy_24s88152486x2058486153(V);
V g_list_2esortBy_24s88152486x2058486153_entry(V self, V *a);
extern Clo g_list_2esortBy_24s88152486x2058486153_clo;
HeffT2 g_map_2elookup_24s567992785x1569911877_24cpr(V, V);
V g_prelude_2e_2b_2b_24f201610143x1454021782(V, V);
V g_prelude_2e_2b_2b_24f201610143x1454021782_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f201610143x1454021782_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2econcatWith_24s593061764x1986092725(V, V);
V g_std_2edoc_2econcatWith_24s593061764x1986092725_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s593061764x1986092725_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0, 1, "\001");

static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2eblankMark_st;
static V g_heff_2esyntax_2efmt_2elayout_2eblankMark_init(void) {
  return ((V)&g_heff_2esyntax_2efmt_2elayout_2eblankMark_str0);
}
V g_heff_2esyntax_2efmt_2elayout_2eblankMark_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2eblankMark_st)) return g_heff_2esyntax_2efmt_2elayout_2eblankMark_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2eblankMark_val, &g_heff_2esyntax_2efmt_2elayout_2eblankMark_st, g_heff_2esyntax_2efmt_2elayout_2eblankMark_init);
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etok_str0, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2etok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etok_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2etok(V v_env_240, V v_t_241) {
top: ;
  V v_x1_248;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
    v_x1_248 = NTAG(TAG_Nil);
  } else {
    HeffT2 v_t_243 = (g_map_2elookup_24s567992785x1569911877_24cpr(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        v_x1_248 = v_x_247;
      } else {
        heff_drop(v_field_245);
        v_x1_248 = NTAG(TAG_Nil);
      }
    }
  }
  V v_t_2419;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    v_t_2419 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    V v_t_2417;
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 4)))) {
      v_t_2417 = NTAG(TAG_Nil);
    } else {
      HeffT2 v_t_2412 = (g_map_2elookup_24s567992785x1569911877_24cpr(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 1)));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_x_2416 = v_field_2414;
          v_t_2417 = v_x_2416;
        } else {
          heff_drop(v_field_2414);
          v_t_2417 = NTAG(TAG_Nil);
        }
      }
    }
    V v_t_2418 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24f1134152647x940271785(a_0, a_1)); heff_drop(v_t_2417); r_; });
    v_t_2419 = (g_std_2edoc_2e_3c_3e(v_t_2418, heff_dup(g_std_2edoc_2ehardline_get())));
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  HeffT2 v_t_2420 = (g_map_2elookup_24s567992785x1569911877_24cpr(heff_dup(heff_rfield(v_t_241, 7)), heff_rfield(v_env_240, 2)));
  V v_t_2425;
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_x_2424 = v_field_2422;
      v_t_2425 = v_x_2424;
    } else {
      heff_drop(v_field_2422);
      v_t_2425 = NTAG(TAG_Nil);
    }
  }
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24f1160581125x508466714(a_0, a_1)); heff_drop(v_t_2425); r_; });
  V v_s_2427 = heff_dup(heff_rfield(v_t_241, 2));
  V v_t_2429;
  if (heff_strEq_c_lent(v_s_2427, ((V)&g_heff_2esyntax_2efmt_2elayout_2etok_str0), 2)) {
    heff_drop(v_s_2427);
    v_t_2429 = NTAG(TAG_None);
  } else {
    v_t_2429 = heff_tag_n(TAG_Text, 1, (V[]){v_s_2427});
  }
  V v_t_2431;
  if (heff_intEq_c(heff_dup(heff_rfield(v_t_241, 7)), heff_dup(heff_rfield(v_env_240, 5)))) {
    heff_drop_rec(v_env_240, 7);
    heff_drop_rec(v_t_241, 9);
    v_t_2431 = heff_dup(g_std_2edoc_2eemptyDoc_get());
  } else {
    v_t_2431 = (g_heff_2esyntax_2efmt_2elayout_2etrailOf(v_env_240, v_t_241));
  }
  V v_t_2432 = (g_std_2edoc_2e_3c_3e(v_t_2429, v_t_2431));
  V v_t_2433 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2432));
  HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2433);
}
V g_heff_2esyntax_2efmt_2elayout_2etok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etok(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2eleadDocs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eleadDocs(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_t_246;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_245 = heff_dup(heff_rfield(v_c_242, 1));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_245);
        v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    } else {
      v_t_246 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_247 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_dup(heff_rfield(v_c_242, 0))));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2eleadDocs(v_cs_243, heff_intAdd(v_i_241, MK_INT(1LL))));
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_247, v_t_249));
    HEFF_LAST return g_std_2edoc_2e_3c_3e(v_t_246, v_t_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eleadDocs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eleadDocs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eopensBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eopensBlock(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_True);
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eopensBlock_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eopensBlock(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2ehangs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ehangs_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ehangs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    V v_body_2476 = heff_field(v_e_240, 3);
    V t_0 = v_body_2476;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    return NTAG(TAG_True);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_True);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ehangs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ehangs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0, 1, "=");
Clo g_heff_2esyntax_2efmt_2elayout_2eisFSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisFSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    V v_eq_2439 = heff_field(v_x1_240, 1);
    return heff_strEq(heff_dup(heff_rfield(v_eq_2439, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eisFSet_str0));
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisFSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eisFSet(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Named: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Braces: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Update: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EField: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_App: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Op: {
    V v_a_2454 = heff_field(v_e_240, 0);
    V v_op_2455 = heff_field(v_e_240, 1);
    V v_b_2456 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_dup(v_b_2456)));
    {
      V v_field_2458 = v_t_2457.f[0];
      V v_field_2459 = v_t_2457.f[1];
      V v_bf_2460 = v_field_2458;
      V v_rest_2461 = v_field_2459;
      V v_t_2462 = (g_heff_2esyntax_2efmt_2elayout_2esameOp(heff_dup(v_op_2455), v_rest_2461));
      if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
        heff_drop(v_b_2456);
        heff_drop(v_t_2462);
        V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_bf_2460}), v_rest_2461});
        return ((HeffT2){{v_a_2454, v_t_2463}});
      } else {
        heff_drop(v_bf_2460);
        heff_drop(v_rest_2461);
        heff_drop(v_t_2462);
        V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_op_2455, v_b_2456}), NTAG(TAG_Nil)});
        return ((HeffT2){{v_a_2454, v_t_2464}});
      }
    }
  }
  case TAG_Ops: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Case: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_If: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_Do: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0, 2, "->");
Clo g_heff_2esyntax_2efmt_2elayout_2eanyArrow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eanyArrow(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Atom: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Seg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Update: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EUSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ECon: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EField: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ENeg: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_OpRhs: {
      V v_op_2461 = heff_field(v_x11_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_2461, 1)), ((V)&g_heff_2esyntax_2efmt_2elayout_2eanyArrow_str0))) {
        return NTAG(TAG_True);
      } else {
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
    }
    case TAG_Ann: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eanyArrow_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2epListGo_str0, 1, " ");
Clo g_heff_2esyntax_2efmt_2elayout_2epListGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2epListGo_entry, 5, 0};

V g_heff_2esyntax_2efmt_2elayout_2epListGo(V v_env_240, V v_pOne_241, V v_x3_242, V v_commas_243, V v_isFirst_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_pOne_241);
    heff_drop(v_commas_243);
    heff_drop(v_isFirst_244);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_ps_246 = heff_field(v_x3_242, 1);
    V v_t_2410;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    } else {
      switch (heff_tag_of(v_commas_243)) {
      case TAG_Nil: {
        v_t_2410 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_dup(heff_field(v_commas_243, 0));
        V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_247));
        v_t_2410 = (g_std_2edoc_2e_3c_3e(v_t_249, heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2epListGo_str0)})));
        break;
      }
      default: heff_nomatch(v_commas_243);
      }
    }
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_pOne_241), 1, (V[]){heff_dup(v_p_245)}));
    V v_t_2412;
    if ((heff_dup(v_isFirst_244) == NTAG(TAG_True))) {
      heff_drop(v_isFirst_244);
      v_t_2412 = v_commas_243;
    } else {
      heff_drop(v_isFirst_244);
      v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = v_commas_243; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_commas_243); r_; });
    }
    V v_t_2413 = (g_heff_2esyntax_2efmt_2elayout_2epListGo(v_env_240, v_pOne_241, v_ps_246, v_t_2412, NTAG(TAG_False)));
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_2411, v_t_2413));
    return (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2414));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2epListGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2epListGo(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2efmt_2elayout_2eisSameIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eisSameIn(V v_f_240, V v_m_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_Atom: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_App: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_r_242, 0);
    V v_t_2463 = (g_heff_2esyntax_2efixity_2erelate(v_f_240, v_m_241, heff_dup(heff_rfield(v_op_2461, 1))));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_Tighter: {
      return NTAG(TAG_False);
    }
    case TAG_Looser: {
      return NTAG(TAG_False);
    }
    case TAG_Same: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_True);
    }
    case TAG_Unrelated: {
      return NTAG(TAG_False);
    }
    case TAG_Undeclared: {
      heff_take_n(v_t_2463, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_Ann: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_If: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_f_240);
    heff_drop(v_m_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eisSameIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eisSameIn(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2415;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
      V v_t_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
      HeffT2 v_t_247 = (g_map_2elookup_24s567992785x1569911877_24cpr(heff_take_field(v_t_246, 7), heff_rfield(v_env_240, 1)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_t_2414;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2411 = v_field_249;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_Nil: {
            v_t_2414 = heff_get_n(v_t_246, 8, 9);
            break;
          }
          case TAG_Cons: {
            V v_x_2412 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            heff_drop_rec(v_t_246, 9);
            v_t_2414 = heff_get_n(v_x_2412, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
        } else {
          heff_drop(v_field_249);
          v_t_2414 = heff_get_n(v_t_246, 8, 9);
        }
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2414);
          v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2415 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x_243));
    V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_x_243)));
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2416, v_t_2417, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2420 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2421 = (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2420));
    V v_t_2422 = (g_std_2edoc_2e_3c_3e(v_t_2415, v_t_2421));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2422));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746_lam0(V self, V *args) {
  V v_e_2418 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 13));
  heff_room[0] = v_e_2418;
  heff_room[1] = v_x_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str2, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str13, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str14, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str21, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str25, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str27, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str28, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str31, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str33, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str34, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str39, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str41, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str43, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str45, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str49, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str51, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str53, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str55, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str57, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str59, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str61, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str63, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str65, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str67, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str69, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str71, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str72, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str75, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str76, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str77, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str79, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str81, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str83, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str85, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str89, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str91, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str93, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str95, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str99, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str100, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str101, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str103, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str105, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str106, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str109, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2elay_str110, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam0, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam20, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam21, 6, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam22, 8, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam23, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam24, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam25, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam86, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam87, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam88_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam88, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam89, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam90, 3, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam93, 5, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam94, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam95, 2, 0};
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args); static Clo g_heff_2esyntax_2efmt_2elayout_2elay_lam96_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elay_lam96, 2, 0};

static V g_heff_2esyntax_2efmt_2elayout_2elay_val;
static HEFF_ONCE g_heff_2esyntax_2efmt_2elayout_2elay_st;
static V g_heff_2esyntax_2efmt_2elayout_2elay_init(void) {
  return heff_rec_n(16, shape_pE__rhsOf__letHead__letLink__ifLink__elseOf__appDoc__chainOperand__binderDoc__opRhsDoc__opsRhsDoc__opsChainDoc__opsCut__altDoc__stmtDoc__rhsField, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam0_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam20_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam21_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam22_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam23_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam24_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam25_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam86_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam87_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam88_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam89_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam90_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam93_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam94_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam95_clo), ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_lam96_clo)});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2efmt_2elayout_2elay_st)) return g_heff_2esyntax_2efmt_2elayout_2elay_val;
  return heff_global(&g_heff_2esyntax_2efmt_2elayout_2elay_val, &g_heff_2esyntax_2efmt_2elayout_2elay_st, g_heff_2esyntax_2efmt_2elayout_2elay_init);
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam2(V self, V *args) {
  V v_i_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_d_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2411 = heff_intSub(v_k_249, v_i_2410);
  if (heff_intEq_c(heff_dup(v_i_2411), MK_INT(0LL))) {
    heff_drop(v_i_2411);
    return v_d_247;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2411, v_d_247});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_d_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam2, 1, 2, (V[]){v_k_249, v_d_247})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam3(V self, V *args) {
  V v_comma_2440 = args[0];
  V v_e_2441 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2440));
  V v_b_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_2441}));
  V v_t_2444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str3)}), v_b_2443));
  V v_t_2445 = (g_std_2edoc_2e_3c_3e(v_a_2442, v_t_2444));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2445));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam5(V self, V *args) {
  V v_i_2456 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_d_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2457 = heff_intSub(v_k_2455, v_i_2456);
  if (heff_intEq_c(heff_dup(v_i_2457), MK_INT(0LL))) {
    heff_drop(v_i_2457);
    return v_d_2454;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2457, v_d_2454});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam4(V self, V *args) {
  V v_k_2455 = args[0];
  V v_d_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam5, 1, 2, (V[]){v_k_2455, v_d_2454})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam6(V self, V *args) {
  V v_t_2464 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_2464));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam7(V self, V *args) {
  V v_comma_2479 = args[0];
  V v_f_2480 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2481 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_2479));
  V v_d_2482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_2480}));
  V v_t_2483 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str5)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2482})));
  V v_t_2484 = (g_std_2edoc_2e_3c_3e(v_a_2481, v_t_2483));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_2484));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam9(V self, V *args) {
  V v_i_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_d_2491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_2494 = heff_intSub(v_k_2492, v_i_2493);
  if (heff_intEq_c(heff_dup(v_i_2494), MK_INT(0LL))) {
    heff_drop(v_i_2494);
    return v_d_2491;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_2494, v_d_2491});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam8(V self, V *args) {
  V v_k_2492 = args[0];
  V v_d_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam9, 1, 2, (V[]){v_k_2492, v_d_2491})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam10(V self, V *args) {
  V v_comma_24121 = args[0];
  V v_f_24122 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_24123 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_comma_24121));
  V v_d_24124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){v_env_240, v_f_24122}));
  V v_t_24125 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str11)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24124})));
  V v_t_24126 = (g_std_2edoc_2e_3c_3e(v_a_24123, v_t_24125));
  return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2elinebreak_get()), v_t_24126));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam12(V self, V *args) {
  V v_i_24137 = args[0];
  V v_k_24136 = heff_env(self)[0];
  V v_d_24135 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24138 = heff_intSub(v_k_24136, v_i_24137);
  if (heff_intEq_c(heff_dup(v_i_24138), MK_INT(0LL))) {
    heff_drop(v_i_24138);
    return v_d_24135;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24138, v_d_24135});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam11(V self, V *args) {
  V v_k_24136 = args[0];
  V v_d_24135 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam12, 1, 2, (V[]){v_k_24136, v_d_24135})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam13(V self, V *args) {
  V v_bar_24195 = args[0];
  V v_a_24196 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_o_24178 = heff_env(self)[1];
  V v_c_24181 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_24197 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_24178, 4, 9), heff_get_n(v_c_24181, 3, 9)));
  V v_t_24198;
  if ((heff_dup(v_x1_24197) == NTAG(TAG_True))) {
    heff_drop(v_x1_24197);
    v_t_24198 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24197);
    v_t_24198 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24199 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_24195));
  V v_b_24200 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24196}));
  V v_t_24201 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str18)}), v_b_24200));
  V v_t_24202 = (g_std_2edoc_2e_3c_3e(v_a_24199, v_t_24201));
  return (g_std_2edoc_2e_3c_3e(v_t_24198, v_t_24202));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam15(V self, V *args) {
  V v_i_24209 = args[0];
  V v_k_24208 = heff_env(self)[0];
  V v_d_24207 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24210 = heff_intSub(v_k_24208, v_i_24209);
  if (heff_intEq_c(heff_dup(v_i_24210), MK_INT(0LL))) {
    heff_drop(v_i_24210);
    return v_d_24207;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24210, v_d_24207});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam14(V self, V *args) {
  V v_k_24208 = args[0];
  V v_d_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam15, 1, 2, (V[]){v_k_24208, v_d_24207})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam16(V self, V *args) {
  V v_a_24217 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24218 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_24217}));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str21)}), v_t_24218));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam17(V self, V *args) {
  V v_r_24239 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_rest_24237 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24240 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_24239));
  V v_t_24241;
  if ((heff_dup(v_x1_24240) == NTAG(TAG_True))) {
    heff_drop(v_x1_24240);
    v_t_24241 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24240);
    v_t_24241 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24242 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 9)), 3, (V[]){v_env_240, v_rest_24237, v_r_24239}));
  return (g_std_2edoc_2e_3c_3e(v_t_24241, v_t_24242));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam19(V self, V *args) {
  V v_i_24355 = args[0];
  V v_k_24354 = heff_env(self)[0];
  V v_d_24353 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_i_24356 = heff_intSub(v_k_24354, v_i_24355);
  if (heff_intEq_c(heff_dup(v_i_24356), MK_INT(0LL))) {
    heff_drop(v_i_24356);
    return v_d_24353;
  } else {
    return heff_tag_n(TAG_Nest, 2, (V[]){v_i_24356, v_d_24353});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam18(V self, V *args) {
  V v_k_24354 = args[0];
  V v_d_24353 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nesting, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam19, 1, 2, (V[]){v_k_24354, v_d_24353})});
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam0(V self, V *args) {
  V v_env_240 = args[0];
  V v_e0_241 = args[1];
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_242 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_242));
  }
  case TAG_EParen: {
    V v_o_243 = heff_field(v_e0_241, 0);
    V v_e_244 = heff_field(v_e0_241, 1);
    V v_c_245 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_243));
    V v_d_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_244}));
    V v_t_248 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_245));
    V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam1, 1, 1, (V[]){v_d_247})}), v_t_248));
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
  }
  case TAG_Named: {
    V v_o_2414 = heff_field(v_e0_241, 0);
    V v_x_2415 = heff_field(v_e0_241, 1);
    V v_k_2416 = heff_field(v_e0_241, 2);
    V v_e_2417 = heff_field(v_e0_241, 3);
    V v_c_2418 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_2419 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2414));
    V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_2415));
    V v_a_2421 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_k_2416));
    V v_b_2422 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_2417}));
    V v_t_2423 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str0)}), v_b_2422));
    V v_t_2424 = (g_std_2edoc_2e_3c_3e(v_a_2421, v_t_2423));
    V v_t_2425 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str1)}), v_t_2424));
    V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2425));
    V v_t_2427 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2418));
    V v_t_2428 = (g_std_2edoc_2e_3c_3e(v_t_2426, v_t_2427));
    return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2428));
  }
  case TAG_Tup: {
    V v_o_2429 = heff_field(v_e0_241, 0);
    V v_es_2430 = heff_field(v_e0_241, 1);
    V v_commas_2431 = heff_field(v_e0_241, 2);
    V v_c_2432 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_es_2430)) {
    case TAG_Nil: {
      heff_drop(v_commas_2431);
      V v_t_2433 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2429));
      V v_t_2434 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      return (g_std_2edoc_2e_3c_3e(v_t_2433, v_t_2434));
    }
    case TAG_Cons: {
      V v_e1_2435 = heff_field(v_es_2430, 0);
      V v_more_2436 = heff_field(v_es_2430, 1);
      V v_ru_24es_2430_24Cons = heff_take_reuse_n(v_es_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2429)));
      V v_t_2438 = heff_tag_at_n(v_ru_24es_2430_24Cons, TAG_FlatAlt, 2, (V[]){heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str2)}), heff_dup(g_std_2edoc_2eemptyDoc_get())});
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e1_2435}));
      V v_t_2446 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam3, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2431; V a_3 = v_more_2436; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2431); heff_drop(v_more_2436); r_; });
      V v_x1_2447 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_2429, 4, 9), heff_dup(heff_rfield(v_c_2432, 3))));
      V v_t_2448;
      if ((heff_dup(v_x1_2447) == NTAG(TAG_True))) {
        heff_drop(v_x1_2447);
        v_t_2448 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2447);
        v_t_2448 = heff_dup(g_std_2edoc_2elinebreak_get());
      }
      V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2432));
      V v_t_2450 = (g_std_2edoc_2e_3c_3e(v_t_2448, v_t_2449));
      V v_t_2451 = (g_std_2edoc_2e_3c_3e(v_t_2446, v_t_2450));
      V v_t_2452 = (g_std_2edoc_2e_3c_3e(v_t_2439, v_t_2451));
      V v_t_2453 = (g_std_2edoc_2e_3c_3e(v_t_2438, v_t_2452));
      V v_d_2454 = (g_std_2edoc_2e_3c_3e(v_t_2437, v_t_2453));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam4, 1, 1, (V[]){v_d_2454})})));
    }
    default: return heff_nomatch(v_es_2430);
    }
  }
  case TAG_Seg: {
    V v_v_2459 = heff_field(v_e0_241, 0);
    V v_cc_2460 = heff_field(v_e0_241, 1);
    V v_spec_2461 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_v_2459}));
    V v_t_2463 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_2460));
    V v_t_2465 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam6, 1, 1, (V[]){v_env_240}); V a_2 = v_spec_2461; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_spec_2461); r_; });
    V v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2463, v_t_2465));
    return (g_std_2edoc_2e_3c_3e(v_t_2462, v_t_2466));
  }
  case TAG_Braces: {
    V v_o_2467 = heff_field(v_e0_241, 0);
    V v_fs_2468 = heff_field(v_e0_241, 1);
    V v_commas_2469 = heff_field(v_e0_241, 2);
    V v_c_2470 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    switch (heff_tag_of(v_fs_2468)) {
    case TAG_Nil: {
      heff_drop(v_commas_2469);
      V v_t_2471 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2467));
      V v_t_2472 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2470));
      return (g_std_2edoc_2e_3c_3e(v_t_2471, v_t_2472));
    }
    case TAG_Cons: {
      V v_f1_2473 = heff_field(v_fs_2468, 0);
      V v_more_2474 = heff_field(v_fs_2468, 1);
      V v_ru_24fs_2468_24Cons = heff_take_reuse_n(v_fs_2468, 3ULL, 2);
      V v_a_2475 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2467)));
      V v_d_2476 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_2473}));
      V v_t_2477 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str4)}), heff_tag_at_n(v_ru_24fs_2468_24Cons, TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_2476})));
      V v_t_2478 = (g_std_2edoc_2e_3c_3e(v_a_2475, v_t_2477));
      V v_t_2485 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam7, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_2469; V a_3 = v_more_2474; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_2469); heff_drop(v_more_2474); r_; });
      V v_x1_2486 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_2467, 4, 9), heff_dup(heff_rfield(v_c_2470, 3))));
      V v_t_2487;
      if ((heff_dup(v_x1_2486) == NTAG(TAG_True))) {
        heff_drop(v_x1_2486);
        v_t_2487 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_2486);
        v_t_2487 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_2488 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_2470));
      V v_t_2489 = (g_std_2edoc_2e_3c_3e(v_t_2487, v_t_2488));
      V v_t_2490 = (g_std_2edoc_2e_3c_3e(v_t_2485, v_t_2489));
      V v_d_2491 = (g_std_2edoc_2e_3c_3e(v_t_2478, v_t_2490));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam8, 1, 1, (V[]){v_d_2491})})));
    }
    default: return heff_nomatch(v_fs_2468);
    }
  }
  case TAG_Update: {
    V v_o_2496 = heff_field(v_e0_241, 0);
    V v_r_2497 = heff_field(v_e0_241, 1);
    V v_bar_2498 = heff_field(v_e0_241, 2);
    V v_fs_2499 = heff_field(v_e0_241, 3);
    V v_commas_24100 = heff_field(v_e0_241, 4);
    V v_c_24101 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_fs_2499)) {
    case TAG_Nil: {
      heff_drop(v_commas_24100);
      V v_a_24102 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_2496));
      V v_a_24103 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_2497}));
      V v_a_24104 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2498));
      V v_b_24105 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24101));
      V v_t_24106 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str6)}), v_b_24105));
      V v_t_24107 = (g_std_2edoc_2e_3c_3e(v_a_24104, v_t_24106));
      V v_t_24108 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str7)}), v_t_24107));
      V v_t_24109 = (g_std_2edoc_2e_3c_3e(v_a_24103, v_t_24108));
      V v_t_24110 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str8)}), v_t_24109));
      return (g_std_2edoc_2e_3c_3e(v_a_24102, v_t_24110));
    }
    case TAG_Cons: {
      V v_f1_24111 = heff_field(v_fs_2499, 0);
      V v_more_24112 = heff_field(v_fs_2499, 1);
      V v_ru_24fs_2499_24Cons = heff_take_reuse_n(v_fs_2499, 3ULL, 2);
      V v_a_24113 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_2496)));
      V v_d_24114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_r_2497}));
      V v_t_24115 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str9)}), heff_tag_at_n(v_ru_24fs_2499_24Cons, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24114})));
      V v_t_24116 = (g_std_2edoc_2e_3c_3e(v_a_24113, v_t_24115));
      V v_a_24117 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2498));
      V v_d_24118 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 15)), 2, (V[]){heff_dup(v_env_240), v_f1_24111}));
      V v_t_24119 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str10)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(4LL), v_d_24118})));
      V v_t_24120 = (g_std_2edoc_2e_3c_3e(v_a_24117, v_t_24119));
      V v_t_24127 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam10, 2, 1, (V[]){heff_dup(v_env_240)}); V a_2 = v_commas_24100; V a_3 = v_more_24112; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_commas_24100); heff_drop(v_more_24112); r_; });
      V v_x1_24128 = (g_heff_2esyntax_2efmt_2elayout_2enewlineIn(heff_dup(heff_rfield(v_env_240, 0)), heff_get_n(v_o_2496, 4, 9), heff_dup(heff_rfield(v_c_24101, 3))));
      V v_t_24129;
      if ((heff_dup(v_x1_24128) == NTAG(TAG_True))) {
        heff_drop(v_x1_24128);
        v_t_24129 = heff_dup(g_std_2edoc_2ehardline_get());
      } else {
        heff_drop(v_x1_24128);
        v_t_24129 = heff_dup(g_std_2edoc_2eline_get());
      }
      V v_t_24130 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24101));
      V v_t_24131 = (g_std_2edoc_2e_3c_3e(v_t_24129, v_t_24130));
      V v_t_24132 = (g_std_2edoc_2e_3c_3e(v_t_24127, v_t_24131));
      V v_t_24133 = (g_std_2edoc_2e_3c_3e(v_t_24120, v_t_24132));
      V v_t_24134 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24133));
      V v_d_24135 = (g_std_2edoc_2e_3c_3e(v_t_24116, v_t_24134));
      return (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam11, 1, 1, (V[]){v_d_24135})})));
    }
    default: return heff_nomatch(v_fs_2499);
    }
  }
  case TAG_EUSet: {
    V v_x_24140 = heff_field(v_e0_241, 0);
    V v_eq_24141 = heff_field(v_e0_241, 1);
    V v_e_24142 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24143 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_x_24140}));
    V v_b_24144 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24141));
    V v_t_24145 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str12)}), v_b_24144));
    V v_t_24146 = (g_std_2edoc_2e_3c_3e(v_a_24143, v_t_24145));
    V v_t_24147 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24142}));
    return (g_std_2edoc_2e_3c_3e(v_t_24146, v_t_24147));
  }
  case TAG_InstB: {
    V v_o_24148 = heff_field(v_e0_241, 0);
    V v_o2_24149 = heff_field(v_e0_241, 1);
    V v_d_24150 = heff_field(v_e0_241, 2);
    V v_c1_24151 = heff_field(v_e0_241, 3);
    V v_c_24152 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24153 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24148));
    V v_t_24154 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o2_24149));
    V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24150}));
    V v_t_24156 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c1_24151));
    V v_t_24157 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24152));
    V v_t_24158 = (g_std_2edoc_2e_3c_3e(v_t_24156, v_t_24157));
    V v_t_24159 = (g_std_2edoc_2e_3c_3e(v_t_24155, v_t_24158));
    V v_t_24160 = (g_std_2edoc_2e_3c_3e(v_t_24154, v_t_24159));
    return (g_std_2edoc_2e_3c_3e(v_t_24153, v_t_24160));
  }
  case TAG_EFSet: {
    V v_x_24161 = heff_field(v_e0_241, 0);
    V v_eq_24162 = heff_field(v_e0_241, 1);
    V v_e_24163 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24164 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24161));
    V v_b_24165 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24162));
    V v_t_24166 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str13)}), v_b_24165));
    V v_t_24167 = (g_std_2edoc_2e_3c_3e(v_a_24164, v_t_24166));
    V v_t_24168 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24163}));
    return (g_std_2edoc_2e_3c_3e(v_t_24167, v_t_24168));
  }
  case TAG_EFDefault: {
    V v_d_24169 = heff_field(v_e0_241, 0);
    V v_eq_24170 = heff_field(v_e0_241, 1);
    V v_e_24171 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24172 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_d_24169}));
    V v_b_24173 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_eq_24170));
    V v_t_24174 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str14)}), v_b_24173));
    V v_t_24175 = (g_std_2edoc_2e_3c_3e(v_a_24172, v_t_24174));
    V v_t_24176 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24171}));
    return (g_std_2edoc_2e_3c_3e(v_t_24175, v_t_24176));
  }
  case TAG_Sum: {
    V v_kw_24177 = heff_field(v_e0_241, 0);
    V v_o_24178 = heff_field(v_e0_241, 1);
    V v_alts_24179 = heff_field(v_e0_241, 2);
    V v_bars_24180 = heff_field(v_e0_241, 3);
    V v_c_24181 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    switch (heff_tag_of(v_alts_24179)) {
    case TAG_Nil: {
      heff_drop(v_bars_24180);
      V v_a_24182 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24177));
      V v_a_24183 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24178));
      V v_b_24184 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24181));
      V v_t_24185 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str15)}), v_b_24184));
      V v_t_24186 = (g_std_2edoc_2e_3c_3e(v_a_24183, v_t_24185));
      V v_t_24187 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str16)}), v_t_24186));
      return (g_std_2edoc_2e_3c_3e(v_a_24182, v_t_24187));
    }
    case TAG_Cons: {
      V v_a1_24188 = heff_field(v_alts_24179, 0);
      V v_more_24189 = heff_field(v_alts_24179, 1);
      heff_take_n(v_alts_24179, 3ULL, 2);
      V v_a_24190 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24177));
      V v_a_24191 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_o_24178)));
      V v_b_24192 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_24188}));
      V v_t_24193 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str17)}), v_b_24192));
      V v_t_24194 = (g_std_2edoc_2e_3c_3e(v_a_24191, v_t_24193));
      V v_a_24203 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam13, 2, 3, (V[]){heff_dup(v_env_240), v_o_24178, heff_dup(v_c_24181)}); V a_2 = v_bars_24180; V a_3 = v_more_24189; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_24180); heff_drop(v_more_24189); r_; });
      V v_b_24204 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24181));
      V v_t_24205 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str19)}), v_b_24204));
      V v_t_24206 = (g_std_2edoc_2e_3c_3e(v_a_24203, v_t_24205));
      V v_d_24207 = (g_std_2edoc_2e_3c_3e(v_t_24194, v_t_24206));
      V v_b_24212 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam14, 1, 1, (V[]){v_d_24207})})));
      V v_t_24213 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str20)}), v_b_24212));
      return (g_std_2edoc_2e_3c_3e(v_a_24190, v_t_24213));
    }
    default: return heff_nomatch(v_alts_24179);
    }
  }
  case TAG_ECon: {
    V v_c_24214 = heff_field(v_e0_241, 0);
    V v_args_24215 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24216 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_c_24214));
    V v_t_24219 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam16, 1, 1, (V[]){v_env_240}); V a_2 = v_args_24215; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24215); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24216, v_t_24219));
  }
  case TAG_EField: {
    V v_e_24220 = heff_field(v_e0_241, 0);
    V v_f_24221 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24222 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24220}));
    V v_t_24223 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_f_24221));
    return (g_std_2edoc_2e_3c_3e(v_t_24222, v_t_24223));
  }
  case TAG_ENeg: {
    V v_m_24224 = heff_field(v_e0_241, 0);
    V v_e_24225 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24226 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_m_24224));
    V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24225}));
    return (g_std_2edoc_2e_3c_3e(v_t_24226, v_t_24227));
  }
  case TAG_App: {
    V v_h_24228 = heff_field(v_e0_241, 0);
    V v_args_24229 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 6));
    heff_room[0] = v_env_240;
    heff_room[1] = v_h_24228;
    heff_room[2] = v_args_24229;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_Op: {
    V v_a_24230 = heff_field(v_e0_241, 0);
    V v_op_24231 = heff_field(v_e0_241, 1);
    V v_b_24232 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24Op = heff_take_reuse_n(v_e0_241, 7ULL, 3);
    HeffT2 v_t_24233 = (g_heff_2esyntax_2efmt_2elayout_2echain_24cpr(heff_tag_at_n(v_ru_24e0_241_24Op, TAG_Op, 3, (V[]){v_a_24230, v_op_24231, v_b_24232})));
    {
      V v_field_24234 = v_t_24233.f[0];
      V v_field_24235 = v_t_24233.f[1];
      V v_first_24236 = v_field_24234;
      V v_rest_24237 = v_field_24235;
      V v_t_24238 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){heff_dup(v_env_240), heff_dup(v_rest_24237), v_first_24236}));
      V v_t_24243 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam17, 1, 2, (V[]){v_env_240, heff_dup(v_rest_24237)}); V a_2 = v_rest_24237; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_24237); r_; });
      V v_t_24244 = (g_std_2edoc_2e_3c_3e(v_t_24238, v_t_24243));
      return (g_std_2edoc_2egroup(v_t_24244));
    }
  }
  case TAG_Ops: {
    V v_a_24245 = heff_field(v_e0_241, 0);
    V v_rest_24246 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    heff_room[0] = v_env_240;
    heff_room[1] = v_a_24245;
    heff_room[2] = v_rest_24246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  case TAG_OpRhs: {
    V v_op_24247 = heff_field(v_e0_241, 0);
    V v_e_24248 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_a_24249 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_op_24247));
    V v_b_24250 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_e_24248}));
    V v_t_24251 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str22)}), v_b_24250));
    return (g_std_2edoc_2e_3c_3e(v_a_24249, v_t_24251));
  }
  case TAG_Ann: {
    V v_e_24252 = heff_field(v_e0_241, 0);
    V v_cc_24253 = heff_field(v_e0_241, 1);
    V v_ty_24254 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24255 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_e_24252}));
    V v_b_24256 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24253));
    V v_t_24257 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str23)}), v_b_24256));
    V v_t_24258 = (g_std_2edoc_2e_3c_3e(v_a_24255, v_t_24257));
    V v_t_24259 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_ty_24254}));
    V v_d_24260 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24259));
    V v_t_24261 = (g_std_2edoc_2e_3c_3e(v_t_24258, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24260})));
    return (g_std_2edoc_2egroup(v_t_24261));
  }
  case TAG_BVar: {
    V v_t_24262 = heff_field(v_e0_241, 0);
    heff_take_n(v_e0_241, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_t_24262));
  }
  case TAG_BImp: {
    V v_o_24263 = heff_field(v_e0_241, 0);
    V v_x_24264 = heff_field(v_e0_241, 1);
    V v_c_24265 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_t_24266 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24263));
    V v_t_24267 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24264));
    V v_t_24268 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24265));
    V v_t_24269 = (g_std_2edoc_2e_3c_3e(v_t_24267, v_t_24268));
    return (g_std_2edoc_2e_3c_3e(v_t_24266, v_t_24269));
  }
  case TAG_BAnn: {
    V v_o_24270 = heff_field(v_e0_241, 0);
    V v_x_24271 = heff_field(v_e0_241, 1);
    V v_cc_24272 = heff_field(v_e0_241, 2);
    V v_ty_24273 = heff_field(v_e0_241, 3);
    V v_c_24274 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 31ULL, 5);
    V v_t_24275 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_o_24270));
    V v_a_24276 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24271));
    V v_a_24277 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_cc_24272));
    V v_b_24278 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_ty_24273}));
    V v_t_24279 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str24)}), v_b_24278));
    V v_t_24280 = (g_std_2edoc_2e_3c_3e(v_a_24277, v_t_24279));
    V v_t_24281 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str25)}), v_t_24280));
    V v_t_24282 = (g_std_2edoc_2e_3c_3e(v_a_24276, v_t_24281));
    V v_t_24283 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_240, v_c_24274));
    V v_t_24284 = (g_std_2edoc_2e_3c_3e(v_t_24282, v_t_24283));
    return (g_std_2edoc_2e_3c_3e(v_t_24275, v_t_24284));
  }
  case TAG_Lam: {
    V v_bs_24285 = heff_field(v_e0_241, 0);
    V v_binders_24286 = heff_field(v_e0_241, 1);
    V v_arrow_24287 = heff_field(v_e0_241, 2);
    V v_body_24288 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_t_24289 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bs_24285));
    V v_t_24290 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 8)), 1, (V[]){heff_dup(v_env_240)}));
    V v_t_24291 = (g_list_2emap(v_t_24290, v_binders_24286));
    V v_a_24292 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str26); V a_1 = v_t_24291; V r_ = (g_std_2edoc_2econcatWith_24s593061764x1986092725(a_0, a_1)); heff_drop(v_t_24291); r_; });
    V v_b_24293 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24287));
    V v_t_24294 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str27)}), v_b_24293));
    V v_t_24295 = (g_std_2edoc_2e_3c_3e(v_a_24292, v_t_24294));
    V v_t_24296 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_body_24288));
    V v_t_24300;
    if ((heff_dup(v_t_24296) == NTAG(TAG_True))) {
      heff_drop(v_t_24296);
      V v_t_24297 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24288}));
      v_t_24300 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str28)}), v_t_24297));
    } else {
      heff_drop(v_t_24296);
      V v_t_24298 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_body_24288}));
      V v_d_24299 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24298));
      v_t_24300 = (g_std_2edoc_2egroup(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24299})));
    }
    V v_t_24301 = (g_std_2edoc_2e_3c_3e(v_t_24295, v_t_24300));
    return (g_std_2edoc_2e_3c_3e(v_t_24289, v_t_24301));
  }
  case TAG_Case: {
    V v_kw_24302 = heff_field(v_e0_241, 0);
    V v_scrut_24303 = heff_field(v_e0_241, 1);
    V v_of2_24304 = heff_field(v_e0_241, 2);
    V v_alts_24305 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 15ULL, 4);
    V v_a_24306 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24302));
    V v_a_24307 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_scrut_24303}));
    V v_b_24308 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_of2_24304));
    V v_t_24309 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str29)}), v_b_24308));
    V v_t_24310 = (g_std_2edoc_2e_3c_3e(v_a_24307, v_t_24309));
    V v_t_24311 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str30)}), v_t_24310));
    V v_t_24312 = (g_std_2edoc_2e_3c_3e(v_a_24306, v_t_24311));
    V v_t_24313 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_alts_24305; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1785097368x381247746(a_0, a_1, a_2)); heff_drop(v_alts_24305); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24312, v_t_24313));
  }
  case TAG_EAlt: {
    V v_p_24314 = heff_field(v_e0_241, 0);
    V v_arrow_24315 = heff_field(v_e0_241, 1);
    V v_body_24316 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24317 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_p_24314; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24314); r_; });
    V v_b_24318 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24315));
    V v_t_24319 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str31)}), v_b_24318));
    V v_t_24320 = (g_std_2edoc_2e_3c_3e(v_a_24317, v_t_24319));
    V v_t_24321 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_body_24316}));
    return (g_std_2edoc_2e_3c_3e(v_t_24320, v_t_24321));
  }
  case TAG_If: {
    V v_kw_24322 = heff_field(v_e0_241, 0);
    V v_c_24323 = heff_field(v_e0_241, 1);
    V v_th_24324 = heff_field(v_e0_241, 2);
    V v_a_24325 = heff_field(v_e0_241, 3);
    V v_el_24326 = heff_field(v_e0_241, 4);
    V v_b_24327 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    V v_t_24328 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_240), v_kw_24322, v_c_24323, v_th_24324, v_a_24325}));
    V v_t_24329 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_240, v_el_24326, v_b_24327}));
    V v_t_24330 = (g_std_2edoc_2e_3c_3e(v_t_24328, v_t_24329));
    return (g_std_2edoc_2egroup(v_t_24330));
  }
  case TAG_Do: {
    V v_kw_24331 = heff_field(v_e0_241, 0);
    V v_stmts_24332 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24333 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_kw_24331));
    V v_t_24334 = ({ V a_0 = v_env_240; V a_1 = MK_INT(0LL); V a_2 = v_stmts_24332; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1630127108x1269591338(a_0, a_1, a_2)); heff_drop(v_stmts_24332); r_; });
    return (g_std_2edoc_2e_3c_3e(v_t_24333, v_t_24334));
  }
  case TAG_ESBind: {
    V v_x_24335 = heff_field(v_e0_241, 0);
    V v_arrow_24336 = heff_field(v_e0_241, 1);
    V v_e_24337 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    V v_a_24338 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_x_24335));
    V v_b_24339 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_arrow_24336));
    V v_t_24340 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str32)}), v_b_24339));
    V v_t_24341 = (g_std_2edoc_2e_3c_3e(v_a_24338, v_t_24340));
    V v_t_24342 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_240, v_e_24337}));
    return (g_std_2edoc_2e_3c_3e(v_t_24341, v_t_24342));
  }
  case TAG_ELet: {
    V v_kw_24343 = heff_field(v_e0_241, 0);
    V v_p_24344 = heff_field(v_e0_241, 1);
    V v_ann_24345 = heff_field(v_e0_241, 2);
    V v_eq_24346 = heff_field(v_e0_241, 3);
    V v_e_24347 = heff_field(v_e0_241, 4);
    V v_body_24348 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 63ULL, 6);
    switch (heff_tag_of(v_body_24348)) {
    case TAG_Nothing: {
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){v_env_240, v_kw_24343, v_p_24344, v_ann_24345, v_eq_24346, v_e_24347});
    }
    case TAG_Just: {
      V v_it1_24349 = heff_field(v_body_24348, 0);
      V v_ru_24body_24348_24Just = heff_take_reuse_n(v_body_24348, 1ULL, 1);
      switch (heff_tag_of(v_it1_24349)) {
      case TAG_MkPair: {
        V v_i_24350 = heff_field(v_it1_24349, 0);
        V v_b_24351 = heff_field(v_it1_24349, 1);
        heff_take_n(v_it1_24349, 3ULL, 2);
        V v_t_24352 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_240, v_kw_24343, v_p_24344, v_ann_24345, v_eq_24346, v_e_24347, v_i_24350, v_b_24351}));
        V v_d_24353 = (g_std_2edoc_2egroup(v_t_24352));
        return heff_tag_at_n(v_ru_24body_24348_24Just, TAG_Column, 1, (V[]){heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam18, 1, 1, (V[]){v_d_24353})});
      }
      default: return heff_nomatch(v_it1_24349);
      }
    }
    default: return heff_nomatch(v_body_24348);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam20(V self, V *args) {
  V v_env_24358 = args[0];
  V v_e_24359 = args[1];
  V v_t_24360 = (g_heff_2esyntax_2efmt_2elayout_2eopensBlock(v_e_24359));
  if ((heff_dup(v_t_24360) == NTAG(TAG_True))) {
    heff_drop(v_t_24360);
    V v_t_24361 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24358, v_e_24359}));
    return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str33)}), v_t_24361));
  } else {
    heff_drop(v_t_24360);
    V v_t_24362 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24358, v_e_24359}));
    V v_t_24363 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2eline_get()), v_t_24362));
    return (g_std_2edoc_2egroup(v_t_24363));
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam21(V self, V *args) {
  V v_env_24364 = args[0];
  V v_kw_24365 = args[1];
  V v_p_24366 = args[2];
  V v_ann_24367 = args[3];
  V v_eq_24368 = args[4];
  V v_e_24369 = args[5];
  V v_a_24370 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24364), v_kw_24365));
  V v_b_24371 = ({ V a_0 = heff_dup(v_env_24364); V a_1 = v_p_24366; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_24366); r_; });
  V v_t_24372 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str34)}), v_b_24371));
  V v_t_24373 = (g_std_2edoc_2e_3c_3e(v_a_24370, v_t_24372));
  V v_a_24381;
  switch (heff_tag_of(v_ann_24367)) {
  case TAG_Nothing: {
    v_a_24381 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    break;
  }
  case TAG_Just: {
    V v_it1_24374 = heff_field(v_ann_24367, 0);
    V v_ru_24ann_24367_24Just = heff_take_reuse_n(v_ann_24367, 1ULL, 1);
    switch (heff_tag_of(v_it1_24374)) {
    case TAG_MkPair: {
      V v_cc_24375 = heff_field(v_it1_24374, 0);
      V v_ty_24376 = heff_field(v_it1_24374, 1);
      heff_take_n(v_it1_24374, 3ULL, 2);
      V v_a_24377 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24364), v_cc_24375));
      V v_b_24378 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24364), v_ty_24376}));
      V v_t_24379 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24ann_24367_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str35)}), v_b_24378));
      V v_t_24380 = (g_std_2edoc_2e_3c_3e(v_a_24377, v_t_24379));
      v_a_24381 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str36)}), v_t_24380));
      break;
    }
    default: heff_nomatch(v_it1_24374);
    }
    break;
  }
  default: heff_nomatch(v_ann_24367);
  }
  V v_b_24382 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24364), v_eq_24368));
  V v_t_24383 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str37)}), v_b_24382));
  V v_t_24384 = (g_std_2edoc_2e_3c_3e(v_a_24381, v_t_24383));
  V v_t_24385 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_24364, v_e_24369}));
  V v_t_24386 = (g_std_2edoc_2e_3c_3e(v_t_24384, v_t_24385));
  return (g_std_2edoc_2e_3c_3e(v_t_24373, v_t_24386));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam22(V self, V *args) {
  V v_env_24387 = args[0];
  V v_kw_24388 = args[1];
  V v_p_24389 = args[2];
  V v_ann_24390 = args[3];
  V v_eq_24391 = args[4];
  V v_e_24392 = args[5];
  V v_i_24393 = args[6];
  V v_b_24394 = args[7];
  V v_d_24395 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 2)), 6, (V[]){heff_dup(v_env_24387), v_kw_24388, v_p_24389, v_ann_24390, v_eq_24391, v_e_24392}));
  V v_t_24396 = heff_dup(heff_rfield(v_i_24393, 6));
  V v_x1_24398;
  if ((heff_dup(v_t_24396) == NTAG(TAG_True))) {
    heff_drop(v_t_24396);
    v_x1_24398 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_24396);
    V v_t_24397 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24394));
    v_x1_24398 = heff_get_n(v_t_24397, 6, 9);
  }
  V v_t_24399;
  if ((heff_dup(v_x1_24398) == NTAG(TAG_True))) {
    heff_drop(v_x1_24398);
    v_t_24399 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24398);
    v_t_24399 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24400 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24387), v_i_24393));
  V v_b_24504;
  switch (heff_tag_of(v_b_24394)) {
  case TAG_Atom: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_EParen: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Named: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Tup: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Seg: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Braces: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Update: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_EUSet: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_InstB: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_EFSet: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_EFDefault: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Sum: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_ECon: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_EField: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_ENeg: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_App: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Op: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Ops: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_OpRhs: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Ann: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_BVar: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_BImp: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_BAnn: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Lam: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Case: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_EAlt: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_If: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_Do: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_ESBind: {
    v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
    break;
  }
  case TAG_ELet: {
    V v_kw2_24495 = heff_dup(heff_field(v_b_24394, 0));
    V v_p2_24496 = heff_dup(heff_field(v_b_24394, 1));
    V v_ann2_24497 = heff_dup(heff_field(v_b_24394, 2));
    V v_eq2_24498 = heff_dup(heff_field(v_b_24394, 3));
    V v_e2_24499 = heff_dup(heff_field(v_b_24394, 4));
    V v_it6_24500 = heff_dup(heff_field(v_b_24394, 5));
    switch (heff_tag_of(v_it6_24500)) {
    case TAG_Nothing: {
      heff_drop(v_kw2_24495);
      heff_drop(v_p2_24496);
      heff_drop(v_ann2_24497);
      heff_drop(v_eq2_24498);
      heff_drop(v_e2_24499);
      v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24387, v_b_24394}));
      break;
    }
    case TAG_Just: {
      V v_it61_24501 = heff_field(v_it6_24500, 0);
      heff_take_n(v_it6_24500, 1ULL, 1);
      heff_drop_tag(v_b_24394, 6);
      switch (heff_tag_of(v_it61_24501)) {
      case TAG_MkPair: {
        V v_i2_24502 = heff_field(v_it61_24501, 0);
        V v_b2_24503 = heff_field(v_it61_24501, 1);
        heff_take_n(v_it61_24501, 3ULL, 2);
        v_b_24504 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 3)), 8, (V[]){v_env_24387, v_kw2_24495, v_p2_24496, v_ann2_24497, v_eq2_24498, v_e2_24499, v_i2_24502, v_b2_24503}));
        break;
      }
      default: heff_nomatch(v_it61_24501);
      }
      break;
    }
    default: heff_nomatch(v_it6_24500);
    }
    break;
  }
  default: heff_nomatch(v_b_24394);
  }
  V v_t_24505 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str38)}), v_b_24504));
  V v_t_24506 = (g_std_2edoc_2e_3c_3e(v_a_24400, v_t_24505));
  V v_t_24507 = (g_std_2edoc_2e_3c_3e(v_t_24399, v_t_24506));
  return (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24395}), v_t_24507));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam23(V self, V *args) {
  V v_env_24508 = args[0];
  V v_kw_24509 = args[1];
  V v_c_24510 = args[2];
  V v_th_24511 = args[3];
  V v_a_24512 = args[4];
  V v_a_24513 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24508), v_kw_24509));
  V v_b_24514 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24508), v_c_24510}));
  V v_t_24515 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str39)}), v_b_24514));
  V v_t_24516 = (g_std_2edoc_2e_3c_3e(v_a_24513, v_t_24515));
  V v_t_24517 = heff_dup(heff_rfield(v_th_24511, 6));
  V v_x1_24519;
  if ((heff_dup(v_t_24517) == NTAG(TAG_True))) {
    heff_drop(v_t_24517);
    v_x1_24519 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_24517);
    V v_t_24518 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24512));
    v_x1_24519 = heff_get_n(v_t_24518, 6, 9);
  }
  V v_t_24520;
  if ((heff_dup(v_x1_24519) == NTAG(TAG_True))) {
    heff_drop(v_x1_24519);
    v_t_24520 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24519);
    v_t_24520 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_a_24521 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24508), v_th_24511));
  V v_d_24522 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24508, v_a_24512}));
  V v_t_24523 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str40)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24522})));
  V v_t_24524 = (g_std_2edoc_2e_3c_3e(v_a_24521, v_t_24523));
  V v_d_24525 = (g_std_2edoc_2e_3c_3e(v_t_24520, v_t_24524));
  V v_t_24526 = (g_std_2edoc_2e_3c_3e(v_t_24516, heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24525})));
  return (g_std_2edoc_2egroup(v_t_24526));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam24(V self, V *args) {
  V v_env_24527 = args[0];
  V v_el_24528 = args[1];
  V v_b_24529 = args[2];
  switch (heff_tag_of(v_b_24529)) {
  case TAG_Atom: {
    V v_t_24531 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24533;
    if ((heff_dup(v_t_24531) == NTAG(TAG_True))) {
      heff_drop(v_t_24531);
      v_x1_24533 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24531);
      V v_t_24532 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24533 = heff_get_n(v_t_24532, 6, 9);
    }
    V v_t_24534;
    if ((heff_dup(v_x1_24533) == NTAG(TAG_True))) {
      heff_drop(v_x1_24533);
      v_t_24534 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24533);
      v_t_24534 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24535 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24536 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24537 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str41)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24536})));
    V v_t_24538 = (g_std_2edoc_2e_3c_3e(v_a_24535, v_t_24537));
    return (g_std_2edoc_2e_3c_3e(v_t_24534, v_t_24538));
  }
  case TAG_EParen: {
    V v_t_24542 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24544;
    if ((heff_dup(v_t_24542) == NTAG(TAG_True))) {
      heff_drop(v_t_24542);
      v_x1_24544 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24542);
      V v_t_24543 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24544 = heff_get_n(v_t_24543, 6, 9);
    }
    V v_t_24545;
    if ((heff_dup(v_x1_24544) == NTAG(TAG_True))) {
      heff_drop(v_x1_24544);
      v_t_24545 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24544);
      v_t_24545 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24546 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24547 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24548 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str42)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24547})));
    V v_t_24549 = (g_std_2edoc_2e_3c_3e(v_a_24546, v_t_24548));
    return (g_std_2edoc_2e_3c_3e(v_t_24545, v_t_24549));
  }
  case TAG_Named: {
    V v_t_24555 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24557;
    if ((heff_dup(v_t_24555) == NTAG(TAG_True))) {
      heff_drop(v_t_24555);
      v_x1_24557 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24555);
      V v_t_24556 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24557 = heff_get_n(v_t_24556, 6, 9);
    }
    V v_t_24558;
    if ((heff_dup(v_x1_24557) == NTAG(TAG_True))) {
      heff_drop(v_x1_24557);
      v_t_24558 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24557);
      v_t_24558 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24559 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24560 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24561 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str43)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24560})));
    V v_t_24562 = (g_std_2edoc_2e_3c_3e(v_a_24559, v_t_24561));
    return (g_std_2edoc_2e_3c_3e(v_t_24558, v_t_24562));
  }
  case TAG_Tup: {
    V v_t_24567 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24569;
    if ((heff_dup(v_t_24567) == NTAG(TAG_True))) {
      heff_drop(v_t_24567);
      v_x1_24569 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24567);
      V v_t_24568 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24569 = heff_get_n(v_t_24568, 6, 9);
    }
    V v_t_24570;
    if ((heff_dup(v_x1_24569) == NTAG(TAG_True))) {
      heff_drop(v_x1_24569);
      v_t_24570 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24569);
      v_t_24570 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24571 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24572 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24573 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str44)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24572})));
    V v_t_24574 = (g_std_2edoc_2e_3c_3e(v_a_24571, v_t_24573));
    return (g_std_2edoc_2e_3c_3e(v_t_24570, v_t_24574));
  }
  case TAG_Seg: {
    V v_t_24578 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24580;
    if ((heff_dup(v_t_24578) == NTAG(TAG_True))) {
      heff_drop(v_t_24578);
      v_x1_24580 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24578);
      V v_t_24579 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24580 = heff_get_n(v_t_24579, 6, 9);
    }
    V v_t_24581;
    if ((heff_dup(v_x1_24580) == NTAG(TAG_True))) {
      heff_drop(v_x1_24580);
      v_t_24581 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24580);
      v_t_24581 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24582 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24583 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24584 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str45)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24583})));
    V v_t_24585 = (g_std_2edoc_2e_3c_3e(v_a_24582, v_t_24584));
    return (g_std_2edoc_2e_3c_3e(v_t_24581, v_t_24585));
  }
  case TAG_Braces: {
    V v_t_24590 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24592;
    if ((heff_dup(v_t_24590) == NTAG(TAG_True))) {
      heff_drop(v_t_24590);
      v_x1_24592 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24590);
      V v_t_24591 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24592 = heff_get_n(v_t_24591, 6, 9);
    }
    V v_t_24593;
    if ((heff_dup(v_x1_24592) == NTAG(TAG_True))) {
      heff_drop(v_x1_24592);
      v_t_24593 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24592);
      v_t_24593 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24594 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24595 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24596 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str46)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24595})));
    V v_t_24597 = (g_std_2edoc_2e_3c_3e(v_a_24594, v_t_24596));
    return (g_std_2edoc_2e_3c_3e(v_t_24593, v_t_24597));
  }
  case TAG_Update: {
    V v_t_24604 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24606;
    if ((heff_dup(v_t_24604) == NTAG(TAG_True))) {
      heff_drop(v_t_24604);
      v_x1_24606 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24604);
      V v_t_24605 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24606 = heff_get_n(v_t_24605, 6, 9);
    }
    V v_t_24607;
    if ((heff_dup(v_x1_24606) == NTAG(TAG_True))) {
      heff_drop(v_x1_24606);
      v_t_24607 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24606);
      v_t_24607 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24608 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24609 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24610 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str47)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24609})));
    V v_t_24611 = (g_std_2edoc_2e_3c_3e(v_a_24608, v_t_24610));
    return (g_std_2edoc_2e_3c_3e(v_t_24607, v_t_24611));
  }
  case TAG_EUSet: {
    V v_t_24615 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24617;
    if ((heff_dup(v_t_24615) == NTAG(TAG_True))) {
      heff_drop(v_t_24615);
      v_x1_24617 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24615);
      V v_t_24616 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24617 = heff_get_n(v_t_24616, 6, 9);
    }
    V v_t_24618;
    if ((heff_dup(v_x1_24617) == NTAG(TAG_True))) {
      heff_drop(v_x1_24617);
      v_t_24618 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24617);
      v_t_24618 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24619 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24620 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24621 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str48)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24620})));
    V v_t_24622 = (g_std_2edoc_2e_3c_3e(v_a_24619, v_t_24621));
    return (g_std_2edoc_2e_3c_3e(v_t_24618, v_t_24622));
  }
  case TAG_InstB: {
    V v_t_24628 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24630;
    if ((heff_dup(v_t_24628) == NTAG(TAG_True))) {
      heff_drop(v_t_24628);
      v_x1_24630 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24628);
      V v_t_24629 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24630 = heff_get_n(v_t_24629, 6, 9);
    }
    V v_t_24631;
    if ((heff_dup(v_x1_24630) == NTAG(TAG_True))) {
      heff_drop(v_x1_24630);
      v_t_24631 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24630);
      v_t_24631 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24632 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24633 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24634 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str49)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24633})));
    V v_t_24635 = (g_std_2edoc_2e_3c_3e(v_a_24632, v_t_24634));
    return (g_std_2edoc_2e_3c_3e(v_t_24631, v_t_24635));
  }
  case TAG_EFSet: {
    V v_t_24639 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24641;
    if ((heff_dup(v_t_24639) == NTAG(TAG_True))) {
      heff_drop(v_t_24639);
      v_x1_24641 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24639);
      V v_t_24640 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24641 = heff_get_n(v_t_24640, 6, 9);
    }
    V v_t_24642;
    if ((heff_dup(v_x1_24641) == NTAG(TAG_True))) {
      heff_drop(v_x1_24641);
      v_t_24642 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24641);
      v_t_24642 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24643 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24644 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24645 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str50)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24644})));
    V v_t_24646 = (g_std_2edoc_2e_3c_3e(v_a_24643, v_t_24645));
    return (g_std_2edoc_2e_3c_3e(v_t_24642, v_t_24646));
  }
  case TAG_EFDefault: {
    V v_t_24650 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24652;
    if ((heff_dup(v_t_24650) == NTAG(TAG_True))) {
      heff_drop(v_t_24650);
      v_x1_24652 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24650);
      V v_t_24651 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24652 = heff_get_n(v_t_24651, 6, 9);
    }
    V v_t_24653;
    if ((heff_dup(v_x1_24652) == NTAG(TAG_True))) {
      heff_drop(v_x1_24652);
      v_t_24653 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24652);
      v_t_24653 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24654 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24655 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24656 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str51)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24655})));
    V v_t_24657 = (g_std_2edoc_2e_3c_3e(v_a_24654, v_t_24656));
    return (g_std_2edoc_2e_3c_3e(v_t_24653, v_t_24657));
  }
  case TAG_Sum: {
    V v_t_24663 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24665;
    if ((heff_dup(v_t_24663) == NTAG(TAG_True))) {
      heff_drop(v_t_24663);
      v_x1_24665 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24663);
      V v_t_24664 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24665 = heff_get_n(v_t_24664, 6, 9);
    }
    V v_t_24666;
    if ((heff_dup(v_x1_24665) == NTAG(TAG_True))) {
      heff_drop(v_x1_24665);
      v_t_24666 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24665);
      v_t_24666 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24667 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24668 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24669 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str52)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24668})));
    V v_t_24670 = (g_std_2edoc_2e_3c_3e(v_a_24667, v_t_24669));
    return (g_std_2edoc_2e_3c_3e(v_t_24666, v_t_24670));
  }
  case TAG_ECon: {
    V v_t_24673 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24675;
    if ((heff_dup(v_t_24673) == NTAG(TAG_True))) {
      heff_drop(v_t_24673);
      v_x1_24675 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24673);
      V v_t_24674 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24675 = heff_get_n(v_t_24674, 6, 9);
    }
    V v_t_24676;
    if ((heff_dup(v_x1_24675) == NTAG(TAG_True))) {
      heff_drop(v_x1_24675);
      v_t_24676 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24675);
      v_t_24676 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24677 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24678 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24679 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str53)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24678})));
    V v_t_24680 = (g_std_2edoc_2e_3c_3e(v_a_24677, v_t_24679));
    return (g_std_2edoc_2e_3c_3e(v_t_24676, v_t_24680));
  }
  case TAG_EField: {
    V v_t_24683 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24685;
    if ((heff_dup(v_t_24683) == NTAG(TAG_True))) {
      heff_drop(v_t_24683);
      v_x1_24685 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24683);
      V v_t_24684 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24685 = heff_get_n(v_t_24684, 6, 9);
    }
    V v_t_24686;
    if ((heff_dup(v_x1_24685) == NTAG(TAG_True))) {
      heff_drop(v_x1_24685);
      v_t_24686 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24685);
      v_t_24686 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24687 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24688 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24689 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str54)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24688})));
    V v_t_24690 = (g_std_2edoc_2e_3c_3e(v_a_24687, v_t_24689));
    return (g_std_2edoc_2e_3c_3e(v_t_24686, v_t_24690));
  }
  case TAG_ENeg: {
    V v_t_24693 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24695;
    if ((heff_dup(v_t_24693) == NTAG(TAG_True))) {
      heff_drop(v_t_24693);
      v_x1_24695 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24693);
      V v_t_24694 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24695 = heff_get_n(v_t_24694, 6, 9);
    }
    V v_t_24696;
    if ((heff_dup(v_x1_24695) == NTAG(TAG_True))) {
      heff_drop(v_x1_24695);
      v_t_24696 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24695);
      v_t_24696 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24697 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24698 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24699 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str55)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24698})));
    V v_t_24700 = (g_std_2edoc_2e_3c_3e(v_a_24697, v_t_24699));
    return (g_std_2edoc_2e_3c_3e(v_t_24696, v_t_24700));
  }
  case TAG_App: {
    V v_t_24703 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24705;
    if ((heff_dup(v_t_24703) == NTAG(TAG_True))) {
      heff_drop(v_t_24703);
      v_x1_24705 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24703);
      V v_t_24704 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24705 = heff_get_n(v_t_24704, 6, 9);
    }
    V v_t_24706;
    if ((heff_dup(v_x1_24705) == NTAG(TAG_True))) {
      heff_drop(v_x1_24705);
      v_t_24706 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24705);
      v_t_24706 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24707 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24708 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24709 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str56)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24708})));
    V v_t_24710 = (g_std_2edoc_2e_3c_3e(v_a_24707, v_t_24709));
    return (g_std_2edoc_2e_3c_3e(v_t_24706, v_t_24710));
  }
  case TAG_Op: {
    V v_t_24714 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24716;
    if ((heff_dup(v_t_24714) == NTAG(TAG_True))) {
      heff_drop(v_t_24714);
      v_x1_24716 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24714);
      V v_t_24715 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24716 = heff_get_n(v_t_24715, 6, 9);
    }
    V v_t_24717;
    if ((heff_dup(v_x1_24716) == NTAG(TAG_True))) {
      heff_drop(v_x1_24716);
      v_t_24717 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24716);
      v_t_24717 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24718 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24719 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24720 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str57)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24719})));
    V v_t_24721 = (g_std_2edoc_2e_3c_3e(v_a_24718, v_t_24720));
    return (g_std_2edoc_2e_3c_3e(v_t_24717, v_t_24721));
  }
  case TAG_Ops: {
    V v_t_24724 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24726;
    if ((heff_dup(v_t_24724) == NTAG(TAG_True))) {
      heff_drop(v_t_24724);
      v_x1_24726 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24724);
      V v_t_24725 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24726 = heff_get_n(v_t_24725, 6, 9);
    }
    V v_t_24727;
    if ((heff_dup(v_x1_24726) == NTAG(TAG_True))) {
      heff_drop(v_x1_24726);
      v_t_24727 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24726);
      v_t_24727 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24728 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24729 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24730 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str58)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24729})));
    V v_t_24731 = (g_std_2edoc_2e_3c_3e(v_a_24728, v_t_24730));
    return (g_std_2edoc_2e_3c_3e(v_t_24727, v_t_24731));
  }
  case TAG_OpRhs: {
    V v_t_24734 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24736;
    if ((heff_dup(v_t_24734) == NTAG(TAG_True))) {
      heff_drop(v_t_24734);
      v_x1_24736 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24734);
      V v_t_24735 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24736 = heff_get_n(v_t_24735, 6, 9);
    }
    V v_t_24737;
    if ((heff_dup(v_x1_24736) == NTAG(TAG_True))) {
      heff_drop(v_x1_24736);
      v_t_24737 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24736);
      v_t_24737 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24738 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24739 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24740 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str59)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24739})));
    V v_t_24741 = (g_std_2edoc_2e_3c_3e(v_a_24738, v_t_24740));
    return (g_std_2edoc_2e_3c_3e(v_t_24737, v_t_24741));
  }
  case TAG_Ann: {
    V v_t_24745 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24747;
    if ((heff_dup(v_t_24745) == NTAG(TAG_True))) {
      heff_drop(v_t_24745);
      v_x1_24747 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24745);
      V v_t_24746 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24747 = heff_get_n(v_t_24746, 6, 9);
    }
    V v_t_24748;
    if ((heff_dup(v_x1_24747) == NTAG(TAG_True))) {
      heff_drop(v_x1_24747);
      v_t_24748 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24747);
      v_t_24748 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24749 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24750 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24751 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str60)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24750})));
    V v_t_24752 = (g_std_2edoc_2e_3c_3e(v_a_24749, v_t_24751));
    return (g_std_2edoc_2e_3c_3e(v_t_24748, v_t_24752));
  }
  case TAG_BVar: {
    V v_t_24754 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24756;
    if ((heff_dup(v_t_24754) == NTAG(TAG_True))) {
      heff_drop(v_t_24754);
      v_x1_24756 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24754);
      V v_t_24755 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24756 = heff_get_n(v_t_24755, 6, 9);
    }
    V v_t_24757;
    if ((heff_dup(v_x1_24756) == NTAG(TAG_True))) {
      heff_drop(v_x1_24756);
      v_t_24757 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24756);
      v_t_24757 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24758 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24759 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24760 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str61)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24759})));
    V v_t_24761 = (g_std_2edoc_2e_3c_3e(v_a_24758, v_t_24760));
    return (g_std_2edoc_2e_3c_3e(v_t_24757, v_t_24761));
  }
  case TAG_BImp: {
    V v_t_24765 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24767;
    if ((heff_dup(v_t_24765) == NTAG(TAG_True))) {
      heff_drop(v_t_24765);
      v_x1_24767 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24765);
      V v_t_24766 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24767 = heff_get_n(v_t_24766, 6, 9);
    }
    V v_t_24768;
    if ((heff_dup(v_x1_24767) == NTAG(TAG_True))) {
      heff_drop(v_x1_24767);
      v_t_24768 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24767);
      v_t_24768 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24769 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24770 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24771 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str62)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24770})));
    V v_t_24772 = (g_std_2edoc_2e_3c_3e(v_a_24769, v_t_24771));
    return (g_std_2edoc_2e_3c_3e(v_t_24768, v_t_24772));
  }
  case TAG_BAnn: {
    V v_t_24778 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24780;
    if ((heff_dup(v_t_24778) == NTAG(TAG_True))) {
      heff_drop(v_t_24778);
      v_x1_24780 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24778);
      V v_t_24779 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24780 = heff_get_n(v_t_24779, 6, 9);
    }
    V v_t_24781;
    if ((heff_dup(v_x1_24780) == NTAG(TAG_True))) {
      heff_drop(v_x1_24780);
      v_t_24781 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24780);
      v_t_24781 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24782 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24783 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24784 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str63)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24783})));
    V v_t_24785 = (g_std_2edoc_2e_3c_3e(v_a_24782, v_t_24784));
    return (g_std_2edoc_2e_3c_3e(v_t_24781, v_t_24785));
  }
  case TAG_Lam: {
    V v_t_24790 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24792;
    if ((heff_dup(v_t_24790) == NTAG(TAG_True))) {
      heff_drop(v_t_24790);
      v_x1_24792 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24790);
      V v_t_24791 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24792 = heff_get_n(v_t_24791, 6, 9);
    }
    V v_t_24793;
    if ((heff_dup(v_x1_24792) == NTAG(TAG_True))) {
      heff_drop(v_x1_24792);
      v_t_24793 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24792);
      v_t_24793 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24794 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24795 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24796 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str64)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24795})));
    V v_t_24797 = (g_std_2edoc_2e_3c_3e(v_a_24794, v_t_24796));
    return (g_std_2edoc_2e_3c_3e(v_t_24793, v_t_24797));
  }
  case TAG_Case: {
    V v_t_24802 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24804;
    if ((heff_dup(v_t_24802) == NTAG(TAG_True))) {
      heff_drop(v_t_24802);
      v_x1_24804 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24802);
      V v_t_24803 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24804 = heff_get_n(v_t_24803, 6, 9);
    }
    V v_t_24805;
    if ((heff_dup(v_x1_24804) == NTAG(TAG_True))) {
      heff_drop(v_x1_24804);
      v_t_24805 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24804);
      v_t_24805 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24806 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24807 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24808 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str65)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24807})));
    V v_t_24809 = (g_std_2edoc_2e_3c_3e(v_a_24806, v_t_24808));
    return (g_std_2edoc_2e_3c_3e(v_t_24805, v_t_24809));
  }
  case TAG_EAlt: {
    V v_t_24813 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24815;
    if ((heff_dup(v_t_24813) == NTAG(TAG_True))) {
      heff_drop(v_t_24813);
      v_x1_24815 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24813);
      V v_t_24814 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24815 = heff_get_n(v_t_24814, 6, 9);
    }
    V v_t_24816;
    if ((heff_dup(v_x1_24815) == NTAG(TAG_True))) {
      heff_drop(v_x1_24815);
      v_t_24816 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24815);
      v_t_24816 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24817 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24818 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24819 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str66)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24818})));
    V v_t_24820 = (g_std_2edoc_2e_3c_3e(v_a_24817, v_t_24819));
    return (g_std_2edoc_2e_3c_3e(v_t_24816, v_t_24820));
  }
  case TAG_If: {
    V v_kw_24821 = heff_dup(heff_field(v_b_24529, 0));
    V v_c_24822 = heff_dup(heff_field(v_b_24529, 1));
    V v_th_24823 = heff_dup(heff_field(v_b_24529, 2));
    V v_a_24824 = heff_dup(heff_field(v_b_24529, 3));
    V v_el2_24825 = heff_dup(heff_field(v_b_24529, 4));
    V v_b2_24826 = heff_dup(heff_field(v_b_24529, 5));
    V v_t_24827 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24829;
    if ((heff_dup(v_t_24827) == NTAG(TAG_True))) {
      heff_drop_tag(v_b_24529, 6);
      heff_drop(v_t_24827);
      v_x1_24829 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24827);
      V v_t_24828 = ({ V a_0 = v_b_24529; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_b_24529, 6); r_; });
      v_x1_24829 = heff_get_n(v_t_24828, 6, 9);
    }
    V v_t_24830;
    if ((heff_dup(v_x1_24829) == NTAG(TAG_True))) {
      heff_drop(v_x1_24829);
      v_t_24830 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24829);
      v_t_24830 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24831 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_b_24832 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 4)), 5, (V[]){heff_dup(v_env_24527), v_kw_24821, v_c_24822, v_th_24823, v_a_24824}));
    V v_t_24833 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str67)}), v_b_24832));
    V v_t_24834 = (g_std_2edoc_2e_3c_3e(v_a_24831, v_t_24833));
    V v_t_24835 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 5)), 3, (V[]){v_env_24527, v_el2_24825, v_b2_24826}));
    V v_t_24836 = (g_std_2edoc_2e_3c_3e(v_t_24834, v_t_24835));
    return (g_std_2edoc_2e_3c_3e(v_t_24830, v_t_24836));
  }
  case TAG_Do: {
    V v_t_24839 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24841;
    if ((heff_dup(v_t_24839) == NTAG(TAG_True))) {
      heff_drop(v_t_24839);
      v_x1_24841 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24839);
      V v_t_24840 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24841 = heff_get_n(v_t_24840, 6, 9);
    }
    V v_t_24842;
    if ((heff_dup(v_x1_24841) == NTAG(TAG_True))) {
      heff_drop(v_x1_24841);
      v_t_24842 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24841);
      v_t_24842 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24843 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24844 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24845 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str68)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24844})));
    V v_t_24846 = (g_std_2edoc_2e_3c_3e(v_a_24843, v_t_24845));
    return (g_std_2edoc_2e_3c_3e(v_t_24842, v_t_24846));
  }
  case TAG_ESBind: {
    V v_t_24850 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24852;
    if ((heff_dup(v_t_24850) == NTAG(TAG_True))) {
      heff_drop(v_t_24850);
      v_x1_24852 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24850);
      V v_t_24851 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24852 = heff_get_n(v_t_24851, 6, 9);
    }
    V v_t_24853;
    if ((heff_dup(v_x1_24852) == NTAG(TAG_True))) {
      heff_drop(v_x1_24852);
      v_t_24853 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24852);
      v_t_24853 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24854 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24855 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24856 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str69)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24855})));
    V v_t_24857 = (g_std_2edoc_2e_3c_3e(v_a_24854, v_t_24856));
    return (g_std_2edoc_2e_3c_3e(v_t_24853, v_t_24857));
  }
  case TAG_ELet: {
    V v_t_24864 = heff_dup(heff_rfield(v_el_24528, 6));
    V v_x1_24866;
    if ((heff_dup(v_t_24864) == NTAG(TAG_True))) {
      heff_drop(v_t_24864);
      v_x1_24866 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_24864);
      V v_t_24865 = (g_heff_2esyntax_2ecst_2efirstE(v_b_24529));
      v_x1_24866 = heff_get_n(v_t_24865, 6, 9);
    }
    V v_t_24867;
    if ((heff_dup(v_x1_24866) == NTAG(TAG_True))) {
      heff_drop(v_x1_24866);
      v_t_24867 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_x1_24866);
      v_t_24867 = heff_dup(g_std_2edoc_2eline_get());
    }
    V v_a_24868 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24527), v_el_24528));
    V v_d_24869 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24527, v_b_24529}));
    V v_t_24870 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str70)}), heff_tag_n(TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24869})));
    V v_t_24871 = (g_std_2edoc_2e_3c_3e(v_a_24868, v_t_24870));
    return (g_std_2edoc_2e_3c_3e(v_t_24867, v_t_24871));
  }
  default: return heff_nomatch(v_b_24529);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam26(V self, V *args) {
  V v_a_24887 = args[0];
  V v_one_24886 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24888 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24887));
  V v_x1_24889 = heff_get_n(v_t_24888, 6, 9);
  V v_t_24890;
  if ((heff_dup(v_x1_24889) == NTAG(TAG_True))) {
    heff_drop(v_x1_24889);
    v_t_24890 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24889);
    v_t_24890 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24891 = heff_tr(heff_call(v_one_24886, 1, (V[]){v_a_24887}));
  return (g_std_2edoc_2e_3c_3e(v_t_24890, v_t_24891));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam27(V self, V *args) {
  V v_a_24899 = args[0];
  V v_one_24898 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24900 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24899));
  V v_x1_24901 = heff_get_n(v_t_24900, 6, 9);
  V v_t_24902;
  if ((heff_dup(v_x1_24901) == NTAG(TAG_True))) {
    heff_drop(v_x1_24901);
    v_t_24902 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24901);
    v_t_24902 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24903 = heff_tr(heff_call(v_one_24898, 1, (V[]){v_a_24899}));
  return (g_std_2edoc_2e_3c_3e(v_t_24902, v_t_24903));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam28(V self, V *args) {
  V v_a_24912 = args[0];
  V v_one_24911 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24913 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24912));
  V v_x1_24914 = heff_get_n(v_t_24913, 6, 9);
  V v_t_24915;
  if ((heff_dup(v_x1_24914) == NTAG(TAG_True))) {
    heff_drop(v_x1_24914);
    v_t_24915 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24914);
    v_t_24915 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24916 = heff_tr(heff_call(v_one_24911, 1, (V[]){v_a_24912}));
  return (g_std_2edoc_2e_3c_3e(v_t_24915, v_t_24916));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam29(V self, V *args) {
  V v_a_24928 = args[0];
  V v_one_24927 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24929 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24928));
  V v_x1_24930 = heff_get_n(v_t_24929, 6, 9);
  V v_t_24931;
  if ((heff_dup(v_x1_24930) == NTAG(TAG_True))) {
    heff_drop(v_x1_24930);
    v_t_24931 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24930);
    v_t_24931 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24932 = heff_tr(heff_call(v_one_24927, 1, (V[]){v_a_24928}));
  return (g_std_2edoc_2e_3c_3e(v_t_24931, v_t_24932));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam30(V self, V *args) {
  V v_a_24943 = args[0];
  V v_one_24942 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24944 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24943));
  V v_x1_24945 = heff_get_n(v_t_24944, 6, 9);
  V v_t_24946;
  if ((heff_dup(v_x1_24945) == NTAG(TAG_True))) {
    heff_drop(v_x1_24945);
    v_t_24946 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24945);
    v_t_24946 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24947 = heff_tr(heff_call(v_one_24942, 1, (V[]){v_a_24943}));
  return (g_std_2edoc_2e_3c_3e(v_t_24946, v_t_24947));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam31(V self, V *args) {
  V v_a_24955 = args[0];
  V v_one_24954 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24956 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24955));
  V v_x1_24957 = heff_get_n(v_t_24956, 6, 9);
  V v_t_24958;
  if ((heff_dup(v_x1_24957) == NTAG(TAG_True))) {
    heff_drop(v_x1_24957);
    v_t_24958 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24957);
    v_t_24958 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24959 = heff_tr(heff_call(v_one_24954, 1, (V[]){v_a_24955}));
  return (g_std_2edoc_2e_3c_3e(v_t_24958, v_t_24959));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam32(V self, V *args) {
  V v_a_24969 = args[0];
  V v_one_24968 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24970 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24969));
  V v_x1_24971 = heff_get_n(v_t_24970, 6, 9);
  V v_t_24972;
  if ((heff_dup(v_x1_24971) == NTAG(TAG_True))) {
    heff_drop(v_x1_24971);
    v_t_24972 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24971);
    v_t_24972 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24973 = heff_tr(heff_call(v_one_24968, 1, (V[]){v_a_24969}));
  return (g_std_2edoc_2e_3c_3e(v_t_24972, v_t_24973));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam33(V self, V *args) {
  V v_a_24981 = args[0];
  V v_one_24980 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24982 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24981));
  V v_x1_24983 = heff_get_n(v_t_24982, 6, 9);
  V v_t_24984;
  if ((heff_dup(v_x1_24983) == NTAG(TAG_True))) {
    heff_drop(v_x1_24983);
    v_t_24984 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24983);
    v_t_24984 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24985 = heff_tr(heff_call(v_one_24980, 1, (V[]){v_a_24981}));
  return (g_std_2edoc_2e_3c_3e(v_t_24984, v_t_24985));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam34(V self, V *args) {
  V v_a_24994 = args[0];
  V v_one_24993 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24995 = (g_heff_2esyntax_2ecst_2efirstE(v_a_24994));
  V v_x1_24996 = heff_get_n(v_t_24995, 6, 9);
  V v_t_24997;
  if ((heff_dup(v_x1_24996) == NTAG(TAG_True))) {
    heff_drop(v_x1_24996);
    v_t_24997 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_24996);
    v_t_24997 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_24998 = heff_tr(heff_call(v_one_24993, 1, (V[]){v_a_24994}));
  return (g_std_2edoc_2e_3c_3e(v_t_24997, v_t_24998));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam35(V self, V *args) {
  V v_a_241006 = args[0];
  V v_one_241005 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241007 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241006));
  V v_x1_241008 = heff_get_n(v_t_241007, 6, 9);
  V v_t_241009;
  if ((heff_dup(v_x1_241008) == NTAG(TAG_True))) {
    heff_drop(v_x1_241008);
    v_t_241009 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241008);
    v_t_241009 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241010 = heff_tr(heff_call(v_one_241005, 1, (V[]){v_a_241006}));
  return (g_std_2edoc_2e_3c_3e(v_t_241009, v_t_241010));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam36(V self, V *args) {
  V v_a_241020 = args[0];
  V v_one_241019 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241021 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241020));
  V v_x1_241022 = heff_get_n(v_t_241021, 6, 9);
  V v_t_241023;
  if ((heff_dup(v_x1_241022) == NTAG(TAG_True))) {
    heff_drop(v_x1_241022);
    v_t_241023 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241022);
    v_t_241023 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241024 = heff_tr(heff_call(v_one_241019, 1, (V[]){v_a_241020}));
  return (g_std_2edoc_2e_3c_3e(v_t_241023, v_t_241024));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam37(V self, V *args) {
  V v_a_241032 = args[0];
  V v_one_241031 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241033 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241032));
  V v_x1_241034 = heff_get_n(v_t_241033, 6, 9);
  V v_t_241035;
  if ((heff_dup(v_x1_241034) == NTAG(TAG_True))) {
    heff_drop(v_x1_241034);
    v_t_241035 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241034);
    v_t_241035 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241036 = heff_tr(heff_call(v_one_241031, 1, (V[]){v_a_241032}));
  return (g_std_2edoc_2e_3c_3e(v_t_241035, v_t_241036));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam38(V self, V *args) {
  V v_a_241048 = args[0];
  V v_one_241047 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241049 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241048));
  V v_x1_241050 = heff_get_n(v_t_241049, 6, 9);
  V v_t_241051;
  if ((heff_dup(v_x1_241050) == NTAG(TAG_True))) {
    heff_drop(v_x1_241050);
    v_t_241051 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241050);
    v_t_241051 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241052 = heff_tr(heff_call(v_one_241047, 1, (V[]){v_a_241048}));
  return (g_std_2edoc_2e_3c_3e(v_t_241051, v_t_241052));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam39(V self, V *args) {
  V v_a_241060 = args[0];
  V v_one_241059 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241061 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241060));
  V v_x1_241062 = heff_get_n(v_t_241061, 6, 9);
  V v_t_241063;
  if ((heff_dup(v_x1_241062) == NTAG(TAG_True))) {
    heff_drop(v_x1_241062);
    v_t_241063 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241062);
    v_t_241063 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241064 = heff_tr(heff_call(v_one_241059, 1, (V[]){v_a_241060}));
  return (g_std_2edoc_2e_3c_3e(v_t_241063, v_t_241064));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam40(V self, V *args) {
  V v_a_241073 = args[0];
  V v_one_241072 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241074 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241073));
  V v_x1_241075 = heff_get_n(v_t_241074, 6, 9);
  V v_t_241076;
  if ((heff_dup(v_x1_241075) == NTAG(TAG_True))) {
    heff_drop(v_x1_241075);
    v_t_241076 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241075);
    v_t_241076 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241077 = heff_tr(heff_call(v_one_241072, 1, (V[]){v_a_241073}));
  return (g_std_2edoc_2e_3c_3e(v_t_241076, v_t_241077));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam41(V self, V *args) {
  V v_a_241085 = args[0];
  V v_one_241084 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241086 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241085));
  V v_x1_241087 = heff_get_n(v_t_241086, 6, 9);
  V v_t_241088;
  if ((heff_dup(v_x1_241087) == NTAG(TAG_True))) {
    heff_drop(v_x1_241087);
    v_t_241088 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241087);
    v_t_241088 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241089 = heff_tr(heff_call(v_one_241084, 1, (V[]){v_a_241085}));
  return (g_std_2edoc_2e_3c_3e(v_t_241088, v_t_241089));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam42(V self, V *args) {
  V v_a_241100 = args[0];
  V v_one_241099 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241101 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241100));
  V v_x1_241102 = heff_get_n(v_t_241101, 6, 9);
  V v_t_241103;
  if ((heff_dup(v_x1_241102) == NTAG(TAG_True))) {
    heff_drop(v_x1_241102);
    v_t_241103 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241102);
    v_t_241103 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241104 = heff_tr(heff_call(v_one_241099, 1, (V[]){v_a_241100}));
  return (g_std_2edoc_2e_3c_3e(v_t_241103, v_t_241104));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam43(V self, V *args) {
  V v_a_241112 = args[0];
  V v_one_241111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241113 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241112));
  V v_x1_241114 = heff_get_n(v_t_241113, 6, 9);
  V v_t_241115;
  if ((heff_dup(v_x1_241114) == NTAG(TAG_True))) {
    heff_drop(v_x1_241114);
    v_t_241115 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241114);
    v_t_241115 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241116 = heff_tr(heff_call(v_one_241111, 1, (V[]){v_a_241112}));
  return (g_std_2edoc_2e_3c_3e(v_t_241115, v_t_241116));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam44(V self, V *args) {
  V v_a_241125 = args[0];
  V v_one_241124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241126 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241125));
  V v_x1_241127 = heff_get_n(v_t_241126, 6, 9);
  V v_t_241128;
  if ((heff_dup(v_x1_241127) == NTAG(TAG_True))) {
    heff_drop(v_x1_241127);
    v_t_241128 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241127);
    v_t_241128 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241129 = heff_tr(heff_call(v_one_241124, 1, (V[]){v_a_241125}));
  return (g_std_2edoc_2e_3c_3e(v_t_241128, v_t_241129));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam45(V self, V *args) {
  V v_a_241137 = args[0];
  V v_one_241136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241138 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241137));
  V v_x1_241139 = heff_get_n(v_t_241138, 6, 9);
  V v_t_241140;
  if ((heff_dup(v_x1_241139) == NTAG(TAG_True))) {
    heff_drop(v_x1_241139);
    v_t_241140 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241139);
    v_t_241140 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241141 = heff_tr(heff_call(v_one_241136, 1, (V[]){v_a_241137}));
  return (g_std_2edoc_2e_3c_3e(v_t_241140, v_t_241141));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam46(V self, V *args) {
  V v_a_241150 = args[0];
  V v_one_241149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241151 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241150));
  V v_x1_241152 = heff_get_n(v_t_241151, 6, 9);
  V v_t_241153;
  if ((heff_dup(v_x1_241152) == NTAG(TAG_True))) {
    heff_drop(v_x1_241152);
    v_t_241153 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241152);
    v_t_241153 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241154 = heff_tr(heff_call(v_one_241149, 1, (V[]){v_a_241150}));
  return (g_std_2edoc_2e_3c_3e(v_t_241153, v_t_241154));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam47(V self, V *args) {
  V v_a_241162 = args[0];
  V v_one_241161 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241163 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241162));
  V v_x1_241164 = heff_get_n(v_t_241163, 6, 9);
  V v_t_241165;
  if ((heff_dup(v_x1_241164) == NTAG(TAG_True))) {
    heff_drop(v_x1_241164);
    v_t_241165 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241164);
    v_t_241165 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241166 = heff_tr(heff_call(v_one_241161, 1, (V[]){v_a_241162}));
  return (g_std_2edoc_2e_3c_3e(v_t_241165, v_t_241166));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam48(V self, V *args) {
  V v_a_241177 = args[0];
  V v_one_241176 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241178 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241177));
  V v_x1_241179 = heff_get_n(v_t_241178, 6, 9);
  V v_t_241180;
  if ((heff_dup(v_x1_241179) == NTAG(TAG_True))) {
    heff_drop(v_x1_241179);
    v_t_241180 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241179);
    v_t_241180 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241181 = heff_tr(heff_call(v_one_241176, 1, (V[]){v_a_241177}));
  return (g_std_2edoc_2e_3c_3e(v_t_241180, v_t_241181));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam49(V self, V *args) {
  V v_a_241189 = args[0];
  V v_one_241188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241190 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241189));
  V v_x1_241191 = heff_get_n(v_t_241190, 6, 9);
  V v_t_241192;
  if ((heff_dup(v_x1_241191) == NTAG(TAG_True))) {
    heff_drop(v_x1_241191);
    v_t_241192 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241191);
    v_t_241192 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241193 = heff_tr(heff_call(v_one_241188, 1, (V[]){v_a_241189}));
  return (g_std_2edoc_2e_3c_3e(v_t_241192, v_t_241193));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam50(V self, V *args) {
  V v_a_241201 = args[0];
  V v_one_241200 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241202 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241201));
  V v_x1_241203 = heff_get_n(v_t_241202, 6, 9);
  V v_t_241204;
  if ((heff_dup(v_x1_241203) == NTAG(TAG_True))) {
    heff_drop(v_x1_241203);
    v_t_241204 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241203);
    v_t_241204 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241205 = heff_tr(heff_call(v_one_241200, 1, (V[]){v_a_241201}));
  return (g_std_2edoc_2e_3c_3e(v_t_241204, v_t_241205));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam51(V self, V *args) {
  V v_a_241213 = args[0];
  V v_one_241212 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241214 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241213));
  V v_x1_241215 = heff_get_n(v_t_241214, 6, 9);
  V v_t_241216;
  if ((heff_dup(v_x1_241215) == NTAG(TAG_True))) {
    heff_drop(v_x1_241215);
    v_t_241216 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241215);
    v_t_241216 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241217 = heff_tr(heff_call(v_one_241212, 1, (V[]){v_a_241213}));
  return (g_std_2edoc_2e_3c_3e(v_t_241216, v_t_241217));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam52(V self, V *args) {
  V v_a_241225 = args[0];
  V v_one_241224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241226 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241225));
  V v_x1_241227 = heff_get_n(v_t_241226, 6, 9);
  V v_t_241228;
  if ((heff_dup(v_x1_241227) == NTAG(TAG_True))) {
    heff_drop(v_x1_241227);
    v_t_241228 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241227);
    v_t_241228 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241229 = heff_tr(heff_call(v_one_241224, 1, (V[]){v_a_241225}));
  return (g_std_2edoc_2e_3c_3e(v_t_241228, v_t_241229));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam53(V self, V *args) {
  V v_a_241237 = args[0];
  V v_one_241236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241238 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241237));
  V v_x1_241239 = heff_get_n(v_t_241238, 6, 9);
  V v_t_241240;
  if ((heff_dup(v_x1_241239) == NTAG(TAG_True))) {
    heff_drop(v_x1_241239);
    v_t_241240 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241239);
    v_t_241240 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241241 = heff_tr(heff_call(v_one_241236, 1, (V[]){v_a_241237}));
  return (g_std_2edoc_2e_3c_3e(v_t_241240, v_t_241241));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam54(V self, V *args) {
  V v_a_241249 = args[0];
  V v_one_241248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241250 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241249));
  V v_x1_241251 = heff_get_n(v_t_241250, 6, 9);
  V v_t_241252;
  if ((heff_dup(v_x1_241251) == NTAG(TAG_True))) {
    heff_drop(v_x1_241251);
    v_t_241252 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241251);
    v_t_241252 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241253 = heff_tr(heff_call(v_one_241248, 1, (V[]){v_a_241249}));
  return (g_std_2edoc_2e_3c_3e(v_t_241252, v_t_241253));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam55(V self, V *args) {
  V v_a_241261 = args[0];
  V v_one_241260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241262 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241261));
  V v_x1_241263 = heff_get_n(v_t_241262, 6, 9);
  V v_t_241264;
  if ((heff_dup(v_x1_241263) == NTAG(TAG_True))) {
    heff_drop(v_x1_241263);
    v_t_241264 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241263);
    v_t_241264 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241265 = heff_tr(heff_call(v_one_241260, 1, (V[]){v_a_241261}));
  return (g_std_2edoc_2e_3c_3e(v_t_241264, v_t_241265));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam56(V self, V *args) {
  V v_a_241273 = args[0];
  V v_one_241272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241274 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241273));
  V v_x1_241275 = heff_get_n(v_t_241274, 6, 9);
  V v_t_241276;
  if ((heff_dup(v_x1_241275) == NTAG(TAG_True))) {
    heff_drop(v_x1_241275);
    v_t_241276 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241275);
    v_t_241276 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241277 = heff_tr(heff_call(v_one_241272, 1, (V[]){v_a_241273}));
  return (g_std_2edoc_2e_3c_3e(v_t_241276, v_t_241277));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam57(V self, V *args) {
  V v_a_241285 = args[0];
  V v_one_241284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241286 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241285));
  V v_x1_241287 = heff_get_n(v_t_241286, 6, 9);
  V v_t_241288;
  if ((heff_dup(v_x1_241287) == NTAG(TAG_True))) {
    heff_drop(v_x1_241287);
    v_t_241288 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241287);
    v_t_241288 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241289 = heff_tr(heff_call(v_one_241284, 1, (V[]){v_a_241285}));
  return (g_std_2edoc_2e_3c_3e(v_t_241288, v_t_241289));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam58(V self, V *args) {
  V v_a_241298 = args[0];
  V v_one_241297 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241299 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241298));
  V v_x1_241300 = heff_get_n(v_t_241299, 6, 9);
  V v_t_241301;
  if ((heff_dup(v_x1_241300) == NTAG(TAG_True))) {
    heff_drop(v_x1_241300);
    v_t_241301 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241300);
    v_t_241301 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241302 = heff_tr(heff_call(v_one_241297, 1, (V[]){v_a_241298}));
  return (g_std_2edoc_2e_3c_3e(v_t_241301, v_t_241302));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam59(V self, V *args) {
  V v_a_241310 = args[0];
  V v_one_241309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241311 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241310));
  V v_x1_241312 = heff_get_n(v_t_241311, 6, 9);
  V v_t_241313;
  if ((heff_dup(v_x1_241312) == NTAG(TAG_True))) {
    heff_drop(v_x1_241312);
    v_t_241313 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241312);
    v_t_241313 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241314 = heff_tr(heff_call(v_one_241309, 1, (V[]){v_a_241310}));
  return (g_std_2edoc_2e_3c_3e(v_t_241313, v_t_241314));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam60(V self, V *args) {
  V v_a_241322 = args[0];
  V v_one_241321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241323 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241322));
  V v_x1_241324 = heff_get_n(v_t_241323, 6, 9);
  V v_t_241325;
  if ((heff_dup(v_x1_241324) == NTAG(TAG_True))) {
    heff_drop(v_x1_241324);
    v_t_241325 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241324);
    v_t_241325 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241326 = heff_tr(heff_call(v_one_241321, 1, (V[]){v_a_241322}));
  return (g_std_2edoc_2e_3c_3e(v_t_241325, v_t_241326));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam61(V self, V *args) {
  V v_a_241334 = args[0];
  V v_one_241333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241335 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241334));
  V v_x1_241336 = heff_get_n(v_t_241335, 6, 9);
  V v_t_241337;
  if ((heff_dup(v_x1_241336) == NTAG(TAG_True))) {
    heff_drop(v_x1_241336);
    v_t_241337 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241336);
    v_t_241337 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241338 = heff_tr(heff_call(v_one_241333, 1, (V[]){v_a_241334}));
  return (g_std_2edoc_2e_3c_3e(v_t_241337, v_t_241338));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam62(V self, V *args) {
  V v_a_241346 = args[0];
  V v_one_241345 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241347 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241346));
  V v_x1_241348 = heff_get_n(v_t_241347, 6, 9);
  V v_t_241349;
  if ((heff_dup(v_x1_241348) == NTAG(TAG_True))) {
    heff_drop(v_x1_241348);
    v_t_241349 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241348);
    v_t_241349 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241350 = heff_tr(heff_call(v_one_241345, 1, (V[]){v_a_241346}));
  return (g_std_2edoc_2e_3c_3e(v_t_241349, v_t_241350));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam63(V self, V *args) {
  V v_a_241358 = args[0];
  V v_one_241357 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241359 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241358));
  V v_x1_241360 = heff_get_n(v_t_241359, 6, 9);
  V v_t_241361;
  if ((heff_dup(v_x1_241360) == NTAG(TAG_True))) {
    heff_drop(v_x1_241360);
    v_t_241361 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241360);
    v_t_241361 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241362 = heff_tr(heff_call(v_one_241357, 1, (V[]){v_a_241358}));
  return (g_std_2edoc_2e_3c_3e(v_t_241361, v_t_241362));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam64(V self, V *args) {
  V v_a_241371 = args[0];
  V v_one_241370 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241372 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241371));
  V v_x1_241373 = heff_get_n(v_t_241372, 6, 9);
  V v_t_241374;
  if ((heff_dup(v_x1_241373) == NTAG(TAG_True))) {
    heff_drop(v_x1_241373);
    v_t_241374 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241373);
    v_t_241374 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241375 = heff_tr(heff_call(v_one_241370, 1, (V[]){v_a_241371}));
  return (g_std_2edoc_2e_3c_3e(v_t_241374, v_t_241375));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam65(V self, V *args) {
  V v_a_241383 = args[0];
  V v_one_241382 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241384 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241383));
  V v_x1_241385 = heff_get_n(v_t_241384, 6, 9);
  V v_t_241386;
  if ((heff_dup(v_x1_241385) == NTAG(TAG_True))) {
    heff_drop(v_x1_241385);
    v_t_241386 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241385);
    v_t_241386 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241387 = heff_tr(heff_call(v_one_241382, 1, (V[]){v_a_241383}));
  return (g_std_2edoc_2e_3c_3e(v_t_241386, v_t_241387));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam66(V self, V *args) {
  V v_a_241394 = args[0];
  V v_one_241393 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241395 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241394));
  V v_x1_241396 = heff_get_n(v_t_241395, 6, 9);
  V v_t_241397;
  if ((heff_dup(v_x1_241396) == NTAG(TAG_True))) {
    heff_drop(v_x1_241396);
    v_t_241397 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241396);
    v_t_241397 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241398 = heff_tr(heff_call(v_one_241393, 1, (V[]){v_a_241394}));
  return (g_std_2edoc_2e_3c_3e(v_t_241397, v_t_241398));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam67(V self, V *args) {
  V v_a_241406 = args[0];
  V v_one_241405 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241407 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241406));
  V v_x1_241408 = heff_get_n(v_t_241407, 6, 9);
  V v_t_241409;
  if ((heff_dup(v_x1_241408) == NTAG(TAG_True))) {
    heff_drop(v_x1_241408);
    v_t_241409 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241408);
    v_t_241409 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241410 = heff_tr(heff_call(v_one_241405, 1, (V[]){v_a_241406}));
  return (g_std_2edoc_2e_3c_3e(v_t_241409, v_t_241410));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam68(V self, V *args) {
  V v_a_241419 = args[0];
  V v_one_241418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241420 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241419));
  V v_x1_241421 = heff_get_n(v_t_241420, 6, 9);
  V v_t_241422;
  if ((heff_dup(v_x1_241421) == NTAG(TAG_True))) {
    heff_drop(v_x1_241421);
    v_t_241422 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241421);
    v_t_241422 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241423 = heff_tr(heff_call(v_one_241418, 1, (V[]){v_a_241419}));
  return (g_std_2edoc_2e_3c_3e(v_t_241422, v_t_241423));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam69(V self, V *args) {
  V v_a_241431 = args[0];
  V v_one_241430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241432 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241431));
  V v_x1_241433 = heff_get_n(v_t_241432, 6, 9);
  V v_t_241434;
  if ((heff_dup(v_x1_241433) == NTAG(TAG_True))) {
    heff_drop(v_x1_241433);
    v_t_241434 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241433);
    v_t_241434 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241435 = heff_tr(heff_call(v_one_241430, 1, (V[]){v_a_241431}));
  return (g_std_2edoc_2e_3c_3e(v_t_241434, v_t_241435));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam70(V self, V *args) {
  V v_a_241446 = args[0];
  V v_one_241445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241447 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241446));
  V v_x1_241448 = heff_get_n(v_t_241447, 6, 9);
  V v_t_241449;
  if ((heff_dup(v_x1_241448) == NTAG(TAG_True))) {
    heff_drop(v_x1_241448);
    v_t_241449 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241448);
    v_t_241449 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241450 = heff_tr(heff_call(v_one_241445, 1, (V[]){v_a_241446}));
  return (g_std_2edoc_2e_3c_3e(v_t_241449, v_t_241450));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam71(V self, V *args) {
  V v_a_241458 = args[0];
  V v_one_241457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241459 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241458));
  V v_x1_241460 = heff_get_n(v_t_241459, 6, 9);
  V v_t_241461;
  if ((heff_dup(v_x1_241460) == NTAG(TAG_True))) {
    heff_drop(v_x1_241460);
    v_t_241461 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241460);
    v_t_241461 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241462 = heff_tr(heff_call(v_one_241457, 1, (V[]){v_a_241458}));
  return (g_std_2edoc_2e_3c_3e(v_t_241461, v_t_241462));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam72(V self, V *args) {
  V v_a_241472 = args[0];
  V v_one_241471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241473 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241472));
  V v_x1_241474 = heff_get_n(v_t_241473, 6, 9);
  V v_t_241475;
  if ((heff_dup(v_x1_241474) == NTAG(TAG_True))) {
    heff_drop(v_x1_241474);
    v_t_241475 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241474);
    v_t_241475 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241476 = heff_tr(heff_call(v_one_241471, 1, (V[]){v_a_241472}));
  return (g_std_2edoc_2e_3c_3e(v_t_241475, v_t_241476));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam73(V self, V *args) {
  V v_a_241484 = args[0];
  V v_one_241483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241485 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241484));
  V v_x1_241486 = heff_get_n(v_t_241485, 6, 9);
  V v_t_241487;
  if ((heff_dup(v_x1_241486) == NTAG(TAG_True))) {
    heff_drop(v_x1_241486);
    v_t_241487 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241486);
    v_t_241487 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241488 = heff_tr(heff_call(v_one_241483, 1, (V[]){v_a_241484}));
  return (g_std_2edoc_2e_3c_3e(v_t_241487, v_t_241488));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam74(V self, V *args) {
  V v_a_241498 = args[0];
  V v_one_241497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241499 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241498));
  V v_x1_241500 = heff_get_n(v_t_241499, 6, 9);
  V v_t_241501;
  if ((heff_dup(v_x1_241500) == NTAG(TAG_True))) {
    heff_drop(v_x1_241500);
    v_t_241501 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241500);
    v_t_241501 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241502 = heff_tr(heff_call(v_one_241497, 1, (V[]){v_a_241498}));
  return (g_std_2edoc_2e_3c_3e(v_t_241501, v_t_241502));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam75(V self, V *args) {
  V v_a_241510 = args[0];
  V v_one_241509 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241511 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241510));
  V v_x1_241512 = heff_get_n(v_t_241511, 6, 9);
  V v_t_241513;
  if ((heff_dup(v_x1_241512) == NTAG(TAG_True))) {
    heff_drop(v_x1_241512);
    v_t_241513 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241512);
    v_t_241513 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241514 = heff_tr(heff_call(v_one_241509, 1, (V[]){v_a_241510}));
  return (g_std_2edoc_2e_3c_3e(v_t_241513, v_t_241514));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam76(V self, V *args) {
  V v_a_241523 = args[0];
  V v_one_241522 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241524 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241523));
  V v_x1_241525 = heff_get_n(v_t_241524, 6, 9);
  V v_t_241526;
  if ((heff_dup(v_x1_241525) == NTAG(TAG_True))) {
    heff_drop(v_x1_241525);
    v_t_241526 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241525);
    v_t_241526 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241527 = heff_tr(heff_call(v_one_241522, 1, (V[]){v_a_241523}));
  return (g_std_2edoc_2e_3c_3e(v_t_241526, v_t_241527));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam77(V self, V *args) {
  V v_a_241535 = args[0];
  V v_one_241534 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241536 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241535));
  V v_x1_241537 = heff_get_n(v_t_241536, 6, 9);
  V v_t_241538;
  if ((heff_dup(v_x1_241537) == NTAG(TAG_True))) {
    heff_drop(v_x1_241537);
    v_t_241538 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241537);
    v_t_241538 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241539 = heff_tr(heff_call(v_one_241534, 1, (V[]){v_a_241535}));
  return (g_std_2edoc_2e_3c_3e(v_t_241538, v_t_241539));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam78(V self, V *args) {
  V v_a_241551 = args[0];
  V v_one_241550 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241552 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241551));
  V v_x1_241553 = heff_get_n(v_t_241552, 6, 9);
  V v_t_241554;
  if ((heff_dup(v_x1_241553) == NTAG(TAG_True))) {
    heff_drop(v_x1_241553);
    v_t_241554 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241553);
    v_t_241554 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241555 = heff_tr(heff_call(v_one_241550, 1, (V[]){v_a_241551}));
  return (g_std_2edoc_2e_3c_3e(v_t_241554, v_t_241555));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam79(V self, V *args) {
  V v_a_241563 = args[0];
  V v_one_241562 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241564 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241563));
  V v_x1_241565 = heff_get_n(v_t_241564, 6, 9);
  V v_t_241566;
  if ((heff_dup(v_x1_241565) == NTAG(TAG_True))) {
    heff_drop(v_x1_241565);
    v_t_241566 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241565);
    v_t_241566 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241567 = heff_tr(heff_call(v_one_241562, 1, (V[]){v_a_241563}));
  return (g_std_2edoc_2e_3c_3e(v_t_241566, v_t_241567));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam80(V self, V *args) {
  V v_a_241575 = args[0];
  V v_one_241574 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241576 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241575));
  V v_x1_241577 = heff_get_n(v_t_241576, 6, 9);
  V v_t_241578;
  if ((heff_dup(v_x1_241577) == NTAG(TAG_True))) {
    heff_drop(v_x1_241577);
    v_t_241578 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241577);
    v_t_241578 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241579 = heff_tr(heff_call(v_one_241574, 1, (V[]){v_a_241575}));
  return (g_std_2edoc_2e_3c_3e(v_t_241578, v_t_241579));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam81(V self, V *args) {
  V v_a_241587 = args[0];
  V v_one_241586 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241588 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241587));
  V v_x1_241589 = heff_get_n(v_t_241588, 6, 9);
  V v_t_241590;
  if ((heff_dup(v_x1_241589) == NTAG(TAG_True))) {
    heff_drop(v_x1_241589);
    v_t_241590 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241589);
    v_t_241590 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241591 = heff_tr(heff_call(v_one_241586, 1, (V[]){v_a_241587}));
  return (g_std_2edoc_2e_3c_3e(v_t_241590, v_t_241591));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam82(V self, V *args) {
  V v_a_241600 = args[0];
  V v_one_241599 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241601 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241600));
  V v_x1_241602 = heff_get_n(v_t_241601, 6, 9);
  V v_t_241603;
  if ((heff_dup(v_x1_241602) == NTAG(TAG_True))) {
    heff_drop(v_x1_241602);
    v_t_241603 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241602);
    v_t_241603 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241604 = heff_tr(heff_call(v_one_241599, 1, (V[]){v_a_241600}));
  return (g_std_2edoc_2e_3c_3e(v_t_241603, v_t_241604));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam83(V self, V *args) {
  V v_a_241612 = args[0];
  V v_one_241611 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241613 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241612));
  V v_x1_241614 = heff_get_n(v_t_241613, 6, 9);
  V v_t_241615;
  if ((heff_dup(v_x1_241614) == NTAG(TAG_True))) {
    heff_drop(v_x1_241614);
    v_t_241615 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241614);
    v_t_241615 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241616 = heff_tr(heff_call(v_one_241611, 1, (V[]){v_a_241612}));
  return (g_std_2edoc_2e_3c_3e(v_t_241615, v_t_241616));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam84(V self, V *args) {
  V v_a_241628 = args[0];
  V v_one_241627 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241629 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241628));
  V v_x1_241630 = heff_get_n(v_t_241629, 6, 9);
  V v_t_241631;
  if ((heff_dup(v_x1_241630) == NTAG(TAG_True))) {
    heff_drop(v_x1_241630);
    v_t_241631 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241630);
    v_t_241631 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241632 = heff_tr(heff_call(v_one_241627, 1, (V[]){v_a_241628}));
  return (g_std_2edoc_2e_3c_3e(v_t_241631, v_t_241632));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam85(V self, V *args) {
  V v_a_241640 = args[0];
  V v_one_241639 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_241641 = (g_heff_2esyntax_2ecst_2efirstE(v_a_241640));
  V v_x1_241642 = heff_get_n(v_t_241641, 6, 9);
  V v_t_241643;
  if ((heff_dup(v_x1_241642) == NTAG(TAG_True))) {
    heff_drop(v_x1_241642);
    v_t_241643 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_241642);
    v_t_241643 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_241644 = heff_tr(heff_call(v_one_241639, 1, (V[]){v_a_241640}));
  return (g_std_2edoc_2e_3c_3e(v_t_241643, v_t_241644));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam25(V self, V *args) {
  V v_env_24872 = args[0];
  V v_h_24873 = args[1];
  V v_args_24874 = args[2];
  V v_x1_24875 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_24874)));
  V v_t_24879;
  switch (heff_tag_of(v_x1_24875)) {
  case TAG_Nil: {
    v_t_24879 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_24876 = heff_field(v_x1_24875, 0);
    V v_rev_24877 = heff_field(v_x1_24875, 1);
    V v_ru_24x1_24875_24Cons = heff_take_reuse_n(v_x1_24875, 3ULL, 2);
    V v_t_24878 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rev_24877));
    v_t_24879 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_24875_24Cons, TAG_MkPair, 2, (V[]){v_t_24878, v_x_24876})});
    break;
  }
  default: heff_nomatch(v_x1_24875);
  }
  switch (heff_tag_of(v_t_24879)) {
  case TAG_Nothing: {
    heff_drop(v_args_24874);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_24872;
    args[1] = v_h_24873;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Just: {
    V v_pr_24880 = heff_field(v_t_24879, 0);
    V v_ru_24t_24879_24Just = heff_take_reuse_n(v_t_24879, 1ULL, 1);
    switch (heff_tag_of(v_pr_24880)) {
    case TAG_MkPair: {
      V v_init2_24881 = heff_field(v_pr_24880, 0);
      V v_lastA_24882 = heff_field(v_pr_24880, 1);
      V v_ru_24pr_24880_24MkPair = heff_take_reuse_n(v_pr_24880, 3ULL, 2);
      switch (heff_tag_of(v_lastA_24882)) {
      case TAG_Atom: {
        V v_t_24884 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_24884) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_24884);
          V v_t_24885 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24886 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_24892 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam26, 1, 1, (V[]){v_one_24886}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_24893 = (g_std_2edoc_2e_3c_3e(v_t_24885, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24892})));
          V v_a_24894 = (g_std_2edoc_2egroup(v_t_24893));
          V v_b_24895 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_24896 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str71)}), v_b_24895));
          return (g_std_2edoc_2e_3c_3e(v_a_24894, v_t_24896));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 1);
          heff_drop(v_t_24884);
          V v_t_24897 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24898 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_24904 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam27, 1, 1, (V[]){v_one_24898}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_24905 = (g_std_2edoc_2e_3c_3e(v_t_24897, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24904})));
          return (g_std_2edoc_2egroup(v_t_24905));
        }
      }
      case TAG_EParen: {
        V v_o_24906 = heff_field(v_lastA_24882, 0);
        V v_e_24907 = heff_field(v_lastA_24882, 1);
        V v_c_24908 = heff_field(v_lastA_24882, 2);
        heff_take_n(v_lastA_24882, 7ULL, 3);
        V v_t_24909 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_e_24907));
        if ((heff_dup(v_t_24909) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_24909);
          V v_t_24910 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24911 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_24917 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam28, 1, 1, (V[]){v_one_24911}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_24918 = (g_std_2edoc_2e_3c_3e(v_t_24910, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24917})));
          V v_a_24919 = (g_std_2edoc_2egroup(v_t_24918));
          V v_b_24920 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_24872), v_o_24906));
          V v_t_24921 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str72)}), v_b_24920));
          V v_t_24922 = (g_std_2edoc_2e_3c_3e(v_a_24919, v_t_24921));
          V v_t_24923 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_e_24907}));
          V v_t_24924 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_24872, v_c_24908));
          V v_t_24925 = (g_std_2edoc_2e_3c_3e(v_t_24923, v_t_24924));
          return (g_std_2edoc_2e_3c_3e(v_t_24922, v_t_24925));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop(v_o_24906);
          heff_drop(v_e_24907);
          heff_drop(v_c_24908);
          heff_drop(v_t_24909);
          V v_t_24926 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24927 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_24933 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam29, 1, 1, (V[]){v_one_24927}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_24934 = (g_std_2edoc_2e_3c_3e(v_t_24926, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24933})));
          return (g_std_2edoc_2egroup(v_t_24934));
        }
      }
      case TAG_Named: {
        V v_t_24940 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_24940) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_24940);
          V v_t_24941 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24942 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_24948 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam30, 1, 1, (V[]){v_one_24942}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_24949 = (g_std_2edoc_2e_3c_3e(v_t_24941, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24948})));
          V v_a_24950 = (g_std_2edoc_2egroup(v_t_24949));
          V v_b_24951 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_24952 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str73)}), v_b_24951));
          return (g_std_2edoc_2e_3c_3e(v_a_24950, v_t_24952));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 5);
          heff_drop(v_t_24940);
          V v_t_24953 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24954 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_24960 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam31, 1, 1, (V[]){v_one_24954}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_24961 = (g_std_2edoc_2e_3c_3e(v_t_24953, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24960})));
          return (g_std_2edoc_2egroup(v_t_24961));
        }
      }
      case TAG_Tup: {
        V v_t_24966 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_24966) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_24966);
          V v_t_24967 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24968 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_24974 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam32, 1, 1, (V[]){v_one_24968}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_24975 = (g_std_2edoc_2e_3c_3e(v_t_24967, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24974})));
          V v_a_24976 = (g_std_2edoc_2egroup(v_t_24975));
          V v_b_24977 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_24978 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str74)}), v_b_24977));
          return (g_std_2edoc_2e_3c_3e(v_a_24976, v_t_24978));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 4);
          heff_drop(v_t_24966);
          V v_t_24979 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24980 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_24986 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam33, 1, 1, (V[]){v_one_24980}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_24987 = (g_std_2edoc_2e_3c_3e(v_t_24979, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24986})));
          return (g_std_2edoc_2egroup(v_t_24987));
        }
      }
      case TAG_Seg: {
        V v_t_24991 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_24991) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_24991);
          V v_t_24992 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_24993 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_24999 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam34, 1, 1, (V[]){v_one_24993}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241000 = (g_std_2edoc_2e_3c_3e(v_t_24992, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_24999})));
          V v_a_241001 = (g_std_2edoc_2egroup(v_t_241000));
          V v_b_241002 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241003 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str75)}), v_b_241002));
          return (g_std_2edoc_2e_3c_3e(v_a_241001, v_t_241003));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_24991);
          V v_t_241004 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241005 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241011 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam35, 1, 1, (V[]){v_one_241005}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241012 = (g_std_2edoc_2e_3c_3e(v_t_241004, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241011})));
          return (g_std_2edoc_2egroup(v_t_241012));
        }
      }
      case TAG_Braces: {
        V v_t_241017 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241017) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241017);
          V v_t_241018 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241019 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241025 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam36, 1, 1, (V[]){v_one_241019}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241026 = (g_std_2edoc_2e_3c_3e(v_t_241018, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241025})));
          V v_a_241027 = (g_std_2edoc_2egroup(v_t_241026));
          V v_b_241028 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241029 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str76)}), v_b_241028));
          return (g_std_2edoc_2e_3c_3e(v_a_241027, v_t_241029));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 4);
          heff_drop(v_t_241017);
          V v_t_241030 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241031 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241037 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam37, 1, 1, (V[]){v_one_241031}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241038 = (g_std_2edoc_2e_3c_3e(v_t_241030, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241037})));
          return (g_std_2edoc_2egroup(v_t_241038));
        }
      }
      case TAG_Update: {
        V v_t_241045 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241045) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241045);
          V v_t_241046 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241047 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241053 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam38, 1, 1, (V[]){v_one_241047}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241054 = (g_std_2edoc_2e_3c_3e(v_t_241046, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241053})));
          V v_a_241055 = (g_std_2edoc_2egroup(v_t_241054));
          V v_b_241056 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241057 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str77)}), v_b_241056));
          return (g_std_2edoc_2e_3c_3e(v_a_241055, v_t_241057));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 6);
          heff_drop(v_t_241045);
          V v_t_241058 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241059 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241065 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam39, 1, 1, (V[]){v_one_241059}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241066 = (g_std_2edoc_2e_3c_3e(v_t_241058, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241065})));
          return (g_std_2edoc_2egroup(v_t_241066));
        }
      }
      case TAG_EUSet: {
        V v_t_241070 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241070) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241070);
          V v_t_241071 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241072 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241078 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam40, 1, 1, (V[]){v_one_241072}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241079 = (g_std_2edoc_2e_3c_3e(v_t_241071, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241078})));
          V v_a_241080 = (g_std_2edoc_2egroup(v_t_241079));
          V v_b_241081 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241082 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str78)}), v_b_241081));
          return (g_std_2edoc_2e_3c_3e(v_a_241080, v_t_241082));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241070);
          V v_t_241083 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241084 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241090 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam41, 1, 1, (V[]){v_one_241084}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241091 = (g_std_2edoc_2e_3c_3e(v_t_241083, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241090})));
          return (g_std_2edoc_2egroup(v_t_241091));
        }
      }
      case TAG_InstB: {
        V v_t_241097 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241097) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241097);
          V v_t_241098 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241099 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241105 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam42, 1, 1, (V[]){v_one_241099}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241106 = (g_std_2edoc_2e_3c_3e(v_t_241098, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241105})));
          V v_a_241107 = (g_std_2edoc_2egroup(v_t_241106));
          V v_b_241108 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241109 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str79)}), v_b_241108));
          return (g_std_2edoc_2e_3c_3e(v_a_241107, v_t_241109));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 5);
          heff_drop(v_t_241097);
          V v_t_241110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241111 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241117 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam43, 1, 1, (V[]){v_one_241111}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241118 = (g_std_2edoc_2e_3c_3e(v_t_241110, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241117})));
          return (g_std_2edoc_2egroup(v_t_241118));
        }
      }
      case TAG_EFSet: {
        V v_t_241122 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241122) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241122);
          V v_t_241123 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241124 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241130 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam44, 1, 1, (V[]){v_one_241124}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241131 = (g_std_2edoc_2e_3c_3e(v_t_241123, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241130})));
          V v_a_241132 = (g_std_2edoc_2egroup(v_t_241131));
          V v_b_241133 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241134 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str80)}), v_b_241133));
          return (g_std_2edoc_2e_3c_3e(v_a_241132, v_t_241134));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241122);
          V v_t_241135 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241136 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241142 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam45, 1, 1, (V[]){v_one_241136}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241143 = (g_std_2edoc_2e_3c_3e(v_t_241135, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241142})));
          return (g_std_2edoc_2egroup(v_t_241143));
        }
      }
      case TAG_EFDefault: {
        V v_t_241147 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241147) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241147);
          V v_t_241148 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241149 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241155 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam46, 1, 1, (V[]){v_one_241149}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241156 = (g_std_2edoc_2e_3c_3e(v_t_241148, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241155})));
          V v_a_241157 = (g_std_2edoc_2egroup(v_t_241156));
          V v_b_241158 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241159 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str81)}), v_b_241158));
          return (g_std_2edoc_2e_3c_3e(v_a_241157, v_t_241159));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241147);
          V v_t_241160 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241161 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241167 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam47, 1, 1, (V[]){v_one_241161}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241168 = (g_std_2edoc_2e_3c_3e(v_t_241160, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241167})));
          return (g_std_2edoc_2egroup(v_t_241168));
        }
      }
      case TAG_Sum: {
        V v_t_241174 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241174) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241174);
          V v_t_241175 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241176 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241182 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam48, 1, 1, (V[]){v_one_241176}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241183 = (g_std_2edoc_2e_3c_3e(v_t_241175, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241182})));
          V v_a_241184 = (g_std_2edoc_2egroup(v_t_241183));
          V v_b_241185 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241186 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str82)}), v_b_241185));
          return (g_std_2edoc_2e_3c_3e(v_a_241184, v_t_241186));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 5);
          heff_drop(v_t_241174);
          V v_t_241187 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241188 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241194 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam49, 1, 1, (V[]){v_one_241188}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241195 = (g_std_2edoc_2e_3c_3e(v_t_241187, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241194})));
          return (g_std_2edoc_2egroup(v_t_241195));
        }
      }
      case TAG_ECon: {
        V v_t_241198 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241198) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241198);
          V v_t_241199 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241200 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241206 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam50, 1, 1, (V[]){v_one_241200}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241207 = (g_std_2edoc_2e_3c_3e(v_t_241199, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241206})));
          V v_a_241208 = (g_std_2edoc_2egroup(v_t_241207));
          V v_b_241209 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241210 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str83)}), v_b_241209));
          return (g_std_2edoc_2e_3c_3e(v_a_241208, v_t_241210));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241198);
          V v_t_241211 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241212 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241218 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam51, 1, 1, (V[]){v_one_241212}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241219 = (g_std_2edoc_2e_3c_3e(v_t_241211, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241218})));
          return (g_std_2edoc_2egroup(v_t_241219));
        }
      }
      case TAG_EField: {
        V v_t_241222 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241222) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241222);
          V v_t_241223 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241224 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241230 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam52, 1, 1, (V[]){v_one_241224}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241231 = (g_std_2edoc_2e_3c_3e(v_t_241223, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241230})));
          V v_a_241232 = (g_std_2edoc_2egroup(v_t_241231));
          V v_b_241233 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241234 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str84)}), v_b_241233));
          return (g_std_2edoc_2e_3c_3e(v_a_241232, v_t_241234));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241222);
          V v_t_241235 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241236 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241242 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam53, 1, 1, (V[]){v_one_241236}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241243 = (g_std_2edoc_2e_3c_3e(v_t_241235, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241242})));
          return (g_std_2edoc_2egroup(v_t_241243));
        }
      }
      case TAG_ENeg: {
        V v_t_241246 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241246) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241246);
          V v_t_241247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241248 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241254 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam54, 1, 1, (V[]){v_one_241248}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241255 = (g_std_2edoc_2e_3c_3e(v_t_241247, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241254})));
          V v_a_241256 = (g_std_2edoc_2egroup(v_t_241255));
          V v_b_241257 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241258 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str85)}), v_b_241257));
          return (g_std_2edoc_2e_3c_3e(v_a_241256, v_t_241258));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241246);
          V v_t_241259 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241260 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241266 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam55, 1, 1, (V[]){v_one_241260}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241267 = (g_std_2edoc_2e_3c_3e(v_t_241259, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241266})));
          return (g_std_2edoc_2egroup(v_t_241267));
        }
      }
      case TAG_App: {
        V v_t_241270 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241270) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241270);
          V v_t_241271 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241272 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241278 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam56, 1, 1, (V[]){v_one_241272}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241279 = (g_std_2edoc_2e_3c_3e(v_t_241271, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241278})));
          V v_a_241280 = (g_std_2edoc_2egroup(v_t_241279));
          V v_b_241281 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241282 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str86)}), v_b_241281));
          return (g_std_2edoc_2e_3c_3e(v_a_241280, v_t_241282));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241270);
          V v_t_241283 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241284 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241290 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam57, 1, 1, (V[]){v_one_241284}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241291 = (g_std_2edoc_2e_3c_3e(v_t_241283, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241290})));
          return (g_std_2edoc_2egroup(v_t_241291));
        }
      }
      case TAG_Op: {
        V v_t_241295 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241295) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241295);
          V v_t_241296 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241297 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241303 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam58, 1, 1, (V[]){v_one_241297}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241304 = (g_std_2edoc_2e_3c_3e(v_t_241296, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241303})));
          V v_a_241305 = (g_std_2edoc_2egroup(v_t_241304));
          V v_b_241306 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241307 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str87)}), v_b_241306));
          return (g_std_2edoc_2e_3c_3e(v_a_241305, v_t_241307));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241295);
          V v_t_241308 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241309 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241315 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam59, 1, 1, (V[]){v_one_241309}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241316 = (g_std_2edoc_2e_3c_3e(v_t_241308, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241315})));
          return (g_std_2edoc_2egroup(v_t_241316));
        }
      }
      case TAG_Ops: {
        V v_t_241319 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241319) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241319);
          V v_t_241320 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241321 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241327 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam60, 1, 1, (V[]){v_one_241321}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241328 = (g_std_2edoc_2e_3c_3e(v_t_241320, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241327})));
          V v_a_241329 = (g_std_2edoc_2egroup(v_t_241328));
          V v_b_241330 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241331 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str88)}), v_b_241330));
          return (g_std_2edoc_2e_3c_3e(v_a_241329, v_t_241331));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241319);
          V v_t_241332 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241333 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241339 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam61, 1, 1, (V[]){v_one_241333}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241340 = (g_std_2edoc_2e_3c_3e(v_t_241332, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241339})));
          return (g_std_2edoc_2egroup(v_t_241340));
        }
      }
      case TAG_OpRhs: {
        V v_t_241343 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241343) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241343);
          V v_t_241344 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241345 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241351 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam62, 1, 1, (V[]){v_one_241345}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241352 = (g_std_2edoc_2e_3c_3e(v_t_241344, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241351})));
          V v_a_241353 = (g_std_2edoc_2egroup(v_t_241352));
          V v_b_241354 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241355 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str89)}), v_b_241354));
          return (g_std_2edoc_2e_3c_3e(v_a_241353, v_t_241355));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241343);
          V v_t_241356 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241357 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241363 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam63, 1, 1, (V[]){v_one_241357}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241364 = (g_std_2edoc_2e_3c_3e(v_t_241356, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241363})));
          return (g_std_2edoc_2egroup(v_t_241364));
        }
      }
      case TAG_Ann: {
        V v_t_241368 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241368) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241368);
          V v_t_241369 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241370 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241376 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam64, 1, 1, (V[]){v_one_241370}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241377 = (g_std_2edoc_2e_3c_3e(v_t_241369, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241376})));
          V v_a_241378 = (g_std_2edoc_2egroup(v_t_241377));
          V v_b_241379 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241380 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str90)}), v_b_241379));
          return (g_std_2edoc_2e_3c_3e(v_a_241378, v_t_241380));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241368);
          V v_t_241381 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241382 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241388 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam65, 1, 1, (V[]){v_one_241382}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241389 = (g_std_2edoc_2e_3c_3e(v_t_241381, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241388})));
          return (g_std_2edoc_2egroup(v_t_241389));
        }
      }
      case TAG_BVar: {
        V v_t_241391 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241391) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241391);
          V v_t_241392 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241393 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241399 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam66, 1, 1, (V[]){v_one_241393}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241400 = (g_std_2edoc_2e_3c_3e(v_t_241392, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241399})));
          V v_a_241401 = (g_std_2edoc_2egroup(v_t_241400));
          V v_b_241402 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241403 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str91)}), v_b_241402));
          return (g_std_2edoc_2e_3c_3e(v_a_241401, v_t_241403));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 1);
          heff_drop(v_t_241391);
          V v_t_241404 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241405 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241411 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam67, 1, 1, (V[]){v_one_241405}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241412 = (g_std_2edoc_2e_3c_3e(v_t_241404, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241411})));
          return (g_std_2edoc_2egroup(v_t_241412));
        }
      }
      case TAG_BImp: {
        V v_t_241416 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241416) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241416);
          V v_t_241417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241418 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam68, 1, 1, (V[]){v_one_241418}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241425 = (g_std_2edoc_2e_3c_3e(v_t_241417, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241424})));
          V v_a_241426 = (g_std_2edoc_2egroup(v_t_241425));
          V v_b_241427 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241428 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str92)}), v_b_241427));
          return (g_std_2edoc_2e_3c_3e(v_a_241426, v_t_241428));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241416);
          V v_t_241429 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241436 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam69, 1, 1, (V[]){v_one_241430}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241437 = (g_std_2edoc_2e_3c_3e(v_t_241429, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241436})));
          return (g_std_2edoc_2egroup(v_t_241437));
        }
      }
      case TAG_BAnn: {
        V v_t_241443 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241443) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241443);
          V v_t_241444 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241445 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241451 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam70, 1, 1, (V[]){v_one_241445}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241452 = (g_std_2edoc_2e_3c_3e(v_t_241444, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241451})));
          V v_a_241453 = (g_std_2edoc_2egroup(v_t_241452));
          V v_b_241454 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241455 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str93)}), v_b_241454));
          return (g_std_2edoc_2e_3c_3e(v_a_241453, v_t_241455));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 5);
          heff_drop(v_t_241443);
          V v_t_241456 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241457 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241463 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam71, 1, 1, (V[]){v_one_241457}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241464 = (g_std_2edoc_2e_3c_3e(v_t_241456, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241463})));
          return (g_std_2edoc_2egroup(v_t_241464));
        }
      }
      case TAG_Lam: {
        V v_t_241469 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241469) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241469);
          V v_t_241470 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241471 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241477 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam72, 1, 1, (V[]){v_one_241471}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241478 = (g_std_2edoc_2e_3c_3e(v_t_241470, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241477})));
          V v_a_241479 = (g_std_2edoc_2egroup(v_t_241478));
          V v_b_241480 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241481 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str94)}), v_b_241480));
          return (g_std_2edoc_2e_3c_3e(v_a_241479, v_t_241481));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 4);
          heff_drop(v_t_241469);
          V v_t_241482 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241483 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241489 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam73, 1, 1, (V[]){v_one_241483}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241490 = (g_std_2edoc_2e_3c_3e(v_t_241482, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241489})));
          return (g_std_2edoc_2egroup(v_t_241490));
        }
      }
      case TAG_Case: {
        V v_t_241495 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241495) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241495);
          V v_t_241496 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241497 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241503 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam74, 1, 1, (V[]){v_one_241497}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241504 = (g_std_2edoc_2e_3c_3e(v_t_241496, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241503})));
          V v_a_241505 = (g_std_2edoc_2egroup(v_t_241504));
          V v_b_241506 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241507 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str95)}), v_b_241506));
          return (g_std_2edoc_2e_3c_3e(v_a_241505, v_t_241507));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 4);
          heff_drop(v_t_241495);
          V v_t_241508 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241509 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241515 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam75, 1, 1, (V[]){v_one_241509}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241516 = (g_std_2edoc_2e_3c_3e(v_t_241508, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241515})));
          return (g_std_2edoc_2egroup(v_t_241516));
        }
      }
      case TAG_EAlt: {
        V v_t_241520 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241520) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241520);
          V v_t_241521 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241522 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241528 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam76, 1, 1, (V[]){v_one_241522}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241529 = (g_std_2edoc_2e_3c_3e(v_t_241521, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241528})));
          V v_a_241530 = (g_std_2edoc_2egroup(v_t_241529));
          V v_b_241531 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241532 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str96)}), v_b_241531));
          return (g_std_2edoc_2e_3c_3e(v_a_241530, v_t_241532));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241520);
          V v_t_241533 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241534 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241540 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam77, 1, 1, (V[]){v_one_241534}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241541 = (g_std_2edoc_2e_3c_3e(v_t_241533, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241540})));
          return (g_std_2edoc_2egroup(v_t_241541));
        }
      }
      case TAG_If: {
        V v_t_241548 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241548) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241548);
          V v_t_241549 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241550 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241556 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam78, 1, 1, (V[]){v_one_241550}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241557 = (g_std_2edoc_2e_3c_3e(v_t_241549, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241556})));
          V v_a_241558 = (g_std_2edoc_2egroup(v_t_241557));
          V v_b_241559 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241560 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str97)}), v_b_241559));
          return (g_std_2edoc_2e_3c_3e(v_a_241558, v_t_241560));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 6);
          heff_drop(v_t_241548);
          V v_t_241561 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241562 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241568 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam79, 1, 1, (V[]){v_one_241562}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241569 = (g_std_2edoc_2e_3c_3e(v_t_241561, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241568})));
          return (g_std_2edoc_2egroup(v_t_241569));
        }
      }
      case TAG_Do: {
        V v_t_241572 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241572) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241572);
          V v_t_241573 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241574 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241580 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam80, 1, 1, (V[]){v_one_241574}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241581 = (g_std_2edoc_2e_3c_3e(v_t_241573, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241580})));
          V v_a_241582 = (g_std_2edoc_2egroup(v_t_241581));
          V v_b_241583 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241584 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str98)}), v_b_241583));
          return (g_std_2edoc_2e_3c_3e(v_a_241582, v_t_241584));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 2);
          heff_drop(v_t_241572);
          V v_t_241585 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241586 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241592 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam81, 1, 1, (V[]){v_one_241586}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241593 = (g_std_2edoc_2e_3c_3e(v_t_241585, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241592})));
          return (g_std_2edoc_2egroup(v_t_241593));
        }
      }
      case TAG_ESBind: {
        V v_t_241597 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241597) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241597);
          V v_t_241598 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241599 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241605 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam82, 1, 1, (V[]){v_one_241599}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241606 = (g_std_2edoc_2e_3c_3e(v_t_241598, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241605})));
          V v_a_241607 = (g_std_2edoc_2egroup(v_t_241606));
          V v_b_241608 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241609 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str99)}), v_b_241608));
          return (g_std_2edoc_2e_3c_3e(v_a_241607, v_t_241609));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 3);
          heff_drop(v_t_241597);
          V v_t_241610 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241611 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241617 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam83, 1, 1, (V[]){v_one_241611}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241618 = (g_std_2edoc_2e_3c_3e(v_t_241610, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241617})));
          return (g_std_2edoc_2egroup(v_t_241618));
        }
      }
      case TAG_ELet: {
        V v_t_241625 = (g_heff_2esyntax_2efmt_2elayout_2ehangs(v_lastA_24882));
        if ((heff_dup(v_t_241625) == NTAG(TAG_True))) {
          heff_drop(v_args_24874);
          heff_drop(v_t_241625);
          V v_t_241626 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241627 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){heff_dup(v_env_24872)}));
          V v_d_241633 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam84, 1, 1, (V[]){v_one_241627}); V a_2 = v_init2_24881; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_init2_24881); r_; });
          V v_t_241634 = (g_std_2edoc_2e_3c_3e(v_t_241626, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241633})));
          V v_a_241635 = (g_std_2edoc_2egroup(v_t_241634));
          V v_b_241636 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_24872, v_lastA_24882}));
          V v_t_241637 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24t_24879_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str100)}), v_b_241636));
          return (g_std_2edoc_2e_3c_3e(v_a_241635, v_t_241637));
        } else {
          heff_drop_cell(v_ru_24t_24879_24Just, 1);
          heff_drop(v_init2_24881);
          heff_drop_tag(v_lastA_24882, 6);
          heff_drop(v_t_241625);
          V v_t_241638 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_24872), v_h_24873}));
          V v_one_241639 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 1, (V[]){v_env_24872}));
          V v_d_241645 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam85, 1, 1, (V[]){v_one_241639}); V a_2 = v_args_24874; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_args_24874); r_; });
          V v_t_241646 = (g_std_2edoc_2e_3c_3e(v_t_241638, heff_tag_at_n(v_ru_24pr_24880_24MkPair, TAG_Nest, 2, (V[]){MK_INT(2LL), v_d_241645})));
          return (g_std_2edoc_2egroup(v_t_241646));
        }
      }
      default: return heff_nomatch(v_lastA_24882);
      }
    }
    default: return heff_nomatch(v_pr_24880);
    }
  }
  default: return heff_nomatch(v_t_24879);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam86(V self, V *args) {
  V v_env_241647 = args[0];
  V v_rest_241648 = args[1];
  V v_e_241649 = args[2];
  switch (heff_tag_of(v_e_241649)) {
  case TAG_Atom: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V v_o_241666 = heff_field(v_e_241649, 0);
    V v_fs_241667 = heff_field(v_e_241649, 1);
    V v_commas_241668 = heff_field(v_e_241649, 2);
    V v_c_241669 = heff_field(v_e_241649, 3);
    heff_take_n(v_e_241649, 15ULL, 4);
    switch (heff_tag_of(v_fs_241667)) {
    case TAG_Nil: {
      heff_drop(v_rest_241648);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
      args[0] = v_env_241647;
      args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241666, v_fs_241667, v_commas_241668, v_c_241669});
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_Cons: {
      V v_d_241670 = heff_dup(heff_field(v_fs_241667, 0));
      V v_rest2_241671 = heff_dup(heff_field(v_fs_241667, 1));
      switch (heff_tag_of(v_rest2_241671)) {
      case TAG_Nil: {
        V v_t_241672 = ({ V a_0 = v_rest_241648; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eanyArrow(a_0)); heff_drop(v_rest_241648); r_; });
        if ((heff_dup(v_t_241672) == NTAG(TAG_True))) {
          heff_drop(v_t_241672);
          V v_x1_241673 = (g_heff_2esyntax_2efmt_2elayout_2eisFSet(v_d_241670));
          if ((heff_dup(v_x1_241673) == NTAG(TAG_True))) {
            heff_drop(v_d_241670);
            heff_drop(v_x1_241673);
            V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
            args[0] = v_env_241647;
            args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241666, v_fs_241667, v_commas_241668, v_c_241669});
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          } else {
            heff_drop(v_x1_241673);
            switch (heff_tag_of(v_commas_241668)) {
            case TAG_Nil: {
              heff_drop_tag(v_fs_241667, 2);
              V v_t_241674 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241647), v_o_241666));
              V v_t_241675 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241647), v_d_241670}));
              V v_t_241676 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241647, v_c_241669));
              V v_t_241677 = (g_std_2edoc_2e_3c_3e(v_t_241675, v_t_241676));
              return (g_std_2edoc_2e_3c_3e(v_t_241674, v_t_241677));
            }
            case TAG_Cons: {
              heff_drop(v_d_241670);
              V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
              args[0] = v_env_241647;
              args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241666, v_fs_241667, v_commas_241668, v_c_241669});
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            default: return heff_nomatch(v_commas_241668);
            }
          }
        } else {
          heff_drop(v_d_241670);
          heff_drop(v_t_241672);
          V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
          args[0] = v_env_241647;
          args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241666, v_fs_241667, v_commas_241668, v_c_241669});
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_rest2_241671, 0ULL, 2);
        heff_drop(v_rest_241648);
        heff_drop(v_d_241670);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
        args[0] = v_env_241647;
        args[1] = heff_tag_n(TAG_Braces, 4, (V[]){v_o_241666, v_fs_241667, v_commas_241668, v_c_241669});
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_rest2_241671);
      }
    }
    default: return heff_nomatch(v_fs_241667);
    }
  }
  case TAG_Update: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241648);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241647;
    args[1] = v_e_241649;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_e_241649);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam87(V self, V *args) {
  V v_env_241762 = args[0];
  V v_b_241763 = args[1];
  switch (heff_tag_of(v_b_241763)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V v_t_241827 = heff_field(v_b_241763, 0);
    heff_take_n(v_b_241763, 1ULL, 1);
    return (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241762, v_t_241827));
  }
  case TAG_BImp: {
    V v_o_241828 = heff_field(v_b_241763, 0);
    V v_x_241829 = heff_field(v_b_241763, 1);
    V v_c_241830 = heff_field(v_b_241763, 2);
    heff_take_n(v_b_241763, 7ULL, 3);
    V v_t_241831 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241762), v_o_241828));
    V v_t_241832 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241762), v_x_241829));
    V v_t_241833 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241762, v_c_241830));
    V v_t_241834 = (g_std_2edoc_2e_3c_3e(v_t_241832, v_t_241833));
    return (g_std_2edoc_2e_3c_3e(v_t_241831, v_t_241834));
  }
  case TAG_BAnn: {
    V v_o_241835 = heff_field(v_b_241763, 0);
    V v_x_241836 = heff_field(v_b_241763, 1);
    V v_cc_241837 = heff_field(v_b_241763, 2);
    V v_ty_241838 = heff_field(v_b_241763, 3);
    V v_c_241839 = heff_field(v_b_241763, 4);
    heff_take_n(v_b_241763, 31ULL, 5);
    V v_t_241840 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241762), v_o_241835));
    V v_a_241841 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241762), v_x_241836));
    V v_a_241842 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241762), v_cc_241837));
    V v_b_241843 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_241762), v_ty_241838}));
    V v_t_241844 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str101)}), v_b_241843));
    V v_t_241845 = (g_std_2edoc_2e_3c_3e(v_a_241842, v_t_241844));
    V v_t_241846 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str102)}), v_t_241845));
    V v_t_241847 = (g_std_2edoc_2e_3c_3e(v_a_241841, v_t_241846));
    V v_t_241848 = (g_heff_2esyntax_2efmt_2elayout_2etok(v_env_241762, v_c_241839));
    V v_t_241849 = (g_std_2edoc_2e_3c_3e(v_t_241847, v_t_241848));
    return (g_std_2edoc_2e_3c_3e(v_t_241840, v_t_241849));
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241762;
    args[1] = v_b_241763;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_b_241763);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam88(V self, V *args) {
  V v_env_241878 = args[0];
  V v_rest_241879 = args[1];
  V v_r_241880 = args[2];
  switch (heff_tag_of(v_r_241880)) {
  case TAG_Atom: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_241939 = heff_field(v_r_241880, 0);
    V v_e_241940 = heff_field(v_r_241880, 1);
    heff_take_n(v_r_241880, 3ULL, 2);
    V v_a_241941 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241878), v_op_241939));
    V v_b_241942 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 7)), 3, (V[]){v_env_241878, v_rest_241879, v_e_241940}));
    V v_t_241943 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str103)}), v_b_241942));
    return (g_std_2edoc_2e_3c_3e(v_a_241941, v_t_241943));
  }
  case TAG_Ann: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    heff_drop(v_rest_241879);
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241878;
    args[1] = v_r_241880;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241880);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam89(V self, V *args) {
  V v_env_241984 = args[0];
  V v_r_241985 = args[1];
  switch (heff_tag_of(v_r_241985)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V v_op_242044 = heff_field(v_r_241985, 0);
    V v_e_242045 = heff_field(v_r_241985, 1);
    heff_take_n(v_r_241985, 3ULL, 2);
    V v_a_242046 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_241984), v_op_242044));
    V v_b_242047 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_241984, v_e_242045}));
    V v_t_242048 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str104)}), v_b_242047));
    return (g_std_2edoc_2e_3c_3e(v_a_242046, v_t_242048));
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_241984;
    args[1] = v_r_241985;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_r_241985);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam91(V self, V *args) {
  V v_r_242102 = args[0];
  V v_env_242089 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242103 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242102));
  V v_t_242104;
  if ((heff_dup(v_x1_242103) == NTAG(TAG_True))) {
    heff_drop(v_x1_242103);
    v_t_242104 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242103);
    v_t_242104 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242105 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242089, v_r_242102}));
  return (g_std_2edoc_2e_3c_3e(v_t_242104, v_t_242105));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam92(V self, V *args) {
  V v_r_242111 = args[0];
  V v_env_242089 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242112 = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(v_r_242111));
  V v_t_242113;
  if ((heff_dup(v_x1_242112) == NTAG(TAG_True))) {
    heff_drop(v_x1_242112);
    v_t_242113 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_x1_242112);
    v_t_242113 = heff_dup(g_std_2edoc_2eline_get());
  }
  V v_t_242114 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 10)), 2, (V[]){v_env_242089, v_r_242111}));
  return (g_std_2edoc_2e_3c_3e(v_t_242113, v_t_242114));
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam90(V self, V *args) {
  V v_env_242089 = args[0];
  V v_first_242090 = args[1];
  V v_rest_242091 = args[2];
  V v_f_242092 = heff_dup(heff_rfield(v_env_242089, 6));
  HeffT2 v_t_242093 = (g_heff_2esyntax_2efmt_2elayout_2eopsOf_24cpr(heff_dup(v_f_242092), heff_dup(v_rest_242091)));
  {
    V v_field_242095 = v_t_242093.f[1];
    int64_t v_tag_242094 = ((int64_t)v_t_242093.f[0]);
    V v_t_242100;
    if ((v_tag_242094 == ((int64_t)0ULL))) {
      V v_it1_242097 = v_field_242095;
      switch (heff_tag_of(v_it1_242097)) {
      case TAG_Nil: {
        heff_drop(v_f_242092);
        v_t_242100 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_o_242098 = heff_field(v_it1_242097, 0);
        V v_os_242099 = heff_field(v_it1_242097, 1);
        heff_take_n(v_it1_242097, 3ULL, 2);
        v_t_242100 = ({ V a_0 = v_f_242092; V a_1 = v_o_242098; V a_2 = v_os_242099; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eloosestGo(a_0, a_1, a_2)); heff_drop(v_os_242099); r_; });
        break;
      }
      default: heff_nomatch(v_it1_242097);
      }
    } else {
      heff_drop(v_f_242092);
      heff_drop(v_field_242095);
      v_t_242100 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_242100)) {
    case TAG_Nothing: {
      V v_t_242101 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242089), v_first_242090}));
      V v_t_242106 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam91, 1, 1, (V[]){v_env_242089}); V a_2 = v_rest_242091; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242091); r_; });
      V v_t_242107 = (g_std_2edoc_2e_3c_3e(v_t_242101, v_t_242106));
      return (g_std_2edoc_2egroup(v_t_242107));
    }
    case TAG_Just: {
      V v_m_242108 = heff_field(v_t_242100, 0);
      heff_take_n(v_t_242100, 1ULL, 1);
      V v_t_242109 = (g_list_2eall_24s78096928x1476871221(heff_dup(heff_rfield(v_env_242089, 6)), heff_dup(v_m_242108), v_rest_242091));
      if ((heff_dup(v_t_242109) == NTAG(TAG_True))) {
        heff_drop(v_m_242108);
        heff_drop(v_t_242109);
        V v_t_242110 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242089), v_first_242090}));
        V v_t_242115 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2elay_lam92, 1, 1, (V[]){v_env_242089}); V a_2 = v_rest_242091; V r_ = (g_list_2efoldl_24f1559904364x1248618624(a_0, a_1, a_2)); heff_drop(v_rest_242091); r_; });
        V v_t_242116 = (g_std_2edoc_2e_3c_3e(v_t_242110, v_t_242115));
        return (g_std_2edoc_2egroup(v_t_242116));
      } else {
        heff_drop(v_t_242109);
        V v_t_242117 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242089, v_m_242108, v_first_242090, NTAG(TAG_Nil), v_rest_242091}));
        return (g_std_2edoc_2egroup(v_t_242117));
      }
    }
    default: return heff_nomatch(v_t_242100);
    }
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam93(V self, V *args) {
  V v_env_242118 = args[0];
  V v_m_242119 = args[1];
  V v_f_242120 = args[2];
  V v_acc_242121 = args[3];
  V v_rs_242122 = args[4];
  switch (heff_tag_of(v_rs_242122)) {
  case TAG_Nil: {
    heff_drop(v_m_242119);
    V v_t_242123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242121));
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11));
    args[0] = v_env_242118;
    args[1] = v_f_242120;
    args[2] = v_t_242123;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  case TAG_Cons: {
    V v_r_242124 = heff_field(v_rs_242122, 0);
    V v_rest2_242125 = heff_field(v_rs_242122, 1);
    heff_take_n(v_rs_242122, 3ULL, 2);
    switch (heff_tag_of(v_r_242124)) {
    case TAG_Atom: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EParen: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Named: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Tup: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Seg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Braces: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Update: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EUSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_InstB: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFSet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EFDefault: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Sum: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ECon: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EField: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ENeg: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_App: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Op: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Ops: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_OpRhs: {
      V v_op_242184 = heff_dup(heff_field(v_r_242124, 0));
      V v_e_242185 = heff_dup(heff_field(v_r_242124, 1));
      V v_t_242186 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(heff_rfield(v_env_242118, 6)), heff_dup(v_m_242119), heff_dup(heff_rfield(v_op_242184, 1))));
      V v_t_242189;
      switch (heff_tag_of(v_t_242186)) {
      case TAG_Tighter: {
        v_t_242189 = NTAG(TAG_False);
        break;
      }
      case TAG_Looser: {
        v_t_242189 = NTAG(TAG_False);
        break;
      }
      case TAG_Same: {
        heff_take_n(v_t_242186, 0ULL, 1);
        v_t_242189 = NTAG(TAG_True);
        break;
      }
      case TAG_Unrelated: {
        v_t_242189 = NTAG(TAG_False);
        break;
      }
      case TAG_Undeclared: {
        heff_take_n(v_t_242186, 0ULL, 1);
        v_t_242189 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_242186);
      }
      if ((heff_dup(v_t_242189) == NTAG(TAG_True))) {
        heff_drop(v_t_242189);
        V v_t_242190 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242121));
        V v_t_242191 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 11)), 3, (V[]){heff_dup(v_env_242118), v_f_242120, v_t_242190}));
        V v_x1_242192 = ({ V a_0 = v_r_242124; V r_ = (g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a_0)); heff_drop_tag(v_r_242124, 2); r_; });
        V v_t_242193;
        if ((heff_dup(v_x1_242192) == NTAG(TAG_True))) {
          heff_drop(v_x1_242192);
          v_t_242193 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_x1_242192);
          v_t_242193 = heff_dup(g_std_2edoc_2eline_get());
        }
        V v_a_242194 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242118), v_op_242184));
        V v_b_242195 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12)), 5, (V[]){v_env_242118, v_m_242119, v_e_242185, NTAG(TAG_Nil), v_rest2_242125}));
        V v_t_242196 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str105)}), v_b_242195));
        V v_t_242197 = (g_std_2edoc_2e_3c_3e(v_a_242194, v_t_242196));
        V v_t_242198 = (g_std_2edoc_2e_3c_3e(v_t_242193, v_t_242197));
        return (g_std_2edoc_2e_3c_3e(v_t_242191, v_t_242198));
      } else {
        heff_drop_rec(v_op_242184, 9);
        heff_drop(v_e_242185);
        heff_drop(v_t_242189);
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
        args[0] = v_env_242118;
        args[1] = v_m_242119;
        args[2] = v_f_242120;
        args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
        args[4] = v_rest2_242125;
        if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 5, args);
      }
    }
    case TAG_Ann: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BVar: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BImp: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_BAnn: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Lam: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Case: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_EAlt: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_If: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_Do: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ESBind: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    case TAG_ELet: {
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 12));
      args[0] = v_env_242118;
      args[1] = v_m_242119;
      args[2] = v_f_242120;
      args[3] = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242124, v_acc_242121});
      args[4] = v_rest2_242125;
      if (heff_exact(f_, 5, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 5, args);
    }
    default: return heff_nomatch(v_r_242124);
    }
  }
  default: return heff_nomatch(v_rs_242122);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam94(V self, V *args) {
  V v_env_242239 = args[0];
  V v_a_242240 = args[1];
  switch (heff_tag_of(v_a_242240)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V v_p_242321 = heff_field(v_a_242240, 0);
    V v_arrow_242322 = heff_field(v_a_242240, 1);
    V v_body_242323 = heff_field(v_a_242240, 2);
    heff_take_n(v_a_242240, 7ULL, 3);
    V v_a_242324 = ({ V a_0 = heff_dup(v_env_242239); V a_1 = v_p_242321; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epP(a_0, a_1)); heff_drop(v_p_242321); r_; });
    V v_b_242325 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242239), v_arrow_242322));
    V v_t_242326 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str106)}), v_b_242325));
    V v_t_242327 = (g_std_2edoc_2e_3c_3e(v_a_242324, v_t_242326));
    V v_t_242328 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242239, v_body_242323}));
    return (g_std_2edoc_2e_3c_3e(v_t_242327, v_t_242328));
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242239;
    args[1] = v_a_242240;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_a_242240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam95(V self, V *args) {
  V v_env_242346 = args[0];
  V v_s_242347 = args[1];
  switch (heff_tag_of(v_s_242347)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFDefault: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V v_x_242439 = heff_field(v_s_242347, 0);
    V v_arrow_242440 = heff_field(v_s_242347, 1);
    V v_e_242441 = heff_field(v_s_242347, 2);
    heff_take_n(v_s_242347, 7ULL, 3);
    V v_a_242442 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242346), v_x_242439));
    V v_b_242443 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242346), v_arrow_242440));
    V v_t_242444 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str107)}), v_b_242443));
    V v_t_242445 = (g_std_2edoc_2e_3c_3e(v_a_242442, v_t_242444));
    V v_t_242446 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242346, v_e_242441}));
    return (g_std_2edoc_2e_3c_3e(v_t_242445, v_t_242446));
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242346;
    args[1] = v_s_242347;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_s_242347);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elay_lam96(V self, V *args) {
  V v_env_242453 = args[0];
  V v_f_242454 = args[1];
  switch (heff_tag_of(v_f_242454)) {
  case TAG_Atom: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EParen: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Named: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Tup: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Seg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Braces: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Update: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EUSet: {
    V v_x_242481 = heff_field(v_f_242454, 0);
    V v_eq_242482 = heff_field(v_f_242454, 1);
    V v_e_242483 = heff_field(v_f_242454, 2);
    heff_take_n(v_f_242454, 7ULL, 3);
    V v_a_242484 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242453), v_x_242481}));
    V v_b_242485 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242453), v_eq_242482));
    V v_t_242486 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str108)}), v_b_242485));
    V v_t_242487 = (g_std_2edoc_2e_3c_3e(v_a_242484, v_t_242486));
    V v_t_242488 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242453, v_e_242483}));
    return (g_std_2edoc_2e_3c_3e(v_t_242487, v_t_242488));
  }
  case TAG_InstB: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EFSet: {
    V v_x_242494 = heff_field(v_f_242454, 0);
    V v_eq_242495 = heff_field(v_f_242454, 1);
    V v_e_242496 = heff_field(v_f_242454, 2);
    heff_take_n(v_f_242454, 7ULL, 3);
    V v_a_242497 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242453), v_x_242494));
    V v_b_242498 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242453), v_eq_242495));
    V v_t_242499 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str109)}), v_b_242498));
    V v_t_242500 = (g_std_2edoc_2e_3c_3e(v_a_242497, v_t_242499));
    V v_t_242501 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242453, v_e_242496}));
    return (g_std_2edoc_2e_3c_3e(v_t_242500, v_t_242501));
  }
  case TAG_EFDefault: {
    V v_d_242502 = heff_field(v_f_242454, 0);
    V v_eq_242503 = heff_field(v_f_242454, 1);
    V v_e_242504 = heff_field(v_f_242454, 2);
    heff_take_n(v_f_242454, 7ULL, 3);
    V v_a_242505 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_242453), v_d_242502}));
    V v_b_242506 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_242453), v_eq_242503));
    V v_t_242507 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2elay_str110)}), v_b_242506));
    V v_t_242508 = (g_std_2edoc_2e_3c_3e(v_a_242505, v_t_242507));
    V v_t_242509 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 1)), 2, (V[]){v_env_242453, v_e_242504}));
    return (g_std_2edoc_2e_3c_3e(v_t_242508, v_t_242509));
  }
  case TAG_Sum: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ECon: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EField: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ENeg: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_App: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Op: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ops: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_OpRhs: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Ann: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BVar: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BImp: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_BAnn: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Lam: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Case: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_EAlt: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_If: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Do: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ESBind: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_ELet: {
    V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0));
    args[0] = v_env_242453;
    args[1] = v_f_242454;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_f_242454);
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1, 1, " ");
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_env_240);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkDAlts: {
      V v_eq_243 = heff_field(v_x21_242, 0);
      V v_x212_244 = heff_field(v_x21_242, 1);
      V v_bars_245 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_Nil: {
        heff_drop(v_env_240);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        heff_drop_rec(v_eq_243, 9);
        heff_drop(v_bars_245);
        return heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
      case TAG_Cons: {
        V v_a1_246 = heff_field(v_x212_244, 0);
        V v_more_247 = heff_field(v_x212_244, 1);
        heff_take_n(v_x212_244, 3ULL, 2);
        V v_t_248 = heff_dup(heff_rfield(v_eq_243, 6));
        V v_t_2410;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
        } else {
          heff_drop(v_t_248);
          V v_t_249 = (g_list_2eany_24s1092144743x1559898298(v_bars_245));
          if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2ehardline_get());
          } else {
            heff_drop(v_t_249);
            v_t_2410 = heff_dup(g_std_2edoc_2eline_get());
          }
        }
        V v_a_2411 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), heff_dup(v_eq_243)));
        V v_b_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){heff_dup(v_env_240), v_a1_246}));
        V v_t_2413 = (g_std_2edoc_2e_3c_3e(heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str0)}), v_b_2412));
        V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_a_2411, v_t_2413));
        V v_t_2424 = ({ V a_0 = heff_dup(g_std_2edoc_2eemptyDoc_get()); V a_1 = heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0, 2, 3, (V[]){v_eq_243, heff_dup(v_bars_245), v_env_240}); V a_2 = v_bars_245; V a_3 = v_more_247; V r_ = (g_list_2efoldl_24f1443542135x1147816397(a_0, a_1, a_2, a_3)); heff_drop(v_bars_245); heff_drop(v_more_247); r_; });
        V v_t_2425 = (g_std_2edoc_2e_3c_3e(v_t_2414, v_t_2424));
        V v_t_2426 = (g_std_2edoc_2e_3c_3e(v_t_2410, v_t_2425));
        return (g_std_2edoc_2egroup(v_t_2426));
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc(a[0], a[1]);
}
V g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_lam0(V self, V *args) {
  V v_bar_2415 = args[0];
  V v_a_2416 = args[1];
  V v_eq_243 = heff_env(self)[0];
  V v_bars_245 = heff_env(self)[1];
  V v_env_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_get_n(v_eq_243, 6, 9);
  V v_t_2419;
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop(v_bars_245);
    heff_drop(v_t_2417);
    v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
  } else {
    heff_drop(v_t_2417);
    V v_t_2418 = ({ V a_0 = v_bars_245; V r_ = (g_list_2eany_24s1092144743x1559898298(a_0)); heff_drop(v_bars_245); r_; });
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2ehardline_get());
    } else {
      heff_drop(v_t_2418);
      v_t_2419 = heff_dup(g_std_2edoc_2eline_get());
    }
  }
  V v_a_2420 = (g_heff_2esyntax_2efmt_2elayout_2etok(heff_dup(v_env_240), v_bar_2415));
  V v_b_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2esyntax_2efmt_2elayout_2elay_get(), 0)), 2, (V[]){v_env_240, v_a_2416}));
  V v_t_2422 = (g_std_2edoc_2e_3c_3e(heff_tag_n(TAG_Text, 1, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2edataAltsDoc_str1)}), v_b_2421));
  V v_t_2423 = (g_std_2edoc_2e_3c_3e(v_a_2420, v_t_2422));
  return (g_std_2edoc_2e_3c_3e(v_t_2419, v_t_2423));
}
Clo g_heff_2esyntax_2efmt_2elayout_2edeclSep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2edeclSep(V v_env_240, V v_i_241, V v_d_242) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), v_i_241)) {
    V v_t_244 = (g_heff_2esyntax_2ecst_2efirstD(v_d_242));
    HeffT2 v_t_245 = ({ V a_0 = heff_take_field(v_t_244, 7); V b_1 = heff_get_n(v_env_240, 1, 7); HeffT2 r_ = (g_map_2elookup_24s567992785x1569911877_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2413;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2412;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2412 = heff_get_n(v_t_244, 8, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_x_249, 0);
          heff_take_n(v_x_249, 1ULL, 2);
          heff_drop_rec(v_t_244, 9);
          v_t_2412 = heff_get_n(v_x_2410, 1, 2);
          break;
        }
        default: heff_nomatch(v_x_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2412 = heff_get_n(v_t_244, 8, 9);
      }
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_dup(g_std_2edoc_2eemptyDoc_get());
      }
    }
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2413));
  } else {
    heff_drop_rec(v_env_240, 7);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edeclSep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2edeclSep(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2edefName_str13, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2edefName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2edefName_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2edefName(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_DImport: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str0);
  }
  case TAG_DFixity: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str1);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_d_240, 0);
    V v_x2_247 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_244)));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str2);
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DInstance: {
    V v_n_2411 = heff_field(v_d_240, 1);
    V v_x2_2414 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2411)));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str4);
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str5); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  case TAG_DEqn: {
    V v_n_2417 = heff_field(v_d_240, 0);
    V v_x2_2422 = (g_list_2emap_24s759871588x920431471(heff_dup(v_n_2417)));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str6);
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str7); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  case TAG_DData: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str8);
  }
  case TAG_DType: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str9);
  }
  case TAG_DTheory: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str10);
  }
  case TAG_DPrimitive: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str11);
  }
  case TAG_DTest: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str12);
  }
  case TAG_DWatch: {
    return ((V)&g_heff_2esyntax_2efmt_2elayout_2edefName_str13);
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2edefName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2edefName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0, 7, "doctest");
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry, 4, 0};

V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V v_env_240, V v_i_241, V v_above_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_i_241);
    heff_drop(v_above_242);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2edeclSep(heff_dup(v_env_240), heff_dup(v_i_241), v_d_244));
    V v_t_2445;
    switch (heff_tag_of(v_d_244)) {
    case TAG_DImport: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DFixity: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DSig: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DInstance: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DEqn: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DData: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DType: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTheory: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DPrimitive: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DTest: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_DWatch: {
      V v_w_2443 = heff_dup(heff_field(v_d_244, 0));
      v_t_2445 = heff_strEq(heff_get_n(v_w_2443, 0, 9), ((V)&g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_str0));
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_t_2466;
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
      V v_t_2447 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
      V v_t_2449 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2446, v_t_2447, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0, 1, 1, (V[]){heff_dup(v_d_244)})));
      V v_t_2450 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); heff_drop(v_d_244); r_; });
      V v_t_2451 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_t_2450, v_ds_245));
      v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2449, v_t_2451));
    } else {
      heff_drop(v_t_2445);
      V v_t_2452 = ({ V a_0 = heff_dup(v_env_240); V a_1 = v_above_242; V a_2 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eskipped(a_0, a_1, a_2)); heff_drop(v_above_242); r_; });
      if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
        heff_drop(v_t_2452);
        V v_t_2453 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2454 = (g_heff_2esyntax_2efmt_2elayout_2edefName(v_d_244));
        V v_t_2455 = (g_heff_2esyntax_2efmt_2elayout_2edefLast(v_t_2454, heff_dup(v_d_244), v_ds_245));
        V v_t_2456 = (g_heff_2esyntax_2ecst_2elastD(v_t_2455));
        V v_t_2457 = (g_heff_2esyntax_2efmt_2elayout_2easWritten(heff_dup(v_env_240), v_t_2453, v_t_2456));
        V v_t_2458 = ({ V a_0 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2edefName(a_0)); heff_drop(v_d_244); r_; });
        V v_t_2459 = (g_heff_2esyntax_2efmt_2elayout_2eafterDef(v_t_2458, v_ds_245));
        V v_t_2460 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_t_2459));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2457, v_t_2460));
      } else {
        heff_drop(v_t_2452);
        V v_t_2461 = (g_heff_2esyntax_2ecst_2efirstD(v_d_244));
        V v_t_2462 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_244)));
        V v_t_2464 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2461, v_t_2462, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1, 1, 1, (V[]){v_d_244})));
        V v_t_2465 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), NTAG(TAG_False), v_ds_245));
        v_t_2466 = (g_std_2edoc_2e_3c_3e(v_t_2464, v_t_2465));
      }
    }
    return (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2466));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam0(V self, V *args) {
  V v_e_2448 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2448; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_lam1(V self, V *args) {
  V v_e_2463 = args[0];
  V v_d_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2463; V a_1 = v_d_244; V r_ = (g_heff_2esyntax_2efmt_2elayout_2epD(a_0, a_1)); heff_drop(v_d_244); r_; });
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str2, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str6, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2erender2_str7, 1, "\012");
Clo g_heff_2esyntax_2efmt_2elayout_2erender2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2erender2_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2erender2(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_240}), NTAG(TAG_Nil)});
  V v_s_242 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_241));
  V v_s_243 = (g_std_2edoc_2edisplayInto(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str0), v_s_242));
  V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str1), heff_dup(v_s_243), MK_INT(0LL), heff_strFind(((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str2), v_s_243, MK_INT(0LL)), NTAG(TAG_Nil)));
  V v_t_245 = (g_list_2emap_24s725725455x1186198702(v_t_244));
  V v_x2_246 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_245));
  V v_s_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_s_249 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_s_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x2_2411;
  if ((heff_unbox_word(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()))) == ((int64_t)0ULL))) {
    v_x2_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_s_249, NTAG(TAG_Nil)});
  } else {
    v_x2_2411 = (g_prelude_2esplitFrom(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), heff_dup(v_s_249), MK_INT(0LL), heff_strFind(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), v_s_249, MK_INT(0LL)), NTAG(TAG_Nil)));
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str6); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2erender2_str7));
}
V g_heff_2esyntax_2efmt_2elayout_2erender2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2erender2(a[0]);
}

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtParsed_24cpr(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_e_242 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_at_240, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_e_242)}});
  }
  case TAG_Right: {
    V v_ds_243 = heff_field(v_x2_241, 0);
    V v_env_244 = heff_take_field(v_at_240, 1);
    V v_eof_245 = (g_heff_2esyntax_2efmt_2elayout_2eeofOf(heff_get_n(v_at_240, 0, 2)));
    V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(heff_dup(v_env_244), MK_INT(0LL), NTAG(TAG_False), heff_dup(v_ds_243)));
    HeffT2 v_t_247 = (g_map_2elookup_24s567992785x1569911877_24cpr(heff_get_n(v_eof_245, 7, 9), heff_rfield(v_env_244, 1)));
    V v_t_2412;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_249;
        v_t_2412 = v_x_2411;
      } else {
        heff_drop(v_field_249);
        v_t_2412 = NTAG(TAG_Nil);
      }
    }
    V v_t_2413 = ({ V a_0 = v_env_244; V a_1 = v_t_2412; V r_ = (g_heff_2esyntax_2efmt_2elayout_2eeofLeadDocs(a_0, a_1)); heff_drop_rec(v_env_244, 7); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_std_2edoc_2e_3c_3e(v_t_246, v_t_2413));
    V v_f_2415 = (g_heff_2esyntax_2efmt_2elayout_2erender2(v_t_2414));
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2415}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V v_f_240, V v_src_241, V v_hdr_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_244, 0ULL, 2);
    v_t_247 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_f_240);
    heff_drop(v_src_241);
    heff_drop_rec(v_hdr_242, 2);
    heff_drop_rec(v_l_243, 3);
    heff_drop(v_t_247);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr_str0)}});
  } else {
    heff_drop(v_t_247);
    V v_t_248 = (g_prelude_2e_2b_2b_24f201610143x1454021782(heff_take_field(v_l_243, 0), heff_get_n(v_hdr_242, 0, 2)));
    V v_t_249 = (g_list_2esortBy_24s88152486x2058486153(v_t_248));
    HeffT2 v_t_2410 = (g_heff_2esyntax_2efmt_2etokens_2eattach_24cpr(v_src_241, v_t_249, heff_get_n(v_l_243, 2, 3)));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_t_2413 = ({ V rv_6 = v_f_240; V rr_ = heff_rec_reuse_nf(v_field_2412, 63ULL, 7, shape_src__lead__inline__trail__noLead__noTrail__fix, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      V v_at_2414 = heff_rec_n(2, shape_toks__env, (V[]){v_field_2411, v_t_2413});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      V v_t_2416 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_at_2414, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2415, MK_INT(0LL)});
      V v_t_2417 = (g_heff_2esyntax_2ecst_2eprogramGo(v_t_2416, NTAG(TAG_Nil)));
      return ({ V a_0 = v_at_2414; V a_1 = v_t_2417; HeffT2 r_ = (g_heff_2esyntax_2efmt_2elayout_2efmtParsed_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
    }
  }
}