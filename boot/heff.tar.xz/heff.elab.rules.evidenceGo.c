// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_clo;
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_str0, 2, "`(");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_str1, 51, " := _)` names an argument, but there is none named ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_str2, 5, " here");
Clo g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_entry, 4, 0};

V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(V v_sp_240, V v_x_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_str0), heff_dup(v_x_241)), ((V)&g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_str1));
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, v_x_241), ((V)&g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_str2));
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_t_247, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2410}));
  return heff_tail(v_bind_244, 2, (V[]){v_t_2411, v_k2_243});
}
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(a[0], a[1], a[2], a[3]);
}