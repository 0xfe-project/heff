// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Delay 58579
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Left 13886
#define TAG_MkDelayed 26976
#define TAG_MkSaved 51533
#define TAG_MkSt 48854
#define TAG_MkWanted 40078
#define TAG_Pending 60181
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_Resolve 2188
#define TAG_RestoreDelayed 1107
#define TAG_RestoreWaiting 10254
#define TAG_Right 62770
#define TAG_SaveDelayed 42463
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define TAG_Want 10361
#define LBL_bind 9519364
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_left 9813198
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_trace 311979359
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2eelab_2emeta_2ealg2(V, V);
V g_heff_2eelab_2emeta_2ealg2_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2ealg2_clo;
V g_heff_2eelab_2emeta_2eanyDelayed(V, V);
V g_heff_2eelab_2emeta_2eanyDelayed_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eanyDelayed_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedFlex(V, V);
V g_heff_2eelab_2emeta_2eblockedFlex_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedFlex_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2edeferAlg(V, V);
V g_heff_2eelab_2emeta_2edeferAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2edeferAlg_clo;
V g_heff_2eelab_2emeta_2edelayedReady(V, V, V);
V g_heff_2eelab_2emeta_2edelayedReady_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2edelayedReady_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2ekeepFailed(V, V, V, V);
V g_heff_2eelab_2emeta_2ekeepFailed_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2ekeepFailed_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2enotesAlg(V, V);
V g_heff_2eelab_2emeta_2enotesAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2enotesAlg_clo;
V g_heff_2eelab_2emeta_2eresolveKept(V);
V g_heff_2eelab_2emeta_2eresolveKept_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eresolveKept_clo;
V g_heff_2eelab_2emeta_2eresolveKept_24dps(V, V);
V g_heff_2eelab_2emeta_2eresolveKept_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eresolveKept_24dps_clo;
V g_heff_2eelab_2emeta_2eresolveListS(V, V, V);
V g_heff_2eelab_2emeta_2eresolveListS_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eresolveListS_clo;
V g_heff_2eelab_2emeta_2eresolveS(V, V);
V g_heff_2eelab_2emeta_2eresolveS_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eresolveS_clo;
V g_heff_2eelab_2emeta_2eretryEach(V, V);
V g_heff_2eelab_2emeta_2eretryEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eretryEach_clo;
V g_heff_2eelab_2emeta_2eretryGo(V, V, V, V);
V g_heff_2eelab_2emeta_2eretryGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eretryGo_clo;
V g_heff_2eelab_2emeta_2erunEachS(V, V);
V g_heff_2eelab_2emeta_2erunEachS_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2erunEachS_clo;
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2emeta_2eundoIfFailed(V, V, V, V, V);
V g_heff_2eelab_2emeta_2eundoIfFailed_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eundoIfFailed_clo;
V g_heff_2eelab_2emeta_2eundoTo(V, V);
V g_heff_2eelab_2emeta_2eundoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eundoTo_clo;
V g_heff_2eelab_2emeta_2ewakeS(V, V);
V g_heff_2eelab_2emeta_2ewakeS_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2ewakeS_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void);
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2elookup_24s1338854231x236594845(V, V);
V g_map_2elookup_24s1338854231x236594845_entry(V self, V *a);
extern Clo g_map_2elookup_24s1338854231x236594845_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2eelab_2emeta_2eliftU_lam1(V self, V *args); static Clo g_heff_2eelab_2emeta_2eliftU_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eliftU_lam1, 2, 0};
V g_heff_2eelab_2emeta_2eliftU_lam0(V self, V *args);
V g_heff_2eelab_2emeta_2eliftU_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eliftU_lam2(V self, V *args);
Clo g_heff_2eelab_2emeta_2eliftU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eliftU_entry, 3, 0};

V g_heff_2eelab_2emeta_2eliftU(V v_u_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eliftU_lam0, 1, 1, (V[]){v_u_240})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2emeta_2eliftU_lam2, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eliftU(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eliftU_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_c_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_244}), v_c_245});
}
V g_heff_2eelab_2emeta_2eliftU_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_u_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_u_240;
  heff_room[0] = heff_dup(g_heff_2eelab_2eunify_2euH_get());
  heff_room[1] = ((V)&g_heff_2eelab_2emeta_2eliftU_lam1_clo);
  heff_room[2] = v_c_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2emeta_2eliftU_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_r_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_242;
  args[0] = v_r_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2eliftU_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_r_2410 = heff_field(v_x_249, 0);
    V v_c2_2411 = heff_field(v_x_249, 1);
    V v_ru_24x_249_24MkPair = heff_take_reuse_n(v_x_249, 3ULL, 2);
    V v_t_2412 = heff_tag_at_n(v_ru_24x_249_24MkPair, TAG_Put, 2, (V[]){v_c2_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eliftU_lam3, 1, 2, (V[]){v_k_242, v_r_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_249);
  }
}
Clo g_heff_2eelab_2emeta_2eblockedFlex_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eblockedFlex_entry, 2, 0};

V g_heff_2eelab_2emeta_2eblockedFlex(V v_ps_240, V v_a_241) {
top: ;
  V v_it_2423;
  switch (heff_tag_of(v_a_241)) {
  case TAG_VU: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    V v_t1_243 = heff_field(v_a_241, 0);
    V v_sp_244 = heff_field(v_a_241, 1);
    switch (heff_tag_of(v_t1_243)) {
    case TAG_HLocal: {
      v_it_2423 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_HGlobal: {
      v_it_2423 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_t1_243, 0);
      v_it_2423 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_m_2410), heff_dup(v_sp_244)})});
      break;
    }
    case TAG_HError: {
      v_it_2423 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t1_243);
    }
    break;
  }
  case TAG_VFunction: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VRecord: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_it_2423 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_a_241);
  }
  switch (heff_tag_of(v_it_2423)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_2424 = heff_field(v_it_2423, 0);
    heff_take_n(v_it_2423, 1ULL, 1);
    switch (heff_tag_of(v_it1_2424)) {
    case TAG_MkPair: {
      V v_m_2425 = heff_field(v_it1_2424, 0);
      heff_take_n(v_it1_2424, 1ULL, 2);
      V v_x3_2427 = (g_map_2elookup_24s1338854231x236594845(v_m_2425, v_ps_240));
      switch (heff_tag_of(v_x3_2427)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take_n(v_x3_2427, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x3_2427);
      }
    }
    default: return heff_nomatch(v_it1_2424);
    }
  }
  default: return heff_nomatch(v_it_2423);
  }
}
V g_heff_2eelab_2emeta_2eblockedFlex_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2emeta_2eblockedFlex(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2emeta_2eblockedTy_lam0(V self, V *args);
V g_heff_2eelab_2emeta_2eblockedTy_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eblockedTy_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eblockedTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eblockedTy_entry, 3, 0};

V g_heff_2eelab_2emeta_2eblockedTy(V v_a0_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eblockedTy_lam0, 1, 1, (V[]){v_a0_240})})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2emeta_2eblockedTy_lam1, 1, 2, (V[]){v_hd_241, v_k_242})});
}
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eblockedTy(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eblockedTy_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_a0_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_243, 3, 8); V a_1 = v_a0_240; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2emeta_2eblockedTy_lam2(V self, V *args) {
  V v_c_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_x_247)) {
  case TAG_VU: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2410 = heff_dup(heff_field(v_x_247, 0));
    switch (heff_tag_of(v_h_2410)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2410, 0ULL, 1);
      v_t_2430 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2410, 0ULL, 1);
      v_t_2430 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2410, 0ULL, 1);
      v_t_2430 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2430 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2410);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop_rec(v_c_248, 8);
    heff_drop(v_x_247);
    heff_drop(v_t_2430);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2430);
    return ({ V b_0 = heff_get_n(v_c_248, 2, 8); V a_1 = v_x_247; V r_ = (g_heff_2eelab_2emeta_2eblockedFlex(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_247); r_; });
  }
}
V g_heff_2eelab_2emeta_2eblockedTy_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eblockedTy_lam2, 1, 1, (V[]){v_x_247})})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2432}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2433;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2ekeepFailed_lam0(V self, V *args);
V g_heff_2eelab_2emeta_2ekeepFailed_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2ekeepFailed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2ekeepFailed_entry, 4, 0};

V g_heff_2eelab_2emeta_2ekeepFailed(V v_p_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Left: {
    V v_ru_24x2_241_24Left = heff_take_reuse_n(v_x2_241, 0ULL, 1);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2ekeepFailed_lam0, 1, 1, (V[]){v_p_240})})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){v_t_249}));
    return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2emeta_2ekeepFailed_lam1, 1, 2, (V[]){v_p_242, v_p_243})});
  }
  case TAG_Right: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_p_240, 4);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2ekeepFailed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2ekeepFailed(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2emeta_2ekeepFailed_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_p_240, 7ULL, 4, shape_shape__left__right__failed, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_take_field(v_c_245, 5)});
  return ({ V rv_5 = v_t_247; V rr_ = heff_rec_reuse_nf(v_c_245, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2emeta_2ekeepFailed_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})}));
  V f_ = heff_get_n(v_p_242, 1, 3);
  heff_room[0] = v_t_2414;
  heff_room[1] = v_p_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2emeta_2eundoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eundoTo_entry, 2, 0};

V g_heff_2eelab_2emeta_2eundoTo(V v_before_240, V v_c_241) {
top: ;
  V v_c_242 = ({ V rv_3 = heff_take_field(v_before_240, 3); V rv_4 = heff_take_field(v_before_240, 4); V rr_ = heff_rec_reuse_nf(v_c_241, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  return ({ V rv_5 = heff_get_n(v_before_240, 5, 8); V rr_ = heff_rec_reuse_nf(v_c_242, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2emeta_2eundoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eundoTo(a[0], a[1]);
}
V g_heff_2eelab_2emeta_2eundoIfFailed_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eundoIfFailed_lam1(V self, V *args);
V g_heff_2eelab_2emeta_2eundoIfFailed_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2eundoIfFailed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eundoIfFailed_entry, 5, 0};

V g_heff_2eelab_2emeta_2eundoIfFailed(V v_before_240, V v_waiting_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Left: {
    V v_err_245 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Left = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2eundoTo_clo), 1, (V[]){v_before_240}));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_248}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2emeta_2eundoIfFailed_lam0, 1, 4, (V[]){v_p_243, v_waiting_241, v_p_244, v_err_245})});
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    heff_drop(v_before_240);
    heff_drop(v_waiting_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2419})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2emeta_2eundoIfFailed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eundoIfFailed(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2emeta_2eundoIfFailed_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_err_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V f_ = v_p_244;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2eundoIfFailed_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_waiting_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_err_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_waiting_241, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_p_243, 1, 3);
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eundoIfFailed_lam2, 1, 2, (V[]){v_p_244, v_err_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eundoIfFailed_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_waiting_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_err_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})}));
  V f_ = heff_dup(heff_rfield(v_p_243, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eundoIfFailed_lam1, 1, 4, (V[]){v_waiting_241, v_p_243, v_p_244, v_err_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eattempt_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eattempt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eattempt_lam0, 1, 0};
V g_heff_2eelab_2emeta_2eattempt_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2eattempt_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eattempt_lam2, 1, 0};
V g_heff_2eelab_2emeta_2eattempt_lam4(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eattempt_entry, 3, 0};

V g_heff_2eelab_2emeta_2eattempt(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eattempt_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam1, 1, 3, (V[]){v_hd_241, v_m_240, v_k_242})});
}
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eattempt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eattempt_lam0(V self, V *args) {
  V v_c_243 = args[0];
  return v_c_243;
}
V g_heff_2eelab_2emeta_2eattempt_lam2(V self, V *args) {
  V v_sv_248 = args[0];
  return v_sv_248;
}
V g_heff_2eelab_2emeta_2eattempt_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2eundoIfFailed(v_x_247, v_x_2411, v_x_2412, v_hd_241, v_k_242));
}
V g_heff_2eelab_2emeta_2eattempt_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_m_240;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam4, 1, 4, (V[]){v_x_247, v_x_2411, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eattempt_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eattempt_lam2_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam3, 1, 4, (V[]){v_m_240, v_hd_241, v_x_247, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryEach_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryEach_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryEach_lam0, 2, 0};
V g_heff_2eelab_2emeta_2eretryEach_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eretryEach_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eretryEach_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eretryEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryEach_entry, 2, 0};

V g_heff_2eelab_2emeta_2eretryEach(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2emeta_2eretryEach_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), heff_dup(v_g_240), heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_dup(heff_rfield(v_p_244, 2))));
    return heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam1, 2, 4, (V[]){v_t_246, heff_dup(v_p_244), v_g_240, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2eretryEach_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2emeta_2eretryEach(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2emeta_2eretryEach_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2eretryEach_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2411);
  V v_t_2412 = ({ V a_0 = v_g_240; V a_1 = v_rest_245; V r_ = (g_heff_2eelab_2emeta_2eretryEach(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2412;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryEach_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2emeta_2ekeepFailed(v_p_244, v_x_2410, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam3, 1, 4, (V[]){v_g_240, v_rest_245, v_hd_247, v_k_248})));
}
V g_heff_2eelab_2emeta_2eretryEach_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_246}));
  return (g_heff_2eelab_2emeta_2eattempt(v_t_249, heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam2, 1, 5, (V[]){v_p_244, v_hd_247, v_g_240, v_rest_245, v_k_248})));
}
V g_heff_2eelab_2emeta_2eretryGo_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_lam0, 1, 0};
V g_heff_2eelab_2emeta_2eretryGo_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_lam2, 1, 0};
V g_heff_2eelab_2emeta_2eretryGo_lam6(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryGo_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_lam6, 1, 0};
V g_heff_2eelab_2emeta_2eretryGo_lam7(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam5(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam4(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eretryGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_entry, 4, 0};

V g_heff_2eelab_2emeta_2eretryGo(V v_g_240, V v_fuel_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eretryGo_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam1, 1, 4, (V[]){v_hd_242, v_g_240, v_k_243, v_fuel_241})});
}
V g_heff_2eelab_2emeta_2eretryGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eretryGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2emeta_2eretryGo_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_244, 5, 8)));
}
V g_heff_2eelab_2emeta_2eretryGo_lam2(V self, V *args) {
  V v_c_249 = args[0];
  return ({ V rv_5 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_c_249, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2emeta_2eretryGo_lam6(V self, V *args) {
  V v_c_2420 = args[0];
  return heff_get_n(v_c_2420, 5, 8);
}
V g_heff_2eelab_2emeta_2eretryGo_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_x_2424));
  if (heff_intEq_c(v_t_2425, MK_INT(0LL))) {
    heff_drop(v_x_248);
    heff_drop(v_fuel_241);
    heff_drop(v_g_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2424));
    V f_ = v_k_243;
    args[0] = v_x_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2428 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_x_2424));
    V v_t_2429 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
    if (heff_intEq_c(v_t_2428, v_t_2429)) {
      heff_drop(v_fuel_241);
      heff_drop(v_g_240);
      heff_drop_rec(v_hd_242, 3);
      V v_x_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2424));
      V f_ = v_k_243;
      args[0] = v_x_2431;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      if (heff_intLt_c(MK_INT(50LL), heff_dup(v_fuel_241))) {
        heff_drop(v_fuel_241);
        heff_drop(v_g_240);
        heff_drop_rec(v_hd_242, 3);
        V v_x_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2424));
        V f_ = v_k_243;
        args[0] = v_x_2433;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2424);
        return (g_heff_2eelab_2emeta_2eretryGo(v_g_240, heff_intAdd(v_fuel_241, MK_INT(1LL)), v_hd_242, v_k_243));
      }
    }
  }
}
V g_heff_2eelab_2emeta_2eretryGo_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2419);
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eretryGo_lam6_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2422}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam7, 1, 5, (V[]){v_k_243, v_x_248, v_fuel_241, v_g_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryGo_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_fuel_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  V v_c_2418 = (g_heff_2eelab_2emeta_2eretryEach(heff_dup(v_g_240), v_x_248));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam5, 1, 5, (V[]){v_hd_242, v_k_243, v_x_248, v_fuel_241, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryGo_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_fuel_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam4, 1, 5, (V[]){v_g_240, v_x_248, v_hd_242, v_k_243, v_fuel_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eretryGo_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam3, 1, 5, (V[]){v_hd_242, v_g_240, v_x_248, v_k_243, v_fuel_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2emeta_2edelayedReady_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2edelayedReady_entry, 3, 0};

V g_heff_2eelab_2emeta_2edelayedReady(V v_mc_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkDelayed: {
    V v_ty_243 = heff_field(v_x3_242, 0);
    if ((heff_dup(v_all_241) == NTAG(TAG_True))) {
      return NTAG(TAG_True);
    } else {
      V v_t_245 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, heff_dup(v_ty_243)));
      V v_x1_2427;
      switch (heff_tag_of(v_t_245)) {
      case TAG_VU: {
        heff_take_n(v_t_245, 0ULL, 1);
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_247 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 5);
        switch (heff_tag_of(v_t1_247)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_247, 0ULL, 1);
          v_x1_2427 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_247, 0ULL, 1);
          v_x1_2427 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_247, 0ULL, 1);
          v_x1_2427 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_x1_2427 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_247);
        }
        break;
      }
      case TAG_VFunction: {
        heff_take_n(v_t_245, 0ULL, 5);
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        heff_take_n(v_t_245, 0ULL, 4);
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        heff_take_n(v_t_245, 0ULL, 1);
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        heff_take_n(v_t_245, 0ULL, 1);
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        heff_take_n(v_t_245, 0ULL, 1);
        v_x1_2427 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2427) == NTAG(TAG_True)));
      heff_drop(v_x1_2427);
      return v_ret_24bool;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2emeta_2edelayedReady_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2emeta_2edelayedReady(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2emeta_2eanyDelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eanyDelayed_entry, 2, 0};

V g_heff_2eelab_2emeta_2eanyDelayed(V v_mc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = ({ V a_0 = v_mc_240; V b_1 = NTAG(TAG_False); V a_2 = v_d_242; V r_ = (g_heff_2eelab_2emeta_2edelayedReady(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_mc_240;
      V t_1 = v_rest_243;
      v_mc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2eanyDelayed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2emeta_2eanyDelayed(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2emeta_2eresolveKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eresolveKept_entry, 1, 0};

V g_heff_2eelab_2emeta_2eresolveKept(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      V v_x112_244 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      if ((heff_dup(v_x111_243) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x111_243);
        heff_drop(v_x112_244);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      } else {
        heff_drop(v_x111_243);
        V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x112_244, heff_hole()});
        V v_u_246 = (g_heff_2eelab_2emeta_2eresolveKept_24dps(v_rest_242, heff_dup(v_cell_245)));
        heff_drop(v_u_246);
        return v_cell_245;
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2eresolveKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eresolveKept(a[0]);
}
Clo g_heff_2eelab_2emeta_2eresolveKept_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eresolveKept_24dps_entry, 2, 0};

V g_heff_2eelab_2emeta_2eresolveKept_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x111_244 = heff_field(v_x11_242, 0);
      V v_x112_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      if ((heff_dup(v_x111_244) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x111_244);
        heff_drop(v_x112_245);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        heff_drop(v_x111_244);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x112_245, heff_hole()});
        V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
        heff_drop(v_u_247);
        V t_0 = v_rest_243;
        V t_1 = v_cell_246;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2eresolveKept_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eresolveKept_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2emeta_2erunEachS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2erunEachS_entry, 2, 0};

V g_heff_2eelab_2emeta_2erunEachS(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkDelayed: {
      V v_chk_246 = heff_field(v_x11_243, 1);
      heff_take_n(v_x11_243, 2ULL, 2);
      V v_x1_247 = heff_tr(heff_call(v_chk_246, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_MkPair: {
        V v_x11_248 = heff_field(v_x1_247, 0);
        V v_st_249 = heff_field(v_x1_247, 1);
        heff_take_n(v_x1_247, 3ULL, 2);
        switch (heff_tag_of(v_x11_248)) {
        case TAG_Left: {
          V v_e_2410 = heff_field(v_x11_248, 0);
          heff_take_n(v_x11_248, 1ULL, 1);
          heff_drop(v_rest_244);
          return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
        }
        case TAG_Right: {
          heff_take_n(v_x11_248, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          V t_0 = v_rest_244;
          V t_1 = v_st_249;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x11_248);
        }
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2erunEachS_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2erunEachS(a[0], a[1]);
}
V g_heff_2eelab_2emeta_2ewakeS_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2ewakeS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2ewakeS_entry, 2, 0};

V g_heff_2eelab_2emeta_2ewakeS(V v_all_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2edelayedReady_clo), 2, (V[]){heff_get_n(v_t_245, 3, 8), heff_dup(v_all_240)}));
  V v_t_2410;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_d_248 = heff_dup(heff_field(v_st_241, 1));
    v_t_2410 = v_d_248;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_x1_2411 = (g_list_2efilter(v_t_246, v_t_2410));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nil: {
    v_t_2414 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2411, 0ULL, 2);
    v_t_2414 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_all_240);
    heff_drop(v_t_2414);
    V v_t_2415 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_st_241});
  } else {
    heff_drop(v_t_2414);
    V v_t_2419;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_c_2416 = heff_dup(heff_field(v_st_241, 0));
      v_t_2419 = v_c_2416;
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2edelayedReady_clo), 2, (V[]){heff_get_n(v_t_2419, 3, 8), heff_dup(v_all_240)}));
    V v_t_2424;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_d_2422 = heff_dup(heff_field(v_st_241, 1));
      v_t_2424 = v_d_2422;
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_t_2425 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), v_t_2420, v_t_2424));
    V v_t_2436;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_c_2426 = heff_dup(heff_field(v_st_241, 0));
      V v_d_2427 = heff_dup(heff_field(v_st_241, 1));
      V v_w_2428 = heff_dup(heff_field(v_st_241, 2));
      V v_t_2435 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2emeta_2ewakeS_lam0, 1, 2, (V[]){v_st_241, heff_dup(v_all_240)}), v_d_2427));
      v_t_2436 = heff_tag_n(TAG_MkSt, 3, (V[]){v_c_2426, v_t_2435, v_w_2428});
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_x1_2437 = (g_heff_2eelab_2emeta_2erunEachS(v_t_2425, v_t_2436));
    switch (heff_tag_of(v_x1_2437)) {
    case TAG_MkPair: {
      V v_x11_2438 = heff_field(v_x1_2437, 0);
      V v_st_2439 = heff_field(v_x1_2437, 1);
      V v_ru_24x1_2437_24MkPair = heff_take_reuse_n(v_x1_2437, 3ULL, 2);
      switch (heff_tag_of(v_x11_2438)) {
      case TAG_Left: {
        V v_e_2440 = heff_field(v_x11_2438, 0);
        heff_take_n(v_x11_2438, 1ULL, 1);
        heff_drop(v_all_240);
        return heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
      }
      case TAG_Right: {
        heff_take_n(v_x11_2438, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_2437_24MkPair, 2);
        V t_0 = v_all_240;
        V t_1 = v_st_2439;
        v_all_240 = t_0;
        v_st_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x11_2438);
      }
    }
    default: return heff_nomatch(v_x1_2437);
    }
  }
}
V g_heff_2eelab_2emeta_2ewakeS_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2ewakeS(a[0], a[1]);
}
V g_heff_2eelab_2emeta_2ewakeS_lam0(V self, V *args) {
  V v_d_2429 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_all_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_2430 = heff_field(v_st_241, 0);
    heff_take_n(v_st_241, 1ULL, 3);
    v_t_2433 = v_c_2430;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_x1_2434 = ({ V b_0 = heff_get_n(v_t_2433, 3, 8); V a_1 = v_all_240; V a_2 = v_d_2429; V r_ = (g_heff_2eelab_2emeta_2edelayedReady(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_all_240); heff_drop(v_d_2429); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2434) == NTAG(TAG_True)));
  heff_drop(v_x1_2434);
  return v_ret_24bool;
}
Clo g_heff_2eelab_2emeta_2eresolveListS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eresolveListS_entry, 3, 0};

V g_heff_2eelab_2emeta_2eresolveListS(V v_final_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_final_240);
    V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkWanted: {
      V v_sp_246 = heff_field(v_x21_244, 0);
      V v_f_247 = heff_field(v_x21_244, 1);
      V v_ru_24x21_244_24MkWanted = heff_take_reuse_n(v_x21_244, 3ULL, 2);
      V v_x1_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){heff_dup(v_final_240), v_p_242}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x11_249 = heff_field(v_x1_248, 0);
        V v_st_2410 = heff_field(v_x1_248, 1);
        V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
        switch (heff_tag_of(v_x11_249)) {
        case TAG_Left: {
          V v_e_2411 = heff_field(v_x11_249, 0);
          heff_take_n(v_x11_249, 1ULL, 1);
          heff_drop(v_final_240);
          heff_drop(v_rest_245);
          heff_drop(v_sp_246);
          heff_drop(v_f_247);
          heff_drop_cell(v_ru_24x21_244_24MkWanted, 2);
          heff_drop_cell(v_ru_24x1_248_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
        }
        case TAG_Right: {
          V v_x_2412 = heff_field(v_x11_249, 0);
          V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
          V v_x1_2413 = (g_heff_2eelab_2emeta_2eresolveListS(v_final_240, v_rest_245, v_st_2410));
          switch (heff_tag_of(v_x1_2413)) {
          case TAG_MkPair: {
            V v_x11_2414 = heff_field(v_x1_2413, 0);
            V v_st_2415 = heff_field(v_x1_2413, 1);
            heff_take_n(v_x1_2413, 3ULL, 2);
            switch (heff_tag_of(v_x11_2414)) {
            case TAG_Left: {
              V v_e_2416 = heff_field(v_x11_2414, 0);
              heff_take_n(v_x11_2414, 1ULL, 1);
              heff_drop(v_sp_246);
              heff_drop(v_f_247);
              heff_drop_cell(v_ru_24x21_244_24MkWanted, 2);
              heff_drop_cell(v_ru_24x1_248_24MkPair, 2);
              heff_drop(v_x_2412);
              heff_drop_cell(v_ru_24x11_249_24Right, 1);
              return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
            }
            case TAG_Right: {
              V v_x_2417 = heff_field(v_x11_2414, 0);
              heff_take_n(v_x11_2414, 1ULL, 1);
              V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_2412, heff_tag_n(TAG_MkWanted, 2, (V[]){v_sp_246, v_f_247})});
              V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x21_244_24MkWanted, TAG_Cons, 2, (V[]){v_t_2418, v_x_2417})});
              return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2415});
            }
            default: return heff_nomatch(v_x11_2414);
            }
          }
          default: return heff_nomatch(v_x1_2413);
          }
        }
        default: return heff_nomatch(v_x11_249);
        }
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2eresolveListS_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eresolveListS(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2emeta_2eresolveS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eresolveS_entry, 2, 0};

V g_heff_2eelab_2emeta_2eresolveS(V v_final_240, V v_st_241) {
top: ;
  V v_x1_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_w_244 = heff_dup(heff_field(v_st_241, 2));
    v_x1_245 = v_w_244;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_248;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_248 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_final_240);
    heff_drop(v_t_248);
    V v_t_249 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_st_241});
  } else {
    heff_drop(v_t_248);
    V v_t_2413;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_w_2412 = heff_dup(heff_field(v_st_241, 2));
      v_t_2413 = v_w_2412;
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_t_2417;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_c_2414 = heff_field(v_st_241, 0);
      V v_d_2415 = heff_field(v_st_241, 1);
      V v_ru_24st_241_24MkSt = heff_take_reuse_n(v_st_241, 3ULL, 3);
      v_t_2417 = heff_tag_at_n(v_ru_24st_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_2414, v_d_2415, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_x1_2418 = (g_heff_2eelab_2emeta_2eresolveListS(v_final_240, v_t_2413, v_t_2417));
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_MkPair: {
      V v_x11_2419 = heff_field(v_x1_2418, 0);
      V v_st_2420 = heff_field(v_x1_2418, 1);
      V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
      switch (heff_tag_of(v_x11_2419)) {
      case TAG_Left: {
        V v_e_2421 = heff_field(v_x11_2419, 0);
        heff_take_n(v_x11_2419, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
      }
      case TAG_Right: {
        V v_x_2422 = heff_field(v_x11_2419, 0);
        heff_take_n(v_x11_2419, 1ULL, 1);
        V v_t_2423 = (g_list_2eany_24s141450647x925029990(v_x_2422));
        V v_t_2429;
        switch (heff_tag_of(v_st_2420)) {
        case TAG_MkSt: {
          V v_c_2424 = heff_field(v_st_2420, 0);
          V v_d_2425 = heff_field(v_st_2420, 1);
          V v_w_2426 = heff_field(v_st_2420, 2);
          V v_ru_24st_2420_24MkSt = heff_take_reuse_n(v_st_2420, 7ULL, 3);
          V v_t_2427 = (g_heff_2eelab_2emeta_2eresolveKept(v_x_2422));
          V v_t_2428 = (g_prelude_2e_2b_2b(v_w_2426, v_t_2427));
          v_t_2429 = heff_tag_at_n(v_ru_24st_2420_24MkSt, TAG_MkSt, 3, (V[]){v_c_2424, v_d_2425, v_t_2428});
          break;
        }
        default: heff_nomatch(v_st_2420);
        }
        return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_t_2429});
      }
      default: return heff_nomatch(v_x11_2419);
      }
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
}
V g_heff_2eelab_2emeta_2eresolveS_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eresolveS(a[0], a[1]);
}
Clo g_heff_2eelab_2emeta_2edeferAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2edeferAlg_entry, 2, 0};

V g_heff_2eelab_2emeta_2edeferAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Delay: {
    V v_ty_242 = heff_field(v_x1_240, 0);
    V v_c_243 = heff_field(v_x1_240, 1);
    V v_x_244 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24Delay = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_249;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_245 = heff_field(v_p_241, 0);
      V v_d_246 = heff_field(v_p_241, 1);
      V v_w_247 = heff_field(v_p_241, 2);
      heff_take_n(v_p_241, 7ULL, 3);
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDelayed, 2, (V[]){v_ty_242, v_c_243}), v_d_246});
      v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Delay, TAG_MkSt, 3, (V[]){v_c_245, v_t_248, v_w_247});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_244}), v_t_249});
  }
  case TAG_Want: {
    V v_sp_2410 = heff_field(v_x1_240, 0);
    V v_f_2411 = heff_field(v_x1_240, 1);
    V v_x_2412 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24Want = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2418;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_2413 = heff_field(v_p_241, 0);
      V v_d_2414 = heff_field(v_p_241, 1);
      V v_w_2415 = heff_field(v_p_241, 2);
      heff_take_n(v_p_241, 7ULL, 3);
      V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkWanted, 2, (V[]){v_sp_2410, v_f_2411}), NTAG(TAG_Nil)});
      V v_t_2417 = (g_prelude_2e_2b_2b(v_w_2415, v_t_2416));
      v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24Want, TAG_MkSt, 3, (V[]){v_c_2413, v_d_2414, v_t_2417});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2412}), v_t_2418});
  }
  case TAG_Wake: {
    V v_all_2419 = heff_field(v_x1_240, 0);
    V v_x_2420 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Wake = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x1_2421 = (g_heff_2eelab_2emeta_2ewakeS(v_all_2419, v_p_241));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_MkPair: {
      V v_x11_2422 = heff_field(v_x1_2421, 0);
      V v_st_2423 = heff_field(v_x1_2421, 1);
      heff_take_n(v_x1_2421, 3ULL, 2);
      switch (heff_tag_of(v_x11_2422)) {
      case TAG_Left: {
        V v_e_2424 = heff_field(v_x11_2422, 0);
        heff_take_n(v_x11_2422, 1ULL, 1);
        heff_drop(v_x_2420);
        return heff_tag_at_n(v_ru_24x1_240_24Wake, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
      }
      case TAG_Right: {
        heff_take_n(v_x11_2422, 0ULL, 1);
        return heff_tag_at_n(v_ru_24x1_240_24Wake, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2420}), v_st_2423});
      }
      default: return heff_nomatch(v_x11_2422);
      }
    }
    default: return heff_nomatch(v_x1_2421);
    }
  }
  case TAG_Resolve: {
    V v_final_2426 = heff_field(v_x1_240, 0);
    V v_k_2427 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Resolve = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x1_2428 = (g_heff_2eelab_2emeta_2eresolveS(v_final_2426, v_p_241));
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_MkPair: {
      V v_x11_2429 = heff_field(v_x1_2428, 0);
      V v_st_2430 = heff_field(v_x1_2428, 1);
      heff_take_n(v_x1_2428, 3ULL, 2);
      switch (heff_tag_of(v_x11_2429)) {
      case TAG_Left: {
        V v_e_2431 = heff_field(v_x11_2429, 0);
        heff_take_n(v_x11_2429, 1ULL, 1);
        heff_drop(v_k_2427);
        return heff_tag_at_n(v_ru_24x1_240_24Resolve, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
      }
      case TAG_Right: {
        V v_x_2432 = heff_field(v_x11_2429, 0);
        heff_take_n(v_x11_2429, 1ULL, 1);
        V v_t_2433 = heff_tr(heff_call(v_k_2427, 1, (V[]){v_x_2432}));
        return heff_tag_at_n(v_ru_24x1_240_24Resolve, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2433}), v_st_2430});
      }
      default: return heff_nomatch(v_x11_2429);
      }
    }
    default: return heff_nomatch(v_x1_2428);
    }
  }
  case TAG_Pending: {
    V v_k_2434 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Pending = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2438;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_2435 = heff_dup(heff_field(v_p_241, 0));
      v_t_2438 = v_c_2435;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_2442;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_d_2440 = heff_dup(heff_field(v_p_241, 1));
      v_t_2442 = v_d_2440;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_2443 = ({ V b_0 = heff_get_n(v_t_2438, 3, 8); V a_1 = v_t_2442; V r_ = (g_heff_2eelab_2emeta_2eanyDelayed(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2442); r_; });
    V v_t_2444 = heff_tr(heff_call(v_k_2434, 1, (V[]){v_t_2443}));
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Pending, TAG_Right, 1, (V[]){v_t_2444}), v_p_241});
  }
  case TAG_SaveDelayed: {
    V v_k_2445 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SaveDelayed = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2449;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_d_2447 = heff_dup(heff_field(v_p_241, 1));
      v_t_2449 = v_d_2447;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_2453;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_w_2452 = heff_dup(heff_field(v_p_241, 2));
      v_t_2453 = v_w_2452;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_2454 = heff_tr(heff_call(v_k_2445, 1, (V[]){heff_tag_n(TAG_MkSaved, 2, (V[]){v_t_2449, v_t_2453})}));
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SaveDelayed, TAG_Right, 1, (V[]){v_t_2454}), v_p_241});
  }
  case TAG_RestoreDelayed: {
    V v_sv_2455 = heff_field(v_x1_240, 0);
    V v_x_2456 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RestoreDelayed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2462;
    switch (heff_tag_of(v_sv_2455)) {
    case TAG_MkSaved: {
      V v_ds_2457 = heff_field(v_sv_2455, 0);
      heff_take_n(v_sv_2455, 1ULL, 2);
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_c_2459 = heff_field(v_p_241, 0);
        V v_w_2461 = heff_field(v_p_241, 2);
        V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 5ULL, 3);
        v_t_2462 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_2459, v_ds_2457, v_w_2461});
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      break;
    }
    default: heff_nomatch(v_sv_2455);
    }
    return heff_tag_at_n(v_ru_24x1_240_24RestoreDelayed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2456}), v_t_2462});
  }
  case TAG_RestoreWaiting: {
    V v_sv_2463 = heff_field(v_x1_240, 0);
    V v_x_2464 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RestoreWaiting = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2474;
    switch (heff_tag_of(v_sv_2463)) {
    case TAG_MkSaved: {
      V v_ds_2465 = heff_field(v_sv_2463, 0);
      V v_ws_2466 = heff_field(v_sv_2463, 1);
      heff_take_n(v_sv_2463, 3ULL, 2);
      V v_x2_2470;
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_c_2467 = heff_field(v_p_241, 0);
        V v_w_2469 = heff_field(v_p_241, 2);
        V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 5ULL, 3);
        v_x2_2470 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_2467, v_ds_2465, v_w_2469});
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_MkSt: {
        V v_c_2471 = heff_field(v_x2_2470, 0);
        V v_d_2472 = heff_field(v_x2_2470, 1);
        V v_ru_24x2_2470_24MkSt = heff_take_reuse_n(v_x2_2470, 3ULL, 3);
        v_t_2474 = heff_tag_at_n(v_ru_24x2_2470_24MkSt, TAG_MkSt, 3, (V[]){v_c_2471, v_d_2472, v_ws_2466});
        break;
      }
      default: heff_nomatch(v_x2_2470);
      }
      break;
    }
    default: heff_nomatch(v_sv_2463);
    }
    return heff_tag_at_n(v_ru_24x1_240_24RestoreWaiting, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2464}), v_t_2474});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2edeferAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2edeferAlg(a[0], a[1]);
}
Clo g_heff_2eelab_2emeta_2enotesAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2enotesAlg_entry, 2, 0};

V g_heff_2eelab_2emeta_2enotesAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Trace: {
    V v_ev_242 = heff_field(v_x1_240, 0);
    V v_x_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Trace = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_244 = heff_field(v_p_241, 0);
      V v_d_245 = heff_field(v_p_241, 1);
      V v_w_246 = heff_field(v_p_241, 2);
      V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 7ULL, 3);
      V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24Trace, TAG_Cons, 2, (V[]){v_ev_242, heff_dup(heff_rfield(v_c_244, 6))});
      V v_t_248 = ({ V rv_6 = v_t_247; V rr_ = heff_rec_reuse_nf(v_c_244, 191ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 53247u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
      v_t_249 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_t_248, v_d_245, v_w_246});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_243}), v_t_249});
  }
  case TAG_Record: {
    V v_i_2410 = heff_field(v_x1_240, 0);
    V v_x_2411 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Record = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_2412 = heff_field(v_p_241, 0);
      V v_d_2413 = heff_field(v_p_241, 1);
      V v_w_2414 = heff_field(v_p_241, 2);
      V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 7ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x1_240_24Record, TAG_Cons, 2, (V[]){v_i_2410, heff_dup(heff_rfield(v_c_2412, 0))});
      V v_t_2416 = ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_c_2412, 254ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 65532u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      v_t_2417 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_t_2416, v_d_2413, v_w_2414});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2411}), v_t_2417});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2enotesAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2enotesAlg(a[0], a[1]);
}
Clo g_heff_2eelab_2emeta_2ealg2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2ealg2_entry, 2, 0};

V g_heff_2eelab_2emeta_2ealg2(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_c_244 = heff_dup(heff_field(v_p_241, 0));
        v_t_247 = v_c_244;
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      V v_t_248 = heff_tr(heff_call(v_k_243, 1, (V[]){v_t_247}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_248}), v_p_241});
    }
    case TAG_Put: {
      V v_c_249 = heff_field(v_t_242, 0);
      V v_x_2410 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      V v_t_2414;
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_d_2412 = heff_field(v_p_241, 1);
        V v_w_2413 = heff_field(v_p_241, 2);
        V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 6ULL, 3);
        v_t_2414 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_249, v_d_2412, v_w_2413});
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_2410}), v_t_2414});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_2415 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_2415)) {
    case TAG_Throw: {
      V v_d_2416 = heff_field(v_q_2415, 0);
      heff_take_n(v_q_2415, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_d_2416}), v_p_241});
    }
    case TAG_Catch: {
      V v_c_2417 = heff_field(v_q_2415, 0);
      V v_h_2418 = heff_field(v_q_2415, 1);
      V v_ru_24q_2415_24Catch = heff_take_reuse_n(v_q_2415, 3ULL, 2);
      V v_x2_2419 = heff_tr(heff_call(v_c_2417, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_MkPair: {
        V v_x21_2420 = heff_field(v_x2_2419, 0);
        V v_st_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        switch (heff_tag_of(v_x21_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x21_2420, 0);
          heff_take_n(v_x21_2420, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24InR, 1);
          heff_drop_cell(v_ru_24q_2415_24Catch, 2);
          return heff_tail(v_h_2418, 2, (V[]){v_e_2422, v_st_2421});
        }
        case TAG_Right: {
          V v_x_2423 = heff_field(v_x21_2420, 0);
          heff_take_n(v_x21_2420, 1ULL, 1);
          heff_drop(v_h_2418);
          return heff_tag_at_n(v_ru_24q_2415_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Right, 1, (V[]){v_x_2423}), v_st_2421});
        }
        default: return heff_nomatch(v_x21_2420);
        }
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    default: return heff_nomatch(v_q_2415);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2ealg2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2ealg2(a[0], a[1]);
}
V g_heff_2eelab_2emeta_2eelabH_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eelabH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eelabH_lam0, 2, 0};
V g_heff_2eelab_2emeta_2eelabH_lam1(V self, V *args); static Clo g_heff_2eelab_2emeta_2eelabH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eelabH_lam1, 3, 0};
V g_heff_2eelab_2emeta_2eelabH_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2eelabH_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eelabH_lam2, 1, 0};

static V g_heff_2eelab_2emeta_2eelabH_val;
static HEFF_ONCE g_heff_2eelab_2emeta_2eelabH_st;
static V g_heff_2eelab_2emeta_2eelabH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2emeta_2eelabH_lam0_clo), ((V)&g_heff_2eelab_2emeta_2eelabH_lam1_clo), ((V)&g_heff_2eelab_2emeta_2eelabH_lam2_clo)});
}
V g_heff_2eelab_2emeta_2eelabH_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2emeta_2eelabH_st)) return g_heff_2eelab_2emeta_2eelabH_val;
  return heff_global(&g_heff_2eelab_2emeta_2eelabH_val, &g_heff_2eelab_2emeta_2eelabH_st, g_heff_2eelab_2emeta_2eelabH_init);
}
V g_heff_2eelab_2emeta_2eelabH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_st_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_st_241});
}
V g_heff_2eelab_2emeta_2eelabH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_st_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2emeta_2eelabH_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_p_2411 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    switch (heff_tag_of(v_p_2411)) {
    case TAG_InL: {
      V v_p_2412 = heff_field(v_p_2411, 0);
      heff_take_n(v_p_2411, 1ULL, 1);
      V f_ = ((V)&g_heff_2eelab_2emeta_2ealg2_clo);
      args[0] = v_p_2412;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_InR: {
      V v_q_2413 = heff_field(v_p_2411, 0);
      heff_take_n(v_p_2411, 1ULL, 1);
      V f_ = ((V)&g_heff_2eelab_2emeta_2edeferAlg_clo);
      args[0] = v_q_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_p_2411);
    }
  }
  case TAG_InR: {
    V v_q_2414 = heff_field(v_p_2410, 0);
    heff_take_n(v_p_2410, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2emeta_2enotesAlg_clo);
    args[0] = v_q_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_heff_2eelab_2emeta_2esettleGo_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2esettleGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_lam2, 1, 0};
V g_heff_2eelab_2emeta_2esettleGo_lam4(V self, V *args); static Clo g_heff_2eelab_2emeta_2esettleGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_lam4, 1, 0};
V g_heff_2eelab_2emeta_2esettleGo_lam7(V self, V *args); static Clo g_heff_2eelab_2emeta_2esettleGo_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_lam7, 1, 0};
V g_heff_2eelab_2emeta_2esettleGo_lam8(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam6(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam5(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam1(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2esettleGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_entry, 4, 0};

V g_heff_2eelab_2emeta_2esettleGo(V v_g_240, V v_fuel_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_fuel_241, v_k_243})});
}
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2esettleGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2emeta_2esettleGo_lam2(V self, V *args) {
  V v_b_249 = args[0];
  return v_b_249;
}
V g_heff_2eelab_2emeta_2esettleGo_lam4(V self, V *args) {
  V v_b_2414 = args[0];
  return v_b_2414;
}
V g_heff_2eelab_2emeta_2esettleGo_lam7(V self, V *args) {
  V v_b_2423 = args[0];
  return v_b_2423;
}
V g_heff_2eelab_2emeta_2esettleGo_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2427);
  return (g_heff_2eelab_2emeta_2eretryGo(v_g_240, MK_INT(0LL), v_hd_242, v_k_243));
}
V g_heff_2eelab_2emeta_2esettleGo_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2422);
  V v_t_2424 = heff_tag_n(TAG_Resolve, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2eelab_2emeta_2esettleGo_lam7_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2425}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam8, 1, 3, (V[]){v_g_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_fuel_241 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_bool(((heff_dup(v_x_2417) == NTAG(TAG_True)) ? heff_intLe_c(heff_dup(v_fuel_241), MK_INT(50LL)) : ((heff_dup(v_x_2413) == NTAG(TAG_True)) && heff_intLe_c(heff_dup(v_fuel_241), MK_INT(50LL)))));
  heff_drop(v_x_2417);
  heff_drop(v_x_2413);
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    return (g_heff_2eelab_2emeta_2esettleGo(v_g_240, heff_intAdd(v_fuel_241, MK_INT(1LL)), v_hd_242, v_k_243));
  } else {
    heff_drop(v_fuel_241);
    heff_drop(v_t_2418);
    V v_t_2419 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_True), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2420}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2421;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam6, 1, 3, (V[]){v_hd_242, v_g_240, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2emeta_2esettleGo_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Pending, 1, (V[]){((V)&g_heff_2eelab_2emeta_2esettleGo_lam4_clo)})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam5, 1, 5, (V[]){v_fuel_241, v_x_2413, v_g_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_t_2410 = heff_tag_n(TAG_Resolve, 2, (V[]){NTAG(TAG_False), ((V)&g_heff_2eelab_2emeta_2esettleGo_lam2_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam3, 1, 4, (V[]){v_hd_242, v_fuel_241, v_g_240, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_247);
  return (g_heff_2eelab_2emeta_2eretryGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam1, 1, 4, (V[]){v_hd_242, v_fuel_241, v_g_240, v_k_243})));
}