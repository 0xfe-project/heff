// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CanGuess 47396
#define TAG_Catch 6517
#define TAG_Delay 58579
#define TAG_DelayGuessing 16914
#define TAG_Get 18914
#define TAG_Guess 23323
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Left 13886
#define TAG_MkDelayed 26976
#define TAG_MkSaved 51533
#define TAG_MkSt 48854
#define TAG_MkWanted 40078
#define TAG_Pending 60181
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_Resolve 2188
#define TAG_RestoreDelayed 1107
#define TAG_RestoreWaiting 10254
#define TAG_Right 62770
#define TAG_SaveDelayed 42463
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Wake 10253
#define TAG_Want 10361
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_left 9813198
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_trace 311979359
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_heff_2eelab_2emeta_2eanyDelayed(V, V);
V g_heff_2eelab_2emeta_2eanyDelayed_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eanyDelayed_clo;
V g_heff_2eelab_2emeta_2eapproximateFirst(V, V);
V g_heff_2eelab_2emeta_2eapproximateFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eapproximateFirst_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2ecleanly(V, V, V);
V g_heff_2eelab_2emeta_2ecleanly_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2ecleanly_clo;
V g_heff_2eelab_2emeta_2edeferAlg(V, V);
V g_heff_2eelab_2emeta_2edeferAlg_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2edeferAlg_clo;
V g_heff_2eelab_2emeta_2edelayedReady(V, V, V);
V g_heff_2eelab_2emeta_2edelayedReady_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2edelayedReady_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2eforceAll(V, V, V);
V g_heff_2eelab_2emeta_2eforceAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eforceAll_clo;
HeffT2 g_heff_2eelab_2emeta_2eguessS_24cpr(V, V);
V g_heff_2eelab_2emeta_2elastResort(V, V, V, V, V);
V g_heff_2eelab_2emeta_2elastResort_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2elastResort_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eresolveKept(V);
V g_heff_2eelab_2emeta_2eresolveKept_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eresolveKept_clo;
V g_heff_2eelab_2emeta_2eresolveKept_24dps(V, V);
V g_heff_2eelab_2emeta_2eresolveKept_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eresolveKept_24dps_clo;
HeffT2 g_heff_2eelab_2emeta_2eresolveListS_24s1932284354x1121394425_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2emeta_2eresolveListS_24s1959998642x2038352004_24cpr(V, V, V);
V g_heff_2eelab_2emeta_2eretryEach(V, V, V, V);
V g_heff_2eelab_2emeta_2eretryEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eretryEach_clo;
V g_heff_2eelab_2emeta_2eretryGo(V, V, V, V);
V g_heff_2eelab_2emeta_2eretryGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eretryGo_clo;
HeffT2 g_heff_2eelab_2emeta_2erunEachS_24cpr(V, V);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
HeffT2 g_heff_2eelab_2emeta_2ewakeResolveS_24cpr(V, V);
HeffT2 g_heff_2eelab_2emeta_2ewakeS_24cpr(V, V);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_clo;
V g_heff_2eelab_2eunify_2euH_get(void);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s141450647x925029990(V);
V g_list_2eany_24s141450647x925029990_entry(V self, V *a);
extern Clo g_list_2eany_24s141450647x925029990_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(V, V);
V g_heff_2eelab_2emeta_2eliftU_lam1(V self, V *args); static Clo g_heff_2eelab_2emeta_2eliftU_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eliftU_lam1, 2, 0};
V g_heff_2eelab_2emeta_2eliftU_lam0(V self, V *args);
V g_heff_2eelab_2emeta_2eliftU_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eliftU_lam2(V self, V *args);
Clo g_heff_2eelab_2emeta_2eliftU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eliftU_entry, 3, 0};

V g_heff_2eelab_2emeta_2eliftU(V v_u_240, V v_hd_241, V v_k_242) {
top: ;
  V v_bind_243 = heff_take_field(v_hd_241, 1);
  V v_malg_244 = heff_get_n(v_hd_241, 2, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eliftU_lam0, 1, 1, (V[]){v_u_240})})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(v_bind_243), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2emeta_2eliftU_lam2, 1, 3, (V[]){v_malg_244, v_bind_243, v_k_242})});
}
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eliftU(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eliftU_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_c_247 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_246}), v_c_247});
}
V g_heff_2eelab_2emeta_2eliftU_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_u_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_u_240;
  heff_room[0] = heff_dup(g_heff_2eelab_2eunify_2euH_get());
  heff_room[1] = ((V)&g_heff_2eelab_2emeta_2eliftU_lam1_clo);
  heff_room[2] = v_c_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2emeta_2eliftU_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_r_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2417);
  V f_ = v_k_242;
  args[0] = v_r_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2eliftU_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_malg_244 = heff_env(self)[0];
  V v_bind_243 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_r_2412 = heff_field(v_x_2411, 0);
    V v_c2_2413 = heff_field(v_x_2411, 1);
    V v_ru_24x_2411_24MkPair = heff_take_reuse_n(v_x_2411, 3ULL, 2);
    V v_t_2414 = heff_tag_at_n(v_ru_24x_2411_24MkPair, TAG_Put, 2, (V[]){v_c2_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(v_malg_244, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
    V f_ = v_bind_243;
    heff_room[0] = v_t_2416;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eliftU_lam3, 1, 2, (V[]){v_k_242, v_r_2412});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2emeta_2eblockedTy_lam0(V self, V *args);
V g_heff_2eelab_2emeta_2eblockedTy_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eblockedTy_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eblockedTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eblockedTy_entry, 3, 0};

V g_heff_2eelab_2emeta_2eblockedTy(V v_a0_240, V v_hd_241, V v_k_242) {
top: ;
  V v_bind_243 = heff_take_field(v_hd_241, 1);
  V v_malg_244 = heff_get_n(v_hd_241, 2, 3);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eblockedTy_lam0, 1, 1, (V[]){v_a0_240})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(v_malg_244), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(v_bind_243), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2emeta_2eblockedTy_lam1, 1, 3, (V[]){v_malg_244, v_bind_243, v_k_242})});
}
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eblockedTy(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eblockedTy_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_a0_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_245, 3, 9); V a_1 = v_a0_240; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2emeta_2eblockedTy_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_2412 = heff_dup(heff_field(v_x_249, 0));
    switch (heff_tag_of(v_h_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_h_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop_rec(v_c_2410, 9);
    heff_drop(v_x_249);
    heff_drop(v_t_2433);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2433);
    switch (heff_tag_of(v_x_249)) {
    case TAG_VU: {
      heff_take_n(v_x_249, 0ULL, 1);
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_t1_2435 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 5);
      switch (heff_tag_of(v_t1_2435)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2435, 0ULL, 1);
        heff_drop_rec(v_c_2410, 9);
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2435, 0ULL, 1);
        heff_drop_rec(v_c_2410, 9);
        return NTAG(TAG_False);
      }
      case TAG_HMeta: {
        V v_m_2442 = heff_field(v_t1_2435, 0);
        heff_take_n(v_t1_2435, 1ULL, 1);
        HeffT2 v_t_2443 = ({ V b_0 = heff_get_n(v_c_2410, 2, 9); V a_1 = v_m_2442; HeffT2 r_ = (g_std_2eordmap_2elookup_24s245906730x436713417_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2445 = v_t_2443.f[1];
          int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_2444 == ((int64_t)0ULL)) && ({ V v_x_2446 = heff_dup(v_field_2445); int c_ = 1; heff_drop(v_x_2446); c_; })));
          heff_drop(v_field_2445);
          return v_ret_24bool;
        }
      }
      case TAG_HError: {
        heff_drop_rec(v_c_2410, 9);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t1_2435);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_x_249, 0ULL, 6);
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      heff_take_n(v_x_249, 0ULL, 4);
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      heff_take_n(v_x_249, 0ULL, 1);
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      heff_take_n(v_x_249, 0ULL, 1);
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      heff_take_n(v_x_249, 0ULL, 1);
      heff_drop_rec(v_c_2410, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_249);
    }
  }
}
V g_heff_2eelab_2emeta_2eblockedTy_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_malg_244 = heff_env(self)[0];
  V v_bind_243 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eblockedTy_lam2, 1, 1, (V[]){v_x_249})})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2461}));
  V f_ = v_bind_243;
  heff_room[0] = v_t_2462;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eattempt_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eattempt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eattempt_lam0, 1, 0};
V g_heff_2eelab_2emeta_2eattempt_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2eattempt_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eattempt_lam2, 1, 0};
V g_heff_2eelab_2emeta_2eattempt_lam5(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam8(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam7(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam6(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam4(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eattempt_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eattempt_entry, 3, 0};

V g_heff_2eelab_2emeta_2eattempt(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eattempt_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam1, 1, 3, (V[]){v_hd_241, v_m_240, v_k_242})});
}
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eattempt(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eattempt_lam0(V self, V *args) {
  V v_c_243 = args[0];
  return v_c_243;
}
V g_heff_2eelab_2emeta_2eattempt_lam2(V self, V *args) {
  V v_sv_248 = args[0];
  return v_sv_248;
}
V g_heff_2eelab_2emeta_2eattempt_lam5(V self, V *args) {
  V v_c_2421 = args[0];
  V v_before_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ps_2422 = heff_take_field(v_before_2413, 5);
  return ({ V rv_3 = heff_dup(heff_rfield(v_before_2413, 3)); V rv_4 = heff_get_n(v_before_2413, 4, 9); V rv_5 = v_ps_2422; V rr_ = heff_rec_reuse_nf(v_c_2421, 455ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 258111u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2emeta_2eattempt_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_p_2419 = heff_env(self)[0];
  V v_err_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V f_ = v_p_2419;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_err_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2eattempt_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_waiting_2414 = heff_env(self)[0];
  V v_malg_2418 = heff_env(self)[1];
  V v_bind_2417 = heff_env(self)[2];
  V v_p_2419 = heff_env(self)[3];
  V v_err_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_waiting_2414, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(v_malg_2418, 1, (V[]){v_t_2432}));
  V f_ = v_bind_2417;
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam8, 1, 2, (V[]){v_p_2419, v_err_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eattempt_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_malg_2418 = heff_env(self)[0];
  V v_bind_2417 = heff_env(self)[1];
  V v_waiting_2414 = heff_env(self)[2];
  V v_p_2419 = heff_env(self)[3];
  V v_err_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2427 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2426, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_dup(v_malg_2418), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})}));
  V f_ = heff_dup(v_bind_2417);
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam7, 1, 5, (V[]){v_waiting_2414, v_malg_2418, v_bind_2417, v_p_2419, v_err_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eattempt_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_before_2413 = v_x_247;
  V v_waiting_2414 = v_x_2411;
  V v_x3_2415 = v_x_2412;
  V v_p_2416 = v_hd_241;
  V v_bind_2417 = heff_take_field(v_p_2416, 1);
  V v_malg_2418 = heff_get_n(v_p_2416, 2, 3);
  V v_p_2419 = v_k_242;
  switch (heff_tag_of(v_x3_2415)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x3_2415, 0);
    V v_ru_24x3_2415_24Left = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
    V v_t_2423 = heff_tag_at_n(v_ru_24x3_2415_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam5, 1, 1, (V[]){v_before_2413})})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(v_malg_2418), 1, (V[]){v_t_2424}));
    V f_ = heff_dup(v_bind_2417);
    heff_room[0] = v_t_2425;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam6, 1, 5, (V[]){v_malg_2418, v_bind_2417, v_waiting_2414, v_p_2419, v_err_2420});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_x_2435 = heff_field(v_x3_2415, 0);
    heff_take_n(v_x3_2415, 1ULL, 1);
    heff_drop_rec(v_before_2413, 9);
    heff_drop(v_waiting_2414);
    heff_drop(v_bind_2417);
    heff_drop(v_malg_2418);
    V f_ = v_p_2419;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x3_2415);
  }
}
V g_heff_2eelab_2emeta_2eattempt_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_m_240;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam4, 1, 4, (V[]){v_x_247, v_x_2411, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eattempt_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eattempt_lam2_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eattempt_lam3, 1, 4, (V[]){v_m_240, v_hd_241, v_x_247, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryEach_lam1(V self, V *args);
V g_heff_2eelab_2emeta_2eretryEach_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eretryEach_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eretryEach_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2eretryEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryEach_entry, 4, 0};

V g_heff_2eelab_2emeta_2eretryEach(V v_g_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(heff_rfield(v_p_244, 0)), heff_dup(heff_rfield(v_p_244, 1)), heff_dup(heff_rfield(v_p_244, 2))}));
    V v_t_247 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_246}));
    return (g_heff_2eelab_2emeta_2eattempt(v_t_247, heff_dup(v_p_242), heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam0, 1, 5, (V[]){v_p_244, v_p_242, v_g_240, v_rest_245, v_p_243})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2eretryEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eretryEach(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2emeta_2eretryEach_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  return (g_heff_2eelab_2emeta_2eretryEach(v_g_240, v_rest_245, v_p_242, v_p_243));
}
V g_heff_2eelab_2emeta_2eretryEach_lam2(V self, V *args) {
  V v_c_2417 = args[0];
  V v_p_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = ({ V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_p_249, 7ULL, 4, shape_shape__left__right__failed, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_take_field(v_c_2417, 5)});
  return ({ V rv_5 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_c_2417, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2emeta_2eretryEach_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_2413 = heff_env(self)[0];
  V v_bind_2412 = heff_env(self)[1];
  V v_p_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(v_malg_2413, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})}));
  V f_ = v_bind_2412;
  heff_room[0] = v_t_2426;
  heff_room[1] = v_p_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryEach_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_p_249 = v_p_244;
  V v_x2_2410 = v_x_248;
  V v_p_2411 = heff_dup(v_p_242);
  V v_bind_2412 = heff_take_field(v_p_2411, 1);
  V v_malg_2413 = heff_get_n(v_p_2411, 2, 3);
  V v_p_2415 = heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam1, 1, 4, (V[]){v_g_240, v_rest_245, v_p_242, v_p_243});
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Left: {
    V v_ru_24x2_2410_24Left = heff_take_reuse_n(v_x2_2410, 0ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x2_2410_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam2, 1, 1, (V[]){v_p_249})})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_2413), 1, (V[]){v_t_2421}));
    V f_ = heff_dup(v_bind_2412);
    heff_room[0] = v_t_2422;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryEach_lam3, 1, 3, (V[]){v_malg_2413, v_bind_2412, v_p_2415});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x2_2410, 0ULL, 1);
    heff_drop_rec(v_p_249, 4);
    heff_drop(v_bind_2412);
    heff_drop(v_malg_2413);
    V f_ = v_p_2415;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2eelab_2emeta_2eretryGo_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_lam0, 1, 0};
V g_heff_2eelab_2emeta_2eretryGo_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_lam2, 1, 0};
V g_heff_2eelab_2emeta_2eretryGo_lam6(V self, V *args); static Clo g_heff_2eelab_2emeta_2eretryGo_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_lam6, 1, 0};
V g_heff_2eelab_2emeta_2eretryGo_lam7(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam5(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam4(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2eretryGo_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eretryGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eretryGo_entry, 4, 0};

V g_heff_2eelab_2emeta_2eretryGo(V v_g_240, V v_fuel_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eretryGo_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam1, 1, 4, (V[]){v_hd_242, v_g_240, v_fuel_241, v_k_243})});
}
V g_heff_2eelab_2emeta_2eretryGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eretryGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2emeta_2eretryGo_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_244, 5, 9)));
}
V g_heff_2eelab_2emeta_2eretryGo_lam2(V self, V *args) {
  V v_c_249 = args[0];
  return ({ V rv_5 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_c_249, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2emeta_2eretryGo_lam6(V self, V *args) {
  V v_c_2419 = args[0];
  return heff_get_n(v_c_2419, 5, 9);
}
V g_heff_2eelab_2emeta_2eretryGo_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2423));
  if ((heff_intEq_c_lent(v_t_2424, MK_INT(0LL), 2) || ({ V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2423)); int c_ = ({ V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_248)); int c_ = (heff_intEq_c_lent(v_t_2426, v_t_2427, 0) || (((int64_t)50ULL) < heff_peek_word(v_fuel_241))); heff_drop(v_t_2427); c_; }); heff_drop(v_t_2426); c_; }))) {
    heff_drop(v_x_248);
    heff_drop(v_fuel_241);
    heff_drop(v_g_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_t_2424);
    V v_x_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_x_2423));
    V f_ = v_k_243;
    args[0] = v_x_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2423);
    heff_drop(v_x_248);
    heff_drop(v_t_2424);
    return (g_heff_2eelab_2emeta_2eretryGo(v_g_240, heff_box_word((heff_unbox_word(v_fuel_241) + ((int64_t)1ULL))), v_hd_242, v_k_243));
  }
}
V g_heff_2eelab_2emeta_2eretryGo_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eretryGo_lam6_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam7, 1, 5, (V[]){v_x_248, v_fuel_241, v_k_243, v_g_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryGo_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  return (g_heff_2eelab_2emeta_2eretryEach(heff_dup(v_g_240), heff_dup(v_x_248), heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam5, 1, 5, (V[]){v_hd_242, v_x_248, v_fuel_241, v_k_243, v_g_240})));
}
V g_heff_2eelab_2emeta_2eretryGo_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam4, 1, 5, (V[]){v_g_240, v_x_248, v_hd_242, v_fuel_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2eretryGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2eretryGo_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eretryGo_lam3, 1, 5, (V[]){v_hd_242, v_g_240, v_x_248, v_fuel_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2emeta_2edelayedReady_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2edelayedReady_entry, 3, 0};

V g_heff_2eelab_2emeta_2edelayedReady(V v_mc_240, V v_all_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkDelayed: {
    V v_ty_243 = heff_field(v_x3_242, 0);
    if ((heff_dup(v_all_241) == NTAG(TAG_True))) {
      return NTAG(TAG_True);
    } else {
      V v_t_246 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, heff_dup(v_ty_243)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_VU: {
        heff_take_n(v_t_246, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_VDecode: {
        V v_t1_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 5);
        switch (heff_tag_of(v_t1_248)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_248, 0ULL, 1);
          return NTAG(TAG_True);
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_248, 0ULL, 1);
          return NTAG(TAG_True);
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_248, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_HError: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t1_248);
        }
      }
      case TAG_VFunction: {
        heff_take_n(v_t_246, 0ULL, 6);
        return NTAG(TAG_True);
      }
      case TAG_VRecord: {
        heff_take_n(v_t_246, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_VSum: {
        heff_take_n(v_t_246, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_VPrimInt: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimFloat: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimString: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimRune: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimArray: {
        heff_take_n(v_t_246, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_VFixed: {
        heff_take_n(v_t_246, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_246);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2emeta_2edelayedReady_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2emeta_2edelayedReady(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2emeta_2eanyDelayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eanyDelayed_entry, 2, 0};

V g_heff_2eelab_2emeta_2eanyDelayed(V v_mc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_d_242)) {
    case TAG_MkDelayed: {
      V v_ty_244 = heff_field(v_d_242, 0);
      V v_t_247 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, heff_dup(v_ty_244)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_VU: {
        heff_take_n(v_t_247, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_VDecode: {
        V v_t1_249 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 5);
        switch (heff_tag_of(v_t1_249)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_249, 0ULL, 1);
          return NTAG(TAG_True);
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_249, 0ULL, 1);
          return NTAG(TAG_True);
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_249, 0ULL, 1);
          V t_0 = v_mc_240;
          V t_1 = v_rest_243;
          v_mc_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_HError: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t1_249);
        }
      }
      case TAG_VFunction: {
        heff_take_n(v_t_247, 0ULL, 6);
        return NTAG(TAG_True);
      }
      case TAG_VRecord: {
        heff_take_n(v_t_247, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_VSum: {
        heff_take_n(v_t_247, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_VPrimInt: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimFloat: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimString: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimRune: {
        return NTAG(TAG_True);
      }
      case TAG_VPrimArray: {
        heff_take_n(v_t_247, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_VFixed: {
        heff_take_n(v_t_247, 0ULL, 1);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_d_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2eanyDelayed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2emeta_2eanyDelayed(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2emeta_2eresolveKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eresolveKept_entry, 1, 0};

V g_heff_2eelab_2emeta_2eresolveKept(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      V v_x112_244 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      if ((heff_dup(v_x111_243) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x111_243);
        heff_drop(v_x112_244);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      } else {
        heff_drop(v_x111_243);
        V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x112_244, heff_hole()});
        V v_u_246 = (g_heff_2eelab_2emeta_2eresolveKept_24dps(v_rest_242, heff_dup(v_cell_245)));
        heff_drop(v_u_246);
        return v_cell_245;
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2eresolveKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eresolveKept(a[0]);
}
Clo g_heff_2eelab_2emeta_2eresolveKept_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eresolveKept_24dps_entry, 2, 0};

V g_heff_2eelab_2emeta_2eresolveKept_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x111_244 = heff_field(v_x11_242, 0);
      V v_x112_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      if ((heff_dup(v_x111_244) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x111_244);
        heff_drop(v_x112_245);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        heff_drop(v_x111_244);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x112_245, heff_hole()});
        V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
        heff_drop(v_u_247);
        V t_0 = v_rest_243;
        V t_1 = v_cell_246;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2eresolveKept_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eresolveKept_24dps(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2emeta_2erunEachS_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return ((HeffT2){{v_t_242, v_p_241}});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkDelayed: {
      V v_chk_246 = heff_field(v_x11_243, 1);
      V v_x1_248 = heff_tr(heff_call(heff_dup(v_chk_246), 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x11_249 = heff_field(v_x1_248, 0);
        V v_st_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        switch (heff_tag_of(v_x11_249)) {
        case TAG_Left: {
          V v_e_2411 = heff_field(v_x11_249, 0);
          V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410}});
        }
        case TAG_Right: {
          heff_take_n(v_x11_249, 0ULL, 1);
          V t_0 = v_rest_244;
          V t_1 = v_st_2410;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_249)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2eelab_2emeta_2ewakeS_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2emeta_2ewakeS_24cpr(V v_all_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2edelayedReady_clo), 2, (V[]){heff_get_n(v_t_245, 3, 9), heff_dup(v_all_240)}));
  V v_t_2410;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_d_248 = heff_dup(heff_field(v_st_241, 1));
    v_t_2410 = v_d_248;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_x1_2411 = (g_list_2ekeepIf(v_t_246, v_t_2410));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nil: {
    heff_drop(v_all_240);
    V v_t_2412 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return ((HeffT2){{v_t_2412, v_st_241}});
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2411, 0ULL, 2);
    V v_t_2418;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_c_2415 = heff_dup(heff_field(v_st_241, 0));
      v_t_2418 = v_c_2415;
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2edelayedReady_clo), 2, (V[]){heff_get_n(v_t_2418, 3, 9), heff_dup(v_all_240)}));
    V v_t_2423;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_d_2421 = heff_dup(heff_field(v_st_241, 1));
      v_t_2423 = v_d_2421;
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    V v_t_2424 = (g_list_2efoldl_24f1428393365x1980555854(NTAG(TAG_Nil), v_t_2419, v_t_2423));
    V v_t_2460;
    switch (heff_tag_of(v_st_241)) {
    case TAG_MkSt: {
      V v_c_2425 = heff_dup(heff_field(v_st_241, 0));
      V v_d_2426 = heff_dup(heff_field(v_st_241, 1));
      V v_w_2427 = heff_dup(heff_field(v_st_241, 2));
      V v_t_2459 = (g_list_2ekeepIf(heff_clo_n(g_heff_2eelab_2emeta_2ewakeS_24cpr_lam0, 1, 2, (V[]){heff_dup(v_all_240), v_st_241}), v_d_2426));
      v_t_2460 = heff_tag_n(TAG_MkSt, 3, (V[]){v_c_2425, v_t_2459, v_w_2427});
      break;
    }
    default: heff_nomatch(v_st_241);
    }
    HeffT2 v_t_2461 = ({ V a_0 = v_t_2424; V a_1 = v_t_2460; HeffT2 r_ = (g_heff_2eelab_2emeta_2erunEachS_24cpr(a_0, a_1)); heff_drop(v_t_2424); r_; });
    {
      V v_field_2462 = v_t_2461.f[0];
      V v_field_2463 = v_t_2461.f[1];
      V v_x11_2464 = v_field_2462;
      V v_st_2465 = v_field_2463;
      switch (heff_tag_of(v_x11_2464)) {
      case TAG_Left: {
        V v_e_2466 = heff_field(v_x11_2464, 0);
        V v_ru_24x11_2464_24Left = heff_take_reuse_n(v_x11_2464, 1ULL, 1);
        heff_drop(v_all_240);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2464_24Left, TAG_Left, 1, (V[]){v_e_2466}), v_st_2465}});
      }
      case TAG_Right: {
        heff_take_n(v_x11_2464, 0ULL, 1);
        V t_0 = v_all_240;
        V t_1 = v_st_2465;
        v_all_240 = t_0;
        v_st_241 = t_1;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2464)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
  }
}
V g_heff_2eelab_2emeta_2ewakeS_24cpr_lam0(V self, V *args) {
  V v_d_2428 = args[0];
  V v_all_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_d_2428)) {
  case TAG_MkDelayed: {
    V v_ty_2429 = heff_field(v_d_2428, 0);
    heff_take_n(v_d_2428, 1ULL, 3);
    if ((heff_dup(v_all_240) == NTAG(TAG_True))) {
      heff_drop(v_all_240);
      heff_drop_tag(v_st_241, 3);
      heff_drop(v_ty_2429);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_all_240);
      V v_t_2435;
      switch (heff_tag_of(v_st_241)) {
      case TAG_MkSt: {
        V v_c_2432 = heff_field(v_st_241, 0);
        heff_take_n(v_st_241, 1ULL, 3);
        v_t_2435 = v_c_2432;
        break;
      }
      default: heff_nomatch(v_st_241);
      }
      V v_t_2436 = ({ V b_0 = heff_get_n(v_t_2435, 3, 9); V a_1 = v_ty_2429; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_2436)) {
      case TAG_VU: {
        heff_take_n(v_t_2436, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_VDecode: {
        V v_t1_2438 = heff_field(v_t_2436, 0);
        heff_take_n(v_t_2436, 1ULL, 5);
        switch (heff_tag_of(v_t1_2438)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2438, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2438, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2438, 0ULL, 1);
          return NTAG(TAG_True);
        }
        case TAG_HError: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t1_2438);
        }
      }
      case TAG_VFunction: {
        heff_take_n(v_t_2436, 0ULL, 6);
        return NTAG(TAG_False);
      }
      case TAG_VRecord: {
        heff_take_n(v_t_2436, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_VSum: {
        heff_take_n(v_t_2436, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_VPrimInt: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimFloat: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimString: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimRune: {
        return NTAG(TAG_False);
      }
      case TAG_VPrimArray: {
        heff_take_n(v_t_2436, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_VFixed: {
        heff_take_n(v_t_2436, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
  }
  default: return heff_nomatch(v_d_2428);
  }
}

HeffT2 g_heff_2eelab_2emeta_2eguessS_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
    return ((HeffT2){{v_t_242, v_p_241}});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_2435;
    switch (heff_tag_of(v_d_243)) {
    case TAG_MkDelayed: {
      V v_ty_245 = heff_field(v_d_243, 0);
      V v_gs_247 = heff_field(v_d_243, 2);
      V v_t_2411;
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_c_248 = heff_dup(heff_field(v_p_241, 0));
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      V v_t_2412 = ({ V b_0 = heff_get_n(v_t_2411, 3, 9); V a_1 = heff_dup(v_ty_245); V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_2412)) {
      case TAG_VU: {
        heff_take_n(v_t_2412, 0ULL, 1);
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2414 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 5);
        switch (heff_tag_of(v_t1_2414)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2414, 0ULL, 1);
          v_t_2435 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2414, 0ULL, 1);
          v_t_2435 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2414, 0ULL, 1);
          v_t_2435 = heff_dup(v_gs_247);
          break;
        }
        case TAG_HError: {
          v_t_2435 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t1_2414);
        }
        break;
      }
      case TAG_VFunction: {
        heff_take_n(v_t_2412, 0ULL, 6);
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VRecord: {
        heff_take_n(v_t_2412, 0ULL, 4);
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        heff_take_n(v_t_2412, 0ULL, 1);
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        heff_take_n(v_t_2412, 0ULL, 1);
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        heff_take_n(v_t_2412, 0ULL, 1);
        v_t_2435 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    switch (heff_tag_of(v_t_2435)) {
    case TAG_Nothing: {
      V t_0 = v_rest_244;
      V t_1 = v_p_241;
      v_x1_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_gs_2436 = heff_field(v_t_2435, 0);
      V v_ru_24t_2435_24Just = heff_take_reuse_n(v_t_2435, 1ULL, 1);
      V v_x1_2437 = heff_tr(heff_call(v_gs_2436, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_x1_2437)) {
      case TAG_MkPair: {
        V v_x11_2438 = heff_field(v_x1_2437, 0);
        V v_st_2439 = heff_field(v_x1_2437, 1);
        heff_take_n(v_x1_2437, 3ULL, 2);
        switch (heff_tag_of(v_x11_2438)) {
        case TAG_Left: {
          V v_e_2440 = heff_field(v_x11_2438, 0);
          heff_take_n(v_x11_2438, 1ULL, 1);
          return ((HeffT2){{heff_tag_at_n(v_ru_24t_2435_24Just, TAG_Left, 1, (V[]){v_e_2440}), v_st_2439}});
        }
        case TAG_Right: {
          V v_x_2441 = heff_field(v_x11_2438, 0);
          heff_take_n(v_x11_2438, 1ULL, 1);
          if ((heff_dup(v_x_2441) == NTAG(TAG_True))) {
            heff_drop(v_x_2441);
            V v_t_2442 = heff_tag_at_n(v_ru_24t_2435_24Just, TAG_Right, 1, (V[]){NTAG(TAG_True)});
            return ((HeffT2){{v_t_2442, v_st_2439}});
          } else {
            heff_drop_cell(v_ru_24t_2435_24Just, 1);
            heff_drop(v_x_2441);
            V t_0 = v_rest_244;
            V t_1 = v_st_2439;
            v_x1_240 = t_0;
            v_p_241 = t_1;
            goto top;
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2438)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2437)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2435)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2eelab_2emeta_2eresolveListS_24s1932284354x1121394425_24cpr(V v_final_240, V v_x3_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_final_240);
    V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_p_242}});
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_rest_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkWanted: {
      V v_sp_246 = heff_field(v_x31_244, 0);
      V v_f_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkWanted = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_s_248 = heff_tr(heff_call(heff_dup(v_f_247), 1, (V[]){heff_dup(v_final_240)}));
      V v_x1_249 = heff_tr(heff_call(v_s_248, 1, (V[]){v_p_242}));
      switch (heff_tag_of(v_x1_249)) {
      case TAG_MkPair: {
        V v_x11_2410 = heff_field(v_x1_249, 0);
        V v_st_2411 = heff_field(v_x1_249, 1);
        V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
        switch (heff_tag_of(v_x11_2410)) {
        case TAG_Left: {
          V v_e_2412 = heff_field(v_x11_2410, 0);
          V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
          heff_drop(v_final_240);
          heff_drop(v_rest_245);
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          heff_drop(v_sp_246);
          heff_drop(v_f_247);
          heff_drop_cell(v_ru_24x31_244_24MkWanted, 2);
          heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411}});
        }
        case TAG_Right: {
          V v_x_2413 = heff_field(v_x11_2410, 0);
          V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
          HeffT2 v_t_2414 = (g_heff_2eelab_2emeta_2eresolveListS_24s1932284354x1121394425_24cpr(v_final_240, v_rest_245, v_st_2411));
          {
            V v_field_2415 = v_t_2414.f[0];
            V v_field_2416 = v_t_2414.f[1];
            V v_x11_2417 = v_field_2415;
            V v_st_2418 = v_field_2416;
            switch (heff_tag_of(v_x11_2417)) {
            case TAG_Left: {
              V v_e_2419 = heff_field(v_x11_2417, 0);
              V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
              heff_drop_cell(v_ru_24x3_241_24Cons, 2);
              heff_drop(v_sp_246);
              heff_drop(v_f_247);
              heff_drop_cell(v_ru_24x31_244_24MkWanted, 2);
              heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
              heff_drop(v_x_2413);
              heff_drop_cell(v_ru_24x11_2410_24Right, 1);
              return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2417_24Left, TAG_Left, 1, (V[]){v_e_2419}), v_st_2418}});
            }
            case TAG_Right: {
              V v_x_2420 = heff_field(v_x11_2417, 0);
              heff_take_n(v_x11_2417, 1ULL, 1);
              V v_t_2421 = heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, heff_tag_at_n(v_ru_24x31_244_24MkWanted, TAG_MkWanted, 2, (V[]){v_sp_246, v_f_247})});
              V v_t_2422 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2421, v_x_2420})});
              return ((HeffT2){{v_t_2422, v_st_2418}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_2417)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2eelab_2emeta_2eresolveListS_24s1959998642x2038352004_24cpr(V v_final_240, V v_x3_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_final_240);
    V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_p_242}});
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_rest_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkWanted: {
      V v_sp_246 = heff_field(v_x31_244, 0);
      V v_f_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkWanted = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_s_248 = heff_tr(heff_call(heff_dup(v_f_247), 1, (V[]){heff_dup(v_final_240)}));
      V v_it_249 = heff_tr(heff_call(v_s_248, 1, (V[]){heff_dup(v_p_242)}));
      switch (heff_tag_of(v_it_249)) {
      case TAG_MkPair: {
        V v_it1_2410 = heff_dup(heff_field(v_it_249, 0));
        switch (heff_tag_of(v_it1_2410)) {
        case TAG_Left: {
          V v_ru_24it1_2410_24Left = heff_take_reuse_n(v_it1_2410, 0ULL, 1);
          switch (heff_tag_of(v_it_249)) {
          case TAG_MkPair: {
            V v_ru_24it_249_24MkPair = heff_take_reuse_n(v_it_249, 0ULL, 2);
            HeffT2 v_t_2415 = (g_heff_2eelab_2emeta_2eresolveListS_24s1959998642x2038352004_24cpr(v_final_240, v_rest_245, v_p_242));
            {
              V v_field_2416 = v_t_2415.f[0];
              V v_field_2417 = v_t_2415.f[1];
              V v_x11_2418 = v_field_2416;
              V v_st_2419 = v_field_2417;
              switch (heff_tag_of(v_x11_2418)) {
              case TAG_Left: {
                V v_e_2420 = heff_field(v_x11_2418, 0);
                heff_take_n(v_x11_2418, 1ULL, 1);
                heff_drop_cell(v_ru_24x3_241_24Cons, 2);
                heff_drop(v_sp_246);
                heff_drop(v_f_247);
                heff_drop_cell(v_ru_24x31_244_24MkWanted, 2);
                heff_drop_cell(v_ru_24it_249_24MkPair, 2);
                return ((HeffT2){{heff_tag_at_n(v_ru_24it1_2410_24Left, TAG_Left, 1, (V[]){v_e_2420}), v_st_2419}});
              }
              case TAG_Right: {
                V v_x_2421 = heff_field(v_x11_2418, 0);
                V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
                heff_drop_cell(v_ru_24it1_2410_24Left, 1);
                V v_t_2422 = heff_tag_at_n(v_ru_24it_249_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), heff_tag_at_n(v_ru_24x31_244_24MkWanted, TAG_MkWanted, 2, (V[]){v_sp_246, v_f_247})});
                V v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2422, v_x_2421})});
                return ((HeffT2){{v_t_2423, v_st_2419}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x11_2418)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it_249)}});
          }
        }
        case TAG_Right: {
          V v_ru_24it1_2410_24Right = heff_take_reuse_n(v_it1_2410, 0ULL, 1);
          heff_drop(v_p_242);
          switch (heff_tag_of(v_it_249)) {
          case TAG_MkPair: {
            V v_x11_2425 = heff_field(v_it_249, 0);
            V v_st_2426 = heff_field(v_it_249, 1);
            V v_ru_24it_249_24MkPair = heff_take_reuse_n(v_it_249, 3ULL, 2);
            switch (heff_tag_of(v_x11_2425)) {
            case TAG_Left: {
              V v_e_2427 = heff_field(v_x11_2425, 0);
              V v_ru_24x11_2425_24Left = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
              heff_drop(v_final_240);
              heff_drop(v_rest_245);
              heff_drop_cell(v_ru_24x3_241_24Cons, 2);
              heff_drop(v_sp_246);
              heff_drop(v_f_247);
              heff_drop_cell(v_ru_24x31_244_24MkWanted, 2);
              heff_drop_cell(v_ru_24it1_2410_24Right, 1);
              heff_drop_cell(v_ru_24it_249_24MkPair, 2);
              return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2425_24Left, TAG_Left, 1, (V[]){v_e_2427}), v_st_2426}});
            }
            case TAG_Right: {
              V v_x_2428 = heff_field(v_x11_2425, 0);
              V v_ru_24x11_2425_24Right = heff_take_reuse_n(v_x11_2425, 1ULL, 1);
              HeffT2 v_t_2429 = (g_heff_2eelab_2emeta_2eresolveListS_24s1959998642x2038352004_24cpr(v_final_240, v_rest_245, v_st_2426));
              {
                V v_field_2430 = v_t_2429.f[0];
                V v_field_2431 = v_t_2429.f[1];
                V v_x11_2432 = v_field_2430;
                V v_st_2433 = v_field_2431;
                switch (heff_tag_of(v_x11_2432)) {
                case TAG_Left: {
                  V v_e_2434 = heff_field(v_x11_2432, 0);
                  heff_take_n(v_x11_2432, 1ULL, 1);
                  heff_drop_cell(v_ru_24x3_241_24Cons, 2);
                  heff_drop(v_sp_246);
                  heff_drop(v_f_247);
                  heff_drop_cell(v_ru_24x31_244_24MkWanted, 2);
                  heff_drop_cell(v_ru_24it1_2410_24Right, 1);
                  heff_drop_cell(v_ru_24it_249_24MkPair, 2);
                  heff_drop(v_x_2428);
                  return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2425_24Right, TAG_Left, 1, (V[]){v_e_2434}), v_st_2433}});
                }
                case TAG_Right: {
                  V v_x_2435 = heff_field(v_x11_2432, 0);
                  heff_take_n(v_x11_2432, 1ULL, 1);
                  heff_drop_cell(v_ru_24x11_2425_24Right, 1);
                  V v_t_2436 = heff_tag_at_n(v_ru_24it_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, heff_tag_at_n(v_ru_24x31_244_24MkWanted, TAG_MkWanted, 2, (V[]){v_sp_246, v_f_247})});
                  V v_t_2437 = heff_tag_at_n(v_ru_24it1_2410_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2436, v_x_2435})});
                  return ((HeffT2){{v_t_2437, v_st_2433}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x11_2432)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_2425)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it_249)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it1_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2eelab_2emeta_2ewakeResolveS_24cpr(V v_all_240, V v_st_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2emeta_2ewakeS_24cpr(heff_dup(v_all_240), v_st_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_x11_245 = v_field_243;
    V v_st_246 = v_field_244;
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Left = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      heff_drop(v_all_240);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_245_24Left, TAG_Left, 1, (V[]){v_e_247}), v_st_246}});
    }
    case TAG_Right: {
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 0ULL, 1);
      if ((heff_dup(v_all_240) == NTAG(TAG_True))) {
        heff_drop(v_all_240);
        V v_t_249 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        return ((HeffT2){{v_t_249, v_st_246}});
      } else {
        V v_final_2410 = NTAG(TAG_False);
        V v_st_2411 = v_st_246;
        V v_t_2415;
        switch (heff_tag_of(v_st_2411)) {
        case TAG_MkSt: {
          V v_w_2414 = heff_dup(heff_field(v_st_2411, 2));
          v_t_2415 = v_w_2414;
          break;
        }
        default: heff_nomatch(v_st_2411);
        }
        V v_x1_2441;
        switch (heff_tag_of(v_t_2415)) {
        case TAG_Nil: {
          V v_t_2416 = heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){NTAG(TAG_False)});
          v_x1_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_st_2411});
          break;
        }
        case TAG_Cons: {
          V v_ru_24t_2415_24Cons = heff_take_reuse_n(v_t_2415, 0ULL, 2);
          V v_t_2422;
          switch (heff_tag_of(v_st_2411)) {
          case TAG_MkSt: {
            V v_w_2421 = heff_dup(heff_field(v_st_2411, 2));
            v_t_2422 = v_w_2421;
            break;
          }
          default: heff_nomatch(v_st_2411);
          }
          V v_t_2426;
          switch (heff_tag_of(v_st_2411)) {
          case TAG_MkSt: {
            V v_c_2423 = heff_field(v_st_2411, 0);
            V v_d_2424 = heff_field(v_st_2411, 1);
            V v_ru_24st_2411_24MkSt = heff_take_reuse_n(v_st_2411, 3ULL, 3);
            v_t_2426 = heff_tag_at_n(v_ru_24st_2411_24MkSt, TAG_MkSt, 3, (V[]){v_c_2423, v_d_2424, NTAG(TAG_Nil)});
            break;
          }
          default: heff_nomatch(v_st_2411);
          }
          HeffT2 v_t_2427 = (g_heff_2eelab_2emeta_2eresolveListS_24s1959998642x2038352004_24cpr(v_final_2410, v_t_2422, v_t_2426));
          {
            V v_field_2428 = v_t_2427.f[0];
            V v_field_2429 = v_t_2427.f[1];
            V v_x11_2430 = v_field_2428;
            V v_st_2431 = v_field_2429;
            switch (heff_tag_of(v_x11_2430)) {
            case TAG_Left: {
              V v_e_2432 = heff_field(v_x11_2430, 0);
              V v_ru_24x11_2430_24Left = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
              heff_drop_cell(v_ru_24x11_245_24Right, 1);
              v_x1_2441 = heff_tag_at_n(v_ru_24t_2415_24Cons, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2430_24Left, TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
              break;
            }
            case TAG_Right: {
              V v_x_2433 = heff_field(v_x11_2430, 0);
              heff_take_n(v_x11_2430, 1ULL, 1);
              V v_t_2434 = (g_list_2eany_24s141450647x925029990(v_x_2433));
              V v_t_2440;
              switch (heff_tag_of(v_st_2431)) {
              case TAG_MkSt: {
                V v_c_2435 = heff_field(v_st_2431, 0);
                V v_d_2436 = heff_field(v_st_2431, 1);
                V v_w_2437 = heff_field(v_st_2431, 2);
                V v_ru_24st_2431_24MkSt = heff_take_reuse_n(v_st_2431, 7ULL, 3);
                V v_t_2438 = (g_heff_2eelab_2emeta_2eresolveKept(v_x_2433));
                V v_t_2439 = (g_prelude_2e_2b_2b(v_w_2437, v_t_2438));
                v_t_2440 = heff_tag_at_n(v_ru_24st_2431_24MkSt, TAG_MkSt, 3, (V[]){v_c_2435, v_d_2436, v_t_2439});
                break;
              }
              default: heff_nomatch(v_st_2431);
              }
              v_x1_2441 = heff_tag_at_n(v_ru_24t_2415_24Cons, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_245_24Right, TAG_Right, 1, (V[]){v_t_2434}), v_t_2440});
              break;
            }
            default: heff_nomatch(v_x11_2430);
            }
          }
          break;
        }
        default: heff_nomatch(v_t_2415);
        }
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_MkPair: {
          V v_x11_2442 = heff_field(v_x1_2441, 0);
          V v_st_2443 = heff_field(v_x1_2441, 1);
          heff_take_n(v_x1_2441, 3ULL, 2);
          switch (heff_tag_of(v_x11_2442)) {
          case TAG_Left: {
            V v_e_2444 = heff_field(v_x11_2442, 0);
            V v_ru_24x11_2442_24Left = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
            heff_drop(v_all_240);
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2442_24Left, TAG_Left, 1, (V[]){v_e_2444}), v_st_2443}});
          }
          case TAG_Right: {
            V v_x_2445 = heff_field(v_x11_2442, 0);
            V v_ru_24x11_2442_24Right = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
            if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
              heff_drop(v_x_2445);
              heff_drop_cell(v_ru_24x11_2442_24Right, 1);
              V t_0 = v_all_240;
              V t_1 = v_st_2443;
              v_all_240 = t_0;
              v_st_241 = t_1;
              goto top;
            } else {
              heff_drop(v_all_240);
              heff_drop(v_x_2445);
              V v_t_2446 = heff_tag_at_n(v_ru_24x11_2442_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
              return ((HeffT2){{v_t_2446, v_st_2443}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2442)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2441)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
}
V g_heff_2eelab_2emeta_2edeferAlg_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2edeferAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2edeferAlg_entry, 2, 0};

V g_heff_2eelab_2emeta_2edeferAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Delay: {
    V v_ty_242 = heff_field(v_x1_240, 0);
    V v_c_243 = heff_field(v_x1_240, 1);
    V v_x_244 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24Delay = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_249;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_245 = heff_field(v_p_241, 0);
      V v_d_246 = heff_field(v_p_241, 1);
      V v_w_247 = heff_field(v_p_241, 2);
      V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 7ULL, 3);
      V v_t_248 = heff_tag_at_n(v_ru_24x1_240_24Delay, TAG_MkDelayed, 3, (V[]){v_ty_242, v_c_243, NTAG(TAG_Nothing)});
      v_t_249 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_d_246}), v_w_247});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_244}), v_t_249});
  }
  case TAG_DelayGuessing: {
    V v_ty_2410 = heff_field(v_x1_240, 0);
    V v_c_2411 = heff_field(v_x1_240, 1);
    V v_gs_2412 = heff_field(v_x1_240, 2);
    V v_x_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2418;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_2414 = heff_field(v_p_241, 0);
      V v_d_2415 = heff_field(v_p_241, 1);
      V v_w_2416 = heff_field(v_p_241, 2);
      V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 7ULL, 3);
      V v_t_2417 = heff_tag_n(TAG_MkDelayed, 3, (V[]){v_ty_2410, v_c_2411, heff_tag_n(TAG_Just, 1, (V[]){v_gs_2412})});
      v_t_2418 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_d_2415}), v_w_2416});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2413}), v_t_2418});
  }
  case TAG_Guess: {
    V v_k_2419 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Guess = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_d_2421 = heff_dup(heff_field(v_p_241, 1));
      v_t_2423 = v_d_2421;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2423));
    HeffT2 v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_p_241; HeffT2 r_ = (g_heff_2eelab_2emeta_2eguessS_24cpr(a_0, a_1)); heff_drop(v_t_2424); r_; });
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_x11_2428 = v_field_2426;
      V v_st_2429 = v_field_2427;
      switch (heff_tag_of(v_x11_2428)) {
      case TAG_Left: {
        V v_e_2430 = heff_field(v_x11_2428, 0);
        heff_take_n(v_x11_2428, 1ULL, 1);
        heff_drop(v_k_2419);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Guess, TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
      }
      case TAG_Right: {
        V v_x_2431 = heff_field(v_x11_2428, 0);
        heff_take_n(v_x11_2428, 1ULL, 1);
        V v_t_2432 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_x_2431}));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Guess, TAG_Right, 1, (V[]){v_t_2432}), v_st_2429});
      }
      default: return heff_nomatch(v_x11_2428);
      }
    }
  }
  case TAG_CanGuess: {
    V v_k_2433 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CanGuess = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2437;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_2434 = heff_dup(heff_field(v_p_241, 0));
      v_t_2437 = v_c_2434;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_mc_2438 = heff_get_n(v_t_2437, 3, 9);
    V v_ds_2442;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_d_2440 = heff_dup(heff_field(v_p_241, 1));
      v_ds_2442 = v_d_2440;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_2471 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2emeta_2edeferAlg_lam0, 1, 1, (V[]){v_mc_2438}); V a_1 = v_ds_2442; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ds_2442); r_; });
    V v_t_2472 = heff_tr(heff_call(v_k_2433, 1, (V[]){v_t_2471}));
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24CanGuess, TAG_Right, 1, (V[]){v_t_2472}), v_p_241});
  }
  case TAG_Want: {
    V v_sp_2473 = heff_field(v_x1_240, 0);
    V v_f_2474 = heff_field(v_x1_240, 1);
    V v_x_2475 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24Want = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2481;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_2476 = heff_field(v_p_241, 0);
      V v_d_2477 = heff_field(v_p_241, 1);
      V v_w_2478 = heff_field(v_p_241, 2);
      heff_take_n(v_p_241, 7ULL, 3);
      V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkWanted, 2, (V[]){v_sp_2473, v_f_2474}), NTAG(TAG_Nil)});
      V v_t_2480 = (g_prelude_2e_2b_2b(v_w_2478, v_t_2479));
      v_t_2481 = heff_tag_at_n(v_ru_24x1_240_24Want, TAG_MkSt, 3, (V[]){v_c_2476, v_d_2477, v_t_2480});
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2475}), v_t_2481});
  }
  case TAG_Wake: {
    V v_all_2482 = heff_field(v_x1_240, 0);
    V v_x_2483 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Wake = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2484 = (g_heff_2eelab_2emeta_2ewakeResolveS_24cpr(v_all_2482, v_p_241));
    {
      V v_field_2485 = v_t_2484.f[0];
      V v_field_2486 = v_t_2484.f[1];
      V v_x11_2487 = v_field_2485;
      V v_st_2488 = v_field_2486;
      switch (heff_tag_of(v_x11_2487)) {
      case TAG_Left: {
        V v_e_2489 = heff_field(v_x11_2487, 0);
        V v_ru_24x11_2487_24Left = heff_take_reuse_n(v_x11_2487, 1ULL, 1);
        heff_drop(v_x_2483);
        return heff_tag_at_n(v_ru_24x1_240_24Wake, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2487_24Left, TAG_Left, 1, (V[]){v_e_2489}), v_st_2488});
      }
      case TAG_Right: {
        V v_ru_24x11_2487_24Right = heff_take_reuse_n(v_x11_2487, 0ULL, 1);
        return heff_tag_at_n(v_ru_24x1_240_24Wake, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2487_24Right, TAG_Right, 1, (V[]){v_x_2483}), v_st_2488});
      }
      default: return heff_nomatch(v_x11_2487);
      }
    }
  }
  case TAG_Resolve: {
    V v_final_2491 = heff_field(v_x1_240, 0);
    V v_k_2492 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Resolve = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_final_2493 = v_final_2491;
    V v_st_2494 = v_p_241;
    V v_t_2498;
    switch (heff_tag_of(v_st_2494)) {
    case TAG_MkSt: {
      V v_w_2497 = heff_dup(heff_field(v_st_2494, 2));
      v_t_2498 = v_w_2497;
      break;
    }
    default: heff_nomatch(v_st_2494);
    }
    V v_x1_24124;
    switch (heff_tag_of(v_t_2498)) {
    case TAG_Nil: {
      heff_drop(v_final_2493);
      V v_t_2499 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
      v_x1_24124 = heff_tag_at_n(v_ru_24x1_240_24Resolve, TAG_MkPair, 2, (V[]){v_t_2499, v_st_2494});
      break;
    }
    case TAG_Cons: {
      V v_ru_24t_2498_24Cons = heff_take_reuse_n(v_t_2498, 0ULL, 2);
      V v_t_24105;
      switch (heff_tag_of(v_st_2494)) {
      case TAG_MkSt: {
        V v_w_24104 = heff_dup(heff_field(v_st_2494, 2));
        v_t_24105 = v_w_24104;
        break;
      }
      default: heff_nomatch(v_st_2494);
      }
      V v_t_24109;
      switch (heff_tag_of(v_st_2494)) {
      case TAG_MkSt: {
        V v_c_24106 = heff_field(v_st_2494, 0);
        V v_d_24107 = heff_field(v_st_2494, 1);
        V v_ru_24st_2494_24MkSt = heff_take_reuse_n(v_st_2494, 3ULL, 3);
        v_t_24109 = heff_tag_at_n(v_ru_24st_2494_24MkSt, TAG_MkSt, 3, (V[]){v_c_24106, v_d_24107, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_st_2494);
      }
      HeffT2 v_t_24110 = (g_heff_2eelab_2emeta_2eresolveListS_24s1932284354x1121394425_24cpr(v_final_2493, v_t_24105, v_t_24109));
      {
        V v_field_24111 = v_t_24110.f[0];
        V v_field_24112 = v_t_24110.f[1];
        V v_x11_24113 = v_field_24111;
        V v_st_24114 = v_field_24112;
        switch (heff_tag_of(v_x11_24113)) {
        case TAG_Left: {
          V v_e_24115 = heff_field(v_x11_24113, 0);
          V v_ru_24x11_24113_24Left = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
          heff_drop_cell(v_ru_24t_2498_24Cons, 2);
          v_x1_24124 = heff_tag_at_n(v_ru_24x1_240_24Resolve, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24113_24Left, TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
          break;
        }
        case TAG_Right: {
          V v_x_24116 = heff_field(v_x11_24113, 0);
          V v_ru_24x11_24113_24Right = heff_take_reuse_n(v_x11_24113, 1ULL, 1);
          V v_t_24117 = (g_list_2eany_24s141450647x925029990(v_x_24116));
          V v_t_24123;
          switch (heff_tag_of(v_st_24114)) {
          case TAG_MkSt: {
            V v_c_24118 = heff_field(v_st_24114, 0);
            V v_d_24119 = heff_field(v_st_24114, 1);
            V v_w_24120 = heff_field(v_st_24114, 2);
            V v_ru_24st_24114_24MkSt = heff_take_reuse_n(v_st_24114, 7ULL, 3);
            V v_t_24121 = (g_heff_2eelab_2emeta_2eresolveKept(v_x_24116));
            V v_t_24122 = (g_prelude_2e_2b_2b_24tok2(v_ru_24t_2498_24Cons, v_w_24120, v_t_24121));
            v_t_24123 = heff_tag_at_n(v_ru_24st_24114_24MkSt, TAG_MkSt, 3, (V[]){v_c_24118, v_d_24119, v_t_24122});
            break;
          }
          default: heff_nomatch(v_st_24114);
          }
          v_x1_24124 = heff_tag_at_n(v_ru_24x1_240_24Resolve, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24113_24Right, TAG_Right, 1, (V[]){v_t_24117}), v_t_24123});
          break;
        }
        default: heff_nomatch(v_x11_24113);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_2498);
    }
    switch (heff_tag_of(v_x1_24124)) {
    case TAG_MkPair: {
      V v_x11_24125 = heff_field(v_x1_24124, 0);
      V v_st_24126 = heff_field(v_x1_24124, 1);
      V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
      switch (heff_tag_of(v_x11_24125)) {
      case TAG_Left: {
        V v_e_24127 = heff_field(v_x11_24125, 0);
        V v_ru_24x11_24125_24Left = heff_take_reuse_n(v_x11_24125, 1ULL, 1);
        heff_drop(v_k_2492);
        return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24125_24Left, TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
      }
      case TAG_Right: {
        V v_x_24128 = heff_field(v_x11_24125, 0);
        V v_ru_24x11_24125_24Right = heff_take_reuse_n(v_x11_24125, 1ULL, 1);
        V v_t_24129 = heff_tr(heff_call(v_k_2492, 1, (V[]){v_x_24128}));
        return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_Right, 1, (V[]){v_t_24129}), v_st_24126});
      }
      default: return heff_nomatch(v_x11_24125);
      }
    }
    default: return heff_nomatch(v_x1_24124);
    }
  }
  case TAG_Pending: {
    V v_k_24130 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Pending = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24134;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_c_24131 = heff_dup(heff_field(v_p_241, 0));
      v_t_24134 = v_c_24131;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_24138;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_d_24136 = heff_dup(heff_field(v_p_241, 1));
      v_t_24138 = v_d_24136;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_24139 = ({ V b_0 = heff_get_n(v_t_24134, 3, 9); V a_1 = v_t_24138; V r_ = (g_heff_2eelab_2emeta_2eanyDelayed(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24138); r_; });
    V v_t_24140 = heff_tr(heff_call(v_k_24130, 1, (V[]){v_t_24139}));
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Pending, TAG_Right, 1, (V[]){v_t_24140}), v_p_241});
  }
  case TAG_SaveDelayed: {
    V v_k_24141 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SaveDelayed = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24145;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_d_24143 = heff_dup(heff_field(v_p_241, 1));
      v_t_24145 = v_d_24143;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_24149;
    switch (heff_tag_of(v_p_241)) {
    case TAG_MkSt: {
      V v_w_24148 = heff_dup(heff_field(v_p_241, 2));
      v_t_24149 = v_w_24148;
      break;
    }
    default: heff_nomatch(v_p_241);
    }
    V v_t_24150 = heff_tr(heff_call(v_k_24141, 1, (V[]){heff_tag_n(TAG_MkSaved, 2, (V[]){v_t_24145, v_t_24149})}));
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SaveDelayed, TAG_Right, 1, (V[]){v_t_24150}), v_p_241});
  }
  case TAG_RestoreDelayed: {
    V v_sv_24151 = heff_field(v_x1_240, 0);
    V v_x_24152 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RestoreDelayed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_24158;
    switch (heff_tag_of(v_sv_24151)) {
    case TAG_MkSaved: {
      V v_ds_24153 = heff_field(v_sv_24151, 0);
      heff_take_n(v_sv_24151, 1ULL, 2);
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_c_24155 = heff_field(v_p_241, 0);
        V v_w_24157 = heff_field(v_p_241, 2);
        V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 5ULL, 3);
        v_t_24158 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_24155, v_ds_24153, v_w_24157});
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      break;
    }
    default: heff_nomatch(v_sv_24151);
    }
    return heff_tag_at_n(v_ru_24x1_240_24RestoreDelayed, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_t_24158});
  }
  case TAG_RestoreWaiting: {
    V v_sv_24159 = heff_field(v_x1_240, 0);
    V v_x_24160 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24RestoreWaiting = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_24166;
    switch (heff_tag_of(v_sv_24159)) {
    case TAG_MkSaved: {
      V v_ds_24161 = heff_field(v_sv_24159, 0);
      V v_ws_24162 = heff_field(v_sv_24159, 1);
      heff_take_n(v_sv_24159, 3ULL, 2);
      switch (heff_tag_of(v_p_241)) {
      case TAG_MkSt: {
        V v_c_24163 = heff_field(v_p_241, 0);
        V v_ru_24p_241_24MkSt = heff_take_reuse_n(v_p_241, 1ULL, 3);
        v_t_24166 = heff_tag_at_n(v_ru_24p_241_24MkSt, TAG_MkSt, 3, (V[]){v_c_24163, v_ds_24161, v_ws_24162});
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      break;
    }
    default: heff_nomatch(v_sv_24159);
    }
    return heff_tag_at_n(v_ru_24x1_240_24RestoreWaiting, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24160}), v_t_24166});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2emeta_2edeferAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2edeferAlg(a[0], a[1]);
}
V g_heff_2eelab_2emeta_2edeferAlg_lam0(V self, V *args) {
  V v_d_2443 = args[0];
  V v_mc_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_d_2443)) {
  case TAG_MkDelayed: {
    V v_ty_2444 = heff_field(v_d_2443, 0);
    V v_gs_2446 = heff_field(v_d_2443, 2);
    heff_take_n(v_d_2443, 5ULL, 3);
    V v_t_2447 = ({ V a_0 = v_mc_2438; V a_1 = v_ty_2444; V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_mc_2438); r_; });
    switch (heff_tag_of(v_t_2447)) {
    case TAG_VU: {
      heff_take_n(v_t_2447, 0ULL, 1);
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_t1_2449 = heff_field(v_t_2447, 0);
      heff_take_n(v_t_2447, 1ULL, 5);
      switch (heff_tag_of(v_t1_2449)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2449, 0ULL, 1);
        heff_drop(v_gs_2446);
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2449, 0ULL, 1);
        heff_drop(v_gs_2446);
        return NTAG(TAG_False);
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2449, 0ULL, 1);
        switch (heff_tag_of(v_gs_2446)) {
        case TAG_Nothing: {
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          heff_take_n(v_gs_2446, 0ULL, 1);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_gs_2446);
        }
      }
      case TAG_HError: {
        heff_drop(v_gs_2446);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t1_2449);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_2447, 0ULL, 6);
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      heff_take_n(v_t_2447, 0ULL, 4);
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      heff_take_n(v_t_2447, 0ULL, 1);
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_2447, 0ULL, 1);
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      heff_take_n(v_t_2447, 0ULL, 1);
      heff_drop(v_gs_2446);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  default: return heff_nomatch(v_d_2443);
  }
}
V g_heff_2eelab_2emeta_2eelabH_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eelabH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eelabH_lam0, 2, 0};
V g_heff_2eelab_2emeta_2eelabH_lam1(V self, V *args); static Clo g_heff_2eelab_2emeta_2eelabH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eelabH_lam1, 3, 0};
V g_heff_2eelab_2emeta_2eelabH_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2eelabH_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eelabH_lam2, 2, 0};

static V g_heff_2eelab_2emeta_2eelabH_val;
static HEFF_ONCE g_heff_2eelab_2emeta_2eelabH_st;
static V g_heff_2eelab_2emeta_2eelabH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2eelab_2emeta_2eelabH_lam0_clo), ((V)&g_heff_2eelab_2emeta_2eelabH_lam1_clo), ((V)&g_heff_2eelab_2emeta_2eelabH_lam2_clo)});
}
V g_heff_2eelab_2emeta_2eelabH_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2emeta_2eelabH_st)) return g_heff_2eelab_2emeta_2eelabH_val;
  return heff_global(&g_heff_2eelab_2emeta_2eelabH_val, &g_heff_2eelab_2emeta_2eelabH_st, g_heff_2eelab_2emeta_2eelabH_init);
}
V g_heff_2eelab_2emeta_2eelabH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_st_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_st_241});
}
V g_heff_2eelab_2emeta_2eelabH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_st_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Left, TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2emeta_2eelabH_lam2(V self, V *args) {
  V v_p_2410 = args[0];
  V v_p_2411 = args[1];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_p_2412 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    switch (heff_tag_of(v_p_2412)) {
    case TAG_InL: {
      V v_p_2413 = heff_field(v_p_2412, 0);
      heff_take_n(v_p_2412, 1ULL, 1);
      V v_x1_2414 = v_p_2413;
      V v_p_2415 = v_p_2411;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_InL: {
        V v_t_2416 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Get: {
          V v_k_2417 = heff_field(v_t_2416, 0);
          heff_take_n(v_t_2416, 1ULL, 1);
          V v_t_2421;
          switch (heff_tag_of(v_p_2415)) {
          case TAG_MkSt: {
            V v_c_2418 = heff_dup(heff_field(v_p_2415, 0));
            v_t_2421 = v_c_2418;
            break;
          }
          default: heff_nomatch(v_p_2415);
          }
          V v_t_2422 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_t_2421}));
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24p_2410_24InL, TAG_Right, 1, (V[]){v_t_2422}), v_p_2415});
        }
        case TAG_Put: {
          V v_c_2423 = heff_field(v_t_2416, 0);
          V v_x_2424 = heff_field(v_t_2416, 1);
          V v_ru_24t_2416_24Put = heff_take_reuse_n(v_t_2416, 3ULL, 2);
          V v_t_2428;
          switch (heff_tag_of(v_p_2415)) {
          case TAG_MkSt: {
            V v_d_2426 = heff_field(v_p_2415, 1);
            V v_w_2427 = heff_field(v_p_2415, 2);
            V v_ru_24p_2415_24MkSt = heff_take_reuse_n(v_p_2415, 6ULL, 3);
            v_t_2428 = heff_tag_at_n(v_ru_24p_2415_24MkSt, TAG_MkSt, 3, (V[]){v_c_2423, v_d_2426, v_w_2427});
            break;
          }
          default: heff_nomatch(v_p_2415);
          }
          return heff_tag_at_n(v_ru_24t_2416_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24p_2410_24InL, TAG_Right, 1, (V[]){v_x_2424}), v_t_2428});
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      case TAG_InR: {
        V v_q_2429 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        switch (heff_tag_of(v_q_2429)) {
        case TAG_Throw: {
          V v_d_2430 = heff_field(v_q_2429, 0);
          heff_take_n(v_q_2429, 1ULL, 1);
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24p_2410_24InL, TAG_Left, 1, (V[]){v_d_2430}), v_p_2415});
        }
        case TAG_Catch: {
          V v_c_2431 = heff_field(v_q_2429, 0);
          V v_h_2432 = heff_field(v_q_2429, 1);
          V v_ru_24q_2429_24Catch = heff_take_reuse_n(v_q_2429, 3ULL, 2);
          V v_x2_2433 = heff_tr(heff_call(v_c_2431, 1, (V[]){v_p_2415}));
          switch (heff_tag_of(v_x2_2433)) {
          case TAG_MkPair: {
            V v_x21_2434 = heff_field(v_x2_2433, 0);
            V v_st_2435 = heff_field(v_x2_2433, 1);
            heff_take_n(v_x2_2433, 3ULL, 2);
            switch (heff_tag_of(v_x21_2434)) {
            case TAG_Left: {
              V v_e_2436 = heff_field(v_x21_2434, 0);
              heff_take_n(v_x21_2434, 1ULL, 1);
              heff_drop_cell(v_ru_24p_2410_24InL, 1);
              heff_drop_cell(v_ru_24q_2429_24Catch, 2);
              V f_ = v_h_2432;
              args[0] = v_e_2436;
              args[1] = v_st_2435;
              if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 2, args);
            }
            case TAG_Right: {
              V v_x_2437 = heff_field(v_x21_2434, 0);
              heff_take_n(v_x21_2434, 1ULL, 1);
              heff_drop(v_h_2432);
              return heff_tag_at_n(v_ru_24q_2429_24Catch, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24p_2410_24InL, TAG_Right, 1, (V[]){v_x_2437}), v_st_2435});
            }
            default: return heff_nomatch(v_x21_2434);
            }
          }
          default: return heff_nomatch(v_x2_2433);
          }
        }
        default: return heff_nomatch(v_q_2429);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_InR: {
      V v_q_2438 = heff_field(v_p_2412, 0);
      heff_take_n(v_p_2412, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2410_24InL, 1);
      return (g_heff_2eelab_2emeta_2edeferAlg(v_q_2438, v_p_2411));
    }
    default: return heff_nomatch(v_p_2412);
    }
  }
  case TAG_InR: {
    V v_q_2439 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_x1_2440 = v_q_2439;
    V v_p_2441 = v_p_2411;
    switch (heff_tag_of(v_x1_2440)) {
    case TAG_Trace: {
      V v_ev_2442 = heff_field(v_x1_2440, 0);
      V v_x_2443 = heff_field(v_x1_2440, 1);
      V v_ru_24x1_2440_24Trace = heff_take_reuse_n(v_x1_2440, 3ULL, 2);
      V v_t_2449;
      switch (heff_tag_of(v_p_2441)) {
      case TAG_MkSt: {
        V v_c_2444 = heff_field(v_p_2441, 0);
        V v_d_2445 = heff_field(v_p_2441, 1);
        V v_w_2446 = heff_field(v_p_2441, 2);
        V v_ru_24p_2441_24MkSt = heff_take_reuse_n(v_p_2441, 7ULL, 3);
        V v_t_2447 = heff_tag_at_n(v_ru_24x1_2440_24Trace, TAG_Cons, 2, (V[]){v_ev_2442, heff_dup(heff_rfield(v_c_2444, 6))});
        V v_t_2448 = ({ V rv_6 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_c_2444, 447ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
        v_t_2449 = heff_tag_at_n(v_ru_24p_2441_24MkSt, TAG_MkSt, 3, (V[]){v_t_2448, v_d_2445, v_w_2446});
        break;
      }
      default: heff_nomatch(v_p_2441);
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24p_2410_24InR, TAG_Right, 1, (V[]){v_x_2443}), v_t_2449});
    }
    case TAG_Record: {
      V v_i_2450 = heff_field(v_x1_2440, 0);
      V v_x_2451 = heff_field(v_x1_2440, 1);
      V v_ru_24x1_2440_24Record = heff_take_reuse_n(v_x1_2440, 3ULL, 2);
      V v_t_2457;
      switch (heff_tag_of(v_p_2441)) {
      case TAG_MkSt: {
        V v_c_2452 = heff_field(v_p_2441, 0);
        V v_d_2453 = heff_field(v_p_2441, 1);
        V v_w_2454 = heff_field(v_p_2441, 2);
        V v_ru_24p_2441_24MkSt = heff_take_reuse_n(v_p_2441, 7ULL, 3);
        V v_t_2455 = heff_tag_at_n(v_ru_24x1_2440_24Record, TAG_Cons, 2, (V[]){v_i_2450, heff_dup(heff_rfield(v_c_2452, 0))});
        V v_t_2456 = ({ V rv_0 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_c_2452, 510ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        v_t_2457 = heff_tag_at_n(v_ru_24p_2441_24MkSt, TAG_MkSt, 3, (V[]){v_t_2456, v_d_2453, v_w_2454});
        break;
      }
      default: heff_nomatch(v_p_2441);
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24p_2410_24InR, TAG_Right, 1, (V[]){v_x_2451}), v_t_2457});
    }
    default: return heff_nomatch(v_x1_2440);
    }
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_heff_2eelab_2emeta_2eapproximateFirst_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2eapproximateFirst_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eapproximateFirst_lam0, 2, 0};
V g_heff_2eelab_2emeta_2eapproximateFirst_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eapproximateFirst_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2eapproximateFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eapproximateFirst_entry, 2, 0};

V g_heff_2eelab_2emeta_2eapproximateFirst(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2emeta_2eapproximateFirst_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_failed_246 = heff_dup(heff_rfield(v_p_244, 3));
    V v_shape_247 = heff_dup(heff_rfield(v_p_244, 0));
    V v_left_248 = heff_dup(heff_rfield(v_p_244, 1));
    V v_right_249 = heff_dup(heff_rfield(v_p_244, 2));
    if ((heff_dup(v_failed_246) == NTAG(TAG_True))) {
      heff_drop(v_failed_246);
      heff_drop(v_shape_247);
      heff_drop(v_left_248);
      heff_drop(v_right_249);
      V t_0 = v_g_240;
      V t_1 = v_rest_245;
      v_g_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_failed_246);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2eapproximate_24s1457654632x96757009_clo), 4, (V[]){heff_dup(v_g_240), v_shape_247, v_left_248, v_right_249}));
      V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2eliftU_clo), 1, (V[]){v_t_2410}));
      return heff_clo_n(g_heff_2eelab_2emeta_2eapproximateFirst_lam1, 2, 3, (V[]){v_t_2411, v_g_240, heff_dup(v_rest_245)});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2emeta_2eapproximateFirst_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2emeta_2eapproximateFirst(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2emeta_2eapproximateFirst_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2eapproximateFirst_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_t_2416 = ({ V a_0 = v_g_240; V a_1 = v_rest_245; V r_ = (g_heff_2eelab_2emeta_2eapproximateFirst(a_0, a_1)); heff_drop(v_rest_245); r_; });
    V f_ = v_t_2416;
    heff_room[0] = v_hd_2412;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_b_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    if ((heff_dup(v_b_2417) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_rest_245);
      heff_drop(v_hd_2412);
      heff_drop(v_b_2417);
      V f_ = v_k_2413;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_b_2417);
      V v_t_2418 = ({ V a_0 = v_g_240; V a_1 = v_rest_245; V r_ = (g_heff_2eelab_2emeta_2eapproximateFirst(a_0, a_1)); heff_drop(v_rest_245); r_; });
      V f_ = v_t_2418;
      heff_room[0] = v_hd_2412;
      heff_room[1] = v_k_2413;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2eelab_2emeta_2eapproximateFirst_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2411 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2emeta_2eattempt(v_t_2411, heff_dup(v_hd_2412), heff_clo_n(g_heff_2eelab_2emeta_2eapproximateFirst_lam2, 1, 4, (V[]){v_g_240, v_rest_245, v_hd_2412, v_k_2413})));
}
V g_heff_2eelab_2emeta_2eforceAll_lam1(V self, V *args); static Clo g_heff_2eelab_2emeta_2eforceAll_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eforceAll_lam1, 1, 0};
V g_heff_2eelab_2emeta_2eforceAll_lam2(V self, V *args);
V g_heff_2eelab_2emeta_2eforceAll_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2eforceAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2eforceAll_entry, 3, 0};

V g_heff_2eelab_2emeta_2eforceAll(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_True), NTAG(TAG_MkUnit)});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2emeta_2eforceAll_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2eelab_2emeta_2eforceAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2eforceAll(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2eforceAll_lam1(V self, V *args) {
  V v_b_247 = args[0];
  return v_b_247;
}
V g_heff_2eelab_2emeta_2eforceAll_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  return (g_heff_2eelab_2emeta_2eretryGo(v_g_240, MK_INT(0LL), v_hd_241, v_k_242));
}
V g_heff_2eelab_2emeta_2eforceAll_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_246);
  V v_t_248 = heff_tag_n(TAG_Resolve, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2eelab_2emeta_2eforceAll_lam1_clo)});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2eforceAll_lam2, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2ecleanly_lam1(V self, V *args);
V g_heff_2eelab_2emeta_2ecleanly_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2ecleanly_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2ecleanly_lam2, 1, 0};
V g_heff_2eelab_2emeta_2ecleanly_lam4(V self, V *args);
V g_heff_2eelab_2emeta_2ecleanly_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2ecleanly_lam0(V self, V *args);
V g_heff_2eelab_2emeta_2ecleanly_lam5(V self, V *args);
Clo g_heff_2eelab_2emeta_2ecleanly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2ecleanly_entry, 3, 0};

V g_heff_2eelab_2emeta_2ecleanly(V v_m_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_k_243 = heff_dup(heff_rfield(v_hd_241, 0));
  V v_t_2426 = heff_tr(heff_call(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2emeta_2ecleanly_lam0, 1, 2, (V[]){heff_dup(v_hd_241), v_k_243})}));
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2426, heff_clo_n(g_heff_2eelab_2emeta_2ecleanly_lam5, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2429}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2430, v_k2_242});
}
V g_heff_2eelab_2emeta_2ecleanly_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2ecleanly(a[0], a[1], a[2]);
}
V g_heff_2eelab_2emeta_2ecleanly_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248;
  if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_x_244});
  } else {
    heff_drop(v_x_247);
    heff_drop(v_x_244);
    v_t_248 = NTAG(TAG_Nothing);
  }
  V f_ = v_k_243;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2ecleanly_lam2(V self, V *args) {
  V v_c_2410 = args[0];
  V v_t_2411 = heff_get_n(v_c_2410, 1, 9);
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2411, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eelab_2emeta_2ecleanly_lam4(V self, V *args) {
  V v_unsolved_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_left_245 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2419);
  V v_t_2425;
  switch (heff_tag_of(v_left_245)) {
  case TAG_Nil: {
    if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
      heff_drop(v_x_2417);
      switch (heff_tag_of(v_unsolved_2418)) {
      case TAG_Nil: {
        v_t_2425 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_unsolved_2418, 0ULL, 2);
        v_t_2425 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_unsolved_2418);
      }
    } else {
      heff_drop(v_unsolved_2418);
      heff_drop(v_x_2417);
      v_t_2425 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_left_245, 0ULL, 2);
    heff_drop(v_unsolved_2418);
    heff_drop(v_x_2417);
    v_t_2425 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_left_245);
  }
  V f_ = v_k_2420;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2ecleanly_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_left_245 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2ebind_24s1831149655x1541910000(heff_clo_n(g_heff_2eelab_2emeta_2ecleanly_lam4, 3, 2, (V[]){v_left_245, v_x_2417}), v_hd_246, v_k_249));
}
V g_heff_2eelab_2emeta_2ecleanly_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_left_245 = heff_dup(v_x_244);
  V v_hd_246 = v_hd_241;
  V v_k_249 = heff_clo_n(g_heff_2eelab_2emeta_2ecleanly_lam1, 1, 2, (V[]){v_x_244, v_k_243});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2ecleanly_lam2_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2415}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2ecleanly_lam3, 1, 3, (V[]){v_left_245, v_hd_246, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2ecleanly_lam5(V self, V *args) {
  V v_s_2427 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_s_2427);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2elastResort_lam0(V self, V *args); static Clo g_heff_2eelab_2emeta_2elastResort_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_lam0, 1, 0};
V g_heff_2eelab_2emeta_2elastResort_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2elastResort_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_lam2, 1, 0};
V g_heff_2eelab_2emeta_2elastResort_lam4(V self, V *args); static Clo g_heff_2eelab_2emeta_2elastResort_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_lam4, 1, 0};
V g_heff_2eelab_2emeta_2elastResort_lam6(V self, V *args); static Clo g_heff_2eelab_2emeta_2elastResort_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_lam6, 1, 0};
V g_heff_2eelab_2emeta_2elastResort_lam11(V self, V *args); static Clo g_heff_2eelab_2emeta_2elastResort_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_lam11, 1, 0};
V g_heff_2eelab_2emeta_2elastResort_lam13(V self, V *args); static Clo g_heff_2eelab_2emeta_2elastResort_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_lam13, 2, 0};
V g_heff_2eelab_2emeta_2elastResort_lam16(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam15(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam14(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam12(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam10(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam9(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam8(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam7(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam5(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2elastResort_lam1(V self, V *args);
Clo g_heff_2eelab_2emeta_2elastResort_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2elastResort_entry, 5, 0};

V g_heff_2eelab_2emeta_2elastResort(V v_again_240, V v_g_241, V v_fuel_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_CanGuess, 1, (V[]){((V)&g_heff_2eelab_2emeta_2elastResort_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam1, 1, 5, (V[]){v_hd_243, v_fuel_242, v_g_241, v_k_244, v_again_240})});
}
V g_heff_2eelab_2emeta_2elastResort_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2elastResort(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2emeta_2elastResort_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2eelab_2emeta_2elastResort_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_t_2410 = heff_get_n(v_c_249, 1, 9);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2410, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eelab_2emeta_2elastResort_lam4(V self, V *args) {
  V v_c_2417 = args[0];
  return v_c_2417;
}
V g_heff_2eelab_2emeta_2elastResort_lam6(V self, V *args) {
  V v_sv_2422 = args[0];
  return v_sv_2422;
}
V g_heff_2eelab_2emeta_2elastResort_lam11(V self, V *args) {
  V v_b_2436 = args[0];
  return v_b_2436;
}
V g_heff_2eelab_2emeta_2elastResort_lam13(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2emeta_2elastResort_lam16(V self, V *args) {
  V v_x_2452 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2452);
  return (g_heff_2eelab_2emeta_2eforceAll(v_g_241, v_hd_243, v_k_244));
}
V g_heff_2eelab_2emeta_2elastResort_lam15(V self, V *args) {
  V v_x_2448 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2425, NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2450}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2451;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam16, 1, 3, (V[]){v_g_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2elastResort_lam14(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2444)) {
  case TAG_Nothing: {
    V v_t_2445 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})}));
    V f_ = heff_dup(heff_rfield(v_hd_243, 1));
    heff_room[0] = v_t_2447;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam15, 1, 4, (V[]){v_x_2425, v_hd_243, v_g_241, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_left_2453 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    heff_drop(v_x_2421);
    heff_drop_rec(v_hd_243, 3);
    heff_drop(v_x_2425);
    heff_drop(v_g_241);
    V f_ = v_k_244;
    args[0] = v_left_2453;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2444);
  }
}
V g_heff_2eelab_2emeta_2elastResort_lam12(V self, V *args) {
  V v_x_2439 = args[0];
  V v_again_240 = heff_env(self)[0];
  V v_fuel_242 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2443;
  if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    V v_t_2440 = heff_tr(heff_call(v_again_240, 1, (V[]){heff_intAdd(v_fuel_242, MK_INT(1LL))}));
    v_c_2443 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2ecleanly_clo), 1, (V[]){v_t_2440}));
  } else {
    heff_drop(v_x_2439);
    heff_drop(v_again_240);
    heff_drop(v_fuel_242);
    v_c_2443 = ((V)&g_heff_2eelab_2emeta_2elastResort_lam13_clo);
  }
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam14, 1, 5, (V[]){v_x_2421, v_hd_243, v_x_2425, v_g_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2elastResort_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_again_240 = heff_env(self)[1];
  V v_fuel_242 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2435);
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Guess, 1, (V[]){((V)&g_heff_2eelab_2emeta_2elastResort_lam11_clo)})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam12, 1, 7, (V[]){v_again_240, v_fuel_242, v_hd_243, v_x_2421, v_x_2425, v_g_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2elastResort_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_again_240 = heff_env(self)[2];
  V v_fuel_242 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2433}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2434;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam10, 1, 7, (V[]){v_hd_243, v_again_240, v_fuel_242, v_x_2421, v_x_2425, v_g_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2elastResort_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_again_240 = heff_env(self)[3];
  V v_fuel_242 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Nothing: {
    V v_t_2428 = heff_tag_n(TAG_Put, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})}));
    V f_ = heff_dup(heff_rfield(v_hd_243, 1));
    heff_room[0] = v_t_2430;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam9, 1, 7, (V[]){v_x_2425, v_hd_243, v_again_240, v_fuel_242, v_x_2421, v_g_241, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_left_2454 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    heff_drop(v_x_2421);
    heff_drop_rec(v_hd_243, 3);
    heff_drop(v_x_2425);
    heff_drop(v_again_240);
    heff_drop(v_fuel_242);
    heff_drop(v_g_241);
    V f_ = v_k_244;
    args[0] = v_left_2454;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2eelab_2emeta_2elastResort_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_again_240 = heff_env(self)[3];
  V v_fuel_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2emeta_2eforceAll_clo), 1, (V[]){heff_dup(v_g_241)}));
  return (g_heff_2eelab_2emeta_2ecleanly(v_t_2426, heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam8, 1, 7, (V[]){v_x_2421, v_hd_243, v_x_2425, v_again_240, v_fuel_242, v_g_241, v_k_244})));
}
V g_heff_2eelab_2emeta_2elastResort_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_again_240 = heff_env(self)[2];
  V v_fuel_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2emeta_2elastResort_lam6_clo)})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam7, 1, 6, (V[]){v_g_241, v_hd_243, v_x_2421, v_again_240, v_fuel_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2elastResort_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_fuel_242 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_again_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (((heff_dup(v_x_248) == NTAG(TAG_True)) ? ((heff_dup(v_x_2416) == NTAG(TAG_True)) ? heff_intLt_c_lent(MK_INT(50LL), v_fuel_242, 1) : 1) : 1)) {
    heff_drop(v_x_2416);
    heff_drop(v_x_248);
    heff_drop(v_fuel_242);
    heff_drop(v_again_240);
    return (g_heff_2eelab_2emeta_2eforceAll(v_g_241, v_hd_243, v_k_244));
  } else {
    heff_drop(v_x_2416);
    heff_drop(v_x_248);
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2elastResort_lam4_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2419}));
    V f_ = heff_dup(heff_rfield(v_hd_243, 1));
    heff_room[0] = v_t_2420;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam5, 1, 5, (V[]){v_hd_243, v_g_241, v_again_240, v_fuel_242, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2emeta_2elastResort_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_fuel_242 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_again_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2elastResort_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2elastResort_lam3, 1, 6, (V[]){v_x_248, v_fuel_242, v_g_241, v_hd_243, v_k_244, v_again_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam2(V self, V *args); static Clo g_heff_2eelab_2emeta_2esettleGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_lam2, 1, 0};
V g_heff_2eelab_2emeta_2esettleGo_lam4(V self, V *args); static Clo g_heff_2eelab_2emeta_2esettleGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_lam4, 1, 0};
V g_heff_2eelab_2emeta_2esettleGo_lam6(V self, V *args); static Clo g_heff_2eelab_2emeta_2esettleGo_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_lam6, 1, 0};
V g_heff_2eelab_2emeta_2esettleGo_lam9(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam8(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam7(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam5(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam3(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam1(V self, V *args);
V g_heff_2eelab_2emeta_2esettleGo_lam0(V self, V *args);
Clo g_heff_2eelab_2emeta_2esettleGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2emeta_2esettleGo_entry, 4, 0};

V g_heff_2eelab_2emeta_2esettleGo(V v_g_240, V v_fuel_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wake, 2, (V[]){NTAG(TAG_False), NTAG(TAG_MkUnit)});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_fuel_241, v_k_243})});
}
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2emeta_2esettleGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2emeta_2esettleGo_lam2(V self, V *args) {
  V v_b_249 = args[0];
  return v_b_249;
}
V g_heff_2eelab_2emeta_2esettleGo_lam4(V self, V *args) {
  V v_b_2414 = args[0];
  return v_b_2414;
}
V g_heff_2eelab_2emeta_2esettleGo_lam6(V self, V *args) {
  V v_c_2418 = args[0];
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_2418, 5, 9)));
}
V g_heff_2eelab_2emeta_2esettleGo_lam9(V self, V *args) {
  V v_f_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = ((V)&g_heff_2eelab_2emeta_2esettleGo_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_f_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_fuel_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (((heff_dup(v_x_2424) == NTAG(TAG_True)) && heff_intLe_c_lent(v_fuel_241, MK_INT(50LL), 2))) {
    heff_drop(v_x_2424);
    return (g_heff_2eelab_2emeta_2esettleGo(v_g_240, heff_intAdd(v_fuel_241, MK_INT(1LL)), v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_2424);
    return (g_heff_2eelab_2emeta_2elastResort(heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam9, 1, 1, (V[]){heff_dup(v_g_240)}), v_g_240, v_fuel_241, v_hd_242, v_k_243));
  }
}
V g_heff_2eelab_2emeta_2esettleGo_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2423 = ({ V a_0 = heff_dup(v_g_240); V a_1 = v_x_2422; V r_ = (g_heff_2eelab_2emeta_2eapproximateFirst(a_0, a_1)); heff_drop(v_x_2422); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam8, 1, 4, (V[]){v_fuel_241, v_g_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((((heff_dup(v_x_2417) == NTAG(TAG_True)) || (heff_dup(v_x_2413) == NTAG(TAG_True))) && heff_intLe_c_lent(v_fuel_241, MK_INT(50LL), 2))) {
    heff_drop(v_x_2417);
    heff_drop(v_x_2413);
    return (g_heff_2eelab_2emeta_2esettleGo(v_g_240, heff_intAdd(v_fuel_241, MK_INT(1LL)), v_hd_242, v_k_243));
  } else {
    heff_drop(v_x_2417);
    heff_drop(v_x_2413);
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2emeta_2esettleGo_lam6_clo)})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2420}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2421;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam7, 1, 4, (V[]){v_g_240, v_hd_242, v_fuel_241, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2emeta_2esettleGo_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Pending, 1, (V[]){((V)&g_heff_2eelab_2emeta_2esettleGo_lam4_clo)})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam5, 1, 5, (V[]){v_x_2413, v_fuel_241, v_g_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_fuel_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_t_2410 = heff_tag_n(TAG_Resolve, 2, (V[]){NTAG(TAG_False), ((V)&g_heff_2eelab_2emeta_2esettleGo_lam2_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam3, 1, 4, (V[]){v_hd_242, v_fuel_241, v_g_240, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2emeta_2esettleGo_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_fuel_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_247);
  return (g_heff_2eelab_2emeta_2eretryGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2emeta_2esettleGo_lam1, 1, 4, (V[]){v_hd_242, v_fuel_241, v_g_240, v_k_243})));
}