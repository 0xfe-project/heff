// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
static uint32_t shape_go[] = {LBL_go};
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ecompile_2eir_2efieldTyOfName(V);
V g_heff_2ecompile_2eir_2efieldTyOfName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efieldTyOfName_clo;
V g_heff_2ecompile_2eirtext_2earmD(V, V, V);
V g_heff_2ecompile_2eirtext_2earmD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmD_clo;
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
V g_heff_2ecompile_2eirtext_2ebytesH(V, V, V, V);
V g_heff_2ecompile_2eirtext_2ebytesH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ebytesH_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
V g_heff_2ecompile_2eirtext_2eexprOf(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprOf_clo;
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
V g_heff_2ecompile_2eirtext_2efixedD(V, V);
V g_heff_2ecompile_2eirtext_2efixedD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efixedD_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2eirtext_2enD(V, V);
V g_heff_2ecompile_2eirtext_2enD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_clo;
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(V);
V g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054_clo;
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2efind_24s1236173780x2048419812(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s1236173780x2048419812_entry(V self, V *a);
extern Clo g_list_2efind_24s1236173780x2048419812_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_fs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_intShow(heff_strLength_lent(v_l_244, 0));
      V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_str0), v_l_244));
      V v_rest_248 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_243, v_rest_241));
      V v_t_249 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_245, v_rest_248));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_t_249});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_arms_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_t_244, 0));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_str0), v_t_244));
      V v_rest_249 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_243, v_rest_241));
      V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_246, v_rest_249));
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_245));
      V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_vs_245, v_rest_2410));
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2413});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str10, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str11, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str12, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str13, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str14, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str15, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str16, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str17, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str18, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str19, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str21, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str55, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str56, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str0), v_x_243));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_EGlobal: {
    V v_g_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = heff_intShow(heff_strLength_lent(v_g_247, 0));
    V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str2), v_g_247));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
  }
  case TAG_ELam: {
    V v_xs_2411 = heff_field(v_x2_240, 0);
    V v_b_2412 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2413 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2412, v_rest_241));
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2411, v_rest_2413));
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2415});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str4), v_t_2416}));
  }
  case TAG_EApp: {
    V v_f_2417 = heff_field(v_x2_240, 0);
    V v_as_2418 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2418));
    V v_t_2420 = ({ V a_0 = v_as_2418; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2418); r_; });
    V v_rest_2421 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2419), v_t_2420});
    V v_t_2422 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2417, v_rest_2421));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str5), v_t_2422}));
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_a_2424 = heff_field(v_x2_240, 1);
    V v_b_2425 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2426 = heff_intShow(heff_strLength_lent(v_x_2423, 0));
    V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str6), v_x_2423));
    V v_rest_2428 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2425, v_rest_241));
    V v_t_2429 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2424, v_rest_2428));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2429})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2430);
  }
  case TAG_ERecord: {
    V v_fs_2431 = heff_field(v_x2_240, 0);
    V v_ts_2432 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2431));
    V v_xs_2434 = (g_list_2emap_24s143096761x246530315(v_ts_2432));
    V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2434));
    V v_t_2436 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2434, v_rest_241));
    V v_t_2437 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2435), v_t_2436});
    V v_t_2438 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2431, v_t_2437));
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), v_t_2438});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str8), v_t_2439}));
  }
  case TAG_EProj: {
    V v_e_2440 = heff_field(v_x2_240, 0);
    V v_l_2441 = heff_field(v_x2_240, 1);
    V v_sh_2442 = heff_field(v_x2_240, 2);
    V v_t_2443 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2444 = heff_intShow(heff_strLength_lent(v_l_2441, 0));
    V v_t_2445 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str9), v_l_2441));
    V v_s_2447;
    switch (heff_tag_of(v_t_2443)) {
    case TAG_FtFloat: {
      v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str10);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2446 = heff_field(v_t_2443, 0);
      heff_take_n(v_t_2443, 1ULL, 1);
      switch (heff_tag_of(v_w_2446)) {
      case TAG_I8: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str11);
        break;
      }
      case TAG_I16: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str12);
        break;
      }
      case TAG_I32: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str13);
        break;
      }
      case TAG_I64: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str14);
        break;
      }
      case TAG_U8: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str15);
        break;
      }
      case TAG_U16: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str16);
        break;
      }
      case TAG_U32: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str17);
        break;
      }
      case TAG_U64: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str18);
        break;
      }
      case TAG_F32: {
        v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str19);
        break;
      }
      default: heff_nomatch(v_w_2446);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str20);
      break;
    }
    case TAG_FtAny: {
      v_s_2447 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str21);
      break;
    }
    default: heff_nomatch(v_t_2443);
    }
    V v_t_2448 = heff_intShow(heff_strLength_lent(v_s_2447, 0));
    V v_t_2449 = heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str22), v_s_2447));
    V v_rest_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_rest_241});
    V v_t_2451 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2442));
    V v_t_2452 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2442, v_rest_2450));
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2451), v_t_2452});
    V v_rest_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2453});
    V v_t_2455 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2440, v_rest_2454));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str23), v_t_2455}));
  }
  case TAG_ETag: {
    V v_t_2456 = heff_field(v_x2_240, 0);
    V v_as_2457 = heff_field(v_x2_240, 1);
    V v_ts_2458 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2459 = heff_intShow(heff_strLength_lent(v_t_2456, 0));
    V v_t_2460 = heff_strAppend(v_t_2459, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str24), v_t_2456));
    V v_t_2461 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2457));
    V v_xs_2462 = (g_list_2emap_24s143096761x246530315(v_ts_2458));
    V v_t_2463 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2462));
    V v_t_2464 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2462, v_rest_241));
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2463), v_t_2464});
    V v_t_2466 = ({ V a_0 = v_as_2457; V a_1 = v_t_2465; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2457); r_; });
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2461), v_t_2466});
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2467})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2468);
  }
  case TAG_EMatch: {
    V v_s_2469 = heff_field(v_x2_240, 0);
    V v_arms_2470 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2470));
    V v_t_2472 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2470, v_rest_241));
    V v_rest_2473 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2471), v_t_2472});
    V v_t_2474 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2469, v_rest_2473));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str26), v_t_2474}));
  }
  case TAG_EPrim: {
    V v_p_2475 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2476 = heff_intShow(heff_strLength_lent(v_p_2475, 0));
    V v_t_2477 = heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str27), v_p_2475));
    V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2478);
  }
  case TAG_EPrimCall: {
    V v_p_2479 = heff_field(v_x2_240, 0);
    V v_as_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2481 = heff_intShow(heff_strLength_lent(v_p_2479, 0));
    V v_t_2482 = heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str29), v_p_2479));
    V v_t_2483 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2480));
    V v_t_2484 = ({ V a_0 = v_as_2480; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2480); r_; });
    V v_t_2485 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2483), v_t_2484});
    V v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, v_t_2485})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2486);
  }
  case TAG_ECall: {
    V v_g_2487 = heff_field(v_x2_240, 0);
    V v_as_2488 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2489 = heff_intShow(heff_strLength_lent(v_g_2487, 0));
    V v_t_2490 = heff_strAppend(v_t_2489, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str31), v_g_2487));
    V v_t_2491 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2488));
    V v_t_2492 = ({ V a_0 = v_as_2488; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_as_2488); r_; });
    V v_t_2493 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2491), v_t_2492});
    V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, v_t_2493})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2494);
  }
  case TAG_EInt: {
    V v_i_2495 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2496 = heff_intShow(v_i_2495);
    V v_t_2497 = heff_intShow(heff_strLength_lent(v_s_2496, 0));
    V v_t_2498 = heff_strAppend(v_t_2497, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str33), v_s_2496));
    V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2498, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2499);
  }
  case TAG_EFloat: {
    V v_x_24100 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24101 = heff_floatShow(v_x_24100);
    V v_t_24102 = heff_intShow(heff_strLength_lent(v_s_24101, 0));
    V v_t_24103 = heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str35), v_s_24101));
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24104);
  }
  case TAG_EStr: {
    V v_s_24105 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24106 = heff_intShow(heff_strLength_lent(v_s_24105, 0));
    V v_t_24107 = heff_strAppend(v_t_24106, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str37), v_s_24105));
    V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24108);
  }
  case TAG_EBytes: {
    V v_s_24109 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24110 = heff_intShow(heff_strLength_lent(v_s_24109, 0));
    V v_t_24111 = heff_strAppend(v_t_24110, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str39), v_s_24109));
    V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24112);
  }
  case TAG_EFixed: {
    V v_w_24113 = heff_field(v_x2_240, 0);
    V v_n_24114 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24115;
    switch (heff_tag_of(v_w_24113)) {
    case TAG_I8: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str41);
      break;
    }
    case TAG_I16: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str42);
      break;
    }
    case TAG_I32: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str43);
      break;
    }
    case TAG_I64: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str44);
      break;
    }
    case TAG_U8: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str45);
      break;
    }
    case TAG_U16: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str46);
      break;
    }
    case TAG_U32: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str47);
      break;
    }
    case TAG_U64: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str48);
      break;
    }
    case TAG_F32: {
      v_t_24115 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str49);
      break;
    }
    default: heff_nomatch(v_w_24113);
    }
    V v_s_24116 = heff_intShow(v_n_24114);
    V v_t_24117 = heff_intShow(heff_strLength_lent(v_s_24116, 0));
    V v_t_24118 = heff_strAppend(v_t_24117, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str50), v_s_24116));
    V v_t_24119 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24115, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str51), v_t_24119}));
  }
  case TAG_EFloat32: {
    V v_x_24120 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24121 = heff_floatShow(v_x_24120);
    V v_t_24122 = heff_intShow(heff_strLength_lent(v_s_24121, 0));
    V v_t_24123 = heff_strAppend(v_t_24122, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str52), v_s_24121));
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24124);
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str54), v_rest_241}));
  }
  case TAG_EFix: {
    V v_f_24125 = heff_field(v_x2_240, 0);
    V v_b_24126 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24127 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str55), heff_hole()});
    V v_u_24128 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_24127));
    heff_drop(v_u_24128);
    V v_t_24129 = heff_intShow(heff_strLength_lent(v_f_24125, 0));
    V v_t_24130 = heff_strAppend(v_t_24129, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str56), v_f_24125));
    V v_cell_24131 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, heff_hole()});
    V v_u_24132 = heff_setField(v_cell_24127, MK_INT(1LL), heff_dup(v_cell_24131));
    heff_drop(v_u_24132);
    V t_0 = v_b_24126;
    V t_1 = v_rest_241;
    V t_2 = v_cell_24131;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2econsD(V v_d_240, V v_more_241, V v_s_242, V v_i_243) {
top: ;
  V v_x3_244 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_242), v_i_243}));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_more_241);
    heff_drop(v_s_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_x3_248 = heff_tr(heff_call(v_more_241, 2, (V[]){v_s_242, v_j_247}));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_244_24Just, 1);
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_249 = heff_field(v_x3_248, 0);
        heff_take_n(v_x3_248, 1ULL, 1);
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          heff_take_n(v_x31_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_x_2410}), v_j_2411});
          return heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
        }
        default: return heff_nomatch(v_x31_249);
        }
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eirtext_2efieldD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldD_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2efieldD(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_s_241, v_j_246}));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_x_249}), v_j_2410});
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldD(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V v_more_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_more_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x3_247 = heff_tr(heff_call(v_more_240, 2, (V[]){v_s_241, v_j_246}));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_248 = heff_field(v_x3_247, 0);
        heff_take_n(v_x3_247, 1ULL, 1);
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          heff_take_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_x_249}), v_j_2410});
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2411});
        }
        default: return heff_nomatch(v_x31_248);
        }
      }
      default: return heff_nomatch(v_x3_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_str8, 7, "Float32");
Clo g_heff_2ecompile_2eirtext_2efixedD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efixedD_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efixedD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x1_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str0); V a_1 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str1); V a_2 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str2); V a_3 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str3); V a_4 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str4); V a_5 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str5); V a_6 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str6); V a_7 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str7); V a_8 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_str8); V a_9 = v_x_244; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind_24s1236173780x2048419812(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_j_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_j_245})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eirtext_2efixedD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efixedD(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V v_more_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_more_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_x1_247 = (g_heff_2ecompile_2eir_2efieldTyOfName(v_x_245));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Nothing: {
        heff_drop(v_more_240);
        heff_drop(v_s_241);
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_j_246);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_x3_249 = heff_tr(heff_call(v_more_240, 2, (V[]){v_s_241, v_j_246}));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_243_24Just, 1);
          heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str2, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str3, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str4, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str5, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str6, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str7, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str8, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str9, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str10, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str11, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str12, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str13, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str15, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str18, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str19, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str20, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str21, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str23, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str24, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str26, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eexprOf_str27, 1, "F");
Clo g_heff_2ecompile_2eirtext_2eexprOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprOf_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2eexprOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str0), 2)) {
    heff_drop_rec(v_k_240, 1);
    heff_drop(v_x2_241);
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_247}), v_j_248});
        return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_249});
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str1), 2)) {
      heff_drop_rec(v_k_240, 1);
      heff_drop(v_x2_241);
      V v_x3_2411 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        V v_ru_24x3_2411_24Just = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2413}), v_j_2414});
          return heff_tag_at_n(v_ru_24x3_2411_24Just, TAG_Just, 1, (V[]){v_t_2415});
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2411);
      }
    } else {
      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str2), 2)) {
        heff_drop(v_x2_241);
        V v_x3_2417 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_z_243));
        V v_x3_2422;
        switch (heff_tag_of(v_x3_2417)) {
        case TAG_Nothing: {
          v_x3_2422 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_2418 = heff_field(v_x3_2417, 0);
          heff_take_n(v_x3_2417, 1ULL, 1);
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            heff_take_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2419));
            v_x3_2422 = heff_tr(heff_call(v_t_2421, 2, (V[]){heff_dup(v_z_242), v_j_2420}));
            break;
          }
          default: heff_nomatch(v_x31_2418);
          }
          break;
        }
        default: heff_nomatch(v_x3_2417);
        }
        switch (heff_tag_of(v_x3_2422)) {
        case TAG_Nothing: {
          heff_drop_rec(v_k_240, 1);
          heff_drop(v_z_242);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2423 = heff_field(v_x3_2422, 0);
          V v_ru_24x3_2422_24Just = heff_take_reuse_n(v_x3_2422, 1ULL, 1);
          switch (heff_tag_of(v_x31_2423)) {
          case TAG_MkPair: {
            V v_x_2424 = heff_field(v_x31_2423, 0);
            V v_j_2425 = heff_field(v_x31_2423, 1);
            V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
            V v_x3_2426 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2425}));
            switch (heff_tag_of(v_x3_2426)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x3_2422_24Just, 1);
              heff_drop(v_x_2424);
              heff_drop_cell(v_ru_24x31_2423_24MkPair, 2);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2427 = heff_field(v_x3_2426, 0);
              heff_take_n(v_x3_2426, 1ULL, 1);
              switch (heff_tag_of(v_x31_2427)) {
              case TAG_MkPair: {
                V v_x_2428 = heff_field(v_x31_2427, 0);
                V v_j_2429 = heff_field(v_x31_2427, 1);
                heff_take_n(v_x31_2427, 3ULL, 2);
                V v_t_2430 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_x_2424, v_x_2428}), v_j_2429});
                return heff_tag_at_n(v_ru_24x3_2422_24Just, TAG_Just, 1, (V[]){v_t_2430});
              }
              default: return heff_nomatch(v_x31_2427);
              }
            }
            default: return heff_nomatch(v_x3_2426);
            }
          }
          default: return heff_nomatch(v_x31_2423);
          }
        }
        default: return heff_nomatch(v_x3_2422);
        }
      } else {
        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str3), 2)) {
          heff_drop(v_x2_241);
          V v_x3_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2432)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_242);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2433 = heff_field(v_x3_2432, 0);
            V v_ru_24x3_2432_24Just = heff_take_reuse_n(v_x3_2432, 1ULL, 1);
            switch (heff_tag_of(v_x31_2433)) {
            case TAG_MkPair: {
              V v_x_2434 = heff_field(v_x31_2433, 0);
              V v_j_2435 = heff_field(v_x31_2433, 1);
              V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
              V v_x3_2436 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2435));
              V v_x3_2441;
              switch (heff_tag_of(v_x3_2436)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_242);
                v_x3_2441 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2437 = heff_field(v_x3_2436, 0);
                heff_take_n(v_x3_2436, 1ULL, 1);
                switch (heff_tag_of(v_x31_2437)) {
                case TAG_MkPair: {
                  V v_x_2438 = heff_field(v_x31_2437, 0);
                  V v_j_2439 = heff_field(v_x31_2437, 1);
                  heff_take_n(v_x31_2437, 3ULL, 2);
                  V v_t_2440 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_2438));
                  v_x3_2441 = heff_tr(heff_call(v_t_2440, 2, (V[]){v_z_242, v_j_2439}));
                  break;
                }
                default: heff_nomatch(v_x31_2437);
                }
                break;
              }
              default: heff_nomatch(v_x3_2436);
              }
              switch (heff_tag_of(v_x3_2441)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x3_2432_24Just, 1);
                heff_drop(v_x_2434);
                heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2442 = heff_field(v_x3_2441, 0);
                heff_take_n(v_x3_2441, 1ULL, 1);
                switch (heff_tag_of(v_x31_2442)) {
                case TAG_MkPair: {
                  V v_x_2443 = heff_field(v_x31_2442, 0);
                  V v_j_2444 = heff_field(v_x31_2442, 1);
                  heff_take_n(v_x31_2442, 3ULL, 2);
                  V v_t_2445 = heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2434, v_x_2443}), v_j_2444});
                  return heff_tag_at_n(v_ru_24x3_2432_24Just, TAG_Just, 1, (V[]){v_t_2445});
                }
                default: return heff_nomatch(v_x31_2442);
                }
              }
              default: return heff_nomatch(v_x3_2441);
              }
            }
            default: return heff_nomatch(v_x31_2433);
            }
          }
          default: return heff_nomatch(v_x3_2432);
          }
        } else {
          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str4), 2)) {
            heff_drop(v_x2_241);
            V v_x3_2447 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
            switch (heff_tag_of(v_x3_2447)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 1);
              heff_drop(v_z_242);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2448 = heff_field(v_x3_2447, 0);
              V v_ru_24x3_2447_24Just = heff_take_reuse_n(v_x3_2447, 1ULL, 1);
              switch (heff_tag_of(v_x31_2448)) {
              case TAG_MkPair: {
                V v_x_2449 = heff_field(v_x31_2448, 0);
                V v_j_2450 = heff_field(v_x31_2448, 1);
                V v_ru_24x31_2448_24MkPair = heff_take_reuse_n(v_x31_2448, 3ULL, 2);
                V v_x3_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_j_2450}));
                switch (heff_tag_of(v_x3_2451)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_k_240, 1);
                  heff_drop(v_z_242);
                  heff_drop_cell(v_ru_24x3_2447_24Just, 1);
                  heff_drop(v_x_2449);
                  heff_drop_cell(v_ru_24x31_2448_24MkPair, 2);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2452 = heff_field(v_x3_2451, 0);
                  heff_take_n(v_x3_2451, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2452)) {
                  case TAG_MkPair: {
                    V v_x_2453 = heff_field(v_x31_2452, 0);
                    V v_j_2454 = heff_field(v_x31_2452, 1);
                    heff_take_n(v_x31_2452, 3ULL, 2);
                    V v_x3_2455 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_2454}));
                    switch (heff_tag_of(v_x3_2455)) {
                    case TAG_Nothing: {
                      heff_drop_cell(v_ru_24x3_2447_24Just, 1);
                      heff_drop(v_x_2449);
                      heff_drop_cell(v_ru_24x31_2448_24MkPair, 2);
                      heff_drop(v_x_2453);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2456 = heff_field(v_x3_2455, 0);
                      heff_take_n(v_x3_2455, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2456)) {
                      case TAG_MkPair: {
                        V v_x_2457 = heff_field(v_x31_2456, 0);
                        V v_j_2458 = heff_field(v_x31_2456, 1);
                        heff_take_n(v_x31_2456, 3ULL, 2);
                        V v_t_2459 = heff_tag_at_n(v_ru_24x31_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2449, v_x_2453, v_x_2457}), v_j_2458});
                        return heff_tag_at_n(v_ru_24x3_2447_24Just, TAG_Just, 1, (V[]){v_t_2459});
                      }
                      default: return heff_nomatch(v_x31_2456);
                      }
                    }
                    default: return heff_nomatch(v_x3_2455);
                    }
                  }
                  default: return heff_nomatch(v_x31_2452);
                  }
                }
                default: return heff_nomatch(v_x3_2451);
                }
              }
              default: return heff_nomatch(v_x31_2448);
              }
            }
            default: return heff_nomatch(v_x3_2447);
            }
          } else {
            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str5), 2)) {
              heff_drop(v_x2_241);
              V v_x3_2461 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_z_243));
              V v_x3_2467;
              switch (heff_tag_of(v_x3_2461)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                v_x3_2467 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2462 = heff_field(v_x3_2461, 0);
                heff_take_n(v_x3_2461, 1ULL, 1);
                switch (heff_tag_of(v_x31_2462)) {
                case TAG_MkPair: {
                  V v_x_2463 = heff_field(v_x31_2462, 0);
                  V v_j_2464 = heff_field(v_x31_2462, 1);
                  heff_take_n(v_x31_2462, 3ULL, 2);
                  V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2efieldD_clo), 1, (V[]){v_k_240}));
                  V v_t_2466 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_2465, v_x_2463));
                  v_x3_2467 = heff_tr(heff_call(v_t_2466, 2, (V[]){heff_dup(v_z_242), v_j_2464}));
                  break;
                }
                default: heff_nomatch(v_x31_2462);
                }
                break;
              }
              default: heff_nomatch(v_x3_2461);
              }
              switch (heff_tag_of(v_x3_2467)) {
              case TAG_Nothing: {
                heff_drop(v_z_242);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2468 = heff_field(v_x3_2467, 0);
                V v_ru_24x3_2467_24Just = heff_take_reuse_n(v_x3_2467, 1ULL, 1);
                switch (heff_tag_of(v_x31_2468)) {
                case TAG_MkPair: {
                  V v_x_2469 = heff_field(v_x31_2468, 0);
                  V v_j_2470 = heff_field(v_x31_2468, 1);
                  V v_ru_24x31_2468_24MkPair = heff_take_reuse_n(v_x31_2468, 3ULL, 2);
                  V v_x3_2471 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2470));
                  V v_x3_2476;
                  switch (heff_tag_of(v_x3_2471)) {
                  case TAG_Nothing: {
                    heff_drop(v_z_242);
                    v_x3_2476 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2472 = heff_field(v_x3_2471, 0);
                    heff_take_n(v_x3_2471, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2472)) {
                    case TAG_MkPair: {
                      V v_x_2473 = heff_field(v_x31_2472, 0);
                      V v_j_2474 = heff_field(v_x31_2472, 1);
                      heff_take_n(v_x31_2472, 3ULL, 2);
                      V v_t_2475 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_2473));
                      v_x3_2476 = heff_tr(heff_call(v_t_2475, 2, (V[]){v_z_242, v_j_2474}));
                      break;
                    }
                    default: heff_nomatch(v_x31_2472);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2471);
                  }
                  switch (heff_tag_of(v_x3_2476)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x3_2467_24Just, 1);
                    heff_drop(v_x_2469);
                    heff_drop_cell(v_ru_24x31_2468_24MkPair, 2);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2477 = heff_field(v_x3_2476, 0);
                    heff_take_n(v_x3_2476, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2477)) {
                    case TAG_MkPair: {
                      V v_x_2478 = heff_field(v_x31_2477, 0);
                      V v_j_2479 = heff_field(v_x31_2477, 1);
                      heff_take_n(v_x31_2477, 3ULL, 2);
                      V v_t_2480 = heff_tag_at_n(v_ru_24x31_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2469, v_x_2478}), v_j_2479});
                      return heff_tag_at_n(v_ru_24x3_2467_24Just, TAG_Just, 1, (V[]){v_t_2480});
                    }
                    default: return heff_nomatch(v_x31_2477);
                    }
                  }
                  default: return heff_nomatch(v_x3_2476);
                  }
                }
                default: return heff_nomatch(v_x31_2468);
                }
              }
              default: return heff_nomatch(v_x3_2467);
              }
            } else {
              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str6), 2)) {
                heff_drop(v_x2_241);
                V v_x3_2482 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2482)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2483 = heff_field(v_x3_2482, 0);
                  V v_ru_24x3_2482_24Just = heff_take_reuse_n(v_x3_2482, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2483)) {
                  case TAG_MkPair: {
                    V v_x_2484 = heff_field(v_x31_2483, 0);
                    V v_j_2485 = heff_field(v_x31_2483, 1);
                    V v_ru_24x31_2483_24MkPair = heff_take_reuse_n(v_x31_2483, 3ULL, 2);
                    V v_x3_2486 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_j_2485));
                    switch (heff_tag_of(v_x3_2486)) {
                    case TAG_Nothing: {
                      heff_drop(v_z_242);
                      heff_drop_cell(v_ru_24x3_2482_24Just, 1);
                      heff_drop(v_x_2484);
                      heff_drop_cell(v_ru_24x31_2483_24MkPair, 2);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2487 = heff_field(v_x3_2486, 0);
                      heff_take_n(v_x3_2486, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2487)) {
                      case TAG_MkPair: {
                        V v_x_2488 = heff_field(v_x31_2487, 0);
                        V v_j_2489 = heff_field(v_x31_2487, 1);
                        heff_take_n(v_x31_2487, 3ULL, 2);
                        V v_x3_2490 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2489));
                        V v_x3_2495;
                        switch (heff_tag_of(v_x3_2490)) {
                        case TAG_Nothing: {
                          v_x3_2495 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_2491 = heff_field(v_x3_2490, 0);
                          heff_take_n(v_x3_2490, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2491)) {
                          case TAG_MkPair: {
                            V v_x_2492 = heff_field(v_x31_2491, 0);
                            V v_j_2493 = heff_field(v_x31_2491, 1);
                            heff_take_n(v_x31_2491, 3ULL, 2);
                            V v_t_2494 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2492));
                            v_x3_2495 = heff_tr(heff_call(v_t_2494, 2, (V[]){heff_dup(v_z_242), v_j_2493}));
                            break;
                          }
                          default: heff_nomatch(v_x31_2491);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_2490);
                        }
                        switch (heff_tag_of(v_x3_2495)) {
                        case TAG_Nothing: {
                          heff_drop(v_z_242);
                          heff_drop_cell(v_ru_24x3_2482_24Just, 1);
                          heff_drop(v_x_2484);
                          heff_drop_cell(v_ru_24x31_2483_24MkPair, 2);
                          heff_drop(v_x_2488);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2496 = heff_field(v_x3_2495, 0);
                          heff_take_n(v_x3_2495, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2496)) {
                          case TAG_MkPair: {
                            V v_x_2497 = heff_field(v_x31_2496, 0);
                            V v_j_2498 = heff_field(v_x31_2496, 1);
                            heff_take_n(v_x31_2496, 3ULL, 2);
                            V v_x3_2499 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_j_2498));
                            switch (heff_tag_of(v_x3_2499)) {
                            case TAG_Nothing: {
                              heff_drop_cell(v_ru_24x3_2482_24Just, 1);
                              heff_drop(v_x_2484);
                              heff_drop_cell(v_ru_24x31_2483_24MkPair, 2);
                              heff_drop(v_x_2488);
                              heff_drop(v_x_2497);
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x31_24100 = heff_field(v_x3_2499, 0);
                              heff_take_n(v_x3_2499, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24100)) {
                              case TAG_MkPair: {
                                V v_x_24101 = heff_field(v_x31_24100, 0);
                                V v_j_24102 = heff_field(v_x31_24100, 1);
                                heff_take_n(v_x31_24100, 3ULL, 2);
                                V v_x1_24103 = (g_heff_2ecompile_2eir_2efieldTyOfName(v_x_24101));
                                switch (heff_tag_of(v_x1_24103)) {
                                case TAG_Nothing: {
                                  heff_drop_cell(v_ru_24x3_2482_24Just, 1);
                                  heff_drop(v_x_2484);
                                  heff_drop_cell(v_ru_24x31_2483_24MkPair, 2);
                                  heff_drop(v_x_2488);
                                  heff_drop(v_x_2497);
                                  heff_drop(v_j_24102);
                                  return NTAG(TAG_Nothing);
                                }
                                case TAG_Just: {
                                  V v_x_24104 = heff_field(v_x1_24103, 0);
                                  heff_take_n(v_x1_24103, 1ULL, 1);
                                  V v_t_24105 = heff_tag_at_n(v_ru_24x31_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2484, v_x_2488, v_x_2497, v_x_24104}), v_j_24102});
                                  return heff_tag_at_n(v_ru_24x3_2482_24Just, TAG_Just, 1, (V[]){v_t_24105});
                                }
                                default: return heff_nomatch(v_x1_24103);
                                }
                              }
                              default: return heff_nomatch(v_x31_24100);
                              }
                            }
                            default: return heff_nomatch(v_x3_2499);
                            }
                          }
                          default: return heff_nomatch(v_x31_2496);
                          }
                        }
                        default: return heff_nomatch(v_x3_2495);
                        }
                      }
                      default: return heff_nomatch(v_x31_2487);
                      }
                    }
                    default: return heff_nomatch(v_x3_2486);
                    }
                  }
                  default: return heff_nomatch(v_x31_2483);
                  }
                }
                default: return heff_nomatch(v_x3_2482);
                }
              } else {
                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str7), 2)) {
                  heff_drop(v_x2_241);
                  V v_x3_24107 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                  switch (heff_tag_of(v_x3_24107)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_k_240, 1);
                    heff_drop(v_z_242);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_24108 = heff_field(v_x3_24107, 0);
                    V v_ru_24x3_24107_24Just = heff_take_reuse_n(v_x3_24107, 1ULL, 1);
                    switch (heff_tag_of(v_x31_24108)) {
                    case TAG_MkPair: {
                      V v_x_24109 = heff_field(v_x31_24108, 0);
                      V v_j_24110 = heff_field(v_x31_24108, 1);
                      V v_ru_24x31_24108_24MkPair = heff_take_reuse_n(v_x31_24108, 3ULL, 2);
                      V v_x3_24111 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24110));
                      V v_x3_24116;
                      switch (heff_tag_of(v_x3_24111)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 1);
                        v_x3_24116 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_24112 = heff_field(v_x3_24111, 0);
                        heff_take_n(v_x3_24111, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24112)) {
                        case TAG_MkPair: {
                          V v_x_24113 = heff_field(v_x31_24112, 0);
                          V v_j_24114 = heff_field(v_x31_24112, 1);
                          heff_take_n(v_x31_24112, 3ULL, 2);
                          V v_t_24115 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24113));
                          v_x3_24116 = heff_tr(heff_call(v_t_24115, 2, (V[]){heff_dup(v_z_242), v_j_24114}));
                          break;
                        }
                        default: heff_nomatch(v_x31_24112);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_24111);
                      }
                      switch (heff_tag_of(v_x3_24116)) {
                      case TAG_Nothing: {
                        heff_drop(v_z_242);
                        heff_drop_cell(v_ru_24x3_24107_24Just, 1);
                        heff_drop(v_x_24109);
                        heff_drop_cell(v_ru_24x31_24108_24MkPair, 2);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_24117 = heff_field(v_x3_24116, 0);
                        heff_take_n(v_x3_24116, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24117)) {
                        case TAG_MkPair: {
                          V v_x_24118 = heff_field(v_x31_24117, 0);
                          V v_j_24119 = heff_field(v_x31_24117, 1);
                          heff_take_n(v_x31_24117, 3ULL, 2);
                          V v_x3_24120 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24119));
                          V v_x3_24125;
                          switch (heff_tag_of(v_x3_24120)) {
                          case TAG_Nothing: {
                            heff_drop(v_z_242);
                            v_x3_24125 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_x31_24121 = heff_field(v_x3_24120, 0);
                            heff_take_n(v_x3_24120, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24121)) {
                            case TAG_MkPair: {
                              V v_x_24122 = heff_field(v_x31_24121, 0);
                              V v_j_24123 = heff_field(v_x31_24121, 1);
                              heff_take_n(v_x31_24121, 3ULL, 2);
                              V v_t_24124 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s1622413203x1387229054(v_x_24122));
                              v_x3_24125 = heff_tr(heff_call(v_t_24124, 2, (V[]){v_z_242, v_j_24123}));
                              break;
                            }
                            default: heff_nomatch(v_x31_24121);
                            }
                            break;
                          }
                          default: heff_nomatch(v_x3_24120);
                          }
                          switch (heff_tag_of(v_x3_24125)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24x3_24107_24Just, 1);
                            heff_drop(v_x_24109);
                            heff_drop_cell(v_ru_24x31_24108_24MkPair, 2);
                            heff_drop(v_x_24118);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_24126 = heff_field(v_x3_24125, 0);
                            heff_take_n(v_x3_24125, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24126)) {
                            case TAG_MkPair: {
                              V v_x_24127 = heff_field(v_x31_24126, 0);
                              V v_j_24128 = heff_field(v_x31_24126, 1);
                              heff_take_n(v_x31_24126, 3ULL, 2);
                              V v_t_24129 = heff_tag_at_n(v_ru_24x31_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_x_24109, v_x_24118, v_x_24127}), v_j_24128});
                              return heff_tag_at_n(v_ru_24x3_24107_24Just, TAG_Just, 1, (V[]){v_t_24129});
                            }
                            default: return heff_nomatch(v_x31_24126);
                            }
                          }
                          default: return heff_nomatch(v_x3_24125);
                          }
                        }
                        default: return heff_nomatch(v_x31_24117);
                        }
                      }
                      default: return heff_nomatch(v_x3_24116);
                      }
                    }
                    default: return heff_nomatch(v_x31_24108);
                    }
                  }
                  default: return heff_nomatch(v_x3_24107);
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str8), 2)) {
                    heff_drop(v_x2_241);
                    V v_x3_24131 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_24131)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_z_242);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_24132 = heff_field(v_x3_24131, 0);
                      V v_ru_24x3_24131_24Just = heff_take_reuse_n(v_x3_24131, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24132)) {
                      case TAG_MkPair: {
                        V v_x_24133 = heff_field(v_x31_24132, 0);
                        V v_j_24134 = heff_field(v_x31_24132, 1);
                        V v_ru_24x31_24132_24MkPair = heff_take_reuse_n(v_x31_24132, 3ULL, 2);
                        V v_x3_24135 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24134));
                        V v_x3_24141;
                        switch (heff_tag_of(v_x3_24135)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_k_240, 1);
                          heff_drop(v_z_242);
                          v_x3_24141 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_24136 = heff_field(v_x3_24135, 0);
                          heff_take_n(v_x3_24135, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24136)) {
                          case TAG_MkPair: {
                            V v_x_24137 = heff_field(v_x31_24136, 0);
                            V v_j_24138 = heff_field(v_x31_24136, 1);
                            heff_take_n(v_x31_24136, 3ULL, 2);
                            V v_t_24139 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eirtext_2earmD_clo), 1, (V[]){v_k_240}));
                            V v_t_24140 = heff_tr(g_heff_2ecompile_2eirtext_2enD(v_t_24139, v_x_24137));
                            v_x3_24141 = heff_tr(heff_call(v_t_24140, 2, (V[]){v_z_242, v_j_24138}));
                            break;
                          }
                          default: heff_nomatch(v_x31_24136);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_24135);
                        }
                        switch (heff_tag_of(v_x3_24141)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_24131_24Just, 1);
                          heff_drop(v_x_24133);
                          heff_drop_cell(v_ru_24x31_24132_24MkPair, 2);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24142 = heff_field(v_x3_24141, 0);
                          heff_take_n(v_x3_24141, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24142)) {
                          case TAG_MkPair: {
                            V v_x_24143 = heff_field(v_x31_24142, 0);
                            V v_j_24144 = heff_field(v_x31_24142, 1);
                            heff_take_n(v_x31_24142, 3ULL, 2);
                            V v_t_24145 = heff_tag_at_n(v_ru_24x31_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24133, v_x_24143}), v_j_24144});
                            return heff_tag_at_n(v_ru_24x3_24131_24Just, TAG_Just, 1, (V[]){v_t_24145});
                          }
                          default: return heff_nomatch(v_x31_24142);
                          }
                        }
                        default: return heff_nomatch(v_x3_24141);
                        }
                      }
                      default: return heff_nomatch(v_x31_24132);
                      }
                    }
                    default: return heff_nomatch(v_x3_24131);
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str9), 2)) {
                      heff_drop_rec(v_k_240, 1);
                      heff_drop(v_x2_241);
                      V v_x3_24147 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                      switch (heff_tag_of(v_x3_24147)) {
                      case TAG_Nothing: {
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_24148 = heff_field(v_x3_24147, 0);
                        V v_ru_24x3_24147_24Just = heff_take_reuse_n(v_x3_24147, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24148)) {
                        case TAG_MkPair: {
                          V v_x_24149 = heff_field(v_x31_24148, 0);
                          V v_j_24150 = heff_field(v_x31_24148, 1);
                          V v_ru_24x31_24148_24MkPair = heff_take_reuse_n(v_x31_24148, 3ULL, 2);
                          V v_t_24151 = heff_tag_at_n(v_ru_24x31_24148_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24149}), v_j_24150});
                          return heff_tag_at_n(v_ru_24x3_24147_24Just, TAG_Just, 1, (V[]){v_t_24151});
                        }
                        default: return heff_nomatch(v_x31_24148);
                        }
                      }
                      default: return heff_nomatch(v_x3_24147);
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str10), 2)) {
                        heff_drop(v_x2_241);
                        V v_x3_24153 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                        switch (heff_tag_of(v_x3_24153)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_k_240, 1);
                          heff_drop(v_z_242);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24154 = heff_field(v_x3_24153, 0);
                          V v_ru_24x3_24153_24Just = heff_take_reuse_n(v_x3_24153, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24154)) {
                          case TAG_MkPair: {
                            V v_x_24155 = heff_field(v_x31_24154, 0);
                            V v_j_24156 = heff_field(v_x31_24154, 1);
                            V v_ru_24x31_24154_24MkPair = heff_take_reuse_n(v_x31_24154, 3ULL, 2);
                            V v_x3_24157 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24156));
                            V v_x3_24162;
                            switch (heff_tag_of(v_x3_24157)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_z_242);
                              v_x3_24162 = NTAG(TAG_Nothing);
                              break;
                            }
                            case TAG_Just: {
                              V v_x31_24158 = heff_field(v_x3_24157, 0);
                              heff_take_n(v_x3_24157, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24158)) {
                              case TAG_MkPair: {
                                V v_x_24159 = heff_field(v_x31_24158, 0);
                                V v_j_24160 = heff_field(v_x31_24158, 1);
                                heff_take_n(v_x31_24158, 3ULL, 2);
                                V v_t_24161 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24159));
                                v_x3_24162 = heff_tr(heff_call(v_t_24161, 2, (V[]){v_z_242, v_j_24160}));
                                break;
                              }
                              default: heff_nomatch(v_x31_24158);
                              }
                              break;
                            }
                            default: heff_nomatch(v_x3_24157);
                            }
                            switch (heff_tag_of(v_x3_24162)) {
                            case TAG_Nothing: {
                              heff_drop_cell(v_ru_24x3_24153_24Just, 1);
                              heff_drop(v_x_24155);
                              heff_drop_cell(v_ru_24x31_24154_24MkPair, 2);
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x31_24163 = heff_field(v_x3_24162, 0);
                              heff_take_n(v_x3_24162, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24163)) {
                              case TAG_MkPair: {
                                V v_x_24164 = heff_field(v_x31_24163, 0);
                                V v_j_24165 = heff_field(v_x31_24163, 1);
                                heff_take_n(v_x31_24163, 3ULL, 2);
                                V v_t_24166 = heff_tag_at_n(v_ru_24x31_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_x_24155, v_x_24164}), v_j_24165});
                                return heff_tag_at_n(v_ru_24x3_24153_24Just, TAG_Just, 1, (V[]){v_t_24166});
                              }
                              default: return heff_nomatch(v_x31_24163);
                              }
                            }
                            default: return heff_nomatch(v_x3_24162);
                            }
                          }
                          default: return heff_nomatch(v_x31_24154);
                          }
                        }
                        default: return heff_nomatch(v_x3_24153);
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str11), 2)) {
                          heff_drop(v_x2_241);
                          V v_x3_24168 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                          switch (heff_tag_of(v_x3_24168)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_z_242);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_24169 = heff_field(v_x3_24168, 0);
                            V v_ru_24x3_24168_24Just = heff_take_reuse_n(v_x3_24168, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24169)) {
                            case TAG_MkPair: {
                              V v_x_24170 = heff_field(v_x31_24169, 0);
                              V v_j_24171 = heff_field(v_x31_24169, 1);
                              V v_ru_24x31_24169_24MkPair = heff_take_reuse_n(v_x31_24169, 3ULL, 2);
                              V v_x3_24172 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_24171));
                              V v_x3_24177;
                              switch (heff_tag_of(v_x3_24172)) {
                              case TAG_Nothing: {
                                heff_drop_rec(v_k_240, 1);
                                heff_drop(v_z_242);
                                v_x3_24177 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x31_24173 = heff_field(v_x3_24172, 0);
                                heff_take_n(v_x3_24172, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24173)) {
                                case TAG_MkPair: {
                                  V v_x_24174 = heff_field(v_x31_24173, 0);
                                  V v_j_24175 = heff_field(v_x31_24173, 1);
                                  heff_take_n(v_x31_24173, 3ULL, 2);
                                  V v_t_24176 = heff_tr(g_heff_2ecompile_2eirtext_2enD(heff_get_n(v_k_240, 0, 1), v_x_24174));
                                  v_x3_24177 = heff_tr(heff_call(v_t_24176, 2, (V[]){v_z_242, v_j_24175}));
                                  break;
                                }
                                default: heff_nomatch(v_x31_24173);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x3_24172);
                              }
                              switch (heff_tag_of(v_x3_24177)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x3_24168_24Just, 1);
                                heff_drop(v_x_24170);
                                heff_drop_cell(v_ru_24x31_24169_24MkPair, 2);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24178 = heff_field(v_x3_24177, 0);
                                heff_take_n(v_x3_24177, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24178)) {
                                case TAG_MkPair: {
                                  V v_x_24179 = heff_field(v_x31_24178, 0);
                                  V v_j_24180 = heff_field(v_x31_24178, 1);
                                  heff_take_n(v_x31_24178, 3ULL, 2);
                                  V v_t_24181 = heff_tag_at_n(v_ru_24x31_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_x_24170, v_x_24179}), v_j_24180});
                                  return heff_tag_at_n(v_ru_24x3_24168_24Just, TAG_Just, 1, (V[]){v_t_24181});
                                }
                                default: return heff_nomatch(v_x31_24178);
                                }
                              }
                              default: return heff_nomatch(v_x3_24177);
                              }
                            }
                            default: return heff_nomatch(v_x31_24169);
                            }
                          }
                          default: return heff_nomatch(v_x3_24168);
                          }
                        } else {
                          if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str12), 2)) {
                            heff_drop_rec(v_k_240, 1);
                            heff_drop(v_x2_241);
                            V v_x3_24183 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                            switch (heff_tag_of(v_x3_24183)) {
                            case TAG_Nothing: {
                              return NTAG(TAG_Nothing);
                            }
                            case TAG_Just: {
                              V v_x31_24184 = heff_field(v_x3_24183, 0);
                              V v_ru_24x3_24183_24Just = heff_take_reuse_n(v_x3_24183, 1ULL, 1);
                              switch (heff_tag_of(v_x31_24184)) {
                              case TAG_MkPair: {
                                V v_x_24185 = heff_field(v_x31_24184, 0);
                                V v_j_24186 = heff_field(v_x31_24184, 1);
                                heff_take_n(v_x31_24184, 3ULL, 2);
                                V v_t_24187 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24185));
                                V v_x_24188 = heff_tag_n(TAG_EInt, 1, (V[]){v_t_24187});
                                return heff_tag_at_n(v_ru_24x3_24183_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24188, v_j_24186})});
                              }
                              default: return heff_nomatch(v_x31_24184);
                              }
                            }
                            default: return heff_nomatch(v_x3_24183);
                            }
                          } else {
                            if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str13), 2)) {
                              heff_drop_rec(v_k_240, 1);
                              heff_drop(v_x2_241);
                              V v_x3_24190 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                              switch (heff_tag_of(v_x3_24190)) {
                              case TAG_Nothing: {
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24191 = heff_field(v_x3_24190, 0);
                                V v_ru_24x3_24190_24Just = heff_take_reuse_n(v_x3_24190, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24191)) {
                                case TAG_MkPair: {
                                  V v_x_24192 = heff_field(v_x31_24191, 0);
                                  V v_j_24193 = heff_field(v_x31_24191, 1);
                                  heff_take_n(v_x31_24191, 3ULL, 2);
                                  V v_x2_24194 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eirtext_2eexprOf_str14), heff_dup(v_x_24192), MK_INT(0LL), heff_strFind(((V)&g_heff_2ecompile_2eirtext_2eexprOf_str15), v_x_24192, MK_INT(0LL)), NTAG(TAG_Nil)));
                                  V v_t_24197;
                                  switch (heff_tag_of(v_x2_24194)) {
                                  case TAG_Nil: {
                                    v_t_24197 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str16);
                                    break;
                                  }
                                  case TAG_Cons: {
                                    V v_x_24195 = heff_field(v_x2_24194, 0);
                                    V v_xs_24196 = heff_field(v_x2_24194, 1);
                                    heff_take_n(v_x2_24194, 3ULL, 2);
                                    v_t_24197 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str17); V a_1 = v_x_24195; V a_2 = v_xs_24196; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24196); r_; });
                                    break;
                                  }
                                  default: heff_nomatch(v_x2_24194);
                                  }
                                  double v_t_24198 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24197));
                                  V v_x_24199 = heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_t_24198)});
                                  return heff_tag_at_n(v_ru_24x3_24190_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24199, v_j_24193})});
                                }
                                default: return heff_nomatch(v_x31_24191);
                                }
                              }
                              default: return heff_nomatch(v_x3_24190);
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str18), 2)) {
                                heff_drop_rec(v_k_240, 1);
                                heff_drop(v_x2_241);
                                V v_x3_24201 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                switch (heff_tag_of(v_x3_24201)) {
                                case TAG_Nothing: {
                                  return NTAG(TAG_Nothing);
                                }
                                case TAG_Just: {
                                  V v_x31_24202 = heff_field(v_x3_24201, 0);
                                  V v_ru_24x3_24201_24Just = heff_take_reuse_n(v_x3_24201, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24202)) {
                                  case TAG_MkPair: {
                                    V v_x_24203 = heff_field(v_x31_24202, 0);
                                    V v_j_24204 = heff_field(v_x31_24202, 1);
                                    V v_ru_24x31_24202_24MkPair = heff_take_reuse_n(v_x31_24202, 3ULL, 2);
                                    V v_t_24205 = heff_tag_at_n(v_ru_24x31_24202_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_x_24203}), v_j_24204});
                                    return heff_tag_at_n(v_ru_24x3_24201_24Just, TAG_Just, 1, (V[]){v_t_24205});
                                  }
                                  default: return heff_nomatch(v_x31_24202);
                                  }
                                }
                                default: return heff_nomatch(v_x3_24201);
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str19), 2)) {
                                  heff_drop_rec(v_k_240, 1);
                                  heff_drop(v_x2_241);
                                  V v_x3_24207 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                  switch (heff_tag_of(v_x3_24207)) {
                                  case TAG_Nothing: {
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x31_24208 = heff_field(v_x3_24207, 0);
                                    V v_ru_24x3_24207_24Just = heff_take_reuse_n(v_x3_24207, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24208)) {
                                    case TAG_MkPair: {
                                      V v_x_24209 = heff_field(v_x31_24208, 0);
                                      V v_j_24210 = heff_field(v_x31_24208, 1);
                                      V v_ru_24x31_24208_24MkPair = heff_take_reuse_n(v_x31_24208, 3ULL, 2);
                                      V v_t_24211 = heff_tag_at_n(v_ru_24x31_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBytes, 1, (V[]){v_x_24209}), v_j_24210});
                                      return heff_tag_at_n(v_ru_24x3_24207_24Just, TAG_Just, 1, (V[]){v_t_24211});
                                    }
                                    default: return heff_nomatch(v_x31_24208);
                                    }
                                  }
                                  default: return heff_nomatch(v_x3_24207);
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str20), 2)) {
                                    heff_drop_rec(v_k_240, 1);
                                    heff_drop(v_x2_241);
                                    V v_x3_24213 = (g_heff_2ecompile_2eirtext_2efixedD(heff_dup(v_z_242), v_z_243));
                                    switch (heff_tag_of(v_x3_24213)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_z_242);
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x31_24214 = heff_field(v_x3_24213, 0);
                                      V v_ru_24x3_24213_24Just = heff_take_reuse_n(v_x3_24213, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24214)) {
                                      case TAG_MkPair: {
                                        V v_x_24215 = heff_field(v_x31_24214, 0);
                                        V v_j_24216 = heff_field(v_x31_24214, 1);
                                        V v_ru_24x31_24214_24MkPair = heff_take_reuse_n(v_x31_24214, 3ULL, 2);
                                        V v_x3_24217 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_j_24216));
                                        switch (heff_tag_of(v_x3_24217)) {
                                        case TAG_Nothing: {
                                          heff_drop_cell(v_ru_24x3_24213_24Just, 1);
                                          heff_drop(v_x_24215);
                                          heff_drop_cell(v_ru_24x31_24214_24MkPair, 2);
                                          return NTAG(TAG_Nothing);
                                        }
                                        case TAG_Just: {
                                          V v_x31_24218 = heff_field(v_x3_24217, 0);
                                          heff_take_n(v_x3_24217, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24218)) {
                                          case TAG_MkPair: {
                                            V v_x_24219 = heff_field(v_x31_24218, 0);
                                            V v_j_24220 = heff_field(v_x31_24218, 1);
                                            heff_take_n(v_x31_24218, 3ULL, 2);
                                            V v_t_24221 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24219));
                                            V v_x_24222 = heff_tag_at_n(v_ru_24x31_24214_24MkPair, TAG_EFixed, 2, (V[]){v_x_24215, v_t_24221});
                                            return heff_tag_at_n(v_ru_24x3_24213_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24222, v_j_24220})});
                                          }
                                          default: return heff_nomatch(v_x31_24218);
                                          }
                                        }
                                        default: return heff_nomatch(v_x3_24217);
                                        }
                                      }
                                      default: return heff_nomatch(v_x31_24214);
                                      }
                                    }
                                    default: return heff_nomatch(v_x3_24213);
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str21), 2)) {
                                      heff_drop_rec(v_k_240, 1);
                                      heff_drop(v_x2_241);
                                      V v_x3_24224 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                      switch (heff_tag_of(v_x3_24224)) {
                                      case TAG_Nothing: {
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x31_24225 = heff_field(v_x3_24224, 0);
                                        V v_ru_24x3_24224_24Just = heff_take_reuse_n(v_x3_24224, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24225)) {
                                        case TAG_MkPair: {
                                          V v_x_24226 = heff_field(v_x31_24225, 0);
                                          V v_j_24227 = heff_field(v_x31_24225, 1);
                                          heff_take_n(v_x31_24225, 3ULL, 2);
                                          V v_x2_24228 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eirtext_2eexprOf_str22), heff_dup(v_x_24226), MK_INT(0LL), heff_strFind(((V)&g_heff_2ecompile_2eirtext_2eexprOf_str23), v_x_24226, MK_INT(0LL)), NTAG(TAG_Nil)));
                                          V v_t_24231;
                                          switch (heff_tag_of(v_x2_24228)) {
                                          case TAG_Nil: {
                                            v_t_24231 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str24);
                                            break;
                                          }
                                          case TAG_Cons: {
                                            V v_x_24229 = heff_field(v_x2_24228, 0);
                                            V v_xs_24230 = heff_field(v_x2_24228, 1);
                                            heff_take_n(v_x2_24228, 3ULL, 2);
                                            v_t_24231 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str25); V a_1 = v_x_24229; V a_2 = v_xs_24230; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24230); r_; });
                                            break;
                                          }
                                          default: heff_nomatch(v_x2_24228);
                                          }
                                          double v_t_24232 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24231));
                                          V v_x_24233 = heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24232)});
                                          return heff_tag_at_n(v_ru_24x3_24224_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24233, v_j_24227})});
                                        }
                                        default: return heff_nomatch(v_x31_24225);
                                        }
                                      }
                                      default: return heff_nomatch(v_x3_24224);
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str26), 2)) {
                                        heff_drop_rec(v_k_240, 1);
                                        heff_drop(v_x2_241);
                                        heff_drop(v_z_242);
                                        V v_t_24235 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_z_243});
                                        return heff_tag_n(TAG_Just, 1, (V[]){v_t_24235});
                                      } else {
                                        if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ecompile_2eirtext_2eexprOf_str27))) {
                                          V v_x3_24237 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                                          switch (heff_tag_of(v_x3_24237)) {
                                          case TAG_Nothing: {
                                            heff_drop_rec(v_k_240, 1);
                                            heff_drop(v_z_242);
                                            return NTAG(TAG_Nothing);
                                          }
                                          case TAG_Just: {
                                            V v_x31_24238 = heff_field(v_x3_24237, 0);
                                            V v_ru_24x3_24237_24Just = heff_take_reuse_n(v_x3_24237, 1ULL, 1);
                                            switch (heff_tag_of(v_x31_24238)) {
                                            case TAG_MkPair: {
                                              V v_x_24239 = heff_field(v_x31_24238, 0);
                                              V v_j_24240 = heff_field(v_x31_24238, 1);
                                              V v_ru_24x31_24238_24MkPair = heff_take_reuse_n(v_x31_24238, 3ULL, 2);
                                              V v_x3_24241 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_242, v_j_24240}));
                                              switch (heff_tag_of(v_x3_24241)) {
                                              case TAG_Nothing: {
                                                heff_drop_cell(v_ru_24x3_24237_24Just, 1);
                                                heff_drop(v_x_24239);
                                                heff_drop_cell(v_ru_24x31_24238_24MkPair, 2);
                                                return NTAG(TAG_Nothing);
                                              }
                                              case TAG_Just: {
                                                V v_x31_24242 = heff_field(v_x3_24241, 0);
                                                heff_take_n(v_x3_24241, 1ULL, 1);
                                                switch (heff_tag_of(v_x31_24242)) {
                                                case TAG_MkPair: {
                                                  V v_x_24243 = heff_field(v_x31_24242, 0);
                                                  V v_j_24244 = heff_field(v_x31_24242, 1);
                                                  heff_take_n(v_x31_24242, 3ULL, 2);
                                                  V v_t_24245 = heff_tag_at_n(v_ru_24x31_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24239, v_x_24243}), v_j_24244});
                                                  return heff_tag_at_n(v_ru_24x3_24237_24Just, TAG_Just, 1, (V[]){v_t_24245});
                                                }
                                                default: return heff_nomatch(v_x31_24242);
                                                }
                                              }
                                              default: return heff_nomatch(v_x3_24241);
                                              }
                                            }
                                            default: return heff_nomatch(v_x31_24238);
                                            }
                                          }
                                          default: return heff_nomatch(v_x3_24237);
                                          }
                                        } else {
                                          heff_drop_rec(v_k_240, 1);
                                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eirtext_2eexprOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eirtext_2edk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2edk_lam0, 2, 0};

static V g_heff_2ecompile_2eirtext_2edk_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2edk_st;
static V g_heff_2ecompile_2eirtext_2edk_init(void) {
  return heff_rec_n(1, shape_go, (V[]){((V)&g_heff_2ecompile_2eirtext_2edk_lam0_clo)});
}
V g_heff_2ecompile_2eirtext_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2edk_st)) return g_heff_2ecompile_2eirtext_2edk_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2edk_val, &g_heff_2ecompile_2eirtext_2edk_st, g_heff_2ecompile_2eirtext_2edk_init);
}
V g_heff_2ecompile_2eirtext_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_t_242 = heff_dup(g_heff_2ecompile_2eirtext_2edk_get());
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_t_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      return (g_heff_2ecompile_2eirtext_2eexprOf(v_t_242, v_x_245, v_s_240, v_j_246));
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
Clo g_heff_2ecompile_2eirtext_2eexprsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_es_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2eexprsH_24dps(v_es_243, v_rest_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2eexprsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_es_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_es_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x11_243, 0);
      V v_e_246 = heff_field(v_x11_243, 1);
      V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x11_243_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_246}), heff_hole()});
      V v_u_2410 = heff_setField(v_cell_247, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_fs_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_249;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2earmsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2earmsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_arms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x11_242, 0);
      V v_vs_245 = heff_field(v_x11_242, 1);
      V v_b_246 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 7ULL, 3);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_245));
      V v_t_248 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_243, v_rest_241));
      V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_246}), v_t_248});
      V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_vs_245, v_t_249));
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_247}), v_t_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_244}), v_t_2411});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2ehashW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2ehashW_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2ehashW(V v_a_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_240, v_b_241});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_HE: {
      V v_e_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_246 = (g_heff_2ecompile_2eirtext_2enodeH(v_e_245, v_rest_244));
      V t_0 = v_a_240;
      V t_1 = v_b_241;
      V t_2 = v_t_246;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_HS: {
      V v_s_247 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x3_248 = (g_heff_2ecompile_2eirtext_2ebytesH(v_s_247, MK_INT(0LL), v_a_240, v_b_241));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_MkPair: {
        V v_a_249 = heff_field(v_x3_248, 0);
        V v_b_2410 = heff_field(v_x3_248, 1);
        heff_take_n(v_x3_248, 3ULL, 2);
        V t_0 = v_a_249;
        V t_1 = v_b_2410;
        V t_2 = v_rest_244;
        v_a_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    case TAG_HN: {
      V v_n_2411 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2412 = heff_intAdd(heff_intMul(v_a_240, MK_INT(1000003LL)), heff_intAdd(heff_dup(v_n_2411), MK_INT(300LL)));
      V v_t_2413 = heff_intMod(heff_intAdd(v_t_2412, MK_INT(1LL)), MK_INT(2147483647LL));
      V v_t_2414 = heff_intAdd(heff_intMul(v_b_241, MK_INT(999983LL)), heff_intAdd(v_n_2411, MK_INT(300LL)));
      V v_t_2415 = heff_intMod(heff_intAdd(v_t_2414, MK_INT(1LL)), MK_INT(2147483629LL));
      V t_0 = v_t_2413;
      V t_1 = v_t_2415;
      V t_2 = v_rest_244;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2ehashW(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V v_rest_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_243)) {
    case TAG_FtFloat: {
      v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      switch (heff_tag_of(v_w_245)) {
      case TAG_I8: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_245);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_246}), heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_rest_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_rest_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(a[0], a[1], a[2]);
}