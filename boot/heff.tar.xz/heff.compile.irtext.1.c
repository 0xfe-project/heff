// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HC 9068
#define TAG_HE 9070
#define TAG_HN 9079
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_go 10063
static uint32_t shape_go[] = {LBL_go};
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
HeffT2 g_heff_2ecompile_2eirtext_2earmD_24cpr(V, V, V);
V g_heff_2ecompile_2eirtext_2earmsH(V, V);
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsH_clo;
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V, V);
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ebytesH_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eckOf(V);
V g_heff_2ecompile_2eirtext_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eckOf_clo;
V g_heff_2ecompile_2eirtext_2econdH(V, V);
V g_heff_2ecompile_2eirtext_2econdH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdH_clo;
V g_heff_2ecompile_2eirtext_2econdOfTag(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdOfTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdOfTag_clo;
HeffT2 g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_clo;
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_clo;
V g_heff_2ecompile_2eirtext_2econsD(V, V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo;
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V, V, V);
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo;
V g_heff_2ecompile_2eirtext_2edk_get(void);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo;
V g_heff_2ecompile_2eirtext_2eexprOf(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprOf_clo;
HeffT2 g_heff_2ecompile_2eirtext_2eexprOf_24cpr(V, V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH(V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_clo;
V g_heff_2ecompile_2eirtext_2eexprsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2eexprsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(V, V);
V g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302_clo;
V g_heff_2ecompile_2eirtext_2efieldD(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldD_clo;
V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo;
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V, V);
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo;
HeffT2 g_heff_2ecompile_2eirtext_2efixedD_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(V);
V g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591_clo;
V g_heff_2ecompile_2eirtext_2enodeH(V, V);
V g_heff_2ecompile_2eirtext_2enodeH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2enodeH_clo;
V g_heff_2ecompile_2eirtext_2estrsH(V, V);
V g_heff_2ecompile_2eirtext_2estrsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_clo;
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V, V, V);
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo;
V g_heff_2ecompile_2eirtext_2estrsT(V, V);
V g_heff_2ecompile_2eirtext_2estrsT_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2estrsT_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
HeffT2 g_list_2efind_24s1896676244x1358329894_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
HEFF_LIT(g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_fs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_intShow(heff_strLength_lent(v_l_244, 0));
      V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_str0), v_l_244));
      V v_rest_248 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_243, v_rest_241));
      V v_t_249 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_245, v_rest_248));
      return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_t_249});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_str0, 1, ":");
Clo g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_arms_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_t_244, 0));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_str0), v_t_244));
      V v_rest_249 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_243, v_rest_241));
      V v_rest_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_246, v_rest_249));
      V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_245));
      V v_t_2412 = (g_heff_2ecompile_2eirtext_2estrsT(v_vs_245, v_rest_2410));
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2413});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str0, 1, "T");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str1, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str3, 1, "R");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str4, 1, "S");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str5, 1, "N");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str6, 1, "I");
Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_CTrue: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str0), v_rest_241});
  }
  case TAG_CFalse: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str1), v_rest_241});
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_240, 0);
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_p_242, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str2), heff_dup(v_p_242)));
    V v_rest_247 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_b_244), v_rest_241));
    V v_t_248 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_a_243), v_rest_247));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})});
  }
  case TAG_CTest: {
    V v_e_249 = heff_field(v_x2_240, 0);
    V v_t_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_249), v_rest_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str4), v_t_2410});
  }
  case TAG_CNot: {
    V v_c_2411 = heff_field(v_x2_240, 0);
    V v_cell_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str5), heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps(v_c_2411, v_rest_241, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_CIf: {
    V v_a_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_c_2416 = heff_field(v_x2_240, 2);
    V v_cell_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_str6), heff_hole()});
    V v_t_2418 = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(v_c_2416, v_rest_241));
    V v_t_2419 = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(v_b_2415, v_t_2418));
    V v_u_2420 = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps(v_a_2414, v_t_2419, heff_dup(v_cell_2417)));
    heff_drop(v_u_2420);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str0, 1, "T");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str1, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str3, 1, "R");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str4, 1, "S");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str5, 1, "N");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str6, 1, "I");
Clo g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_CTrue: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str0), v_rest_241}));
  }
  case TAG_CFalse: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str1), v_rest_241}));
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_240, 0);
    V v_a_244 = heff_field(v_x2_240, 1);
    V v_b_245 = heff_field(v_x2_240, 2);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_p_243, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str2), heff_dup(v_p_243)));
    V v_rest_248 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_b_245), v_rest_241));
    V v_t_249 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_a_244), v_rest_248));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
  }
  case TAG_CTest: {
    V v_e_2411 = heff_field(v_x2_240, 0);
    V v_t_2412 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_e_2411), v_rest_241));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str4), v_t_2412}));
  }
  case TAG_CNot: {
    V v_c_2413 = heff_field(v_x2_240, 0);
    V v_cell_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str5), heff_hole()});
    V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_c_2413;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2414;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2416 = heff_field(v_x2_240, 0);
    V v_b_2417 = heff_field(v_x2_240, 1);
    V v_c_2418 = heff_field(v_x2_240, 2);
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_str6), heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V v_t_2421 = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(v_c_2418, v_rest_241));
    V v_t_2422 = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(v_b_2417, v_t_2421));
    V t_0 = v_a_2416;
    V t_1 = v_t_2422;
    V t_2 = v_cell_2419;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str0, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str1, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str2, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str3, 1, "g");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str4, 1, "l");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str5, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str6, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str7, 1, "t");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str8, 1, "r");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str10, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str11, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str12, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str13, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str14, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str15, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str16, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str17, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str18, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str19, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str20, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str21, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str22, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str23, 1, "p");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str24, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str25, 1, "c");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str26, 1, "m");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str28, 1, "q");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str29, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str30, 1, "k");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str32, 1, "K");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str33, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str34, 1, "i");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str35, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str36, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str37, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str39, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str40, 1, "b");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str41, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str42, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str43, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str44, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str45, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str46, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str47, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str48, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str49, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str50, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str51, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str52, 1, ":");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str53, 1, "y");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str54, 1, "X");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str55, 1, "o");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str56, 1, "e");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str57, 1, "w");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str58, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str59, 1, ":");
Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str0), v_x_243));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_EGlobal: {
    V v_g_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = heff_intShow(heff_strLength_lent(v_g_247, 0));
    V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str2), v_g_247));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
  }
  case TAG_ELam: {
    V v_xs_2411 = heff_field(v_x2_240, 0);
    V v_b_2412 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ELam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2413 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2412, v_rest_241));
    V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
    V v_t_2415 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2411, v_rest_2413));
    V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24ELam, TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2415});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str4), v_t_2416}));
  }
  case TAG_EApp: {
    V v_f_2417 = heff_field(v_x2_240, 0);
    V v_args_2418 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2418));
    V v_t_2420 = ({ V a_0 = v_args_2418; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2418); r_; });
    V v_rest_2421 = heff_tag_at_n(v_ru_24x2_240_24EApp, TAG_Cons, 2, (V[]){heff_intShow(v_t_2419), v_t_2420});
    V v_t_2422 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_f_2417, v_rest_2421));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str5), v_t_2422}));
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_a_2424 = heff_field(v_x2_240, 1);
    V v_b_2425 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2426 = heff_intShow(heff_strLength_lent(v_x_2423, 0));
    V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str6), v_x_2423));
    V v_rest_2428 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2425, v_rest_241));
    V v_t_2429 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_2424, v_rest_2428));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2429})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2430);
  }
  case TAG_ERecord: {
    V v_fs_2431 = heff_field(v_x2_240, 0);
    V v_ts_2432 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ERecord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2431));
    V v_xs_2434 = (g_list_2emap_24s143096761x246530315(v_ts_2432));
    V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2434));
    V v_t_2436 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2434, v_rest_241));
    V v_t_2437 = heff_tag_at_n(v_ru_24x2_240_24ERecord, TAG_Cons, 2, (V[]){heff_intShow(v_t_2435), v_t_2436});
    V v_t_2438 = (g_heff_2ecompile_2eirtext_2efieldsT_24s578300106x627494150(v_fs_2431, v_t_2437));
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), v_t_2438});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str8), v_t_2439}));
  }
  case TAG_EProj: {
    V v_e_2440 = heff_field(v_x2_240, 0);
    V v_l_2441 = heff_field(v_x2_240, 1);
    V v_sh_2442 = heff_field(v_x2_240, 2);
    V v_t_2443 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2444 = heff_intShow(heff_strLength_lent(v_l_2441, 0));
    V v_t_2445 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str9), v_l_2441));
    V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sh_2442));
    V v_s_2448;
    switch (heff_tag_of(v_t_2443)) {
    case TAG_FtFloat: {
      v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str10);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2447 = heff_field(v_t_2443, 0);
      heff_take_n(v_t_2443, 1ULL, 1);
      switch (heff_tag_of(v_w_2447)) {
      case TAG_I8: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str11);
        break;
      }
      case TAG_I16: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str12);
        break;
      }
      case TAG_I32: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str13);
        break;
      }
      case TAG_I64: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str14);
        break;
      }
      case TAG_U8: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str15);
        break;
      }
      case TAG_U16: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str16);
        break;
      }
      case TAG_U32: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str17);
        break;
      }
      case TAG_U64: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str18);
        break;
      }
      case TAG_F32: {
        v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str19);
        break;
      }
      default: heff_nomatch(v_w_2447);
      }
      break;
    }
    case TAG_FtOther: {
      v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str20);
      break;
    }
    case TAG_FtAny: {
      v_s_2448 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str21);
      break;
    }
    default: heff_nomatch(v_t_2443);
    }
    V v_t_2449 = heff_intShow(heff_strLength_lent(v_s_2448, 0));
    V v_t_2450 = heff_strAppend(v_t_2449, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str22), v_s_2448));
    V v_t_2451 = (g_heff_2ecompile_2eirtext_2estrsT(v_sh_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_rest_241})));
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2446), v_t_2451});
    V v_rest_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2452});
    V v_t_2454 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_e_2440, v_rest_2453));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str23), v_t_2454}));
  }
  case TAG_ETag: {
    V v_t_2455 = heff_field(v_x2_240, 0);
    V v_args_2456 = heff_field(v_x2_240, 1);
    V v_ts_2457 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2458 = heff_intShow(heff_strLength_lent(v_t_2455, 0));
    V v_t_2459 = heff_strAppend(v_t_2458, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str24), v_t_2455));
    V v_t_2460 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2456));
    V v_xs_2461 = (g_list_2emap_24s143096761x246530315(v_ts_2457));
    V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2461));
    V v_t_2463 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_2461, v_rest_241));
    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2462), v_t_2463});
    V v_t_2465 = ({ V a_0 = v_args_2456; V a_1 = v_t_2464; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2456); r_; });
    V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2460), v_t_2465});
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2466})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2467);
  }
  case TAG_EMatch: {
    V v_s_2468 = heff_field(v_x2_240, 0);
    V v_arms_2469 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2469));
    V v_t_2471 = (g_heff_2ecompile_2eirtext_2earmsT_24s1055412469x224976005(v_arms_2469, v_rest_241));
    V v_rest_2472 = heff_tag_at_n(v_ru_24x2_240_24EMatch, TAG_Cons, 2, (V[]){heff_intShow(v_t_2470), v_t_2471});
    V v_t_2473 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_s_2468, v_rest_2472));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str26), v_t_2473}));
  }
  case TAG_EPrim: {
    V v_p_2474 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2475 = heff_intShow(heff_strLength_lent(v_p_2474, 0));
    V v_t_2476 = heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str27), v_p_2474));
    V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str28), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2477);
  }
  case TAG_EPrimCall: {
    V v_p_2478 = heff_field(v_x2_240, 0);
    V v_args_2479 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EPrimCall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2480 = heff_intShow(heff_strLength_lent(v_p_2478, 0));
    V v_t_2481 = heff_strAppend(v_t_2480, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str29), v_p_2478));
    V v_t_2482 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2479));
    V v_t_2483 = ({ V a_0 = v_args_2479; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2479); r_; });
    V v_t_2484 = heff_tag_at_n(v_ru_24x2_240_24EPrimCall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2482), v_t_2483});
    V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, v_t_2484})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2485);
  }
  case TAG_ECall: {
    V v_g_2486 = heff_field(v_x2_240, 0);
    V v_args_2487 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24ECall = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2488 = heff_intShow(heff_strLength_lent(v_g_2486, 0));
    V v_t_2489 = heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str31), v_g_2486));
    V v_t_2490 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2487));
    V v_t_2491 = ({ V a_0 = v_args_2487; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_args_2487); r_; });
    V v_t_2492 = heff_tag_at_n(v_ru_24x2_240_24ECall, TAG_Cons, 2, (V[]){heff_intShow(v_t_2490), v_t_2491});
    V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str32), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_t_2492})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2493);
  }
  case TAG_EInt: {
    V v_i_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2495 = heff_intShow(v_i_2494);
    V v_t_2496 = heff_intShow(heff_strLength_lent(v_s_2495, 0));
    V v_t_2497 = heff_strAppend(v_t_2496, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str33), v_s_2495));
    V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2498);
  }
  case TAG_EFloat: {
    V v_x_2499 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24100 = heff_floatShow(v_x_2499);
    V v_t_24101 = heff_intShow(heff_strLength_lent(v_s_24100, 0));
    V v_t_24102 = heff_strAppend(v_t_24101, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str35), v_s_24100));
    V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24102, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24103);
  }
  case TAG_EStr: {
    V v_s_24104 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24105 = heff_intShow(heff_strLength_lent(v_s_24104, 0));
    V v_t_24106 = heff_strAppend(v_t_24105, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str37), v_s_24104));
    V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24107);
  }
  case TAG_EBytes: {
    V v_s_24108 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24109 = heff_intShow(heff_strLength_lent(v_s_24108, 0));
    V v_t_24110 = heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str39), v_s_24108));
    V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24111);
  }
  case TAG_EFixed: {
    V v_w_24112 = heff_field(v_x2_240, 0);
    V v_n_24113 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24114;
    switch (heff_tag_of(v_w_24112)) {
    case TAG_I8: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str41);
      break;
    }
    case TAG_I16: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str42);
      break;
    }
    case TAG_I32: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str43);
      break;
    }
    case TAG_I64: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str44);
      break;
    }
    case TAG_U8: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str45);
      break;
    }
    case TAG_U16: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str46);
      break;
    }
    case TAG_U32: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str47);
      break;
    }
    case TAG_U64: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str48);
      break;
    }
    case TAG_F32: {
      v_t_24114 = ((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str49);
      break;
    }
    default: heff_nomatch(v_w_24112);
    }
    V v_s_24115 = heff_intShow(v_n_24113);
    V v_t_24116 = heff_intShow(heff_strLength_lent(v_s_24115, 0));
    V v_t_24117 = heff_strAppend(v_t_24116, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str50), v_s_24115));
    V v_t_24118 = heff_tag_at_n(v_ru_24x2_240_24EFixed, TAG_Cons, 2, (V[]){v_t_24114, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str51), v_t_24118}));
  }
  case TAG_EFloat32: {
    V v_x_24119 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24120 = heff_floatShow(v_x_24119);
    V v_t_24121 = heff_intShow(heff_strLength_lent(v_s_24120, 0));
    V v_t_24122 = heff_strAppend(v_t_24121, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str52), v_s_24120));
    V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str53), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24122, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24123);
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str54), v_rest_241}));
  }
  case TAG_EBool: {
    V v_c_24124 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24125 = ({ V a_0 = v_c_24124; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2econdT_24s515840014x915015342(a_0, a_1)); heff_drop(v_c_24124); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str55), v_t_24125}));
  }
  case TAG_ESet: {
    V v_xs_24126 = heff_field(v_x2_240, 0);
    V v_a_24127 = heff_field(v_x2_240, 1);
    V v_b_24128 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_rest_24129 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_24128, v_rest_241));
    V v_rest_24130 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_a_24127, v_rest_24129));
    V v_t_24131 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24126));
    V v_t_24132 = (g_heff_2ecompile_2eirtext_2estrsT(v_xs_24126, v_rest_24130));
    V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24131), v_t_24132});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str56), v_t_24133}));
  }
  case TAG_EValues: {
    V v_es_24134 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24135 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_24134));
    V v_t_24136 = ({ V a_0 = v_es_24134; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eirtext_2eexprsT_24s1517891316x1965381302(a_0, a_1)); heff_drop(v_es_24134); r_; });
    V v_t_24137 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_24135), v_t_24136});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str57), v_t_24137}));
  }
  case TAG_EFix: {
    V v_f_24138 = heff_field(v_x2_240, 0);
    V v_b_24139 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24EFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24140 = heff_tag_at_n(v_ru_24x2_240_24EFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str58), heff_hole()});
    V v_u_24141 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_24140));
    heff_drop(v_u_24141);
    V v_t_24142 = heff_intShow(heff_strLength_lent(v_f_24138, 0));
    V v_t_24143 = heff_strAppend(v_t_24142, heff_strAppend(((V)&g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_str59), v_f_24138));
    V v_cell_24144 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, heff_hole()});
    V v_u_24145 = heff_setField(v_cell_24140, MK_INT(1LL), heff_dup(v_cell_24144));
    heff_drop(v_u_24145);
    V t_0 = v_b_24139;
    V t_1 = v_rest_241;
    V t_2 = v_cell_24144;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2econsD(V v_d_240, V v_more_241, V v_s_242, V v_i_243) {
top: ;
  V v_x3_244 = heff_tr(heff_call(v_d_240, 2, (V[]){heff_dup(v_s_242), v_i_243}));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    heff_drop(v_more_241);
    heff_drop(v_s_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_x3_248 = heff_tr(heff_call(v_more_241, 2, (V[]){v_s_242, v_j_247}));
      switch (heff_tag_of(v_x3_248)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_244_24Just, 1);
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_249 = heff_field(v_x3_248, 0);
        heff_take_n(v_x3_248, 1ULL, 1);
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          heff_take_n(v_x31_249, 3ULL, 2);
          V v_t_2412 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_x_2410}), v_j_2411});
          return heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
        }
        default: return heff_nomatch(v_x31_249);
        }
      }
      default: return heff_nomatch(v_x3_248);
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eirtext_2econsD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eirtext_2efieldD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldD_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2efieldD(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_s_241, v_j_248}));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop_rec(v_k_240, 1);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2efieldD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldD(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(V v_more_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = heff_tr(heff_call(v_more_240, 2, (V[]){v_s_241, v_j_248}));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_more_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD_24s1260282571x732555414(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2eirtext_2earmD_24cpr(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2412 = v_field_2411;
            switch (heff_tag_of(v_x31_2412)) {
            case TAG_MkPair: {
              V v_x_2413 = heff_field(v_x31_2412, 0);
              V v_j_2414 = heff_field(v_x31_2412, 1);
              heff_take_n(v_x31_2412, 3ULL, 2);
              V v_t_2415 = heff_tr(g_heff_2ecompile_2eirtext_2enD_24s406717531x2112426591(v_x_2413));
              V v_x3_2416 = heff_tr(heff_call(v_t_2415, 2, (V[]){heff_dup(v_s_241), v_j_2414}));
              switch (heff_tag_of(v_x3_2416)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_s_241);
                heff_drop(v_x_247);
                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2417 = heff_field(v_x3_2416, 0);
                heff_take_n(v_x3_2416, 1ULL, 1);
                switch (heff_tag_of(v_x31_2417)) {
                case TAG_MkPair: {
                  V v_x_2418 = heff_field(v_x31_2417, 0);
                  V v_j_2419 = heff_field(v_x31_2417, 1);
                  heff_take_n(v_x31_2417, 3ULL, 2);
                  V v_x3_2420 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_s_241, v_j_2419}));
                  switch (heff_tag_of(v_x3_2420)) {
                  case TAG_Nothing: {
                    heff_drop(v_x_247);
                    heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                    heff_drop(v_x_2418);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2421 = heff_field(v_x3_2420, 0);
                    heff_take_n(v_x3_2420, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2421)) {
                    case TAG_MkPair: {
                      V v_x_2422 = heff_field(v_x31_2421, 0);
                      V v_j_2423 = heff_field(v_x31_2421, 1);
                      heff_take_n(v_x31_2421, 3ULL, 2);
                      V v_t_2424 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_x_247, v_x_2418, v_x_2422}), v_j_2423});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2424}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2421)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2420)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2416)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
            }
          } else {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_s_241);
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop_rec(v_k_240, 1);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2efixedD_24cpr_str8, 7, "Float32");

HeffT2 g_heff_2ecompile_2eirtext_2efixedD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str0); V a_1 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str1); V a_2 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str2); V a_3 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str3); V a_4 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str4); V a_5 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str5); V a_6 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str6); V a_7 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str7); V a_8 = ((V)&g_heff_2ecompile_2eirtext_2efixedD_24cpr_str8); V a_9 = v_x_246; V a_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); HeffT2 r_ = (g_list_2efind_24s1896676244x1358329894_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_x_246); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x_2411 = v_field_2410;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2411, v_j_247})}});
          } else {
            heff_drop(v_j_247);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str0, 1, "T");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str1, 1, "F");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str2, 1, "R");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str3, 1, "S");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str4, 1, "N");
HEFF_LIT(g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str5, 1, "I");

HeffT2 g_heff_2ecompile_2eirtext_2econdOfTag_24cpr(V v_k_240, V v_c_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  if (heff_strEq_c_lent(v_x3_242, ((V)&g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str0), 2)) {
    heff_drop_rec(v_k_240, 1);
    heff_drop_rec(v_c_241, 1);
    heff_drop(v_z_243);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_z_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_245}});
  } else {
    if (heff_strEq_c_lent(v_x3_242, ((V)&g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str1), 2)) {
      heff_drop_rec(v_k_240, 1);
      heff_drop_rec(v_c_241, 1);
      heff_drop(v_z_243);
      V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_z_244});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_246}});
    } else {
      if (heff_strEq_c_lent(v_x3_242, ((V)&g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str2), 2)) {
        heff_drop_rec(v_c_241, 1);
        HeffT2 v_t_247 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_243, v_z_244));
        {
          V v_field_249 = v_t_247.f[1];
          int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
          if ((v_tag_248 == ((int64_t)0ULL))) {
            V v_x31_2410 = v_field_249;
            switch (heff_tag_of(v_x31_2410)) {
            case TAG_MkPair: {
              V v_x_2411 = heff_field(v_x31_2410, 0);
              V v_j_2412 = heff_field(v_x31_2410, 1);
              V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
              V v_x3_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_243), v_j_2412}));
              switch (heff_tag_of(v_x3_2413)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 1);
                heff_drop(v_z_243);
                heff_drop(v_x_2411);
                heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2414 = heff_field(v_x3_2413, 0);
                heff_take_n(v_x3_2413, 1ULL, 1);
                switch (heff_tag_of(v_x31_2414)) {
                case TAG_MkPair: {
                  V v_x_2415 = heff_field(v_x31_2414, 0);
                  V v_j_2416 = heff_field(v_x31_2414, 1);
                  heff_take_n(v_x31_2414, 3ULL, 2);
                  V v_x3_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_243, v_j_2416}));
                  switch (heff_tag_of(v_x3_2417)) {
                  case TAG_Nothing: {
                    heff_drop(v_x_2411);
                    heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
                    heff_drop(v_x_2415);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2418 = heff_field(v_x3_2417, 0);
                    heff_take_n(v_x3_2417, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2418)) {
                    case TAG_MkPair: {
                      V v_x_2419 = heff_field(v_x31_2418, 0);
                      V v_j_2420 = heff_field(v_x31_2418, 1);
                      heff_take_n(v_x31_2418, 3ULL, 2);
                      V v_t_2421 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_x_2411, v_x_2415, v_x_2419}), v_j_2420});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2418)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2417)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2414)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2413)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
            }
          } else {
            heff_drop_rec(v_k_240, 1);
            heff_drop(v_z_243);
            heff_drop(v_field_249);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x3_242, ((V)&g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str3), 2)) {
          heff_drop_rec(v_c_241, 1);
          V v_x3_2422 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 1), 2, (V[]){v_z_243, v_z_244}));
          switch (heff_tag_of(v_x3_2422)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2423 = heff_field(v_x3_2422, 0);
            V v_ru_24x3_2422_24Just = heff_take_reuse_n(v_x3_2422, 1ULL, 1);
            switch (heff_tag_of(v_x31_2423)) {
            case TAG_MkPair: {
              V v_x_2424 = heff_field(v_x31_2423, 0);
              V v_j_2425 = heff_field(v_x31_2423, 1);
              V v_ru_24x31_2423_24MkPair = heff_take_reuse_n(v_x31_2423, 3ULL, 2);
              V v_t_2426 = heff_tag_at_n(v_ru_24x31_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2422_24Just, TAG_CTest, 1, (V[]){v_x_2424}), v_j_2425});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2426}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2422)}});
          }
        } else {
          heff_drop_rec(v_k_240, 1);
          if (heff_strEq_c_lent(v_x3_242, ((V)&g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str4), 2)) {
            V v_x3_2427 = heff_tr(heff_call(heff_get_n(v_c_241, 0, 1), 2, (V[]){v_z_243, v_z_244}));
            switch (heff_tag_of(v_x3_2427)) {
            case TAG_Nothing: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2428 = heff_field(v_x3_2427, 0);
              V v_ru_24x3_2427_24Just = heff_take_reuse_n(v_x3_2427, 1ULL, 1);
              switch (heff_tag_of(v_x31_2428)) {
              case TAG_MkPair: {
                V v_x_2429 = heff_field(v_x31_2428, 0);
                V v_j_2430 = heff_field(v_x31_2428, 1);
                V v_ru_24x31_2428_24MkPair = heff_take_reuse_n(v_x31_2428, 3ULL, 2);
                V v_t_2431 = heff_tag_at_n(v_ru_24x31_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2427_24Just, TAG_CNot, 1, (V[]){v_x_2429}), v_j_2430});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2431}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2428)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_2427)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x3_242, ((V)&g_heff_2ecompile_2eirtext_2econdOfTag_24cpr_str5), 2)) {
              V v_x3_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_c_241, 0)), 2, (V[]){heff_dup(v_z_243), v_z_244}));
              switch (heff_tag_of(v_x3_2432)) {
              case TAG_Nothing: {
                heff_drop_rec(v_c_241, 1);
                heff_drop(v_z_243);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2433 = heff_field(v_x3_2432, 0);
                heff_take_n(v_x3_2432, 1ULL, 1);
                switch (heff_tag_of(v_x31_2433)) {
                case TAG_MkPair: {
                  V v_x_2434 = heff_field(v_x31_2433, 0);
                  V v_j_2435 = heff_field(v_x31_2433, 1);
                  V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
                  V v_x3_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_c_241, 0)), 2, (V[]){heff_dup(v_z_243), v_j_2435}));
                  switch (heff_tag_of(v_x3_2436)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_c_241, 1);
                    heff_drop(v_z_243);
                    heff_drop(v_x_2434);
                    heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2437 = heff_field(v_x3_2436, 0);
                    heff_take_n(v_x3_2436, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2437)) {
                    case TAG_MkPair: {
                      V v_x_2438 = heff_field(v_x31_2437, 0);
                      V v_j_2439 = heff_field(v_x31_2437, 1);
                      heff_take_n(v_x31_2437, 3ULL, 2);
                      V v_x3_2440 = heff_tr(heff_call(heff_get_n(v_c_241, 0, 1), 2, (V[]){v_z_243, v_j_2439}));
                      switch (heff_tag_of(v_x3_2440)) {
                      case TAG_Nothing: {
                        heff_drop(v_x_2434);
                        heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                        heff_drop(v_x_2438);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2441 = heff_field(v_x3_2440, 0);
                        heff_take_n(v_x3_2440, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2441)) {
                        case TAG_MkPair: {
                          V v_x_2442 = heff_field(v_x31_2441, 0);
                          V v_j_2443 = heff_field(v_x31_2441, 1);
                          heff_take_n(v_x31_2441, 3ULL, 2);
                          V v_t_2444 = heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_j_2443});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2444}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2440)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2437)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2436)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2433)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2432)}});
              }
            } else {
              heff_drop_rec(v_c_241, 1);
              return ({ V a_0 = v_z_243; V a_1 = v_z_244; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_243); heff_drop(v_z_244); r_; });
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eirtext_2eckOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eirtext_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eckOf_entry, 1, 0};

V g_heff_2ecompile_2eirtext_2eckOf(V v_k_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2ecompile_2eirtext_2eckOf_lam0, 2, 1, (V[]){v_k_240})});
}
V g_heff_2ecompile_2eirtext_2eckOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eckOf(a[0]);
}
V g_heff_2ecompile_2eirtext_2eckOf_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2ecompile_2eirtext_2eckOf(heff_dup(v_k_240)));
  HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_241, v_i_242));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_246;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        return ({ V a_0 = v_k_240; V a_1 = v_t_243; V a_2 = v_x_248; V a_3 = v_s_241; V a_4 = v_j_249; V r_ = (g_heff_2ecompile_2eirtext_2econdOfTag(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_248); r_; });
      }
      default: return heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop(v_s_241);
      heff_drop(v_k_240);
      heff_drop(v_t_243);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(V v_more_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = ({ V a_0 = v_x_247; HeffT2 r_ = (g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(a_0)); heff_drop(v_x_247); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2412 = v_field_2411;
            V v_x3_2413 = heff_tr(heff_call(v_more_240, 2, (V[]){v_s_241, v_j_248}));
            switch (heff_tag_of(v_x3_2413)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              heff_drop(v_x_2412);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2414 = heff_field(v_x3_2413, 0);
              V v_ru_24x3_2413_24Just = heff_take_reuse_n(v_x3_2413, 1ULL, 1);
              switch (heff_tag_of(v_x31_2414)) {
              case TAG_MkPair: {
                V v_x_2415 = heff_field(v_x31_2414, 0);
                V v_j_2416 = heff_field(v_x31_2414, 1);
                heff_take_n(v_x31_2414, 3ULL, 2);
                V v_t_2417 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_x_2415}), v_j_2416});
                return heff_tag_at_n(v_ru_24x3_2413_24Just, TAG_Just, 1, (V[]){v_t_2417});
              }
              default: return heff_nomatch(v_x31_2414);
              }
            }
            default: return heff_nomatch(v_x3_2413);
            }
          } else {
            heff_drop(v_more_240);
            heff_drop(v_s_241);
            heff_drop(v_j_248);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_more_240);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2econsD_24s1169047453x746181915(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2eexprOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprOf_entry, 4, 0};

V g_heff_2ecompile_2eirtext_2eexprOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eirtext_2eexprOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eirtext_2eexprOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eirtext_2eexprOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eirtext_2edk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eirtext_2edk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2edk_lam0, 2, 0};

static V g_heff_2ecompile_2eirtext_2edk_val;
static HEFF_ONCE g_heff_2ecompile_2eirtext_2edk_st;
static V g_heff_2ecompile_2eirtext_2edk_init(void) {
  return heff_rec_n(1, shape_go, (V[]){((V)&g_heff_2ecompile_2eirtext_2edk_lam0_clo)});
}
V g_heff_2ecompile_2eirtext_2edk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eirtext_2edk_st)) return g_heff_2ecompile_2eirtext_2edk_val;
  return heff_global(&g_heff_2ecompile_2eirtext_2edk_val, &g_heff_2ecompile_2eirtext_2edk_st, g_heff_2ecompile_2eirtext_2edk_init);
}
V g_heff_2ecompile_2eirtext_2edk_lam0(V self, V *args) {
  V v_s_240 = args[0];
  V v_i_241 = args[1];
  V v_t_242 = heff_dup(g_heff_2ecompile_2eirtext_2edk_get());
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_240, v_i_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        return ({ V a_0 = v_t_242; V a_1 = v_x_247; V a_2 = v_s_240; V a_3 = v_j_248; V r_ = (g_heff_2ecompile_2eirtext_2eexprOf(a_0, a_1, a_2, a_3)); heff_drop(v_x_247); r_; });
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_t_242);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ecompile_2eirtext_2ebytesH_24cpr(V v_s_240, V v_box_24i_241, V v_a_242, V v_b_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    V v_t_244 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), MK_INT(256LL));
    V v_f_245 = heff_intMod(heff_intAdd(v_t_244, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_246 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), MK_INT(256LL));
    V v_f_247 = heff_intMod(heff_intAdd(v_t_246, MK_INT(1LL)), MK_INT(2147483629LL));
    return ((HeffT2){{v_f_245, v_f_247}});
  } else {
    V v_t_248 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2));
    V v_t_249 = heff_intMod(heff_intAdd(v_t_248, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_2410 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2));
    V v_t_2411 = heff_intMod(heff_intAdd(v_t_2410, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_249;
    V t_3 = v_t_2411;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
Clo g_heff_2ecompile_2eirtext_2eexprsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2eexprsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_es_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_242}), heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eirtext_2eexprsH_24dps(v_es_243, v_rest_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprsH(a[0], a[1]);
}
Clo g_heff_2ecompile_2eirtext_2eexprsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2eexprsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2eexprsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_es_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_243}), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_es_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2eexprsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2eexprsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2efieldsH_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2efieldsH_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x11_243, 0);
      V v_e_246 = heff_field(v_x11_243, 1);
      V v_ru_24x11_243_24MkPair = heff_take_reuse_n(v_x11_243, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_l_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x11_243_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_e_246}), heff_hole()});
      V v_u_2410 = heff_setField(v_cell_247, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_fs_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_249;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2efieldsH_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2efieldsH_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eirtext_2earmsH_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2earmsH_entry, 2, 0};

V g_heff_2ecompile_2eirtext_2earmsH(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_arms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_x11_242, 0);
      V v_vs_245 = heff_field(v_x11_242, 1);
      V v_b_246 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 7ULL, 3);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_245));
      V v_t_248 = (g_heff_2ecompile_2eirtext_2earmsH(v_arms_243, v_rest_241));
      V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_246}), v_t_248});
      V v_t_2410 = (g_heff_2ecompile_2eirtext_2estrsH(v_vs_245, v_t_249));
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HN, 1, (V[]){v_t_247}), v_t_2410});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_t_244}), v_t_2411});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eirtext_2earmsH_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2earmsH(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V v_a_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return ((HeffT2){{v_a_240, v_b_241}});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_HE: {
      V v_e_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_246 = (g_heff_2ecompile_2eirtext_2enodeH(v_e_245, v_rest_244));
      V t_0 = v_a_240;
      V t_1 = v_b_241;
      V t_2 = v_t_246;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_HS: {
      V v_s_247 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      HeffT2 v_t_248 = ({ V a_0 = v_s_247; V a_1 = MK_INT(0LL); V a_2 = v_a_240; V a_3 = v_b_241; HeffT2 r_ = (g_heff_2ecompile_2eirtext_2ebytesH_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_s_247); r_; });
      {
        V v_field_249 = v_t_248.f[0];
        V v_field_2410 = v_t_248.f[1];
        V v_a_2411 = v_field_249;
        V v_b_2412 = v_field_2410;
        V t_0 = v_a_2411;
        V t_1 = v_b_2412;
        V t_2 = v_rest_244;
        v_a_240 = t_0;
        v_b_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_HN: {
      V v_n_2413 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2414 = heff_intAdd(heff_intMul(v_a_240, MK_INT(1000003LL)), heff_intAdd(heff_dup(v_n_2413), MK_INT(300LL)));
      V v_t_2415 = heff_intMod(heff_intAdd(v_t_2414, MK_INT(1LL)), MK_INT(2147483647LL));
      V v_t_2416 = heff_intAdd(heff_intMul(v_b_241, MK_INT(999983LL)), heff_intAdd(v_n_2413, MK_INT(300LL)));
      V v_t_2417 = heff_intMod(heff_intAdd(v_t_2416, MK_INT(1LL)), MK_INT(2147483629LL));
      V t_0 = v_t_2415;
      V t_1 = v_t_2417;
      V t_2 = v_rest_244;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_HC: {
      V v_c_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2419 = (g_heff_2ecompile_2eirtext_2econdH(v_c_2418, v_rest_244));
      V t_0 = v_a_240;
      V t_1 = v_b_241;
      V t_2 = v_t_2419;
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str11, 1, "\?");
Clo g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry, 3, 0};

V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(V v_rest_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_246;
    switch (heff_tag_of(v_x_243)) {
    case TAG_FtFloat: {
      v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      switch (heff_tag_of(v_w_245)) {
      case TAG_I8: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_245);
      }
      break;
    }
    case TAG_FtOther: {
      v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str10);
      break;
    }
    case TAG_FtAny: {
      v_x_246 = ((V)&g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_246}), heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_rest_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_rest_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eirtext_2estrsH_24f1946140229x324275192_24dps(a[0], a[1], a[2]);
}