// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2ehttp_2esameName_2esameFrom_240(V, V, V);
V g_std_2ehttp_2esameName_2esameFrom_240_entry(V self, V *a);
extern Clo g_std_2ehttp_2esameName_2esameFrom_240_clo;
Clo g_std_2ehttp_2esameName_2esameFrom_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2ehttp_2esameName_2esameFrom_240_entry, 3, 0};

V g_std_2ehttp_2esameName_2esameFrom_240(V v_a_240, V v_b_241, V v_box_24i_242) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_a_240, 0)) <= v_i_242)) {
    return NTAG(TAG_True);
  } else {
    V v_c_243 = heff_strByteAt_lent(v_a_240, heff_box_word(v_i_242), 2);
    V v_t_244;
    if (((((int64_t)65ULL) <= heff_peek_word(v_c_243)) && (heff_peek_word(v_c_243) <= ((int64_t)90ULL)))) {
      v_t_244 = heff_box_word((heff_unbox_word(v_c_243) + ((int64_t)32ULL)));
    } else {
      v_t_244 = v_c_243;
    }
    V v_c_245 = heff_strByteAt_lent(v_b_241, heff_box_word(v_i_242), 2);
    V v_t_246;
    if (((((int64_t)65ULL) <= heff_peek_word(v_c_245)) && (heff_peek_word(v_c_245) <= ((int64_t)90ULL)))) {
      v_t_246 = heff_box_word((heff_unbox_word(v_c_245) + ((int64_t)32ULL)));
    } else {
      v_t_246 = v_c_245;
    }
    if ((heff_unbox_word(v_t_244) == heff_unbox_word(v_t_246))) {
      V t_0 = v_a_240;
      V t_1 = v_b_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      v_a_240 = t_0;
      v_b_241 = t_1;
      v_i_242 = t_2;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
}
V g_std_2ehttp_2esameName_2esameFrom_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ehttp_2esameName_2esameFrom_240(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}