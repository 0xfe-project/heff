#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Args 26338
#define TAG_Await 41810
#define TAG_CloseFile 52884
#define TAG_Closed 4831
#define TAG_Copy 17796
#define TAG_Directory 35277
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_IsTerminal 53507
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Link 17969
#define TAG_Log 24016
#define TAG_Message 12631
#define TAG_MkDir 57961
#define TAG_MkHandle 45059
#define TAG_MkKid 64674
#define TAG_Move 53768
#define TAG_Now 25954
#define TAG_OpenPath 44468
#define TAG_Other 45236
#define TAG_PathUri 23459
#define TAG_Platform 55558
#define TAG_ProgramPath 46819
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadChunk 39695
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_ReadLine 54539
#define TAG_ReadOnly 17623
#define TAG_ReadStdin 20528
#define TAG_RealPath 18882
#define TAG_Regular 40886
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Seek 25805
#define TAG_Send 26077
#define TAG_SetMode 203
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Standard 18554
#define TAG_Stat 40105
#define TAG_StatHandle 28117
#define TAG_TempDirectory 27311
#define TAG_TempFile 43961
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_WorkingDir 28879
#define TAG_Writable 11315
#define TAG_Write 36323
#define TAG_WriteBytes 40855
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_WriteString 34128
#define LBL_code 9554612
#define LBL_err 310239
#define LBL_kind 9787483
#define LBL_message 1186782793
#define LBL_mode 9852522
#define LBL_modified 129625309
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_size 10026184
#define LBL_status 1054660381
V g_run_24entry_get(void);
// The standard streams' side of lib/std/io.hf, for the C backend: an
// effect provider.  A provider of the C backend defines, for each
// effect definition X of its module, `static V heff_provider_X(V p, V
// k)`: the operation `p` (a tag, `heff_tag_of`, its fields
// `heff_field`), done, and its answer given to the continuation `k`,
// last (`heff_tail`), as the JavaScript providers do (`k(a[1])`).  A
// function of the operation's (`ReadStdin`'s) is asked for its value
// through `heff_tr`.  It owns `p` and `k` (reference counts, as
// lib/c/runtime.c says): it takes what it keeps of `p` (`heff_dup`),
// drops `p`, and gives `k` away.  A number is as the runtime keeps it: an
// Int a word (`INT_OF`, `MK_INT`) or big, an Int64 and a UInt64 as an Int
// is, an integer of a fixed-width type of up to 32 bits a word of its
// value, a Float32 a word of its bits (`heff_f32_of`, `heff_f32`), a Float64
// boxed (`FLT_OF`, `heff_flt`); a Rune is a word of its code point.  It
// is bundled after lib/c/runtime.c, whose functions it uses -- among
// them the world's, which hold what every provider hands out
// (`heff_hold`, `heff_held`, `heff_release`: lib/std/handle.hf says how).
// A string it is given, or gives, crosses to the system and back only
// through the runtime's helpers, by what it is there -- content, a path,
// a name or text: `heff_str_bytes`, `heff_put`, `heff_cstr`,
// `heff_str_text`, `heff_cstr_text` and the like ("What providers share"
// in lib/c/runtime.c says which is which) -- never by its units, so that
// how the runtime keeps a string is the runtime's alone.

// (the lines std.progress draws on the terminal, once there are any:
// what is written clears them first, and they come back below it --
// lib/std/progress.provider.c says how)
static void (*heff_lines)(int);

static V heff_provider_stdio(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Write: {
    if (heff_lines) heff_lines(1);
    heff_put(stdout, heff_field(p, 0));
    if (heff_lines) heff_lines(0);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_WriteErr: {
    if (heff_lines) heff_lines(1);
    fflush(stdout);
    heff_put(stderr, heff_field(p, 0));
    if (heff_lines) heff_lines(0);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ReadStdin: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    size_t cap = 4096, n = 0;
    unsigned char *buf = heff_alloc(cap);
    size_t got;
    while ((got = fread(buf + n, 1, cap - n, stdin)) > 0) {
      n += got;
      if (n == cap) {
        unsigned char *b2 = heff_alloc(cap * 2);
        memcpy(b2, buf, n);
        free(buf);
        buf = b2;
        cap *= 2;
      }
    }
    V s = heff_str_bytes(buf, (int64_t)n);
    free(buf);
    V x = heff_tr(heff_app1(f, s));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of stdio");
    return 0;
  }
}

// The process's side of lib/std/process.hf, for the C backend: an effect
// provider (the shape of one is said in lib/std/io.provider.c).
// `Exit` ends the program there; `Exec` runs the command in its place.

#ifdef _WIN32
#include <direct.h>
#else
#include <unistd.h>
#endif
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif

// (where the program is: its executable, as the system says)
static V heff_program_path(void) {
  char buf[4096];
#if defined(_WIN32)
  DWORD n = GetModuleFileNameA(NULL, buf, sizeof buf);
  if (n == 0 || n >= sizeof buf) return heff_str_text(heff_argv[0]);
  return heff_str_text(buf);
#elif defined(__APPLE__)
  uint32_t n = sizeof buf;
  if (_NSGetExecutablePath(buf, &n) != 0) return heff_str_text(heff_argv[0]);
#else
  ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
  if (n < 0) return heff_str_text(heff_argv[0]);
  buf[n] = 0;
#endif
#ifndef _WIN32
  char real[4096];
  return heff_str_text(realpath(buf, real) ? real : buf);
#endif
}

// (a list of strings as a NULL-ended array of C strings, `first` first:
// NULL if one of them cannot be a C string)
static char **heff_argv_of(const char *first, V l) {
  int64_t n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  char **as = heff_alloc((n + 2) * sizeof(char *));
  as[0] = (char *)first;
  int64_t i = 1;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) {
    as[i] = heff_cstr_text(heff_field(c, 0));
    if (!as[i]) {
      for (int64_t j = 1; j < i; j++) free(as[j]);
      free(as);
      return NULL;
    }
    i++;
  }
  as[i] = NULL;
  return as;
}


// (the lines std.progress draws on the terminal, once there are any,
// cleared for good where a command runs in the program's place: an
// `Exit` clears them as the program ends -- lib/std/progress.provider.c)
static void (*heff_lines)(int);

static uint32_t heff_run_shape[3] = { LBL_status, LBL_out, LBL_err };

// (a command run, as runtime.c's heff_capture runs it: -1 its status if
// it cannot be, a NUL in its name or an argument)
static V heff_run(V cmd, V args) {
  char *c = heff_cstr_text(cmd);
  char **as = c ? heff_argv_of(c, args) : NULL;
  Buf bo = {0}, be = {0};
  int64_t status = as ? heff_capture(as, &bo, &be) : -1;
  V f[3] = {
    MK_INT(status),
    heff_str_bytes(bo.s ? bo.s : "", (int64_t)bo.n),
    heff_str_bytes(be.s ? be.s : "", (int64_t)be.n),
  };
  free(bo.s);
  free(be.s);
  return heff_rec(3, heff_run_shape, f);
}

static V heff_provider_process(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Args: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_strs_text(heff_argv + 1, heff_argc - 1));
    return heff_tail(k, 1, &x);
  }
  case TAG_GetEnv: {
    char *name = heff_cstr_text(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    const char *v = name ? getenv(name) : NULL;
    free(name);
    V x = heff_answer(f, v ? heff_just(heff_str_text(v)) : heff_nothing);
    return heff_tail(k, 1, &x);
  }
  case TAG_ProgramPath: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_program_path());
    return heff_tail(k, 1, &x);
  }
  case TAG_WorkingDir: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    char buf[4096];
#ifdef _WIN32
    const char *d = _getcwd(buf, sizeof buf);
#else
    const char *d = getcwd(buf, sizeof buf);
#endif
    V x = heff_answer(f, heff_str_text(d ? d : "."));
    return heff_tail(k, 1, &x);
  }
  case TAG_Platform: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#if defined(__APPLE__)
    const char *pl = "darwin";
#elif defined(_WIN32)
    const char *pl = "win32";
#else
    const char *pl = "linux";
#endif
    V x = heff_answer(f, heff_str_text(pl));
    return heff_tail(k, 1, &x);
  }
  case TAG_Exit: {
    int code = (int)INT_OF(heff_field(p, 0));
    fflush(stdout);
    fflush(stderr);
    exit(code);
  }
  case TAG_Run: {
    V cmd = heff_dup(heff_field(p, 0)), args = heff_dup(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    V r = heff_run(cmd, args);
    heff_drop(cmd);
    heff_drop(args);
    V x = heff_answer(f, r);
    return heff_tail(k, 1, &x);
  }
  case TAG_Exec: {
    char *c = heff_cstr_text(heff_field(p, 0));
    char **as = c ? heff_argv_of(c, heff_field(p, 1)) : NULL;
    // (std.progress's lines, if any are drawn, cleared for good: the
    // command has the terminal now)
    if (heff_lines) heff_lines(2);
    fflush(stdout);
    fflush(stderr);
    if (as) {
#ifdef _WIN32
      // (no exec on Windows: the command is run, and its exit code this
      // program's)
      HANDLE h = heff_spawn(as, GetStdHandle(STD_OUTPUT_HANDLE), GetStdHandle(STD_ERROR_HANDLE));
      if (h) exit((int)heff_wait(h));
#else
      execvp(c, as);
#endif
    }
    fprintf(stderr, "%s: cannot run it\n", c ? c : "the command");
    exit(1);
  }
  default:
    heff_fail("not an operation of process");
    return 0;
  }
}

// The disk's side of lib/std/filesystem.hf, for the C backend: an effect
// provider (the shape of one is said in lib/std/io.provider.c).
//
// Whole files, directories and paths are done there and then.  An open
// file is a `FsFile` the world holds (lib/std/handle.hf), let go of --
// closed -- by `CloseFile`; the program has its number.  It reads ahead
// into a buffer of its own, from which lines and chunks are taken.
//
// A read or a write of an open file is a `FsOp`, done in steps as
// std.net's are (lib/std/net.provider.c): where a scheduler of
// std.reactor's runs, a pipe, a terminal or a socket -- what poll can
// say is ready -- is polled first, and the op waits in the runtime's
// reactor (lib/c/runtime.c, "Outside operations done later") until it
// is, the other green threads going on.  The descriptor is left as it
// is, never made non-blocking (a standard stream's flags are its
// parent's too): a read is done once poll says there is something to
// read, and a write of no more than PIPE_BUF bytes once it says there
// is room.  A regular file is always ready, as poll sees it, and is read
// and written there and then, the whole program waiting for the disk.

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#ifdef _WIN32
// (no links on Windows as stat sees them, and mkdir takes no mode)
#define lstat stat
#define S_ISLNK(m) 0
#define heff_mkdir(p) mkdir(p)
#define heff_is_sep(c) ((c) == '/' || (c) == '\\')
#else
#include <limits.h>
#define heff_mkdir(p) mkdir(p, 0777)
#define heff_is_sep(c) ((c) == '/')
#endif

// (a file's text, if it can be read)
static V heff_read_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) return heff_nothing;
  Buf b = {0};
  char chunk[65536];
  size_t got;
  while ((got = fread(chunk, 1, sizeof chunk, f)) > 0) buf_put(&b, chunk, got);
  int bad = ferror(f);
  fclose(f);
  V s = bad ? 0 : heff_str_bytes(b.s ? b.s : "", (int64_t)b.n);
  free(b.s);
  return bad ? heff_nothing : heff_just(s);
}

static int heff_write_file(const char *path, V s) {
  FILE *f = fopen(path, "wb");
  if (!f) return 0;
  heff_put(f, s);
  return fclose(f) == 0;
}

// (a directory is at `path`, links followed)
static int heff_is_dir(const char *path) {
  struct stat st;
  return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

// (a directory and those it is in: whether a directory is there -- a
// file there is none)
static int heff_mkdir_p(char *path) {
  for (char *c = path + 1; *c; c++)
    if (heff_is_sep(*c)) {
      char sep = *c;
      *c = 0;
      // (a drive, `C:`, is there already)
      int drive = c[-1] == ':';
      int ok = drive || heff_mkdir(path) == 0 || errno == EEXIST;
      *c = sep;
      if (!ok) return 0;
    }
  return heff_mkdir(path) == 0 || (errno == EEXIST && heff_is_dir(path));
}

// (the names in a directory, sorted)
static V heff_read_dir(const char *path) {
  DIR *d = opendir(path);
  if (!d) return heff_nothing;
  int64_t n = 0, cap = 64;
  char **ns = heff_alloc(cap * sizeof(char *));
  struct dirent *e;
  while ((e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    if (n == cap) {
      char **n2 = heff_alloc(cap * 2 * sizeof(char *));
      memcpy(n2, ns, n * sizeof(char *));
      free(ns);
      ns = n2;
      cap *= 2;
    }
    ns[n++] = strdup(e->d_name);
  }
  closedir(d);
  qsort(ns, n, sizeof(char *), heff_cmp_cstr);
  V l = heff_strs_bytes(ns, n);
  for (int64_t i = 0; i < n; i++) free(ns[i]);
  free(ns);
  return heff_just(l);
}

// (every file and directory under `p`, its mode's write bits off, or on:
// a directory is made writable before what it holds, read-only after)
static int heff_chmod_all(const char *p, int writable) {
  struct stat st;
  if (lstat(p, &st) != 0) return errno == ENOENT ? -1 : 0;
  if (S_ISLNK(st.st_mode)) return 1;
  mode_t mode = writable ? (st.st_mode | 0200) : (st.st_mode & ~0222);
  mode &= 07777;
  if (S_ISDIR(st.st_mode)) {
    if (writable && chmod(p, mode) != 0) return 0;
    DIR *d = opendir(p);
    if (!d) return 0;
    struct dirent *e;
    int ok = 1;
    while (ok && (e = readdir(d))) {
      if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
      char *q = heff_join(p, e->d_name);
      ok = heff_chmod_all(q, writable) != 0;
      free(q);
    }
    closedir(d);
    if (!ok) return 0;
    if (!writable && chmod(p, mode) != 0) return 0;
    return 1;
  }
  return chmod(p, mode) == 0;
}

// (a file, or a directory and all it holds; nothing there is no failure)
static int heff_remove_all(const char *p) {
  struct stat st;
  if (lstat(p, &st) != 0) return errno == ENOENT;
  if (!S_ISDIR(st.st_mode)) return unlink(p) == 0;
  DIR *d = opendir(p);
  if (!d) return 0;
  struct dirent *e;
  int ok = 1;
  while (ok && (e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    char *q = heff_join(p, e->d_name);
    ok = heff_remove_all(q);
    free(q);
  }
  closedir(d);
  return ok && rmdir(p) == 0;
}

// (a file's bytes copied to `q`, which is given `mode`)
static int heff_copy_file(const char *p, const char *q, mode_t mode) {
  FILE *f = fopen(p, "rb");
  if (!f) return 0;
  FILE *g = fopen(q, "wb");
  if (!g) {
    fclose(f);
    return 0;
  }
  char *chunk = heff_alloc(65536);
  size_t got;
  int ok = 1;
  while (ok && (got = fread(chunk, 1, 65536, f)) > 0) ok = fwrite(chunk, 1, got, g) == got;
  ok = ok && !ferror(f);
  free(chunk);
  fclose(f);
  ok = fclose(g) == 0 && ok;
  return ok && chmod(q, mode) == 0;
}

// (a file, or a directory and all it holds, copied to `q`: links
// followed, modes kept -- a directory's once what it holds is in it)
static int heff_copy_all(const char *p, const char *q) {
  struct stat st;
  if (stat(p, &st) != 0) return 0;
  mode_t mode = st.st_mode & 07777;
  if (!S_ISDIR(st.st_mode)) return heff_copy_file(p, q, mode);
  if (heff_mkdir(q) != 0) return 0;
  DIR *d = opendir(p);
  if (!d) return 0;
  struct dirent *e;
  int ok = 1;
  while (ok && (e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    char *a = heff_join(p, e->d_name);
    char *b = heff_join(q, e->d_name);
    ok = heff_copy_all(a, b);
    free(a);
    free(b);
  }
  closedir(d);
  return ok && chmod(q, mode) == 0;
}

// (nothing is at `p`: no file, directory or link)
static int heff_nothing_at(const char *p) {
  struct stat st;
  return lstat(p, &st) != 0 && errno == ENOENT;
}

// (what an operation answers where its path is none, a string with a NUL
// in it: it fails -- `Nothing` where it reads, `False` where it does)
static V heff_fs_failed(V p) {
  int tag = heff_tag_of(p);
  int at = tag == TAG_WriteFile || tag == TAG_Copy || tag == TAG_Move || tag == TAG_Replace ? 2 : 1;
  V f = heff_dup(heff_field(p, at));
  heff_drop(p);
  return heff_answer(f, tag == TAG_ReadFile || tag == TAG_ReadDir ? heff_nothing : heff_bool(0));
}

// (an operation of whole files and paths: answered by a `Bool` or a
// `Maybe`)
static V heff_fs_whole(V p, V k) {
  char *path = heff_cstr(heff_field(p, 0));
  V x;
  if (!path) {
    x = heff_fs_failed(p);
    return heff_tail(k, 1, &x);
  }
  switch (heff_tag_of(p)) {
  case TAG_ReadFile: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_read_file(path));
    break;
  }
  case TAG_WriteFile: {
    int ok = heff_write_file(path, heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_MkDir: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_bool(heff_mkdir_p(path)));
    break;
  }
  case TAG_ReadDir: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_read_dir(path));
    break;
  }
  case TAG_Remove: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    int ok = heff_chmod_all(path, 1) != 0 && heff_remove_all(path);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_ReadOnly: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_bool(heff_chmod_all(path, 0) == 1));
    break;
  }
  case TAG_Writable: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_bool(heff_chmod_all(path, 1) == 1));
    break;
  }
  case TAG_Copy: {
    char *to = heff_cstr(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    int ok = to && heff_nothing_at(to) && heff_copy_all(path, to);
    free(to);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_Move: {
    char *to = heff_cstr(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    int ok = to && heff_nothing_at(to) && rename(path, to) == 0;
    free(to);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_Replace: {
    char *to = heff_cstr(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    // (rename(2) puts a file in place of another at once; Windows' does
    // not over one there, MoveFileEx does)
#ifdef _WIN32
    int ok = to && MoveFileExA(path, to, MOVEFILE_REPLACE_EXISTING) != 0;
#else
    int ok = to && rename(path, to) == 0;
#endif
    free(to);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  default:
    heff_fail("not an operation of fs");
    return 0;
  }
  free(path);
  return heff_tail(k, 1, &x);
}

// Errors
// ---------------------------------------------------------------------

#ifndef EWOULDBLOCK
#define EWOULDBLOCK EAGAIN
#endif
#ifdef _WIN32
// (nothing is polled on Windows: an op is done there and then)
#ifndef POLLIN
#define POLLIN 1
#define POLLOUT 4
#endif
#ifndef O_CLOEXEC
#define O_CLOEXEC 0
#endif
#else
#ifndef O_BINARY
#define O_BINARY 0
#endif
#endif

// (an errno's name, the same on every system where its number is not)
static const char *fs_errno_name(int e) {
  switch (e) {
#define FS_E(x) case x: return #x;
  FS_E(EACCES) FS_E(EAGAIN) FS_E(EBADF) FS_E(EBUSY) FS_E(EEXIST) FS_E(EFBIG)
  FS_E(EINTR) FS_E(EINVAL) FS_E(EIO) FS_E(EISDIR) FS_E(EMFILE)
  FS_E(ENAMETOOLONG) FS_E(ENFILE) FS_E(ENODEV) FS_E(ENOENT) FS_E(ENOMEM)
  FS_E(ENOSPC) FS_E(ENOSYS) FS_E(ENOTDIR) FS_E(ENOTEMPTY) FS_E(ENXIO)
  FS_E(EPERM) FS_E(EPIPE) FS_E(EROFS) FS_E(ESPIPE) FS_E(EXDEV)
#ifdef ELOOP
  FS_E(ELOOP)
#endif
#ifdef ETXTBSY
  FS_E(ETXTBSY)
#endif
#ifdef EOVERFLOW
  FS_E(EOVERFLOW)
#endif
#ifdef EDQUOT
  FS_E(EDQUOT)
#endif
#if EWOULDBLOCK != EAGAIN
  FS_E(EWOULDBLOCK)
#endif
#undef FS_E
  default: return "E?";
  }
}

static uint32_t fs_error_shape[3] = { LBL_code, LBL_name, LBL_message };
static uint32_t fs_status_shape[4] = { LBL_kind, LBL_size, LBL_modified, LBL_mode };

// (a `FileError` of errno `err`)
static V fs_error(int err) {
  const char *name = fs_errno_name(err);
  char other[24];
  if (name[1] == '?') {
    snprintf(other, sizeof other, "errno %d", err);
    name = other;
  }
  V f[3] = { heff_int(err), heff_str_text(name), heff_str_text(strerror(err)) };
  return heff_rec(3, fs_error_shape, f);
}

static V fs_left(int err) {
  V x = fs_error(err);
  return heff_tag_n(TAG_Left, 1, &x);
}

static V fs_right(V x) { return heff_tag_n(TAG_Right, 1, &x); }

// (`Right MkUnit`)
static V fs_done(void) { return fs_right(NTAG(TAG_MkUnit)); }

// (`Right` what the system says of a file -- `r`, stat's answer, 0 -- or
// `Left` why not)
static V fs_status(int r, const struct stat *st) {
  if (r != 0) return fs_left(errno);
  int kind = S_ISREG(st->st_mode) ? TAG_Regular
           : S_ISDIR(st->st_mode) ? TAG_Directory
           : S_ISLNK(st->st_mode) ? TAG_Link
           : TAG_Other;
#if defined(__APPLE__)
  int64_t s = (int64_t)st->st_mtimespec.tv_sec, ns = (int64_t)st->st_mtimespec.tv_nsec;
#elif defined(_WIN32)
  int64_t s = (int64_t)st->st_mtime, ns = 0;
#else
  int64_t s = (int64_t)st->st_mtim.tv_sec, ns = (int64_t)st->st_mtim.tv_nsec;
#endif
  V f[4] = { NTAG(kind), heff_int((int64_t)st->st_size), heff_int(s * 1000000000 + ns),
             heff_int((int64_t)(st->st_mode & 07777)) };
  return fs_right(heff_rec(4, fs_status_shape, f));
}

// (a number given as an `Int`, at `*n`: whether it is one of a word)
static int fs_int(V v, int64_t *n) {
  if (!IS_INT(v)) return 0;
  *n = INT_OF(v);
  return 1;
}

// Open files
// ---------------------------------------------------------------------

// (the world's open files, told from what other providers hand out)
#define FS_MAGIC 0x66696c65u
// (how much is read ahead at a time; a chunk's most)
#define FS_BUF ((size_t)65536)
#define FS_READ_MAX ((int64_t)16 << 20)

typedef struct {
  uint32_t magic;
  int fd;            // (-1 once closed)
  int refs;          // (the world's, and each op's that has it)
  int standard;      // (a standard stream's number, 0 to 2: never closed;
                     //  else -1)
  int pollable;      // (a pipe, a terminal, a socket: polled, where a
                     //  scheduler runs)
  int seekable;      // (a regular file: what was read ahead is given back
                     //  before a write)
  uint8_t *buf;      // (read ahead: what is not yet taken, from `at` to
  size_t cap, at, end;  //  `end`)
  uint64_t taken;    // (how many times something was taken from it)
} FsFile;

// (the standard streams' files, once asked for: one each, so that what
// one has read ahead is the other's too)
static FsFile *fs_standard[3];

static void fs_unref(FsFile *h) {
  if (--h->refs > 0) return;
  free(h->buf);
  h->magic = 0;
  free(h);
}

// (the world letting go of it: closed, unless it is a standard stream)
static void fs_let_go(void *x) {
  FsFile *h = x;
  if (h->standard >= 0) fs_standard[h->standard] = NULL;
  else if (h->fd >= 0) close(h->fd);
  h->fd = -1;
  fs_unref(h);
}

static FsFile *fs_new(int fd, int standard) {
  FsFile *h = heff_alloc(sizeof *h);
  memset(h, 0, sizeof *h);
  h->magic = FS_MAGIC;
  h->fd = fd;
  h->refs = 1;
  h->standard = standard;
  struct stat st;
  if (fstat(fd, &st) == 0) {
    h->seekable = S_ISREG(st.st_mode);
#ifndef _WIN32
    h->pollable = S_ISFIFO(st.st_mode) || S_ISCHR(st.st_mode) || S_ISSOCK(st.st_mode);
#endif
  }
  return h;
}

// (the file held by the world: `MkHandle i`)
static V fs_handle(FsFile *h) {
  V i = MK_INT(heff_hold(h, fs_let_go));
  return heff_tag_n(TAG_MkHandle, 1, &i);
}

// (the file a handle is the number of, or the program failed: it is none)
static FsFile *fs_file(V handle) {
  FsFile *h = heff_held(INT_OF(heff_field(handle, 0)));
  if (h->magic != FS_MAGIC) heff_fail("std.filesystem: the handle is no open file");
  return h;
}

static size_t fs_buffered(FsFile *h) { return h->end - h->at; }

// (room for `n` more bytes after what is read ahead: what is taken let
// go of, the buffer grown)
static void fs_room(FsFile *h, size_t n) {
  if (h->at == h->end) h->at = h->end = 0;
  if (h->cap - h->end >= n) return;
  if (h->at > 0) {
    memmove(h->buf, h->buf + h->at, h->end - h->at);
    h->end -= h->at;
    h->at = 0;
  }
  if (h->cap - h->end >= n) return;
  size_t cap = h->cap ? h->cap : FS_BUF;
  while (cap - h->end < n) cap *= 2;
  uint8_t *b = heff_alloc(cap);
  if (h->end) memcpy(b, h->buf, h->end);
  free(h->buf);
  h->buf = b;
  h->cap = cap;
}

// (what was read ahead given back, where the file is a regular one, so
// that a write is where the program has read up to: 0, or -1 with
// errno)
static int fs_unread(FsFile *h) {
  size_t n = fs_buffered(h);
  if (!n || !h->seekable) return 0;
#ifdef _WIN32
  if (_lseeki64(h->fd, -(int64_t)n, SEEK_CUR) < 0) return -1;
#else
  if (lseek(h->fd, -(off_t)n, SEEK_CUR) < 0) return -1;
#endif
  h->at = h->end = 0;
  h->taken++;
  return 0;
}

// (whether `fd` is ready for `events` now, not waiting: 1, 0, or -1
// with errno)
static int fs_ready(int fd, short events) {
#ifdef _WIN32
  (void)fd;
  (void)events;
  return 1;
#else
  struct pollfd p = { fd, events, 0 };
  int r;
  do r = poll(&p, 1, 0); while (r < 0 && errno == EINTR);
  return r < 0 ? -1 : r > 0;
#endif
}

// (`fd` waited for here, the whole program waiting: one another made
// non-blocking, not ready)
static void fs_wait_here(int fd, short events) {
#ifdef _WIN32
  (void)fd;
  (void)events;
#else
  struct pollfd p = { fd, events, 0 };
  while (poll(&p, 1, -1) < 0 && errno == EINTR) {}
#endif
}

// An operation, in steps
// ---------------------------------------------------------------------

enum { FS_CHUNK, FS_LINE, FS_WRITE };

typedef struct {
  HeffWait w;        // (first: an op is its wait; its `fd` the file's)
  int what;
  FsFile *h;         // (counted: the op's while it is)
  int err;           // (errno, where it failed)
  int async;         // (polled before each read and write, waiting in the
                     //  reactor until it is ready: a scheduler runs, and
                     //  the file is pollable)
  int eof;           // (a read came to the end)
  int64_t n;         // (a chunk's most)
  size_t scanned;    // (a line's: how far after `h->at` no newline is,
  uint64_t taken;    //  while `h->taken` is this)
  const uint8_t *data;  // (a write's bytes, `len` of them, `done` written)
  int64_t len, done;
  V held;            // (what holds them: a write's operation)
  char *owned;       // (or a copy of them, a string's)
  V result;          // (its answer, once it is done and did not fail)
} FsOp;

static FsOp *fs_op(int what, FsFile *h) {
  FsOp *o = heff_alloc(sizeof *o);
  memset(o, 0, sizeof *o);
  o->what = what;
  o->h = h;
  h->refs++;
  o->w.fd = h->fd;
  o->w.events = POLLIN;
#ifndef _WIN32
  o->async = heff_group != 0 && h->pollable;
#endif
  o->taken = h->taken;
  return o;
}

static void fs_op_free(FsOp *o) {
  if (o->result) heff_drop(o->result);
  if (o->held) heff_drop(o->held);
  free(o->owned);
  fs_unref(o->h);
  free(o);
}

// (up to `n` bytes read into `dst`: how many, 0 at the end, or -1 with
// errno -- EAGAIN, for an async op, where it is not ready)
static ssize_t fs_read_into(FsOp *o, uint8_t *dst, size_t n) {
  int fd = o->h->fd;
  for (;;) {
    if (o->async) {
      int r = fs_ready(fd, POLLIN);
      if (r < 0) return -1;
      if (r == 0) {
        errno = EAGAIN;
        return -1;
      }
    }
#ifdef _WIN32
    ssize_t r = read(fd, dst, (unsigned)n);
#else
    ssize_t r = read(fd, dst, n);
#endif
    if (r >= 0) return r;
    if (errno == EINTR) continue;
    if ((errno == EAGAIN || errno == EWOULDBLOCK) && !o->async) {
      fs_wait_here(fd, POLLIN);
      continue;
    }
    if (errno == EWOULDBLOCK) errno = EAGAIN;
    return -1;
  }
}

// (more read ahead, as much as there is room for, a buffer's at least:
// as `fs_read_into`)
static ssize_t fs_fill(FsOp *o) {
  FsFile *h = o->h;
  fs_room(h, FS_BUF);
  ssize_t r = fs_read_into(o, h->buf + h->end, h->cap - h->end);
  if (r > 0) h->end += (size_t)r;
  return r;
}

// (`n` bytes taken from what was read ahead)
static V fs_take(FsFile *h, size_t n) {
  V b = heff_bytes_in(h->buf + h->at, (int64_t)n);
  h->at += n;
  h->taken++;
  return b;
}

// (a step's end where a read failed: waiting, where it is not ready)
static int fs_failed_step(FsOp *o) {
  if (o->async && errno == EAGAIN) {
    o->w.events = POLLIN;
    return HEFF_STEP_WAIT;
  }
  o->err = errno;
  return HEFF_STEP_DONE;
}

// A chunk: what was read ahead, or read now -- straight into bytes of
// its own where as many as a buffer's are asked for.
static int fs_chunk_step(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  FsFile *h = o->h;
  if (fs_buffered(h) == 0 && (size_t)o->n >= FS_BUF) {
    uint8_t *mine = heff_alloc((size_t)o->n);
    ssize_t r = fs_read_into(o, mine, (size_t)o->n);
    if (r < 0) {
      int e = errno;
      free(mine);
      errno = e;
      return fs_failed_step(o);
    }
    o->result = fs_right(heff_bytes_in(mine, (int64_t)r));
    free(mine);
    return HEFF_STEP_DONE;
  }
  if (fs_buffered(h) == 0 && fs_fill(o) < 0) return fs_failed_step(o);
  size_t n = fs_buffered(h);
  if (n > (size_t)o->n) n = (size_t)o->n;
  o->result = fs_right(n ? fs_take(h, n) : heff_bytes_in("", 0));
  return HEFF_STEP_DONE;
}

// (`Right (Just` the line of `n` bytes from what was read ahead`)`, its
// newline -- `nl` bytes, and a `\r` before it -- taken, left out)
static V fs_take_line(FsFile *h, size_t n, size_t nl) {
  const uint8_t *s = h->buf + h->at;
  size_t len = n;
  if (nl && len > 0 && s[len - 1] == '\r') len--;
  V line = heff_str_bytes(s, (int64_t)len);
  h->at += n + nl;
  h->taken++;
  return fs_right(heff_just(line));
}

// A line: what was read ahead looked through for a newline, more read
// until there is one or the file has ended.
static int fs_line_step(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  FsFile *h = o->h;
  for (;;) {
    if (o->taken != h->taken) {
      // (another op took from it meanwhile: looked through anew)
      o->scanned = 0;
      o->taken = h->taken;
    }
    size_t have = fs_buffered(h);
    if (have > o->scanned) {
      const uint8_t *s = h->buf + h->at;
      const uint8_t *nl = memchr(s + o->scanned, '\n', have - o->scanned);
      if (nl) {
        o->result = fs_take_line(h, (size_t)(nl - s), 1);
        return HEFF_STEP_DONE;
      }
    }
    o->scanned = have;
    if (o->eof) {
      o->result = have ? fs_take_line(h, have, 0) : fs_right(heff_nothing);
      return HEFF_STEP_DONE;
    }
    ssize_t r = fs_fill(o);
    if (r < 0) return fs_failed_step(o);
    if (r == 0) o->eof = 1;
  }
}

// A write: all of it -- where it is polled, no more than PIPE_BUF bytes
// at a time, each once poll says there is room.
static int fs_write_step(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  int fd = o->h->fd;
  while (o->done < o->len) {
    size_t n = (size_t)(o->len - o->done);
#ifndef _WIN32
    if (o->async) {
      int r = fs_ready(fd, POLLOUT);
      if (r < 0) {
        o->err = errno;
        return HEFF_STEP_DONE;
      }
      if (r == 0) {
        w->events = POLLOUT;
        return HEFF_STEP_WAIT;
      }
      if (n > PIPE_BUF) n = PIPE_BUF;
    }
    ssize_t r = write(fd, o->data + o->done, n);
#else
    ssize_t r = write(fd, o->data + o->done, (unsigned)n);
#endif
    if (r >= 0) {
      o->done += r;
      continue;
    }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) {
      if (o->async) {
        w->events = POLLOUT;
        return HEFF_STEP_WAIT;
      }
      fs_wait_here(fd, POLLOUT);
      continue;
    }
    o->err = errno;
    return HEFF_STEP_DONE;
  }
  o->result = fs_done();
  return HEFF_STEP_DONE;
}

static V fs_answer(HeffWait *w) {
  FsOp *o = (FsOp *)w;
  // (why waiting failed, where it did -- its file closed meanwhile,
  // EBADF -- or why the op did)
  int err = w->err ? w->err : o->err;
  V r;
  if (err) r = fs_left(err);
  else {
    r = o->result;
    o->result = 0;
  }
  fs_op_free(o);
  return r;
}

static void fs_cancel(HeffWait *w) { fs_op_free((FsOp *)w); }

// (the op, its first step taken: done, its answer given to `k`; or
// waited for by the reactor -- lib/c/runtime.c's `heff_outside`)
static V fs_go(FsOp *o, int (*step)(HeffWait *), V f, V k) {
  o->w.step = step;
  o->w.answer = fs_answer;
  o->w.cancel = fs_cancel;
  if (step(&o->w) == HEFF_STEP_WAIT) return heff_outside(&o->w, f, k);
  V x = heff_answer(f, fs_answer(&o->w));
  return heff_tail(k, 1, &x);
}

// (`len` bytes at `data` written to `h`: held by `held`, or `owned`)
static V fs_write(FsFile *h, const uint8_t *data, int64_t len, V held, char *owned, V f, V k) {
  // (what std.io wrote before it, first; and what was read ahead given
  // back)
  if (h->standard == 1 || h->standard == 2) fflush(stdout);
  if (h->standard == 2) fflush(stderr);
  if (fs_unread(h) < 0) {
    int e = errno;
    if (held) heff_drop(held);
    free(owned);
    V x = heff_answer(f, fs_left(e));
    return heff_tail(k, 1, &x);
  }
  FsOp *o = fs_op(FS_WRITE, h);
  o->w.events = POLLOUT;
  o->data = data;
  o->len = len;
  o->held = held;
  o->owned = owned;
  return fs_go(o, fs_write_step, f, k);
}

// Paths
// ---------------------------------------------------------------------

// (where the system keeps temporary files, no separator after it)
static void fs_temp_root(char *buf, size_t n) {
#ifdef _WIN32
  DWORD m = GetTempPathA((DWORD)n, buf);
  if (m == 0 || m >= n) snprintf(buf, n, ".");
#else
  const char *t = getenv("TMPDIR");
  snprintf(buf, n, "%s", t && *t ? t : "/tmp");
#endif
  size_t len = strlen(buf);
  while (len > 1 && heff_is_sep(buf[len - 1])) buf[--len] = 0;
}

static uint64_t fs_seed;

// (six letters, a temporary name's, hardly ever the same twice)
static void fs_letters(char *out) {
  uint64_t x = fs_seed ^ ((uint64_t)time(NULL) * 0x9e3779b97f4a7c15ULL) ^ (uint64_t)clock()
             ^ ((uint64_t)getpid() << 32) ^ (uint64_t)(uintptr_t)out;
#ifndef _WIN32
  struct timespec ts;
  clock_gettime(CLOCK_REALTIME, &ts);
  x ^= (uint64_t)ts.tv_nsec * 0xbf58476d1ce4e5b9ULL;
#endif
  fs_seed = x * 6364136223846793005ULL + 1442695040888963407ULL;
  uint64_t y = fs_seed;
  y = (y ^ (y >> 30)) * 0xbf58476d1ce4e5b9ULL;
  y = (y ^ (y >> 27)) * 0x94d049bb133111ebULL;
  y ^= y >> 31;
  static const char abc[] = "abcdefghijklmnopqrstuvwxyz0123456789";
  for (int i = 0; i < 6; i++) {
    out[i] = abc[y % 36];
    y /= 36;
  }
  out[6] = 0;
}

// (a new temporary directory, or file -- open, `Pair` its path and it --
// its name `prefix` and six letters)
static V fs_temp(V prefix, int file) {
  char *pre = heff_cstr(prefix);
  if (!pre) return fs_left(EINVAL);
  char root[4096];
  fs_temp_root(root, sizeof root);
  size_t n = strlen(root) + strlen(pre) + 9;
  char *path = heff_alloc(n);
  V r = 0;
  for (int tries = 0; tries < 100 && !r; tries++) {
    char six[7];
    fs_letters(six);
#ifdef _WIN32
    snprintf(path, n, "%s\\%s%s", root, pre, six);
#else
    snprintf(path, n, "%s/%s%s", root, pre, six);
#endif
    if (!file) {
#ifdef _WIN32
      int made = mkdir(path) == 0;
#else
      int made = mkdir(path, 0700) == 0;
#endif
      if (made) r = fs_right(heff_str_bytes(path, (int64_t)strlen(path)));
      else if (errno != EEXIST) r = fs_left(errno);
    } else {
      int fd = open(path, O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_BINARY, 0600);
      if (fd >= 0) {
        V both[2] = { heff_str_bytes(path, (int64_t)strlen(path)), fs_handle(fs_new(fd, -1)) };
        r = fs_right(heff_tag_n(TAG_MkPair, 2, both));
      } else if (errno != EEXIST) r = fs_left(errno);
    }
  }
  free(pre);
  free(path);
  return r ? r : fs_left(EEXIST);
}

// (`path` with its links resolved: `Right` it, or `Left` why not)
static V fs_real_path(const char *path) {
#ifdef _WIN32
  struct stat st;
  if (stat(path, &st) != 0) return fs_left(errno);
  char *r = _fullpath(NULL, path, 0);
#else
  char *r = realpath(path, NULL);
#endif
  if (!r) return fs_left(errno);
  V s = heff_str_bytes(r, (int64_t)strlen(r));
  free(r);
  return fs_right(s);
}

// (`path`'s mode set: `Right MkUnit`, or `Left` why not)
static V fs_set_mode(const char *path, int64_t mode) {
#ifdef _WIN32
  int r = chmod(path, (mode & 0200) ? (_S_IREAD | _S_IWRITE) : _S_IREAD);
#else
  int r = chmod(path, (mode_t)(mode & 07777));
#endif
  return r == 0 ? fs_done() : fs_left(errno);
}

// (`path` opened as `OpenPath` says: `Right` its handle, or `Left` why
// not -- a directory's, EISDIR)
static V fs_open(const char *path, int64_t access, int create, int truncate, int exclusive, int64_t mode) {
  int flags = access == 0 ? O_RDONLY : access == 1 ? O_WRONLY : access == 2 ? (O_WRONLY | O_APPEND) : O_RDWR;
  if (create) flags |= O_CREAT;
  if (truncate) flags |= O_TRUNC;
  if (exclusive) flags |= O_CREAT | O_EXCL;
  flags |= O_CLOEXEC | O_BINARY;
  int fd;
  do fd = open(path, flags, (int)(mode & 07777)); while (fd < 0 && errno == EINTR);
  if (fd < 0) return fs_left(errno);
  struct stat st;
  if (fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)) {
    close(fd);
    return fs_left(EISDIR);
  }
  return fs_right(fs_handle(fs_new(fd, -1)));
}

// The operations
// ---------------------------------------------------------------------

// (`x` given to the function at field `at` of `p`, its answer to `k`;
// `p` let go of)
static V fs_answered(V p, int at, V x, V k) {
  V f = heff_dup(heff_field(p, at));
  heff_drop(p);
  V y = heff_answer(f, x);
  return heff_tail(k, 1, &y);
}

static V heff_provider_fs(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Stat: {
    char *path = heff_cstr(heff_field(p, 0));
    int follow = heff_field(p, 1) == NTAG(TAG_True);
    V r;
    if (!path) r = fs_left(EINVAL);
    else {
      struct stat st;
      int s = follow ? stat(path, &st) : lstat(path, &st);
      r = fs_status(s, &st);
      free(path);
    }
    return fs_answered(p, 2, r, k);
  }
  case TAG_SetMode: {
    char *path = heff_cstr(heff_field(p, 0));
    int64_t mode;
    V r = !path || !fs_int(heff_field(p, 1), &mode) ? fs_left(EINVAL) : fs_set_mode(path, mode);
    free(path);
    return fs_answered(p, 2, r, k);
  }
  case TAG_RealPath: {
    char *path = heff_cstr(heff_field(p, 0));
    V r = path ? fs_real_path(path) : fs_left(EINVAL);
    free(path);
    return fs_answered(p, 1, r, k);
  }
  case TAG_TempDirectory:
    return fs_answered(p, 1, fs_temp(heff_field(p, 0), 0), k);
  case TAG_TempFile:
    return fs_answered(p, 1, fs_temp(heff_field(p, 0), 1), k);
  case TAG_OpenPath: {
    char *path = heff_cstr(heff_field(p, 0));
    int64_t access, mode;
    int ok = path && fs_int(heff_field(p, 1), &access) && fs_int(heff_field(p, 5), &mode);
    V r = !ok ? fs_left(EINVAL)
              : fs_open(path, access, heff_field(p, 2) == NTAG(TAG_True), heff_field(p, 3) == NTAG(TAG_True),
                        heff_field(p, 4) == NTAG(TAG_True), mode);
    free(path);
    return fs_answered(p, 6, r, k);
  }
  case TAG_Standard: {
    int64_t i = INT_OF(heff_field(p, 0));
    if (i < 0 || i > 2) heff_fail("std.filesystem: no such standard stream");
    if (!fs_standard[i]) fs_standard[i] = fs_new((int)i, (int)i);
    return fs_answered(p, 1, fs_handle(fs_standard[i]), k);
  }
  case TAG_ReadChunk: {
    FsFile *h = fs_file(heff_field(p, 0));
    int64_t n;
    if (!fs_int(heff_field(p, 1), &n)) n = FS_READ_MAX;
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    if (n <= 0) {
      V x = heff_answer(f, fs_right(heff_bytes_in("", 0)));
      return heff_tail(k, 1, &x);
    }
    FsOp *o = fs_op(FS_CHUNK, h);
    o->n = n > FS_READ_MAX ? FS_READ_MAX : n;
    return fs_go(o, fs_chunk_step, f, k);
  }
  case TAG_ReadLine: {
    FsFile *h = fs_file(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return fs_go(fs_op(FS_LINE, h), fs_line_step, f, k);
  }
  case TAG_WriteBytes: {
    FsFile *h = fs_file(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 2));
    int64_t n;
    // (the bytes are `p`'s, held until they are written)
    const uint8_t *data = heff_bytes_data(heff_field(p, 1), &n);
    return fs_write(h, data, n, p, NULL, f, k);
  }
  case TAG_WriteString: {
    FsFile *h = fs_file(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 2));
    size_t n;
    char *data = heff_bytes(heff_field(p, 1), &n);
    heff_drop(p);
    return fs_write(h, (const uint8_t *)data, (int64_t)n, 0, data, f, k);
  }
  case TAG_Seek: {
    FsFile *h = fs_file(heff_field(p, 0));
    int64_t from, n;
    V r;
    if (!fs_int(heff_field(p, 1), &from) || !fs_int(heff_field(p, 2), &n)) r = fs_left(EINVAL);
    else {
      // (from where the program has read up to, not where the file was
      // read ahead to)
      if (from == 1) n -= (int64_t)fs_buffered(h);
      int whence = from == 0 ? SEEK_SET : from == 1 ? SEEK_CUR : SEEK_END;
#ifdef _WIN32
      int64_t at = _lseeki64(h->fd, n, whence);
#else
      int64_t at = (int64_t)lseek(h->fd, (off_t)n, whence);
#endif
      if (at < 0) r = fs_left(errno);
      else {
        h->at = h->end = 0;
        h->taken++;
        r = fs_right(heff_int(at));
      }
    }
    return fs_answered(p, 3, r, k);
  }
  case TAG_StatHandle: {
    FsFile *h = fs_file(heff_field(p, 0));
    struct stat st;
    int s = fstat(h->fd, &st);
    return fs_answered(p, 1, fs_status(s, &st), k);
  }
  case TAG_CloseFile: {
    int64_t i = INT_OF(heff_field(heff_field(p, 0), 0));
    FsFile *h = fs_file(heff_field(p, 0));
    int err = 0;
    if (h->standard < 0 && h->fd >= 0) {
      // (what waits on it told so, not polled closed)
      heff_reactor_closing(h->fd);
      if (close(h->fd) != 0 && errno != EINTR) err = errno;
      h->fd = -1;
    }
    heff_release(i);
    return fs_answered(p, 1, err ? fs_left(err) : fs_done(), k);
  }
  default:
    return heff_fs_whole(p, k);
  }
}

// The terminal's side of src/heff/lsp/report.hf, for the C backend: an
// effect provider (the shape of one is said in lib/std/io.provider.c).

#include <unistd.h>

// (colour on the stream `fd`: it is a terminal, or `HEFF_TTY=1` says it
// is, and `NO_COLOR` is not set)
static int heff_report_color(int fd) {
  const char *tty = getenv("HEFF_TTY"), *no = getenv("NO_COLOR");
  return (isatty(fd) || (tty && tty[0] == '1' && !tty[1])) && !(no && no[0]);
}

static V heff_provider_report(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_UseColor:
  case TAG_ErrColor: {
    int fd = heff_tag_of(p) == TAG_UseColor ? 1 : 2;
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(heff_report_color(fd)));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of report");
    return 0;
  }
}

// The client's side of src/heff/lsp/rpc.hf, for the C backend: JSON-RPC over
// stdio, as the Language Server Protocol frames it -- each message a
// `Content-Length: n` header, a blank line, then n bytes of JSON; stdout
// carries only the messages, logs go to stderr -- and what of the host a
// language server asks for (the shape of a provider is said in
// lib/std/io.provider.c).  Its strings are text, a host of text's --
// JSON's, and the paths and URIs a client names, or that are made of
// them (`heff_str_text`, `heff_cstr_text`) -- but for what it sends and
// logs, which is written out as it is (`heff_bytes`, `heff_put`).

#include <dirent.h>
#ifndef _WIN32
#include <poll.h>
#endif
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#ifdef _WIN32
#define lstat stat
#endif

// A message's JSON, as src/heff/util/json.hf's `Json`
// ---------------------------------------------------------------------

typedef struct { const char *s, *end; } Json;

static void json_ws(Json *j) {
  while (j->s < j->end && (*j->s == ' ' || *j->s == '\t' || *j->s == '\n' || *j->s == '\r')) j->s++;
}

static int json_lit(Json *j, const char *w) {
  size_t n = strlen(w);
  if ((size_t)(j->end - j->s) < n || memcmp(j->s, w, n) != 0) return 0;
  j->s += n;
  return 1;
}

static void json_utf8(Buf *b, uint32_t u) {
  char c[4];
  size_t n;
  if (u < 0x80) { c[0] = (char)u; n = 1; }
  else if (u < 0x800) { c[0] = (char)(0xC0 | (u >> 6)); c[1] = (char)(0x80 | (u & 0x3F)); n = 2; }
  else if (u < 0x10000) { c[0] = (char)(0xE0 | (u >> 12)); c[1] = (char)(0x80 | ((u >> 6) & 0x3F)); c[2] = (char)(0x80 | (u & 0x3F)); n = 3; }
  else { c[0] = (char)(0xF0 | (u >> 18)); c[1] = (char)(0x80 | ((u >> 12) & 0x3F)); c[2] = (char)(0x80 | ((u >> 6) & 0x3F)); c[3] = (char)(0x80 | (u & 0x3F)); n = 4; }
  buf_put(b, c, n);
}

static int json_hex4(Json *j, uint32_t *u) {
  if (j->end - j->s < 4) return 0;
  *u = 0;
  for (int i = 0; i < 4; i++) {
    char c = *j->s++;
    *u <<= 4;
    if (c >= '0' && c <= '9') *u |= (uint32_t)(c - '0');
    else if (c >= 'a' && c <= 'f') *u |= (uint32_t)(c - 'a' + 10);
    else if (c >= 'A' && c <= 'F') *u |= (uint32_t)(c - 'A' + 10);
    else return 0;
  }
  return 1;
}

// (a string's text, its escapes undone: 0 if it is not one)
static V json_string(Json *j) {
  if (j->s >= j->end || *j->s != '"') return 0;
  j->s++;
  Buf b = {0};
  for (;;) {
    if (j->s >= j->end) { free(b.s); return 0; }
    char c = *j->s++;
    if (c == '"') break;
    if (c != '\\') { buf_put(&b, &c, 1); continue; }
    if (j->s >= j->end) { free(b.s); return 0; }
    char e = *j->s++;
    uint32_t u;
    switch (e) {
    case '"': case '\\': case '/': buf_put(&b, &e, 1); break;
    case 'b': buf_put(&b, "\b", 1); break;
    case 'f': buf_put(&b, "\f", 1); break;
    case 'n': buf_put(&b, "\n", 1); break;
    case 'r': buf_put(&b, "\r", 1); break;
    case 't': buf_put(&b, "\t", 1); break;
    case 'u':
      if (!json_hex4(j, &u)) { free(b.s); return 0; }
      if (u >= 0xD800 && u < 0xDC00 && j->end - j->s >= 6 && j->s[0] == '\\' && j->s[1] == 'u') {
        Json save = *j;
        uint32_t lo;
        j->s += 2;
        if (json_hex4(j, &lo) && lo >= 0xDC00 && lo < 0xE000) u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00);
        else *j = save;
      }
      // (a surrogate not in a pair, U+FFFD, as JavaScript's string has
      // it, made UTF-8)
      if (u >= 0xD800 && u < 0xE000) u = 0xFFFD;
      json_utf8(&b, u);
      break;
    default: free(b.s); return 0;
    }
  }
  V s = heff_str_text_n(b.s ? b.s : "", (int64_t)b.n);
  free(b.s);
  return s;
}

static V json_value(Json *j);

// (a list of what `item` reads, between `open` and `close`)
static V json_items(Json *j, char close, V (*item)(Json *)) {
  j->s++;
  int64_t n = 0, cap = 8;
  V *xs = heff_alloc(cap * sizeof(V));
  json_ws(j);
  if (j->s < j->end && *j->s == close) j->s++;
  else
    for (;;) {
      V x = item(j);
      if (!x) goto bad;
      if (n == cap) {
        V *x2 = heff_alloc(cap * 2 * sizeof(V));
        memcpy(x2, xs, n * sizeof(V));
        free(xs);
        xs = x2;
        cap *= 2;
      }
      xs[n++] = x;
      json_ws(j);
      if (j->s < j->end && *j->s == ',') { j->s++; continue; }
      if (j->s < j->end && *j->s == close) { j->s++; break; }
      goto bad;
    }
  V l = NTAG(TAG_Nil);
  for (int64_t i = n - 1; i >= 0; i--) l = heff_cons(xs[i], l);
  free(xs);
  return l;
bad:
  for (int64_t i = 0; i < n; i++) heff_drop(xs[i]);
  free(xs);
  return 0;
}

static V json_member(Json *j) {
  json_ws(j);
  V k = json_string(j);
  if (!k) return 0;
  json_ws(j);
  if (j->s >= j->end || *j->s != ':') { heff_drop(k); return 0; }
  j->s++;
  V v = json_value(j);
  if (!v) { heff_drop(k); return 0; }
  V f[2] = { k, v };
  return heff_tag(TAG_MkPair, 2, f);
}

static V json_one(int tag, V x) { return x ? heff_tag(tag, 1, &x) : 0; }

// (a number: an integer an Int, as JavaScript's Number.isInteger says)
static V json_number(Json *j) {
  char *e;
  double d = strtod(j->s, &e);
  if (e == j->s || e > j->end) return 0;
  j->s = e;
  if (d == floor(d) && fabs(d) < 2305843009213693952.0) return json_one(TAG_JInt, MK_INT((int64_t)d));
  return json_one(TAG_JFloat, heff_flt(d));
}

static V json_value(Json *j) {
  json_ws(j);
  if (j->s >= j->end) return 0;
  switch (*j->s) {
  case 'n': return json_lit(j, "null") ? NTAG(TAG_JNull) : 0;
  case 't': return json_lit(j, "true") ? json_one(TAG_JBool, NTAG(TAG_True)) : 0;
  case 'f': return json_lit(j, "false") ? json_one(TAG_JBool, NTAG(TAG_False)) : 0;
  case '"': return json_one(TAG_JString, json_string(j));
  case '[': return json_one(TAG_JArray, json_items(j, ']', json_value));
  case '{': return json_one(TAG_JObject, json_items(j, '}', json_member));
  default: return json_number(j);
  }
}

// (a body as JSON: 0 if it is not)
static V json_parse(const char *s, size_t n) {
  Json j = { s, s + n };
  V v = json_value(&j);
  json_ws(&j);
  if (v && j.s != j.end) { heff_drop(v); return 0; }
  return v;
}

// The messages, read from stdin
// ---------------------------------------------------------------------

static Buf rpc_in;
static int rpc_closed;

// (the next message's body, if a whole one is read: malloc'd)
static char *rpc_take(size_t *len) {
  for (;;) {
    char *sep = NULL;
    for (size_t i = 0; i + 4 <= rpc_in.n; i++)
      if (memcmp(rpc_in.s + i, "\r\n\r\n", 4) == 0) { sep = rpc_in.s + i; break; }
    if (!sep) return NULL;
    size_t head = (size_t)(sep - rpc_in.s), start = head + 4;
    long n = -1;
    for (size_t i = 0; i + 15 <= head; i++)
      if (strncasecmp(rpc_in.s + i, "Content-Length:", 15) == 0) {
        size_t k = i + 15;
        while (k < head && (rpc_in.s[k] == ' ' || rpc_in.s[k] == '\t')) k++;
        if (k < head && rpc_in.s[k] >= '0' && rpc_in.s[k] <= '9') {
          n = 0;
          while (k < head && rpc_in.s[k] >= '0' && rpc_in.s[k] <= '9') n = n * 10 + (rpc_in.s[k++] - '0');
        }
        break;
      }
    if (n < 0) {
      memmove(rpc_in.s, rpc_in.s + start, rpc_in.n - start);
      rpc_in.n -= start;
      continue;
    }
    if (rpc_in.n < start + (size_t)n) return NULL;
    char *body = heff_alloc((size_t)n + 1);
    memcpy(body, rpc_in.s + start, (size_t)n);
    body[n] = 0;
    memmove(rpc_in.s, rpc_in.s + start + n, rpc_in.n - start - n);
    rpc_in.n -= start + n;
    *len = (size_t)n;
    return body;
  }
}

static int64_t rpc_now(void) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME, &t);
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

// (whether stdin has something to read within `wait` ms (none, below
// 0): 1 if so, 0 if not, below 0 if waiting failed)
static int rpc_ready(int wait) {
#ifdef _WIN32
  // (a pipe, as an editor gives it, is looked into until it has bytes;
  // what is not a pipe is read, waiting there)
  HANDLE h = GetStdHandle(STD_INPUT_HANDLE);
  int64_t until = rpc_now() + wait;
  for (;;) {
    DWORD avail = 0;
    if (!PeekNamedPipe(h, NULL, 0, NULL, &avail, NULL) || avail > 0) return 1;
    if (wait >= 0 && rpc_now() >= until) return 0;
    Sleep(5);
  }
#else
  struct pollfd fd = { 0, POLLIN, 0 };
  return poll(&fd, 1, wait);
#endif
}

// (the next event: a message, the time waited for, `ms`, passing first
// (none, below 0), or the client gone)
static V rpc_await(int64_t ms) {
  int64_t until = rpc_now() + ms;
  for (;;) {
    size_t n;
    char *body = rpc_take(&n);
    if (body) {
      V v = json_parse(body, n);
      free(body);
      if (v) return heff_tag(TAG_Message, 1, &v);
      fputs("heff lsp: not JSON\n", stderr);
      continue;
    }
    if (rpc_closed) return NTAG(TAG_Closed);
    int wait = -1;
    if (ms >= 0) {
      int64_t left = until - rpc_now();
      if (left <= 0) return NTAG(TAG_Timeout);
      wait = left > 0x7fffffff ? 0x7fffffff : (int)left;
    }
    int r = rpc_ready(wait);
    if (r == 0) return NTAG(TAG_Timeout);
    if (r < 0) continue;
    char chunk[65536];
    ssize_t got = read(0, chunk, sizeof chunk);
    if (got <= 0) rpc_closed = 1;
    else buf_put(&rpc_in, chunk, (size_t)got);
  }
}

// Paths and URIs
// ---------------------------------------------------------------------

// (a path made absolute against the working directory, its `.`, `..`
// and repeated separators resolved, as Node.js's path.resolve: malloc'd;
// on Windows a path starts with its drive, `C:`, and its separator is
// `\\`, though `/` is read as one too)
#ifdef _WIN32
#define RPC_SEP '\\'
#define rpc_is_sep(c) ((c) == '/' || (c) == '\\')
#else
#define RPC_SEP '/'
#define rpc_is_sep(c) ((c) == '/')
#endif

static char *rpc_resolve(const char *p) {
  Buf b = {0};
  char cwd[4096];
  if (!getcwd(cwd, sizeof cwd)) cwd[0] = 0;
#ifdef _WIN32
  int drive = p[0] && p[1] == ':';
  if (drive && rpc_is_sep(p[2])) buf_str(&b, p);
  else if (rpc_is_sep(p[0])) {
    if (cwd[0] && cwd[1] == ':') buf_put(&b, cwd, 2);
    buf_str(&b, p);
  } else {
    buf_str(&b, cwd);
    buf_put(&b, "\\", 1);
    buf_str(&b, drive ? p + 2 : p);
  }
#else
  if (p[0] != '/') {
    buf_str(&b, cwd);
    buf_put(&b, "/", 1);
  }
  buf_str(&b, p);
#endif
  buf_put(&b, "", 1);
  char *out = heff_alloc(b.n + 2);
  size_t o = 0, top = 0;
  const char *s = b.s;
#ifdef _WIN32
  if (s[0] && s[1] == ':') {
    out[o++] = s[0];
    out[o++] = ':';
    s += 2;
    top = 2;
  }
#endif
  while (*s) {
    while (rpc_is_sep(*s)) s++;
    const char *e = s;
    while (*e && !rpc_is_sep(*e)) e++;
    size_t n = (size_t)(e - s);
    if (n == 0 || (n == 1 && s[0] == '.')) {}
    else if (n == 2 && s[0] == '.' && s[1] == '.') {
      while (o > top && out[o - 1] != RPC_SEP) o--;
      if (o > top) o--;
    } else {
      out[o++] = RPC_SEP;
      memcpy(out + o, s, n);
      o += n;
    }
    s = e;
  }
  if (o == top) out[o++] = RPC_SEP;
  out[o] = 0;
  free(b.s);
  return out;
}

static int rpc_hex(char c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

// (a file: URI's path, as Node.js's fileURLToPath: none if it has a host)
static V rpc_uri_path(const char *u) {
  if (strncmp(u, "file:", 5) != 0) return heff_nothing;
  u += 5;
  if (strncmp(u, "//", 2) == 0) {
    u += 2;
    const char *h = u;
    while (*u && *u != '/') u++;
    size_t hn = (size_t)(u - h);
    if (hn != 0 && !(hn == 9 && strncasecmp(h, "localhost", 9) == 0)) return heff_nothing;
  }
  Buf b = {0};
  for (; *u && *u != '?' && *u != '#'; u++) {
    int a, c;
    if (*u == '%' && (a = rpc_hex(u[1])) >= 0 && (c = rpc_hex(u[2])) >= 0) {
      char x = (char)(a * 16 + c);
      if (x == '/' || (RPC_SEP == '\\' && x == '\\')) { free(b.s); return heff_nothing; }
      buf_put(&b, &x, 1);
      u += 2;
    } else buf_put(&b, u, 1);
  }
  if (b.n == 0) buf_put(&b, "/", 1);
#ifdef _WIN32
  // (`/C:/a/b` is `C:\\a\\b`; a path without its drive is no path here)
  buf_put(&b, "", 1);
  if (!(b.n >= 4 && b.s[0] == '/' && b.s[2] == ':' && (b.s[3] == '/' || b.s[3] == 0))) { free(b.s); return heff_nothing; }
  b.n -= 2;
  memmove(b.s, b.s + 1, b.n);
  for (size_t i = 0; i < b.n; i++)
    if (b.s[i] == '/') b.s[i] = '\\';
  if (b.n == 2) buf_put(&b, "\\", 1);
#endif
  V s = heff_str_text_n(b.s, (int64_t)b.n);
  free(b.s);
  return heff_just(s);
}

// (a path as a file: URI, as Node.js's pathToFileURL(...).href)
static V rpc_path_uri(const char *p) {
  char *abs = rpc_resolve(p);
  Buf b = {0};
#ifdef _WIN32
  // (`C:\\a\\b` is `file:///C:/a/b`)
  for (char *c = abs; *c; c++)
    if (*c == '\\') *c = '/';
  buf_str(&b, "file:///");
#else
  buf_str(&b, "file://");
#endif
  for (const unsigned char *c = (const unsigned char *)abs; *c; c++) {
    if (*c <= 0x20 || *c >= 0x7F || strchr("\"#<>?`{}%\\", *c)) {
      char e[4];
      snprintf(e, sizeof e, "%%%02X", *c);
      buf_put(&b, e, 3);
    } else buf_put(&b, (const char *)c, 1);
  }
  free(abs);
  V s = heff_str_text_n(b.s, (int64_t)b.n);
  free(b.s);
  return s;
}

// The project's files
// ---------------------------------------------------------------------

static int rpc_is_root(const char *d) {
  char *p = heff_join(d, "package.hf");
  struct stat st;
  int ok = stat(p, &st) == 0 && S_ISREG(st.st_mode) && access(p, R_OK) == 0;
  free(p);
  return ok;
}

typedef struct { char **xs; int64_t n, cap; } Names;

static void names_add(Names *ns, char *x) {
  if (ns->n == ns->cap) {
    int64_t cap = ns->cap ? ns->cap * 2 : 16;
    char **x2 = heff_alloc(cap * sizeof(char *));
    if (ns->n) memcpy(x2, ns->xs, ns->n * sizeof(char *));
    free(ns->xs);
    ns->xs = x2;
    ns->cap = cap;
  }
  ns->xs[ns->n++] = x;
}

static int names_has(Names *ns, const char *x) {
  for (int64_t i = 0; i < ns->n; i++)
    if (strcmp(ns->xs[i], x) == 0) return 1;
  return 0;
}

static void names_free(Names *ns) {
  for (int64_t i = 0; i < ns->n; i++) free(ns->xs[i]);
  free(ns->xs);
}

static void rpc_walk(const char *d, Names *ignored, Names *files) {
  DIR *dir = opendir(d);
  if (!dir) return;
  Names here = {0};
  struct dirent *e;
  while ((e = readdir(dir))) names_add(&here, strdup(e->d_name));
  closedir(dir);
  qsort(here.xs, here.n, sizeof(char *), heff_cmp_cstr);
  for (int64_t i = 0; i < here.n; i++) {
    const char *name = here.xs[i];
    if (name[0] == '.' || names_has(ignored, name)) continue;
    char *p = heff_join(d, name);
    struct stat st;
    if (lstat(p, &st) == 0) {
      if (S_ISDIR(st.st_mode)) {
        if (!rpc_is_root(p)) rpc_walk(p, ignored, files);
      } else if (S_ISREG(st.st_mode)) {
        size_t n = strlen(name);
        if (n >= 3 && strcmp(name + n - 3, ".hf") == 0) { names_add(files, p); continue; }
      }
    }
    free(p);
  }
  names_free(&here);
}

// (the `.hf` files of the project at `root` (a directory with a
// package.hf): every directory but another project's, a hidden one, or
// one the root's .gitignore names)
static V rpc_project_files(const char *root) {
  Names files = {0}, ignored = {0};
  if (rpc_is_root(root)) {
    names_add(&ignored, strdup("node_modules"));
    char *gi = heff_join(root, ".gitignore");
    FILE *f = fopen(gi, "r");
    free(gi);
    if (f) {
      char line[4096];
      while (fgets(line, sizeof line, f)) {
        char *s = line, *e = line + strlen(line);
        while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
        while (e > s && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\r' || e[-1] == '\n')) e--;
        if (s < e && *s == '/') s++;
        if (e > s && e[-1] == '/') e--;
        *e = 0;
        if (!*s || *s == '#' || strpbrk(s, "*?[/!")) continue;
        names_add(&ignored, strdup(s));
      }
      fclose(f);
    }
    rpc_walk(root, &ignored, &files);
  }
  V l = heff_strs_text(files.xs, files.n);
  names_free(&files);
  names_free(&ignored);
  return l;
}

// The provider
// ---------------------------------------------------------------------

static V heff_provider_rpc(V p, V k) {
  V x;
  switch (heff_tag_of(p)) {
  case TAG_Await: {
    int64_t ms = INT_OF(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, rpc_await(ms));
    break;
  }
  case TAG_Send: {
    size_t n;
    char *body = heff_bytes(heff_field(p, 0), &n);
    x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    fprintf(stdout, "Content-Length: %zu\r\n\r\n", n);
    fwrite(body, 1, n, stdout);
    fflush(stdout);
    free(body);
    break;
  }
  case TAG_Log: {
    fputs("heff lsp: ", stderr);
    heff_put(stderr, heff_field(p, 0));
    fputc('\n', stderr);
    x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    break;
  }
  case TAG_Now: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    x = heff_answer(f, MK_INT(rpc_now()));
    break;
  }
  case TAG_ProjectFiles: case TAG_UriPath: case TAG_PathUri: case TAG_AbsPath: {
    int tag = heff_tag_of(p);
    char *s = heff_cstr_text(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    // (a path or a URI with a NUL in it, which cannot be a C string, is
    // none: no files, no path, and as it was where one is made of it)
    V was = s ? 0 : heff_dup(heff_field(p, 0));
    heff_drop(p);
    V r;
    if (!s) r = tag == TAG_ProjectFiles ? NTAG(TAG_Nil) : tag == TAG_UriPath ? heff_nothing : was;
    else if (tag == TAG_ProjectFiles) r = rpc_project_files(s);
    else if (tag == TAG_UriPath) r = rpc_uri_path(s);
    else if (tag == TAG_PathUri) r = rpc_path_uri(s);
    else {
      char *a = rpc_resolve(s);
      r = heff_str_text(a);
      free(a);
    }
    free(s);
    x = heff_answer(f, r);
    break;
  }
  case TAG_Quit: {
    int code = (int)INT_OF(heff_field(p, 0));
    fflush(stdout);
    fflush(stderr);
    exit(code);
  }
  default:
    heff_fail("not an operation of rpc");
    return 0;
  }
  return heff_tail(k, 1, &x);
}

// The terminal's side of lib/std/progress.hf, for the C backend: an
// effect provider (the shape of one is said in lib/std/io.provider.c).
//
// The lines are drawn on the standard error by a thread of their own,
// as zig draws its progress (std.Progress): every 80 ms, the newest
// lines given, if they are not those drawn -- none in the first 200 ms
// after lines are first given, so that what is quickly done shows
// nothing -- each cut to the terminal's width, as many as leave two of
// its rows.  The cursor is left where the first line starts: what the
// program writes there clears them first (`heff_lines`, which
// lib/std/io.provider.c calls around each write), and they come back
// below it.  At the program's end, or where it runs a command in its
// place, they are cleared for good.
//
// A command run under a task (`ShowRun`) is given a pipe for its own
// progress, its number in `ZIG_PROGRESS`, as zig gives its children
// one: zig writes the tree of its tasks there every 80 ms, a packet
// each -- `n`, a byte; `n` tasks of 128 bytes (how many of its items
// are done, of how many: 32 bits each, little-endian; its name, 120
// bytes, ended by a 0 if shorter); and the index of each one's parent,
// a byte each (255: none) -- and the newest tree is given to the
// program's function, whose lines are drawn.  (On Windows, where zig's
// is a handle, the command is run as std.process's `run` runs it.)

#ifndef _WIN32
#include <sys/ioctl.h>
#endif
#include <time.h>

// (`heff_lines(1)`: what is drawn cleared, and nothing drawn, until
// `heff_lines(0)`; `heff_lines(2)`: cleared, and nothing drawn again.
// Set once lines are first given; the providers of the streams declare
// it too -- one variable, however many of them a program has)
static void (*heff_lines)(int);

#ifdef _WIN32
static SRWLOCK heff_st_mu = SRWLOCK_INIT;
static CONDITION_VARIABLE heff_st_cv = CONDITION_VARIABLE_INIT;
static HANDLE heff_st_thread;
static void heff_st_lock(void) { AcquireSRWLockExclusive(&heff_st_mu); }
static void heff_st_unlock(void) { ReleaseSRWLockExclusive(&heff_st_mu); }
static void heff_st_wait(int ms) { SleepConditionVariableSRW(&heff_st_cv, &heff_st_mu, (DWORD)ms, 0); }
static void heff_st_wake(void) { WakeAllConditionVariable(&heff_st_cv); }
static int64_t heff_st_now(void) { return (int64_t)GetTickCount64(); }
#else
static pthread_mutex_t heff_st_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t heff_st_cv = PTHREAD_COND_INITIALIZER;
static pthread_t heff_st_thread;
static void heff_st_lock(void) { pthread_mutex_lock(&heff_st_mu); }
static void heff_st_unlock(void) { pthread_mutex_unlock(&heff_st_mu); }
static void heff_st_wait(int ms) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME, &t);
  t.tv_nsec += (long)ms * 1000000L;
  t.tv_sec += t.tv_nsec / 1000000000L;
  t.tv_nsec %= 1000000000L;
  pthread_cond_timedwait(&heff_st_cv, &heff_st_mu, &t);
}
static void heff_st_wake(void) { pthread_cond_broadcast(&heff_st_cv); }
static int64_t heff_st_now(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}
#endif

// (the newest lines given, `heff_st_n` of them; how many are on the
// terminal now; whether they are not those; since when lines have been
// given, nothing drawn before; whether the thread draws; whether the
// program is ending)
static char **heff_st_lines = NULL;
static int heff_st_n = 0, heff_st_drawn = 0, heff_st_dirty = 0;
static int64_t heff_st_since = 0;
static int heff_st_going = 0, heff_st_over = 0;

// (lines are drawn where the standard error is a terminal and `TERM` is
// not `dumb`; on Windows, a console that takes escape sequences: 1, 0,
// or -1 not asked yet)
static int heff_st_tty = -1;

static int heff_st_terminal(void) {
  if (heff_st_tty >= 0) return heff_st_tty;
  const char *term = getenv("TERM");
  int ok = !(term && strcmp(term, "dumb") == 0);
#ifdef _WIN32
  DWORD mode;
  HANDLE h = GetStdHandle(STD_ERROR_HANDLE);
  ok = ok && _isatty(2) && GetConsoleMode(h, &mode)
    && ((mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING) || SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING));
#else
  ok = ok && isatty(2);
#endif
  heff_st_tty = ok;
  return ok;
}

// (the terminal's columns and rows: 80 by 25 if it does not say)
static void heff_st_size(int *cols, int *rows) {
  *cols = 80;
  *rows = 25;
#ifdef _WIN32
  CONSOLE_SCREEN_BUFFER_INFO info;
  if (GetConsoleScreenBufferInfo(GetStdHandle(STD_ERROR_HANDLE), &info)) {
    *cols = info.srWindow.Right - info.srWindow.Left + 1;
    *rows = info.srWindow.Bottom - info.srWindow.Top + 1;
  }
#else
  struct winsize w;
  if (ioctl(2, TIOCGWINSZ, &w) == 0 && w.ws_col > 0 && w.ws_row > 0) {
    *cols = w.ws_col;
    *rows = w.ws_row;
  }
#endif
}

// (how many columns a character takes: two, East Asian wide ones, else
// one)
static int heff_st_width(uint32_t u) {
  return (u >= 0x1100 && u <= 0x115F) || (u >= 0x2E80 && u <= 0xA4CF) || (u >= 0xAC00 && u <= 0xD7A3)
    || (u >= 0xF900 && u <= 0xFAFF) || (u >= 0xFE30 && u <= 0xFE4F) || (u >= 0xFF00 && u <= 0xFF60)
    || (u >= 0xFFE0 && u <= 0xFFE6) || (u >= 0x1F300 && u <= 0x1F64F) || (u >= 0x1F900 && u <= 0x1F9FF)
    || (u >= 0x20000 && u <= 0x3FFFD) ? 2 : 1;
}

// (a line, UTF-8, as much of it as fits in `width` columns)
static void heff_st_cut(Buf *b, const char *s, int width) {
  int w = 0;
  const unsigned char *p = (const unsigned char *)s;
  while (*p) {
    int len = *p < 0x80 ? 1 : *p < 0xE0 ? 2 : *p < 0xF0 ? 3 : 4;
    uint32_t u = len == 1 ? *p : len == 2 ? *p & 0x1F : len == 3 ? *p & 0x0F : *p & 0x07;
    for (int i = 1; i < len; i++) {
      if ((p[i] & 0xC0) != 0x80) { len = i; break; }
      u = (u << 6) | (p[i] & 0x3F);
    }
    int cw = heff_st_width(u);
    if (w + cw > width) break;
    buf_put(b, (const char *)p, (size_t)len);
    w += cw;
    p += len;
  }
}

// (what is drawn cleared: the cursor is where it starts)
static void heff_st_clear(void) {
  if (heff_st_drawn == 0) return;
  fputs("\x1b[J", stderr);
  fflush(stderr);
  heff_st_drawn = 0;
  heff_st_dirty = heff_st_n > 0;
}

// (the newest lines drawn in place of what was, at once -- the cursor
// back where they start -- as one write, the terminal told to show it
// whole: the lock held)
static void heff_st_draw(void) {
  int cols, rows;
  heff_st_size(&cols, &rows);
  Buf b = {0};
  buf_str(&b, "\x1b[?2026h\x1b[J");
  int n = 0;
  for (; n < heff_st_n && n + 2 < rows; n++) {
    // (a column short of the width: a line that fills it wraps on some)
    heff_st_cut(&b, heff_st_lines[n], cols - 1);
#ifdef _WIN32
    buf_str(&b, "\r\n");
#else
    buf_str(&b, "\n");
#endif
  }
  if (n > 0) {
    buf_str(&b, "\r");
    for (int i = 0; i < n; i++) buf_str(&b, "\x1bM");
  }
  buf_str(&b, "\x1b[?2026l");
  fwrite(b.s, 1, b.n, stderr);
  fflush(stderr);
  free(b.s);
  heff_st_drawn = n;
  heff_st_dirty = 0;
}

#ifdef _WIN32
static DWORD WINAPI heff_st_loop(LPVOID u) {
#else
static void *heff_st_loop(void *u) {
#endif
  (void)u;
  heff_st_lock();
  while (heff_st_going) {
    heff_st_wait(80);
    if (heff_st_going && heff_st_dirty && heff_st_now() - heff_st_since >= 200) heff_st_draw();
  }
  heff_st_unlock();
  return 0;
}

static void heff_st_free(void) {
  for (int i = 0; i < heff_st_n; i++) free(heff_st_lines[i]);
  free(heff_st_lines);
  heff_st_lines = NULL;
  heff_st_n = 0;
}

// (what the streams' providers call: see `heff_lines`)
static void heff_st_hold(int what) {
  if (what == 0) {
    // (what was written out before the lines come back)
    if (heff_st_n > 0) fflush(stdout);
    heff_st_unlock();
    return;
  }
  heff_st_lock();
  heff_st_clear();
  if (what == 2) {
    heff_st_over = 1;
    heff_st_going = 0;
    heff_st_free();
    heff_st_wake();
    heff_st_unlock();
  }
}

static void heff_st_atexit(void) {
  if (heff_lines) heff_lines(2);
}

// (the lines given are those there are: the lock held)
static int heff_st_same(char **lines, int n) {
  if (n != heff_st_n) return 0;
  for (int i = 0; i < n; i++)
    if (strcmp(lines[i], heff_st_lines[i]) != 0) return 0;
  return 1;
}

// (the lines `l`, a list of strings, drawn from now on, unless they are
// those there are; none: nothing drawn, what was cleared at once.  The
// thread, once started, draws until the program ends: lines that come
// again later are drawn at its next turn, not after 200 ms -- zig waits
// once, too)
static void heff_st_show(V l) {
  if (!heff_st_terminal() || heff_st_over) return;
  int n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  char **lines = heff_alloc((size_t)(n ? n : 1) * sizeof(char *));
  int i = 0;
  // (a line with a NUL in it, which cannot be a C string, drawn empty)
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) {
    char *line = heff_cstr_text(heff_field(c, 0));
    lines[i++] = line ? line : strdup("");
  }
  heff_st_lock();
  if (heff_st_same(lines, n)) {
    heff_st_unlock();
    for (i = 0; i < n; i++) free(lines[i]);
    free(lines);
    return;
  }
  heff_st_free();
  heff_st_lines = lines;
  heff_st_n = n;
  heff_st_dirty = n > 0;
  if (n == 0) heff_st_clear();
  else if (!heff_st_going) {
    static int registered = 0;
    if (!registered) { registered = 1; atexit(heff_st_atexit); }
    heff_lines = heff_st_hold;
    heff_st_going = 1;
    heff_st_since = heff_st_now();
#ifdef _WIN32
    heff_st_thread = CreateThread(NULL, 0, heff_st_loop, NULL, 0, NULL);
    if (!heff_st_thread) heff_st_going = 0;
#else
    if (pthread_create(&heff_st_thread, NULL, heff_st_loop, NULL) != 0) heff_st_going = 0;
#endif
  }
  heff_st_unlock();
}

static uint32_t heff_st_ran_shape[3] = { LBL_status, LBL_out, LBL_err };

#ifndef _WIN32
// (a packet of zig's, the tasks of its tree, as a list of `MkKid`s)
static V heff_st_kids(const unsigned char *pk) {
  int n = pk[0];
  V l = NTAG(TAG_Nil);
  for (int i = n - 1; i >= 0; i--) {
    const unsigned char *s = pk + 1 + i * 128;
    uint32_t done = (uint32_t)s[0] | (uint32_t)s[1] << 8 | (uint32_t)s[2] << 16 | (uint32_t)s[3] << 24;
    uint32_t total = (uint32_t)s[4] | (uint32_t)s[5] << 8 | (uint32_t)s[6] << 16 | (uint32_t)s[7] << 24;
    char name[121];
    memcpy(name, s + 8, 120);
    name[120] = 0;
    V f[4] = { heff_str_text(name), MK_INT(done), MK_INT(total == 0xFFFFFFFFu ? 0 : total), MK_INT(pk[1 + n * 128 + i]) };
    l = heff_cons(heff_tag(TAG_MkKid, 4, f), l);
  }
  return l;
}

// (what the command has said of its progress, read: each whole packet
// taken, the newest one's tree given to `f`, whose lines are drawn)
static void heff_st_packets(Buf *pb, V f) {
  size_t at = 0, newest = (size_t)-1;
  while (pb->n - at >= 1) {
    size_t len = 1 + (size_t)(unsigned char)pb->s[at] * 129;
    if (pb->n - at < len) break;
    newest = at;
    at += len;
  }
  if (newest != (size_t)-1) {
    V lines = heff_tr(heff_app1(heff_dup(f), heff_st_kids((const unsigned char *)pb->s + newest)));
    heff_st_show(lines);
    heff_drop(lines);
  }
  memmove(pb->s, pb->s + at, pb->n - at);
  pb->n -= at;
}

extern char **environ;

// (the command `as` run as runtime.c's heff_capture runs it, with
// `ZIG_PROGRESS`, its progress drawn by `f` as it comes)
static int64_t heff_st_capture(char **as, Buf *bo, Buf *be, V f) {
  int64_t status = -1;
  int po[2], pe[2], pp[2];
  if (pipe(po) != 0) return -1;
  if (pipe(pe) != 0) { close(po[0]); close(po[1]); return -1; }
  if (pipe(pp) != 0) { close(po[0]); close(po[1]); close(pe[0]); close(pe[1]); return -1; }
  // (the environment, its ZIG_PROGRESS the pipe's end)
  int ne = 0;
  while (environ[ne]) ne++;
  char **env = heff_alloc((size_t)(ne + 2) * sizeof(char *));
  int k = 0;
  for (int i = 0; i < ne; i++)
    if (strncmp(environ[i], "ZIG_PROGRESS=", 13) != 0) env[k++] = environ[i];
  char zp[32];
  snprintf(zp, sizeof zp, "ZIG_PROGRESS=%d", pp[1]);
  env[k++] = zp;
  env[k] = NULL;
  posix_spawn_file_actions_t fa;
  posix_spawn_file_actions_init(&fa);
  posix_spawn_file_actions_adddup2(&fa, po[1], 1);
  posix_spawn_file_actions_adddup2(&fa, pe[1], 2);
  posix_spawn_file_actions_addclose(&fa, po[0]);
  posix_spawn_file_actions_addclose(&fa, pe[0]);
  posix_spawn_file_actions_addclose(&fa, pp[0]);
  pid_t pid;
  int ok = posix_spawnp(&pid, as[0], &fa, NULL, as, env) == 0;
  posix_spawn_file_actions_destroy(&fa);
  free(env);
  close(po[1]);
  close(pe[1]);
  close(pp[1]);
  // (its streams and its progress read together, until all are closed)
  struct pollfd fds[3] = { { po[0], POLLIN, 0 }, { pe[0], POLLIN, 0 }, { pp[0], POLLIN, 0 } };
  Buf pb = {0};
  int open = 3;
  char chunk[65536];
  while (open > 0) {
    if (poll(fds, 3, -1) < 0) break;
    for (int i = 0; i < 3; i++) {
      if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP))) continue;
      ssize_t got = read(fds[i].fd, chunk, sizeof chunk);
      if (got <= 0) { close(fds[i].fd); fds[i].fd = -1; open--; }
      else if (i == 2) { buf_put(&pb, chunk, (size_t)got); heff_st_packets(&pb, f); }
      else buf_put(i == 0 ? bo : be, chunk, (size_t)got);
    }
  }
  free(pb.s);
  if (ok) {
    int st;
    if (waitpid(pid, &st, 0) >= 0 && WIFEXITED(st)) status = WEXITSTATUS(st);
  }
  return status;
}
#endif

static V heff_provider_terminal(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_IsTerminal: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(heff_st_terminal()));
    return heff_tail(k, 1, &x);
  }
  case TAG_ShowLines: {
    heff_st_show(heff_field(p, 0));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ShowRun: {
    // (a command with a NUL in its name or an argument is not run: -1
    // its status, as where it cannot be)
    char *c = heff_cstr_text(heff_field(p, 0));
    int ok = c != NULL;
    int64_t n = 0;
    for (V l = heff_field(p, 1); heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) n++;
    char **as = heff_alloc((size_t)(n + 2) * sizeof(char *));
    as[0] = c;
    int64_t i = 1;
    for (V l = heff_field(p, 1); heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) {
      as[i] = heff_cstr_text(heff_field(l, 0));
      ok = ok && as[i] != NULL;
      i++;
    }
    as[i] = NULL;
    V f = heff_dup(heff_field(p, 2)), r = heff_dup(heff_field(p, 3));
    heff_drop(p);
    Buf bo = {0}, be = {0};
#ifdef _WIN32
    int64_t status = ok ? heff_capture(as, &bo, &be) : -1;
#else
    int64_t status = !ok ? -1 : heff_st_terminal() && !heff_st_over ? heff_st_capture(as, &bo, &be, f) : heff_capture(as, &bo, &be);
#endif
    heff_drop(f);
    for (int64_t j = 0; j < i; j++) free(as[j]);
    free(as);
    V fs[3] = {
      MK_INT(status),
      heff_str_bytes(bo.s ? bo.s : "", (int64_t)bo.n),
      heff_str_bytes(be.s ? be.s : "", (int64_t)be.n),
    };
    free(bo.s);
    free(be.s);
    V x = heff_answer(r, heff_rec(3, heff_st_ran_shape, fs));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of terminal");
    return 0;
  }
}

static V heff_perform_5(V p, V k) { return heff_provider_stdio(p, k); }
static V heff_perform_6(V p, V k) { return heff_provider_process(p, k); }
static V heff_perform_4(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_5(q, k) : heff_perform_6(q, k); }
static V heff_perform_7(V p, V k) { return heff_provider_fs(p, k); }
static V heff_perform_3(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_4(q, k) : heff_perform_7(q, k); }
static V heff_perform_8(V p, V k) { return heff_provider_report(p, k); }
static V heff_perform_2(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_3(q, k) : heff_perform_8(q, k); }
static V heff_perform_9(V p, V k) { return heff_provider_rpc(p, k); }
static V heff_perform_1(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_2(q, k) : heff_perform_9(q, k); }
static V heff_perform_10(V p, V k) { return heff_provider_terminal(p, k); }
static V heff_perform_0(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_1(q, k) : heff_perform_10(q, k); }
V heff_perform(V p, V k) { return heff_perform_0(p, k); }

static V heff_entry(void) { return g_run_24entry_get(); }
