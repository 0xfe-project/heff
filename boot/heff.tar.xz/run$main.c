#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Args 26338
#define TAG_Await 41810
#define TAG_Closed 4831
#define TAG_Copy 17796
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_IsTerminal 53507
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Log 24016
#define TAG_Message 12631
#define TAG_MkDir 57961
#define TAG_MkKid 64674
#define TAG_Move 53768
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Platform 55558
#define TAG_ProgramPath 46819
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_ReadStdin 20528
#define TAG_Remove 9747
#define TAG_Run 29975
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Timeout 14063
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_err 310239
#define LBL_out 319944
#define LBL_status 1054660381
V g_run_24entry_get(void);
// The standard streams' side of lib/std/io.hf, for the C backend: an
// effect provider.  A provider of the C backend defines, for each
// effect definition X of its module, `static V heff_provider_X(V p, V
// k)`: the operation `p` (a tag, `heff_tag_of`, its fields
// `heff_field`), done, and its answer given to the continuation `k`,
// last (`heff_tail`), as the JavaScript providers do (`k(a[1])`).  A
// function of the operation's (`ReadStdin`'s) is asked for its value
// through `heff_tr`.  It owns `p` and `k` (reference counts, as
// lib/c/runtime.c says): it takes what it keeps of `p` (`heff_dup`),
// drops `p`, and gives `k` away.  It is bundled after lib/c/runtime.c,
// whose functions it uses -- among them the world's, which hold what
// every provider hands out (`heff_hold`, `heff_held`, `heff_release`:
// lib/std/handle.hf says how).

// (the lines std.progress draws on the terminal, once there are any:
// what is written clears them first, and they come back below it --
// lib/std/progress.provider.c says how)
static void (*heff_lines)(int);

static V heff_provider_stdio(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Write: {
    if (heff_lines) heff_lines(1);
    heff_put(stdout, heff_field(p, 0));
    if (heff_lines) heff_lines(0);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_WriteErr: {
    if (heff_lines) heff_lines(1);
    fflush(stdout);
    heff_put(stderr, heff_field(p, 0));
    if (heff_lines) heff_lines(0);
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ReadStdin: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    size_t cap = 4096, n = 0;
    unsigned char *buf = heff_alloc(cap);
    size_t got;
    while ((got = fread(buf + n, 1, cap - n, stdin)) > 0) {
      n += got;
      if (n == cap) {
        unsigned char *b2 = heff_alloc(cap * 2);
        memcpy(b2, buf, n);
        free(buf);
        buf = b2;
        cap *= 2;
      }
    }
    V s = heff_str_utf8(buf, (int64_t)n);
    free(buf);
    V x = heff_tr(heff_app1(f, s));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of stdio");
    return 0;
  }
}

// The process's side of lib/std/process.hf, for the C backend: an effect
// provider (the shape of one is said in lib/std/io.provider.c).
// `Exit` ends the program there; `Exec` runs the command in its place
// (Node.js's first thread does that once the program has ended).

#ifndef _WIN32
#include <unistd.h>
#endif
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif

// (where the program is: its executable, as the system says)
static V heff_program_path(void) {
  char buf[4096];
#if defined(_WIN32)
  DWORD n = GetModuleFileNameA(NULL, buf, sizeof buf);
  if (n == 0 || n >= sizeof buf) return heff_str_c(heff_argv[0]);
  return heff_str_c(buf);
#elif defined(__APPLE__)
  uint32_t n = sizeof buf;
  if (_NSGetExecutablePath(buf, &n) != 0) return heff_str_c(heff_argv[0]);
#else
  ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
  if (n < 0) return heff_str_c(heff_argv[0]);
  buf[n] = 0;
#endif
#ifndef _WIN32
  char real[4096];
  return heff_str_c(realpath(buf, real) ? real : buf);
#endif
}

// (a list of strings as a NULL-ended array of C strings, `first` first)
static char **heff_argv_of(const char *first, V l) {
  int64_t n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  char **as = heff_alloc((n + 2) * sizeof(char *));
  as[0] = (char *)first;
  int64_t i = 1;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) as[i++] = heff_cstr(heff_field(c, 0));
  as[i] = NULL;
  return as;
}


// (the lines std.progress draws on the terminal, once there are any,
// cleared for good where a command runs in the program's place: an
// `Exit` clears them as the program ends -- lib/std/progress.provider.c)
static void (*heff_lines)(int);

static uint32_t heff_run_shape[3] = { LBL_status, LBL_out, LBL_err };

static V heff_run(V cmd, V args) {
  char *c = heff_cstr(cmd);
  char **as = heff_argv_of(c, args);
  Buf bo = {0}, be = {0};
  int64_t status = heff_capture(as, &bo, &be);
  V f[3] = {
    MK_INT(status),
    heff_str_utf8((const unsigned char *)(bo.s ? bo.s : ""), (int64_t)bo.n),
    heff_str_utf8((const unsigned char *)(be.s ? be.s : ""), (int64_t)be.n),
  };
  free(bo.s);
  free(be.s);
  return heff_rec(3, heff_run_shape, f);
}

static V heff_provider_process(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_Args: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_strs(heff_argv + 1, heff_argc - 1));
    return heff_tail(k, 1, &x);
  }
  case TAG_GetEnv: {
    char *name = heff_cstr(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    const char *v = getenv(name);
    free(name);
    V x = heff_answer(f, v ? heff_just(heff_str_c(v)) : heff_nothing);
    return heff_tail(k, 1, &x);
  }
  case TAG_ProgramPath: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_program_path());
    return heff_tail(k, 1, &x);
  }
  case TAG_Platform: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
#if defined(__APPLE__)
    const char *pl = "darwin";
#elif defined(_WIN32)
    const char *pl = "win32";
#else
    const char *pl = "linux";
#endif
    V x = heff_answer(f, heff_str_c(pl));
    return heff_tail(k, 1, &x);
  }
  case TAG_Exit: {
    int code = (int)INT_OF(heff_field(p, 0));
    fflush(stdout);
    fflush(stderr);
    exit(code);
  }
  case TAG_Run: {
    V cmd = heff_dup(heff_field(p, 0)), args = heff_dup(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    V r = heff_run(cmd, args);
    heff_drop(cmd);
    heff_drop(args);
    V x = heff_answer(f, r);
    return heff_tail(k, 1, &x);
  }
  case TAG_Exec: {
    char *c = heff_cstr(heff_field(p, 0));
    char **as = heff_argv_of(c, heff_field(p, 1));
    // (std.progress's lines, if any are drawn, cleared for good: the
    // command has the terminal now)
    if (heff_lines) heff_lines(2);
    fflush(stdout);
    fflush(stderr);
#ifdef _WIN32
    // (no exec on Windows: the command is run, and its exit code this
    // program's)
    HANDLE h = heff_spawn(as, GetStdHandle(STD_OUTPUT_HANDLE), GetStdHandle(STD_ERROR_HANDLE));
    if (h) exit((int)heff_wait(h));
#else
    execvp(c, as);
#endif
    fprintf(stderr, "%s: cannot run it\n", c);
    exit(1);
  }
  default:
    heff_fail("not an operation of process");
    return 0;
  }
}

// The disk's side of lib/std/filesystem.hf, for the C backend: an effect
// provider (the shape of one is said in lib/std/io.provider.c).

#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef _WIN32
// (no links on Windows as stat sees them, and mkdir takes no mode)
#define lstat stat
#define S_ISLNK(m) 0
#define heff_mkdir(p) mkdir(p)
#define heff_is_sep(c) ((c) == '/' || (c) == '\\')
#else
#define heff_mkdir(p) mkdir(p, 0777)
#define heff_is_sep(c) ((c) == '/')
#endif

// (a file's text, if it can be read)
static V heff_read_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) return heff_nothing;
  Buf b = {0};
  char chunk[65536];
  size_t got;
  while ((got = fread(chunk, 1, sizeof chunk, f)) > 0) buf_put(&b, chunk, got);
  int bad = ferror(f);
  fclose(f);
  V s = bad ? 0 : heff_str_utf8((const unsigned char *)(b.s ? b.s : ""), (int64_t)b.n);
  free(b.s);
  return bad ? heff_nothing : heff_just(s);
}

static int heff_write_file(const char *path, V s) {
  FILE *f = fopen(path, "wb");
  if (!f) return 0;
  heff_put(f, s);
  return fclose(f) == 0;
}

// (a directory and those it is in)
static int heff_mkdir_p(char *path) {
  for (char *c = path + 1; *c; c++)
    if (heff_is_sep(*c)) {
      char sep = *c;
      *c = 0;
      // (a drive, `C:`, is there already)
      int drive = c[-1] == ':';
      int ok = drive || heff_mkdir(path) == 0 || errno == EEXIST;
      *c = sep;
      if (!ok) return 0;
    }
  return heff_mkdir(path) == 0 || errno == EEXIST;
}

// (the names in a directory, sorted)
static V heff_read_dir(const char *path) {
  DIR *d = opendir(path);
  if (!d) return heff_nothing;
  int64_t n = 0, cap = 64;
  char **ns = heff_alloc(cap * sizeof(char *));
  struct dirent *e;
  while ((e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    if (n == cap) {
      char **n2 = heff_alloc(cap * 2 * sizeof(char *));
      memcpy(n2, ns, n * sizeof(char *));
      free(ns);
      ns = n2;
      cap *= 2;
    }
    ns[n++] = strdup(e->d_name);
  }
  closedir(d);
  qsort(ns, n, sizeof(char *), heff_cmp_cstr);
  V l = heff_strs(ns, n);
  for (int64_t i = 0; i < n; i++) free(ns[i]);
  free(ns);
  return heff_just(l);
}

// (every file and directory under `p`, its mode's write bits off, or on:
// a directory is made writable before what it holds, read-only after)
static int heff_chmod_all(const char *p, int writable) {
  struct stat st;
  if (lstat(p, &st) != 0) return errno == ENOENT ? -1 : 0;
  if (S_ISLNK(st.st_mode)) return 1;
  mode_t mode = writable ? (st.st_mode | 0200) : (st.st_mode & ~0222);
  mode &= 07777;
  if (S_ISDIR(st.st_mode)) {
    if (writable && chmod(p, mode) != 0) return 0;
    DIR *d = opendir(p);
    if (!d) return 0;
    struct dirent *e;
    int ok = 1;
    while (ok && (e = readdir(d))) {
      if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
      char *q = heff_join(p, e->d_name);
      ok = heff_chmod_all(q, writable) != 0;
      free(q);
    }
    closedir(d);
    if (!ok) return 0;
    if (!writable && chmod(p, mode) != 0) return 0;
    return 1;
  }
  return chmod(p, mode) == 0;
}

// (a file, or a directory and all it holds; nothing there is no failure)
static int heff_remove_all(const char *p) {
  struct stat st;
  if (lstat(p, &st) != 0) return errno == ENOENT;
  if (!S_ISDIR(st.st_mode)) return unlink(p) == 0;
  DIR *d = opendir(p);
  if (!d) return 0;
  struct dirent *e;
  int ok = 1;
  while (ok && (e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    char *q = heff_join(p, e->d_name);
    ok = heff_remove_all(q);
    free(q);
  }
  closedir(d);
  return ok && rmdir(p) == 0;
}

// (a file's bytes copied to `q`, which is given `mode`)
static int heff_copy_file(const char *p, const char *q, mode_t mode) {
  FILE *f = fopen(p, "rb");
  if (!f) return 0;
  FILE *g = fopen(q, "wb");
  if (!g) {
    fclose(f);
    return 0;
  }
  char *chunk = heff_alloc(65536);
  size_t got;
  int ok = 1;
  while (ok && (got = fread(chunk, 1, 65536, f)) > 0) ok = fwrite(chunk, 1, got, g) == got;
  ok = ok && !ferror(f);
  free(chunk);
  fclose(f);
  ok = fclose(g) == 0 && ok;
  return ok && chmod(q, mode) == 0;
}

// (a file, or a directory and all it holds, copied to `q`: links
// followed, modes kept -- a directory's once what it holds is in it)
static int heff_copy_all(const char *p, const char *q) {
  struct stat st;
  if (stat(p, &st) != 0) return 0;
  mode_t mode = st.st_mode & 07777;
  if (!S_ISDIR(st.st_mode)) return heff_copy_file(p, q, mode);
  if (heff_mkdir(q) != 0) return 0;
  DIR *d = opendir(p);
  if (!d) return 0;
  struct dirent *e;
  int ok = 1;
  while (ok && (e = readdir(d))) {
    if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
    char *a = heff_join(p, e->d_name);
    char *b = heff_join(q, e->d_name);
    ok = heff_copy_all(a, b);
    free(a);
    free(b);
  }
  closedir(d);
  return ok && chmod(q, mode) == 0;
}

// (nothing is at `p`: no file, directory or link)
static int heff_nothing_at(const char *p) {
  struct stat st;
  return lstat(p, &st) != 0 && errno == ENOENT;
}

static V heff_provider_fs(V p, V k) {
  char *path = heff_cstr(heff_field(p, 0));
  V x;
  switch (heff_tag_of(p)) {
  case TAG_ReadFile: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_read_file(path));
    break;
  }
  case TAG_WriteFile: {
    int ok = heff_write_file(path, heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_MkDir: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_bool(heff_mkdir_p(path)));
    break;
  }
  case TAG_ReadDir: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_read_dir(path));
    break;
  }
  case TAG_Remove: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    int ok = heff_chmod_all(path, 1) != 0 && heff_remove_all(path);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_ReadOnly: {
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, heff_bool(heff_chmod_all(path, 0) == 1));
    break;
  }
  case TAG_Copy: {
    char *to = heff_cstr(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    int ok = heff_nothing_at(to) && heff_copy_all(path, to);
    free(to);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  case TAG_Move: {
    char *to = heff_cstr(heff_field(p, 1));
    V f = heff_dup(heff_field(p, 2));
    heff_drop(p);
    int ok = heff_nothing_at(to) && rename(path, to) == 0;
    free(to);
    x = heff_answer(f, heff_bool(ok));
    break;
  }
  default:
    heff_fail("not an operation of fs");
    return 0;
  }
  free(path);
  return heff_tail(k, 1, &x);
}

// The terminal's side of src/heff/report.hf, for the C backend: an
// effect provider (the shape of one is said in lib/std/io.provider.c).

#include <unistd.h>

// (colour on the stream `fd`: it is a terminal, or `HEFF_TTY=1` says it
// is, and `NO_COLOR` is not set)
static int heff_report_color(int fd) {
  const char *tty = getenv("HEFF_TTY"), *no = getenv("NO_COLOR");
  return (isatty(fd) || (tty && tty[0] == '1' && !tty[1])) && !(no && no[0]);
}

static V heff_provider_report(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_UseColor:
  case TAG_ErrColor: {
    int fd = heff_tag_of(p) == TAG_UseColor ? 1 : 2;
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(heff_report_color(fd)));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of report");
    return 0;
  }
}

// The client's side of src/heff/rpc.hf, for the C backend: JSON-RPC over
// stdio, as the Language Server Protocol frames it -- each message a
// `Content-Length: n` header, a blank line, then n bytes of JSON; stdout
// carries only the messages, logs go to stderr -- and what of the host a
// language server asks for (the shape of a provider is said in
// lib/std/io.provider.c).

#include <dirent.h>
#ifndef _WIN32
#include <poll.h>
#endif
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#ifdef _WIN32
#define lstat stat
#endif

// A message's JSON, as src/heff/json.hf's `Json`
// ---------------------------------------------------------------------

typedef struct { const char *s, *end; } Json;

static void json_ws(Json *j) {
  while (j->s < j->end && (*j->s == ' ' || *j->s == '\t' || *j->s == '\n' || *j->s == '\r')) j->s++;
}

static int json_lit(Json *j, const char *w) {
  size_t n = strlen(w);
  if ((size_t)(j->end - j->s) < n || memcmp(j->s, w, n) != 0) return 0;
  j->s += n;
  return 1;
}

static void json_utf8(Buf *b, uint32_t u) {
  char c[4];
  size_t n;
  if (u < 0x80) { c[0] = (char)u; n = 1; }
  else if (u < 0x800) { c[0] = (char)(0xC0 | (u >> 6)); c[1] = (char)(0x80 | (u & 0x3F)); n = 2; }
  else if (u < 0x10000) { c[0] = (char)(0xE0 | (u >> 12)); c[1] = (char)(0x80 | ((u >> 6) & 0x3F)); c[2] = (char)(0x80 | (u & 0x3F)); n = 3; }
  else { c[0] = (char)(0xF0 | (u >> 18)); c[1] = (char)(0x80 | ((u >> 12) & 0x3F)); c[2] = (char)(0x80 | ((u >> 6) & 0x3F)); c[3] = (char)(0x80 | (u & 0x3F)); n = 4; }
  buf_put(b, c, n);
}

static int json_hex4(Json *j, uint32_t *u) {
  if (j->end - j->s < 4) return 0;
  *u = 0;
  for (int i = 0; i < 4; i++) {
    char c = *j->s++;
    *u <<= 4;
    if (c >= '0' && c <= '9') *u |= (uint32_t)(c - '0');
    else if (c >= 'a' && c <= 'f') *u |= (uint32_t)(c - 'a' + 10);
    else if (c >= 'A' && c <= 'F') *u |= (uint32_t)(c - 'A' + 10);
    else return 0;
  }
  return 1;
}

// (a string's text, its escapes undone: 0 if it is not one)
static V json_string(Json *j) {
  if (j->s >= j->end || *j->s != '"') return 0;
  j->s++;
  Buf b = {0};
  for (;;) {
    if (j->s >= j->end) { free(b.s); return 0; }
    char c = *j->s++;
    if (c == '"') break;
    if (c != '\\') { buf_put(&b, &c, 1); continue; }
    if (j->s >= j->end) { free(b.s); return 0; }
    char e = *j->s++;
    uint32_t u;
    switch (e) {
    case '"': case '\\': case '/': buf_put(&b, &e, 1); break;
    case 'b': buf_put(&b, "\b", 1); break;
    case 'f': buf_put(&b, "\f", 1); break;
    case 'n': buf_put(&b, "\n", 1); break;
    case 'r': buf_put(&b, "\r", 1); break;
    case 't': buf_put(&b, "\t", 1); break;
    case 'u':
      if (!json_hex4(j, &u)) { free(b.s); return 0; }
      if (u >= 0xD800 && u < 0xDC00 && j->end - j->s >= 6 && j->s[0] == '\\' && j->s[1] == 'u') {
        Json save = *j;
        uint32_t lo;
        j->s += 2;
        if (json_hex4(j, &lo) && lo >= 0xDC00 && lo < 0xE000) u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00);
        else *j = save;
      }
      json_utf8(&b, u);
      break;
    default: free(b.s); return 0;
    }
  }
  V s = heff_str_utf8((const unsigned char *)(b.s ? b.s : ""), (int64_t)b.n);
  free(b.s);
  return s;
}

static V json_value(Json *j);

// (a list of what `item` reads, between `open` and `close`)
static V json_items(Json *j, char close, V (*item)(Json *)) {
  j->s++;
  int64_t n = 0, cap = 8;
  V *xs = heff_alloc(cap * sizeof(V));
  json_ws(j);
  if (j->s < j->end && *j->s == close) j->s++;
  else
    for (;;) {
      V x = item(j);
      if (!x) goto bad;
      if (n == cap) {
        V *x2 = heff_alloc(cap * 2 * sizeof(V));
        memcpy(x2, xs, n * sizeof(V));
        free(xs);
        xs = x2;
        cap *= 2;
      }
      xs[n++] = x;
      json_ws(j);
      if (j->s < j->end && *j->s == ',') { j->s++; continue; }
      if (j->s < j->end && *j->s == close) { j->s++; break; }
      goto bad;
    }
  V l = NTAG(TAG_Nil);
  for (int64_t i = n - 1; i >= 0; i--) l = heff_cons(xs[i], l);
  free(xs);
  return l;
bad:
  for (int64_t i = 0; i < n; i++) heff_drop(xs[i]);
  free(xs);
  return 0;
}

static V json_member(Json *j) {
  json_ws(j);
  V k = json_string(j);
  if (!k) return 0;
  json_ws(j);
  if (j->s >= j->end || *j->s != ':') { heff_drop(k); return 0; }
  j->s++;
  V v = json_value(j);
  if (!v) { heff_drop(k); return 0; }
  V f[2] = { k, v };
  return heff_tag(TAG_MkPair, 2, f);
}

static V json_one(int tag, V x) { return x ? heff_tag(tag, 1, &x) : 0; }

// (a number: an integer an Int, as JavaScript's Number.isInteger says)
static V json_number(Json *j) {
  char *e;
  double d = strtod(j->s, &e);
  if (e == j->s || e > j->end) return 0;
  j->s = e;
  if (d == floor(d) && fabs(d) < 2305843009213693952.0) return json_one(TAG_JInt, MK_INT((int64_t)d));
  return json_one(TAG_JFloat, heff_flt(d));
}

static V json_value(Json *j) {
  json_ws(j);
  if (j->s >= j->end) return 0;
  switch (*j->s) {
  case 'n': return json_lit(j, "null") ? NTAG(TAG_JNull) : 0;
  case 't': return json_lit(j, "true") ? json_one(TAG_JBool, NTAG(TAG_True)) : 0;
  case 'f': return json_lit(j, "false") ? json_one(TAG_JBool, NTAG(TAG_False)) : 0;
  case '"': return json_one(TAG_JString, json_string(j));
  case '[': return json_one(TAG_JArray, json_items(j, ']', json_value));
  case '{': return json_one(TAG_JObject, json_items(j, '}', json_member));
  default: return json_number(j);
  }
}

// (a body as JSON: 0 if it is not)
static V json_parse(const char *s, size_t n) {
  Json j = { s, s + n };
  V v = json_value(&j);
  json_ws(&j);
  if (v && j.s != j.end) { heff_drop(v); return 0; }
  return v;
}

// The messages, read from stdin
// ---------------------------------------------------------------------

static Buf rpc_in;
static int rpc_closed;

// (the next message's body, if a whole one is read: malloc'd)
static char *rpc_take(size_t *len) {
  for (;;) {
    char *sep = NULL;
    for (size_t i = 0; i + 4 <= rpc_in.n; i++)
      if (memcmp(rpc_in.s + i, "\r\n\r\n", 4) == 0) { sep = rpc_in.s + i; break; }
    if (!sep) return NULL;
    size_t head = (size_t)(sep - rpc_in.s), start = head + 4;
    long n = -1;
    for (size_t i = 0; i + 15 <= head; i++)
      if (strncasecmp(rpc_in.s + i, "Content-Length:", 15) == 0) {
        size_t k = i + 15;
        while (k < head && (rpc_in.s[k] == ' ' || rpc_in.s[k] == '\t')) k++;
        if (k < head && rpc_in.s[k] >= '0' && rpc_in.s[k] <= '9') {
          n = 0;
          while (k < head && rpc_in.s[k] >= '0' && rpc_in.s[k] <= '9') n = n * 10 + (rpc_in.s[k++] - '0');
        }
        break;
      }
    if (n < 0) {
      memmove(rpc_in.s, rpc_in.s + start, rpc_in.n - start);
      rpc_in.n -= start;
      continue;
    }
    if (rpc_in.n < start + (size_t)n) return NULL;
    char *body = heff_alloc((size_t)n + 1);
    memcpy(body, rpc_in.s + start, (size_t)n);
    body[n] = 0;
    memmove(rpc_in.s, rpc_in.s + start + n, rpc_in.n - start - n);
    rpc_in.n -= start + n;
    *len = (size_t)n;
    return body;
  }
}

static int64_t rpc_now(void) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME, &t);
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

// (whether stdin has something to read within `wait` ms (none, below
// 0): 1 if so, 0 if not, below 0 if waiting failed)
static int rpc_ready(int wait) {
#ifdef _WIN32
  // (a pipe, as an editor gives it, is looked into until it has bytes;
  // what is not a pipe is read, waiting there)
  HANDLE h = GetStdHandle(STD_INPUT_HANDLE);
  int64_t until = rpc_now() + wait;
  for (;;) {
    DWORD avail = 0;
    if (!PeekNamedPipe(h, NULL, 0, NULL, &avail, NULL) || avail > 0) return 1;
    if (wait >= 0 && rpc_now() >= until) return 0;
    Sleep(5);
  }
#else
  struct pollfd fd = { 0, POLLIN, 0 };
  return poll(&fd, 1, wait);
#endif
}

// (the next event: a message, the time waited for, `ms`, passing first
// (none, below 0), or the client gone)
static V rpc_await(int64_t ms) {
  int64_t until = rpc_now() + ms;
  for (;;) {
    size_t n;
    char *body = rpc_take(&n);
    if (body) {
      V v = json_parse(body, n);
      free(body);
      if (v) return heff_tag(TAG_Message, 1, &v);
      fputs("heff lsp: not JSON\n", stderr);
      continue;
    }
    if (rpc_closed) return NTAG(TAG_Closed);
    int wait = -1;
    if (ms >= 0) {
      int64_t left = until - rpc_now();
      if (left <= 0) return NTAG(TAG_Timeout);
      wait = left > 0x7fffffff ? 0x7fffffff : (int)left;
    }
    int r = rpc_ready(wait);
    if (r == 0) return NTAG(TAG_Timeout);
    if (r < 0) continue;
    char chunk[65536];
    ssize_t got = read(0, chunk, sizeof chunk);
    if (got <= 0) rpc_closed = 1;
    else buf_put(&rpc_in, chunk, (size_t)got);
  }
}

// Paths and URIs
// ---------------------------------------------------------------------

// (a path made absolute against the working directory, its `.`, `..`
// and repeated separators resolved, as Node.js's path.resolve: malloc'd;
// on Windows a path starts with its drive, `C:`, and its separator is
// `\\`, though `/` is read as one too)
#ifdef _WIN32
#define RPC_SEP '\\'
#define rpc_is_sep(c) ((c) == '/' || (c) == '\\')
#else
#define RPC_SEP '/'
#define rpc_is_sep(c) ((c) == '/')
#endif

static char *rpc_resolve(const char *p) {
  Buf b = {0};
  char cwd[4096];
  if (!getcwd(cwd, sizeof cwd)) cwd[0] = 0;
#ifdef _WIN32
  int drive = p[0] && p[1] == ':';
  if (drive && rpc_is_sep(p[2])) buf_str(&b, p);
  else if (rpc_is_sep(p[0])) {
    if (cwd[0] && cwd[1] == ':') buf_put(&b, cwd, 2);
    buf_str(&b, p);
  } else {
    buf_str(&b, cwd);
    buf_put(&b, "\\", 1);
    buf_str(&b, drive ? p + 2 : p);
  }
#else
  if (p[0] != '/') {
    buf_str(&b, cwd);
    buf_put(&b, "/", 1);
  }
  buf_str(&b, p);
#endif
  buf_put(&b, "", 1);
  char *out = heff_alloc(b.n + 2);
  size_t o = 0, top = 0;
  const char *s = b.s;
#ifdef _WIN32
  if (s[0] && s[1] == ':') {
    out[o++] = s[0];
    out[o++] = ':';
    s += 2;
    top = 2;
  }
#endif
  while (*s) {
    while (rpc_is_sep(*s)) s++;
    const char *e = s;
    while (*e && !rpc_is_sep(*e)) e++;
    size_t n = (size_t)(e - s);
    if (n == 0 || (n == 1 && s[0] == '.')) {}
    else if (n == 2 && s[0] == '.' && s[1] == '.') {
      while (o > top && out[o - 1] != RPC_SEP) o--;
      if (o > top) o--;
    } else {
      out[o++] = RPC_SEP;
      memcpy(out + o, s, n);
      o += n;
    }
    s = e;
  }
  if (o == top) out[o++] = RPC_SEP;
  out[o] = 0;
  free(b.s);
  return out;
}

static int rpc_hex(char c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

// (a file: URI's path, as Node.js's fileURLToPath: none if it has a host)
static V rpc_uri_path(const char *u) {
  if (strncmp(u, "file:", 5) != 0) return heff_nothing;
  u += 5;
  if (strncmp(u, "//", 2) == 0) {
    u += 2;
    const char *h = u;
    while (*u && *u != '/') u++;
    size_t hn = (size_t)(u - h);
    if (hn != 0 && !(hn == 9 && strncasecmp(h, "localhost", 9) == 0)) return heff_nothing;
  }
  Buf b = {0};
  for (; *u && *u != '?' && *u != '#'; u++) {
    int a, c;
    if (*u == '%' && (a = rpc_hex(u[1])) >= 0 && (c = rpc_hex(u[2])) >= 0) {
      char x = (char)(a * 16 + c);
      if (x == '/' || (RPC_SEP == '\\' && x == '\\')) { free(b.s); return heff_nothing; }
      buf_put(&b, &x, 1);
      u += 2;
    } else buf_put(&b, u, 1);
  }
  if (b.n == 0) buf_put(&b, "/", 1);
#ifdef _WIN32
  // (`/C:/a/b` is `C:\\a\\b`; a path without its drive is no path here)
  buf_put(&b, "", 1);
  if (!(b.n >= 4 && b.s[0] == '/' && b.s[2] == ':' && (b.s[3] == '/' || b.s[3] == 0))) { free(b.s); return heff_nothing; }
  b.n -= 2;
  memmove(b.s, b.s + 1, b.n);
  for (size_t i = 0; i < b.n; i++)
    if (b.s[i] == '/') b.s[i] = '\\';
  if (b.n == 2) buf_put(&b, "\\", 1);
#endif
  V s = heff_str_utf8((const unsigned char *)b.s, (int64_t)b.n);
  free(b.s);
  return heff_just(s);
}

// (a path as a file: URI, as Node.js's pathToFileURL(...).href)
static V rpc_path_uri(const char *p) {
  char *abs = rpc_resolve(p);
  Buf b = {0};
#ifdef _WIN32
  // (`C:\\a\\b` is `file:///C:/a/b`)
  for (char *c = abs; *c; c++)
    if (*c == '\\') *c = '/';
  buf_str(&b, "file:///");
#else
  buf_str(&b, "file://");
#endif
  for (const unsigned char *c = (const unsigned char *)abs; *c; c++) {
    if (*c <= 0x20 || *c >= 0x7F || strchr("\"#<>?`{}%\\", *c)) {
      char e[4];
      snprintf(e, sizeof e, "%%%02X", *c);
      buf_put(&b, e, 3);
    } else buf_put(&b, (const char *)c, 1);
  }
  free(abs);
  V s = heff_str_utf8((const unsigned char *)b.s, (int64_t)b.n);
  free(b.s);
  return s;
}

// The project's files
// ---------------------------------------------------------------------

static int rpc_is_root(const char *d) {
  char *p = heff_join(d, "package.hf");
  struct stat st;
  int ok = stat(p, &st) == 0 && S_ISREG(st.st_mode) && access(p, R_OK) == 0;
  free(p);
  return ok;
}

typedef struct { char **xs; int64_t n, cap; } Names;

static void names_add(Names *ns, char *x) {
  if (ns->n == ns->cap) {
    int64_t cap = ns->cap ? ns->cap * 2 : 16;
    char **x2 = heff_alloc(cap * sizeof(char *));
    if (ns->n) memcpy(x2, ns->xs, ns->n * sizeof(char *));
    free(ns->xs);
    ns->xs = x2;
    ns->cap = cap;
  }
  ns->xs[ns->n++] = x;
}

static int names_has(Names *ns, const char *x) {
  for (int64_t i = 0; i < ns->n; i++)
    if (strcmp(ns->xs[i], x) == 0) return 1;
  return 0;
}

static void names_free(Names *ns) {
  for (int64_t i = 0; i < ns->n; i++) free(ns->xs[i]);
  free(ns->xs);
}

static void rpc_walk(const char *d, Names *ignored, Names *files) {
  DIR *dir = opendir(d);
  if (!dir) return;
  Names here = {0};
  struct dirent *e;
  while ((e = readdir(dir))) names_add(&here, strdup(e->d_name));
  closedir(dir);
  qsort(here.xs, here.n, sizeof(char *), heff_cmp_cstr);
  for (int64_t i = 0; i < here.n; i++) {
    const char *name = here.xs[i];
    if (name[0] == '.' || names_has(ignored, name)) continue;
    char *p = heff_join(d, name);
    struct stat st;
    if (lstat(p, &st) == 0) {
      if (S_ISDIR(st.st_mode)) {
        if (!rpc_is_root(p)) rpc_walk(p, ignored, files);
      } else if (S_ISREG(st.st_mode)) {
        size_t n = strlen(name);
        if (n >= 3 && strcmp(name + n - 3, ".hf") == 0) { names_add(files, p); continue; }
      }
    }
    free(p);
  }
  names_free(&here);
}

// (the `.hf` files of the project at `root` (a directory with a
// package.hf): every directory but another project's, a hidden one, or
// one the root's .gitignore names)
static V rpc_project_files(const char *root) {
  Names files = {0}, ignored = {0};
  if (rpc_is_root(root)) {
    names_add(&ignored, strdup("node_modules"));
    char *gi = heff_join(root, ".gitignore");
    FILE *f = fopen(gi, "r");
    free(gi);
    if (f) {
      char line[4096];
      while (fgets(line, sizeof line, f)) {
        char *s = line, *e = line + strlen(line);
        while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
        while (e > s && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\r' || e[-1] == '\n')) e--;
        if (s < e && *s == '/') s++;
        if (e > s && e[-1] == '/') e--;
        *e = 0;
        if (!*s || *s == '#' || strpbrk(s, "*?[/!")) continue;
        names_add(&ignored, strdup(s));
      }
      fclose(f);
    }
    rpc_walk(root, &ignored, &files);
  }
  V l = heff_strs(files.xs, files.n);
  names_free(&files);
  names_free(&ignored);
  return l;
}

// The provider
// ---------------------------------------------------------------------

static V heff_provider_rpc(V p, V k) {
  V x;
  switch (heff_tag_of(p)) {
  case TAG_Await: {
    int64_t ms = INT_OF(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    x = heff_answer(f, rpc_await(ms));
    break;
  }
  case TAG_Send: {
    char *body = heff_cstr(heff_field(p, 0));
    x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    size_t n = strlen(body);
    fprintf(stdout, "Content-Length: %zu\r\n\r\n", n);
    fwrite(body, 1, n, stdout);
    fflush(stdout);
    free(body);
    break;
  }
  case TAG_Log: {
    fputs("heff lsp: ", stderr);
    heff_put(stderr, heff_field(p, 0));
    fputc('\n', stderr);
    x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    break;
  }
  case TAG_Now: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    x = heff_answer(f, MK_INT(rpc_now()));
    break;
  }
  case TAG_ProjectFiles: case TAG_UriPath: case TAG_PathUri: case TAG_AbsPath: {
    int tag = heff_tag_of(p);
    char *s = heff_cstr(heff_field(p, 0));
    V f = heff_dup(heff_field(p, 1));
    heff_drop(p);
    V r;
    if (tag == TAG_ProjectFiles) r = rpc_project_files(s);
    else if (tag == TAG_UriPath) r = rpc_uri_path(s);
    else if (tag == TAG_PathUri) r = rpc_path_uri(s);
    else {
      char *a = rpc_resolve(s);
      r = heff_str_c(a);
      free(a);
    }
    free(s);
    x = heff_answer(f, r);
    break;
  }
  case TAG_Quit: {
    int code = (int)INT_OF(heff_field(p, 0));
    fflush(stdout);
    fflush(stderr);
    exit(code);
  }
  default:
    heff_fail("not an operation of rpc");
    return 0;
  }
  return heff_tail(k, 1, &x);
}

// The terminal's side of lib/std/progress.hf, for the C backend: an
// effect provider (the shape of one is said in lib/std/io.provider.c).
//
// The lines are drawn on the standard error by a thread of their own,
// as zig draws its progress (std.Progress): every 80 ms, the newest
// lines given, if they are not those drawn -- none in the first 200 ms
// after lines are first given, so that what is quickly done shows
// nothing -- each cut to the terminal's width, as many as leave two of
// its rows.  The cursor is left where the first line starts: what the
// program writes there clears them first (`heff_lines`, which
// lib/std/io.provider.c calls around each write), and they come back
// below it.  At the program's end, or where it runs a command in its
// place, they are cleared for good.
//
// A command run under a task (`ShowRun`) is given a pipe for its own
// progress, its number in `ZIG_PROGRESS`, as zig gives its children
// one: zig writes the tree of its tasks there every 80 ms, a packet
// each -- `n`, a byte; `n` tasks of 128 bytes (how many of its items
// are done, of how many: 32 bits each, little-endian; its name, 120
// bytes, ended by a 0 if shorter); and the index of each one's parent,
// a byte each (255: none) -- and the newest tree is given to the
// program's function, whose lines are drawn.  (On Windows, where zig's
// is a handle, the command is run as std.process's `run` runs it.)

#ifndef _WIN32
#include <sys/ioctl.h>
#endif
#include <time.h>

// (`heff_lines(1)`: what is drawn cleared, and nothing drawn, until
// `heff_lines(0)`; `heff_lines(2)`: cleared, and nothing drawn again.
// Set once lines are first given; the providers of the streams declare
// it too -- one variable, however many of them a program has)
static void (*heff_lines)(int);

#ifdef _WIN32
static SRWLOCK heff_st_mu = SRWLOCK_INIT;
static CONDITION_VARIABLE heff_st_cv = CONDITION_VARIABLE_INIT;
static HANDLE heff_st_thread;
static void heff_st_lock(void) { AcquireSRWLockExclusive(&heff_st_mu); }
static void heff_st_unlock(void) { ReleaseSRWLockExclusive(&heff_st_mu); }
static void heff_st_wait(int ms) { SleepConditionVariableSRW(&heff_st_cv, &heff_st_mu, (DWORD)ms, 0); }
static void heff_st_wake(void) { WakeAllConditionVariable(&heff_st_cv); }
static int64_t heff_st_now(void) { return (int64_t)GetTickCount64(); }
#else
static pthread_mutex_t heff_st_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t heff_st_cv = PTHREAD_COND_INITIALIZER;
static pthread_t heff_st_thread;
static void heff_st_lock(void) { pthread_mutex_lock(&heff_st_mu); }
static void heff_st_unlock(void) { pthread_mutex_unlock(&heff_st_mu); }
static void heff_st_wait(int ms) {
  struct timespec t;
  clock_gettime(CLOCK_REALTIME, &t);
  t.tv_nsec += (long)ms * 1000000L;
  t.tv_sec += t.tv_nsec / 1000000000L;
  t.tv_nsec %= 1000000000L;
  pthread_cond_timedwait(&heff_st_cv, &heff_st_mu, &t);
}
static void heff_st_wake(void) { pthread_cond_broadcast(&heff_st_cv); }
static int64_t heff_st_now(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}
#endif

// (the newest lines given, `heff_st_n` of them; how many are on the
// terminal now; whether they are not those; since when lines have been
// given, nothing drawn before; whether the thread draws; whether the
// program is ending)
static char **heff_st_lines = NULL;
static int heff_st_n = 0, heff_st_drawn = 0, heff_st_dirty = 0;
static int64_t heff_st_since = 0;
static int heff_st_going = 0, heff_st_over = 0;

// (lines are drawn where the standard error is a terminal and `TERM` is
// not `dumb`; on Windows, a console that takes escape sequences: 1, 0,
// or -1 not asked yet)
static int heff_st_tty = -1;

static int heff_st_terminal(void) {
  if (heff_st_tty >= 0) return heff_st_tty;
  const char *term = getenv("TERM");
  int ok = !(term && strcmp(term, "dumb") == 0);
#ifdef _WIN32
  DWORD mode;
  HANDLE h = GetStdHandle(STD_ERROR_HANDLE);
  ok = ok && _isatty(2) && GetConsoleMode(h, &mode)
    && ((mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING) || SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING));
#else
  ok = ok && isatty(2);
#endif
  heff_st_tty = ok;
  return ok;
}

// (the terminal's columns and rows: 80 by 25 if it does not say)
static void heff_st_size(int *cols, int *rows) {
  *cols = 80;
  *rows = 25;
#ifdef _WIN32
  CONSOLE_SCREEN_BUFFER_INFO info;
  if (GetConsoleScreenBufferInfo(GetStdHandle(STD_ERROR_HANDLE), &info)) {
    *cols = info.srWindow.Right - info.srWindow.Left + 1;
    *rows = info.srWindow.Bottom - info.srWindow.Top + 1;
  }
#else
  struct winsize w;
  if (ioctl(2, TIOCGWINSZ, &w) == 0 && w.ws_col > 0 && w.ws_row > 0) {
    *cols = w.ws_col;
    *rows = w.ws_row;
  }
#endif
}

// (how many columns a character takes: two, East Asian wide ones, else
// one)
static int heff_st_width(uint32_t u) {
  return (u >= 0x1100 && u <= 0x115F) || (u >= 0x2E80 && u <= 0xA4CF) || (u >= 0xAC00 && u <= 0xD7A3)
    || (u >= 0xF900 && u <= 0xFAFF) || (u >= 0xFE30 && u <= 0xFE4F) || (u >= 0xFF00 && u <= 0xFF60)
    || (u >= 0xFFE0 && u <= 0xFFE6) || (u >= 0x1F300 && u <= 0x1F64F) || (u >= 0x1F900 && u <= 0x1F9FF)
    || (u >= 0x20000 && u <= 0x3FFFD) ? 2 : 1;
}

// (a line, UTF-8, as much of it as fits in `width` columns)
static void heff_st_cut(Buf *b, const char *s, int width) {
  int w = 0;
  const unsigned char *p = (const unsigned char *)s;
  while (*p) {
    int len = *p < 0x80 ? 1 : *p < 0xE0 ? 2 : *p < 0xF0 ? 3 : 4;
    uint32_t u = len == 1 ? *p : len == 2 ? *p & 0x1F : len == 3 ? *p & 0x0F : *p & 0x07;
    for (int i = 1; i < len; i++) {
      if ((p[i] & 0xC0) != 0x80) { len = i; break; }
      u = (u << 6) | (p[i] & 0x3F);
    }
    int cw = heff_st_width(u);
    if (w + cw > width) break;
    buf_put(b, (const char *)p, (size_t)len);
    w += cw;
    p += len;
  }
}

// (what is drawn cleared: the cursor is where it starts)
static void heff_st_clear(void) {
  if (heff_st_drawn == 0) return;
  fputs("\x1b[J", stderr);
  fflush(stderr);
  heff_st_drawn = 0;
  heff_st_dirty = heff_st_n > 0;
}

// (the newest lines drawn in place of what was, at once -- the cursor
// back where they start -- as one write, the terminal told to show it
// whole: the lock held)
static void heff_st_draw(void) {
  int cols, rows;
  heff_st_size(&cols, &rows);
  Buf b = {0};
  buf_str(&b, "\x1b[?2026h\x1b[J");
  int n = 0;
  for (; n < heff_st_n && n + 2 < rows; n++) {
    // (a column short of the width: a line that fills it wraps on some)
    heff_st_cut(&b, heff_st_lines[n], cols - 1);
#ifdef _WIN32
    buf_str(&b, "\r\n");
#else
    buf_str(&b, "\n");
#endif
  }
  if (n > 0) {
    buf_str(&b, "\r");
    for (int i = 0; i < n; i++) buf_str(&b, "\x1bM");
  }
  buf_str(&b, "\x1b[?2026l");
  fwrite(b.s, 1, b.n, stderr);
  fflush(stderr);
  free(b.s);
  heff_st_drawn = n;
  heff_st_dirty = 0;
}

#ifdef _WIN32
static DWORD WINAPI heff_st_loop(LPVOID u) {
#else
static void *heff_st_loop(void *u) {
#endif
  (void)u;
  heff_st_lock();
  while (heff_st_going) {
    heff_st_wait(80);
    if (heff_st_going && heff_st_dirty && heff_st_now() - heff_st_since >= 200) heff_st_draw();
  }
  heff_st_unlock();
  return 0;
}

static void heff_st_free(void) {
  for (int i = 0; i < heff_st_n; i++) free(heff_st_lines[i]);
  free(heff_st_lines);
  heff_st_lines = NULL;
  heff_st_n = 0;
}

// (what the streams' providers call: see `heff_lines`)
static void heff_st_hold(int what) {
  if (what == 0) {
    // (what was written out before the lines come back)
    if (heff_st_n > 0) fflush(stdout);
    heff_st_unlock();
    return;
  }
  heff_st_lock();
  heff_st_clear();
  if (what == 2) {
    heff_st_over = 1;
    heff_st_going = 0;
    heff_st_free();
    heff_st_wake();
    heff_st_unlock();
  }
}

static void heff_st_atexit(void) {
  if (heff_lines) heff_lines(2);
}

// (the lines given are those there are: the lock held)
static int heff_st_same(char **lines, int n) {
  if (n != heff_st_n) return 0;
  for (int i = 0; i < n; i++)
    if (strcmp(lines[i], heff_st_lines[i]) != 0) return 0;
  return 1;
}

// (the lines `l`, a list of strings, drawn from now on, unless they are
// those there are; none: nothing drawn, what was cleared at once.  The
// thread, once started, draws until the program ends: lines that come
// again later are drawn at its next turn, not after 200 ms -- zig waits
// once, too)
static void heff_st_show(V l) {
  if (!heff_st_terminal() || heff_st_over) return;
  int n = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) n++;
  char **lines = heff_alloc((size_t)(n ? n : 1) * sizeof(char *));
  int i = 0;
  for (V c = l; heff_tag_of(c) == TAG_Cons; c = heff_field(c, 1)) lines[i++] = heff_cstr(heff_field(c, 0));
  heff_st_lock();
  if (heff_st_same(lines, n)) {
    heff_st_unlock();
    for (i = 0; i < n; i++) free(lines[i]);
    free(lines);
    return;
  }
  heff_st_free();
  heff_st_lines = lines;
  heff_st_n = n;
  heff_st_dirty = n > 0;
  if (n == 0) heff_st_clear();
  else if (!heff_st_going) {
    static int registered = 0;
    if (!registered) { registered = 1; atexit(heff_st_atexit); }
    heff_lines = heff_st_hold;
    heff_st_going = 1;
    heff_st_since = heff_st_now();
#ifdef _WIN32
    heff_st_thread = CreateThread(NULL, 0, heff_st_loop, NULL, 0, NULL);
    if (!heff_st_thread) heff_st_going = 0;
#else
    if (pthread_create(&heff_st_thread, NULL, heff_st_loop, NULL) != 0) heff_st_going = 0;
#endif
  }
  heff_st_unlock();
}

static uint32_t heff_st_ran_shape[3] = { LBL_status, LBL_out, LBL_err };

#ifndef _WIN32
// (a packet of zig's, the tasks of its tree, as a list of `MkKid`s)
static V heff_st_kids(const unsigned char *pk) {
  int n = pk[0];
  V l = NTAG(TAG_Nil);
  for (int i = n - 1; i >= 0; i--) {
    const unsigned char *s = pk + 1 + i * 128;
    uint32_t done = (uint32_t)s[0] | (uint32_t)s[1] << 8 | (uint32_t)s[2] << 16 | (uint32_t)s[3] << 24;
    uint32_t total = (uint32_t)s[4] | (uint32_t)s[5] << 8 | (uint32_t)s[6] << 16 | (uint32_t)s[7] << 24;
    char name[121];
    memcpy(name, s + 8, 120);
    name[120] = 0;
    V f[4] = { heff_str_c(name), MK_INT(done), MK_INT(total == 0xFFFFFFFFu ? 0 : total), MK_INT(pk[1 + n * 128 + i]) };
    l = heff_cons(heff_tag(TAG_MkKid, 4, f), l);
  }
  return l;
}

// (what the command has said of its progress, read: each whole packet
// taken, the newest one's tree given to `f`, whose lines are drawn)
static void heff_st_packets(Buf *pb, V f) {
  size_t at = 0, newest = (size_t)-1;
  while (pb->n - at >= 1) {
    size_t len = 1 + (size_t)(unsigned char)pb->s[at] * 129;
    if (pb->n - at < len) break;
    newest = at;
    at += len;
  }
  if (newest != (size_t)-1) {
    V lines = heff_tr(heff_app1(heff_dup(f), heff_st_kids((const unsigned char *)pb->s + newest)));
    heff_st_show(lines);
    heff_drop(lines);
  }
  memmove(pb->s, pb->s + at, pb->n - at);
  pb->n -= at;
}

extern char **environ;

// (the command `as` run as runtime.c's heff_capture runs it, with
// `ZIG_PROGRESS`, its progress drawn by `f` as it comes)
static int64_t heff_st_capture(char **as, Buf *bo, Buf *be, V f) {
  int64_t status = -1;
  int po[2], pe[2], pp[2];
  if (pipe(po) != 0) return -1;
  if (pipe(pe) != 0) { close(po[0]); close(po[1]); return -1; }
  if (pipe(pp) != 0) { close(po[0]); close(po[1]); close(pe[0]); close(pe[1]); return -1; }
  // (the environment, its ZIG_PROGRESS the pipe's end)
  int ne = 0;
  while (environ[ne]) ne++;
  char **env = heff_alloc((size_t)(ne + 2) * sizeof(char *));
  int k = 0;
  for (int i = 0; i < ne; i++)
    if (strncmp(environ[i], "ZIG_PROGRESS=", 13) != 0) env[k++] = environ[i];
  char zp[32];
  snprintf(zp, sizeof zp, "ZIG_PROGRESS=%d", pp[1]);
  env[k++] = zp;
  env[k] = NULL;
  posix_spawn_file_actions_t fa;
  posix_spawn_file_actions_init(&fa);
  posix_spawn_file_actions_adddup2(&fa, po[1], 1);
  posix_spawn_file_actions_adddup2(&fa, pe[1], 2);
  posix_spawn_file_actions_addclose(&fa, po[0]);
  posix_spawn_file_actions_addclose(&fa, pe[0]);
  posix_spawn_file_actions_addclose(&fa, pp[0]);
  pid_t pid;
  int ok = posix_spawnp(&pid, as[0], &fa, NULL, as, env) == 0;
  posix_spawn_file_actions_destroy(&fa);
  free(env);
  close(po[1]);
  close(pe[1]);
  close(pp[1]);
  // (its streams and its progress read together, until all are closed)
  struct pollfd fds[3] = { { po[0], POLLIN, 0 }, { pe[0], POLLIN, 0 }, { pp[0], POLLIN, 0 } };
  Buf pb = {0};
  int open = 3;
  char chunk[65536];
  while (open > 0) {
    if (poll(fds, 3, -1) < 0) break;
    for (int i = 0; i < 3; i++) {
      if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP))) continue;
      ssize_t got = read(fds[i].fd, chunk, sizeof chunk);
      if (got <= 0) { close(fds[i].fd); fds[i].fd = -1; open--; }
      else if (i == 2) { buf_put(&pb, chunk, (size_t)got); heff_st_packets(&pb, f); }
      else buf_put(i == 0 ? bo : be, chunk, (size_t)got);
    }
  }
  free(pb.s);
  if (ok) {
    int st;
    if (waitpid(pid, &st, 0) >= 0 && WIFEXITED(st)) status = WEXITSTATUS(st);
  }
  return status;
}
#endif

static V heff_provider_terminal(V p, V k) {
  switch (heff_tag_of(p)) {
  case TAG_IsTerminal: {
    V f = heff_dup(heff_field(p, 0));
    heff_drop(p);
    V x = heff_answer(f, heff_bool(heff_st_terminal()));
    return heff_tail(k, 1, &x);
  }
  case TAG_ShowLines: {
    heff_st_show(heff_field(p, 0));
    V x = heff_dup(heff_field(p, 1));
    heff_drop(p);
    return heff_tail(k, 1, &x);
  }
  case TAG_ShowRun: {
    char *c = heff_cstr(heff_field(p, 0));
    int64_t n = 0;
    for (V l = heff_field(p, 1); heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) n++;
    char **as = heff_alloc((size_t)(n + 2) * sizeof(char *));
    as[0] = c;
    int64_t i = 1;
    for (V l = heff_field(p, 1); heff_tag_of(l) == TAG_Cons; l = heff_field(l, 1)) as[i++] = heff_cstr(heff_field(l, 0));
    as[i] = NULL;
    V f = heff_dup(heff_field(p, 2)), r = heff_dup(heff_field(p, 3));
    heff_drop(p);
    Buf bo = {0}, be = {0};
#ifdef _WIN32
    int64_t status = heff_capture(as, &bo, &be);
#else
    int64_t status = heff_st_terminal() && !heff_st_over ? heff_st_capture(as, &bo, &be, f) : heff_capture(as, &bo, &be);
#endif
    heff_drop(f);
    for (int64_t j = 0; j < i; j++) free(as[j]);
    free(as);
    V fs[3] = {
      MK_INT(status),
      heff_str_utf8((const unsigned char *)(bo.s ? bo.s : ""), (int64_t)bo.n),
      heff_str_utf8((const unsigned char *)(be.s ? be.s : ""), (int64_t)be.n),
    };
    free(bo.s);
    free(be.s);
    V x = heff_answer(r, heff_rec(3, heff_st_ran_shape, fs));
    return heff_tail(k, 1, &x);
  }
  default:
    heff_fail("not an operation of terminal");
    return 0;
  }
}

static V heff_perform_5(V p, V k) { return heff_provider_stdio(p, k); }
static V heff_perform_6(V p, V k) { return heff_provider_process(p, k); }
static V heff_perform_4(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_5(q, k) : heff_perform_6(q, k); }
static V heff_perform_7(V p, V k) { return heff_provider_fs(p, k); }
static V heff_perform_3(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_4(q, k) : heff_perform_7(q, k); }
static V heff_perform_8(V p, V k) { return heff_provider_report(p, k); }
static V heff_perform_2(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_3(q, k) : heff_perform_8(q, k); }
static V heff_perform_9(V p, V k) { return heff_provider_rpc(p, k); }
static V heff_perform_1(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_2(q, k) : heff_perform_9(q, k); }
static V heff_perform_10(V p, V k) { return heff_provider_terminal(p, k); }
static V heff_perform_0(V p, V k) { int l = heff_tag_of(p) == TAG_InL; V q = heff_dup(heff_field(p, 0)); heff_drop(p); return l ? heff_perform_1(q, k) : heff_perform_10(q, k); }
V heff_perform(V p, V k) { return heff_perform_0(p, k); }

static V heff_entry(void) { return g_run_24entry_get(); }
