// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
HEFF_LIT(g_prelude_2einstanceShowString_2eescapedFrom_241_str0, 2, "\\\"");
HEFF_LIT(g_prelude_2einstanceShowString_2eescapedFrom_241_str1, 2, "\\\\");
HEFF_LIT(g_prelude_2einstanceShowString_2eescapedFrom_241_str2, 2, "\\n");
Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceShowString_2eescapedFrom_241_entry, 3, 0};

V g_prelude_2einstanceShowString_2eescapedFrom_241(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_243;
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
      v_t_243 = ((V)&g_prelude_2einstanceShowString_2eescapedFrom_241_str0);
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)92ULL))) {
        v_t_243 = ((V)&g_prelude_2einstanceShowString_2eescapedFrom_241_str1);
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)10ULL))) {
          v_t_243 = ((V)&g_prelude_2einstanceShowString_2eescapedFrom_241_str2);
        } else {
          v_t_243 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))));
        }
      }
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_243);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2einstanceShowString_2eescapedFrom_241(a0, a[1], a[2]); heff_drop(a0); return r;
}