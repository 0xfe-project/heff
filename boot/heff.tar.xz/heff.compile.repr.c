// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IAny 21222
#define TAG_IBind 27068
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_RetAs 20415
#define TAG_RetClass 33382
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_args 9498020
#define LBL_big 307066
#define LBL_boxedIn 304670893
#define LBL_boxedOut 854869195
#define LBL_fixed 298804110
#define LBL_flat 9641024
#define LBL_kept 9783717
#define LBL_op 10312
#define LBL_params 951713969
#define LBL_pinned 958995203
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_sigs 10025609
#define LBL_unboxedIn 1261597312
#define LBL_unboxedOut 454817126
static uint32_t shape_args__result[] = {LBL_args, LBL_result};
static uint32_t shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big[] = {LBL_reprs, LBL_boxedIn, LBL_unboxedIn, LBL_boxedOut, LBL_unboxedOut, LBL_pinned, LBL_kept, LBL_big};
V g_heff_2ecompile_2eranges_2ewordPrims_get(void);
V g_heff_2ecompile_2erepr_2edecideOf(V, V);
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecideOf_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2edefEvents(V, V);
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edefEvents_clo;
V g_heff_2ecompile_2erepr_2eelemS(V, V);
V g_heff_2ecompile_2erepr_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eelemS_clo;
V g_heff_2ecompile_2erepr_2eentered(V, V);
V g_heff_2ecompile_2erepr_2eentered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eentered_clo;
V g_heff_2ecompile_2erepr_2efloat1Prims_get(void);
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void);
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void);
HeffT2 g_heff_2ecompile_2erepr_2efloatShape_24cpr(V);
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2efreeGo(V, V, V);
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efreeGo_clo;
V g_heff_2ecompile_2erepr_2ehope(V);
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ehope_clo;
HeffT2 g_heff_2ecompile_2erepr_2ehopeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL(V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eindexOfL_clo;
V g_heff_2ecompile_2erepr_2ekeptOne(V, V, V, V);
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ekeptOne_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V, V);
V g_heff_2ecompile_2erepr_2epinFields(V, V, V);
V g_heff_2ecompile_2erepr_2epinFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2epinFields_clo;
V g_heff_2ecompile_2erepr_2eprimShape(V);
V g_heff_2ecompile_2erepr_2eprimShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eprimShape_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
HeffT2 g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2epushElement(V, V, V, V);
V g_heff_2ecompile_2erepr_2epushElement_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2epushElement_clo;
V g_heff_2ecompile_2erepr_2ereadRepr(V, V);
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereadRepr_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprOfName(V);
V g_heff_2ecompile_2erepr_2ereprOfName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprOfName_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2erepr_2ereprsWords(V, V, V);
V g_heff_2ecompile_2erepr_2ereprsWords_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsWords_clo;
V g_heff_2ecompile_2erepr_2eretName_get(void);
V g_heff_2ecompile_2erepr_2ereturned(V, V, V);
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereturned_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2eseen(V, V);
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eseen_clo;
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2esourceOf(V, V);
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esourceOf_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2estatsWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erepr_2estatsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsWith_clo;
V g_heff_2ecompile_2erepr_2estepGives(V, V, V);
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estepGives_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erepr_2ewalk(V, V, V);
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewalk_clo;
V g_heff_2ecompile_2erepr_2ewithRepr(V, V);
V g_heff_2ecompile_2erepr_2ewithRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewithRepr_clo;
V g_heff_2ecompile_2erepr_2ewordEvents(V, V, V);
V g_heff_2ecompile_2erepr_2ewordEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewordEvents_clo;
V g_heff_2ecompile_2erepr_2ewordParams(V, V);
V g_heff_2ecompile_2erepr_2ewordParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewordParams_clo;
HeffT2 g_heff_2ecompile_2erepr_2ewordShape_24cpr(V);
V g_heff_2eelab_2efixed_2eallFixed_get(void);
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_list_2eany_24s100684943x1504448948(V, V);
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a);
extern Clo g_list_2eany_24s100684943x1504448948_clo;
V g_list_2eany_24s1080008383x1763122651(V, V);
V g_list_2eany_24s1080008383x1763122651_entry(V self, V *a);
extern Clo g_list_2eany_24s1080008383x1763122651_clo;
V g_list_2eany_24s120814613x1439363162(V, V);
V g_list_2eany_24s120814613x1439363162_entry(V self, V *a);
extern Clo g_list_2eany_24s120814613x1439363162_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1070132730x1847213213(V, V);
V g_list_2efoldl_24f1070132730x1847213213_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1070132730x1847213213_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24f488322910x556193579(V, V, V);
V g_list_2efoldl_24f488322910x556193579_entry(V self, V *a);
extern Clo g_list_2efoldl_24f488322910x556193579_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1674844076x2137676876(V, V, V, V);
V g_list_2efoldl_24s1674844076x2137676876_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1674844076x2137676876_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s29004368x870998936(V, V);
V g_list_2efoldl_24s29004368x870998936_entry(V self, V *a);
extern Clo g_list_2efoldl_24s29004368x870998936_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s512987356x688045438(V, V);
V g_list_2efoldl_24s512987356x688045438_entry(V self, V *a);
extern Clo g_list_2efoldl_24s512987356x688045438_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s728686882x2096535788(V, V, V);
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a);
extern Clo g_list_2efoldl_24s728686882x2096535788_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1310249268x749995235(V, V, V);
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
HeffT2 g_map_2elookup_24s1546226666x2146984184_24cpr(V, V);
HeffT2 g_map_2elookup_24s659669741x1036301430_24cpr(V, V);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f714167978x1237207677(V, V, V, V);
V g_prelude_2e_2b_2b_24f714167978x1237207677_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f714167978x1237207677_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str8, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str9, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str10, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str11, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str12, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str13, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str14, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str15, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str16, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str17, 7, "Float32");
Clo g_heff_2ecompile_2erepr_2ereprEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RepV: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_True);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepFix: {
    V v_a_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_t_245;
      switch (heff_tag_of(v_a_243)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str0);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str1);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str2);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str3);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str4);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str5);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str6);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str7);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str8);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      V v_t_246;
      switch (heff_tag_of(v_b_244)) {
      case TAG_I8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str9);
        break;
      }
      case TAG_I16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str10);
        break;
      }
      case TAG_I32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str11);
        break;
      }
      case TAG_I64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str12);
        break;
      }
      case TAG_U8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str13);
        break;
      }
      case TAG_U16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str14);
        break;
      }
      case TAG_U32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str15);
        break;
      }
      case TAG_U64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str16);
        break;
      }
      case TAG_F32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str17);
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      return heff_strEq(v_t_245, v_t_246);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepF64: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepInt: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str3, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str4, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str5, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str6, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str11, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str13, 3, "Int");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str14, 2, "->");
Clo g_heff_2ecompile_2erepr_2esigName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esigName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2esigName(V v_s_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s2090270526x1588636862(heff_take_field(v_s_240, 0)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ecompile_2erepr_2esigName_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ecompile_2erepr_2esigName_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_t_245 = heff_get_n(v_s_240, 1, 2);
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_RepV: {
    v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str2);
    break;
  }
  case TAG_RepFix: {
    V v_w_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_w_246)) {
    case TAG_I8: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str3);
      break;
    }
    case TAG_I16: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str4);
      break;
    }
    case TAG_I32: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str5);
      break;
    }
    case TAG_I64: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str6);
      break;
    }
    case TAG_U8: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str7);
      break;
    }
    case TAG_U16: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str8);
      break;
    }
    case TAG_U32: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str9);
      break;
    }
    case TAG_U64: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str10);
      break;
    }
    case TAG_F32: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str11);
      break;
    }
    default: heff_nomatch(v_w_246);
    }
    break;
  }
  case TAG_RepF64: {
    v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str12);
    break;
  }
  case TAG_RepInt: {
    v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str13);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2erepr_2esigName_str14), v_t_247));
}
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esigName(a[0]);
}
Clo g_heff_2ecompile_2erepr_2ereprsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2erepr_2ereprEq(v_a_244, v_b_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_242}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  }
  case TAG_OpSub: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_245 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_244}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_245}});
  }
  case TAG_OpMul: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_246}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
  }
  case TAG_OpDiv: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_249 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_248}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_OpRem: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2410}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
  }
  case TAG_OpEq: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2412}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2413}});
  }
  case TAG_OpLt: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2414}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
  }
  case TAG_OpLe: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2416}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
  }
  case TAG_OpAnd: {
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2419 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2418}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
  }
  case TAG_OpOr: {
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2420}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
  }
  case TAG_OpXor: {
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2423 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2422}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2423}});
  }
  case TAG_OpShl: {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2425 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2424}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2425}});
  }
  case TAG_OpShr: {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2427 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2426}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
  }
  case TAG_OpShow: {
    heff_drop(v_r_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpFromInt: {
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2428, v_r_240})}});
  }
  case TAG_OpToInt: {
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2430 = heff_rec_n(2, shape_args__result, (V[]){v_t_2429, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2430}});
  }
  case TAG_OpSqrt: {
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2431, v_r_240})}});
  }
  case TAG_OpFromFloat: {
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2432, v_r_240})}});
  }
  case TAG_OpToFloat: {
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2434 = heff_rec_n(2, shape_args__result, (V[]){v_t_2433, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2434}});
  }
  case TAG_OpFloor: {
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2436 = heff_rec_n(2, shape_args__result, (V[]){v_t_2435, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2436}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2erepr_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2eelemS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2eelemS(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str0, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str1, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str2, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str3, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str4, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str5, 8, "floatAdd");

static V g_heff_2ecompile_2erepr_2efloat2Prims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloat2Prims_st;
static V g_heff_2ecompile_2erepr_2efloat2Prims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str4), v_t_241})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str5), v_t_242});
}
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloat2Prims_st)) return g_heff_2ecompile_2erepr_2efloat2Prims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloat2Prims_val, &g_heff_2ecompile_2erepr_2efloat2Prims_st, g_heff_2ecompile_2erepr_2efloat2Prims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str0, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str1, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str2, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str3, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str4, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str5, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str6, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str7, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str8, 8, "floatSin");

static V g_heff_2ecompile_2erepr_2efloat1Prims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloat1Prims_st;
static V g_heff_2ecompile_2erepr_2efloat1Prims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str6), v_t_242})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str8), v_t_243})});
}
V g_heff_2ecompile_2erepr_2efloat1Prims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloat1Prims_st)) return g_heff_2ecompile_2erepr_2efloat1Prims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloat1Prims_val, &g_heff_2ecompile_2erepr_2efloat1Prims_st, g_heff_2ecompile_2erepr_2efloat1Prims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str0, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str1, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str2, 7, "floatLt");

static V g_heff_2ecompile_2erepr_2efloatRelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloatRelPrims_st;
static V g_heff_2ecompile_2erepr_2efloatRelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str2), v_t_240})});
}
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloatRelPrims_st)) return g_heff_2ecompile_2erepr_2efloatRelPrims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloatRelPrims_val, &g_heff_2ecompile_2erepr_2efloatRelPrims_st, g_heff_2ecompile_2erepr_2efloatRelPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatShape_24cpr_str0, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatShape_24cpr_str1, 10, "floatFloor");

HeffT2 g_heff_2ecompile_2erepr_2efloatShape_24cpr(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloat2Prims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_p_240);
    heff_drop(v_t_241);
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_242});
    V v_t_244 = heff_rec_n(2, shape_args__result, (V[]){v_t_243, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    heff_drop(v_t_241);
    V v_t_245 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloat1Prims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_245);
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
      V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){v_t_246, NTAG(TAG_RepF64)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
    } else {
      heff_drop(v_t_245);
      V v_t_248 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloatRelPrims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_t_248);
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_249});
        V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){v_t_2410, NTAG(TAG_RepV)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
      } else {
        heff_drop(v_t_248);
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2efloatShape_24cpr_str0), 2)) {
          heff_drop(v_p_240);
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
          V v_t_2414 = heff_rec_n(2, shape_args__result, (V[]){v_t_2413, NTAG(TAG_RepF64)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
        } else {
          if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2erepr_2efloatShape_24cpr_str1))) {
            V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
            V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){v_t_2416, NTAG(TAG_RepV)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str0, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str1, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str2, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewordShape_24cpr_str3, 11, "wordToFloat");

HeffT2 g_heff_2ecompile_2erepr_2ewordShape_24cpr(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str0), 2)) {
    heff_drop(v_p_240);
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_242});
    V v_t_244 = heff_rec_n(2, shape_args__result, (V[]){v_t_243, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_244}});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str1), 2)) {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_246});
      V v_t_248 = heff_rec_n(2, shape_args__result, (V[]){v_t_247, NTAG(TAG_RepV)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_248}});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str2), 2)) {
        heff_drop(v_p_240);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2410});
        V v_t_2412 = heff_rec_n(2, shape_args__result, (V[]){v_t_2411, NTAG(TAG_RepV)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
      } else {
        if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2erepr_2ewordShape_24cpr_str3))) {
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
          V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){v_t_2414, NTAG(TAG_RepF64)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
        } else {
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2416});
          V v_t_2418 = heff_rec_n(2, shape_args__result, (V[]){v_t_2417, NTAG(TAG_RepInt)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2418}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2erepr_2eprimShape_24cpr_str0, 4, "word");

HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V v_p_240) {
top: ;
  if ((((int64_t)4ULL) < heff_unbox_word(heff_strLength_lent(v_p_240, 0)))) {
    if (heff_strEq_c(heff_strSlice_lent(v_p_240, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ecompile_2erepr_2eprimShape_24cpr_str0))) {
      V v_t_243 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2eranges_2ewordPrims_get()); V r_ = (g_list_2eany_24s1230506745x754542351(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
        heff_drop(v_t_243);
        HEFF_LAST return g_heff_2ecompile_2erepr_2ewordShape_24cpr(v_p_240);
      } else {
        heff_drop(v_t_243);
        HeffT2 v_t_244 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(heff_dup(v_p_240)));
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            heff_drop(v_p_240);
            V v_fp_248 = v_field_246;
            V v_t_249 = heff_tag_n(TAG_RepFix, 1, (V[]){heff_take_field(v_fp_248, 0)});
            return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_fp_248, 1, 2); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eopShape_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
          } else {
            heff_drop(v_field_246);
            HEFF_LAST return g_heff_2ecompile_2erepr_2efloatShape_24cpr(v_p_240);
          }
        }
      }
    } else {
      HeffT2 v_t_2410 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(heff_dup(v_p_240)));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_p_240);
          V v_fp_2414 = v_field_2412;
          V v_t_2415 = heff_tag_n(TAG_RepFix, 1, (V[]){heff_take_field(v_fp_2414, 0)});
          return ({ V a_0 = v_t_2415; V b_1 = heff_get_n(v_fp_2414, 1, 2); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eopShape_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        } else {
          heff_drop(v_field_2412);
          HEFF_LAST return g_heff_2ecompile_2erepr_2efloatShape_24cpr(v_p_240);
        }
      }
    }
  } else {
    HeffT2 v_t_2416 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(heff_dup(v_p_240)));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_p_240);
        V v_fp_2420 = v_field_2418;
        V v_t_2421 = heff_tag_n(TAG_RepFix, 1, (V[]){heff_take_field(v_fp_2420, 0)});
        return ({ V a_0 = v_t_2421; V b_1 = heff_get_n(v_fp_2420, 1, 2); HeffT2 r_ = (g_heff_2ecompile_2erepr_2eopShape_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      } else {
        heff_drop(v_field_2418);
        HEFF_LAST return g_heff_2ecompile_2erepr_2efloatShape_24cpr(v_p_240);
      }
    }
  }
}
Clo g_heff_2ecompile_2erepr_2eprimShape_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eprimShape_entry, 1, 0};

V g_heff_2ecompile_2erepr_2eprimShape(V v_p_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erepr_2eprimShape_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eprimShape(a[0]);
}
Clo g_heff_2ecompile_2erepr_2eslotRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eslotRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eslotRepr(V v_i_240, V v_t_241) {
top: ;
  if (heff_intLt_c(v_i_240, MK_INT(16LL))) {
    switch (heff_tag_of(v_t_241)) {
    case TAG_FtFloat: {
      return NTAG(TAG_RepF64);
    }
    case TAG_FtFixed: {
      V v_w_243 = heff_field(v_t_241, 0);
      V v_ru_24t_241_24FtFixed = heff_take_reuse_n(v_t_241, 1ULL, 1);
      int64_t v_t_244;
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_244 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_244 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_244 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_244 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_244 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_244 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      if ((v_t_244 == ((int64_t)64ULL))) {
        return heff_tag_at_n(v_ru_24t_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_243});
      } else {
        heff_drop(v_w_243);
        heff_drop_cell(v_ru_24t_241_24FtFixed, 1);
        return NTAG(TAG_RepV);
      }
    }
    case TAG_FtOther: {
      return NTAG(TAG_RepV);
    }
    case TAG_FtAny: {
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_t_241);
    }
  } else {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
}
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eslotRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2emayBeFlat_entry, 1, 0};

V g_heff_2ecompile_2erepr_2emayBeFlat(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_FtFloat: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_241 = heff_field(v_t_240, 0);
      int64_t v_t_242;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_242 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_242 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_242 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_242 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_242 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_242 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_ret_24bool = heff_bool((v_t_242 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtFixed: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_245 = heff_field(v_t_240, 0);
      int64_t v_t_246;
      switch (heff_tag_of(v_w_245)) {
      case TAG_I8: {
        v_t_246 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_246 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_246 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_246 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_246 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_246 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_246 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_246 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_246 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_245);
      }
      V v_ret_24bool = heff_bool((v_t_246 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtOther: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_248 = heff_field(v_t_240, 0);
      int64_t v_t_249;
      switch (heff_tag_of(v_w_248)) {
      case TAG_I8: {
        v_t_249 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_249 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_249 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_249 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_249 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_249 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_249 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_249 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_249 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_248);
      }
      V v_ret_24bool = heff_bool((v_t_249 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtAny: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2emayBeFlat(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2ereadRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereadRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereadRepr(V v_x1_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
  case TAG_Just: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(v_i_242, MK_INT(16LL))) {
      switch (heff_tag_of(v_t_241)) {
      case TAG_FtFloat: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepF64);
      }
      case TAG_FtFixed: {
        V v_w_244 = heff_field(v_t_241, 0);
        heff_take_n(v_t_241, 1ULL, 1);
        int64_t v_t_245;
        switch (heff_tag_of(v_w_244)) {
        case TAG_I8: {
          v_t_245 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_245 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_245 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_245 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_245 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_245 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_245 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_245 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_245 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_244);
        }
        if ((v_t_245 == ((int64_t)64ULL))) {
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_RepFix, 1, (V[]){v_w_244});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          heff_drop(v_w_244);
          return NTAG(TAG_RepV);
        }
      }
      case TAG_FtOther: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      case TAG_FtAny: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      default: return heff_nomatch(v_t_241);
      }
    } else {
      heff_drop(v_t_241);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return NTAG(TAG_RepV);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereadRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2efourTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efourTo_entry, 1, 0};

V g_heff_2ecompile_2erepr_2efourTo(V v_i_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
    heff_drop(v_i_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2erepr_2efourTo(heff_intSub(v_i_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(4LL), v_t_242);
  }
}
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efourTo(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str1, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str2, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str3, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str4, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str5, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str6, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str7, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str8, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str9, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprOfName_str10, 7, "Float32");
Clo g_heff_2ecompile_2erepr_2ereprOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprOfName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ereprOfName(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str0), 2)) {
    heff_drop(v_x_240);
    return NTAG(TAG_RepV);
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str1), 2)) {
      heff_drop(v_x_240);
      return NTAG(TAG_RepF64);
    } else {
      HeffT2 v_t_243 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2ecompile_2erepr_2ereprOfName_str2), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str3), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str4), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str5), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str6), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str7), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str8), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str9), ((V)&g_heff_2ecompile_2erepr_2ereprOfName_str10), v_x_240, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
      {
        V v_field_245 = v_t_243.f[1];
        int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          V v_x_247 = v_field_245;
          return heff_tag_n(TAG_RepFix, 1, (V[]){v_x_247});
        } else {
          heff_drop(v_field_245);
          return NTAG(TAG_RepV);
        }
      }
    }
  }
}
V g_heff_2ecompile_2erepr_2ereprOfName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereprOfName(a[0]);
}
Clo g_heff_2ecompile_2erepr_2etyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2etyIn_entry, 2, 0};

V g_heff_2ecompile_2erepr_2etyIn(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_FtAny);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_dup(v_t_242);
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_ts_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2etyIn(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2eretName_str0, 4, "$ret");

static V g_heff_2ecompile_2erepr_2eretName_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2eretName_st;
static V g_heff_2ecompile_2erepr_2eretName_init(void) {
  return ((V)&g_heff_2ecompile_2erepr_2eretName_str0);
}
V g_heff_2ecompile_2erepr_2eretName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2eretName_st)) return g_heff_2ecompile_2erepr_2eretName_val;
  return heff_global(&g_heff_2ecompile_2erepr_2eretName_val, &g_heff_2ecompile_2erepr_2eretName_st, g_heff_2ecompile_2erepr_2eretName_init);
}
Clo g_heff_2ecompile_2erepr_2epushElement_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2epushElement_entry, 4, 0};

V g_heff_2ecompile_2erepr_2epushElement(V v_x1_240, V v_rs_241, V v_vs_242, V v_rest_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_241, v_vs_242));
    return (g_list_2efoldl_24s1690891682x1517899652(v_rest_243, v_t_244));
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_x1_240, 0);
    V v_t_246 = (g_list_2ezipWith_24s1876717925x1404326288(v_rs_241, heff_dup(v_vs_242)));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_242); r_; });
    V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
    HEFF_LAST return g_prelude_2e_2b_2b_24f714167978x1237207677(v_rest_243, heff_dup(v_e_245), v_t_246, v_t_248);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2epushElement_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2epushElement(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2estepGives_str0, 10, "arrayIndex");
Clo g_heff_2ecompile_2erepr_2estepGives_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estepGives_entry, 3, 0};

V g_heff_2ecompile_2erepr_2estepGives(V v_x_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_ru_24o_241_24OSimple = heff_take_reuse_n(v_o_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24o_241_24OSimple, TAG_Boxed, 1, (V[]){v_x_240}), v_acc_242});
  }
  case TAG_OCall: {
    V v_ru_24o_241_24OCall = heff_take_reuse_n(v_o_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24o_241_24OCall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240}), v_acc_242});
  }
  case TAG_OApply: {
    V v_ru_24o_241_24OApply = heff_take_reuse_n(v_o_241, 0ULL, 2);
    return heff_tag_at_n(v_ru_24o_241_24OApply, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240}), v_acc_242});
  }
  case TAG_OPrim: {
    V v_p_248 = heff_field(v_o_241, 0);
    V v_ru_24o_241_24OPrim = heff_take_reuse_n(v_o_241, 1ULL, 2);
    if (heff_strEq_c(v_p_248, ((V)&g_heff_2ecompile_2erepr_2estepGives_str0))) {
      return heff_tag_at_n(v_ru_24o_241_24OPrim, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Element, 1, (V[]){v_x_240}), v_acc_242});
    } else {
      return heff_tag_at_n(v_ru_24o_241_24OPrim, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240}), v_acc_242});
    }
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240}), v_acc_242});
  }
  case TAG_OBool: {
    V v_ru_24o_241_24OBool = heff_take_reuse_n(v_o_241, 0ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24o_241_24OBool, TAG_Boxed, 1, (V[]){v_x_240}), v_acc_242});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2estepGives(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2eindexOfL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eindexOfL_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eindexOfL(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      heff_drop(v_l_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erepr_2eindexOfL(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erepr_2esourceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esourceOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2esourceOf(V v_x_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SGlobal: {
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SInt: {
    V v_n_244 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SInt = heff_take_reuse_n(v_v_241, 1ULL, 1);
    if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_244))) {
      if (heff_intLe_c(v_n_244, MK_INT(4611686018427387903LL))) {
        heff_drop_cell(v_ru_24v_241_24SInt, 1);
        return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepInt)});
      } else {
        return heff_tag_at_n(v_ru_24v_241_24SInt, TAG_Boxed, 1, (V[]){v_x_240});
      }
    } else {
      heff_drop(v_n_244);
      return heff_tag_at_n(v_ru_24v_241_24SInt, TAG_Boxed, 1, (V[]){v_x_240});
    }
  }
  case TAG_SFloat: {
    heff_take_na(v_v_241, 0ULL, 1);
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepF64)});
  }
  case TAG_SStr: {
    V v_ru_24v_241_24SStr = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SStr, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SBytes: {
    V v_ru_24v_241_24SBytes = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SBytes, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SFixed: {
    V v_w_2410 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SFixed = heff_take_reuse_n(v_v_241, 1ULL, 2);
    return heff_tag_at_n(v_ru_24v_241_24SFixed, TAG_Literal, 2, (V[]){v_x_240, heff_tag_n(TAG_RepFix, 1, (V[]){v_w_2410})});
  }
  case TAG_SFloat32: {
    V v_ru_24v_241_24SFloat32 = heff_take_reuse_na(v_v_241, 0ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24v_241_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, v_t_2413});
  }
  case TAG_SPrimFn: {
    V v_ru_24v_241_24SPrimFn = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SPrimFn, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_STag: {
    heff_take_n(v_v_241, 0ULL, 3);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SRec: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SProj: {
    V v_l_2423 = heff_field(v_v_241, 1);
    V v_sh_2424 = heff_field(v_v_241, 2);
    V v_t_2425 = heff_field(v_v_241, 3);
    heff_take_n(v_v_241, 14ULL, 4);
    V v_t_2426 = ({ V a_0 = v_l_2423; V a_1 = MK_INT(0LL); V a_2 = v_sh_2424; V r_ = (g_heff_2ecompile_2erepr_2eindexOfL(a_0, a_1, a_2)); heff_drop(v_sh_2424); r_; });
    V v_r_2427 = (g_heff_2ecompile_2erepr_2ereadRepr(v_t_2426, v_t_2425));
    switch (heff_tag_of(v_r_2427)) {
    case TAG_RepV: {
      return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
    }
    case TAG_RepFix: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2427});
    }
    case TAG_RepF64: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2427});
    }
    case TAG_RepInt: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2427});
    }
    default: return heff_nomatch(v_r_2427);
    }
  }
  case TAG_SPrim: {
    V v_p_2429 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SPrim = heff_take_reuse_n(v_v_241, 1ULL, 2);
    HeffT2 v_t_2431 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(heff_dup(v_p_2429)));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_s_2435 = v_field_2433;
        V v_t_2436 = heff_get_n(v_s_2435, 1, 2);
        V v_t_2438;
        switch (heff_tag_of(v_t_2436)) {
        case TAG_RepV: {
          v_t_2438 = NTAG(TAG_True);
          break;
        }
        case TAG_RepFix: {
          heff_take_n(v_t_2436, 0ULL, 1);
          v_t_2438 = NTAG(TAG_False);
          break;
        }
        case TAG_RepF64: {
          v_t_2438 = NTAG(TAG_False);
          break;
        }
        case TAG_RepInt: {
          v_t_2438 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2436);
        }
        if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
          heff_drop(v_p_2429);
          heff_drop_cell(v_ru_24v_241_24SPrim, 2);
          heff_drop(v_t_2438);
          return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
        } else {
          heff_drop(v_t_2438);
          HeffT2 v_t_2439 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_2429));
          V v_t_2444;
          {
            V v_field_2441 = v_t_2439.f[1];
            int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
            if ((v_tag_2440 == ((int64_t)0ULL))) {
              V v_s_2443 = v_field_2441;
              v_t_2444 = heff_get_n(v_s_2443, 1, 2);
            } else {
              heff_drop(v_field_2441);
              v_t_2444 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2444});
        }
      } else {
        heff_drop(v_p_2429);
        heff_drop_cell(v_ru_24v_241_24SPrim, 2);
        heff_drop(v_field_2433);
        return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
      }
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esourceOf(a[0], a[1]);
}
V g_heff_2ecompile_2erepr_2epinFields_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2epinFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2epinFields_entry, 3, 0};

V g_heff_2ecompile_2erepr_2epinFields(V v_ps_240, V v_acc_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s964765707x1396946999(v_acc_241, v_vs_242));
  }
  case TAG_Cons: {
    V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
    V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_vs_242, v_t_246));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2epinFields_lam0, 2, 1, (V[]){v_ps_240}); V a_1 = v_acc_241; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ecompile_2erepr_2epinFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2epinFields(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erepr_2epinFields_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x3_249 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_i_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24MkPair = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = v_i_2411; V a_1 = v_ps_240; V r_ = (g_list_2eany_24s120814613x1439363162(a_0, a_1)); heff_drop_tag(v_ps_240, 2); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      return heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){v_x_2410}), v_acc_248});
    } else {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_2410)}), v_acc_248});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_2410}), v_t_2413});
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
Clo g_heff_2ecompile_2erepr_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2erepr_2efreeGo(V v_bs_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_bs_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_map_2elookup_24s659669741x1036301430_24cpr(heff_dup(v_x_243), v_bs_240));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_bs_240;
        V t_1 = v_xs_244;
        V t_2 = v_acc_242;
        v_bs_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), NTAG(TAG_MkUnit), v_bs_240));
        V t_0 = v_t_2410;
        V t_1 = v_xs_244;
        V t_2 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
        v_bs_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efreeGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2ereturned_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereturned_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ereturned(V v_x1_240, V v_o_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RetAs: {
    V v_r_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RetAs = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_o_241)) {
    case TAG_OSimple: {
      V v_v_244 = heff_field(v_o_241, 0);
      heff_take_n(v_o_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24RetAs, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_r_243, v_v_244}), v_rest_242});
    }
    case TAG_OCall: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OApply: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OPrim: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OAbandon: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OBool: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    default: return heff_nomatch(v_o_241);
    }
  }
  case TAG_RetClass: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_o_241}), v_rest_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereturned(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2ewalk_str0, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2erepr_2ewalk_str1, 14, "arrayReplicate");
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam1(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam2(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewalk_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ewalk(V v_sg_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_sg_240, 2);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_r_245 = heff_field(v_x31_243, 0);
      V v_x312_246 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24IVal = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_246)) {
      case TAG_SVar: {
        V v_x_247 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Wants, 2, (V[]){v_x_247, v_r_245}), v_acc_241});
        V t_0 = v_sg_240;
        V t_1 = v_t_248;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x312_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2418 = heff_field(v_x312_246, 0);
        V v_x3122_2419 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 3ULL, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        switch (heff_tag_of(v_x3122_2419)) {
        case TAG_MkBlock: {
          V v_t_2420 = heff_field(v_x3122_2419, 0);
          V v_ru_24x3122_2419_24MkBlock = heff_take_reuse_n(v_x3122_2419, 1ULL, 1);
          V v_t_2421 = heff_tag_at_n(v_ru_24x3122_2419_24MkBlock, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
          V v_t_2422 = heff_tag_n(TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2421, v_t_2420});
          V v_t_2423 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
          V v_evs_2424 = (g_heff_2ecompile_2erepr_2ewalk(heff_dup(v_sg_240), NTAG(TAG_Nil), v_t_2423));
          V v_t_2425 = (g_prelude_2e_2b_2b(heff_dup(v_evs_2424), v_acc_241));
          V v_t_2426 = (g_list_2efoldl_24s2096135476x728523350(v_t_2425, heff_dup(v_xs_2418)));
          V v_t_2427 = (g_list_2efoldl_24s1694506840x958926808(heff_dup(g_map_2eempty_get()), v_evs_2424));
          V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_xs_2418; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2418); r_; });
          V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2424));
          V v_t_2430 = (g_list_2efoldl_24s512987356x688045438(NTAG(TAG_Nil), v_t_2429));
          V v_t_2431 = (g_heff_2ecompile_2erepr_2efreeGo(v_t_2428, v_t_2430, NTAG(TAG_Nil)));
          V v_t_2432 = (g_list_2efoldl_24s29004368x870998936(v_t_2426, v_t_2431));
          V t_0 = v_sg_240;
          V t_1 = v_t_2432;
          V t_2 = v_rest_244;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3122_2419);
        }
      }
      case TAG_STag: {
        V v_as_2434 = heff_field(v_x312_246, 1);
        V v_ts_2435 = heff_field(v_x312_246, 2);
        heff_take_n(v_x312_246, 6ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_n_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2434));
        V v_t_2437 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2436, MK_INT(1LL))));
        V v_rs_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam0, 1, 1, (V[]){v_ts_2435}), v_t_2437));
        V v_t_2441 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2440, v_as_2434));
        V v_t_2442 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_2441));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2442;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2443 = heff_field(v_x312_246, 0);
        V v_ts_2444 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_t_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2444));
        V v_t_2446 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2445, MK_INT(1LL))));
        V v_rs_2447 = (g_list_2ezipWith_24s1713677103x1107896282(v_t_2446, v_ts_2444));
        V v_vs_2448 = (g_list_2emap_24s1173914895x100384474(v_fs_2443));
        V v_t_2449 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2447, v_vs_2448));
        V v_t_2450 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_2449));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2450;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2451 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 4);
        heff_drop(v_r_245);
        V v_t_2455 = heff_tag_at_n(v_ru_24x31_243_24IVal, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_2451});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2455, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrim: {
        V v_p_2456 = heff_field(v_x312_246, 0);
        V v_as_2457 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_t_2460;
        if (heff_strEq_c_lent(v_p_2456, ((V)&g_heff_2ecompile_2erepr_2ewalk_str0), 2)) {
          v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(2LL)});
        } else {
          if (heff_strEq_c_lent(v_p_2456, ((V)&g_heff_2ecompile_2erepr_2ewalk_str1), 2)) {
            v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
          } else {
            v_t_2460 = NTAG(TAG_Nothing);
          }
        }
        HeffT2 v_t_2461 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_2456));
        V v_t_2466;
        {
          V v_field_2463 = v_t_2461.f[1];
          int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
          if ((v_tag_2462 == ((int64_t)0ULL))) {
            V v_s_2465 = v_field_2463;
            v_t_2466 = heff_get_n(v_s_2465, 0, 2);
          } else {
            heff_drop(v_field_2463);
            v_t_2466 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_2457)));
          }
        }
        V v_t_2467 = ({ V a_0 = v_t_2460; V a_1 = v_t_2466; V a_2 = v_as_2457; V a_3 = v_rest_244; V r_ = (g_heff_2ecompile_2erepr_2epushElement(a_0, a_1, a_2, a_3)); heff_drop(v_t_2460); r_; });
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2467;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_246);
      }
    }
    case TAG_IAny: {
      V v_x311_2468 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2468)) {
      case TAG_SVar: {
        heff_take_n(v_x311_2468, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SGlobal: {
        V v_t_2471 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2471, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        V v_t_2473 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2473, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        V v_t_2475 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2475, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        V v_t_2477 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2477, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        V v_t_2479 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2479, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        V v_t_2482 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2482, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        V v_t_2484 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2484, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        V v_t_2486 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2486, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_t_2489 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2489, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_STag: {
        V v_t_2493 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2493, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_t_2496 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2496, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_t_24101 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24101, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrim: {
        V v_t_24104 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x311_2468});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24104, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2468);
      }
    }
    case TAG_IBind: {
      V v_x_24105 = heff_field(v_x31_243, 0);
      V v_x312_24106 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24IBind = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_24106)) {
      case TAG_OSimple: {
        V v_x3121_24107 = heff_field(v_x312_24106, 0);
        heff_take_n(v_x312_24106, 1ULL, 1);
        switch (heff_tag_of(v_x3121_24107)) {
        case TAG_SVar: {
          V v_y_24108 = heff_field(v_x3121_24107, 0);
          heff_take_n(v_x3121_24107, 1ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24IBind, 2);
          V v_t_24109 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Merge, 2, (V[]){v_x_24105, v_y_24108}), v_acc_241});
          V t_0 = v_sg_240;
          V t_1 = v_t_24109;
          V t_2 = v_rest_244;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SGlobal: {
          V v_t_24111 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24112 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24111, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24112, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SInt: {
          V v_t_24114 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24115 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24114, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24115, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SFloat: {
          V v_t_24117 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24118 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24117, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SStr: {
          V v_t_24120 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24121 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24120, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SBytes: {
          V v_t_24123 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24124 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24123, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SFixed: {
          V v_t_24127 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24128 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24127, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24128, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SFloat32: {
          V v_t_24130 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24131 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24130, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24131, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SPrimFn: {
          V v_t_24133 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24134 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24133, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SLam: {
          V v_t_24137 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24138 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24137, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_STag: {
          V v_t_24142 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24143 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24142, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SRec: {
          V v_t_24146 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24147 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24146, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SProj: {
          V v_t_24152 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24153 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24152, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24153, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SPrim: {
          V v_t_24156 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_24105, heff_dup(v_x3121_24107)));
          V v_t_24157 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_24107});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24156, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3121_24107);
        }
      }
      case TAG_OCall: {
        V v_g_24158 = heff_field(v_x312_24106, 0);
        V v_as_24159 = heff_field(v_x312_24106, 1);
        V v_ru_24x312_24106_24OCall = heff_take_reuse_n(v_x312_24106, 3ULL, 2);
        HeffT2 v_t_24160 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_g_24158), heff_rfield(v_sg_240, 0)));
        V v_t_24167;
        {
          V v_field_24162 = v_t_24160.f[1];
          int64_t v_tag_24161 = ((int64_t)v_t_24160.f[0]);
          V v_r_24165;
          if ((v_tag_24161 == ((int64_t)0ULL))) {
            V v_s_24164 = v_field_24162;
            v_r_24165 = heff_get_n(v_s_24164, 1, 2);
          } else {
            heff_drop(v_field_24162);
            v_r_24165 = NTAG(TAG_RepV);
          }
          switch (heff_tag_of(v_r_24165)) {
          case TAG_RepV: {
            heff_drop_cell(v_ru_24x31_243_24IBind, 2);
            v_t_24167 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_24105});
            break;
          }
          case TAG_RepFix: {
            v_t_24167 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Unboxed, 2, (V[]){v_x_24105, v_r_24165});
            break;
          }
          case TAG_RepF64: {
            v_t_24167 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Unboxed, 2, (V[]){v_x_24105, v_r_24165});
            break;
          }
          case TAG_RepInt: {
            v_t_24167 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Unboxed, 2, (V[]){v_x_24105, v_r_24165});
            break;
          }
          default: heff_nomatch(v_r_24165);
          }
        }
        V v_t_24168 = heff_tag_n(TAG_IOp, 1, (V[]){heff_tag_at_n(v_ru_24x312_24106_24OCall, TAG_OCall, 2, (V[]){v_g_24158, v_as_24159})});
        V t_0 = v_sg_240;
        V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24167, v_acc_241});
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24168, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        heff_drop_cell(v_ru_24x31_243_24IBind, 2);
        V v_t_24171 = (g_heff_2ecompile_2erepr_2estepGives(v_x_24105, heff_dup(v_x312_24106), v_acc_241));
        V v_t_24172 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x312_24106}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_t_24171;
        V t_2 = v_t_24172;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        heff_drop_cell(v_ru_24x31_243_24IBind, 2);
        V v_t_24175 = (g_heff_2ecompile_2erepr_2estepGives(v_x_24105, heff_dup(v_x312_24106), v_acc_241));
        V v_t_24176 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x312_24106}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_t_24175;
        V t_2 = v_t_24176;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x_24105);
        heff_drop_cell(v_ru_24x31_243_24IBind, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        heff_drop_cell(v_ru_24x31_243_24IBind, 2);
        V v_t_24178 = (g_heff_2ecompile_2erepr_2estepGives(v_x_24105, heff_dup(v_x312_24106), v_acc_241));
        V v_t_24179 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x312_24106}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_t_24178;
        V t_2 = v_t_24179;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_24106);
      }
    }
    case TAG_IOp: {
      V v_x311_24180 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24180)) {
      case TAG_OSimple: {
        V v_v_24181 = heff_field(v_x311_24180, 0);
        heff_take_n(v_x311_24180, 1ULL, 1);
        V v_t_24182 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24181});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24182, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_g_24183 = heff_field(v_x311_24180, 0);
        V v_as_24184 = heff_field(v_x311_24180, 1);
        heff_take_n(v_x311_24180, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        HeffT2 v_t_24185 = (g_map_2elookup_24s1546226666x2146984184_24cpr(v_g_24183, heff_rfield(v_sg_240, 0)));
        V v_t_24192;
        {
          V v_field_24187 = v_t_24185.f[1];
          int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
          V v_rs_24190;
          if ((v_tag_24186 == ((int64_t)0ULL))) {
            V v_s_24189 = v_field_24187;
            v_rs_24190 = heff_get_n(v_s_24189, 0, 2);
          } else {
            heff_drop(v_field_24187);
            v_rs_24190 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_24184)));
          }
          V v_t_24191 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24190, v_as_24184));
          v_t_24192 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_24191));
        }
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24192;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_24193 = heff_field(v_x311_24180, 0);
        V v_as_24194 = heff_field(v_x311_24180, 1);
        heff_take_n(v_x311_24180, 3ULL, 2);
        V v_t_24195 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_24193, v_as_24194})));
        V v_t_24196 = (g_list_2efoldl_24s728686882x2096535788(NTAG(TAG_RepV), v_rest_244, v_t_24195));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24196;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_24198 = heff_field(v_x311_24180, 1);
        heff_take_n(v_x311_24180, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_24199 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_24198));
        V v_t_24200 = (g_list_2efoldl_24s728686882x2096535788(NTAG(TAG_RepV), v_rest_244, v_t_24199));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24200;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_24201 = heff_field(v_x311_24180, 0);
        heff_take_n(v_x311_24180, 1ULL, 1);
        V v_t_24202 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24201}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24202;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24180);
      }
    }
    case TAG_ICond: {
      V v_x311_24203 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24203)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_p_24204 = heff_field(v_x311_24203, 0);
        V v_a_24205 = heff_field(v_x311_24203, 1);
        V v_b_24206 = heff_field(v_x311_24203, 2);
        heff_take_n(v_x311_24203, 7ULL, 3);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        HeffT2 v_t_24207 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_24204));
        V v_t_24216;
        {
          V v_field_24209 = v_t_24207.f[1];
          int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
          V v_rs_24213;
          if ((v_tag_24208 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x3_242_24Cons, 2);
            V v_s_24211 = v_field_24209;
            v_rs_24213 = heff_get_n(v_s_24211, 0, 2);
          } else {
            heff_drop(v_field_24209);
            V v_t_24212 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_24206), NTAG(TAG_Nil)});
            v_rs_24213 = (g_list_2emap_24s1598879313x231311047(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_24205), v_t_24212})));
          }
          V v_t_24214 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24206, NTAG(TAG_Nil)});
          V v_t_24215 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24213, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24205, v_t_24214})));
          v_t_24216 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_24215));
        }
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24216;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_24217 = heff_field(v_x311_24203, 0);
        heff_take_n(v_x311_24203, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24218 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24217});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24218, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_24219 = heff_field(v_x311_24203, 0);
        heff_take_n(v_x311_24203, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24220 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24219}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24220;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_24221 = heff_field(v_x311_24203, 0);
        V v_b_24222 = heff_field(v_x311_24203, 1);
        V v_c_24223 = heff_field(v_x311_24203, 2);
        heff_take_n(v_x311_24203, 7ULL, 3);
        V v_t_24224 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24223}), v_rest_244});
        V v_t_24225 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_24222}), v_t_24224});
        V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_24221}), v_t_24225});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24226;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_x_24227 = heff_field(v_x311_24203, 0);
        V v_o_24228 = heff_field(v_x311_24203, 1);
        V v_c_24229 = heff_field(v_x311_24203, 2);
        heff_take_n(v_x311_24203, 7ULL, 3);
        V v_t_24230 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24227)}), v_acc_241});
        V v_t_24231 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_24229}), v_rest_244});
        V v_t_24232 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24227, v_o_24228}), v_t_24231});
        V t_0 = v_sg_240;
        V t_1 = v_t_24230;
        V t_2 = v_t_24232;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24203);
      }
    }
    case TAG_ISts: {
      V v_x311_24233 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24233)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24234 = heff_field(v_x311_24233, 0);
        V v_ss_24235 = heff_field(v_x311_24233, 1);
        V v_ru_24x311_24233_24Cons = heff_take_reuse_n(v_x311_24233, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24234)) {
        case TAG_SLet: {
          V v_x_24236 = heff_field(v_x3111_24234, 0);
          V v_o_24237 = heff_field(v_x3111_24234, 1);
          V v_ru_24x3111_24234_24SLet = heff_take_reuse_n(v_x3111_24234, 3ULL, 2);
          V v_t_24238 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24236)}), v_acc_241});
          V v_t_24239 = heff_tag_at_n(v_ru_24x311_24233_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24235}), v_rest_244});
          V v_t_24240 = heff_tag_at_n(v_ru_24x3111_24234_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24236, v_o_24237}), v_t_24239});
          V t_0 = v_sg_240;
          V t_1 = v_t_24238;
          V t_2 = v_t_24240;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_24241 = heff_field(v_x3111_24234, 0);
          heff_take_n(v_x3111_24234, 1ULL, 1);
          V v_t_24242 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){v_x_24241}), v_acc_241});
          V v_t_24243 = heff_tag_at_n(v_ru_24x311_24233_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24235}), v_rest_244});
          V t_0 = v_sg_240;
          V t_1 = v_t_24242;
          V t_2 = v_t_24243;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_x_24244 = heff_field(v_x3111_24234, 0);
          V v_o_24245 = heff_field(v_x3111_24234, 1);
          heff_take_n(v_x3111_24234, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24235}), v_rest_244});
          V v_t_24247 = heff_tag_at_n(v_ru_24x311_24233_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24244, v_o_24245}), v_t_24246});
          V t_0 = v_sg_240;
          V t_1 = v_acc_241;
          V t_2 = v_t_24247;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24248 = heff_field(v_x3111_24234, 0);
          V v_ts_24249 = heff_field(v_x3111_24234, 1);
          V v_fs_24250 = heff_field(v_x3111_24234, 2);
          heff_take_n(v_x3111_24234, 7ULL, 3);
          V v_t_24251 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24235}), v_rest_244});
          V v_t_24252 = heff_tag_at_n(v_ru_24x311_24233_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_24250}), v_t_24251});
          V v_t_24253 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24249}), v_t_24252});
          V v_t_24254 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24248}), v_t_24253});
          V t_0 = v_sg_240;
          V t_1 = v_acc_241;
          V t_2 = v_t_24254;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24255 = heff_field(v_x3111_24234, 0);
          V v_arms_24256 = heff_field(v_x3111_24234, 1);
          V v_ru_24x3111_24234_24SCase = heff_take_reuse_n(v_x3111_24234, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24268 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam1, 2, 1, (V[]){heff_dup(v_sg_240)}), v_acc_241, v_arms_24256));
          V v_t_24269 = heff_tag_at_n(v_ru_24x3111_24234_24SCase, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24255});
          V v_t_24270 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24235}), v_rest_244});
          V v_t_24271 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24256));
          V v_t_24272 = (g_list_2efoldl_24s1104809983x118204267(v_t_24270, v_t_24271));
          V t_0 = v_sg_240;
          V t_1 = v_t_24268;
          V t_2 = heff_tag_at_n(v_ru_24x311_24233_24Cons, TAG_Cons, 2, (V[]){v_t_24269, v_t_24272});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24234);
        }
      }
      default: return heff_nomatch(v_x311_24233);
      }
    }
    case TAG_ITl: {
      V v_ps_24273 = heff_field(v_x31_243, 0);
      V v_rt_24274 = heff_field(v_x31_243, 1);
      V v_x313_24275 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x313_24275)) {
      case TAG_TSeq: {
        V v_ss_24276 = heff_field(v_x313_24275, 0);
        V v_t_24277 = heff_field(v_x313_24275, 1);
        V v_ru_24x313_24275_24TSeq = heff_take_reuse_n(v_x313_24275, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24278 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){v_ps_24273, v_rt_24274, v_t_24277}), v_rest_244});
        V v_t_24279 = heff_tag_at_n(v_ru_24x313_24275_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24276}), v_t_24278});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24279;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24280 = heff_field(v_x313_24275, 0);
        heff_take_n(v_x313_24275, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_ps_24273);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24281 = (g_heff_2ecompile_2erepr_2ereturned(v_rt_24274, v_o_24280, v_rest_244));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24281;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24282 = heff_field(v_x313_24275, 0);
        heff_take_n(v_x313_24275, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_rt_24274);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24283 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ps_24273, v_vs_24282));
        V v_t_24284 = (g_list_2efoldl_24s348204425x880103432(v_rest_244, v_t_24283));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24284;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24285 = heff_field(v_x313_24275, 0);
        V v_t_24286 = heff_field(v_x313_24275, 1);
        V v_e_24287 = heff_field(v_x313_24275, 2);
        heff_take_n(v_x313_24275, 7ULL, 3);
        V v_t_24288 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_ps_24273), heff_dup(v_rt_24274), v_e_24287}), v_rest_244});
        V v_t_24289 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 3, (V[]){v_ps_24273, v_rt_24274, v_t_24286}), v_t_24288});
        V v_t_24290 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24285}), v_t_24289});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24290;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24291 = heff_field(v_x313_24275, 0);
        V v_arms_24292 = heff_field(v_x313_24275, 1);
        V v_ru_24x313_24275_24TCase = heff_take_reuse_n(v_x313_24275, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24304 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam2, 2, 1, (V[]){heff_dup(v_sg_240)}), v_acc_241, v_arms_24292));
        V v_t_24305 = heff_tag_at_n(v_ru_24x313_24275_24TCase, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24291});
        V v_t_24306 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24292));
        V v_t_24307 = (g_list_2efoldl_24s2145639387x28888241(v_ps_24273, v_rt_24274, v_rest_244, v_t_24306));
        V t_0 = v_sg_240;
        V t_1 = v_t_24304;
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_24305, v_t_24307});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x313_24275);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ewalk(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args) {
  V v_i_2438 = args[0];
  V v_ts_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = ({ V a_0 = heff_dup(v_i_2438); V a_1 = v_ts_2435; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2435); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2438, v_t_2439));
}
V g_heff_2ecompile_2erepr_2ewalk_lam1(V self, V *args) {
  V v_acc_24257 = args[0];
  V v_x3_24258 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24258)) {
  case TAG_MkArm: {
    V v_t_24259 = heff_field(v_x3_24258, 0);
    V v_vs_24260 = heff_field(v_x3_24258, 1);
    heff_take_n(v_x3_24258, 3ULL, 3);
    HeffT2 v_t_24262 = ({ V a_0 = v_t_24259; V b_1 = heff_get_n(v_sg_240, 1, 2); HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24267;
    {
      V v_field_24264 = v_t_24262.f[1];
      int64_t v_tag_24263 = ((int64_t)v_t_24262.f[0]);
      if ((v_tag_24263 == ((int64_t)0ULL))) {
        V v_x_24266 = v_field_24264;
        v_t_24267 = v_x_24266;
      } else {
        heff_drop(v_field_24264);
        v_t_24267 = NTAG(TAG_Nil);
      }
    }
    return (g_heff_2ecompile_2erepr_2epinFields(v_t_24267, v_acc_24257, v_vs_24260));
  }
  default: return heff_nomatch(v_x3_24258);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_lam2(V self, V *args) {
  V v_acc_24293 = args[0];
  V v_x3_24294 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24294)) {
  case TAG_MkArm: {
    V v_t_24295 = heff_field(v_x3_24294, 0);
    V v_vs_24296 = heff_field(v_x3_24294, 1);
    heff_take_n(v_x3_24294, 3ULL, 3);
    HeffT2 v_t_24298 = ({ V a_0 = v_t_24295; V b_1 = heff_get_n(v_sg_240, 1, 2); HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24303;
    {
      V v_field_24300 = v_t_24298.f[1];
      int64_t v_tag_24299 = ((int64_t)v_t_24298.f[0]);
      if ((v_tag_24299 == ((int64_t)0ULL))) {
        V v_x_24302 = v_field_24300;
        v_t_24303 = v_x_24302;
      } else {
        heff_drop(v_field_24300);
        v_t_24303 = NTAG(TAG_Nil);
      }
    }
    return (g_heff_2ecompile_2erepr_2epinFields(v_t_24303, v_acc_24293, v_vs_24296));
  }
  default: return heff_nomatch(v_x3_24294);
  }
}
Clo g_heff_2ecompile_2erepr_2eentered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eentered_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eentered(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_RepV: {
      V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_244});
    }
    case TAG_RepFix: {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_242, v_x22_243}), v_t_246});
    }
    case TAG_RepF64: {
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_242, v_x22_243}), v_t_247});
    }
    case TAG_RepInt: {
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_acc_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_242, v_x22_243}), v_t_248});
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2eentered_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eentered(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2edefEvents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edefEvents_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edefEvents(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkDef: {
    V v_key_242 = heff_field(v_x2_241, 0);
    V v_x23_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24MkDef = heff_take_reuse_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x23_244)) {
    case TAG_DefFun: {
      V v_xs_245 = heff_field(v_x23_244, 0);
      V v_x232_246 = heff_field(v_x23_244, 1);
      V v_ru_24x23_244_24DefFun = heff_take_reuse_n(v_x23_244, 3ULL, 2);
      switch (heff_tag_of(v_x232_246)) {
      case TAG_MkBlock: {
        V v_t_247 = heff_field(v_x232_246, 0);
        heff_take_n(v_x232_246, 1ULL, 1);
        HeffT2 v_t_248 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_key_242), heff_rfield(v_sg_240, 0)));
        V v_t_2413;
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_s_2412 = v_field_2410;
            v_t_2413 = heff_get_n(v_s_2412, 0, 2);
          } else {
            heff_drop(v_field_2410);
            v_t_2413 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_245)));
          }
        }
        V v_t_2414 = (g_list_2efoldl_24f488322910x556193579(NTAG(TAG_Nil), heff_dup(v_xs_245), v_t_2413));
        HeffT2 v_t_2415 = (g_map_2elookup_24s1546226666x2146984184_24cpr(v_key_242, heff_rfield(v_sg_240, 0)));
        V v_t_2420;
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_s_2419 = v_field_2417;
            v_t_2420 = heff_get_n(v_s_2419, 1, 2);
          } else {
            heff_drop(v_field_2417);
            v_t_2420 = NTAG(TAG_RepV);
          }
        }
        V v_t_2421 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){v_xs_245, heff_tag_n(TAG_RetAs, 1, (V[]){v_t_2420}), v_t_247});
        V v_t_2422 = heff_tag_at_n(v_ru_24x23_244_24DefFun, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, v_t_2414, v_t_2422));
      }
      default: return heff_nomatch(v_x232_246);
      }
    }
    case TAG_DefVal: {
      V v_x231_2423 = heff_field(v_x23_244, 0);
      V v_ru_24x23_244_24DefVal = heff_take_reuse_n(v_x23_244, 1ULL, 1);
      heff_drop(v_key_242);
      switch (heff_tag_of(v_x231_2423)) {
      case TAG_MkBlock: {
        V v_t_2424 = heff_field(v_x231_2423, 0);
        heff_take_n(v_x231_2423, 1ULL, 1);
        V v_t_2425 = heff_tag_at_n(v_ru_24x23_244_24DefVal, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
        V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2425, v_t_2424});
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_Nil), v_t_2427));
      }
      default: return heff_nomatch(v_x231_2423);
      }
    }
    default: return heff_nomatch(v_x23_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2edefEvents(a[0], a[1]);
}
V g_heff_2ecompile_2erepr_2ewordParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewordParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewordParams_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ewordParams(V v_is_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_MkDef: {
    V v_d3_244 = heff_field(v_d_241, 2);
    switch (heff_tag_of(v_d3_244)) {
    case TAG_DefFun: {
      V v_xs_245 = heff_field(v_d3_244, 0);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
      V v_t_249 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_248));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ewordParams_lam0, 2, 1, (V[]){heff_dup(v_is_240)}); V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
    }
    case TAG_DefVal: {
      return heff_dup(g_map_2eempty_get());
    }
    default: return heff_nomatch(v_d3_244);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2ecompile_2erepr_2ewordParams_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ewordParams(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2ewordParams_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_p_2411 = args[1];
  V v_is_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = v_p_2411; V a_1 = v_is_240; V r_ = (g_list_2eany_24s1080008383x1763122651(a_0, a_1)); heff_drop(v_is_240); r_; });
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_t_2415;
    switch (heff_tag_of(v_p_2411)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_p_2411, 0);
      heff_take_n(v_p_2411, 1ULL, 2);
      v_t_2415 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_p_2411);
    }
    return (g_map_2einsert_24s1341440536x470972936(v_t_2415, NTAG(TAG_MkUnit), v_m_2410));
  } else {
    heff_drop(v_p_2411);
    heff_drop(v_t_2412);
    return v_m_2410;
  }
}
V g_heff_2ecompile_2erepr_2ewordEvents_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewordEvents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewordEvents_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ewordEvents(V v_sg_240, V v_is_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_is_241)) {
  case TAG_Nil: {
    return (g_heff_2ecompile_2erepr_2edefEvents(v_sg_240, v_d_242));
  }
  case TAG_Cons: {
    V v_ws_245 = (g_heff_2ecompile_2erepr_2ewordParams(v_is_241, v_d_242));
    V v_t_246 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_240, v_d_242));
    return (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erepr_2ewordEvents_lam0, 1, 1, (V[]){v_ws_245}), v_t_246));
  }
  default: return heff_nomatch(v_is_241);
  }
}
V g_heff_2ecompile_2erepr_2ewordEvents_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ewordEvents(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2ewordEvents_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_ws_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_e_247)) {
  case TAG_Merge: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Boxed: {
    V v_x_2410 = heff_field(v_e_247, 0);
    V v_ru_24e_247_24Boxed = heff_take_reuse_n(v_e_247, 1ULL, 1);
    HeffT2 v_t_2411 = ({ V a_0 = heff_dup(v_x_2410); V a_1 = v_ws_245; HeffT2 r_ = (g_map_2elookup_24s659669741x1036301430_24cpr(a_0, a_1)); heff_drop(v_ws_245); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24e_247_24Boxed, 1);
        V v_x_2415 = v_field_2413;
        heff_drop(v_x_2415);
        return heff_tag_n(TAG_BoxedWord, 1, (V[]){v_x_2410});
      } else {
        heff_drop(v_field_2413);
        return heff_tag_at_n(v_ru_24e_247_24Boxed, TAG_Boxed, 1, (V[]){v_x_2410});
      }
    }
  }
  case TAG_BoxedWord: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Element: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Unboxed: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Literal: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Wants: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Binds: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Pinned: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  case TAG_Kept: {
    heff_drop(v_ws_245);
    return v_e_247;
  }
  default: return heff_nomatch(v_e_247);
  }
}
Clo g_heff_2ecompile_2erepr_2erootFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2erootFrom_entry, 3, 0};

V g_heff_2ecompile_2erepr_2erootFrom(V v_parent_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return v_x_241;
  }
  case TAG_Just: {
    V v_y_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_241, v_y_243, 0)) {
      heff_drop(v_y_243);
      return v_x_241;
    } else {
      heff_drop(v_x_241);
      V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_y_243), v_parent_240));
      V t_0 = v_parent_240;
      V t_1 = v_y_243;
      V t_2 = v_t_245;
      v_parent_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2erootFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2eunite_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunite_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eunite(V v_parent_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_a_241), v_parent_240));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_a_241), v_t_243));
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_b_242), v_parent_240));
  V v_t_246 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_b_242), v_t_245));
  if (heff_strEq_c(v_t_244, v_t_246)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return v_parent_240;
  } else {
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_a_241), v_parent_240));
    V v_t_249 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_a_241, v_t_248));
    V v_t_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_b_242), v_parent_240));
    V v_t_2411 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_b_242, v_t_2410));
    HEFF_LAST return g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2411, v_parent_240);
  }
}
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eunite(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2eunpinOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunpinOne_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eunpinOne(V v_pins_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Merge: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_y_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24Merge = heff_take_reuse_n(v_e_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_map_2elookup_24s659669741x1036301430_24cpr(heff_dup(v_x_242), v_pins_240));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24e_241_24Merge, 2);
        V v_x_248 = v_field_246;
        heff_drop(v_x_248);
        V v_t_249 = heff_tag_n(TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_2410});
      } else {
        heff_drop(v_field_246);
        HeffT2 v_t_2411 = (g_map_2elookup_24s659669741x1036301430_24cpr(heff_dup(v_y_243), v_pins_240));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24e_241_24Merge, 2);
            V v_x_2415 = v_field_2413;
            heff_drop(v_x_2415);
            V v_t_2416 = heff_tag_n(TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
            V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_2417});
          } else {
            heff_drop(v_field_2413);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_241_24Merge, TAG_Merge, 2, (V[]){v_x_242, v_y_243}), NTAG(TAG_Nil)});
          }
        }
      }
    }
  }
  case TAG_Boxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_BoxedWord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Element: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Unboxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Literal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Wants: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Binds: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Pinned: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Kept: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eunpinOne(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ecompile_2erepr_2enoStats_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2enoStats_st;
static V g_heff_2ecompile_2erepr_2enoStats_init(void) {
  return heff_rec_n(8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, (V[]){NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False)});
}
V g_heff_2ecompile_2erepr_2enoStats_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2enoStats_st)) return g_heff_2ecompile_2erepr_2enoStats_val;
  return heff_global(&g_heff_2ecompile_2erepr_2enoStats_val, &g_heff_2ecompile_2erepr_2enoStats_st, g_heff_2ecompile_2erepr_2enoStats_init);
}
Clo g_heff_2ecompile_2erepr_2ewithRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewithRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ewithRepr(V v_r_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_RepV: {
    return v_rs_241;
  }
  case TAG_RepFix: {
    V v_t_243 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_tag(v_r_240, 1);
      heff_drop(v_t_243);
      return v_rs_241;
    } else {
      heff_drop(v_t_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  case TAG_RepF64: {
    V v_t_244 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return v_rs_241;
    } else {
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  case TAG_RepInt: {
    V v_t_245 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return v_rs_241;
    } else {
      heff_drop(v_t_245);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2erepr_2ewithRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ewithRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2estatsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsWith_entry, 7, 0};

V g_heff_2ecompile_2erepr_2estatsWith(V v_r_240, V v_bi_241, V v_ui_242, V v_bo_243, V v_uo_244, V v_pin_245, V v_s_246) {
top: ;
  V v_t_247 = (g_heff_2ecompile_2erepr_2ewithRepr(v_r_240, heff_take_field(v_s_246, 0)));
  V v_t_248 = heff_intAdd(heff_take_field(v_s_246, 1), v_bi_241);
  V v_t_249 = heff_intAdd(heff_take_field(v_s_246, 2), v_ui_242);
  V v_t_2410 = heff_intAdd(heff_take_field(v_s_246, 3), v_bo_243);
  V v_t_2411 = heff_intAdd(heff_take_field(v_s_246, 4), v_uo_244);
  V v_t_2412 = heff_take_field(v_s_246, 5);
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_pin_245);
    heff_drop(v_t_2412);
    v_t_2413 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = v_pin_245;
  }
  return ({ V rv_0 = v_t_247; V rv_1 = v_t_248; V rv_2 = v_t_249; V rv_3 = v_t_2410; V rv_4 = v_t_2411; V rv_5 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_246, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ecompile_2erepr_2estatsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2estatsWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2erepr_2eseen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eseen_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eseen(V v_e_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Merge: {
    return v_s_241;
  }
  case TAG_Boxed: {
    V v_t_245 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(1LL));
    V v_t_246 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_247 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_248 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_249 = heff_take_field(v_s_241, 5);
    V v_t_2410 = heff_bool((heff_dup(v_t_249) == NTAG(TAG_True)));
    heff_drop(v_t_249);
    return ({ V rv_1 = v_t_245; V rv_2 = v_t_246; V rv_3 = v_t_247; V rv_4 = v_t_248; V rv_5 = v_t_2410; V rv_7 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 65ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 12291u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 7) = rv_7; rr_; });
  }
  case TAG_BoxedWord: {
    return (g_heff_2ecompile_2erepr_2estatsWith(NTAG(TAG_RepInt), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), v_s_241));
  }
  case TAG_Element: {
    return ({ V rv_7 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  }
  case TAG_Unboxed: {
    V v_r_2414 = heff_field(v_e_240, 1);
    V v_t_2415 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2414), heff_take_field(v_s_241, 0)));
    V v_t_2416 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2417 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(1LL));
    V v_t_2418 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2419 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2420 = heff_take_field(v_s_241, 5);
    V v_t_2421 = heff_bool((heff_dup(v_t_2420) == NTAG(TAG_True)));
    heff_drop(v_t_2420);
    return ({ V rv_0 = v_t_2415; V rv_1 = v_t_2416; V rv_2 = v_t_2417; V rv_3 = v_t_2418; V rv_4 = v_t_2419; V rv_5 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Literal: {
    V v_r_2423 = heff_field(v_e_240, 1);
    V v_t_2424 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2423), heff_take_field(v_s_241, 0)));
    V v_t_2425 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2426 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_2427 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2428 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2429 = heff_take_field(v_s_241, 5);
    V v_t_2430 = heff_bool((heff_dup(v_t_2429) == NTAG(TAG_True)));
    heff_drop(v_t_2429);
    return ({ V rv_0 = v_t_2424; V rv_1 = v_t_2425; V rv_2 = v_t_2426; V rv_3 = v_t_2427; V rv_4 = v_t_2428; V rv_5 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Wants: {
    V v_e2_2432 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2432)) {
    case TAG_RepV: {
      V v_t_2433 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2434 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2435 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(1LL));
      V v_t_2436 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
      V v_t_2437 = heff_take_field(v_s_241, 5);
      V v_t_2438 = heff_bool((heff_dup(v_t_2437) == NTAG(TAG_True)));
      heff_drop(v_t_2437);
      return ({ V rv_1 = v_t_2433; V rv_2 = v_t_2434; V rv_3 = v_t_2435; V rv_4 = v_t_2436; V rv_5 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_s_241, 193ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61443u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_RepFix: {
      V v_t_2440 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_e2_2432), heff_take_field(v_s_241, 0)));
      V v_t_2441 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2442 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2443 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2444 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      V v_t_2445 = heff_take_field(v_s_241, 5);
      V v_t_2446 = heff_bool((heff_dup(v_t_2445) == NTAG(TAG_True)));
      heff_drop(v_t_2445);
      return ({ V rv_0 = v_t_2440; V rv_1 = v_t_2441; V rv_2 = v_t_2442; V rv_3 = v_t_2443; V rv_4 = v_t_2444; V rv_5 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_RepF64: {
      V v_t_2447 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_e2_2432), heff_take_field(v_s_241, 0)));
      V v_t_2448 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2449 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2450 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2451 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      V v_t_2452 = heff_take_field(v_s_241, 5);
      V v_t_2453 = heff_bool((heff_dup(v_t_2452) == NTAG(TAG_True)));
      heff_drop(v_t_2452);
      return ({ V rv_0 = v_t_2447; V rv_1 = v_t_2448; V rv_2 = v_t_2449; V rv_3 = v_t_2450; V rv_4 = v_t_2451; V rv_5 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_RepInt: {
      V v_t_2454 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_e2_2432), heff_take_field(v_s_241, 0)));
      V v_t_2455 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2456 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2457 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2458 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      V v_t_2459 = heff_take_field(v_s_241, 5);
      V v_t_2460 = heff_bool((heff_dup(v_t_2459) == NTAG(TAG_True)));
      heff_drop(v_t_2459);
      return ({ V rv_0 = v_t_2454; V rv_1 = v_t_2455; V rv_2 = v_t_2456; V rv_3 = v_t_2457; V rv_4 = v_t_2458; V rv_5 = v_t_2460; V rr_ = heff_rec_reuse_nf(v_s_241, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    default: return heff_nomatch(v_e2_2432);
    }
  }
  case TAG_Binds: {
    return v_s_241;
  }
  case TAG_Pinned: {
    V v_t_2463 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2464 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_2465 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2466 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2467 = heff_take_field(v_s_241, 5);
    V v_t_2468 = heff_bool(((heff_dup(v_t_2467) == NTAG(TAG_True)) || 1));
    heff_drop(v_t_2467);
    return ({ V rv_1 = v_t_2463; V rv_2 = v_t_2464; V rv_3 = v_t_2465; V rv_4 = v_t_2466; V rv_5 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_s_241, 193ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61443u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Kept: {
    V v_r_2470 = heff_field(v_e_240, 1);
    V v_t_2471 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2470), heff_take_field(v_s_241, 0)));
    return ({ V rv_0 = v_t_2471; V rv_6 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_r_2470)}); V rr_ = heff_rec_reuse_nf(v_s_241, 190ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 53244u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eseen(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2estatsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2estatsOf(V v_parent_240, V v_evs_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2estatsOf_lam0, 2, 1, (V[]){heff_dup(v_parent_240)}), heff_dup(g_map_2eempty_get()), v_evs_241));
}
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2estatsOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_e_243 = args[1];
  V v_parent_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2419;
  switch (heff_tag_of(v_e_243)) {
  case TAG_Merge: {
    V v_x_244 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_244;
    break;
  }
  case TAG_Boxed: {
    V v_x_246 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_246;
    break;
  }
  case TAG_BoxedWord: {
    V v_x_247 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_247;
    break;
  }
  case TAG_Element: {
    V v_x_248 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_248;
    break;
  }
  case TAG_Unboxed: {
    V v_x_249 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_249;
    break;
  }
  case TAG_Literal: {
    V v_x_2411 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_2411;
    break;
  }
  case TAG_Wants: {
    V v_x_2413 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_2413;
    break;
  }
  case TAG_Binds: {
    V v_x_2415 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_2415;
    break;
  }
  case TAG_Pinned: {
    V v_x_2416 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_2416;
    break;
  }
  case TAG_Kept: {
    V v_x_2417 = heff_dup(heff_field(v_e_243, 0));
    v_x_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_e_243);
  }
  V v_t_2420 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2419), v_parent_240));
  V v_root_2421 = ({ V a_0 = v_parent_240; V a_1 = v_x_2419; V a_2 = v_t_2420; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_2422 = (g_map_2elookup_24s1546226666x2146984184_24cpr(heff_dup(v_root_2421), v_m_242));
  V v_t_2427;
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x_2426 = v_field_2424;
      v_t_2427 = v_x_2426;
    } else {
      heff_drop(v_field_2424);
      v_t_2427 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
  }
  V v_t_2428 = ({ V a_0 = v_e_243; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2erepr_2eseen(a_0, a_1)); heff_drop(v_e_243); r_; });
  return (g_map_2einsert_24s1341440536x470972936(v_root_2421, v_t_2428, v_m_242));
}
Clo g_heff_2ecompile_2erepr_2edecideOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecideOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edecideOf(V v_s_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_240, 8);
    return NTAG(TAG_RepV);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_rs_241, 0);
    V v_rs2_243 = heff_field(v_rs_241, 1);
    switch (heff_tag_of(v_rs2_243)) {
    case TAG_Nil: {
      V v_t_245;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_245 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_245 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_245 = MK_INT(2LL);
        break;
      }
      case TAG_RepInt: {
        v_t_245 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_246 = heff_intMul(heff_take_field(v_s_240, 1), v_t_245);
      V v_t_2410;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_2410 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_247 = heff_field(v_r_242, 0);
        int64_t v_t_248;
        switch (heff_tag_of(v_w_247)) {
        case TAG_I8: {
          v_t_248 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_248 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_248 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_248 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_248 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_248 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_248 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_248 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_248 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_247);
        }
        if ((v_t_248 == ((int64_t)64ULL))) {
          v_t_2410 = MK_INT(2LL);
        } else {
          v_t_2410 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2410 = MK_INT(3LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2410 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_2411 = heff_intMul(heff_take_field(v_s_240, 3), v_t_2410);
      V v_t_2415;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_2415 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_2412 = heff_field(v_r_242, 0);
        int64_t v_t_2413;
        switch (heff_tag_of(v_w_2412)) {
        case TAG_I8: {
          v_t_2413 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2413 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2413 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2413 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2413 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2413 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2413 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2413 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2413 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2412);
        }
        if ((v_t_2413 == ((int64_t)64ULL))) {
          v_t_2415 = MK_INT(2LL);
        } else {
          v_t_2415 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = MK_INT(3LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2415 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_2416 = heff_intMul(heff_take_field(v_s_240, 2), v_t_2415);
      V v_t_2418;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = MK_INT(2LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_2419 = heff_intMul(heff_get_n(v_s_240, 4, 8), v_t_2418);
      if (heff_intLe_c(heff_intAdd(v_t_246, v_t_2411), heff_intAdd(v_t_2416, v_t_2419))) {
        return heff_dup(v_r_242);
      } else {
        return NTAG(TAG_RepV);
      }
    }
    case TAG_Cons: {
      heff_drop_rec(v_s_240, 8);
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_rs2_243);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecideOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2ehope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ehope_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ehope(V v_s_240) {
top: ;
  V v_t_241 = heff_take_field(v_s_240, 6);
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_take_field(v_s_240, 5);
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_240, 8);
      heff_drop(v_t_242);
      return NTAG(TAG_RepV);
    } else {
      heff_drop(v_t_242);
      V v_t_243 = heff_take_field(v_s_240, 0);
      V v_r_248;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nil: {
        v_r_248 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Cons: {
        V v_r_244 = heff_field(v_t_243, 0);
        V v_rs2_245 = heff_field(v_t_243, 1);
        heff_take_n(v_t_243, 3ULL, 2);
        switch (heff_tag_of(v_rs2_245)) {
        case TAG_Nil: {
          v_r_248 = v_r_244;
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_rs2_245, 0ULL, 2);
          heff_drop(v_r_244);
          v_r_248 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_rs2_245);
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      switch (heff_tag_of(v_r_248)) {
      case TAG_RepV: {
        heff_drop_rec(v_s_240, 8);
        return v_r_248;
      }
      case TAG_RepFix: {
        heff_drop_rec(v_s_240, 8);
        return v_r_248;
      }
      case TAG_RepF64: {
        heff_drop_rec(v_s_240, 8);
        return v_r_248;
      }
      case TAG_RepInt: {
        V v_t_2410 = heff_get_n(v_s_240, 7, 8);
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          return NTAG(TAG_RepV);
        } else {
          heff_drop(v_t_2410);
          return NTAG(TAG_RepInt);
        }
      }
      default: return heff_nomatch(v_r_248);
      }
    }
  }
  case TAG_Just: {
    V v_r_2411 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_s_240, 8);
    return v_r_2411;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ehope(a[0]);
}
Clo g_heff_2ecompile_2erepr_2ekeptOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ekeptOne_entry, 4, 0};

V g_heff_2ecompile_2erepr_2ekeptOne(V v_parent_240, V v_stats_241, V v_m_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_Merge: {
    return v_m_242;
  }
  case TAG_Boxed: {
    return v_m_242;
  }
  case TAG_BoxedWord: {
    return v_m_242;
  }
  case TAG_Element: {
    return v_m_242;
  }
  case TAG_Unboxed: {
    return v_m_242;
  }
  case TAG_Literal: {
    return v_m_242;
  }
  case TAG_Wants: {
    return v_m_242;
  }
  case TAG_Binds: {
    V v_x_2415 = heff_field(v_e_243, 0);
    V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2415), v_parent_240));
    V v_t_2417 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_x_2415), v_t_2416));
    HeffT2 v_t_2418 = (g_map_2elookup_24s1546226666x2146984184_24cpr(v_t_2417, v_stats_241));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      V v_s_2423;
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2422 = v_field_2420;
        v_s_2423 = v_x_2422;
      } else {
        heff_drop(v_field_2420);
        v_s_2423 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
      }
      V v_t_2424 = heff_dup(heff_rfield(v_s_2423, 6));
      V v_r_2430;
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nothing: {
        V v_t_2425 = heff_dup(heff_rfield(v_s_2423, 5));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop_rec(v_s_2423, 8);
          heff_drop(v_t_2425);
          v_r_2430 = NTAG(TAG_RepV);
        } else {
          heff_drop(v_t_2425);
          V v_r_2426 = (g_heff_2ecompile_2erepr_2edecideOf(heff_dup(v_s_2423), heff_rfield(v_s_2423, 0)));
          switch (heff_tag_of(v_r_2426)) {
          case TAG_RepV: {
            heff_drop_rec(v_s_2423, 8);
            v_r_2430 = v_r_2426;
            break;
          }
          case TAG_RepFix: {
            heff_drop_rec(v_s_2423, 8);
            v_r_2430 = v_r_2426;
            break;
          }
          case TAG_RepF64: {
            heff_drop_rec(v_s_2423, 8);
            v_r_2430 = v_r_2426;
            break;
          }
          case TAG_RepInt: {
            V v_t_2428 = heff_get_n(v_s_2423, 7, 8);
            if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
              heff_drop(v_t_2428);
              v_r_2430 = NTAG(TAG_RepV);
            } else {
              heff_drop(v_t_2428);
              v_r_2430 = NTAG(TAG_RepInt);
            }
            break;
          }
          default: heff_nomatch(v_r_2426);
          }
        }
        break;
      }
      case TAG_Just: {
        V v_r_2429 = heff_field(v_t_2424, 0);
        heff_take_n(v_t_2424, 1ULL, 1);
        heff_drop_rec(v_s_2423, 8);
        v_r_2430 = v_r_2429;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      switch (heff_tag_of(v_r_2430)) {
      case TAG_RepV: {
        return v_m_242;
      }
      case TAG_RepFix: {
        return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2415), v_r_2430, v_m_242));
      }
      case TAG_RepF64: {
        return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2415), v_r_2430, v_m_242));
      }
      case TAG_RepInt: {
        return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2415), v_r_2430, v_m_242));
      }
      default: return heff_nomatch(v_r_2430);
      }
    }
  }
  case TAG_Pinned: {
    return v_m_242;
  }
  case TAG_Kept: {
    return v_m_242;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erepr_2ekeptOne(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erepr_2ereprsWords_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ereprsWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsWords_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ereprsWords(V v_sg_240, V v_is_241, V v_d_242) {
top: ;
  V v_evs_243 = (g_heff_2ecompile_2erepr_2ewordEvents(v_sg_240, v_is_241, v_d_242));
  V v_pins_244 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_map_2eempty_get()), v_evs_243));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_243));
  V v_evs_249 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ereprsWords_lam0, 2, 1, (V[]){v_pins_244}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  V v_parent_2410 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_map_2eempty_get()), v_evs_249));
  V v_t_2411 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2410, v_evs_249));
  return ({ V a_0 = v_parent_2410; V a_1 = v_t_2411; V a_2 = heff_dup(g_map_2eempty_get()); V a_3 = v_evs_249; V r_ = (g_list_2efoldl_24s1674844076x2137676876(a_0, a_1, a_2, a_3)); heff_drop(v_parent_2410); heff_drop(v_t_2411); heff_drop(v_evs_249); r_; });
}
V g_heff_2ecompile_2erepr_2ereprsWords_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprsWords(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2ereprsWords_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_pins_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = ({ V a_0 = v_pins_244; V a_1 = v_x_247; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_244); r_; });
  return (g_prelude_2e_2b_2b(v_t_248, v_acc_246));
}
Clo g_heff_2ecompile_2erepr_2edecidedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecidedIn_entry, 3, 0};

V g_heff_2ecompile_2erepr_2edecidedIn(V v_parent_240, V v_stats_241, V v_x_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), v_parent_240));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_x_242, v_t_243));
  HeffT2 v_t_245 = (g_map_2elookup_24s1546226666x2146984184_24cpr(v_t_244, v_stats_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_s_2410;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      v_s_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_s_2410 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
    V v_t_2411 = heff_dup(heff_rfield(v_s_2410, 6));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_dup(heff_rfield(v_s_2410, 5));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop_rec(v_s_2410, 8);
        heff_drop(v_t_2412);
        return NTAG(TAG_RepV);
      } else {
        heff_drop(v_t_2412);
        V v_r_2413 = (g_heff_2ecompile_2erepr_2edecideOf(heff_dup(v_s_2410), heff_rfield(v_s_2410, 0)));
        switch (heff_tag_of(v_r_2413)) {
        case TAG_RepV: {
          heff_drop_rec(v_s_2410, 8);
          return v_r_2413;
        }
        case TAG_RepFix: {
          heff_drop_rec(v_s_2410, 8);
          return v_r_2413;
        }
        case TAG_RepF64: {
          heff_drop_rec(v_s_2410, 8);
          return v_r_2413;
        }
        case TAG_RepInt: {
          V v_t_2415 = heff_get_n(v_s_2410, 7, 8);
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            return NTAG(TAG_RepV);
          } else {
            heff_drop(v_t_2415);
            return NTAG(TAG_RepInt);
          }
        }
        default: return heff_nomatch(v_r_2413);
        }
      }
    }
    case TAG_Just: {
      V v_r_2416 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      heff_drop_rec(v_s_2410, 8);
      return v_r_2416;
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
}
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecidedIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V v_sg_240, V v_bounces_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
  V v_t_245 = (g_list_2efoldl_24f1070132730x1847213213(NTAG(TAG_Nil), heff_dup(v_xs_242)));
  V v_t_246 = heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_xs_242), NTAG(TAG_RetClass), v_t_243});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, v_t_245, v_t_247));
  V v_evs_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_248});
  V v_pins_2410 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_map_2eempty_get()), v_evs_249));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_249));
  V v_evs_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0, 2, 1, (V[]){v_pins_2410}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V v_parent_2416 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_map_2eempty_get()), v_evs_2415));
  V v_t_2417 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2416, v_evs_2415));
  V v_f_2418 = ({ V a_0 = v_parent_2416; V a_1 = v_t_2417; V a_2 = v_xs_242; V r_ = (g_list_2emap_24s1310249268x749995235(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
  V v_f_2420;
  if ((heff_dup(v_bounces_241) == NTAG(TAG_True))) {
    heff_drop(v_evs_2415);
    heff_drop(v_parent_2416);
    v_f_2420 = NTAG(TAG_RepV);
  } else {
    V v_t_2419 = ({ V a_0 = v_parent_2416; V a_1 = v_evs_2415; V r_ = (g_heff_2ecompile_2erepr_2estatsOf(a_0, a_1)); heff_drop(v_evs_2415); r_; });
    v_f_2420 = ({ V a_0 = v_parent_2416; V a_1 = v_t_2419; V a_2 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V r_ = (g_heff_2ecompile_2erepr_2edecidedIn(a_0, a_1, a_2)); heff_drop(v_parent_2416); heff_drop(v_t_2419); r_; });
  }
  return ((HeffT2){{v_f_2418, v_f_2420}});
}
V g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_pins_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = ({ V a_0 = v_pins_2410; V a_1 = v_x_2413; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2410); r_; });
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}
V g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr(V v_parent_240, V v_evs_241, V v_bounces_242, V v_xs_243) {
top: ;
  V v_stats_244 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_240, v_evs_241));
  V v_f_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr_lam0, 1, 2, (V[]){heff_dup(v_parent_240), v_stats_244}), v_xs_243));
  V v_f_2424;
  if ((heff_dup(v_bounces_242) == NTAG(TAG_True))) {
    v_f_2424 = NTAG(TAG_RepV);
  } else {
    V v_stats_2415 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_240, v_evs_241));
    V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_parent_240));
    V v_t_2417 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_t_2416));
    HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_stats_2415; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_stats_2415); r_; });
    V v_t_2423;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_x_2422 = v_field_2420;
        v_t_2423 = v_x_2422;
      } else {
        heff_drop(v_field_2420);
        v_t_2423 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
      }
    }
    v_f_2424 = (g_heff_2ecompile_2erepr_2ehope(v_t_2423));
  }
  return ((HeffT2){{v_f_2414, v_f_2424}});
}
V g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_parent_240 = heff_env(self)[0];
  V v_stats_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_245), v_parent_240));
  V v_t_247 = ({ V a_0 = v_parent_240; V a_1 = v_x_245; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_stats_244; HeffT2 r_ = (g_map_2elookup_24s1546226666x2146984184_24cpr(a_0, a_1)); heff_drop(v_stats_244); r_; });
  V v_t_2413;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_2410;
      v_t_2413 = v_x_2412;
    } else {
      heff_drop(v_field_2410);
      v_t_2413 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
  }
  return (g_heff_2ecompile_2erepr_2ehope(v_t_2413));
}
V g_heff_2ecompile_2erepr_2ehopeSig_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2ehopeSig_24cpr(V v_sg_240, V v_bounces_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
  V v_t_245 = (g_list_2efoldl_24f1070132730x1847213213(NTAG(TAG_Nil), heff_dup(v_xs_242)));
  V v_t_246 = heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_xs_242), NTAG(TAG_RetClass), v_t_243});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, v_t_245, v_t_247));
  V v_evs_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_248});
  V v_pins_2410 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_map_2eempty_get()), v_evs_249));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_249));
  V v_evs_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ehopeSig_24cpr_lam0, 2, 1, (V[]){v_pins_2410}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  V v_t_2416 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_map_2eempty_get()), v_evs_2415));
  return ({ V a_0 = v_t_2416; V a_1 = v_evs_2415; V a_2 = v_bounces_241; V a_3 = v_xs_242; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eproposalIn_24s1922589859x1920127656_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); heff_drop(v_evs_2415); r_; });
}
V g_heff_2ecompile_2erepr_2ehopeSig_24cpr_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_pins_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = ({ V a_0 = v_pins_2410; V a_1 = v_x_2413; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2410); r_; });
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}