// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IBind 27068
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_RetAs 20415
#define TAG_RetClass 33382
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define LBL_args 9498020
#define LBL_boxedIn 304670893
#define LBL_boxedOut 854869195
#define LBL_fixed 298804110
#define LBL_kept 9783717
#define LBL_op 10312
#define LBL_params 951713969
#define LBL_pinned 958995203
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_unboxedIn 1261597312
#define LBL_unboxedOut 454817126
static uint32_t shape_args__result[] = {LBL_args, LBL_result};
static uint32_t shape_params__result[] = {LBL_params, LBL_result};
static uint32_t shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept[] = {LBL_reprs, LBL_boxedIn, LBL_unboxedIn, LBL_boxedOut, LBL_unboxedOut, LBL_pinned, LBL_kept};
V g_heff_2ecompile_2erepr_2edecideOf(V, V);
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecideOf_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2edefEvents(V, V);
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edefEvents_clo;
V g_heff_2ecompile_2erepr_2eelemS(V, V);
V g_heff_2ecompile_2erepr_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eelemS_clo;
V g_heff_2ecompile_2erepr_2eflatFields_get(void);
V g_heff_2ecompile_2erepr_2efloat1Prims_get(void);
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void);
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void);
V g_heff_2ecompile_2erepr_2efloatShape(V);
V g_heff_2ecompile_2erepr_2efloatShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efloatShape_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2efreeGo(V, V, V);
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efreeGo_clo;
V g_heff_2ecompile_2erepr_2eindexOfL(V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eindexOfL_clo;
V g_heff_2ecompile_2erepr_2ekeptOne(V, V, V, V);
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ekeptOne_clo;
V g_heff_2ecompile_2erepr_2ekeptTo(V, V);
V g_heff_2ecompile_2erepr_2ekeptTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ekeptTo_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
V g_heff_2ecompile_2erepr_2eopShape(V, V);
V g_heff_2ecompile_2erepr_2eopShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eopShape_clo;
V g_heff_2ecompile_2erepr_2eproposeSig(V, V, V, V);
V g_heff_2ecompile_2erepr_2eproposeSig_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eproposeSig_clo;
V g_heff_2ecompile_2erepr_2ereadRepr(V, V);
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereadRepr_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2erepr_2ereprsWith(V, V);
V g_heff_2ecompile_2erepr_2ereprsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsWith_clo;
V g_heff_2ecompile_2erepr_2eretName_get(void);
V g_heff_2ecompile_2erepr_2ereturned(V, V, V);
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereturned_clo;
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2eseen(V, V);
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eseen_clo;
V g_heff_2ecompile_2erepr_2esigName(V);
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esigName_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2esourceOf(V, V);
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esourceOf_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2estatsWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erepr_2estatsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsWith_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erepr_2ewalk(V, V, V);
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewalk_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1444904008x673566408(V, V);
V g_list_2efoldl_24s1444904008x673566408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1444904008x673566408_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s1854174827x1081689521(V, V);
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854174827x1081689521_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s29004368x870998936(V, V);
V g_list_2efoldl_24s29004368x870998936_entry(V self, V *a);
extern Clo g_list_2efoldl_24s29004368x870998936_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s883603918x1469273954(V, V);
V g_list_2efoldl_24s883603918x1469273954_entry(V self, V *a);
extern Clo g_list_2efoldl_24s883603918x1469273954_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1917875516x88484758(V);
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str8, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str9, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str10, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str11, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str12, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str13, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str14, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str15, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str16, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str17, 7, "Float32");
Clo g_heff_2ecompile_2erepr_2ereprEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprEq(V v_a_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_RepV: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_RepV: {
      return NTAG(TAG_True);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_RepFix: {
    V v_a1_243 = heff_field(v_a_240, 0);
    switch (heff_tag_of(v_b_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      V v_b1_244 = heff_field(v_b_241, 0);
      V v_t_245;
      switch (heff_tag_of(v_a1_243)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str0);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str1);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str2);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str3);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str4);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str5);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str6);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str7);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str8);
        break;
      }
      default: heff_nomatch(v_a1_243);
      }
      V v_t_246;
      switch (heff_tag_of(v_b1_244)) {
      case TAG_I8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str9);
        break;
      }
      case TAG_I16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str10);
        break;
      }
      case TAG_I32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str11);
        break;
      }
      case TAG_I64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str12);
        break;
      }
      case TAG_U8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str13);
        break;
      }
      case TAG_U16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str14);
        break;
      }
      case TAG_U32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str15);
        break;
      }
      case TAG_U64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str16);
        break;
      }
      case TAG_F32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str17);
        break;
      }
      default: heff_nomatch(v_b1_244);
      }
      return heff_strEq(v_t_245, v_t_246);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_RepF64: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str1, 1, ",");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str3, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str4, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str5, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str6, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str11, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2erepr_2esigName_str13, 2, "->");
Clo g_heff_2ecompile_2erepr_2esigName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esigName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2esigName(V v_s_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s2090270526x1588636862(heff_take_field(v_s_240, 0)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ecompile_2erepr_2esigName_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ecompile_2erepr_2esigName_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_t_245 = heff_get_n(v_s_240, 1, 2);
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_RepV: {
    v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str2);
    break;
  }
  case TAG_RepFix: {
    V v_w_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_w_246)) {
    case TAG_I8: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str3);
      break;
    }
    case TAG_I16: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str4);
      break;
    }
    case TAG_I32: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str5);
      break;
    }
    case TAG_I64: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str6);
      break;
    }
    case TAG_U8: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str7);
      break;
    }
    case TAG_U16: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str8);
      break;
    }
    case TAG_U32: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str9);
      break;
    }
    case TAG_U64: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str10);
      break;
    }
    case TAG_F32: {
      v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str11);
      break;
    }
    default: heff_nomatch(v_w_246);
    }
    break;
  }
  case TAG_RepF64: {
    v_t_247 = ((V)&g_heff_2ecompile_2erepr_2esigName_str12);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2erepr_2esigName_str13), v_t_247));
}
V g_heff_2ecompile_2erepr_2esigName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esigName(a[0]);
}
Clo g_heff_2ecompile_2erepr_2ereprsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprsEq(V v_as_240, V v_bs_241) {
top: ;
  switch (heff_tag_of(v_as_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_bs_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_bs_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_as_240, 0);
    V v_as2_245 = heff_field(v_as_240, 1);
    switch (heff_tag_of(v_bs_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_bs_241, 0);
      V v_bs2_247 = heff_field(v_bs_241, 1);
      V v_t_248 = (g_heff_2ecompile_2erepr_2ereprEq(v_a_244, v_b_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_as2_245;
        V t_1 = v_bs2_247;
        v_as_240 = t_0;
        v_bs_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_bs_241);
    }
  }
  default: return heff_nomatch(v_as_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2eopShape_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eopShape_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eopShape(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_242}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
  }
  case TAG_OpSub: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_245 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_244}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
  }
  case TAG_OpMul: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_246}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
  }
  case TAG_OpDiv: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_249 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_248}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
  }
  case TAG_OpRem: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2410}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  }
  case TAG_OpEq: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2412}), NTAG(TAG_RepV)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
  }
  case TAG_OpLt: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2414}), NTAG(TAG_RepV)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
  }
  case TAG_OpLe: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2416}), NTAG(TAG_RepV)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
  }
  case TAG_OpAnd: {
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2419 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2418}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
  }
  case TAG_OpOr: {
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2420}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
  }
  case TAG_OpXor: {
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2423 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2422}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
  }
  case TAG_OpShl: {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2425 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2424}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2425});
  }
  case TAG_OpShr: {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2427 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2426}), v_r_240});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2427});
  }
  case TAG_OpShow: {
    heff_drop(v_r_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_OpFromInt: {
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_args__result, (V[]){v_t_2428, v_r_240})});
  }
  case TAG_OpToInt: {
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2430 = heff_rec_n(2, shape_args__result, (V[]){v_t_2429, NTAG(TAG_RepV)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
  }
  case TAG_OpSqrt: {
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_args__result, (V[]){v_t_2431, v_r_240})});
  }
  case TAG_OpFromFloat: {
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_args__result, (V[]){v_t_2432, v_r_240})});
  }
  case TAG_OpToFloat: {
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2434 = heff_rec_n(2, shape_args__result, (V[]){v_t_2433, NTAG(TAG_RepF64)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2434});
  }
  case TAG_OpFloor: {
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2436 = heff_rec_n(2, shape_args__result, (V[]){v_t_2435, NTAG(TAG_RepV)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2eopShape_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2eopShape(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2eelemS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2eelemS(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str0, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str1, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str2, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str3, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str4, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat2Prims_str5, 8, "floatAdd");

static V g_heff_2ecompile_2erepr_2efloat2Prims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloat2Prims_st;
static V g_heff_2ecompile_2erepr_2efloat2Prims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str4), v_t_241})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat2Prims_str5), v_t_242});
}
V g_heff_2ecompile_2erepr_2efloat2Prims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloat2Prims_st)) return g_heff_2ecompile_2erepr_2efloat2Prims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloat2Prims_val, &g_heff_2ecompile_2erepr_2efloat2Prims_st, g_heff_2ecompile_2erepr_2efloat2Prims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str0, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str1, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str2, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str3, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str4, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str5, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str6, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str7, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloat1Prims_str8, 8, "floatSin");

static V g_heff_2ecompile_2erepr_2efloat1Prims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloat1Prims_st;
static V g_heff_2ecompile_2erepr_2efloat1Prims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str6), v_t_242})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloat1Prims_str8), v_t_243})});
}
V g_heff_2ecompile_2erepr_2efloat1Prims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloat1Prims_st)) return g_heff_2ecompile_2erepr_2efloat1Prims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloat1Prims_val, &g_heff_2ecompile_2erepr_2efloat1Prims_st, g_heff_2ecompile_2erepr_2efloat1Prims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str0, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str1, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatRelPrims_str2, 7, "floatLt");

static V g_heff_2ecompile_2erepr_2efloatRelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2efloatRelPrims_st;
static V g_heff_2ecompile_2erepr_2efloatRelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2erepr_2efloatRelPrims_str2), v_t_240})});
}
V g_heff_2ecompile_2erepr_2efloatRelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2efloatRelPrims_st)) return g_heff_2ecompile_2erepr_2efloatRelPrims_val;
  return heff_global(&g_heff_2ecompile_2erepr_2efloatRelPrims_val, &g_heff_2ecompile_2erepr_2efloatRelPrims_st, g_heff_2ecompile_2erepr_2efloatRelPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatShape_str0, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2erepr_2efloatShape_str1, 10, "floatFloor");
Clo g_heff_2ecompile_2erepr_2efloatShape_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efloatShape_entry, 1, 0};

V g_heff_2ecompile_2erepr_2efloatShape(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloat2Prims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_p_240);
    heff_drop(v_t_241);
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_242});
    V v_t_244 = heff_rec_n(2, shape_args__result, (V[]){v_t_243, NTAG(TAG_RepF64)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    heff_drop(v_t_241);
    V v_t_245 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloat1Prims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_245);
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
      V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){v_t_246, NTAG(TAG_RepF64)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
    } else {
      heff_drop(v_t_245);
      V v_t_248 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2erepr_2efloatRelPrims_get()); V r_ = (g_heff_2ecompile_2erepr_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_p_240);
        heff_drop(v_t_248);
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_249});
        V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){v_t_2410, NTAG(TAG_RepV)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
      } else {
        heff_drop(v_t_248);
        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2erepr_2efloatShape_str0))) {
          heff_drop(v_p_240);
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
          V v_t_2414 = heff_rec_n(2, shape_args__result, (V[]){v_t_2413, NTAG(TAG_RepF64)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
        } else {
          if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2erepr_2efloatShape_str1))) {
            V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
            V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){v_t_2416, NTAG(TAG_RepV)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
          } else {
            return NTAG(TAG_Nothing);
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2erepr_2efloatShape_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efloatShape(a[0]);
}

static V g_heff_2ecompile_2erepr_2eflatFields_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2eflatFields_st;
static V g_heff_2ecompile_2erepr_2eflatFields_init(void) {
  return MK_INT(16LL);
}
V g_heff_2ecompile_2erepr_2eflatFields_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2eflatFields_st)) return g_heff_2ecompile_2erepr_2eflatFields_val;
  return heff_global(&g_heff_2ecompile_2erepr_2eflatFields_val, &g_heff_2ecompile_2erepr_2eflatFields_st, g_heff_2ecompile_2erepr_2eflatFields_init);
}
Clo g_heff_2ecompile_2erepr_2eslotRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eslotRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eslotRepr(V v_i_240, V v_t_241) {
top: ;
  if (heff_intLt_c(v_i_240, heff_dup(g_heff_2ecompile_2erepr_2eflatFields_get()))) {
    switch (heff_tag_of(v_t_241)) {
    case TAG_FtFloat: {
      return NTAG(TAG_RepF64);
    }
    case TAG_FtFixed: {
      V v_w_243 = heff_field(v_t_241, 0);
      V v_ru_24t_241_24FtFixed = heff_take_reuse_n(v_t_241, 1ULL, 1);
      V v_t_244;
      switch (heff_tag_of(v_w_243)) {
      case TAG_I8: {
        v_t_244 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_244 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_244 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_244 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_244 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_244 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_244 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_244 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_244 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      if (heff_intEq_c(v_t_244, MK_INT(64LL))) {
        return heff_tag_at_n(v_ru_24t_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_243});
      } else {
        heff_drop(v_w_243);
        heff_drop_cell(v_ru_24t_241_24FtFixed, 1);
        return NTAG(TAG_RepV);
      }
    }
    case TAG_FtOther: {
      return NTAG(TAG_RepV);
    }
    case TAG_FtAny: {
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_t_241);
    }
  } else {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
}
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eslotRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2emayBeFlat_entry, 1, 0};

V g_heff_2ecompile_2erepr_2emayBeFlat(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_FtFloat: {
    V v_r_244;
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      v_r_244 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_241 = heff_field(v_t_240, 0);
      V v_ru_24t_240_24FtFixed = heff_take_reuse_n(v_t_240, 1ULL, 1);
      V v_t_242;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_242 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_242 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_242 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_242 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_242 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_242 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_242 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_242 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_242 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      if (heff_intEq_c(v_t_242, MK_INT(64LL))) {
        v_r_244 = heff_tag_at_n(v_ru_24t_240_24FtFixed, TAG_RepFix, 1, (V[]){v_w_241});
      } else {
        heff_drop(v_w_241);
        heff_drop_cell(v_ru_24t_240_24FtFixed, 1);
        v_r_244 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_r_244 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_r_244 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    V v_x1_246;
    switch (heff_tag_of(v_r_244)) {
    case TAG_RepV: {
      v_x1_246 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      heff_take_n(v_r_244, 0ULL, 1);
      v_x1_246 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_x1_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_r_244);
    }
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
    heff_drop(v_x1_246);
    return v_ret_24bool;
  }
  case TAG_FtFixed: {
    V v_r_2411;
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      v_r_2411 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_248 = heff_field(v_t_240, 0);
      V v_ru_24t_240_24FtFixed = heff_take_reuse_n(v_t_240, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_w_248)) {
      case TAG_I8: {
        v_t_249 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_249 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_249 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_249 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_249 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_249 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_249 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_249 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_249 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_248);
      }
      if (heff_intEq_c(v_t_249, MK_INT(64LL))) {
        v_r_2411 = heff_tag_at_n(v_ru_24t_240_24FtFixed, TAG_RepFix, 1, (V[]){v_w_248});
      } else {
        heff_drop(v_w_248);
        heff_drop_cell(v_ru_24t_240_24FtFixed, 1);
        v_r_2411 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_r_2411 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_r_2411 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    V v_x1_2413;
    switch (heff_tag_of(v_r_2411)) {
    case TAG_RepV: {
      v_x1_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      heff_take_n(v_r_2411, 0ULL, 1);
      v_x1_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_x1_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_r_2411);
    }
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2413) == NTAG(TAG_True)));
    heff_drop(v_x1_2413);
    return v_ret_24bool;
  }
  case TAG_FtOther: {
    V v_r_2417;
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      v_r_2417 = NTAG(TAG_RepF64);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2414 = heff_field(v_t_240, 0);
      V v_ru_24t_240_24FtFixed = heff_take_reuse_n(v_t_240, 1ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_w_2414)) {
      case TAG_I8: {
        v_t_2415 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2415 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2415 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2415 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2415 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2415 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2415 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2415 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2415 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_2414);
      }
      if (heff_intEq_c(v_t_2415, MK_INT(64LL))) {
        v_r_2417 = heff_tag_at_n(v_ru_24t_240_24FtFixed, TAG_RepFix, 1, (V[]){v_w_2414});
      } else {
        heff_drop(v_w_2414);
        heff_drop_cell(v_ru_24t_240_24FtFixed, 1);
        v_r_2417 = NTAG(TAG_RepV);
      }
      break;
    }
    case TAG_FtOther: {
      v_r_2417 = NTAG(TAG_RepV);
      break;
    }
    case TAG_FtAny: {
      v_r_2417 = NTAG(TAG_RepV);
      break;
    }
    default: heff_nomatch(v_t_240);
    }
    V v_x1_2419;
    switch (heff_tag_of(v_r_2417)) {
    case TAG_RepV: {
      v_x1_2419 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      heff_take_n(v_r_2417, 0ULL, 1);
      v_x1_2419 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_x1_2419 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_r_2417);
    }
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2419) == NTAG(TAG_True)));
    heff_drop(v_x1_2419);
    return v_ret_24bool;
  }
  case TAG_FtAny: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2emayBeFlat(a[0]);
}
Clo g_heff_2ecompile_2erepr_2ereadRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereadRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereadRepr(V v_x1_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
  case TAG_Just: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(v_i_242, heff_dup(g_heff_2ecompile_2erepr_2eflatFields_get()))) {
      switch (heff_tag_of(v_t_241)) {
      case TAG_FtFloat: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepF64);
      }
      case TAG_FtFixed: {
        V v_w_244 = heff_field(v_t_241, 0);
        heff_take_n(v_t_241, 1ULL, 1);
        V v_t_245;
        switch (heff_tag_of(v_w_244)) {
        case TAG_I8: {
          v_t_245 = MK_INT(8LL);
          break;
        }
        case TAG_I16: {
          v_t_245 = MK_INT(16LL);
          break;
        }
        case TAG_I32: {
          v_t_245 = MK_INT(32LL);
          break;
        }
        case TAG_I64: {
          v_t_245 = MK_INT(64LL);
          break;
        }
        case TAG_U8: {
          v_t_245 = MK_INT(8LL);
          break;
        }
        case TAG_U16: {
          v_t_245 = MK_INT(16LL);
          break;
        }
        case TAG_U32: {
          v_t_245 = MK_INT(32LL);
          break;
        }
        case TAG_U64: {
          v_t_245 = MK_INT(64LL);
          break;
        }
        case TAG_F32: {
          v_t_245 = MK_INT(32LL);
          break;
        }
        default: heff_nomatch(v_w_244);
        }
        if (heff_intEq_c(v_t_245, MK_INT(64LL))) {
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_RepFix, 1, (V[]){v_w_244});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          heff_drop(v_w_244);
          return NTAG(TAG_RepV);
        }
      }
      case TAG_FtOther: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      case TAG_FtAny: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      default: return heff_nomatch(v_t_241);
      }
    } else {
      heff_drop(v_t_241);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return NTAG(TAG_RepV);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereadRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2efourTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efourTo_entry, 1, 0};

V g_heff_2ecompile_2erepr_2efourTo(V v_i_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_i_240), MK_INT(0LL))) {
    heff_drop(v_i_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2erepr_2efourTo(heff_intSub(v_i_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(4LL), v_t_242);
  }
}
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efourTo(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2erepr_2eretName_str0, 4, "$ret");

static V g_heff_2ecompile_2erepr_2eretName_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2eretName_st;
static V g_heff_2ecompile_2erepr_2eretName_init(void) {
  return ((V)&g_heff_2ecompile_2erepr_2eretName_str0);
}
V g_heff_2ecompile_2erepr_2eretName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2eretName_st)) return g_heff_2ecompile_2erepr_2eretName_val;
  return heff_global(&g_heff_2ecompile_2erepr_2eretName_val, &g_heff_2ecompile_2erepr_2eretName_st, g_heff_2ecompile_2erepr_2eretName_init);
}
Clo g_heff_2ecompile_2erepr_2eindexOfL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eindexOfL_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eindexOfL(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(v_l_240), heff_dup(v_k_243))) {
      heff_drop(v_l_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erepr_2eindexOfL(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erepr_2esourceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esourceOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2esourceOf(V v_x_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SGlobal: {
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SInt: {
    V v_ru_24v_241_24SInt = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SInt, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SFloat: {
    heff_take_n(v_v_241, 0ULL, 1);
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepF64)});
  }
  case TAG_SStr: {
    V v_ru_24v_241_24SStr = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SStr, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SBytes: {
    V v_ru_24v_241_24SBytes = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SBytes, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SFixed: {
    V v_w_248 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SFixed = heff_take_reuse_n(v_v_241, 1ULL, 2);
    return heff_tag_at_n(v_ru_24v_241_24SFixed, TAG_Literal, 2, (V[]){v_x_240, heff_tag_n(TAG_RepFix, 1, (V[]){v_w_248})});
  }
  case TAG_SFloat32: {
    V v_ru_24v_241_24SFloat32 = heff_take_reuse_n(v_v_241, 0ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24v_241_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, v_t_2411});
  }
  case TAG_SPrimFn: {
    V v_ru_24v_241_24SPrimFn = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SPrimFn, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_STag: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SRec: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SProj: {
    V v_l_2420 = heff_field(v_v_241, 1);
    V v_sh_2421 = heff_field(v_v_241, 2);
    V v_t_2422 = heff_field(v_v_241, 3);
    heff_take_n(v_v_241, 14ULL, 4);
    V v_t_2423 = ({ V a_0 = v_l_2420; V a_1 = MK_INT(0LL); V a_2 = v_sh_2421; V r_ = (g_heff_2ecompile_2erepr_2eindexOfL(a_0, a_1, a_2)); heff_drop(v_sh_2421); r_; });
    V v_r_2424 = (g_heff_2ecompile_2erepr_2ereadRepr(v_t_2423, v_t_2422));
    switch (heff_tag_of(v_r_2424)) {
    case TAG_RepV: {
      return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
    }
    case TAG_RepFix: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2424});
    }
    case TAG_RepF64: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2424});
    }
    default: return heff_nomatch(v_r_2424);
    }
  }
  case TAG_SPrim: {
    V v_p_2426 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SPrim = heff_take_reuse_n(v_v_241, 1ULL, 2);
    V v_x2_2428 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2426)));
    V v_x1_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nothing: {
      v_x1_2431 = (g_heff_2ecompile_2erepr_2efloatShape(heff_dup(v_p_2426)));
      break;
    }
    case TAG_Just: {
      V v_fp_2429 = heff_field(v_x2_2428, 0);
      V v_ru_24x2_2428_24Just = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_2428_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_2429, 0))});
      v_x1_2431 = ({ V a_0 = v_t_2430; V b_1 = heff_get_n(v_fp_2429, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_r_2433;
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nothing: {
      v_r_2433 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_s_2432 = heff_field(v_x1_2431, 0);
      heff_take_n(v_x1_2431, 1ULL, 1);
      v_r_2433 = heff_get_n(v_s_2432, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_2431);
    }
    V v_t_2435;
    switch (heff_tag_of(v_r_2433)) {
    case TAG_RepV: {
      v_t_2435 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      heff_take_n(v_r_2433, 0ULL, 1);
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_2435 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_r_2433);
    }
    if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
      heff_drop(v_p_2426);
      heff_drop_cell(v_ru_24v_241_24SPrim, 2);
      heff_drop(v_t_2435);
      return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
    } else {
      heff_drop(v_t_2435);
      V v_x2_2436 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2426)));
      V v_x1_2439;
      switch (heff_tag_of(v_x2_2436)) {
      case TAG_Nothing: {
        v_x1_2439 = (g_heff_2ecompile_2erepr_2efloatShape(v_p_2426));
        break;
      }
      case TAG_Just: {
        V v_fp_2437 = heff_field(v_x2_2436, 0);
        V v_ru_24x2_2436_24Just = heff_take_reuse_n(v_x2_2436, 1ULL, 1);
        heff_drop(v_p_2426);
        V v_t_2438 = heff_tag_at_n(v_ru_24x2_2436_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_2437, 0))});
        v_x1_2439 = ({ V a_0 = v_t_2438; V b_1 = heff_get_n(v_fp_2437, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2436);
      }
      V v_t_2441;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_Nothing: {
        v_t_2441 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Just: {
        V v_s_2440 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2441 = heff_get_n(v_s_2440, 1, 2);
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2441});
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esourceOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2erepr_2efreeGo(V v_bs_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_bs_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_bs_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), NTAG(TAG_MkUnit), v_bs_240));
      V t_0 = v_t_246;
      V t_1 = v_xs_244;
      V t_2 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      v_bs_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_bs_240;
      V t_1 = v_xs_244;
      V t_2 = v_acc_242;
      v_bs_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efreeGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2ereturned_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereturned_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ereturned(V v_x1_240, V v_o_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RetAs: {
    V v_r_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24RetAs = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_o_241)) {
    case TAG_OSimple: {
      V v_v_244 = heff_field(v_o_241, 0);
      heff_take_n(v_o_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24RetAs, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_r_243, v_v_244}), v_rest_242});
    }
    case TAG_OCall: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OApply: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OPrim: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OAbandon: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    case TAG_OBool: {
      heff_drop(v_r_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24RetAs, TAG_IOp, 1, (V[]){v_o_241}), v_rest_242});
    }
    default: return heff_nomatch(v_o_241);
    }
  }
  case TAG_RetClass: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_o_241}), v_rest_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereturned_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereturned(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewalk_entry, 3, 0};

V g_heff_2ecompile_2erepr_2ewalk(V v_sg_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_r_245 = heff_field(v_x31_243, 0);
      V v_x312_246 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24IVal = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_246)) {
      case TAG_SVar: {
        V v_x_247 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Wants, 2, (V[]){v_x_247, v_r_245}), v_acc_241});
        V t_0 = v_sg_240;
        V t_1 = v_t_248;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x312_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x312_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2418 = heff_field(v_x312_246, 0);
        V v_x3122_2419 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 3ULL, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        switch (heff_tag_of(v_x3122_2419)) {
        case TAG_MkBlock: {
          V v_t_2420 = heff_field(v_x3122_2419, 0);
          V v_ru_24x3122_2419_24MkBlock = heff_take_reuse_n(v_x3122_2419, 1ULL, 1);
          V v_t_2421 = heff_tag_at_n(v_ru_24x3122_2419_24MkBlock, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
          V v_t_2422 = heff_tag_n(TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2421, v_t_2420});
          V v_t_2423 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
          V v_evs_2424 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_Nil), v_t_2423));
          V v_t_2425 = (g_prelude_2e_2b_2b(heff_dup(v_evs_2424), v_acc_241));
          V v_t_2426 = (g_list_2efoldl_24s2096135476x728523350(v_t_2425, heff_dup(v_xs_2418)));
          V v_t_2427 = (g_list_2efoldl_24s1694506840x958926808(heff_dup(g_map_2eempty_get()), v_evs_2424));
          V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_xs_2418; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2418); r_; });
          V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2424));
          V v_t_2430 = (g_list_2efoldl_24s883603918x1469273954(NTAG(TAG_Nil), v_t_2429));
          V v_t_2431 = (g_heff_2ecompile_2erepr_2efreeGo(v_t_2428, v_t_2430, NTAG(TAG_Nil)));
          V v_t_2432 = (g_list_2efoldl_24s29004368x870998936(v_t_2426, v_t_2431));
          V t_0 = v_sg_240;
          V t_1 = v_t_2432;
          V t_2 = v_rest_244;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3122_2419);
        }
      }
      case TAG_STag: {
        V v_as_2434 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2434));
        V v_t_2436 = (g_list_2efoldl_24s1444904008x673566408(v_rest_244, v_t_2435));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2436;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2437 = heff_field(v_x312_246, 0);
        V v_ts_2438 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_t_2439 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ts_2438));
        V v_t_2440 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2439, MK_INT(1LL))));
        V v_rs_2441 = (g_list_2ezipWith_24s1713677103x1107896282(v_t_2440, v_ts_2438));
        V v_vs_2442 = (g_list_2emap_24s1173914895x100384474(v_fs_2437));
        V v_t_2443 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2441, v_vs_2442));
        V v_t_2444 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_2443));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2444;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2445 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 4);
        heff_drop(v_r_245);
        V v_t_2449 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_2445});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_at_n(v_ru_24x31_243_24IVal, TAG_Cons, 2, (V[]){v_t_2449, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrim: {
        V v_p_2450 = heff_field(v_x312_246, 0);
        V v_as_2451 = heff_field(v_x312_246, 1);
        heff_take_n(v_x312_246, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_r_245);
        heff_drop_cell(v_ru_24x31_243_24IVal, 2);
        V v_x2_2452 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2450)));
        V v_x1_2455;
        switch (heff_tag_of(v_x2_2452)) {
        case TAG_Nothing: {
          v_x1_2455 = (g_heff_2ecompile_2erepr_2efloatShape(v_p_2450));
          break;
        }
        case TAG_Just: {
          V v_fp_2453 = heff_field(v_x2_2452, 0);
          V v_ru_24x2_2452_24Just = heff_take_reuse_n(v_x2_2452, 1ULL, 1);
          heff_drop(v_p_2450);
          V v_t_2454 = heff_tag_at_n(v_ru_24x2_2452_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_2453, 0))});
          v_x1_2455 = ({ V a_0 = v_t_2454; V b_1 = heff_get_n(v_fp_2453, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2452);
        }
        V v_rs_2457;
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_Nothing: {
          v_rs_2457 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_2451)));
          break;
        }
        case TAG_Just: {
          V v_s_2456 = heff_field(v_x1_2455, 0);
          heff_take_n(v_x1_2455, 1ULL, 1);
          v_rs_2457 = heff_get_n(v_s_2456, 0, 2);
          break;
        }
        default: heff_nomatch(v_x1_2455);
        }
        V v_t_2458 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2457, v_as_2451));
        V v_t_2459 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_2458));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_2459;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_246);
      }
    }
    case TAG_IBind: {
      V v_x_2460 = heff_field(v_x31_243, 0);
      V v_x312_2461 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24IBind = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_2461)) {
      case TAG_OSimple: {
        V v_x3121_2462 = heff_field(v_x312_2461, 0);
        heff_take_n(v_x312_2461, 1ULL, 1);
        switch (heff_tag_of(v_x3121_2462)) {
        case TAG_SVar: {
          V v_y_2463 = heff_field(v_x3121_2462, 0);
          heff_take_n(v_x3121_2462, 1ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24IBind, 2);
          V v_t_2464 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Merge, 2, (V[]){v_x_2460, v_y_2463}), v_acc_241});
          V t_0 = v_sg_240;
          V t_1 = v_t_2464;
          V t_2 = v_rest_244;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SGlobal: {
          V v_t_2466 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2467 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2466, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SInt: {
          V v_t_2469 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2470 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2469, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SFloat: {
          V v_t_2472 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2473 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2472, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SStr: {
          V v_t_2475 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2476 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2475, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SBytes: {
          V v_t_2478 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2479 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2478, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SFixed: {
          V v_t_2482 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2483 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2482, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SFloat32: {
          V v_t_2485 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2486 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2485, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SPrimFn: {
          V v_t_2488 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2489 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2488, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SLam: {
          V v_t_2492 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2493 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2492, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2493, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_STag: {
          V v_t_2496 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_2497 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_2496, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SRec: {
          V v_t_24100 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_24101 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_24100, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24101, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SProj: {
          V v_t_24106 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_24107 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_24106, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SPrim: {
          V v_t_24110 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2460, heff_dup(v_x3121_2462)));
          V v_t_24111 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x3121_2462});
          V t_0 = v_sg_240;
          V t_1 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){v_t_24110, v_acc_241});
          V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, v_rest_244});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3121_2462);
        }
      }
      case TAG_OCall: {
        V v_g_24112 = heff_field(v_x312_2461, 0);
        V v_as_24113 = heff_field(v_x312_2461, 1);
        V v_ru_24x312_2461_24OCall = heff_take_reuse_n(v_x312_2461, 3ULL, 2);
        V v_x1_24114 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_24112), v_sg_240));
        V v_r_24116;
        switch (heff_tag_of(v_x1_24114)) {
        case TAG_Nothing: {
          v_r_24116 = NTAG(TAG_RepV);
          break;
        }
        case TAG_Just: {
          V v_s_24115 = heff_field(v_x1_24114, 0);
          heff_take_n(v_x1_24114, 1ULL, 1);
          v_r_24116 = heff_get_n(v_s_24115, 1, 2);
          break;
        }
        default: heff_nomatch(v_x1_24114);
        }
        V v_t_24118;
        switch (heff_tag_of(v_r_24116)) {
        case TAG_RepV: {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_t_24118 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_2460});
          break;
        }
        case TAG_RepFix: {
          v_t_24118 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Unboxed, 2, (V[]){v_x_2460, v_r_24116});
          break;
        }
        case TAG_RepF64: {
          v_t_24118 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Unboxed, 2, (V[]){v_x_2460, v_r_24116});
          break;
        }
        default: heff_nomatch(v_r_24116);
        }
        V v_t_24119 = heff_tag_n(TAG_IOp, 1, (V[]){heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_OCall, 2, (V[]){v_g_24112, v_as_24113})});
        V t_0 = v_sg_240;
        V t_1 = heff_tag_at_n(v_ru_24x312_2461_24OCall, TAG_Cons, 2, (V[]){v_t_24118, v_acc_241});
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24119, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_t_24122 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_2460}), v_acc_241});
        V v_t_24123 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x312_2461}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_t_24122;
        V t_2 = v_t_24123;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_t_24126 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_2460}), v_acc_241});
        V v_t_24127 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x312_2461}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_t_24126;
        V t_2 = v_t_24127;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_x_2460);
        heff_drop_cell(v_ru_24x31_243_24IBind, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_t_24129 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_2460}), v_acc_241});
        V v_t_24130 = heff_tag_at_n(v_ru_24x31_243_24IBind, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x312_2461}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_t_24129;
        V t_2 = v_t_24130;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_2461);
      }
    }
    case TAG_IOp: {
      V v_x311_24131 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24131)) {
      case TAG_OSimple: {
        V v_v_24132 = heff_field(v_x311_24131, 0);
        heff_take_n(v_x311_24131, 1ULL, 1);
        V v_t_24133 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24132});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24133, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_g_24134 = heff_field(v_x311_24131, 0);
        V v_as_24135 = heff_field(v_x311_24131, 1);
        heff_take_n(v_x311_24131, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x2_24136 = (g_map_2elookup_24s1546226666x2146984184(v_g_24134, v_sg_240));
        V v_rs_24138;
        switch (heff_tag_of(v_x2_24136)) {
        case TAG_Nothing: {
          v_rs_24138 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_24135)));
          break;
        }
        case TAG_Just: {
          V v_s_24137 = heff_field(v_x2_24136, 0);
          heff_take_n(v_x2_24136, 1ULL, 1);
          v_rs_24138 = heff_get_n(v_s_24137, 0, 2);
          break;
        }
        default: heff_nomatch(v_x2_24136);
        }
        V v_t_24139 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24138, v_as_24135));
        V v_t_24140 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_24139));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24140;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_24141 = heff_field(v_x311_24131, 0);
        V v_as_24142 = heff_field(v_x311_24131, 1);
        heff_take_n(v_x311_24131, 3ULL, 2);
        V v_t_24143 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_24141, v_as_24142})));
        V v_t_24144 = (g_list_2efoldl_24s1444904008x673566408(v_rest_244, v_t_24143));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24144;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_24146 = heff_field(v_x311_24131, 1);
        heff_take_n(v_x311_24131, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_24147 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_24146));
        V v_t_24148 = (g_list_2efoldl_24s1444904008x673566408(v_rest_244, v_t_24147));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24148;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_24149 = heff_field(v_x311_24131, 0);
        heff_take_n(v_x311_24131, 1ULL, 1);
        V v_t_24150 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24149}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24150;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24131);
      }
    }
    case TAG_ICond: {
      V v_x311_24151 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24151)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_p_24152 = heff_field(v_x311_24151, 0);
        V v_a_24153 = heff_field(v_x311_24151, 1);
        V v_b_24154 = heff_field(v_x311_24151, 2);
        heff_take_n(v_x311_24151, 7ULL, 3);
        V v_x2_24155 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_24152)));
        V v_x1_24158;
        switch (heff_tag_of(v_x2_24155)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x31_243_24ICond, 1);
          v_x1_24158 = (g_heff_2ecompile_2erepr_2efloatShape(v_p_24152));
          break;
        }
        case TAG_Just: {
          V v_fp_24156 = heff_field(v_x2_24155, 0);
          heff_take_n(v_x2_24155, 1ULL, 1);
          heff_drop(v_p_24152);
          V v_t_24157 = heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_24156, 0))});
          v_x1_24158 = ({ V a_0 = v_t_24157; V b_1 = heff_get_n(v_fp_24156, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24155);
        }
        V v_rs_24161;
        switch (heff_tag_of(v_x1_24158)) {
        case TAG_Nothing: {
          V v_t_24159 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_24154), NTAG(TAG_Nil)});
          v_rs_24161 = (g_list_2emap_24s1598879313x231311047(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_24153), v_t_24159})));
          break;
        }
        case TAG_Just: {
          V v_s_24160 = heff_field(v_x1_24158, 0);
          heff_take_n(v_x1_24158, 1ULL, 1);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          v_rs_24161 = heff_get_n(v_s_24160, 0, 2);
          break;
        }
        default: heff_nomatch(v_x1_24158);
        }
        V v_t_24162 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24154, NTAG(TAG_Nil)});
        V v_t_24163 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24161, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24153, v_t_24162})));
        V v_t_24164 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_244, v_t_24163));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24164;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_24165 = heff_field(v_x311_24151, 0);
        heff_take_n(v_x311_24151, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24166 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24165});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24166, v_rest_244});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_24167 = heff_field(v_x311_24151, 0);
        heff_take_n(v_x311_24151, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_24168 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24167}), v_rest_244});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24168;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_24169 = heff_field(v_x311_24151, 0);
        V v_b_24170 = heff_field(v_x311_24151, 1);
        V v_c_24171 = heff_field(v_x311_24151, 2);
        heff_take_n(v_x311_24151, 7ULL, 3);
        V v_t_24172 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24171}), v_rest_244});
        V v_t_24173 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_24170}), v_t_24172});
        V v_t_24174 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_24169}), v_t_24173});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24174;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_x_24175 = heff_field(v_x311_24151, 0);
        V v_o_24176 = heff_field(v_x311_24151, 1);
        V v_c_24177 = heff_field(v_x311_24151, 2);
        heff_take_n(v_x311_24151, 7ULL, 3);
        V v_t_24178 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24175)}), v_acc_241});
        V v_t_24179 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_c_24177}), v_rest_244});
        V v_t_24180 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24175, v_o_24176}), v_t_24179});
        V t_0 = v_sg_240;
        V t_1 = v_t_24178;
        V t_2 = v_t_24180;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24151);
      }
    }
    case TAG_ISts: {
      V v_x311_24181 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24181)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_rest_244;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_24182 = heff_field(v_x311_24181, 0);
        V v_ss_24183 = heff_field(v_x311_24181, 1);
        V v_ru_24x311_24181_24Cons = heff_take_reuse_n(v_x311_24181, 3ULL, 2);
        switch (heff_tag_of(v_x3111_24182)) {
        case TAG_SLet: {
          V v_x_24184 = heff_field(v_x3111_24182, 0);
          V v_o_24185 = heff_field(v_x3111_24182, 1);
          V v_ru_24x3111_24182_24SLet = heff_take_reuse_n(v_x3111_24182, 3ULL, 2);
          V v_t_24186 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24184)}), v_acc_241});
          V v_t_24187 = heff_tag_at_n(v_ru_24x311_24181_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24183}), v_rest_244});
          V v_t_24188 = heff_tag_at_n(v_ru_24x3111_24182_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24184, v_o_24185}), v_t_24187});
          V t_0 = v_sg_240;
          V t_1 = v_t_24186;
          V t_2 = v_t_24188;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_24189 = heff_field(v_x3111_24182, 0);
          heff_take_n(v_x3111_24182, 1ULL, 1);
          V v_t_24190 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){v_x_24189}), v_acc_241});
          V v_t_24191 = heff_tag_at_n(v_ru_24x311_24181_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24183}), v_rest_244});
          V t_0 = v_sg_240;
          V t_1 = v_t_24190;
          V t_2 = v_t_24191;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_x_24192 = heff_field(v_x3111_24182, 0);
          V v_o_24193 = heff_field(v_x3111_24182, 1);
          heff_take_n(v_x3111_24182, 3ULL, 2);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_24194 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24183}), v_rest_244});
          V v_t_24195 = heff_tag_at_n(v_ru_24x311_24181_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24192, v_o_24193}), v_t_24194});
          V t_0 = v_sg_240;
          V t_1 = v_acc_241;
          V t_2 = v_t_24195;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24196 = heff_field(v_x3111_24182, 0);
          V v_ts_24197 = heff_field(v_x3111_24182, 1);
          V v_fs_24198 = heff_field(v_x3111_24182, 2);
          heff_take_n(v_x3111_24182, 7ULL, 3);
          V v_t_24199 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24183}), v_rest_244});
          V v_t_24200 = heff_tag_at_n(v_ru_24x311_24181_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_24198}), v_t_24199});
          V v_t_24201 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24197}), v_t_24200});
          V v_t_24202 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24196}), v_t_24201});
          V t_0 = v_sg_240;
          V t_1 = v_acc_241;
          V t_2 = v_t_24202;
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24203 = heff_field(v_x3111_24182, 0);
          V v_arms_24204 = heff_field(v_x3111_24182, 1);
          V v_ru_24x3111_24182_24SCase = heff_take_reuse_n(v_x3111_24182, 3ULL, 2);
          V v_t_24205 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_24204)));
          V v_xs_24206 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24205; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_24205); r_; });
          V v_t_24207 = (g_list_2efoldl_24s964765707x1396946999(v_acc_241, v_xs_24206));
          V v_t_24208 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24203});
          V v_t_24209 = heff_tag_at_n(v_ru_24x311_24181_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_ss_24183}), v_rest_244});
          V v_t_24210 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24204));
          V v_t_24211 = (g_list_2efoldl_24s1104809983x118204267(v_t_24209, v_t_24210));
          V t_0 = v_sg_240;
          V t_1 = v_t_24207;
          V t_2 = heff_tag_at_n(v_ru_24x3111_24182_24SCase, TAG_Cons, 2, (V[]){v_t_24208, v_t_24211});
          v_sg_240 = t_0;
          v_acc_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_24182);
        }
      }
      default: return heff_nomatch(v_x311_24181);
      }
    }
    case TAG_ITl: {
      V v_ps_24212 = heff_field(v_x31_243, 0);
      V v_rt_24213 = heff_field(v_x31_243, 1);
      V v_x313_24214 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      switch (heff_tag_of(v_x313_24214)) {
      case TAG_TSeq: {
        V v_ss_24215 = heff_field(v_x313_24214, 0);
        V v_t_24216 = heff_field(v_x313_24214, 1);
        V v_ru_24x313_24214_24TSeq = heff_take_reuse_n(v_x313_24214, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24217 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){v_ps_24212, v_rt_24213, v_t_24216}), v_rest_244});
        V v_t_24218 = heff_tag_at_n(v_ru_24x313_24214_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24215}), v_t_24217});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24218;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24219 = heff_field(v_x313_24214, 0);
        heff_take_n(v_x313_24214, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_ps_24212);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24220 = (g_heff_2ecompile_2erepr_2ereturned(v_rt_24213, v_o_24219, v_rest_244));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24220;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24221 = heff_field(v_x313_24214, 0);
        heff_take_n(v_x313_24214, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_rt_24213);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24222 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ps_24212, v_vs_24221));
        V v_t_24223 = (g_list_2efoldl_24s348204425x880103432(v_rest_244, v_t_24222));
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24223;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24224 = heff_field(v_x313_24214, 0);
        V v_t_24225 = heff_field(v_x313_24214, 1);
        V v_e_24226 = heff_field(v_x313_24214, 2);
        heff_take_n(v_x313_24214, 7ULL, 3);
        V v_t_24227 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_ps_24212), heff_dup(v_rt_24213), v_e_24226}), v_rest_244});
        V v_t_24228 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 3, (V[]){v_ps_24212, v_rt_24213, v_t_24225}), v_t_24227});
        V v_t_24229 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24224}), v_t_24228});
        V t_0 = v_sg_240;
        V t_1 = v_acc_241;
        V t_2 = v_t_24229;
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24230 = heff_field(v_x313_24214, 0);
        V v_arms_24231 = heff_field(v_x313_24214, 1);
        V v_ru_24x313_24214_24TCase = heff_take_reuse_n(v_x313_24214, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 3);
        V v_t_24232 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_24231)));
        V v_xs_24233 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24232; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_24232); r_; });
        V v_t_24234 = (g_list_2efoldl_24s964765707x1396946999(v_acc_241, v_xs_24233));
        V v_t_24235 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24230});
        V v_t_24236 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24231));
        V v_t_24242 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam0, 2, 2, (V[]){v_ps_24212, v_rt_24213}); V a_1 = v_rest_244; V a_2 = v_t_24236; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24236); r_; });
        V t_0 = v_sg_240;
        V t_1 = v_t_24234;
        V t_2 = heff_tag_at_n(v_ru_24x313_24214_24TCase, TAG_Cons, 2, (V[]){v_t_24235, v_t_24242});
        v_sg_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x313_24214);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2ewalk(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args) {
  V v_acc_24237 = args[0];
  V v_x_24238 = args[1];
  V v_ps_24212 = heff_env(self)[0];
  V v_rt_24213 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_24238)) {
  case TAG_MkArm: {
    V v_t_24241 = heff_field(v_x_24238, 2);
    V v_ru_24x_24238_24MkArm = heff_take_reuse_n(v_x_24238, 4ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x_24238_24MkArm, TAG_ITl, 3, (V[]){v_ps_24212, v_rt_24213, v_t_24241}), v_acc_24237});
  }
  default: return heff_nomatch(v_x_24238);
  }
}
Clo g_heff_2ecompile_2erepr_2edefEvents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edefEvents_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edefEvents(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkDef: {
    V v_key_242 = heff_field(v_x2_241, 0);
    V v_x23_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24MkDef = heff_take_reuse_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x23_244)) {
    case TAG_DefFun: {
      V v_xs_245 = heff_field(v_x23_244, 0);
      V v_x232_246 = heff_field(v_x23_244, 1);
      V v_ru_24x23_244_24DefFun = heff_take_reuse_n(v_x23_244, 3ULL, 2);
      switch (heff_tag_of(v_x232_246)) {
      case TAG_MkBlock: {
        V v_t_247 = heff_field(v_x232_246, 0);
        heff_take_n(v_x232_246, 1ULL, 1);
        V v_x2_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_242), v_sg_240));
        V v_t_2410;
        switch (heff_tag_of(v_x2_248)) {
        case TAG_Nothing: {
          v_t_2410 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_245)));
          break;
        }
        case TAG_Just: {
          V v_s_249 = heff_field(v_x2_248, 0);
          heff_take_n(v_x2_248, 1ULL, 1);
          v_t_2410 = heff_get_n(v_s_249, 0, 2);
          break;
        }
        default: heff_nomatch(v_x2_248);
        }
        V v_t_2411 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2410));
        V v_t_2412 = (g_list_2efoldl_24s1854174827x1081689521(NTAG(TAG_Nil), v_t_2411));
        V v_x1_2413 = (g_map_2elookup_24s1546226666x2146984184(v_key_242, v_sg_240));
        V v_t_2415;
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_Nothing: {
          v_t_2415 = NTAG(TAG_RepV);
          break;
        }
        case TAG_Just: {
          V v_s_2414 = heff_field(v_x1_2413, 0);
          heff_take_n(v_x1_2413, 1ULL, 1);
          v_t_2415 = heff_get_n(v_s_2414, 1, 2);
          break;
        }
        default: heff_nomatch(v_x1_2413);
        }
        V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){v_xs_245, heff_tag_n(TAG_RetAs, 1, (V[]){v_t_2415}), v_t_247});
        V v_t_2417 = heff_tag_at_n(v_ru_24x23_244_24DefFun, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, v_t_2412, v_t_2417));
      }
      default: return heff_nomatch(v_x232_246);
      }
    }
    case TAG_DefVal: {
      V v_x231_2418 = heff_field(v_x23_244, 0);
      V v_ru_24x23_244_24DefVal = heff_take_reuse_n(v_x23_244, 1ULL, 1);
      heff_drop(v_key_242);
      switch (heff_tag_of(v_x231_2418)) {
      case TAG_MkBlock: {
        V v_t_2419 = heff_field(v_x231_2418, 0);
        heff_take_n(v_x231_2418, 1ULL, 1);
        V v_t_2420 = heff_tag_at_n(v_ru_24x23_244_24DefVal, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
        V v_t_2421 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2420, v_t_2419});
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_Nil), v_t_2422));
      }
      default: return heff_nomatch(v_x231_2418);
      }
    }
    default: return heff_nomatch(v_x23_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2edefEvents(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2erootFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2erootFrom_entry, 3, 0};

V g_heff_2ecompile_2erepr_2erootFrom(V v_parent_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return v_x_241;
  }
  case TAG_Just: {
    V v_y_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_x_241), heff_dup(v_y_243))) {
      heff_drop(v_y_243);
      return v_x_241;
    } else {
      heff_drop(v_x_241);
      V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_y_243), v_parent_240));
      V t_0 = v_parent_240;
      V t_1 = v_y_243;
      V t_2 = v_t_245;
      v_parent_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2erootFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2eunite_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunite_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eunite(V v_parent_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_a_241), v_parent_240));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_a_241), v_t_243));
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_b_242), v_parent_240));
  V v_t_246 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_b_242), v_t_245));
  if (heff_strEq_c(v_t_244, v_t_246)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return v_parent_240;
  } else {
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_a_241), v_parent_240));
    V v_t_249 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_a_241, v_t_248));
    V v_t_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_b_242), v_parent_240));
    V v_t_2411 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_b_242, v_t_2410));
    HEFF_LAST return g_map_2einsert_24s1341440536x470972936(v_t_249, v_t_2411, v_parent_240);
  }
}
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eunite(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2eunpinOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunpinOne_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eunpinOne(V v_pins_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Merge: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_y_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24Merge = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_pins_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_y_243), v_pins_240));
      switch (heff_tag_of(v_x3_245)) {
      case TAG_Nothing: {
        return heff_tag_at_n(v_ru_24e_241_24Merge, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Merge, 2, (V[]){v_x_242, v_y_243}), NTAG(TAG_Nil)});
      }
      case TAG_Just: {
        V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 0ULL, 1);
        V v_t_247 = heff_tag_at_n(v_ru_24e_241_24Merge, TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Boxed, 1, (V[]){v_x_242}), v_t_248});
      }
      default: return heff_nomatch(v_x3_245);
      }
    }
    case TAG_Just: {
      V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 0ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24e_241_24Merge, TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Boxed, 1, (V[]){v_x_242}), v_t_2411});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_Boxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Unboxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Literal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Wants: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Binds: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Pinned: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Kept: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eunpinOne(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ecompile_2erepr_2enoStats_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2enoStats_st;
static V g_heff_2ecompile_2erepr_2enoStats_init(void) {
  return heff_rec_n(7, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept, (V[]){NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nothing)});
}
V g_heff_2ecompile_2erepr_2enoStats_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2enoStats_st)) return g_heff_2ecompile_2erepr_2enoStats_val;
  return heff_global(&g_heff_2ecompile_2erepr_2enoStats_val, &g_heff_2ecompile_2erepr_2enoStats_st, g_heff_2ecompile_2erepr_2enoStats_init);
}
Clo g_heff_2ecompile_2erepr_2estatsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsWith_entry, 7, 0};

V g_heff_2ecompile_2erepr_2estatsWith(V v_r_240, V v_bi_241, V v_ui_242, V v_bo_243, V v_uo_244, V v_pin_245, V v_s_246) {
top: ;
  V v_rs_247 = heff_take_field(v_s_246, 0);
  V v_t_2413;
  switch (heff_tag_of(v_r_240)) {
  case TAG_RepV: {
    v_t_2413 = v_rs_247;
    break;
  }
  case TAG_RepFix: {
    V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2ereprEq_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_t_2410 = (g_list_2eany(v_t_249, v_rs_247));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop_tag(v_r_240, 1);
      heff_drop(v_t_2410);
      v_t_2413 = v_rs_247;
    } else {
      heff_drop(v_t_2410);
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_247});
    }
    break;
  }
  case TAG_RepF64: {
    V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2ereprEq_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_t_2412 = (g_list_2eany(v_t_2411, v_rs_247));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      v_t_2413 = v_rs_247;
    } else {
      heff_drop(v_t_2412);
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_247});
    }
    break;
  }
  default: heff_nomatch(v_r_240);
  }
  V v_t_2414 = heff_intAdd(heff_take_field(v_s_246, 1), v_bi_241);
  V v_t_2415 = heff_intAdd(heff_take_field(v_s_246, 2), v_ui_242);
  V v_t_2416 = heff_intAdd(heff_take_field(v_s_246, 3), v_bo_243);
  V v_t_2417 = heff_intAdd(heff_take_field(v_s_246, 4), v_uo_244);
  V v_t_2418 = heff_take_field(v_s_246, 5);
  V v_t_2419;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_pin_245);
    heff_drop(v_t_2418);
    v_t_2419 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2418);
    v_t_2419 = v_pin_245;
  }
  return ({ V rv_0 = v_t_2413; V rv_1 = v_t_2414; V rv_2 = v_t_2415; V rv_3 = v_t_2416; V rv_4 = v_t_2417; V rv_5 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_246, 64ULL, 7, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept, 12288u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ecompile_2erepr_2estatsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2estatsWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2erepr_2ekeptTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ekeptTo_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ekeptTo(V v_r_240, V v_s_241) {
top: ;
  V v_rs_242 = heff_take_field(v_s_241, 0);
  V v_t_248;
  switch (heff_tag_of(v_r_240)) {
  case TAG_RepV: {
    v_t_248 = v_rs_242;
    break;
  }
  case TAG_RepFix: {
    V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2ereprEq_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_rs_242));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_248 = v_rs_242;
    } else {
      heff_drop(v_t_245);
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_rs_242});
    }
    break;
  }
  case TAG_RepF64: {
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2ereprEq_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_t_247 = (g_list_2eany(v_t_246, v_rs_242));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = v_rs_242;
    } else {
      heff_drop(v_t_247);
      v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_rs_242});
    }
    break;
  }
  default: heff_nomatch(v_r_240);
  }
  return ({ V rv_0 = v_t_248; V rv_6 = heff_tag_n(TAG_Just, 1, (V[]){v_r_240}); V rr_ = heff_rec_reuse_nf(v_s_241, 62ULL, 7, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ecompile_2erepr_2ekeptTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ekeptTo(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2eseen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eseen_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eseen(V v_e_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Merge: {
    return v_s_241;
  }
  case TAG_Boxed: {
    return (g_heff_2ecompile_2erepr_2estatsWith(NTAG(TAG_RepV), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), v_s_241));
  }
  case TAG_Unboxed: {
    V v_r_246 = heff_field(v_e_240, 1);
    return (g_heff_2ecompile_2erepr_2estatsWith(heff_dup(v_r_246), MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), v_s_241));
  }
  case TAG_Literal: {
    V v_r_248 = heff_field(v_e_240, 1);
    return (g_heff_2ecompile_2erepr_2estatsWith(heff_dup(v_r_248), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), v_s_241));
  }
  case TAG_Wants: {
    V v_e2_2410 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2410)) {
    case TAG_RepV: {
      return (g_heff_2ecompile_2erepr_2estatsWith(NTAG(TAG_RepV), MK_INT(0LL), MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), NTAG(TAG_False), v_s_241));
    }
    case TAG_RepFix: {
      return (g_heff_2ecompile_2erepr_2estatsWith(heff_dup(v_e2_2410), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(1LL), NTAG(TAG_False), v_s_241));
    }
    case TAG_RepF64: {
      return (g_heff_2ecompile_2erepr_2estatsWith(heff_dup(v_e2_2410), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(1LL), NTAG(TAG_False), v_s_241));
    }
    default: return heff_nomatch(v_e2_2410);
    }
  }
  case TAG_Binds: {
    return v_s_241;
  }
  case TAG_Pinned: {
    return (g_heff_2ecompile_2erepr_2estatsWith(NTAG(TAG_RepV), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), v_s_241));
  }
  case TAG_Kept: {
    V v_r_2415 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2ecompile_2erepr_2ekeptTo(heff_dup(v_r_2415), v_s_241);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eseen(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2estatsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2estatsOf(V v_parent_240, V v_evs_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2estatsOf_lam0, 2, 1, (V[]){heff_dup(v_parent_240)}), heff_dup(g_map_2eempty_get()), v_evs_241));
}
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2estatsOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_e_243 = args[1];
  V v_parent_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2417;
  switch (heff_tag_of(v_e_243)) {
  case TAG_Merge: {
    V v_x_244 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_244;
    break;
  }
  case TAG_Boxed: {
    V v_x_246 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_246;
    break;
  }
  case TAG_Unboxed: {
    V v_x_247 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_247;
    break;
  }
  case TAG_Literal: {
    V v_x_249 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_249;
    break;
  }
  case TAG_Wants: {
    V v_x_2411 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_2411;
    break;
  }
  case TAG_Binds: {
    V v_x_2413 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_2413;
    break;
  }
  case TAG_Pinned: {
    V v_x_2414 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_2414;
    break;
  }
  case TAG_Kept: {
    V v_x_2415 = heff_dup(heff_field(v_e_243, 0));
    v_x_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_e_243);
  }
  V v_t_2418 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2417), v_parent_240));
  V v_root_2419 = ({ V a_0 = v_parent_240; V a_1 = v_x_2417; V a_2 = v_t_2418; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  V v_x2_2420 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_root_2419), v_m_242));
  V v_t_2422;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nothing: {
    v_t_2422 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    heff_take_n(v_x2_2420, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_t_2423 = ({ V a_0 = v_e_243; V a_1 = v_t_2422; V r_ = (g_heff_2ecompile_2erepr_2eseen(a_0, a_1)); heff_drop(v_e_243); r_; });
  return (g_map_2einsert_24s1341440536x470972936(v_root_2419, v_t_2423, v_m_242));
}
Clo g_heff_2ecompile_2erepr_2edecideOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecideOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edecideOf(V v_s_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_s_240, 7);
    return NTAG(TAG_RepV);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_rs_241, 0);
    V v_rs2_243 = heff_field(v_rs_241, 1);
    switch (heff_tag_of(v_rs2_243)) {
    case TAG_Nil: {
      V v_t_245;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_245 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_245 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_245 = MK_INT(2LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_246 = heff_intMul(heff_take_field(v_s_240, 1), v_t_245);
      V v_t_2410;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_2410 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_247 = heff_field(v_r_242, 0);
        V v_t_248;
        switch (heff_tag_of(v_w_247)) {
        case TAG_I8: {
          v_t_248 = MK_INT(8LL);
          break;
        }
        case TAG_I16: {
          v_t_248 = MK_INT(16LL);
          break;
        }
        case TAG_I32: {
          v_t_248 = MK_INT(32LL);
          break;
        }
        case TAG_I64: {
          v_t_248 = MK_INT(64LL);
          break;
        }
        case TAG_U8: {
          v_t_248 = MK_INT(8LL);
          break;
        }
        case TAG_U16: {
          v_t_248 = MK_INT(16LL);
          break;
        }
        case TAG_U32: {
          v_t_248 = MK_INT(32LL);
          break;
        }
        case TAG_U64: {
          v_t_248 = MK_INT(64LL);
          break;
        }
        case TAG_F32: {
          v_t_248 = MK_INT(32LL);
          break;
        }
        default: heff_nomatch(v_w_247);
        }
        if (heff_intEq_c(v_t_248, MK_INT(64LL))) {
          v_t_2410 = MK_INT(2LL);
        } else {
          v_t_2410 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2410 = MK_INT(3LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_2411 = heff_intMul(heff_take_field(v_s_240, 3), v_t_2410);
      V v_t_2415;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_2415 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_2412 = heff_field(v_r_242, 0);
        V v_t_2413;
        switch (heff_tag_of(v_w_2412)) {
        case TAG_I8: {
          v_t_2413 = MK_INT(8LL);
          break;
        }
        case TAG_I16: {
          v_t_2413 = MK_INT(16LL);
          break;
        }
        case TAG_I32: {
          v_t_2413 = MK_INT(32LL);
          break;
        }
        case TAG_I64: {
          v_t_2413 = MK_INT(64LL);
          break;
        }
        case TAG_U8: {
          v_t_2413 = MK_INT(8LL);
          break;
        }
        case TAG_U16: {
          v_t_2413 = MK_INT(16LL);
          break;
        }
        case TAG_U32: {
          v_t_2413 = MK_INT(32LL);
          break;
        }
        case TAG_U64: {
          v_t_2413 = MK_INT(64LL);
          break;
        }
        case TAG_F32: {
          v_t_2413 = MK_INT(32LL);
          break;
        }
        default: heff_nomatch(v_w_2412);
        }
        if (heff_intEq_c(v_t_2413, MK_INT(64LL))) {
          v_t_2415 = MK_INT(2LL);
        } else {
          v_t_2415 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2415 = MK_INT(3LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_2416 = heff_intMul(heff_take_field(v_s_240, 2), v_t_2415);
      V v_t_2418;
      switch (heff_tag_of(v_r_242)) {
      case TAG_RepV: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = MK_INT(2LL);
        break;
      }
      default: heff_nomatch(v_r_242);
      }
      V v_t_2419 = heff_intMul(heff_get_n(v_s_240, 4, 7), v_t_2418);
      if (heff_intLe_c(heff_intAdd(v_t_246, v_t_2411), heff_intAdd(v_t_2416, v_t_2419))) {
        return heff_dup(v_r_242);
      } else {
        return NTAG(TAG_RepV);
      }
    }
    case TAG_Cons: {
      heff_drop_rec(v_s_240, 7);
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_rs2_243);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecideOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2ekeptOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ekeptOne_entry, 4, 0};

V g_heff_2ecompile_2erepr_2ekeptOne(V v_parent_240, V v_stats_241, V v_m_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_Merge: {
    return v_m_242;
  }
  case TAG_Boxed: {
    return v_m_242;
  }
  case TAG_Unboxed: {
    return v_m_242;
  }
  case TAG_Literal: {
    return v_m_242;
  }
  case TAG_Wants: {
    return v_m_242;
  }
  case TAG_Binds: {
    V v_x_2413 = heff_field(v_e_243, 0);
    V v_t_2414 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2413), v_parent_240));
    V v_t_2415 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_x_2413), v_t_2414));
    V v_x2_2416 = (g_map_2elookup_24s1546226666x2146984184(v_t_2415, v_stats_241));
    V v_s_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_s_2418 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_s_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2419 = heff_dup(heff_rfield(v_s_2418, 6));
    V v_r_2422;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      V v_t_2420 = heff_dup(heff_rfield(v_s_2418, 5));
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop_rec(v_s_2418, 7);
        heff_drop(v_t_2420);
        v_r_2422 = NTAG(TAG_RepV);
      } else {
        heff_drop(v_t_2420);
        v_r_2422 = ({ V a_0 = heff_dup(v_s_2418); V b_1 = heff_get_n(v_s_2418, 0, 7); V r_ = (g_heff_2ecompile_2erepr_2edecideOf(a_0, b_1)); heff_drop(b_1); r_; });
      }
      break;
    }
    case TAG_Just: {
      V v_r_2421 = heff_field(v_t_2419, 0);
      heff_take_n(v_t_2419, 1ULL, 1);
      heff_drop_rec(v_s_2418, 7);
      v_r_2422 = v_r_2421;
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    switch (heff_tag_of(v_r_2422)) {
    case TAG_RepV: {
      return v_m_242;
    }
    case TAG_RepFix: {
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2413), v_r_2422, v_m_242));
    }
    case TAG_RepF64: {
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2413), v_r_2422, v_m_242));
    }
    default: return heff_nomatch(v_r_2422);
    }
  }
  case TAG_Pinned: {
    return v_m_242;
  }
  case TAG_Kept: {
    return v_m_242;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2erepr_2ekeptOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erepr_2ekeptOne(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erepr_2ereprsWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ereprsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsWith_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprsWith(V v_sg_240, V v_d_241) {
top: ;
  V v_evs_242 = (g_heff_2ecompile_2erepr_2edefEvents(v_sg_240, v_d_241));
  V v_pins_243 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_map_2eempty_get()), v_evs_242));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_242));
  V v_evs_248 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2ereprsWith_lam0, 2, 1, (V[]){v_pins_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_parent_249 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_map_2eempty_get()), v_evs_248));
  V v_t_2410 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_249, v_evs_248));
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2ekeptOne_clo), 2, (V[]){v_parent_249, v_t_2410}));
  return ({ V a_0 = v_t_2411; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_evs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_evs_248); r_; });
}
V g_heff_2ecompile_2erepr_2ereprsWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2ereprsWith(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2ereprsWith_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_pins_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V a_0 = v_pins_243; V a_1 = v_x_246; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_243); r_; });
  return (g_prelude_2e_2b_2b(v_t_247, v_acc_245));
}
Clo g_heff_2ecompile_2erepr_2edecidedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecidedIn_entry, 3, 0};

V g_heff_2ecompile_2erepr_2edecidedIn(V v_parent_240, V v_stats_241, V v_x_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), v_parent_240));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_x_242, v_t_243));
  V v_x2_245 = (g_map_2elookup_24s1546226666x2146984184(v_t_244, v_stats_241));
  V v_s_247;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    v_s_247 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    break;
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    v_s_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_248 = heff_dup(heff_rfield(v_s_247, 6));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    V v_t_249 = heff_dup(heff_rfield(v_s_247, 5));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop_rec(v_s_247, 7);
      heff_drop(v_t_249);
      return NTAG(TAG_RepV);
    } else {
      heff_drop(v_t_249);
      return ({ V a_0 = heff_dup(v_s_247); V b_1 = heff_get_n(v_s_247, 0, 7); V r_ = (g_heff_2ecompile_2erepr_2edecideOf(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_Just: {
    V v_r_2410 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    heff_drop_rec(v_s_247, 7);
    return v_r_2410;
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecidedIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2eproposeSig_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2eproposeSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eproposeSig_entry, 4, 0};

V g_heff_2ecompile_2erepr_2eproposeSig(V v_sg_240, V v_bounces_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
  V v_t_245 = (g_list_2emap_24s1917875516x88484758(heff_dup(v_xs_242)));
  V v_t_246 = (g_list_2efoldl_24s1854174827x1081689521(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_xs_242), NTAG(TAG_RetClass), v_t_243});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, v_t_246, v_t_248));
  V v_evs_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_249});
  V v_pins_2411 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_map_2eempty_get()), v_evs_2410));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2410));
  V v_evs_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2eproposeSig_lam0, 2, 1, (V[]){v_pins_2411}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  V v_parent_2417 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_map_2eempty_get()), v_evs_2416));
  V v_t_2418 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2417, v_evs_2416));
  V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erepr_2edecidedIn_clo), 2, (V[]){heff_dup(v_parent_2417), v_t_2418}));
  V v_t_2420 = (g_list_2emap(v_t_2419, v_xs_242));
  V v_t_2422;
  if ((heff_dup(v_bounces_241) == NTAG(TAG_True))) {
    heff_drop(v_evs_2416);
    heff_drop(v_parent_2417);
    v_t_2422 = NTAG(TAG_RepV);
  } else {
    V v_t_2421 = ({ V a_0 = v_parent_2417; V a_1 = v_evs_2416; V r_ = (g_heff_2ecompile_2erepr_2estatsOf(a_0, a_1)); heff_drop(v_evs_2416); r_; });
    v_t_2422 = ({ V a_0 = v_parent_2417; V a_1 = v_t_2421; V a_2 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V r_ = (g_heff_2ecompile_2erepr_2edecidedIn(a_0, a_1, a_2)); heff_drop(v_parent_2417); heff_drop(v_t_2421); r_; });
  }
  return heff_rec_n(2, shape_params__result, (V[]){v_t_2420, v_t_2422});
}
V g_heff_2ecompile_2erepr_2eproposeSig_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2eproposeSig(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2eproposeSig_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_x_2414 = args[1];
  V v_pins_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = v_pins_2411; V a_1 = v_x_2414; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2411); r_; });
  return (g_prelude_2e_2b_2b(v_t_2415, v_acc_2413));
}