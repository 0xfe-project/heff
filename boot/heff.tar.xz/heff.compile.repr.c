// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayAppend 23933
#define TAG_ArrayFromList 11455
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_ArrayIndexInAny 674
#define TAG_ArrayInsertAt 1609
#define TAG_ArrayKeeps 39370
#define TAG_ArrayKeepsAs 18630
#define TAG_ArrayLength 32493
#define TAG_ArrayOwn 58870
#define TAG_ArrayPeek 2264
#define TAG_ArrayPeekIn 6151
#define TAG_ArrayPush 18071
#define TAG_ArrayRemoveAt 38526
#define TAG_ArrayReplicate 47039
#define TAG_ArrayReserve 45606
#define TAG_ArraySet 62162
#define TAG_ArraySetOwned 53556
#define TAG_ArraySetOwnedIn 22211
#define TAG_ArraySlice 38486
#define TAG_ArrayToList 20274
#define TAG_Binds 36386
#define TAG_BitsBytes 6377
#define TAG_BitsConcat 14523
#define TAG_BitsEq 8995
#define TAG_BitsIntAt 48290
#define TAG_BitsLength 37027
#define TAG_BitsOfBytes 24218
#define TAG_BitsOfInt 3554
#define TAG_BitsSlice 40746
#define TAG_Boxed 28180
#define TAG_BoxedWord 41718
#define TAG_BytesAppend 445
#define TAG_BytesAsString 10306
#define TAG_BytesAt 9508
#define TAG_BytesConcat 52027
#define TAG_BytesEq 9629
#define TAG_BytesFromList 45957
#define TAG_BytesFromString 47012
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesOfInt 19560
#define TAG_BytesSlice 56752
#define TAG_BytesToList 62312
#define TAG_BytesToString 37927
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_Element 14172
#define TAG_F32 16337
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatBits 36420
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatOfBits 49155
#define TAG_FloatOfDecimal 61587
#define TAG_FloatPow 21165
#define TAG_FloatShow 17547
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Hole 35555
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IAny 21222
#define TAG_IBind 27068
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntHash 50175
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntOr 36976
#define TAG_IntShl 35657
#define TAG_IntShow 56864
#define TAG_IntShr 35663
#define TAG_IntSub 36050
#define TAG_IntXor 40685
#define TAG_Keep 49586
#define TAG_Kept 49931
#define TAG_Literal 34173
#define TAG_Merge 54398
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_OfFixed 17267
#define TAG_Often 32846
#define TAG_OnWindows 60758
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_Perform 19235
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_RetAs 20415
#define TAG_RetClass 33382
#define TAG_Reuse 22912
#define TAG_RuneEq 61407
#define TAG_RuneFromInt 49375
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_RuneToInt 27192
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_StrAppend 34515
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrFromByte 3813
#define TAG_StrFromJS 60564
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrOfRunes 54236
#define TAG_StrRuneAt 38304
#define TAG_StrRuneCount 54745
#define TAG_StrRuneDecode 45427
#define TAG_StrRuneWidth 48503
#define TAG_StrRunes 5519
#define TAG_StrSlice 780
#define TAG_StrToJS 44411
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define TAG_TrieSlot 53599
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unboxed 46787
#define TAG_Wants 58903
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_args 9498020
#define LBL_big 307066
#define LBL_boxedIn 304670893
#define LBL_boxedOut 854869195
#define LBL_flat 9641024
#define LBL_kept 9783717
#define LBL_params 951713969
#define LBL_pinned 958995203
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_sigs 10025609
#define LBL_unboxedIn 1261597312
#define LBL_unboxedOut 454817126
static uint32_t shape_args__result[] = {LBL_args, LBL_result};
static uint32_t shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big[] = {LBL_reprs, LBL_boxedIn, LBL_unboxedIn, LBL_boxedOut, LBL_unboxedOut, LBL_pinned, LBL_kept, LBL_big};
V g_heff_2ecompile_2erepr_2easWord(V, V);
V g_heff_2ecompile_2erepr_2easWord_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easWord_clo;
V g_heff_2ecompile_2erepr_2easWord_24dps(V, V, V);
V g_heff_2ecompile_2erepr_2easWord_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2easWord_24dps_clo;
V g_heff_2ecompile_2erepr_2edecideOf(V, V);
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecideOf_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2edefEvents(V, V);
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edefEvents_clo;
V g_heff_2ecompile_2erepr_2eeventName(V);
V g_heff_2ecompile_2erepr_2eeventName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eeventName_clo;
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2ecompile_2erepr_2efreeGo(V, V, V);
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efreeGo_clo;
V g_heff_2ecompile_2erepr_2ehope(V);
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ehope_clo;
V g_heff_2ecompile_2erepr_2eindexOfL(V, V, V);
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eindexOfL_clo;
V g_heff_2ecompile_2erepr_2eloops(V);
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eloops_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2ementionedBy(V);
V g_heff_2ecompile_2erepr_2ementionedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ementionedBy_clo;
V g_heff_2ecompile_2erepr_2enoStats_get(void);
HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V, V);
V g_heff_2ecompile_2erepr_2epinFields(V, V, V);
V g_heff_2ecompile_2erepr_2epinFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2epinFields_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V, V, V, V);
V g_heff_2ecompile_2erepr_2ereadRepr(V, V);
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereadRepr_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_heff_2ecompile_2erepr_2eretName_get(void);
V g_heff_2ecompile_2erepr_2erootFrom(V, V, V);
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2erootFrom_clo;
V g_heff_2ecompile_2erepr_2eseen(V, V);
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eseen_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2ecompile_2erepr_2esourceOf(V, V);
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2esourceOf_clo;
V g_heff_2ecompile_2erepr_2estatsOf(V, V);
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estatsOf_clo;
V g_heff_2ecompile_2erepr_2estepGives(V, V, V, V);
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2estepGives_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2ecompile_2erepr_2eunpinOne(V, V);
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunpinOne_clo;
V g_heff_2ecompile_2erepr_2ewalk(V, V, V, V);
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewalk_clo;
V g_heff_2ecompile_2erepr_2ewithRepr(V, V);
V g_heff_2ecompile_2erepr_2ewithRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ewithRepr_clo;
V g_list_2eany_24s100684943x1504448948(V, V);
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a);
extern Clo g_list_2eany_24s100684943x1504448948_clo;
V g_list_2eany_24s52266323x652150664(V);
V g_list_2eany_24s52266323x652150664_entry(V self, V *a);
extern Clo g_list_2eany_24s52266323x652150664_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f155552269x628597815(V, V, V);
V g_list_2efoldl_24f155552269x628597815_entry(V self, V *a);
extern Clo g_list_2efoldl_24f155552269x628597815_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1134919403x2060330530(V, V);
V g_list_2efoldl_24s1134919403x2060330530_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1134919403x2060330530_clo;
V g_list_2efoldl_24s1275727578x1654209034(V, V);
V g_list_2efoldl_24s1275727578x1654209034_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1275727578x1654209034_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1690891682x1517899652(V, V);
V g_list_2efoldl_24s1690891682x1517899652_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1690891682x1517899652_clo;
V g_list_2efoldl_24s1694506840x958926808(V, V);
V g_list_2efoldl_24s1694506840x958926808_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1694506840x958926808_clo;
V g_list_2efoldl_24s1817528582x392224400(V, V, V);
V g_list_2efoldl_24s1817528582x392224400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1817528582x392224400_clo;
V g_list_2efoldl_24s1854174827x1081689521(V, V);
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854174827x1081689521_clo;
V g_list_2efoldl_24s1923327646x248110754(V, V);
V g_list_2efoldl_24s1923327646x248110754_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923327646x248110754_clo;
V g_list_2efoldl_24s2096135476x728523350(V, V);
V g_list_2efoldl_24s2096135476x728523350_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096135476x728523350_clo;
V g_list_2efoldl_24s2145639387x28888241(V, V, V, V);
V g_list_2efoldl_24s2145639387x28888241_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2145639387x28888241_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s728686882x2096535788(V, V, V);
V g_list_2efoldl_24s728686882x2096535788_entry(V self, V *a);
extern Clo g_list_2efoldl_24s728686882x2096535788_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1310249268x749995235(V, V, V);
V g_list_2emap_24s1310249268x749995235_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1917875516x88484758(V);
V g_list_2emap_24s1917875516x88484758_entry(V self, V *a);
extern Clo g_list_2emap_24s1917875516x88484758_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1713677103x1107896282(V, V);
V g_list_2ezipWith_24s1713677103x1107896282_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1713677103x1107896282_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1583460153x999201201(V, V, V, V);
V g_prelude_2e_2b_2b_24f1583460153x999201201_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1583460153x999201201_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str8, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str9, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str10, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str11, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str12, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str13, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str14, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str15, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str16, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erepr_2ereprEq_str17, 7, "Float32");
Clo g_heff_2ecompile_2erepr_2ereprEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_RepV: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_True);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepFix: {
    V v_a_243 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_t_245;
      switch (heff_tag_of(v_a_243)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str0);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str1);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str2);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str3);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str4);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str5);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str6);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str7);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str8);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      V v_t_246;
      switch (heff_tag_of(v_b_244)) {
      case TAG_I8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str9);
        break;
      }
      case TAG_I16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str10);
        break;
      }
      case TAG_I32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str11);
        break;
      }
      case TAG_I64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str12);
        break;
      }
      case TAG_U8: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str13);
        break;
      }
      case TAG_U16: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str14);
        break;
      }
      case TAG_U32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str15);
        break;
      }
      case TAG_U64: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str16);
        break;
      }
      case TAG_F32: {
        v_t_246 = ((V)&g_heff_2ecompile_2erepr_2ereprEq_str17);
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_245, v_t_246, 0));
      heff_drop(v_t_245);
      heff_drop(v_t_246);
      return v_ret_24bool;
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepF64: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_True);
    }
    case TAG_RepInt: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_RepInt: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_RepV: {
      return NTAG(TAG_False);
    }
    case TAG_RepFix: {
      return NTAG(TAG_False);
    }
    case TAG_RepF64: {
      return NTAG(TAG_False);
    }
    case TAG_RepInt: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2ereprsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereprsEq_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereprsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_argv_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      V v_t_248 = (g_heff_2ecompile_2erepr_2ereprEq(v_a_244, v_b_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V t_0 = v_argv_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_248);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2ereprsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2erepr_2eopShape_24cpr(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_OpAdd: {
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_242}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  }
  case TAG_OpSub: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_245 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_244}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_245}});
  }
  case TAG_OpMul: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_247 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_246}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
  }
  case TAG_OpDiv: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_249 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_248}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_OpRem: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2411 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2410}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
  }
  case TAG_OpEq: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2412}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2413}});
  }
  case TAG_OpLt: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2414}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
  }
  case TAG_OpLe: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2417 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_t_2416}), NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
  }
  case TAG_OpAnd: {
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2419 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2418}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
  }
  case TAG_OpOr: {
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2421 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2420}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
  }
  case TAG_OpXor: {
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2423 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2422}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2423}});
  }
  case TAG_OpShl: {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2425 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2424}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2425}});
  }
  case TAG_OpShr: {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    V v_t_2427 = heff_rec_n(2, shape_args__result, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), v_t_2426}), v_r_240});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
  }
  case TAG_OpShow: {
    heff_drop(v_r_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpFromInt: {
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2428, v_r_240})}});
  }
  case TAG_OpToInt: {
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2430 = heff_rec_n(2, shape_args__result, (V[]){v_t_2429, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2430}});
  }
  case TAG_OpSqrt: {
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_240), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2431, v_r_240})}});
  }
  case TAG_OpFromFloat: {
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_args__result, (V[]){v_t_2432, v_r_240})}});
  }
  case TAG_OpToFloat: {
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2434 = heff_rec_n(2, shape_args__result, (V[]){v_t_2433, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2434}});
  }
  case TAG_OpFloor: {
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, NTAG(TAG_Nil)});
    V v_t_2436 = heff_rec_n(2, shape_args__result, (V[]){v_t_2435, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2436}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntAdd: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntSub: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntMul: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntDiv: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntMod: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntLe: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntShow: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntAnd: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntOr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntXor: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntShl: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntShr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_FloatAdd: {
    V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_241});
    V v_t_243 = heff_rec_n(2, shape_args__result, (V[]){v_t_242, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_243}});
  }
  case TAG_FloatSub: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_244});
    V v_t_246 = heff_rec_n(2, shape_args__result, (V[]){v_t_245, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_246}});
  }
  case TAG_FloatMul: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_247});
    V v_t_249 = heff_rec_n(2, shape_args__result, (V[]){v_t_248, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
  }
  case TAG_FloatDiv: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_2410});
    V v_t_2412 = heff_rec_n(2, shape_args__result, (V[]){v_t_2411, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2412}});
  }
  case TAG_FloatEq: {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_2413});
    V v_t_2415 = heff_rec_n(2, shape_args__result, (V[]){v_t_2414, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
  }
  case TAG_FloatLt: {
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_2416});
    V v_t_2418 = heff_rec_n(2, shape_args__result, (V[]){v_t_2417, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2418}});
  }
  case TAG_FloatLe: {
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_2419});
    V v_t_2421 = heff_rec_n(2, shape_args__result, (V[]){v_t_2420, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2421}});
  }
  case TAG_FloatShow: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_FloatFromInt: {
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
    V v_t_2423 = heff_rec_n(2, shape_args__result, (V[]){v_t_2422, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2423}});
  }
  case TAG_FloatSqrt: {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2425 = heff_rec_n(2, shape_args__result, (V[]){v_t_2424, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2425}});
  }
  case TAG_OnWindows: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_FloatFloor: {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2427 = heff_rec_n(2, shape_args__result, (V[]){v_t_2426, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2427}});
  }
  case TAG_FloatSin: {
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2429 = heff_rec_n(2, shape_args__result, (V[]){v_t_2428, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2429}});
  }
  case TAG_FloatCos: {
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2431 = heff_rec_n(2, shape_args__result, (V[]){v_t_2430, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2431}});
  }
  case TAG_FloatTan: {
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2433 = heff_rec_n(2, shape_args__result, (V[]){v_t_2432, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2433}});
  }
  case TAG_FloatAsin: {
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2435 = heff_rec_n(2, shape_args__result, (V[]){v_t_2434, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2435}});
  }
  case TAG_FloatAcos: {
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2437 = heff_rec_n(2, shape_args__result, (V[]){v_t_2436, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2437}});
  }
  case TAG_FloatAtan: {
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2439 = heff_rec_n(2, shape_args__result, (V[]){v_t_2438, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2439}});
  }
  case TAG_FloatAtan2: {
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_2440});
    V v_t_2442 = heff_rec_n(2, shape_args__result, (V[]){v_t_2441, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2442}});
  }
  case TAG_FloatExp: {
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2444 = heff_rec_n(2, shape_args__result, (V[]){v_t_2443, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2444}});
  }
  case TAG_FloatLog: {
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2446 = heff_rec_n(2, shape_args__result, (V[]){v_t_2445, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2446}});
  }
  case TAG_FloatPow: {
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), NTAG(TAG_Nil)});
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepF64), v_t_2447});
    V v_t_2449 = heff_rec_n(2, shape_args__result, (V[]){v_t_2448, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2449}});
  }
  case TAG_ArrayLength: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayIndex: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArraySet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayGenerate: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayFromList: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayToList: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayReplicate: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArraySlice: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayAppend: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayInsertAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayRemoveAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayPush: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayReserve: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Hole: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SetField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrAppend: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrLength: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrSlice: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrCompare: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrFind: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RuneEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RuneLt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RuneLe: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RuneToInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RuneFromInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Keep: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrByteAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrFromByte: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrRuneAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrRuneWidth: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrRuneCount: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrRunes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrOfRunes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrToJS: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrFromJS: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesLength: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesSlice: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesAppend: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesConcat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesFromList: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesToList: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesFromString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesAsString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesToString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesIntAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesOfInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BytesHasAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsLength: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsIntAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsOfInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsConcat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsSlice: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsOfBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BitsEq: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_FloatBits: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_FloatOfBits: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_FloatOfDecimal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrHash: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrHashRange: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrEqRange: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IntHash: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_TrieSlot: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OfFixed: {
    V v_w_2450 = heff_field(v_x1_240, 0);
    V v_op_2451 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2erepr_2eopShape_24cpr(heff_tag_n(TAG_RepFix, 1, (V[]){heff_dup(v_w_2450)}), v_op_2451));
  }
  case TAG_Perform: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_WordAdd: {
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2452});
    V v_t_2454 = heff_rec_n(2, shape_args__result, (V[]){v_t_2453, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2454}});
  }
  case TAG_WordSub: {
    V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2455});
    V v_t_2457 = heff_rec_n(2, shape_args__result, (V[]){v_t_2456, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2457}});
  }
  case TAG_WordMul: {
    V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2458});
    V v_t_2460 = heff_rec_n(2, shape_args__result, (V[]){v_t_2459, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2460}});
  }
  case TAG_WordDiv: {
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2461});
    V v_t_2463 = heff_rec_n(2, shape_args__result, (V[]){v_t_2462, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2463}});
  }
  case TAG_WordMod: {
    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2464});
    V v_t_2466 = heff_rec_n(2, shape_args__result, (V[]){v_t_2465, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2466}});
  }
  case TAG_WordQuot: {
    V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2467});
    V v_t_2469 = heff_rec_n(2, shape_args__result, (V[]){v_t_2468, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2469}});
  }
  case TAG_WordRem: {
    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2470});
    V v_t_2472 = heff_rec_n(2, shape_args__result, (V[]){v_t_2471, NTAG(TAG_RepInt)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2472}});
  }
  case TAG_WordEq: {
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2473});
    V v_t_2475 = heff_rec_n(2, shape_args__result, (V[]){v_t_2474, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2475}});
  }
  case TAG_WordLt: {
    V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2476});
    V v_t_2478 = heff_rec_n(2, shape_args__result, (V[]){v_t_2477, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2478}});
  }
  case TAG_WordLe: {
    V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), v_t_2479});
    V v_t_2481 = heff_rec_n(2, shape_args__result, (V[]){v_t_2480, NTAG(TAG_RepV)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2481}});
  }
  case TAG_WordToFloat: {
    V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepInt), NTAG(TAG_Nil)});
    V v_t_2483 = heff_rec_n(2, shape_args__result, (V[]){v_t_2482, NTAG(TAG_RepF64)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2483}});
  }
  case TAG_ArrayIndexIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayIndexInAny: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayPeek: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayPeekIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArraySetOwned: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArraySetOwnedIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayOwn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayKeeps: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ArrayKeepsAs: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Reuse: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_StrRuneDecode: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2erepr_2eslotRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eslotRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eslotRepr(V v_i_240, V v_t_241) {
top: ;
  if (heff_intLt_c(v_i_240, MK_INT(16LL))) {
    switch (heff_tag_of(v_t_241)) {
    case TAG_FtFloat: {
      return NTAG(TAG_RepF64);
    }
    case TAG_FtFixed: {
      V v_w_242 = heff_field(v_t_241, 0);
      V v_ru_24t_241_24FtFixed = heff_take_reuse_n(v_t_241, 1ULL, 1);
      int64_t v_t_243;
      switch (heff_tag_of(v_w_242)) {
      case TAG_I8: {
        v_t_243 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_243 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_243 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_243 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_243 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_243 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_243 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_243 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_243 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_242);
      }
      if ((v_t_243 == ((int64_t)64ULL))) {
        return heff_tag_at_n(v_ru_24t_241_24FtFixed, TAG_RepFix, 1, (V[]){v_w_242});
      } else {
        heff_drop(v_w_242);
        heff_drop_cell(v_ru_24t_241_24FtFixed, 1);
        return NTAG(TAG_RepV);
      }
    }
    case TAG_FtOther: {
      return NTAG(TAG_RepV);
    }
    case TAG_FtAny: {
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_t_241);
    }
  } else {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
}
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eslotRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2emayBeFlat_entry, 1, 0};

V g_heff_2ecompile_2erepr_2emayBeFlat(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_FtFloat: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_241 = heff_field(v_t_240, 0);
      int64_t v_t_242;
      switch (heff_tag_of(v_w_241)) {
      case TAG_I8: {
        v_t_242 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_242 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_242 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_242 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_242 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_242 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_242 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_241);
      }
      V v_ret_24bool = heff_bool((v_t_242 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtFixed: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_t_240, 0);
      int64_t v_t_245;
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      V v_ret_24bool = heff_bool((v_t_245 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtOther: {
    switch (heff_tag_of(v_t_240)) {
    case TAG_FtFloat: {
      return NTAG(TAG_True);
    }
    case TAG_FtFixed: {
      V v_w_246 = heff_field(v_t_240, 0);
      int64_t v_t_247;
      switch (heff_tag_of(v_w_246)) {
      case TAG_I8: {
        v_t_247 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_247 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_247 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_247 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_247 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_247 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_247 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_247 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_247 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_246);
      }
      V v_ret_24bool = heff_bool((v_t_247 == ((int64_t)64ULL)));
      return v_ret_24bool;
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_FtAny: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2emayBeFlat(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2ereadRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ereadRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ereadRepr(V v_x1_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return NTAG(TAG_RepV);
  }
  case TAG_Just: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    if (heff_intLt_c(v_i_242, MK_INT(16LL))) {
      switch (heff_tag_of(v_t_241)) {
      case TAG_FtFloat: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepF64);
      }
      case TAG_FtFixed: {
        V v_w_243 = heff_field(v_t_241, 0);
        heff_take_n(v_t_241, 1ULL, 1);
        int64_t v_t_244;
        switch (heff_tag_of(v_w_243)) {
        case TAG_I8: {
          v_t_244 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_244 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_244 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_244 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_244 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_244 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_244 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_244 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_244 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_243);
        }
        if ((v_t_244 == ((int64_t)64ULL))) {
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_RepFix, 1, (V[]){v_w_243});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          heff_drop(v_w_243);
          return NTAG(TAG_RepV);
        }
      }
      case TAG_FtOther: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      case TAG_FtAny: {
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_RepV);
      }
      default: return heff_nomatch(v_t_241);
      }
    } else {
      heff_drop(v_t_241);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return NTAG(TAG_RepV);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ereadRepr(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2efourTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efourTo_entry, 1, 0};

V g_heff_2ecompile_2erepr_2efourTo(V v_i_240) {
top: ;
  if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
    heff_drop(v_i_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2ecompile_2erepr_2efourTo(heff_intSub(v_i_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(4LL), v_t_241);
  }
}
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efourTo(a[0]);
}
Clo g_heff_2ecompile_2erepr_2etyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2etyIn_entry, 2, 0};

V g_heff_2ecompile_2erepr_2etyIn(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_FtAny);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_ts_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_dup(v_t_242);
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_ts_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2etyIn(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2erepr_2eretName_str0, 4, "$ret");

static V g_heff_2ecompile_2erepr_2eretName_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2eretName_st;
static V g_heff_2ecompile_2erepr_2eretName_init(void) {
  return ((V)&g_heff_2ecompile_2erepr_2eretName_str0);
}
V g_heff_2ecompile_2erepr_2eretName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2eretName_st)) return g_heff_2ecompile_2erepr_2eretName_val;
  return heff_global(&g_heff_2ecompile_2erepr_2eretName_val, &g_heff_2ecompile_2erepr_2eretName_st, g_heff_2ecompile_2erepr_2eretName_init);
}
Clo g_heff_2ecompile_2erepr_2estepGives_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estepGives_entry, 4, 0};

V g_heff_2ecompile_2erepr_2estepGives(V v_lp_240, V v_x_241, V v_o_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 0ULL, 1);
    V v_t_245;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_245 = heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_245 = heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_acc_243});
  }
  case TAG_OCall: {
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 0ULL, 2);
    V v_t_248;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_248 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_248 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_at_n(v_ru_24o_242_24OCall, TAG_Cons, 2, (V[]){v_t_248, v_acc_243});
  }
  case TAG_OApply: {
    V v_ru_24o_242_24OApply = heff_take_reuse_n(v_o_242, 0ULL, 2);
    V v_t_2411;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_2411 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_2411 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_at_n(v_ru_24o_242_24OApply, TAG_Cons, 2, (V[]){v_t_2411, v_acc_243});
  }
  case TAG_OPrim: {
    V v_p_2412 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OPrim = heff_take_reuse_n(v_o_242, 1ULL, 2);
    switch (heff_tag_of(v_p_2412)) {
    case TAG_ArrayIndex: {
      V v_t_2414;
      if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
        v_t_2414 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Element, 1, (V[]){v_x_241})});
      } else {
        v_t_2414 = heff_tag_n(TAG_Element, 1, (V[]){v_x_241});
      }
      return heff_tag_at_n(v_ru_24o_242_24OPrim, TAG_Cons, 2, (V[]){v_t_2414, v_acc_243});
    }
    default: {
      heff_drop(v_p_2412);
      V v_t_2415;
      if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
        v_t_2415 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
      } else {
        v_t_2415 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
      }
      return heff_tag_at_n(v_ru_24o_242_24OPrim, TAG_Cons, 2, (V[]){v_t_2415, v_acc_243});
    }
    }
  }
  case TAG_OAbandon: {
    V v_t_2416;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_2416 = heff_tag_n(TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_2416 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_acc_243});
  }
  case TAG_OBool: {
    V v_ru_24o_242_24OBool = heff_take_reuse_n(v_o_242, 0ULL, 1);
    V v_t_2418;
    if ((heff_dup(v_lp_240) == NTAG(TAG_True))) {
      v_t_2418 = heff_tag_at_n(v_ru_24o_242_24OBool, TAG_Often, 1, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_241})});
    } else {
      v_t_2418 = heff_tag_at_n(v_ru_24o_242_24OBool, TAG_Boxed, 1, (V[]){v_x_241});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_acc_243});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2erepr_2estepGives_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2estepGives(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2eindexOfL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eindexOfL_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eindexOfL(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_l_240, v_k_243, 0)) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2eindexOfL_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erepr_2eindexOfL(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erepr_2esourceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2esourceOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2esourceOf(V v_x_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SGlobal: {
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SInt: {
    V v_n_244 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SInt = heff_take_reuse_n(v_v_241, 1ULL, 1);
    if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_244, 1) && heff_intLe_c_lent(v_n_244, MK_INT(4611686018427387903LL), 2))) {
      heff_drop(v_n_244);
      heff_drop_cell(v_ru_24v_241_24SInt, 1);
      return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepInt)});
    } else {
      heff_drop(v_n_244);
      return heff_tag_at_n(v_ru_24v_241_24SInt, TAG_Boxed, 1, (V[]){v_x_240});
    }
  }
  case TAG_SFloat: {
    heff_take_na(v_v_241, 0ULL, 1);
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, NTAG(TAG_RepF64)});
  }
  case TAG_SStr: {
    V v_ru_24v_241_24SStr = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SStr, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SBytes: {
    V v_ru_24v_241_24SBytes = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SBytes, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SFixed: {
    V v_w_248 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SFixed = heff_take_reuse_n(v_v_241, 1ULL, 2);
    return heff_tag_at_n(v_ru_24v_241_24SFixed, TAG_Literal, 2, (V[]){v_x_240, heff_tag_n(TAG_RepFix, 1, (V[]){v_w_248})});
  }
  case TAG_SFloat32: {
    V v_ru_24v_241_24SFloat32 = heff_take_reuse_na(v_v_241, 0ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24v_241_24SFloat32, TAG_RepFix, 1, (V[]){NTAG(TAG_F32)});
    return heff_tag_n(TAG_Literal, 2, (V[]){v_x_240, v_t_2411});
  }
  case TAG_SPrimFn: {
    V v_ru_24v_241_24SPrimFn = heff_take_reuse_n(v_v_241, 0ULL, 1);
    return heff_tag_at_n(v_ru_24v_241_24SPrimFn, TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SLam: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_STag: {
    heff_take_n(v_v_241, 0ULL, 3);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SRec: {
    heff_take_n(v_v_241, 0ULL, 2);
    return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
  }
  case TAG_SProj: {
    V v_l_2421 = heff_field(v_v_241, 1);
    V v_sh_2422 = heff_field(v_v_241, 2);
    V v_t_2423 = heff_field(v_v_241, 3);
    heff_take_n(v_v_241, 14ULL, 4);
    V v_t_2424 = ({ V a_0 = v_l_2421; V a_1 = MK_INT(0LL); V a_2 = v_sh_2422; V r_ = (g_heff_2ecompile_2erepr_2eindexOfL(a_0, a_1, a_2)); heff_drop(v_l_2421); heff_drop(v_sh_2422); r_; });
    V v_r_2425 = (g_heff_2ecompile_2erepr_2ereadRepr(v_t_2424, v_t_2423));
    switch (heff_tag_of(v_r_2425)) {
    case TAG_RepV: {
      return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
    }
    case TAG_RepFix: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2425});
    }
    case TAG_RepF64: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2425});
    }
    case TAG_RepInt: {
      return heff_tag_n(TAG_Unboxed, 2, (V[]){v_x_240, v_r_2425});
    }
    default: return heff_nomatch(v_r_2425);
    }
  }
  case TAG_SPrim: {
    V v_p_2427 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SPrim = heff_take_reuse_n(v_v_241, 1ULL, 2);
    HeffT2 v_t_2429 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_2427));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_s_2432 = v_field_2431;
        V v_t_2433 = heff_get_n(v_s_2432, 1, 2);
        switch (heff_tag_of(v_t_2433)) {
        case TAG_RepV: {
          heff_drop(v_p_2427);
          heff_drop_cell(v_ru_24v_241_24SPrim, 2);
          return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
        }
        case TAG_RepFix: {
          heff_take_n(v_t_2433, 0ULL, 1);
          HeffT2 v_t_2435 = ({ V a_0 = v_p_2427; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2427); r_; });
          V v_t_2439;
          {
            V v_field_2437 = v_t_2435.f[1];
            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
            if ((v_tag_2436 == ((int64_t)0ULL))) {
              V v_s_2438 = v_field_2437;
              v_t_2439 = heff_get_n(v_s_2438, 1, 2);
            } else {
              heff_drop(v_field_2437);
              v_t_2439 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2439});
        }
        case TAG_RepF64: {
          HeffT2 v_t_2440 = ({ V a_0 = v_p_2427; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2427); r_; });
          V v_t_2444;
          {
            V v_field_2442 = v_t_2440.f[1];
            int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
            if ((v_tag_2441 == ((int64_t)0ULL))) {
              V v_s_2443 = v_field_2442;
              v_t_2444 = heff_get_n(v_s_2443, 1, 2);
            } else {
              heff_drop(v_field_2442);
              v_t_2444 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2444});
        }
        case TAG_RepInt: {
          HeffT2 v_t_2445 = ({ V a_0 = v_p_2427; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2427); r_; });
          V v_t_2449;
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              V v_s_2448 = v_field_2447;
              v_t_2449 = heff_get_n(v_s_2448, 1, 2);
            } else {
              heff_drop(v_field_2447);
              v_t_2449 = NTAG(TAG_RepV);
            }
          }
          return heff_tag_at_n(v_ru_24v_241_24SPrim, TAG_Unboxed, 2, (V[]){v_x_240, v_t_2449});
        }
        default: return heff_nomatch(v_t_2433);
        }
      } else {
        heff_drop(v_p_2427);
        heff_drop_cell(v_ru_24v_241_24SPrim, 2);
        heff_drop(v_field_2431);
        return heff_tag_n(TAG_Boxed, 1, (V[]){v_x_240});
      }
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erepr_2esourceOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2esourceOf(a[0], a[1]);
}
V g_heff_2ecompile_2erepr_2epinFields_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2epinFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2epinFields_entry, 3, 0};

V g_heff_2ecompile_2erepr_2epinFields(V v_ps_240, V v_acc_241, V v_vs_242) {
top: ;
  switch (heff_tag_of(v_ps_240)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s964765707x1396946999(v_acc_241, v_vs_242));
  }
  case TAG_Cons: {
    V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
    V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(v_vs_242, v_t_246));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2epinFields_lam0, 2, 1, (V[]){v_ps_240}); V a_1 = v_acc_241; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_ps_240);
  }
}
V g_heff_2ecompile_2erepr_2epinFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2epinFields(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erepr_2epinFields_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x3_249 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x3_249, 0);
    V v_i_2411 = heff_field(v_x3_249, 1);
    V v_ru_24x3_249_24MkPair = heff_take_reuse_n(v_x3_249, 3ULL, 2);
    V v_t_2412 = ({ V a_0 = v_i_2411; V a_1 = v_ps_240; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop_tag(v_ps_240, 2); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      return heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){v_x_2410}), v_acc_248});
    } else {
      heff_drop(v_t_2412);
      V v_t_2413 = heff_tag_at_n(v_ru_24x3_249_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_2410)}), v_acc_248});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_2410}), v_t_2413});
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
Clo g_heff_2ecompile_2erepr_2ementionedBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ementionedBy_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ementionedBy(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Merge: {
    V v_y_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Merge = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Merge, TAG_Cons, 2, (V[]){v_y_242, NTAG(TAG_Nil)});
  }
  case TAG_Boxed: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_BoxedWord: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Element: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Unboxed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Literal: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Wants: {
    V v_x_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Wants = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Wants, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
  }
  case TAG_Binds: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Pinned: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_Kept: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Often: {
    V v_e_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2416;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2ementionedBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ementionedBy(a[0]);
}
Clo g_heff_2ecompile_2erepr_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2efreeGo_entry, 3, 0};

V g_heff_2ecompile_2erepr_2efreeGo(V v_bs_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_bs_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_bs_240, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_bs_240;
        V t_1 = v_xs_244;
        V t_2 = v_acc_242;
        v_bs_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_bs_240, heff_dup(v_x_243), NTAG(TAG_MkUnit)));
        V t_0 = v_t_249;
        V t_1 = v_xs_244;
        V t_2 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
        v_bs_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2efreeGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2eloops_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eloops_entry, 1, 0};

V g_heff_2ecompile_2erepr_2eloops(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TSeq: {
    V v_t_242 = heff_field(v_x1_240, 1);
    V t_0 = v_t_242;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_TReturn: {
    return NTAG(TAG_False);
  }
  case TAG_TLoop: {
    return NTAG(TAG_True);
  }
  case TAG_TIf: {
    V v_t_246 = heff_field(v_x1_240, 1);
    V v_e_247 = heff_field(v_x1_240, 2);
    V v_t_248 = (g_heff_2ecompile_2erepr_2eloops(v_t_246));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_248);
      V t_0 = v_e_247;
      v_x1_240 = t_0;
      goto top;
    }
  }
  case TAG_TCase: {
    V v_arms_2410 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_list_2eany_24s52266323x652150664(v_arms_2410);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eloops(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam1(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam2(V self, V *args);
V g_heff_2ecompile_2erepr_2ewalk_lam3(V self, V *args);
Clo g_heff_2ecompile_2erepr_2ewalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewalk_entry, 4, 0};

V g_heff_2ecompile_2erepr_2ewalk(V v_sg_240, V v_lp_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_sg_240, 2);
    heff_drop(v_lp_241);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_IVal: {
      V v_r_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24IVal = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_SVar: {
        V v_x_248 = heff_field(v_x412_247, 0);
        V v_ru_24x412_247_24SVar = heff_take_reuse_n(v_x412_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_t_249;
        if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
          v_t_249 = heff_tag_at_n(v_ru_24x412_247_24SVar, TAG_Often, 1, (V[]){heff_tag_n(TAG_Wants, 2, (V[]){v_x_248, v_r_246})});
        } else {
          heff_drop_cell(v_ru_24x412_247_24SVar, 1);
          v_t_249 = heff_tag_n(TAG_Wants, 2, (V[]){v_x_248, v_r_246});
        }
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_acc_242});
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_na(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x412_247, 0ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x412_247, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2419 = heff_field(v_x412_247, 0);
        V v_x4122_2420 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        heff_drop(v_r_246);
        switch (heff_tag_of(v_x4122_2420)) {
        case TAG_MkBlock: {
          V v_t_2421 = heff_field(v_x4122_2420, 0);
          V v_ru_24x4122_2420_24MkBlock = heff_take_reuse_n(v_x4122_2420, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x4122_2420_24MkBlock, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
          V v_t_2423 = heff_tag_n(TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2422, v_t_2421});
          V v_t_2424 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
          V v_evs_2425 = (g_heff_2ecompile_2erepr_2ewalk(heff_dup(v_sg_240), NTAG(TAG_False), NTAG(TAG_Nil), v_t_2424));
          V v_t_2426 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x41_244_24IVal, heff_dup(v_evs_2425), v_acc_242));
          V v_t_2427 = (g_list_2efoldl_24s2096135476x728523350(v_t_2426, heff_dup(v_xs_2419)));
          V v_t_2428 = (g_list_2efoldl_24s1694506840x958926808(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2425));
          V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_xs_2419; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2419); r_; });
          V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2425));
          V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s1923327646x248110754(a_0, a_1)); heff_drop(v_t_2430); r_; });
          V v_t_2432 = (g_heff_2ecompile_2erepr_2efreeGo(v_t_2429, v_t_2431, NTAG(TAG_Nil)));
          V v_t_2433 = (g_list_2efoldl_24s1817528582x392224400(v_lp_241, v_t_2427, v_t_2432));
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_2433;
          V t_3 = v_rest_245;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x4122_2420);
        }
      }
      case TAG_STag: {
        V v_argv_2435 = heff_field(v_x412_247, 1);
        V v_ts_2436 = heff_field(v_x412_247, 2);
        heff_take_n(v_x412_247, 6ULL, 3);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_n_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2435));
        V v_t_2438 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_n_2437, MK_INT(1LL))));
        V v_rs_2441 = (g_list_2emap_24tok2(v_ru_24x4_243_24Cons, heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam0, 1, 1, (V[]){v_ts_2436}), v_t_2438));
        V v_t_2442 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2441, v_argv_2435));
        V v_t_2443 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_2442));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2443;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2444 = heff_field(v_x412_247, 0);
        V v_ts_2445 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        heff_drop(v_r_246);
        heff_drop_cell(v_ru_24x41_244_24IVal, 2);
        V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2445));
        V v_t_2447 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2446, MK_INT(1LL))));
        V v_rs_2448 = (g_list_2ezipWith_24s1713677103x1107896282(v_t_2447, v_ts_2445));
        V v_vs_2449 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x4_243_24Cons, v_fs_2444));
        V v_t_2450 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_2448, v_vs_2449));
        V v_t_2451 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_2450));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2451;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2452 = heff_field(v_x412_247, 0);
        heff_take_n(v_x412_247, 1ULL, 4);
        heff_drop(v_r_246);
        V v_t_2456 = heff_tag_at_n(v_ru_24x41_244_24IVal, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_2452});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2456, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_SPrim: {
        V v_p_2457 = heff_field(v_x412_247, 0);
        V v_argv_2458 = heff_field(v_x412_247, 1);
        V v_ru_24x412_247_24SPrim = heff_take_reuse_n(v_x412_247, 3ULL, 2);
        heff_drop(v_r_246);
        V v_p_2459 = v_p_2457;
        V v_vs_2460 = v_argv_2458;
        V v_rest_2461 = v_rest_245;
        V v_t_2462;
        switch (heff_tag_of(v_p_2459)) {
        case TAG_ArraySet: {
          v_t_2462 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){MK_INT(2LL), NTAG(TAG_Nil)});
          break;
        }
        case TAG_ArrayReplicate: {
          v_t_2462 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
          break;
        }
        default: {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          v_t_2462 = NTAG(TAG_Nil);
          break;
        }
        }
        V v_t_2463;
        switch (heff_tag_of(v_p_2459)) {
        case TAG_ArrayIndex: {
          v_t_2463 = heff_tag_at_n(v_ru_24x412_247_24SPrim, TAG_Cons, 2, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
          break;
        }
        case TAG_ArraySet: {
          v_t_2463 = heff_tag_at_n(v_ru_24x412_247_24SPrim, TAG_Cons, 2, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
          break;
        }
        default: {
          heff_drop_cell(v_ru_24x412_247_24SPrim, 2);
          v_t_2463 = NTAG(TAG_Nil);
          break;
        }
        }
        V v_ks_2464 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x41_244_24IVal, v_t_2462, v_t_2463));
        HeffT2 v_t_2465 = ({ V a_0 = v_p_2459; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_2459); r_; });
        V v_t_2469;
        {
          V v_field_2467 = v_t_2465.f[1];
          int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
          if ((v_tag_2466 == ((int64_t)0ULL))) {
            V v_s_2468 = v_field_2467;
            v_t_2469 = heff_get_n(v_s_2468, 0, 2);
          } else {
            heff_drop(v_field_2467);
            v_t_2469 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_vs_2460)));
          }
        }
        V v_t_2470 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2469, heff_dup(v_vs_2460)));
        V v_t_2471 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_2460; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_vs_2460); r_; });
        V v_t_2472 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2471, MK_INT(1LL))));
        V v_t_2478 = (g_prelude_2e_2b_2b_24f1583460153x999201201(v_rest_2461, heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam1, 2, 1, (V[]){v_ks_2464}), v_t_2470, v_t_2472));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_2478;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    case TAG_IAny: {
      V v_x411_2479 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_2479)) {
      case TAG_SVar: {
        heff_take_n(v_x411_2479, 0ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: {
        V v_t_2481 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x411_2479});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2481, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      }
    }
    case TAG_IBind: {
      V v_x_2482 = heff_field(v_x41_244, 0);
      V v_x412_2483 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24IBind = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_2483)) {
      case TAG_OSimple: {
        V v_x4121_2484 = heff_field(v_x412_2483, 0);
        V v_ru_24x412_2483_24OSimple = heff_take_reuse_n(v_x412_2483, 1ULL, 1);
        switch (heff_tag_of(v_x4121_2484)) {
        case TAG_SVar: {
          V v_y_2485 = heff_field(v_x4121_2484, 0);
          heff_take_n(v_x4121_2484, 1ULL, 1);
          heff_drop_cell(v_ru_24x412_2483_24OSimple, 1);
          V v_t_2486 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Merge, 2, (V[]){v_x_2482, v_y_2485}), v_acc_242});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_2486;
          V t_3 = v_rest_245;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: {
          V v_e_2487 = (g_heff_2ecompile_2erepr_2esourceOf(v_x_2482, heff_dup(v_x4121_2484)));
          V v_t_2488;
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_2488 = heff_tag_at_n(v_ru_24x412_2483_24OSimple, TAG_Often, 1, (V[]){v_e_2487});
          } else {
            heff_drop_cell(v_ru_24x412_2483_24OSimple, 1);
            v_t_2488 = v_e_2487;
          }
          V v_t_2489 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_x4121_2484});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2488, v_acc_242});
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_rest_245});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        }
      }
      case TAG_OCall: {
        V v_g_2490 = heff_field(v_x412_2483, 0);
        V v_argv_2491 = heff_field(v_x412_2483, 1);
        V v_ru_24x412_2483_24OCall = heff_take_reuse_n(v_x412_2483, 3ULL, 2);
        HeffT2 v_t_2492 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_sg_240, 0), v_g_2490));
        V v_t_2499;
        {
          V v_field_2494 = v_t_2492.f[1];
          int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
          V v_r_2496;
          if ((v_tag_2493 == ((int64_t)0ULL))) {
            V v_s_2495 = v_field_2494;
            v_r_2496 = heff_get_n(v_s_2495, 1, 2);
          } else {
            heff_drop(v_field_2494);
            v_r_2496 = NTAG(TAG_RepV);
          }
          V v_e_2498;
          switch (heff_tag_of(v_r_2496)) {
          case TAG_RepV: {
            heff_drop_cell(v_ru_24x41_244_24IBind, 2);
            v_e_2498 = heff_tag_n(TAG_Boxed, 1, (V[]){v_x_2482});
            break;
          }
          case TAG_RepFix: {
            v_e_2498 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Unboxed, 2, (V[]){v_x_2482, v_r_2496});
            break;
          }
          case TAG_RepF64: {
            v_e_2498 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Unboxed, 2, (V[]){v_x_2482, v_r_2496});
            break;
          }
          case TAG_RepInt: {
            v_e_2498 = heff_tag_at_n(v_ru_24x41_244_24IBind, TAG_Unboxed, 2, (V[]){v_x_2482, v_r_2496});
            break;
          }
          default: heff_nomatch(v_r_2496);
          }
          if ((heff_dup(v_lp_241) == NTAG(TAG_True))) {
            v_t_2499 = heff_tag_n(TAG_Often, 1, (V[]){v_e_2498});
          } else {
            v_t_2499 = v_e_2498;
          }
        }
        V v_t_24100 = heff_tag_n(TAG_IOp, 1, (V[]){heff_tag_at_n(v_ru_24x412_2483_24OCall, TAG_OCall, 2, (V[]){v_g_2490, v_argv_2491})});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2499, v_acc_242});
        V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OApply: {
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V v_t_24103 = (g_heff_2ecompile_2erepr_2estepGives(v_lp_241, v_x_2482, heff_dup(v_x412_2483), v_acc_242));
        V v_t_24104 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x412_2483}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24103;
        V t_3 = v_t_24104;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OPrim: {
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V v_t_24107 = (g_heff_2ecompile_2erepr_2estepGives(v_lp_241, v_x_2482, heff_dup(v_x412_2483), v_acc_242));
        V v_t_24108 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x412_2483}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24107;
        V t_3 = v_t_24108;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_x_2482);
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OBool: {
        heff_drop_cell(v_ru_24x41_244_24IBind, 2);
        V v_t_24110 = (g_heff_2ecompile_2erepr_2estepGives(v_lp_241, v_x_2482, heff_dup(v_x412_2483), v_acc_242));
        V v_t_24111 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_x412_2483}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24110;
        V t_3 = v_t_24111;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x412_2483);
      }
    }
    case TAG_IOp: {
      V v_x411_24112 = heff_field(v_x41_244, 0);
      V v_ru_24x41_244_24IOp = heff_take_reuse_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_24112)) {
      case TAG_OSimple: {
        V v_v_24113 = heff_field(v_x411_24112, 0);
        heff_take_n(v_x411_24112, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24IOp, 1);
        V v_t_24114 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24113});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24114, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OCall: {
        V v_g_24115 = heff_field(v_x411_24112, 0);
        V v_argv_24116 = heff_field(v_x411_24112, 1);
        heff_take_n(v_x411_24112, 3ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24IOp, 1);
        HeffT2 v_t_24117 = ({ V a_0 = heff_rfield(v_sg_240, 0); V a_1 = v_g_24115; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_g_24115); r_; });
        V v_t_24123;
        {
          V v_field_24119 = v_t_24117.f[1];
          int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
          V v_rs_24121;
          if ((v_tag_24118 == ((int64_t)0ULL))) {
            V v_s_24120 = v_field_24119;
            v_rs_24121 = heff_get_n(v_s_24120, 0, 2);
          } else {
            heff_drop(v_field_24119);
            v_rs_24121 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_argv_24116)));
          }
          V v_t_24122 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_rs_24121, v_argv_24116));
          v_t_24123 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_24122));
        }
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24123;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OApply: {
        V v_f_24124 = heff_field(v_x411_24112, 0);
        V v_argv_24125 = heff_field(v_x411_24112, 1);
        heff_take_n(v_x411_24112, 3ULL, 2);
        heff_drop_cell(v_ru_24x41_244_24IOp, 1);
        V v_t_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_24124, v_argv_24125})));
        V v_t_24127 = (g_list_2efoldl_24s728686882x2096535788(NTAG(TAG_RepV), v_rest_245, v_t_24126));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24127;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OPrim: {
        V v_argv_24129 = heff_field(v_x411_24112, 1);
        heff_take_n(v_x411_24112, 2ULL, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24IOp, 1);
        V v_t_24130 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_argv_24129));
        V v_t_24131 = (g_list_2efoldl_24s728686882x2096535788(NTAG(TAG_RepV), v_rest_245, v_t_24130));
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24131;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24IOp, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_OBool: {
        V v_c_24132 = heff_field(v_x411_24112, 0);
        heff_take_n(v_x411_24112, 1ULL, 1);
        V v_t_24133 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24IOp, TAG_ICond, 1, (V[]){v_c_24132}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24133;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x411_24112);
      }
    }
    case TAG_ICond: {
      V v_x411_24134 = heff_field(v_x41_244, 0);
      V v_ru_24x41_244_24ICond = heff_take_reuse_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_24134)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PRel: {
        V v_p_24135 = heff_field(v_x411_24134, 0);
        V v_a_24136 = heff_field(v_x411_24134, 1);
        V v_b_24137 = heff_field(v_x411_24134, 2);
        heff_take_n(v_x411_24134, 7ULL, 3);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        HeffT2 v_t_24138 = ({ V a_0 = v_p_24135; HeffT2 r_ = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(a_0)); heff_drop(v_p_24135); r_; });
        V v_t_24146;
        {
          V v_field_24140 = v_t_24138.f[1];
          int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
          V v_t_24143;
          if ((v_tag_24139 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            V v_s_24141 = v_field_24140;
            v_t_24143 = heff_get_n(v_s_24141, 0, 2);
          } else {
            heff_drop(v_field_24140);
            V v_t_24142 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_RepV), NTAG(TAG_Nil)});
            v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_RepV), v_t_24142});
          }
          V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_24137, NTAG(TAG_Nil)});
          V v_t_24145 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_t_24143, heff_tag_n(TAG_Cons, 2, (V[]){v_a_24136, v_t_24144})));
          v_t_24146 = (g_list_2efoldl_24s1690891682x1517899652(v_rest_245, v_t_24145));
        }
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24146;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PBool: {
        V v_v_24147 = heff_field(v_x411_24134, 0);
        heff_take_n(v_x411_24134, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24ICond, 1);
        V v_t_24148 = heff_tag_n(TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24147});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24148, v_rest_245});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PNot: {
        V v_c_24149 = heff_field(v_x411_24134, 0);
        heff_take_n(v_x411_24134, 1ULL, 1);
        V v_t_24150 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ICond, TAG_ICond, 1, (V[]){v_c_24149}), v_rest_245});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24150;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PIf: {
        V v_a_24151 = heff_field(v_x411_24134, 0);
        V v_b_24152 = heff_field(v_x411_24134, 1);
        V v_c_24153 = heff_field(v_x411_24134, 2);
        heff_take_n(v_x411_24134, 7ULL, 3);
        V v_t_24154 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ICond, TAG_ICond, 1, (V[]){v_c_24153}), v_rest_245});
        V v_t_24155 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_b_24152}), v_t_24154});
        V v_t_24156 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_24151}), v_t_24155});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_t_24156;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_PLet: {
        V v_x_24157 = heff_field(v_x411_24134, 0);
        V v_o_24158 = heff_field(v_x411_24134, 1);
        V v_c_24159 = heff_field(v_x411_24134, 2);
        heff_take_n(v_x411_24134, 7ULL, 3);
        V v_t_24160 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24157)}), v_acc_242});
        V v_t_24161 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ICond, TAG_ICond, 1, (V[]){v_c_24159}), v_rest_245});
        V v_t_24162 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24157, v_o_24158}), v_t_24161});
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_t_24160;
        V t_3 = v_t_24162;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x411_24134);
      }
    }
    case TAG_ISts: {
      V v_x411_24163 = heff_field(v_x41_244, 0);
      V v_ru_24x41_244_24ISts = heff_take_reuse_n(v_x41_244, 1ULL, 1);
      switch (heff_tag_of(v_x411_24163)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop_cell(v_ru_24x41_244_24ISts, 1);
        V t_0 = v_sg_240;
        V t_1 = v_lp_241;
        V t_2 = v_acc_242;
        V t_3 = v_rest_245;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Cons: {
        V v_x4111_24164 = heff_field(v_x411_24163, 0);
        V v_ss_24165 = heff_field(v_x411_24163, 1);
        V v_ru_24x411_24163_24Cons = heff_take_reuse_n(v_x411_24163, 3ULL, 2);
        switch (heff_tag_of(v_x4111_24164)) {
        case TAG_SLet: {
          V v_x_24166 = heff_field(v_x4111_24164, 0);
          V v_o_24167 = heff_field(v_x4111_24164, 1);
          V v_ru_24x4111_24164_24SLet = heff_take_reuse_n(v_x4111_24164, 3ULL, 2);
          V v_t_24168 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24166)}), v_acc_242});
          V v_t_24169 = heff_tag_at_n(v_ru_24x411_24163_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24165}), v_rest_245});
          V v_t_24170 = heff_tag_at_n(v_ru_24x4111_24164_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24166, v_o_24167}), v_t_24169});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24168;
          V t_3 = v_t_24170;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SOnce: {
          V v_x_24171 = heff_field(v_x4111_24164, 0);
          V v_o_24172 = heff_field(v_x4111_24164, 1);
          V v_ru_24x4111_24164_24SOnce = heff_take_reuse_n(v_x4111_24164, 3ULL, 2);
          V v_t_24173 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_24171)}), v_acc_242});
          V v_t_24174 = heff_tag_at_n(v_ru_24x411_24163_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24165}), v_rest_245});
          V v_t_24175 = heff_tag_at_n(v_ru_24x4111_24164_24SOnce, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){v_x_24171, v_o_24172}), v_t_24174});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24173;
          V t_3 = v_t_24175;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_24176 = heff_field(v_x4111_24164, 0);
          V v_ru_24x4111_24164_24SDecl = heff_take_reuse_n(v_x4111_24164, 1ULL, 1);
          V v_t_24177 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4111_24164_24SDecl, TAG_Binds, 1, (V[]){v_x_24176}), v_acc_242});
          V v_t_24178 = heff_tag_at_n(v_ru_24x411_24163_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24165}), v_rest_245});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24177;
          V t_3 = v_t_24178;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SSet: {
          V v_x_24179 = heff_field(v_x4111_24164, 0);
          V v_o_24180 = heff_field(v_x4111_24164, 1);
          V v_ru_24x4111_24164_24SSet = heff_take_reuse_n(v_x4111_24164, 3ULL, 2);
          V v_t_24181 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24165}), v_rest_245});
          V v_t_24182 = heff_tag_at_n(v_ru_24x411_24163_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4111_24164_24SSet, TAG_IBind, 2, (V[]){v_x_24179, v_o_24180}), v_t_24181});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_acc_242;
          V t_3 = v_t_24182;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SIf: {
          V v_c_24183 = heff_field(v_x4111_24164, 0);
          V v_ts_24184 = heff_field(v_x4111_24164, 1);
          V v_fs_24185 = heff_field(v_x4111_24164, 2);
          heff_take_n(v_x4111_24164, 7ULL, 3);
          V v_t_24186 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24165}), v_rest_245});
          V v_t_24187 = heff_tag_at_n(v_ru_24x411_24163_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_fs_24185}), v_t_24186});
          V v_t_24188 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_24184}), v_t_24187});
          V v_t_24189 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24183}), v_t_24188});
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_acc_242;
          V t_3 = v_t_24189;
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        case TAG_SCase: {
          V v_v_24190 = heff_field(v_x4111_24164, 0);
          V v_arms_24191 = heff_field(v_x4111_24164, 1);
          V v_ru_24x4111_24164_24SCase = heff_take_reuse_n(v_x4111_24164, 3ULL, 2);
          V v_t_24202 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam2, 2, 1, (V[]){heff_dup(v_sg_240)}), v_acc_242, v_arms_24191));
          V v_t_24203 = heff_tag_at_n(v_ru_24x4111_24164_24SCase, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24190});
          V v_t_24204 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ISts, TAG_ISts, 1, (V[]){v_ss_24165}), v_rest_245});
          V v_t_24205 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24191));
          V v_t_24206 = (g_list_2efoldl_24s1104809983x118204267(v_t_24204, v_t_24205));
          V t_0 = v_sg_240;
          V t_1 = v_lp_241;
          V t_2 = v_t_24202;
          V t_3 = heff_tag_at_n(v_ru_24x411_24163_24Cons, TAG_Cons, 2, (V[]){v_t_24203, v_t_24206});
          v_sg_240 = t_0;
          v_lp_241 = t_1;
          v_acc_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_x4111_24164);
        }
      }
      default: return heff_nomatch(v_x411_24163);
      }
    }
    case TAG_ITl: {
      V v_ps_24207 = heff_field(v_x41_244, 0);
      V v_rt_24208 = heff_field(v_x41_244, 1);
      V v_x413_24209 = heff_field(v_x41_244, 2);
      V v_ru_24x41_244_24ITl = heff_take_reuse_n(v_x41_244, 7ULL, 3);
      heff_drop(v_lp_241);
      switch (heff_tag_of(v_x413_24209)) {
      case TAG_TSeq: {
        V v_ss_24210 = heff_field(v_x413_24209, 0);
        V v_t_24211 = heff_field(v_x413_24209, 1);
        V v_ru_24x413_24209_24TSeq = heff_take_reuse_n(v_x413_24209, 3ULL, 2);
        V v_t_24212 = (g_heff_2ecompile_2erepr_2eloops(v_t_24211));
        V v_t_24213 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ITl, TAG_ITl, 3, (V[]){v_ps_24207, v_rt_24208, v_t_24211}), v_rest_245});
        V v_t_24214 = heff_tag_at_n(v_ru_24x413_24209_24TSeq, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_24210}), v_t_24213});
        V t_0 = v_sg_240;
        V t_1 = v_t_24212;
        V t_2 = v_acc_242;
        V t_3 = v_t_24214;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24215 = heff_field(v_x413_24209, 0);
        V v_ru_24x413_24209_24TReturn = heff_take_reuse_n(v_x413_24209, 1ULL, 1);
        heff_drop(v_ps_24207);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_x1_24216 = v_rt_24208;
        V v_o_24217 = v_o_24215;
        V v_rest_24218 = v_rest_245;
        V v_t_24228;
        switch (heff_tag_of(v_x1_24216)) {
        case TAG_RetAs: {
          V v_r_24219 = heff_field(v_x1_24216, 0);
          heff_take_n(v_x1_24216, 1ULL, 1);
          switch (heff_tag_of(v_o_24217)) {
          case TAG_OSimple: {
            V v_v_24220 = heff_field(v_o_24217, 0);
            heff_take_n(v_o_24217, 1ULL, 1);
            heff_drop_cell(v_ru_24x413_24209_24TReturn, 1);
            v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 2, (V[]){v_r_24219, v_v_24220}), v_rest_24218});
            break;
          }
          case TAG_OCall: {
            heff_drop(v_r_24219);
            v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x413_24209_24TReturn, TAG_IOp, 1, (V[]){v_o_24217}), v_rest_24218});
            break;
          }
          case TAG_OApply: {
            heff_drop(v_r_24219);
            v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x413_24209_24TReturn, TAG_IOp, 1, (V[]){v_o_24217}), v_rest_24218});
            break;
          }
          case TAG_OPrim: {
            heff_drop(v_r_24219);
            v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x413_24209_24TReturn, TAG_IOp, 1, (V[]){v_o_24217}), v_rest_24218});
            break;
          }
          case TAG_OAbandon: {
            heff_drop(v_r_24219);
            v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x413_24209_24TReturn, TAG_IOp, 1, (V[]){v_o_24217}), v_rest_24218});
            break;
          }
          case TAG_OBool: {
            heff_drop(v_r_24219);
            v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x413_24209_24TReturn, TAG_IOp, 1, (V[]){v_o_24217}), v_rest_24218});
            break;
          }
          default: heff_nomatch(v_o_24217);
          }
          break;
        }
        case TAG_RetClass: {
          heff_drop_cell(v_ru_24x413_24209_24TReturn, 1);
          v_t_24228 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IBind, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), v_o_24217}), v_rest_24218});
          break;
        }
        default: heff_nomatch(v_x1_24216);
        }
        V t_0 = v_sg_240;
        V t_1 = NTAG(TAG_False);
        V t_2 = v_acc_242;
        V t_3 = v_t_24228;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24229 = heff_field(v_x413_24209, 0);
        heff_take_n(v_x413_24209, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_rt_24208);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_t_24230 = (g_list_2efoldl_24f155552269x628597815(NTAG(TAG_Nil), v_ps_24207, v_vs_24229));
        V v_t_24231 = (g_list_2efoldl_24s348204425x880103432(v_rest_245, v_t_24230));
        V t_0 = v_sg_240;
        V t_1 = NTAG(TAG_True);
        V t_2 = v_acc_242;
        V t_3 = v_t_24231;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24232 = heff_field(v_x413_24209, 0);
        V v_t_24233 = heff_field(v_x413_24209, 1);
        V v_e_24234 = heff_field(v_x413_24209, 2);
        V v_ru_24x413_24209_24TIf = heff_take_reuse_n(v_x413_24209, 7ULL, 3);
        V v_t_24235 = (g_heff_2ecompile_2erepr_2eloops(v_t_24233));
        V v_t_24236;
        if ((heff_dup(v_t_24235) == NTAG(TAG_True))) {
          heff_drop(v_t_24235);
          v_t_24236 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_24235);
          v_t_24236 = (g_heff_2ecompile_2erepr_2eloops(v_e_24234));
        }
        V v_t_24237 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24ITl, TAG_ITl, 3, (V[]){heff_dup(v_ps_24207), heff_dup(v_rt_24208), v_e_24234}), v_rest_245});
        V v_t_24238 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x413_24209_24TIf, TAG_ITl, 3, (V[]){v_ps_24207, v_rt_24208, v_t_24233}), v_t_24237});
        V v_t_24239 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24232}), v_t_24238});
        V t_0 = v_sg_240;
        V t_1 = v_t_24236;
        V t_2 = v_acc_242;
        V t_3 = v_t_24239;
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24240 = heff_field(v_x413_24209, 0);
        V v_arms_24241 = heff_field(v_x413_24209, 1);
        V v_ru_24x413_24209_24TCase = heff_take_reuse_n(v_x413_24209, 3ULL, 2);
        heff_drop_cell(v_ru_24x41_244_24ITl, 3);
        V v_t_24242 = (g_list_2eany_24s52266323x652150664(v_arms_24241));
        V v_t_24253 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2ewalk_lam3, 2, 1, (V[]){heff_dup(v_sg_240)}), v_acc_242, v_arms_24241));
        V v_t_24254 = heff_tag_at_n(v_ru_24x413_24209_24TCase, TAG_IVal, 2, (V[]){NTAG(TAG_RepV), v_v_24240});
        V v_t_24255 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24241));
        V v_t_24256 = (g_list_2efoldl_24s2145639387x28888241(v_ps_24207, v_rt_24208, v_rest_245, v_t_24255));
        V t_0 = v_sg_240;
        V t_1 = v_t_24242;
        V t_2 = v_t_24253;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_24254, v_t_24256});
        v_sg_240 = t_0;
        v_lp_241 = t_1;
        v_acc_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_x413_24209);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ewalk(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erepr_2ewalk_lam0(V self, V *args) {
  V v_i_2439 = args[0];
  V v_ts_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = ({ V a_0 = heff_dup(v_i_2439); V a_1 = v_ts_2436; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2436); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2439, v_t_2440));
}
V g_heff_2ecompile_2erepr_2ewalk_lam1(V self, V *args) {
  V v_x2_2473 = args[0];
  V v_i_2474 = args[1];
  V v_ks_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_MkPair: {
    V v_r_2475 = heff_field(v_x2_2473, 0);
    V v_v_2476 = heff_field(v_x2_2473, 1);
    V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
    V v_t_2477 = ({ V a_0 = v_i_2474; V a_1 = v_ks_2464; V r_ = (g_list_2eany_24s688114072x773797180(a_0, a_1)); heff_drop(v_ks_2464); r_; });
    if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
      heff_drop(v_r_2475);
      heff_drop_cell(v_ru_24x2_2473_24MkPair, 2);
      heff_drop(v_t_2477);
      return heff_tag_n(TAG_IAny, 1, (V[]){v_v_2476});
    } else {
      heff_drop(v_t_2477);
      return heff_tag_at_n(v_ru_24x2_2473_24MkPair, TAG_IVal, 2, (V[]){v_r_2475, v_v_2476});
    }
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_lam2(V self, V *args) {
  V v_acc_24192 = args[0];
  V v_x3_24193 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24193)) {
  case TAG_MkArm: {
    V v_t_24194 = heff_field(v_x3_24193, 0);
    V v_vs_24195 = heff_field(v_x3_24193, 1);
    heff_take_n(v_x3_24193, 3ULL, 3);
    HeffT2 v_t_24197 = ({ V b_0 = heff_get_n(v_sg_240, 1, 2); V a_1 = v_t_24194; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24194); r_; });
    V v_t_24201;
    {
      V v_field_24199 = v_t_24197.f[1];
      int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
      if ((v_tag_24198 == ((int64_t)0ULL))) {
        V v_x_24200 = v_field_24199;
        v_t_24201 = v_x_24200;
      } else {
        heff_drop(v_field_24199);
        v_t_24201 = NTAG(TAG_Nil);
      }
    }
    return (g_heff_2ecompile_2erepr_2epinFields(v_t_24201, v_acc_24192, v_vs_24195));
  }
  default: return heff_nomatch(v_x3_24193);
  }
}
V g_heff_2ecompile_2erepr_2ewalk_lam3(V self, V *args) {
  V v_acc_24243 = args[0];
  V v_x3_24244 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_24244)) {
  case TAG_MkArm: {
    V v_t_24245 = heff_field(v_x3_24244, 0);
    V v_vs_24246 = heff_field(v_x3_24244, 1);
    heff_take_n(v_x3_24244, 3ULL, 3);
    HeffT2 v_t_24248 = ({ V b_0 = heff_get_n(v_sg_240, 1, 2); V a_1 = v_t_24245; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_24245); r_; });
    V v_t_24252;
    {
      V v_field_24250 = v_t_24248.f[1];
      int64_t v_tag_24249 = ((int64_t)v_t_24248.f[0]);
      if ((v_tag_24249 == ((int64_t)0ULL))) {
        V v_x_24251 = v_field_24250;
        v_t_24252 = v_x_24251;
      } else {
        heff_drop(v_field_24250);
        v_t_24252 = NTAG(TAG_Nil);
      }
    }
    return (g_heff_2ecompile_2erepr_2epinFields(v_t_24252, v_acc_24243, v_vs_24246));
  }
  default: return heff_nomatch(v_x3_24244);
  }
}
Clo g_heff_2ecompile_2erepr_2edefEvents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edefEvents_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edefEvents(V v_sg_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkDef: {
    V v_key_242 = heff_field(v_x2_241, 0);
    V v_x23_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24MkDef = heff_take_reuse_n(v_x2_241, 5ULL, 3);
    switch (heff_tag_of(v_x23_244)) {
    case TAG_DefFun: {
      V v_xs_245 = heff_field(v_x23_244, 0);
      V v_x232_246 = heff_field(v_x23_244, 1);
      V v_ru_24x23_244_24DefFun = heff_take_reuse_n(v_x23_244, 3ULL, 2);
      switch (heff_tag_of(v_x232_246)) {
      case TAG_MkBlock: {
        V v_t_247 = heff_field(v_x232_246, 0);
        V v_ru_24x232_246_24MkBlock = heff_take_reuse_n(v_x232_246, 1ULL, 1);
        HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_sg_240, 0), v_key_242));
        V v_t_2412;
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_s_2411 = v_field_2410;
            v_t_2412 = heff_get_n(v_s_2411, 0, 2);
          } else {
            heff_drop(v_field_2410);
            v_t_2412 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_245)));
          }
        }
        V v_t_2413 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_245), v_t_2412));
        V v_t_2414 = (g_list_2efoldl_24s1854174827x1081689521(NTAG(TAG_Nil), v_t_2413));
        HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_sg_240, 0); V a_1 = v_key_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_key_242); r_; });
        V v_t_2419;
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_s_2418 = v_field_2417;
            v_t_2419 = heff_get_n(v_s_2418, 1, 2);
          } else {
            heff_drop(v_field_2417);
            v_t_2419 = NTAG(TAG_RepV);
          }
        }
        V v_t_2420 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){v_xs_245, heff_tag_at_n(v_ru_24x232_246_24MkBlock, TAG_RetAs, 1, (V[]){v_t_2419}), v_t_247});
        V v_t_2421 = heff_tag_at_n(v_ru_24x23_244_24DefFun, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), v_t_2414, v_t_2421));
      }
      default: return heff_nomatch(v_x232_246);
      }
    }
    case TAG_DefVal: {
      V v_x231_2422 = heff_field(v_x23_244, 0);
      V v_ru_24x23_244_24DefVal = heff_take_reuse_n(v_x23_244, 1ULL, 1);
      heff_drop(v_key_242);
      switch (heff_tag_of(v_x231_2422)) {
      case TAG_MkBlock: {
        V v_t_2423 = heff_field(v_x231_2422, 0);
        heff_take_n(v_x231_2422, 1ULL, 1);
        V v_t_2424 = heff_tag_at_n(v_ru_24x23_244_24DefVal, TAG_RetAs, 1, (V[]){NTAG(TAG_RepV)});
        V v_t_2425 = heff_tag_at_n(v_ru_24x2_241_24MkDef, TAG_ITl, 3, (V[]){NTAG(TAG_Nil), v_t_2424, v_t_2423});
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), NTAG(TAG_Nil), v_t_2426));
      }
      default: return heff_nomatch(v_x231_2422);
      }
    }
    default: return heff_nomatch(v_x23_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2edefEvents_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2edefEvents(a[0], a[1]);
}
Clo g_heff_2ecompile_2erepr_2easWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2easWord_entry, 2, 0};

V g_heff_2ecompile_2erepr_2easWord(V v_ws_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Merge: {
    return v_x2_241;
  }
  case TAG_Boxed: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Boxed = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_ws_240, v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_241_24Boxed, 1);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        return heff_tag_n(TAG_BoxedWord, 1, (V[]){v_x_244});
      } else {
        heff_drop(v_field_247);
        return heff_tag_at_n(v_ru_24x2_241_24Boxed, TAG_Boxed, 1, (V[]){v_x_244});
      }
    }
  }
  case TAG_BoxedWord: {
    return v_x2_241;
  }
  case TAG_Element: {
    return v_x2_241;
  }
  case TAG_Unboxed: {
    return v_x2_241;
  }
  case TAG_Literal: {
    return v_x2_241;
  }
  case TAG_Wants: {
    return v_x2_241;
  }
  case TAG_Binds: {
    return v_x2_241;
  }
  case TAG_Pinned: {
    return v_x2_241;
  }
  case TAG_Kept: {
    return v_x2_241;
  }
  case TAG_Often: {
    V v_e_2421 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Often = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_241_24Often, TAG_Often, 1, (V[]){heff_hole()});
    V v_u_2423 = (g_heff_2ecompile_2erepr_2easWord_24dps(v_ws_240, v_e_2421, heff_dup(v_cell_2422)));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2easWord_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2easWord(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2easWord_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2easWord_24dps_entry, 3, 0};

V g_heff_2ecompile_2erepr_2easWord_24dps(V v_ws_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Merge: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Boxed: {
    V v_x_245 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_ws_240, v_x_245));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        heff_drop(v_x_249);
        return heff_setField(v_d_242, MK_INT(0LL), heff_tag_n(TAG_BoxedWord, 1, (V[]){v_x_245}));
      } else {
        heff_drop(v_field_248);
        return heff_setField(v_d_242, MK_INT(0LL), heff_tag_n(TAG_Boxed, 1, (V[]){v_x_245}));
      }
    }
  }
  case TAG_BoxedWord: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Element: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Unboxed: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Literal: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Wants: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Binds: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Pinned: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Kept: {
    return heff_setField(v_d_242, MK_INT(0LL), v_x2_241);
  }
  case TAG_Often: {
    V v_e_2422 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Often = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_241_24Often, TAG_Often, 1, (V[]){heff_hole()});
    V v_u_2424 = heff_setField(v_d_242, MK_INT(0LL), heff_dup(v_cell_2423));
    heff_drop(v_u_2424);
    V t_0 = v_ws_240;
    V t_1 = v_e_2422;
    V t_2 = v_cell_2423;
    v_ws_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erepr_2easWord_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2easWord_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2erootFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2erootFrom_entry, 3, 0};

V g_heff_2ecompile_2erepr_2erootFrom(V v_parent_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return v_x_241;
  }
  case TAG_Just: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_x_241, v_y_243, 0)) {
      heff_drop(v_y_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return v_x_241;
    } else {
      heff_drop(v_x_241);
      V v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(v_ru_24x3_242_24Just, v_parent_240, v_y_243));
      V t_0 = v_parent_240;
      V t_1 = v_y_243;
      V t_2 = v_t_244;
      v_parent_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erepr_2erootFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2erootFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erepr_2eunite_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunite_entry, 3, 0};

V g_heff_2ecompile_2erepr_2eunite(V v_parent_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_240, v_a_241));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_a_241), v_t_243));
  V v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_240, v_b_242));
  V v_t_246 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, heff_dup(v_b_242), v_t_245));
  if (heff_strEq_c(v_t_244, v_t_246)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return v_parent_240;
  } else {
    V v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_240, v_a_241));
    V v_t_248 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_a_241, v_t_247));
    V v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_240, v_b_242));
    V v_t_2410 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_b_242, v_t_249));
    HEFF_LAST return g_std_2eordmap_2einsert_24s615484302x989744458(v_parent_240, v_t_248, v_t_2410);
  }
}
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2eunite(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erepr_2eunpinOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eunpinOne_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eunpinOne(V v_pins_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Merge: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_y_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24Merge = heff_take_reuse_n(v_e_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_pins_240, v_x_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24e_241_24Merge, 2);
        V v_x_247 = v_field_246;
        heff_drop(v_x_247);
        V v_t_248 = heff_tag_n(TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_249});
      } else {
        heff_drop(v_field_246);
        HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_pins_240, v_y_243));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24e_241_24Merge, 2);
            V v_x_2413 = v_field_2412;
            heff_drop(v_x_2413);
            V v_t_2414 = heff_tag_n(TAG_Wants, 2, (V[]){v_y_243, NTAG(TAG_RepV)});
            V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_242}), v_t_2415});
          } else {
            heff_drop(v_field_2412);
            return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_241_24Merge, TAG_Merge, 2, (V[]){v_x_242, v_y_243}), NTAG(TAG_Nil)});
          }
        }
      }
    }
  }
  case TAG_Boxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_BoxedWord: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Element: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Unboxed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Literal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Wants: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Binds: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Pinned: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Kept: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  case TAG_Often: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2erepr_2eunpinOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eunpinOne(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ecompile_2erepr_2enoStats_val;
static HEFF_ONCE g_heff_2ecompile_2erepr_2enoStats_st;
static V g_heff_2ecompile_2erepr_2enoStats_init(void) {
  return heff_rec_n(8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, (V[]){NTAG(TAG_Nil), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False)});
}
V g_heff_2ecompile_2erepr_2enoStats_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erepr_2enoStats_st)) return g_heff_2ecompile_2erepr_2enoStats_val;
  return heff_global(&g_heff_2ecompile_2erepr_2enoStats_val, &g_heff_2ecompile_2erepr_2enoStats_st, g_heff_2ecompile_2erepr_2enoStats_init);
}
Clo g_heff_2ecompile_2erepr_2ewithRepr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ewithRepr_entry, 2, 0};

V g_heff_2ecompile_2erepr_2ewithRepr(V v_r_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_r_240)) {
  case TAG_RepV: {
    return v_rs_241;
  }
  case TAG_RepFix: {
    V v_t_243 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_tag(v_r_240, 1);
      heff_drop(v_t_243);
      return v_rs_241;
    } else {
      heff_drop(v_t_243);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  case TAG_RepF64: {
    V v_t_244 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return v_rs_241;
    } else {
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  case TAG_RepInt: {
    V v_t_245 = (g_list_2eany_24s100684943x1504448948(v_r_240, v_rs_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return v_rs_241;
    } else {
      heff_drop(v_t_245);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_240, v_rs_241});
    }
  }
  default: return heff_nomatch(v_r_240);
  }
}
V g_heff_2ecompile_2erepr_2ewithRepr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ewithRepr(a[0], a[1]);
}
V g_heff_2ecompile_2erepr_2eseen_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2eseen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eseen_entry, 2, 0};

V g_heff_2ecompile_2erepr_2eseen(V v_x1_240, V v_s_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Merge: {
    return v_s_241;
  }
  case TAG_Boxed: {
    V v_t_245 = heff_take_field(v_s_241, 0);
    V v_t_246 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(1LL));
    V v_t_247 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_248 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_249 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2410 = heff_take_field(v_s_241, 5);
    V v_t_2411 = heff_get_n(v_s_241, 6, 8);
    return heff_rec_n(8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, (V[]){v_t_245, v_t_246, v_t_247, v_t_248, v_t_249, v_t_2410, v_t_2411, NTAG(TAG_True)});
  }
  case TAG_BoxedWord: {
    V v_r_2413 = NTAG(TAG_RepInt);
    V v_bi_2414 = MK_INT(1LL);
    V v_ui_2415 = MK_INT(0LL);
    V v_bo_2416 = MK_INT(0LL);
    V v_uo_2417 = MK_INT(0LL);
    V v_pin_2418 = NTAG(TAG_False);
    V v_s_2419 = v_s_241;
    V v_t_2420 = (g_heff_2ecompile_2erepr_2ewithRepr(v_r_2413, heff_take_field(v_s_2419, 0)));
    V v_t_2421 = heff_intAdd(heff_take_field(v_s_2419, 1), v_bi_2414);
    V v_t_2422 = heff_intAdd(heff_take_field(v_s_2419, 2), v_ui_2415);
    V v_t_2423 = heff_intAdd(heff_take_field(v_s_2419, 3), v_bo_2416);
    V v_t_2424 = heff_intAdd(heff_take_field(v_s_2419, 4), v_uo_2417);
    V v_t_2425 = heff_bool(((heff_dup(heff_rfield(v_s_2419, 5)) == NTAG(TAG_True)) || (heff_dup(v_pin_2418) == NTAG(TAG_True))));
    return ({ V rv_0 = v_t_2420; V rv_1 = v_t_2421; V rv_2 = v_t_2422; V rv_3 = v_t_2423; V rv_4 = v_t_2424; V rv_5 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_s_2419, 192ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61440u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Element: {
    return ({ V rv_7 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 127ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  }
  case TAG_Unboxed: {
    V v_r_2428 = heff_field(v_x1_240, 1);
    V v_t_2429 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2428), heff_take_field(v_s_241, 0)));
    V v_t_2430 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2431 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(1LL));
    V v_t_2432 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2433 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    return ({ V rv_0 = v_t_2429; V rv_1 = v_t_2430; V rv_2 = v_t_2431; V rv_3 = v_t_2432; V rv_4 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_s_241, 224ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 64512u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  }
  case TAG_Literal: {
    V v_r_2435 = heff_field(v_x1_240, 1);
    V v_t_2436 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2435), heff_take_field(v_s_241, 0)));
    V v_t_2437 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2438 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_2439 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2440 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    return ({ V rv_0 = v_t_2436; V rv_1 = v_t_2437; V rv_2 = v_t_2438; V rv_3 = v_t_2439; V rv_4 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_s_241, 224ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 64512u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  }
  case TAG_Wants: {
    V v_x12_2442 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2442)) {
    case TAG_RepV: {
      V v_t_2443 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2444 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2445 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(1LL));
      V v_t_2446 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
      return ({ V rv_1 = v_t_2443; V rv_2 = v_t_2444; V rv_3 = v_t_2445; V rv_4 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_s_241, 225ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 64515u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    case TAG_RepFix: {
      V v_t_2448 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_x12_2442), heff_take_field(v_s_241, 0)));
      V v_t_2449 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2450 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2451 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2452 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      return ({ V rv_0 = v_t_2448; V rv_1 = v_t_2449; V rv_2 = v_t_2450; V rv_3 = v_t_2451; V rv_4 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_s_241, 224ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 64512u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    case TAG_RepF64: {
      V v_t_2453 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_x12_2442), heff_take_field(v_s_241, 0)));
      V v_t_2454 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2455 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2456 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2457 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      return ({ V rv_0 = v_t_2453; V rv_1 = v_t_2454; V rv_2 = v_t_2455; V rv_3 = v_t_2456; V rv_4 = v_t_2457; V rr_ = heff_rec_reuse_nf(v_s_241, 224ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 64512u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    case TAG_RepInt: {
      V v_t_2458 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_x12_2442), heff_take_field(v_s_241, 0)));
      V v_t_2459 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
      V v_t_2460 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
      V v_t_2461 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
      V v_t_2462 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(1LL));
      return ({ V rv_0 = v_t_2458; V rv_1 = v_t_2459; V rv_2 = v_t_2460; V rv_3 = v_t_2461; V rv_4 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_s_241, 224ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 64512u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    default: return heff_nomatch(v_x12_2442);
    }
  }
  case TAG_Binds: {
    return v_s_241;
  }
  case TAG_Pinned: {
    V v_t_2465 = heff_intAdd(heff_take_field(v_s_241, 1), MK_INT(0LL));
    V v_t_2466 = heff_intAdd(heff_take_field(v_s_241, 2), MK_INT(0LL));
    V v_t_2467 = heff_intAdd(heff_take_field(v_s_241, 3), MK_INT(0LL));
    V v_t_2468 = heff_intAdd(heff_take_field(v_s_241, 4), MK_INT(0LL));
    V v_t_2469 = heff_bool(((heff_dup(heff_rfield(v_s_241, 5)) == NTAG(TAG_True)) || 1));
    return ({ V rv_1 = v_t_2465; V rv_2 = v_t_2466; V rv_3 = v_t_2467; V rv_4 = v_t_2468; V rv_5 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_s_241, 193ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 61443u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  case TAG_Kept: {
    V v_r_2471 = heff_field(v_x1_240, 1);
    V v_t_2472 = (g_heff_2ecompile_2erepr_2ewithRepr(heff_dup(v_r_2471), heff_take_field(v_s_241, 0)));
    return ({ V rv_0 = v_t_2472; V rv_6 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_r_2471)}); V rr_ = heff_rec_reuse_nf(v_s_241, 190ULL, 8, shape_reprs__boxedIn__unboxedIn__boxedOut__unboxedOut__pinned__kept__big, 53244u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  case TAG_Often: {
    V v_e_2473 = heff_field(v_x1_240, 0);
    V v_t_2474 = (g_list_2erange(MK_INT(1LL), MK_INT(8LL)));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2eseen_lam0, 2, 1, (V[]){heff_dup(v_e_2473)}); V a_1 = v_s_241; V a_2 = v_t_2474; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2474); r_; });
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2eseen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eseen(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2eseen_lam0(V self, V *args) {
  V v_acc_2475 = args[0];
  V v_x_2476 = args[1];
  V v_e_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2476);
  return ({ V a_0 = v_e_2473; V a_1 = v_acc_2475; V r_ = (g_heff_2ecompile_2erepr_2eseen(a_0, a_1)); heff_drop(v_e_2473); r_; });
}
Clo g_heff_2ecompile_2erepr_2eeventName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2eeventName_entry, 1, 0};

V g_heff_2ecompile_2erepr_2eeventName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Merge: {
    V v_x_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_241);
  }
  case TAG_Boxed: {
    V v_x_243 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_243);
  }
  case TAG_BoxedWord: {
    V v_x_244 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_244);
  }
  case TAG_Element: {
    V v_x_245 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_245);
  }
  case TAG_Unboxed: {
    V v_x_246 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_246);
  }
  case TAG_Literal: {
    V v_x_248 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_248);
  }
  case TAG_Wants: {
    V v_x_2410 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2410);
  }
  case TAG_Binds: {
    V v_x_2412 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2412);
  }
  case TAG_Pinned: {
    V v_x_2413 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2413);
  }
  case TAG_Kept: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2414);
  }
  case TAG_Often: {
    V v_e_2416 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2416;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erepr_2eeventName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erepr_2eeventName(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2erepr_2estatsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2estatsOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2estatsOf(V v_parent_240, V v_evs_241) {
top: ;
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erepr_2estatsOf_lam0, 2, 1, (V[]){heff_dup(v_parent_240)}), heff_dup(g_std_2eordmap_2eempty_get()), v_evs_241));
}
V g_heff_2ecompile_2erepr_2estatsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2estatsOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2estatsOf_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_e_243 = args[1];
  V v_parent_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_244 = (g_heff_2ecompile_2erepr_2eeventName(v_e_243));
  V v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_240, v_x_244));
  V v_root_246 = ({ V a_0 = v_parent_240; V a_1 = v_x_244; V a_2 = v_t_245; V r_ = (g_heff_2ecompile_2erepr_2erootFrom(a_0, a_1, a_2)); heff_drop(v_parent_240); r_; });
  HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_242, v_root_246));
  V v_t_2411;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_249;
      v_t_2411 = v_x_2410;
    } else {
      heff_drop(v_field_249);
      v_t_2411 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
  }
  V v_t_2412 = ({ V a_0 = v_e_243; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2erepr_2eseen(a_0, a_1)); heff_drop(v_e_243); r_; });
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, v_root_246, v_t_2412));
}
Clo g_heff_2ecompile_2erepr_2edecideOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecideOf_entry, 2, 0};

V g_heff_2ecompile_2erepr_2edecideOf(V v_s_240, V v_rs_241) {
top: ;
  V v_boxedIn_242 = heff_take_field(v_s_240, 1);
  V v_boxedOut_243 = heff_take_field(v_s_240, 3);
  V v_unboxedIn_244 = heff_take_field(v_s_240, 2);
  V v_unboxedOut_245 = heff_get_n(v_s_240, 4, 8);
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    heff_drop(v_boxedIn_242);
    heff_drop(v_boxedOut_243);
    heff_drop(v_unboxedIn_244);
    heff_drop(v_unboxedOut_245);
    return NTAG(TAG_RepV);
  }
  case TAG_Cons: {
    V v_r_246 = heff_field(v_rs_241, 0);
    V v_rs2_247 = heff_field(v_rs_241, 1);
    switch (heff_tag_of(v_rs2_247)) {
    case TAG_Nil: {
      V v_t_249;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_249 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_249 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_249 = MK_INT(2LL);
        break;
      }
      case TAG_RepInt: {
        v_t_249 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2412;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_2412 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_2410 = heff_field(v_r_246, 0);
        int64_t v_t_2411;
        switch (heff_tag_of(v_w_2410)) {
        case TAG_I8: {
          v_t_2411 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2411 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2411 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2411 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2411 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2411 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2411 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2411 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2411 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2410);
        }
        if ((v_t_2411 == ((int64_t)64ULL))) {
          v_t_2412 = MK_INT(2LL);
        } else {
          v_t_2412 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2412 = MK_INT(3LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2412 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2413 = heff_intAdd(heff_intMul(v_boxedIn_242, v_t_249), heff_intMul(v_boxedOut_243, v_t_2412));
      V v_t_2416;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_2416 = MK_INT(0LL);
        break;
      }
      case TAG_RepFix: {
        V v_w_2414 = heff_field(v_r_246, 0);
        int64_t v_t_2415;
        switch (heff_tag_of(v_w_2414)) {
        case TAG_I8: {
          v_t_2415 = ((int64_t)8ULL);
          break;
        }
        case TAG_I16: {
          v_t_2415 = ((int64_t)16ULL);
          break;
        }
        case TAG_I32: {
          v_t_2415 = ((int64_t)32ULL);
          break;
        }
        case TAG_I64: {
          v_t_2415 = ((int64_t)64ULL);
          break;
        }
        case TAG_U8: {
          v_t_2415 = ((int64_t)8ULL);
          break;
        }
        case TAG_U16: {
          v_t_2415 = ((int64_t)16ULL);
          break;
        }
        case TAG_U32: {
          v_t_2415 = ((int64_t)32ULL);
          break;
        }
        case TAG_U64: {
          v_t_2415 = ((int64_t)64ULL);
          break;
        }
        case TAG_F32: {
          v_t_2415 = ((int64_t)32ULL);
          break;
        }
        default: heff_nomatch(v_w_2414);
        }
        if ((v_t_2415 == ((int64_t)64ULL))) {
          v_t_2416 = MK_INT(2LL);
        } else {
          v_t_2416 = MK_INT(1LL);
        }
        break;
      }
      case TAG_RepF64: {
        v_t_2416 = MK_INT(3LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2416 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2418;
      switch (heff_tag_of(v_r_246)) {
      case TAG_RepV: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepFix: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      case TAG_RepF64: {
        v_t_2418 = MK_INT(2LL);
        break;
      }
      case TAG_RepInt: {
        v_t_2418 = MK_INT(1LL);
        break;
      }
      default: heff_nomatch(v_r_246);
      }
      V v_t_2419 = heff_intAdd(heff_intMul(v_unboxedIn_244, v_t_2416), heff_intMul(v_unboxedOut_245, v_t_2418));
      if (heff_intLe_c(v_t_2413, v_t_2419)) {
        return heff_dup(v_r_246);
      } else {
        return NTAG(TAG_RepV);
      }
    }
    case TAG_Cons: {
      heff_drop(v_boxedIn_242);
      heff_drop(v_boxedOut_243);
      heff_drop(v_unboxedIn_244);
      heff_drop(v_unboxedOut_245);
      return NTAG(TAG_RepV);
    }
    default: return heff_nomatch(v_rs2_247);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2ecompile_2erepr_2edecideOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecideOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erepr_2ehope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2ehope_entry, 1, 0};

V g_heff_2ecompile_2erepr_2ehope(V v_s_240) {
top: ;
  V v_kept_241 = heff_take_field(v_s_240, 6);
  V v_pinned_242 = heff_take_field(v_s_240, 5);
  V v_reprs_243 = heff_take_field(v_s_240, 0);
  V v_big_244 = heff_get_n(v_s_240, 7, 8);
  switch (heff_tag_of(v_kept_241)) {
  case TAG_Nothing: {
    if ((heff_dup(v_pinned_242) == NTAG(TAG_True))) {
      heff_drop(v_pinned_242);
      heff_drop(v_reprs_243);
      heff_drop(v_big_244);
      return NTAG(TAG_RepV);
    } else {
      heff_drop(v_pinned_242);
      V v_r_249;
      switch (heff_tag_of(v_reprs_243)) {
      case TAG_Nil: {
        v_r_249 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Cons: {
        V v_r_245 = heff_field(v_reprs_243, 0);
        V v_rs2_246 = heff_field(v_reprs_243, 1);
        heff_take_n(v_reprs_243, 3ULL, 2);
        switch (heff_tag_of(v_rs2_246)) {
        case TAG_Nil: {
          v_r_249 = v_r_245;
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_rs2_246, 0ULL, 2);
          heff_drop(v_r_245);
          v_r_249 = NTAG(TAG_RepV);
          break;
        }
        default: heff_nomatch(v_rs2_246);
        }
        break;
      }
      default: heff_nomatch(v_reprs_243);
      }
      switch (heff_tag_of(v_r_249)) {
      case TAG_RepV: {
        heff_drop(v_big_244);
        return v_r_249;
      }
      case TAG_RepFix: {
        heff_drop(v_big_244);
        return v_r_249;
      }
      case TAG_RepF64: {
        heff_drop(v_big_244);
        return v_r_249;
      }
      case TAG_RepInt: {
        if ((heff_dup(v_big_244) == NTAG(TAG_True))) {
          heff_drop(v_big_244);
          return NTAG(TAG_RepV);
        } else {
          heff_drop(v_big_244);
          return NTAG(TAG_RepInt);
        }
      }
      default: return heff_nomatch(v_r_249);
      }
    }
  }
  case TAG_Just: {
    V v_r_2411 = heff_field(v_kept_241, 0);
    heff_take_n(v_kept_241, 1ULL, 1);
    heff_drop(v_pinned_242);
    heff_drop(v_reprs_243);
    heff_drop(v_big_244);
    return v_r_2411;
  }
  default: return heff_nomatch(v_kept_241);
  }
}
V g_heff_2ecompile_2erepr_2ehope_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erepr_2ehope(a[0]);
}
Clo g_heff_2ecompile_2erepr_2edecidedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erepr_2edecidedIn_entry, 3, 0};

V g_heff_2ecompile_2erepr_2edecidedIn(V v_parent_240, V v_stats_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932(v_parent_240, v_x_242));
  V v_t_244 = (g_heff_2ecompile_2erepr_2erootFrom(v_parent_240, v_x_242, v_t_243));
  HeffT2 v_t_245 = ({ V a_0 = v_stats_241; V a_1 = v_t_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_s_249;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_s_249 = v_x_248;
    } else {
      heff_drop(v_field_247);
      v_s_249 = heff_dup(g_heff_2ecompile_2erepr_2enoStats_get());
    }
    V v_t_2410 = heff_dup(heff_rfield(v_s_249, 6));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      V v_t_2411 = heff_dup(heff_rfield(v_s_249, 5));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_s_249, 8);
        heff_drop(v_t_2411);
        return NTAG(TAG_RepV);
      } else {
        heff_drop(v_t_2411);
        V v_r_2412 = (g_heff_2ecompile_2erepr_2edecideOf(heff_dup(v_s_249), heff_rfield(v_s_249, 0)));
        switch (heff_tag_of(v_r_2412)) {
        case TAG_RepV: {
          heff_drop_rec(v_s_249, 8);
          return v_r_2412;
        }
        case TAG_RepFix: {
          heff_drop_rec(v_s_249, 8);
          return v_r_2412;
        }
        case TAG_RepF64: {
          heff_drop_rec(v_s_249, 8);
          return v_r_2412;
        }
        case TAG_RepInt: {
          V v_t_2414 = heff_get_n(v_s_249, 7, 8);
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            return NTAG(TAG_RepV);
          } else {
            heff_drop(v_t_2414);
            return NTAG(TAG_RepInt);
          }
        }
        default: return heff_nomatch(v_r_2412);
        }
      }
    }
    case TAG_Just: {
      V v_r_2415 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      heff_drop_rec(v_s_249, 8);
      return v_r_2415;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
}
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erepr_2edecidedIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2erepr_2eproposeSig_24cpr(V v_sg_240, V v_bounces_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(g_heff_2ecompile_2erepr_2eretName_get()), NTAG(TAG_RepV)});
  V v_t_245 = (g_list_2emap_24s1917875516x88484758(heff_dup(v_xs_242)));
  V v_t_246 = (g_list_2efoldl_24s1854174827x1081689521(NTAG(TAG_Nil), v_t_245));
  V v_t_247 = heff_tag_n(TAG_ITl, 3, (V[]){heff_dup(v_xs_242), NTAG(TAG_RetClass), v_t_243});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_heff_2ecompile_2erepr_2ewalk(v_sg_240, NTAG(TAG_False), v_t_246, v_t_248));
  V v_evs_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_249});
  V v_pins_2411 = (g_list_2efoldl_24s1134919403x2060330530(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2410));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_evs_2410));
  V v_evs_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0, 2, 1, (V[]){v_pins_2411}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
  V v_parent_2417 = (g_list_2efoldl_24s1275727578x1654209034(heff_dup(g_std_2eordmap_2eempty_get()), v_evs_2416));
  V v_t_2418 = (g_heff_2ecompile_2erepr_2estatsOf(v_parent_2417, v_evs_2416));
  V v_f_2419 = ({ V a_0 = v_parent_2417; V a_1 = v_t_2418; V a_2 = v_xs_242; V r_ = (g_list_2emap_24s1310249268x749995235(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  V v_f_2421;
  if ((heff_dup(v_bounces_241) == NTAG(TAG_True))) {
    heff_drop(v_evs_2416);
    heff_drop(v_parent_2417);
    v_f_2421 = NTAG(TAG_RepV);
  } else {
    V v_t_2420 = ({ V a_0 = v_parent_2417; V a_1 = v_evs_2416; V r_ = (g_heff_2ecompile_2erepr_2estatsOf(a_0, a_1)); heff_drop(v_evs_2416); r_; });
    v_f_2421 = ({ V a_0 = v_parent_2417; V a_1 = v_t_2420; V a_2 = heff_dup(g_heff_2ecompile_2erepr_2eretName_get()); V r_ = (g_heff_2ecompile_2erepr_2edecidedIn(a_0, a_1, a_2)); heff_drop(v_parent_2417); heff_drop(v_t_2420); r_; });
  }
  return ((HeffT2){{v_f_2419, v_f_2421}});
}
V g_heff_2ecompile_2erepr_2eproposeSig_24cpr_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_x_2414 = args[1];
  V v_pins_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = v_pins_2411; V a_1 = v_x_2414; V r_ = (g_heff_2ecompile_2erepr_2eunpinOne(a_0, a_1)); heff_drop(v_pins_2411); r_; });
  return (g_prelude_2e_2b_2b(v_t_2415, v_acc_2413));
}