// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_answered 245579351
#define LBL_args 9498020
#define LBL_fun 311289
#define LBL_result 1012715336
#define LBL_tag 324116
static uint32_t shape_tag__fun__args__result__answered[] = {LBL_tag, LBL_fun, LBL_args, LBL_result, LBL_answered};
V g_heff_2ecompile_2eglue_2eargsBad(V, V, V, V);
V g_heff_2ecompile_2eglue_2eargsBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eargsBad_clo;
V g_heff_2ecompile_2eglue_2ebindingOf(V, V);
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ebindingOf_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
HeffT2 g_heff_2ecompile_2eglue_2efirstBad_24cpr(V);
V g_heff_2ecompile_2eglue_2eisGlobalTy(V, V);
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo;
V g_heff_2ecompile_2eglue_2ejusts_24dps(V, V);
V g_heff_2ecompile_2eglue_2ejusts_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_24dps_clo;
HeffT2 g_heff_2ecompile_2eglue_2elastOf_24cpr(V);
V g_heff_2ecompile_2eglue_2eresultBad(V, V, V);
V g_heff_2ecompile_2eglue_2eresultBad_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eresultBad_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
Clo g_heff_2ecompile_2eglue_2eisGlobalTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2eisGlobalTy_entry, 2, 0};

V g_heff_2ecompile_2eglue_2eisGlobalTy(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SDecode: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24SDecode = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SLocal: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SGlobal: {
      V v_g_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return heff_strEq_lent(v_g_245, v_k_240, 1);
    }
    case TAG_SCode: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x21_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      V v_e_2421 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      V t_0 = v_k_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24SDecode, TAG_SDecode, 1, (V[]){v_e_2421});
      v_k_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x21_243, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x21_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x21_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24SDecode, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_x2_241, 0ULL, 5);
    return NTAG(TAG_False);
  }
  case TAG_SRecord: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SIsTy: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimRune: {
    return NTAG(TAG_False);
  }
  case TAG_SPrimArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eglue_2eisGlobalTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eglue_2eisGlobalTy(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eglue_2elastOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_241}});
    }
    case TAG_Cons: {
      heff_drop(v_x_241);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str0, 33, "` has no field: no answer to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str1, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str2, 33, "` has no field: no answer to give");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str3, 1, "`");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str4, 14, " are described");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str5, 31, " arguments and its answer, but ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str6, 6, "` has ");
HEFF_LIT(g_heff_2ecompile_2eglue_2ebindingOf_str7, 1, "`");
Clo g_heff_2ecompile_2eglue_2ebindingOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ebindingOf_entry, 2, 0};

V g_heff_2ecompile_2eglue_2ebindingOf(V v_r_240, V v_fields_241) {
top: ;
  if ((heff_unbox_word(heff_arrayLength_lent(v_fields_241, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_fields_241);
    V v_t_243 = heff_strAppend(heff_get_n(v_r_240, 0, 4), ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str0));
    return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str1), v_t_243)});
  } else {
    V v_x_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_240, 2)));
    int64_t v_t_245 = (heff_unbox_word(heff_arrayLength_lent(v_fields_241, 0)) - ((int64_t)1ULL));
    if (heff_intEq_c(v_x_244, heff_box_word(v_t_245))) {
      HeffT2 v_t_247 = (g_heff_2ecompile_2eglue_2elastOf_24cpr(heff_arrayToList(heff_dup(v_fields_241))));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_last_2411 = v_field_249;
          V v_t_2412 = ({ V a_0 = heff_dup(heff_rfield(v_r_240, 0)); V a_1 = MK_INT(0LL); V a_2 = heff_rfield(v_r_240, 2); V b_3 = heff_arrayToList(v_fields_241); V r_ = (g_heff_2ecompile_2eglue_2eargsBad(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          V v_t_2413 = (g_heff_2ecompile_2eglue_2eresultBad(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(heff_rfield(v_r_240, 3)), heff_dup(v_last_2411)));
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
          HeffT2 v_t_2415 = (g_heff_2ecompile_2eglue_2efirstBad_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414})));
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              heff_drop_rec(v_r_240, 4);
              heff_drop(v_last_2411);
              V v_m_2419 = v_field_2417;
              return heff_tag_n(TAG_Left, 1, (V[]){v_m_2419});
            } else {
              heff_drop(v_field_2417);
              V v_t_2434;
              switch (heff_tag_of(v_last_2411)) {
              case TAG_SU: {
                heff_take_n(v_last_2411, 0ULL, 1);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SDecode: {
                heff_take_n(v_last_2411, 0ULL, 1);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SFunction: {
                heff_take_n(v_last_2411, 0ULL, 5);
                v_t_2434 = NTAG(TAG_True);
                break;
              }
              case TAG_SRecord: {
                heff_take_n(v_last_2411, 0ULL, 3);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SSum: {
                heff_take_n(v_last_2411, 0ULL, 1);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SIsTy: {
                heff_take_n(v_last_2411, 0ULL, 1);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SPrimInt: {
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SPrimFloat: {
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SPrimString: {
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SPrimRune: {
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SPrimArray: {
                heff_take_n(v_last_2411, 0ULL, 1);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              case TAG_SFixed: {
                heff_take_n(v_last_2411, 0ULL, 1);
                v_t_2434 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_last_2411);
              }
              V v_t_2435 = heff_rec_n(5, shape_tag__fun__args__result__answered, (V[]){heff_take_field(v_r_240, 0), heff_take_field(v_r_240, 1), heff_take_field(v_r_240, 2), heff_get_n(v_r_240, 3, 4), v_t_2434});
              return heff_tag_n(TAG_Right, 1, (V[]){v_t_2435});
            }
          }
        } else {
          heff_drop(v_fields_241);
          heff_drop(v_field_249);
          V v_t_2436 = heff_strAppend(heff_get_n(v_r_240, 0, 4), ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str2));
          return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str3), v_t_2436)});
        }
      }
    } else {
      int64_t v_t_2437 = (heff_unbox_word(heff_arrayLength(v_fields_241)) - ((int64_t)1ULL));
      V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_240, 2)));
      V v_t_2439 = heff_strAppend(heff_intShow(v_t_2438), ((V)&g_heff_2ecompile_2eglue_2ebindingOf_str4));
      V v_t_2440 = heff_strAppend(heff_intShow(heff_box_word(v_t_2437)), heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str5), v_t_2439));
      V v_t_2441 = heff_strAppend(heff_get_n(v_r_240, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str6), v_t_2440));
      return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eglue_2ebindingOf_str7), v_t_2441)});
    }
  }
}
V g_heff_2ecompile_2eglue_2ebindingOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ebindingOf(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      V v_why_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_243}});
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_245 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_rest_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_244);
          V v_why_249 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_249}});
        } else {
          V v_xs_2410 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_xs_2410})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eglue_2ejusts_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eglue_2ejusts_24dps_entry, 2, 0};

V g_heff_2ecompile_2eglue_2ejusts_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eglue_2ejusts_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eglue_2ejusts_24dps(a[0], a[1]);
}