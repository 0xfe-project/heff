// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_LNil 57394
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_N 306
#define TAG_SCode 58360
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_by 9918
#define LBL_byName 571997869
#define LBL_cached 579094605
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_discarded 1490202606
#define LBL_effect 641056956
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_err 310239
#define LBL_failure 1292767177
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_groups 709681407
#define LBL_i 323
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_known 303562589
#define LBL_labels 836724522
#define LBL_lenient 294367673
#define LBL_level 304224158
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_multi 305615187
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opens 307306371
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_places 961367927
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_key__by__span[] = {LBL_key, LBL_by, LBL_span};
static uint32_t shape_key__effect[] = {LBL_key, LBL_effect};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_decls, LBL_top, LBL_diags, LBL_own, LBL_deps, LBL_opens, LBL_aliases, LBL_fixities, LBL_cached};
static uint32_t shape_name__key__ty__level[] = {LBL_name, LBL_key, LBL_ty, LBL_level};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_out__multi__first[] = {LBL_out, LBL_multi, LBL_first};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2eaddTests(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eaddTests_clo;
V g_heff_2ebuild_2edriver_2eagainGo(V, V, V);
V g_heff_2ebuild_2edriver_2eagainGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eagainGo_clo;
V g_heff_2ebuild_2edriver_2ealiasModule(V, V);
V g_heff_2ebuild_2edriver_2ealiasModule_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasModule_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasQOne(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eclashMap(V, V);
V g_heff_2ebuild_2edriver_2eclashMap_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclashMap_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062(V, V, V, V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_clo;
V g_heff_2ebuild_2edriver_2eearlierGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eearlierGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eelabDecls(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabDecls_clo;
V g_heff_2ebuild_2edriver_2eelabDirect(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabDirect_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabDirect_clo;
V g_heff_2ebuild_2edriver_2eelabEnv(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabEnv_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabEnv_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2eelabRead(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabRead_clo;
V g_heff_2ebuild_2edriver_2eelabTop(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabTop_clo;
V g_heff_2ebuild_2edriver_2eenvOne(V, V);
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eenvOne_clo;
V g_heff_2ebuild_2edriver_2eevalWatch(V, V);
V g_heff_2ebuild_2edriver_2eevalWatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalWatch_clo;
V g_heff_2ebuild_2edriver_2efailureOfV(V);
V g_heff_2ebuild_2edriver_2efailureOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efailureOfV_clo;
V g_heff_2ebuild_2edriver_2efieldV(V, V);
V g_heff_2ebuild_2edriver_2efieldV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efieldV_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindFirst_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efits_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixOf(V, V);
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixOf_clo;
V g_heff_2ebuild_2edriver_2efixityLines(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_clo;
V g_heff_2ebuild_2edriver_2eimportLines(V);
V g_heff_2ebuild_2edriver_2eimportLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportLines_clo;
V g_heff_2ebuild_2edriver_2eintegrationOfV(V);
V g_heff_2ebuild_2edriver_2eintegrationOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eintegrationOfV_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
V g_heff_2ebuild_2edriver_2eknownIn(V, V);
V g_heff_2ebuild_2edriver_2eknownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eknownIn_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2emoduleStruct(V, V, V);
V g_heff_2ebuild_2edriver_2emoduleStruct_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emoduleStruct_clo;
V g_heff_2ebuild_2edriver_2enubByName(V);
V g_heff_2ebuild_2edriver_2enubByName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubByName_clo;
V g_heff_2ebuild_2edriver_2enubByName_24dps(V, V);
V g_heff_2ebuild_2edriver_2enubByName_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubByName_24dps_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2eopenNames_24dps(V, V);
V g_heff_2ebuild_2edriver_2eopenNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_24dps_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2edriver_2epickIntegrations(V, V, V);
V g_heff_2ebuild_2edriver_2epickIntegrations_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickIntegrations_clo;
V g_heff_2ebuild_2edriver_2epickOutcomes(V, V, V, V);
V g_heff_2ebuild_2edriver_2epickOutcomes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickOutcomes_clo;
V g_heff_2ebuild_2edriver_2eprimDeclsGo(V, V, V);
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo;
V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(V, V, V, V);
V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_clo;
HeffT2 g_heff_2ebuild_2edriver_2ereadExpRead_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
HeffT2 g_heff_2ebuild_2edriver_2erunTests_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
V g_heff_2ebuild_2edriver_2eskippedOfV(V);
V g_heff_2ebuild_2edriver_2eskippedOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eskippedOfV_clo;
HeffT2 g_heff_2ebuild_2edriver_2espanOfName_24cpr(V, V);
V g_heff_2ebuild_2edriver_2estructAdd(V, V, V, V);
V g_heff_2ebuild_2edriver_2estructAdd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructAdd_clo;
V g_heff_2ebuild_2edriver_2estructBody(V, V, V);
V g_heff_2ebuild_2edriver_2estructBody_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructBody_clo;
V g_heff_2ebuild_2edriver_2estructEntryOf(V, V);
V g_heff_2ebuild_2edriver_2estructEntryOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructEntryOf_clo;
V g_heff_2ebuild_2edriver_2estructFieldsGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructFieldsGo_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2edriver_2etwicesGo(V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2edriver_2ewithEntry(V, V, V);
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithEntry_clo;
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_clo;
V g_heff_2ebuild_2edriver_2ewithTwice(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithTwice_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515_clo;
HeffT2 g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(V, V);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eunderBrokenFrom(V, V, V);
V g_heff_2eelab_2eglobals_2eunderBrokenFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eunderBrokenFrom_clo;
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT3 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1450888590x1561911320(V, V, V, V);
V g_list_2efilter_24s1450888590x1561911320_entry(V self, V *a);
extern Clo g_list_2efilter_24s1450888590x1561911320_clo;
V g_list_2efilter_24s334334379x923000927(V, V);
V g_list_2efilter_24s334334379x923000927_entry(V self, V *a);
extern Clo g_list_2efilter_24s334334379x923000927_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1702742059x483228236_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f139246788x401086883(V, V);
V g_list_2efoldl_24f139246788x401086883_entry(V self, V *a);
extern Clo g_list_2efoldl_24f139246788x401086883_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2efoldl_24s1634882103x1209760496(V, V);
V g_list_2efoldl_24s1634882103x1209760496_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1634882103x1209760496_clo;
V g_list_2efoldl_24s1651927898x830279104(V, V);
V g_list_2efoldl_24s1651927898x830279104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651927898x830279104_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s810240426x431529267(V, V);
V g_list_2efoldl_24s810240426x431529267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s810240426x431529267_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1502491305x440718220(V, V);
V g_list_2emap_24f1502491305x440718220_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_clo;
V g_list_2emap_24f489129082x766375942(V, V, V, V, V);
V g_list_2emap_24f489129082x766375942_entry(V self, V *a);
extern Clo g_list_2emap_24f489129082x766375942_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1183242293x627656570(V, V);
V g_list_2emap_24s1183242293x627656570_entry(V self, V *a);
extern Clo g_list_2emap_24s1183242293x627656570_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1512999845x472671375(V, V, V, V, V);
V g_list_2emap_24s1512999845x472671375_entry(V self, V *a);
extern Clo g_list_2emap_24s1512999845x472671375_clo;
V g_list_2emap_24s1517387949x485543551(V);
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s204237290x1967740547(V, V, V, V);
V g_list_2emap_24s204237290x1967740547_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;

HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_c_242}});
    } else {
      heff_drop_rec(v_c_242, 13);
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eenvOne_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2edriver_2eenvOne_str1, 2, "#T");
V g_heff_2ebuild_2edriver_2eenvOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eenvOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eenvOne_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eenvOne(V v_c_240, V v_g_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), ((V)&g_heff_2ebuild_2edriver_2eenvOne_str0));
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), ((V)&g_heff_2ebuild_2edriver_2eenvOne_str1));
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_245 = ({ V b_0 = heff_get_n(v_t_244, 3, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_246 = (g_list_2emap_24s1415906091x1371825187(v_t_245));
  V v_t_247 = ({ V a_0 = v_g_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1651927898x830279104(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_2410 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edriver_2eenvOne_lam0, 2, 1, (V[]){heff_dup(v_c_240)}), v_t_247, heff_rfield(v_c_240, 7)));
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ewithEntry(v_t_243, heff_dup(v_c_240), v_t_2410));
  return (g_heff_2ebuild_2edriver_2ewithEntry(v_t_242, v_c_240, v_t_2411));
}
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eenvOne(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eenvOne_lam0(V self, V *args) {
  V v_g2_248 = args[0];
  V v_o_249 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2ewithEntry(heff_get_n(v_o_249, 1, 2), v_c_240, v_g2_248));
}
Clo g_heff_2ebuild_2edriver_2enubByName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubByName_entry, 1, 0};

V g_heff_2ebuild_2edriver_2enubByName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_o_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s334334379x923000927(v_o_241, v_rest_242));
    V v_u_245 = (g_heff_2ebuild_2edriver_2enubByName_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubByName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2enubByName(a[0]);
}
Clo g_heff_2ebuild_2edriver_2eclashMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eclashMap_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eclashMap(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_o_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_m_240, heff_rfield(v_o_242, 0)));
    V v_t_2414;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_it1_248 = v_field_246;
        switch (heff_tag_of(v_it1_248)) {
        case TAG_MkPair: {
          V v_k_249 = heff_field(v_it1_248, 0);
          V v_c_2410 = heff_field(v_it1_248, 1);
          heff_take_n(v_it1_248, 3ULL, 2);
          if ((heff_dup(v_c_2410) == NTAG(TAG_True))) {
            heff_drop_rec(v_o_242, 3);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_k_249);
            heff_drop(v_c_2410);
            v_t_2414 = v_m_240;
          } else {
            heff_drop(v_c_2410);
            if (heff_strEq_c(heff_dup(v_k_249), heff_dup(heff_rfield(v_o_242, 1)))) {
              heff_drop_rec(v_o_242, 3);
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              heff_drop(v_k_249);
              v_t_2414 = v_m_240;
            } else {
              V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_k_249, NTAG(TAG_True)});
              v_t_2414 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, heff_get_n(v_o_242, 0, 3), v_t_2412));
            }
          }
          break;
        }
        default: heff_nomatch(v_it1_248);
        }
      } else {
        heff_drop(v_field_246);
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_o_242, 1)), NTAG(TAG_False)});
        v_t_2414 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, heff_get_n(v_o_242, 0, 3), v_t_2413));
      }
    }
    V t_0 = v_t_2414;
    V t_1 = v_rest_243;
    v_m_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eclashMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eclashMap(a[0], a[1]);
}

HeffT2 g_heff_2ebuild_2edriver_2espanOfName_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_sp_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_x_241, v_y_244, 2)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_245}});
      } else {
        heff_drop(v_sp_245);
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str2, 1, ".");
V g_heff_2ebuild_2edriver_2ealiasQOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasQOne_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ealiasQOne(V v_done_240, V v_g_241, V v_q_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_240, heff_rfield(v_q_242, 0)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_c_247 = v_field_245;
      V v_t_248 = (g_heff_2ebuild_2edriver_2ealiasModule(v_g_241, heff_dup(v_q_242)));
      V v_t_249 = (g_list_2emap_24s1183242293x627656570(heff_dup(v_c_247), heff_dup(heff_rfield(v_c_247, 7))));
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_c_247, 5)), 0, 9);
      V v_t_2411 = ({ V b_0 = heff_get_n(v_t_2410, 3, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2412 = ({ V a_0 = v_c_247; V a_1 = ((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = v_t_2411; V r_ = (g_list_2emap_24f489129082x766375942(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
      V v_t_2413 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2412));
      V v_t_2414 = (g_heff_2ebuild_2edriver_2eappendD(v_t_249, v_t_2413));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ealiasQOne_lam0, 2, 1, (V[]){v_q_242}); V a_1 = v_t_248; V a_2 = v_t_2414; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
    } else {
      heff_drop(v_field_245);
      V v_t_2420 = heff_strAppend(heff_get_n(v_q_242, 1, 2), ((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str2));
      V v_t_2421 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g_241, 3), v_t_2420, NTAG(TAG_MkUnit)));
      return ({ V rv_3 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_g_241, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    }
  }
}
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasQOne(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2ealiasQOne_lam0(V self, V *args) {
  V v_g2_2415 = args[0];
  V v_o_2416 = args[1];
  V v_q_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str1), heff_take_field(v_o_2416, 0));
  V v_t_2418 = heff_strAppend(heff_get_n(v_q_242, 1, 2), v_t_2417);
  V v_t_2419 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g2_2415, 2), v_t_2418, heff_get_n(v_o_2416, 1, 3)));
  return ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_g2_2415, 123ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2ebuild_2edriver_2eknownIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eknownIn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eknownIn(V v_g_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_240, 2), v_x_241));
  V v_t_2417;
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_k_246 = v_field_244;
      HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_g_240, 1); V a_1 = v_k_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_246); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_e_2411 = v_field_249;
          v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_e_2411});
        } else {
          heff_drop(v_field_249);
          v_t_2417 = NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_field_244);
      HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_240, 1), v_x_241));
      {
        V v_field_2414 = v_t_2412.f[1];
        int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
        if ((v_tag_2413 == ((int64_t)0ULL))) {
          V v_e_2416 = v_field_2414;
          v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){v_e_2416});
        } else {
          heff_drop(v_field_2414);
          v_t_2417 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    HeffT2 v_t_2418 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_240, 4), v_x_241));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop_rec(v_g_240, 7);
        V v_x_2422 = v_field_2420;
        heff_drop(v_x_2422);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_field_2420);
        return (g_heff_2eelab_2eglobals_2eunderBrokenFrom(v_g_240, v_x_241, MK_INT(0LL)));
      }
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop_rec(v_g_240, 7);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2ebuild_2edriver_2eknownIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eknownIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2eopenNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eopenNames_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eopenNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_i_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_i_241, 0, 3), heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edriver_2eopenNames_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop_rec(v_i_241, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eopenNames(a[0]);
}
Clo g_heff_2ebuild_2edriver_2estructEntryOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructEntryOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2estructEntryOf(V v_g_240, V v_o_241) {
top: ;
  V v_k_242 = heff_dup(heff_rfield(v_o_241, 1));
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_240, 1), v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_k_242);
      V v_e_247 = v_field_245;
      V v_t_248 = (g_heff_2eelab_2evalue_2elevelOf(heff_rfield(v_e_247, 3)));
      V v_t_249 = heff_rec_n(4, shape_name__key__ty__level, (V[]){heff_take_field(v_o_241, 0), heff_get_n(v_o_241, 1, 2), heff_get_n(v_e_247, 1, 4), v_t_248});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_g_240, 2); V a_1 = v_k_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_242); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k2_2414 = v_field_2412;
          HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_g_240, 1, 7); V a_1 = v_k2_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2414); r_; });
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              V v_e_2419 = v_field_2417;
              V v_t_2420 = (g_heff_2eelab_2evalue_2elevelOf(heff_rfield(v_e_2419, 3)));
              V v_t_2421 = heff_rec_n(4, shape_name__key__ty__level, (V[]){heff_take_field(v_o_241, 0), heff_get_n(v_o_241, 1, 2), heff_get_n(v_e_2419, 1, 4), v_t_2420});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
            } else {
              heff_drop_rec(v_o_241, 2);
              heff_drop(v_field_2417);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop_rec(v_g_240, 7);
          heff_drop_rec(v_o_241, 2);
          heff_drop(v_field_2412);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2estructEntryOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2estructEntryOf(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry, 6, 0};

V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(V v_r_240, V v_i_241, V v_depth_242, V v_j_243, V v_x5_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    heff_drop(v_j_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x51_246 = heff_field(v_x5_244, 0);
    V v_rest_247 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x51_246, 0);
      V v_t_249 = heff_field(v_x51_246, 1);
      heff_take_n(v_x51_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), heff_dup(v_j_243)), v_t_249}));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_t_2410}), heff_hole()});
      V v_u_2412 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_r_240;
      V t_1 = v_i_241;
      V t_2 = v_depth_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_rest_247;
      V t_5 = v_cell_2411;
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x51_246);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_t_244)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SDecode = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e_246}));
    return heff_tag_at_n(v_ru_24t_244_24SDecode, TAG_SDecode, 1, (V[]){v_t_247});
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_t_244, 0);
    V v_dom_249 = heff_field(v_t_244, 1);
    V v_cod_2410 = heff_field(v_t_244, 2);
    V v_implicit_2411 = heff_field(v_t_244, 3);
    V v_dflt_2412 = heff_field(v_t_244, 4);
    V v_ru_24t_244_24SFunction = heff_take_reuse_n(v_t_244, 31ULL, 5);
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_dom_249}));
    V v_t_2419;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_cod_2410, 0);
      V v_t_2415 = heff_field(v_cod_2410, 1);
      V v_ru_24cod_2410_24MkAbs = heff_take_reuse_n(v_cod_2410, 3ULL, 2);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2415}));
      v_t_2419 = heff_tag_at_n(v_ru_24cod_2410_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2414, v_t_2416});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2417 = heff_field(v_cod_2410, 0);
      V v_ru_24cod_2410_24AbsConst = heff_take_reuse_n(v_cod_2410, 1ULL, 1);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2417}));
      v_t_2419 = heff_tag_at_n(v_ru_24cod_2410_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2418});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    return heff_tag_at_n(v_ru_24t_244_24SFunction, TAG_SFunction, 5, (V[]){v_level_248, v_t_2413, v_t_2419, v_implicit_2411, v_dflt_2412});
  }
  case TAG_SRecord: {
    V v_level_2420 = heff_field(v_t_244, 0);
    V v_fs_2421 = heff_field(v_t_244, 1);
    V v_ds_2422 = heff_field(v_t_244, 2);
    V v_ru_24t_244_24SRecord = heff_take_reuse_n(v_t_244, 7ULL, 3);
    V v_t_2423 = heff_arrayToList(heff_take_field(v_fs_2421, 0));
    V v_t_2424 = heff_arrayToList(heff_get_n(v_fs_2421, 2, 3));
    V v_t_2425 = (g_heff_2eutil_2edict_2ezipKV(v_t_2423, v_t_2424));
    V v_pairs_2426 = (g_heff_2ebuild_2edriver_2ecloseFieldsGo(v_r_240, v_i_242, v_depth_243, MK_INT(0LL), v_t_2425));
    V v_t_2427 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2426)));
    V v_t_2428 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2426));
    V v_t_2429 = (g_list_2emap_24s1173914895x100384474(v_pairs_2426));
    V v_t_2430 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2427), v_t_2428, heff_arrayFromList(v_t_2429)});
    return heff_tag_at_n(v_ru_24t_244_24SRecord, TAG_SRecord, 3, (V[]){v_level_2420, v_t_2430, v_ds_2422});
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SSum = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_xs_2432 = heff_take_field(v_vs_2431, 2);
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2432, 0), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTypeF_lam0, 1, 4, (V[]){v_xs_2432, v_r_240, v_i_242, v_depth_243}));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_vs_2431, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_244_24SSum, TAG_SSum, 1, (V[]){v_t_2438});
  }
  case TAG_SIsTy: {
    V v_t2_2439 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SIsTy = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t2_2439}));
    return heff_tag_at_n(v_ru_24t_244_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2440});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimArray: {
    V v_t2_2441 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SPrimArray = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t2_2441}));
    return heff_tag_at_n(v_ru_24t_244_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2442});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecloseTypeF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_xs_2434 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t2_2436 = heff_arrayIndex(v_xs_2434, v_i_2435);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_t2_2436;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam0(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2434, 0), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTypeF_lam1, 1, 4, (V[]){v_xs_2434, v_r_240, v_i_242, v_depth_243}));
}
HEFF_LIT(g_heff_2ebuild_2edriver_2estructAdd_str0, 2, "#T");
Clo g_heff_2ebuild_2edriver_2estructAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructAdd_entry, 4, 0};

V g_heff_2ebuild_2edriver_2estructAdd(V v_mkey_240, V v_g_241, V v_es_242, V v_idx_243) {
top: ;
  V v_k_244 = heff_strAppend(heff_dup(v_mkey_240), ((V)&g_heff_2ebuild_2edriver_2estructAdd_str0));
  V v_t_245 = (g_list_2efoldl_24s1608132097x1207501887(NTAG(TAG_Small), v_es_242));
  V v_t_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Large); V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_245); heff_drop(b_1); r_; });
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = NTAG(TAG_LargeU);
  } else {
    heff_drop(v_t_246);
    v_t_247 = NTAG(TAG_SmallU);
  }
  V v_tyStx_248 = heff_tag_n(TAG_SU, 1, (V[]){v_t_247});
  V v_t_249 = (g_list_2efoldl_24s1608132097x1207501887(NTAG(TAG_Small), v_es_242));
  V v_pairs_2410 = (g_heff_2ebuild_2edriver_2estructFieldsGo(v_idx_243, MK_INT(0LL), heff_dup(v_es_242)));
  V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2410)));
  V v_t_2412 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2410));
  V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_pairs_2410));
  V v_t_2414 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2411), v_t_2412, heff_arrayFromList(v_t_2413)});
  V v_bodyStx_2415 = heff_tag_n(TAG_SCode, 1, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_t_249, v_t_2414, heff_dup(g_heff_2eutil_2edict_2eempty_get())})});
  V v_t_2416 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_241), heff_dup(v_k_244), heff_dup(v_tyStx_248), heff_dup(v_bodyStx_2415)));
  HeffT2 v_t_2417 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_241), NTAG(TAG_N), heff_dup(v_tyStx_248), NTAG(TAG_LNil)));
  V v_t_2425;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2419;
      v_t_2425 = v_x_2421;
    } else {
      if ((v_tag_2418 == ((int64_t)1ULL))) {
        V v_x11_2423 = v_field_2419;
        heff_drop(v_x11_2423);
        v_t_2425 = heff_abandon();
      } else {
        V v_x_2424 = v_field_2419;
        v_t_2425 = v_x_2424;
      }
    }
  }
  V v_t_2426 = (g_heff_2eelab_2eglobals_2eaddEntry(v_k_244, heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2415, v_tyStx_248, v_t_2416, v_t_2425}), v_g_241));
  return (g_heff_2ebuild_2edriver_2estructBody(v_mkey_240, v_es_242, v_t_2426));
}
V g_heff_2ebuild_2edriver_2estructAdd_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2estructAdd(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_heff_2ebuild_2edriver_2efixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efixOf(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_f_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_n_244, v_m_241, 0)) {
        return heff_dup(v_f_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_m_241;
        v_x1_240 = t_0;
        v_m_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2efixOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str1, 1, ".");
Clo g_heff_2ebuild_2edriver_2eelabTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabTop_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabTop(V v_s_240, V v_imps_241, V v_direct_242, V v_r_243, V v_t_244) {
top: ;
  V v_own_245 = ({ V a_0 = heff_dup(heff_rfield(v_s_240, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_244, 2)); V r_ = (g_list_2emap_24s1512999845x472671375(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_globals_246 = (g_heff_2ebuild_2edriver_2emoduleStruct(heff_dup(heff_rfield(v_s_240, 0)), v_own_245, heff_take_field(v_t_244, 0)));
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_248 = (g_list_2edrop(v_t_247, heff_rfield(v_imps_241, 0)));
  V v_t_249 = (g_heff_2ebuild_2edriver_2eagainGo(heff_rfield(v_imps_241, 1), heff_dup(heff_rfield(v_imps_241, 1)), v_t_248));
  V v_t_2410 = (g_list_2emap_24f1502491305x440718220(heff_take_field(v_r_243, 1), heff_dup(heff_rfield(v_t_244, 1))));
  V v_diags_2411 = (g_heff_2ebuild_2edriver_2eappendD(v_t_249, v_t_2410));
  V v_own_2412 = ({ V a_0 = heff_dup(heff_rfield(v_s_240, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_244, 2)); V r_ = (g_list_2emap_24s1512999845x472671375(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_2413 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_241, 0))));
  V v_deps_2414 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2416 = (g_list_2edrop(v_t_2415, heff_rfield(v_imps_241, 0)));
  V v_opens_2417 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2416));
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2419 = ({ V a_0 = v_t_2418; V b_1 = heff_get_n(v_imps_241, 0, 3); V r_ = (g_list_2edrop(a_0, b_1)); heff_drop(b_1); r_; });
  V v_aliases_2420 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_2419));
  V v_t_2421 = ({ V rv_0 = v_globals_246; V rr_ = heff_rec_reuse_nf(v_t_244, 510ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_rec_n(13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 2)), heff_get_n(v_s_240, 3, 7), heff_dup(heff_rfield(v_r_243, 0)), v_t_2421, v_diags_2411, v_own_2412, v_deps_2414, v_opens_2417, v_aliases_2420, heff_get_n(v_r_243, 2, 4), NTAG(TAG_False)});
}
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eelabTop(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabDecls_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabDecls_str1, 1, ".");
Clo g_heff_2ebuild_2edriver_2eelabDecls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabDecls_entry, 7, 0};

V g_heff_2ebuild_2edriver_2eelabDecls(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245, V v_decls_246) {
top: ;
  V v_g0_247 = (g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701(heff_dup(v_s_241), ((V)&g_heff_2ebuild_2edriver_2eelabDecls_str0), v_g0_244, heff_rfield(v_r_245, 3)));
  V v_t_248 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g0_247, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2emap_24s1960706388x853997965(v_decls_246));
  V v_t_2410 = ({ V a_0 = heff_dup(heff_rfield(v_s_241, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabDecls_str1); V a_2 = v_t_248; V a_3 = v_t_249; V r_ = (g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  return (g_heff_2ebuild_2edriver_2eelabTop(v_s_241, v_imps_242, v_direct_243, v_r_245, v_t_2410));
}
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabDecls(a0, a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabEnv_str0, 5, ", at ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabEnv_str1, 3, "by ");
V g_heff_2ebuild_2edriver_2eelabEnv_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabEnv_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabEnv(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1634882103x1209760496(heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), v_direct_243));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabEnv_str0), heff_dup(heff_rfield(v_s_241, 2)));
  V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), v_t_246);
  V v_o_249 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2eelabEnv_lam0, 1, 1, (V[]){heff_dup(v_g0_244)}), v_t_245, NTAG(TAG_False), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabEnv_str1), v_t_247), heff_dup(heff_rfield(v_s_241, 2))});
  V v_src_2410 = heff_dup(heff_rfield(v_imps_242, 2));
  V v_t_2411 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_2412 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2410, v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2413 = ({ V a_0 = v_src_2410; V a_1 = v_o_249; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2ereadLexed(a_0, a_1, a_2)); heff_drop(v_src_2410); r_; });
  return (g_heff_2ebuild_2edriver_2eelabRead(v_done_240, v_s_241, v_imps_242, v_direct_243, v_g0_244, v_t_2413));
}
V g_heff_2ebuild_2edriver_2eelabEnv_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabEnv(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edriver_2eelabEnv_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_g0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_g0_244; V a_1 = v_x_248; V r_ = (g_heff_2ebuild_2edriver_2eknownIn(a_0, a_1)); heff_drop(v_x_248); r_; });
}
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062_entry, 4, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_244, 5)), 0, 9);
    V v_t_247 = ({ V b_0 = heff_get_n(v_t_246, 3, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248 = (g_list_2emap_24f489129082x766375942(heff_dup(v_x_244), heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), v_t_247));
    V v_t_249 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_248));
    V v_t_2410 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062(v_lit_240, v_lit_241, v_lit_242, v_xs_245));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s1788052250x532341062(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eprimDeclsGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eprimDeclsGo(V v_c_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x2_241, 0);
    V v_os_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop_rec(v_o_243, 2);
      heff_drop(v_os_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x31_245 = heff_field(v_x3_242, 0);
      V v_sps_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_sp_248 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 2ULL, 2);
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_243, 0)), heff_dup(heff_rfield(v_o_243, 1)))) {
          V v_t_2410 = heff_rec_n(3, shape_key__by__span, (V[]){heff_get_n(v_o_243, 1, 2), heff_dup(v_c_240), v_sp_248});
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
          V v_u_2412 = (g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(v_c_240, v_os_244, v_sps_246, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        } else {
          heff_drop_rec(v_o_243, 2);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_sp_248);
          V t_0 = v_c_240;
          V t_1 = v_os_244;
          V t_2 = v_sps_246;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eprimDeclsGo(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(V v_c_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_os_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop_rec(v_o_244, 2);
      heff_drop(v_os_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x31_246 = heff_field(v_x3_242, 0);
      V v_sps_247 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 2ULL, 2);
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_244, 0)), heff_dup(heff_rfield(v_o_244, 1)))) {
          V v_t_2411 = heff_rec_n(3, shape_key__by__span, (V[]){heff_get_n(v_o_244, 1, 2), heff_dup(v_c_240), v_sp_249});
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_c_240;
          V t_1 = v_os_245;
          V t_2 = v_sps_247;
          V t_3 = v_cell_2412;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_d_243 = t_3;
          goto top;
        } else {
          heff_drop_rec(v_o_244, 2);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_sp_249);
          V t_0 = v_c_240;
          V t_1 = v_os_245;
          V t_2 = v_sps_247;
          V t_3 = v_d_243;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2edriver_2ewithDiags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithDiags_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewithDiags(V v_c_240, V v_ds_241) {
top: ;
  switch (heff_tag_of(v_ds_241)) {
  case TAG_Nil: {
    return v_c_240;
  }
  case TAG_Cons: {
    V v_diags_244 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_c_240, 6), v_ds_241));
    return ({ V rv_6 = v_diags_244; V rr_ = heff_rec_reuse_nf(v_c_240, 8127ULL, 13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached, 67096575u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_ds_241);
  }
}
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithDiags(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ewithTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithTwice_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ewithTwice(V v_done_240, V v_imps_241, V v_needed_242, V v_c_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(v_needed_242));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_243, 5)), 6, 9);
  V v_t_246 = (g_heff_2ebuild_2edriver_2eprimDeclsGo(heff_dup(v_c_243), heff_dup(heff_rfield(v_c_243, 7)), v_t_245));
  V v_t_247 = (g_heff_2ebuild_2edriver_2eappendD(v_t_244, v_t_246));
  V v_t_248 = (g_heff_2ebuild_2edriver_2etwicesGo(heff_dup(g_std_2emap_2eempty_get()), v_t_247));
  V v_t_249 = (g_list_2efilter_24s1450888590x1561911320(heff_dup(v_done_240), heff_dup(v_imps_241), heff_dup(v_c_243), v_t_248));
  V v_t_2410 = (g_list_2emap_24s204237290x1967740547(v_done_240, v_imps_241, heff_dup(v_c_243), v_t_249));
  return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_243, v_t_2410));
}
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ewithTwice(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eelabNeeding_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabNeeding_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabNeeding(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_reached_244) {
top: ;
  V v_needed_247 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam0, 1, 1, (V[]){heff_dup(v_reached_244)}), heff_dup(v_done_240)));
  V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam1, 1, 1, (V[]){heff_dup(v_imps_242)}), heff_dup(v_done_240)));
  V v_t_2412 = ({ V a_0 = heff_dup(v_done_240); V a_1 = v_s_241; V a_2 = heff_dup(v_imps_242); V a_3 = v_thaw_243; V a_4 = v_t_2411; V a_5 = v_needed_247; V r_ = (g_heff_2ebuild_2edriver_2eelabDirect(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2411); r_; });
  return ({ V a_0 = v_done_240; V a_1 = v_imps_242; V a_2 = v_needed_247; V a_3 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2ewithTwice(a_0, a_1, a_2, a_3)); heff_drop(v_needed_247); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2edriver_2eelabNeeding(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_reached_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_245, 0, 13)}));
  return ({ V a_0 = v_t_246; V a_1 = v_reached_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_reached_244); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_imps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_heff_2ebuild_2edriver_2eopenNames(heff_get_n(v_imps_242, 0, 3)));
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_248, 0, 13)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
Clo g_heff_2ebuild_2edriver_2elean_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elean_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elean(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 7, 9);
  V v_infos_242 = (g_list_2emap_24s214260857x938990544(v_t_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 1, 9);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 2, 9);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 4, 9);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 9);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_2410 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249, v_infos_242, NTAG(TAG_Nil)});
  return ({ V rv_5 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_c_240, 8159ULL, 13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached, 67105791u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elean(a[0]);
}
Clo g_heff_2ebuild_2edriver_2etraceless_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etraceless_entry, 1, 0};

V g_heff_2ebuild_2edriver_2etraceless(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 1, 9);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 2, 9);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 4, 9);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 9);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 7, 9);
  V v_t_249 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, NTAG(TAG_Nil)});
  return ({ V rv_5 = v_t_249; V rr_ = heff_rec_reuse_nf(v_c_240, 8159ULL, 13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached, 67105791u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etraceless(a[0]);
}

HeffT2 g_heff_2ebuild_2edriver_2ereadExpRead_24cpr(V v_ge_240, V v_g_241, V v_r_242) {
top: ;
  V v_t_243 = heff_take_field(v_r_242, 1);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_245 = (g_list_2emap_24s1960706388x853997965(heff_get_n(v_r_242, 0, 4)));
    V v_t_246 = ({ V a_0 = v_t_244; V a_1 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_t_247 = heff_take_field(v_t_246, 1);
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      V v_t_248 = heff_get_n(v_t_246, 4, 9);
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        heff_drop(v_ge_240);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 2);
        V v_f_2411 = (g_heff_2ebuild_2edriver_2eevalWatch(v_ge_240, heff_get_n(v_x_249, 1, 2)));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_248)}});
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop(v_ge_240);
      heff_drop_rec(v_t_246, 9);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_247)}});
    }
  }
  case TAG_Cons: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_ge_240);
    heff_drop(v_g_241);
    heff_drop_rec(v_r_242, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str11, 4, "Just");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str24, 6, "Differ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str32, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str33, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str37, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str40, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str41, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str43, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str45, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str46, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str48, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str50, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str51, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str52, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str53, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str54, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str55, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str56, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str58, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str59, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str60, 0, "");
Clo g_heff_2ebuild_2edriver_2efailureOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efailureOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2efailureOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_2414 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str7);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str8);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str9);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str10);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str11))) {
    V v_t_2429;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2419 = heff_field(v_v_240, 1);
      v_t_2429 = heff_dup(v_vs_2419);
      break;
    }
    case TAG_VInt: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2430 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2429; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2450;
    {
      V v_field_2432 = v_t_2430.f[1];
      V v_field_2433 = v_t_2430.f[2];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x_2435 = v_field_2432;
        V v_x12_2436 = v_field_2433;
        heff_drop(v_x12_2436);
        switch (heff_tag_of(v_x_2435)) {
        case TAG_VFun: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str12);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str13);
          break;
        }
        case TAG_VTag: {
          V v_x_2439 = heff_field(v_x_2435, 0);
          heff_take_n(v_x_2435, 1ULL, 2);
          v_t_2450 = v_x_2439;
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str14);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str15);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str16);
          break;
        }
        case TAG_VStr: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str17);
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str18);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str19);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2435, 0ULL, 1);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str20);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2435, 0ULL, 2);
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str21);
          break;
        }
        case TAG_VErased: {
          v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str22);
          break;
        }
        default: heff_nomatch(v_x_2435);
        }
      } else {
        heff_drop(v_field_2432);
        heff_drop(v_field_2433);
        v_t_2450 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str23);
      }
    }
    if (heff_strEq_c(v_t_2450, ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str24))) {
      V v_t_2465;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2455 = heff_field(v_v_240, 1);
        v_t_2465 = heff_dup(v_vs_2455);
        break;
      }
      case TAG_VInt: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2465 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_2466 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2465; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2465); r_; });
      V v_t_24107;
      {
        V v_field_2468 = v_t_2466.f[1];
        V v_field_2469 = v_t_2466.f[2];
        int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
        V v_t_2486;
        if ((v_tag_2467 == ((int64_t)0ULL))) {
          V v_x_2471 = v_field_2468;
          V v_x12_2472 = v_field_2469;
          heff_drop(v_x12_2472);
          switch (heff_tag_of(v_x_2471)) {
          case TAG_VFun: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VTag: {
            V v_vs_2476 = heff_field(v_x_2471, 1);
            heff_take_n(v_x_2471, 2ULL, 2);
            v_t_2486 = v_vs_2476;
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_2471, 0ULL, 1);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_2471, 0ULL, 2);
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VErased: {
            v_t_2486 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_2471);
          }
        } else {
          heff_drop(v_field_2468);
          heff_drop(v_field_2469);
          v_t_2486 = NTAG(TAG_Nil);
        }
        HeffT3 v_t_2487 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2486; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2486); r_; });
        {
          V v_field_2489 = v_t_2487.f[1];
          V v_field_2490 = v_t_2487.f[2];
          int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
          if ((v_tag_2488 == ((int64_t)0ULL))) {
            V v_x_2492 = v_field_2489;
            V v_x12_2493 = v_field_2490;
            heff_drop(v_x12_2493);
            switch (heff_tag_of(v_x_2492)) {
            case TAG_VFun: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str25);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str26);
              break;
            }
            case TAG_VTag: {
              heff_take_n(v_x_2492, 0ULL, 2);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str27);
              break;
            }
            case TAG_VInt: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str28);
              break;
            }
            case TAG_VFloat: {
              heff_take_na(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str29);
              break;
            }
            case TAG_VFloat32: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str30);
              break;
            }
            case TAG_VStr: {
              V v_s_24101 = heff_field(v_x_2492, 0);
              heff_take_n(v_x_2492, 1ULL, 1);
              v_t_24107 = v_s_24101;
              break;
            }
            case TAG_VRune: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str31);
              break;
            }
            case TAG_VArr: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str32);
              break;
            }
            case TAG_VBytes: {
              heff_take_n(v_x_2492, 0ULL, 1);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str33);
              break;
            }
            case TAG_VBits: {
              heff_take_n(v_x_2492, 0ULL, 2);
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str34);
              break;
            }
            case TAG_VErased: {
              v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str35);
              break;
            }
            default: heff_nomatch(v_x_2492);
            }
          } else {
            heff_drop(v_field_2489);
            heff_drop(v_field_2490);
            v_t_24107 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str36);
          }
        }
      }
      V v_t_24121;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24111 = heff_field(v_v_240, 1);
        v_t_24121 = heff_dup(v_vs_24111);
        break;
      }
      case TAG_VInt: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24121 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_24122 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_24121; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24121); r_; });
      V v_t_24163;
      {
        V v_field_24124 = v_t_24122.f[1];
        V v_field_24125 = v_t_24122.f[2];
        int64_t v_tag_24123 = ((int64_t)v_t_24122.f[0]);
        V v_t_24142;
        if ((v_tag_24123 == ((int64_t)0ULL))) {
          V v_x_24127 = v_field_24124;
          V v_x12_24128 = v_field_24125;
          heff_drop(v_x12_24128);
          switch (heff_tag_of(v_x_24127)) {
          case TAG_VFun: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VTag: {
            V v_vs_24132 = heff_field(v_x_24127, 1);
            heff_take_n(v_x_24127, 2ULL, 2);
            v_t_24142 = v_vs_24132;
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_24127, 0ULL, 1);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_24127, 0ULL, 2);
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VErased: {
            v_t_24142 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_24127);
          }
        } else {
          heff_drop(v_field_24124);
          heff_drop(v_field_24125);
          v_t_24142 = NTAG(TAG_Nil);
        }
        HeffT3 v_t_24143 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24142; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24142); r_; });
        {
          V v_field_24145 = v_t_24143.f[1];
          V v_field_24146 = v_t_24143.f[2];
          int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
          if ((v_tag_24144 == ((int64_t)0ULL))) {
            V v_x_24148 = v_field_24145;
            V v_x12_24149 = v_field_24146;
            heff_drop(v_x12_24149);
            switch (heff_tag_of(v_x_24148)) {
            case TAG_VFun: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str37);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str38);
              break;
            }
            case TAG_VTag: {
              heff_take_n(v_x_24148, 0ULL, 2);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str39);
              break;
            }
            case TAG_VInt: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str40);
              break;
            }
            case TAG_VFloat: {
              heff_take_na(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str41);
              break;
            }
            case TAG_VFloat32: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str42);
              break;
            }
            case TAG_VStr: {
              V v_s_24157 = heff_field(v_x_24148, 0);
              heff_take_n(v_x_24148, 1ULL, 1);
              v_t_24163 = v_s_24157;
              break;
            }
            case TAG_VRune: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str43);
              break;
            }
            case TAG_VArr: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str44);
              break;
            }
            case TAG_VBytes: {
              heff_take_n(v_x_24148, 0ULL, 1);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str45);
              break;
            }
            case TAG_VBits: {
              heff_take_n(v_x_24148, 0ULL, 2);
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str46);
              break;
            }
            case TAG_VErased: {
              v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str47);
              break;
            }
            default: heff_nomatch(v_x_24148);
            }
          } else {
            heff_drop(v_field_24145);
            heff_drop(v_field_24146);
            v_t_24163 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str48);
          }
        }
      }
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_24107, v_t_24163})});
    } else {
      V v_t_24177;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24167 = heff_field(v_v_240, 1);
        v_t_24177 = heff_dup(v_vs_24167);
        break;
      }
      case TAG_VInt: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24177 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_24178 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_24177; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24177); r_; });
      V v_t_24219;
      {
        V v_field_24180 = v_t_24178.f[1];
        V v_field_24181 = v_t_24178.f[2];
        int64_t v_tag_24179 = ((int64_t)v_t_24178.f[0]);
        V v_t_24198;
        if ((v_tag_24179 == ((int64_t)0ULL))) {
          V v_x_24183 = v_field_24180;
          V v_x12_24184 = v_field_24181;
          heff_drop(v_x12_24184);
          switch (heff_tag_of(v_x_24183)) {
          case TAG_VFun: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VTag: {
            V v_vs_24188 = heff_field(v_x_24183, 1);
            heff_take_n(v_x_24183, 2ULL, 2);
            v_t_24198 = v_vs_24188;
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_24183, 0ULL, 1);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_24183, 0ULL, 2);
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VErased: {
            v_t_24198 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_24183);
          }
        } else {
          heff_drop(v_field_24180);
          heff_drop(v_field_24181);
          v_t_24198 = NTAG(TAG_Nil);
        }
        HeffT3 v_t_24199 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_24198; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24198); r_; });
        {
          V v_field_24201 = v_t_24199.f[1];
          V v_field_24202 = v_t_24199.f[2];
          int64_t v_tag_24200 = ((int64_t)v_t_24199.f[0]);
          if ((v_tag_24200 == ((int64_t)0ULL))) {
            V v_x_24204 = v_field_24201;
            V v_x12_24205 = v_field_24202;
            heff_drop(v_x12_24205);
            switch (heff_tag_of(v_x_24204)) {
            case TAG_VFun: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str49);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str50);
              break;
            }
            case TAG_VTag: {
              heff_take_n(v_x_24204, 0ULL, 2);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str51);
              break;
            }
            case TAG_VInt: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str52);
              break;
            }
            case TAG_VFloat: {
              heff_take_na(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str53);
              break;
            }
            case TAG_VFloat32: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str54);
              break;
            }
            case TAG_VStr: {
              V v_s_24213 = heff_field(v_x_24204, 0);
              heff_take_n(v_x_24204, 1ULL, 1);
              v_t_24219 = v_s_24213;
              break;
            }
            case TAG_VRune: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str55);
              break;
            }
            case TAG_VArr: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str56);
              break;
            }
            case TAG_VBytes: {
              heff_take_n(v_x_24204, 0ULL, 1);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str57);
              break;
            }
            case TAG_VBits: {
              heff_take_n(v_x_24204, 0ULL, 2);
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str58);
              break;
            }
            case TAG_VErased: {
              v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str59);
              break;
            }
            default: heff_nomatch(v_x_24204);
            }
          } else {
            heff_drop(v_field_24201);
            heff_drop(v_field_24202);
            v_t_24219 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str60);
          }
        }
      }
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_t_24219})});
    }
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2efailureOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efailureOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str12, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str24, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str25, 8, "property");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str32, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str33, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str37, 4, "runs");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str38, 9, "discarded");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str39, 7, "shrinks");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str40, 6, "labels");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str41, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str42, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str43, 4, "seed");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str44, 7, "goldens");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str45, 4, "True");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str46, 4, "True");
Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eoutcomeOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eoutcomeOfV(V v_v_240) {
top: ;
  V v_x1_241 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str0); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_VFun: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str1);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str2);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_241, 0ULL, 2);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str3);
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str4);
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str5);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str6);
    break;
  }
  case TAG_VStr: {
    V v_s_249 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    v_t_2415 = v_s_249;
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str7);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str8);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str9);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_241, 0ULL, 2);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str10);
    break;
  }
  case TAG_VErased: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str11);
    break;
  }
  default: heff_nomatch(v_x1_241);
  }
  V v_x1_2416 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str12); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2430;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str13);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str14);
    break;
  }
  case TAG_VTag: {
    V v_x_2419 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 2);
    v_t_2430 = v_x_2419;
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str15);
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str16);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str17);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str18);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str19);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str20);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str21);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str22);
    break;
  }
  case TAG_VErased: {
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str23);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2431 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str24); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2432 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2ebuild_2edriver_2eskippedOfV(a_0)); heff_drop(v_t_2431); r_; });
  V v_x1_2433 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str25); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2447;
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str26);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str27);
    break;
  }
  case TAG_VTag: {
    V v_x_2436 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 2);
    v_t_2447 = v_x_2436;
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str28);
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str29);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str30);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str31);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str32);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str33);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str34);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2433, 0ULL, 2);
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str35);
    break;
  }
  case TAG_VErased: {
    v_t_2447 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str36);
    break;
  }
  default: heff_nomatch(v_x1_2433);
  }
  V v_x1_2448 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str37); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2462;
  switch (heff_tag_of(v_x1_2448)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2448, 0ULL, 2);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2453 = heff_field(v_x1_2448, 0);
    heff_take_n(v_x1_2448, 1ULL, 1);
    v_t_2462 = v_i_2453;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2448, 0ULL, 1);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2448, 0ULL, 2);
    v_t_2462 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2462 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2448);
  }
  V v_x1_2463 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str38); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2477;
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2463, 0ULL, 2);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2468 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_t_2477 = v_i_2468;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2463, 0ULL, 2);
    v_t_2477 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2477 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2463);
  }
  V v_x1_2478 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str39); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2492;
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2478, 0ULL, 2);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2483 = heff_field(v_x1_2478, 0);
    heff_take_n(v_x1_2478, 1ULL, 1);
    v_t_2492 = v_i_2483;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2478, 0ULL, 2);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2492 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2478);
  }
  V v_t_2493 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str40); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2494 = ({ V a_0 = v_t_2493; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_t_2493); r_; });
  V v_t_2495 = (g_list_2emap_24s570961906x1112476114(v_t_2494));
  V v_t_2496 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str41); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2497 = ({ V a_0 = v_t_2496; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_t_2496); r_; });
  V v_t_2498 = (g_list_2emap_24s218655275x981659442(v_t_2497));
  V v_t_2499 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str42); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24100 = ({ V a_0 = v_t_2499; V r_ = (g_heff_2ebuild_2edriver_2efailureOfV(a_0)); heff_drop(v_t_2499); r_; });
  V v_x1_24101 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str43); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24115;
  switch (heff_tag_of(v_x1_24101)) {
  case TAG_VFun: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_24101, 0ULL, 2);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_24106 = heff_field(v_x1_24101, 0);
    heff_take_n(v_x1_24101, 1ULL, 1);
    v_t_24115 = v_i_24106;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_24101, 0ULL, 1);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_24101, 0ULL, 2);
    v_t_24115 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_24115 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_24101);
  }
  V v_t_24116 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str44); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24117 = ({ V a_0 = v_t_24116; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_t_24116); r_; });
  V v_t_24118 = (g_list_2emap_24s1517387949x485543551(v_t_24117));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_t_2415, heff_strEq(v_t_2430, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str45)), v_t_2432, heff_strEq(v_t_2447, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str46)), v_t_2462, v_t_2477, v_t_2492, v_t_2495, v_t_2498, v_t_24100, v_t_24115, v_t_24118});
}
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eoutcomeOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eintegrationOfV_str11, 0, "");
Clo g_heff_2ebuild_2edriver_2eintegrationOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eintegrationOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eintegrationOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_244 = heff_field(v_v_240, 1);
    v_t_2414 = heff_dup(v_vs_244);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  HeffT3 v_t_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2414; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2435;
  {
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2420 = v_field_2417;
      V v_x12_2421 = v_field_2418;
      heff_drop(v_x12_2421);
      switch (heff_tag_of(v_x_2420)) {
      case TAG_VFun: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str0);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str1);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x_2420, 0ULL, 2);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str2);
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str3);
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str4);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str5);
        break;
      }
      case TAG_VStr: {
        V v_s_2429 = heff_field(v_x_2420, 0);
        heff_take_n(v_x_2420, 1ULL, 1);
        v_t_2435 = v_s_2429;
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str6);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str7);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_x_2420, 0ULL, 1);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str8);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_x_2420, 0ULL, 2);
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str9);
        break;
      }
      case TAG_VErased: {
        v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str10);
        break;
      }
      default: heff_nomatch(v_x_2420);
      }
    } else {
      heff_drop(v_field_2417);
      heff_drop(v_field_2418);
      v_t_2435 = ((V)&g_heff_2ebuild_2edriver_2eintegrationOfV_str11);
    }
  }
  V v_t_2449;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_2439 = heff_field(v_v_240, 1);
    v_t_2449 = heff_dup(v_vs_2439);
    break;
  }
  case TAG_VInt: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBytes: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBits: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2449 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  HeffT3 v_t_2450 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2449; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2449); r_; });
  V v_t_2470;
  {
    V v_field_2452 = v_t_2450.f[1];
    V v_field_2453 = v_t_2450.f[2];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      V v_x_2455 = v_field_2452;
      V v_x12_2456 = v_field_2453;
      heff_drop(v_x12_2456);
      switch (heff_tag_of(v_x_2455)) {
      case TAG_VFun: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x_2455, 0ULL, 2);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VInt: {
        V v_i_2461 = heff_field(v_x_2455, 0);
        heff_take_n(v_x_2455, 1ULL, 1);
        v_t_2470 = v_i_2461;
        break;
      }
      case TAG_VFloat: {
        heff_take_na(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VBytes: {
        heff_take_n(v_x_2455, 0ULL, 1);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VBits: {
        heff_take_n(v_x_2455, 0ULL, 2);
        v_t_2470 = MK_INT(0LL);
        break;
      }
      case TAG_VErased: {
        v_t_2470 = MK_INT(0LL);
        break;
      }
      default: heff_nomatch(v_x_2455);
      }
    } else {
      heff_drop(v_field_2452);
      heff_drop(v_field_2453);
      v_t_2470 = MK_INT(0LL);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_t_2470});
}
V g_heff_2ebuild_2edriver_2eintegrationOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eintegrationOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2erunTests_24cpr_str0, 7, "> test ");
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2erunTests_24cpr(V v_pattern_240, V v_seed_241, V v_c_242) {
top: ;
  V v_t_244 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_242)}), heff_dup(heff_rfield(v_c_242, 7))));
  V v_x1_245 = (g_heff_2ebuild_2edriver_2erootsAmong(heff_dup(v_c_242), v_t_244));
  V v_t_248;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_248 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_pattern_240);
    heff_drop(v_seed_241);
    heff_drop_rec(v_c_242, 13);
    heff_drop(v_t_248);
    return ((HeffT2){{NTAG(TAG_Nil), NTAG(TAG_Nil)}});
  } else {
    heff_drop(v_t_248);
    V v_t_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_24cpr_lam1, 1, 1, (V[]){heff_dup(v_c_242)}), heff_dup(heff_rfield(v_c_242, 7))));
    V v_ts_2411 = (g_heff_2ebuild_2edriver_2erootsAmong(heff_dup(v_c_242), v_t_2410));
    V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_24cpr_lam2, 1, 1, (V[]){heff_dup(v_c_242)}), heff_dup(heff_rfield(v_c_242, 7))));
    V v_t_2414 = (g_heff_2ebuild_2edriver_2erootsAmong(heff_dup(v_c_242), v_t_2413));
    V v_t_2415 = heff_get_n(heff_get_n(v_c_242, 5, 13), 0, 9);
    V v_gs_2416 = (g_heff_2ebuild_2edriver_2eaddTests(v_pattern_240, heff_dup(v_seed_241), MK_INT(0LL), v_t_2414, v_t_2415));
    V v_t_2424 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_24cpr_lam3, 2, 1, (V[]){heff_dup(v_gs_2416)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_gs_2416, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_rs_2425 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(7LL); V b_2 = ((V)&g_heff_2ebuild_2edriver_2erunTests_24cpr_str0); V a_3 = heff_dup(g_std_2emap_2eempty_get()); V a_4 = v_t_2424; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1411022925x633576515(b_0, b_1, b_2, a_3, a_4, a_5)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_f_2426 = (g_heff_2ebuild_2edriver_2epickOutcomes(v_seed_241, heff_dup(v_rs_2425), MK_INT(0LL), v_ts_2411));
    V v_f_2427 = ({ V a_0 = v_rs_2425; V a_1 = MK_INT(0LL); V a_2 = v_ts_2411; V r_ = (g_heff_2ebuild_2edriver_2epickIntegrations(a_0, a_1, a_2)); heff_drop(v_ts_2411); r_; });
    return ((HeffT2){{v_f_2426, v_f_2427}});
  }
}
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_242, v_o_243));
}
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam1(V self, V *args) {
  V v_o_249 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_242, v_o_249));
}
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam2(V self, V *args) {
  V v_o_2412 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_242, v_o_2412));
}
V g_heff_2ebuild_2edriver_2erunTests_24cpr_lam3(V self, V *args) {
  V v_acc_2417 = args[0];
  V v_k_2418 = args[1];
  V v_gs_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_gs_2416, 1, 7); V a_1 = v_k_2418; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_e_2423 = v_field_2421;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2418, v_e_2423}), v_acc_2417});
    } else {
      heff_drop(v_k_2418);
      heff_drop(v_field_2421);
      return v_acc_2417;
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eearlierGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eearlierGo_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eearlierGo(V v_x1_240, V v_i_241, V v_x_242, V v_j_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_j_243);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_g_244, 0)), heff_dup(v_x_242))) {
      return heff_intLt(v_j_243, v_i_241);
    } else {
      V t_0 = v_rest_245;
      V t_1 = v_i_241;
      V t_2 = v_x_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_x_242 = t_2;
      v_j_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eearlierGo(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str3, 1, "\012");
V g_heff_2ebuild_2edriver_2einterface_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2einterface_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2einterface_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2einterface_entry, 1, 0};

V g_heff_2ebuild_2edriver_2einterface(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2edriver_2eimportLines(heff_dup(v_c_240)));
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 11)), 0, 2);
  V v_t_243 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 11)); V a_1 = MK_INT(0LL); V a_2 = v_t_242; V r_ = (g_heff_2ebuild_2edriver_2efixityLines(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_t_244 = heff_rec_n(3, shape_out__multi__first, (V[]){((V)&g_heff_2ebuild_2edriver_2einterface_str0), NTAG(TAG_False), NTAG(TAG_True)});
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2einterface_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get_n(v_c_240, 7, 13)));
  V v_t_2417 = ({ V a_0 = v_t_244; V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24f139246788x401086883(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2417, 0, 3), NTAG(TAG_Nil)});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2418})});
  V v_x2_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str1); V a_1 = v_t_2419; V r_ = (g_list_2efilter_24s727803713x1346936525(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2edriver_2einterface_str2);
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str3); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2einterface(a[0]);
}
V g_heff_2ebuild_2edriver_2einterface_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2410 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_249)));
  HeffT2 v_t_2411 = ({ V a_0 = v_m_248; V a_1 = v_k_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_m_248); heff_drop(v_k_249); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_d_2410);
      V v_x_2415 = v_field_2413;
      return v_x_2415;
    } else {
      heff_drop(v_field_2413);
      return v_d_2410;
    }
  }
}
V g_heff_2ebuild_2edriver_2einterface_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_247 = ({ V b_0 = heff_get_n(v_t_246, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_248 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s810240426x431529267(a_0, a_1)); heff_drop(v_t_247); r_; });
  return (g_heff_2ebuild_2edriver_2esigEntry(v_c_240, heff_clo_n(g_heff_2ebuild_2edriver_2einterface_lam1, 1, 1, (V[]){v_m_248}), v_o_245));
}

HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V v_c_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 1), v_k_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_242, 7);
      V v_e_247 = v_field_245;
      V v_t_248 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
      V v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_247, 3, 4)));
      return ({ V a_0 = v_t_248; V a_1 = v_t_249; HeffT2 r_ = (g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 2), v_k_241));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k2_2414 = v_field_2412;
          HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_g_242, 1, 7); V a_1 = v_k2_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2414); r_; });
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              V v_e_2419 = v_field_2417;
              V v_t_2420 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
              V v_t_2421 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2419, 3, 4)));
              return ({ V a_0 = v_t_2420; V a_1 = v_t_2421; HeffT2 r_ = (g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(a_0, a_1)); heff_drop(v_t_2421); r_; });
            } else {
              heff_drop_rec(v_c_240, 13);
              heff_drop(v_field_2417);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop_rec(v_c_240, 13);
          heff_drop_rec(v_g_242, 7);
          heff_drop(v_field_2412);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str2, 16, " has the effect ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str3, 142, ", which is not provided here (a module M provides its effect in M.provider.js, or M.provider.c for C, beside M.hf; `$host` says where it runs)");
V g_heff_2ebuild_2edriver_2efits_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2efits_24cpr(V v_handled_240, V v_r_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2eeffect_2eleaves(heff_rfield(v_r_241, 2)));
  V v_t_246 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2efits_24cpr_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), v_t_242));
  V v_ms_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
  switch (heff_tag_of(v_ms_247)) {
  case TAG_Nil: {
    V v_f_248 = heff_rec_n(2, shape_key__effect, (V[]){heff_take_field(v_r_241, 1), heff_get_n(v_r_241, 2, 3)});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_248}});
  }
  case TAG_Cons: {
    V v_t_2413;
    switch (heff_tag_of(v_ms_247)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_ms_247, 0);
      V v_xs_2412 = heff_field(v_ms_247, 1);
      heff_take_n(v_ms_247, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_ms_247);
    }
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str3)));
    V v_f_2415 = heff_strAppend(heff_get_n(v_r_241, 0, 3), v_t_2414);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
  }
  default: return ((HeffT2){{heff_nomatch(v_ms_247)}});
  }
}
V g_heff_2ebuild_2edriver_2efits_24cpr_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_l_243}));
  V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_handled_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efindFirst_24cpr_str0, 32, "no computation, `Co h a`, to run");
V g_heff_2ebuild_2edriver_2efindFirst_24cpr_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2efindFirst_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2efindFirst_24cpr(V v_handled_240, V v_cands_241) {
top: ;
  HeffT2 v_t_2411 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2edriver_2efindFirst_24cpr_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), heff_dup(v_cands_241)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_cands_241);
      V v_r_2415 = v_field_2413;
      V v_f_2416 = heff_rec_n(2, shape_key__effect, (V[]){heff_take_field(v_r_2415, 1), heff_get_n(v_r_2415, 2, 3)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2416}});
    } else {
      heff_drop(v_field_2413);
      switch (heff_tag_of(v_cands_241)) {
      case TAG_Nil: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2edriver_2efindFirst_24cpr_str0)}});
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_cands_241, 0);
        heff_take_n(v_cands_241, 1ULL, 2);
        HEFF_LAST return g_heff_2ebuild_2edriver_2efits_24cpr(v_handled_240, v_x_2417);
      }
      default: return ((HeffT2){{heff_nomatch(v_cands_241)}});
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2efindFirst_24cpr_lam1(V self, V *args) {
  V v_l_244 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_l_244}));
  V v_x1_246 = ({ V a_0 = v_t_245; V a_1 = v_handled_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2efindFirst_24cpr_lam0(V self, V *args) {
  V v_r_242 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V b_0 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2eelab_2eeffect_2eleaves(b_0)); heff_drop(b_0); r_; });
  V v_t_247 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2efindFirst_24cpr_lam1, 1, 1, (V[]){v_handled_240}), v_t_243));
  V v_x1_248 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_247));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2ebuild_2edriver_2erefusedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2erefusedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2erefusedIn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2erefusedIn(V v_rs_240, V v_s_241) {
top: ;
  V v_t_242 = heff_take_field(v_s_241, 6);
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_rs_240);
    heff_drop_rec(v_s_241, 7);
    heff_drop(v_t_242);
    return NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_242);
    V v_t_243 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_s_241, 5), heff_take_field(v_s_241, 3)));
    HeffT3 v_t_244 = ({ V b_0 = heff_get_n(v_s_241, 4, 7); V a_1 = v_t_243; HeffT3 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248;
    {
      V v_field_245 = v_t_244.f[0];
      heff_drop(v_t_244.f[1]);
      heff_drop(v_t_244.f[2]);
      v_t_248 = v_field_245;
    }
    V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2erefusedIn_lam0, 1, 1, (V[]){v_rs_240}), v_t_248));
    return (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2416));
  }
}
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2erefusedIn(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2erefusedIn_lam0(V self, V *args) {
  V v_i_249 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = (g_list_2efind_24s1702742059x483228236_24cpr(heff_dup(v_i_249), v_rs_240));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_r_2414 = v_field_2412;
      V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_take_field(v_r_2414, 1), NTAG(TAG_SError), heff_take_field(v_r_2414, 2), heff_get_n(v_i_249, 2, 3), heff_get_n(v_r_2414, 3, 4)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
    } else {
      heff_drop_rec(v_i_249, 3);
      heff_drop(v_field_2412);
      return NTAG(TAG_Nothing);
    }
  }
}