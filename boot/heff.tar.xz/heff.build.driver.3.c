// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_ArmCovered 35323
#define TAG_ArmRuledOut 21752
#define TAG_ArmTaken 39536
#define TAG_EquationCovered 28162
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_LNil 57394
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_N 306
#define TAG_Right 62770
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_SWarning 44190
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arms 9498206
#define LBL_broken 566525696
#define LBL_by 9918
#define LBL_byName 571997869
#define LBL_cached 579094605
#define LBL_claim 296100950
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_defs 9574869
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_discarded 1490202606
#define LBL_effect 641056956
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_err 310239
#define LBL_error 298143266
#define LBL_exposes 1070285678
#define LBL_failure 1292767177
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_groups 709681407
#define LBL_hidden 729654485
#define LBL_i 323
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_known 303562589
#define LBL_labels 836724522
#define LBL_lenient 294367673
#define LBL_level 304224158
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_listed 844633320
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_multi 305615187
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opens 307306371
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_places 961367927
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unreached 121683306
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken__arms[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken, LBL_arms};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_key__by__span[] = {LBL_key, LBL_by, LBL_span};
static uint32_t shape_key__effect[] = {LBL_key, LBL_effect};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_decls, LBL_top, LBL_diags, LBL_own, LBL_deps, LBL_opens, LBL_aliases, LBL_fixities, LBL_cached, LBL_exposes};
static uint32_t shape_name__key__ty__level[] = {LBL_name, LBL_key, LBL_ty, LBL_level};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_out__multi__first[] = {LBL_out, LBL_multi, LBL_first};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2eagainGo(V, V, V);
V g_heff_2ebuild_2edriver_2eagainGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eagainGo_clo;
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasQOne(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo;
V g_heff_2ebuild_2edriver_2ealiasQualified(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eappendLv_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2eappendLv_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_24dps_clo;
V g_heff_2ebuild_2edriver_2eappendLv_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendLv_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_24tok2_clo;
V g_heff_2ebuild_2edriver_2ebrokenIn(V);
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate0(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF_24map1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_24map1_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map0_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_24map1_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_clo;
V g_heff_2ebuild_2edriver_2eearlierGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eearlierGo_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eelabDecls(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabDecls_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2eelabTop(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabTop_clo;
V g_heff_2ebuild_2edriver_2eexposedDiagsGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiagsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiagsGo_clo;
V g_heff_2ebuild_2edriver_2eexposedIn(V, V);
V g_heff_2ebuild_2edriver_2eexposedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedIn_clo;
V g_heff_2ebuild_2edriver_2efailureOfV(V);
V g_heff_2ebuild_2edriver_2efailureOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efailureOfV_clo;
V g_heff_2ebuild_2edriver_2efieldV(V, V);
V g_heff_2ebuild_2edriver_2efieldV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efieldV_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efits(V, V);
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efits_clo;
HeffT2 g_heff_2ebuild_2edriver_2efits_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixOf(V, V);
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixOf_clo;
V g_heff_2ebuild_2edriver_2efixityLines(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2eisTestEl(V);
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestEl_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2eopenNames_24dps(V, V);
V g_heff_2ebuild_2edriver_2eopenNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_24dps_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
HeffT2 g_heff_2ebuild_2edriver_2eownKeyOf_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eownUses(V, V);
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownUses_clo;
V g_heff_2ebuild_2edriver_2eprimDeclsGo(V, V, V);
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo;
V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(V, V, V, V);
V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_clo;
V g_heff_2ebuild_2edriver_2ereachOwn(V, V, V);
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereachOwn_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
HeffT2 g_heff_2ebuild_2edriver_2espanOfName_24cpr(V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructFieldsGo_clo;
V g_heff_2ebuild_2edriver_2estructIdxGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo;
V g_heff_2ebuild_2edriver_2etestsOf(V);
V g_heff_2ebuild_2edriver_2etestsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestsOf_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked(V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2edriver_2etwicesGo(V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_clo;
V g_heff_2ebuild_2edriver_2ewatchExpect(V);
V g_heff_2ebuild_2edriver_2ewatchExpect_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchExpect_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2edriver_2ewithImportedInstances(V, V, V);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo;
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391_clo;
V g_heff_2ebuild_2edriver_2ewithStruct(V, V, V);
V g_heff_2ebuild_2edriver_2ewithStruct_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithStruct_clo;
V g_heff_2ebuild_2edriver_2ewithTwice(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithTwice_clo;
HeffT2 g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(V, V);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_heff_2esyntax_2esurface_2elineColFrom(V, V, V, V);
V g_heff_2esyntax_2esurface_2elineColFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elineColFrom_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s108509638x1972721376(V, V);
V g_list_2eany_24s108509638x1972721376_entry(V self, V *a);
extern Clo g_list_2eany_24s108509638x1972721376_clo;
V g_list_2eany_24s1119291297x466217959(V, V);
V g_list_2eany_24s1119291297x466217959_entry(V self, V *a);
extern Clo g_list_2eany_24s1119291297x466217959_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s582717128x15493447_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f139246788x401086883(V, V);
V g_list_2efoldl_24f139246788x401086883_entry(V self, V *a);
extern Clo g_list_2efoldl_24f139246788x401086883_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1468236620x1316701813(V, V);
V g_list_2efoldl_24s1468236620x1316701813_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1468236620x1316701813_clo;
V g_list_2efoldl_24s1608132097x1207501887(V, V);
V g_list_2efoldl_24s1608132097x1207501887_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1608132097x1207501887_clo;
V g_list_2efoldl_24s1722922134x788519507(V, V);
V g_list_2efoldl_24s1722922134x788519507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722922134x788519507_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s634644062x504497039(V, V);
V g_list_2efoldl_24s634644062x504497039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634644062x504497039_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s14815453x1234467625(V, V, V, V);
V g_list_2ekeepIf_24s14815453x1234467625_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s14815453x1234467625_clo;
V g_list_2ekeepIf_24s1819141159x1906443669(V);
V g_list_2ekeepIf_24s1819141159x1906443669_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1819141159x1906443669_clo;
V g_list_2ekeepIf_24s1823913665x1128491553(V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2ekeepIf_24s958254147x1083401940(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s958254147x1083401940_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s958254147x1083401940_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s1517387949x485543551(V);
V g_list_2emap_24s1517387949x485543551_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1611344417x463861413(V, V, V);
V g_list_2emap_24s1611344417x463861413_entry(V self, V *a);
extern Clo g_list_2emap_24s1611344417x463861413_clo;
V g_list_2emap_24s1694755346x1599566812(V, V);
V g_list_2emap_24s1694755346x1599566812_entry(V self, V *a);
extern Clo g_list_2emap_24s1694755346x1599566812_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s204237290x1967740547(V, V, V, V);
V g_list_2emap_24s204237290x1967740547_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s262223576x596329185(V, V, V, V, V);
V g_list_2emap_24s262223576x596329185_entry(V self, V *a);
extern Clo g_list_2emap_24s262223576x596329185_clo;
V g_list_2emap_24s265594371x763318798(V);
V g_list_2emap_24s265594371x763318798_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_list_2emap_24s704486313x1071100879(V, V, V, V);
V g_list_2emap_24s704486313x1071100879_entry(V self, V *a);
extern Clo g_list_2emap_24s704486313x1071100879_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f1693511458x1129846322(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f1693511458x1129846322_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f1693511458x1129846322_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;

HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_242, 0)), heff_dup(v_m_241))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_c_242)}});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedIn_str0, 1, "#");
V g_heff_2ebuild_2edriver_2eexposedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eexposedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedIn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eexposedIn(V v_x1_240, V v_own_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2edriver_2eexposedIn_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = v_own_241; V r_ = (g_list_2ekeepIf_24s958254147x1083401940(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
  }
  case TAG_Just: {
    V v_es_242 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2eexposedIn_lam0, 1, 1, (V[]){heff_dup(v_es_242)}), v_own_241);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eexposedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eexposedIn(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eexposedIn_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_es_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_o_243, 0, 2); V a_1 = v_es_242; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s545011251x1914964224(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_242); r_; });
}
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_entry, 1, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ebuild_2edriver_2eexposedIn(heff_rfield(v_x_241, 13), heff_dup(heff_rfield(v_x_241, 7))));
    V v_t_244 = (g_list_2emap_24s1694755346x1599566812(heff_dup(v_x_241), v_t_243));
    V v_t_245 = (g_heff_2ebuild_2edriver_2ebrokenIn(heff_dup(v_x_241)));
    V v_t_246 = (g_heff_2ebuild_2edriver_2eappendD(v_t_244, v_t_245));
    V v_t_247 = (g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623(v_xs_242));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s604825074x1812671623(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edriver_2espanOfName_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_sp_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_x_241, v_y_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_sp_245)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str2, 1, ".");
V g_heff_2ebuild_2edriver_2ealiasQOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasQOne_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ealiasQOne(V v_done_240, V v_g_241, V v_q_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(v_done_240, heff_rfield(v_q_242, 0)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_c_246 = v_field_245;
      V v_g_247 = v_g_241;
      V v_q_248 = heff_dup(v_q_242);
      V v_alias_249 = heff_take_field(v_q_248, 1);
      V v_module_2410 = heff_get_n(v_q_248, 0, 2);
      HeffT3 v_t_2411 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(heff_dup(v_g_247), heff_dup(v_alias_249)));
      V v_t_2419;
      {
        V v_field_2413 = v_t_2411.f[1];
        V v_field_2414 = v_t_2411.f[2];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_alias_249);
          heff_drop(v_module_2410);
          heff_drop(v_field_2414);
          V v_x_2415 = v_field_2413;
          heff_drop(v_x_2415);
          v_t_2419 = v_g_247;
        } else {
          if ((v_tag_2412 == ((int64_t)1ULL))) {
            heff_drop(v_alias_249);
            heff_drop(v_module_2410);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            v_t_2419 = v_g_247;
          } else {
            if ((v_tag_2412 == ((int64_t)2ULL))) {
              heff_drop(v_alias_249);
              heff_drop(v_module_2410);
              V v_x_2416 = v_field_2413;
              heff_drop(v_x_2416);
              V v_x_2417 = v_field_2414;
              heff_drop(v_x_2417);
              v_t_2419 = v_g_247;
            } else {
              heff_drop(v_field_2413);
              heff_drop(v_field_2414);
              V v_t_2418 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_247, 2), v_alias_249, heff_strAppend(v_module_2410, ((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str0))));
              v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_g_247, 251ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            }
          }
        }
      }
      V v_t_2420 = (g_heff_2ebuild_2edriver_2eexposedIn(heff_rfield(v_c_246, 13), heff_dup(heff_rfield(v_c_246, 7))));
      V v_t_2421 = (g_list_2emap_24s1694755346x1599566812(heff_dup(v_c_246), v_t_2420));
      V v_t_2422 = (g_heff_2ebuild_2edriver_2ebrokenIn(v_c_246));
      V v_t_2423 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2421, v_t_2422));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ealiasQOne_lam0, 2, 1, (V[]){v_q_242}); V a_1 = v_t_2419; V a_2 = v_t_2423; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
    } else {
      heff_drop(v_field_245);
      V v_t_2430 = heff_strAppend(heff_get_n(v_q_242, 1, 2), ((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str2));
      V v_t_2431 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_241, 3), v_t_2430, NTAG(TAG_MkUnit)));
      return ({ V rv_3 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_g_241, 247ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    }
  }
}
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ealiasQOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2ealiasQOne_lam0(V self, V *args) {
  V v_g2_2424 = args[0];
  V v_o_2425 = args[1];
  V v_q_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_name_2426 = heff_take_field(v_o_2425, 0);
  V v_key_2427 = heff_get_n(v_o_2425, 1, 3);
  V v_t_2428 = heff_strAppend(heff_get_n(v_q_242, 1, 2), ((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str1));
  V v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g2_2424, 2), heff_strAppend(v_t_2428, v_name_2426), v_key_2427));
  return ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_g2_2424, 251ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65487u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2eopenNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eopenNames_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eopenNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_alias_243 = heff_take_field(v_i_241, 1);
    V v_name_244 = heff_get_n(v_i_241, 0, 3);
    switch (heff_tag_of(v_alias_243)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_244, heff_hole()});
      V v_u_246 = (g_heff_2ebuild_2edriver_2eopenNames_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    case TAG_Just: {
      heff_take_n(v_alias_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_alias_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eopenNames(a[0]);
}
Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry, 6, 0};

V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(V v_r_240, V v_i_241, V v_depth_242, V v_j_243, V v_x5_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    heff_drop(v_j_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x51_246 = heff_field(v_x5_244, 0);
    V v_rest_247 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x51_246, 0);
      V v_t_249 = heff_field(v_x51_246, 1);
      V v_ru_24x51_246_24MkPair = heff_take_reuse_n(v_x51_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), heff_dup(v_j_243)), v_t_249}));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x51_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_248, v_t_2410}), heff_hole()});
      V v_u_2412 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_r_240;
      V t_1 = v_i_241;
      V t_2 = v_depth_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      V t_4 = v_rest_247;
      V t_5 = v_cell_2411;
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      v_j_243 = t_3;
      v_x5_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x51_246);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseFieldsGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam0(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTypeF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_lam0, 1, 0};
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam1(V self, V *args); static Clo g_heff_2ebuild_2edriver_2ecloseTypeF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_lam1, 1, 0};
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_t_244)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SDecode = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e_246}));
    return heff_tag_at_n(v_ru_24t_244_24SDecode, TAG_SDecode, 1, (V[]){v_t_247});
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_t_244, 0);
    V v_dom_249 = heff_field(v_t_244, 1);
    V v_cod_2410 = heff_field(v_t_244, 2);
    V v_implicit_2411 = heff_field(v_t_244, 3);
    V v_dflt_2412 = heff_field(v_t_244, 4);
    V v_ru_24t_244_24SFunction = heff_take_reuse_n(v_t_244, 31ULL, 5);
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_dom_249}));
    V v_t_2419;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_cod_2410, 0);
      V v_t_2415 = heff_field(v_cod_2410, 1);
      V v_ru_24cod_2410_24MkAbs = heff_take_reuse_n(v_cod_2410, 3ULL, 2);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2415}));
      v_t_2419 = heff_tag_at_n(v_ru_24cod_2410_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2414, v_t_2416});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2417 = heff_field(v_cod_2410, 0);
      V v_ru_24cod_2410_24AbsConst = heff_take_reuse_n(v_cod_2410, 1ULL, 1);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2417}));
      v_t_2419 = heff_tag_at_n(v_ru_24cod_2410_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2418});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    return heff_tag_at_n(v_ru_24t_244_24SFunction, TAG_SFunction, 5, (V[]){v_level_248, v_t_2413, v_t_2419, v_implicit_2411, v_dflt_2412});
  }
  case TAG_SRecord: {
    V v_level_2420 = heff_field(v_t_244, 0);
    V v_fs_2421 = heff_field(v_t_244, 1);
    V v_ds_2422 = heff_field(v_t_244, 2);
    V v_ru_24t_244_24SRecord = heff_take_reuse_n(v_t_244, 7ULL, 3);
    V v_keys_2423 = heff_take_field(v_fs_2421, 0);
    V v_values_2424 = heff_get_n(v_fs_2421, 2, 3);
    V v_t_2425 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2423), heff_arrayToList(v_values_2424)));
    V v_pairs_2426 = (g_heff_2ebuild_2edriver_2ecloseFieldsGo(v_r_240, v_i_242, v_depth_243, MK_INT(0LL), v_t_2425));
    V v_t_2427 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2426)));
    V v_t_2428 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2426));
    V v_t_2429 = (g_list_2emap_24s1173914895x100384474(v_pairs_2426));
    V v_t_2430 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2427), v_t_2428, heff_arrayFromList(v_t_2429)});
    return heff_tag_at_n(v_ru_24t_244_24SRecord, TAG_SRecord, 3, (V[]){v_level_2420, v_t_2430, v_ds_2422});
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SSum = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_xs_2432 = heff_take_field(v_vs_2431, 2);
    V v_m_2433 = heff_arrayLength_lent(v_xs_2432, 0);
    V v_t_2443;
    if ((heff_peek_word(v_m_2433) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      heff_drop(v_xs_2432);
      v_t_2443 = heff_arrayGenerate(v_m_2433, ((V)&g_heff_2ebuild_2edriver_2ecloseTypeF_lam0_clo));
    } else {
      V v_xs_2435 = heff_arrayIndex_lent(v_xs_2432, MK_INT(0LL), 2);
      V v_m_2436 = heff_arrayLength_lent(v_xs_2435, 0);
      V v_y_2441;
      if ((heff_peek_word(v_m_2436) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_2435);
        v_y_2441 = heff_arrayGenerate(v_m_2436, ((V)&g_heff_2ebuild_2edriver_2ecloseTypeF_lam1_clo));
      } else {
        V v_t2_2438 = heff_arrayIndex_lent(v_xs_2435, MK_INT(0LL), 2);
        V v_y_2439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t2_2438}));
        V v_t_2440 = heff_arrayKeepsAs_lent(v_xs_2435, v_y_2439, 0);
        if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
          heff_drop(v_m_2436);
          heff_drop(v_t_2440);
          v_y_2441 = (g_heff_2ebuild_2edriver_2ecloseTypeF_24map0(heff_dup(v_r_240), heff_dup(v_i_242), heff_dup(v_depth_243), MK_INT(1LL), heff_arraySet(v_xs_2435, MK_INT(0LL), v_y_2439)));
        } else {
          heff_drop(v_t_2440);
          v_y_2441 = ({ V a_0 = v_xs_2435; V a_1 = heff_dup(v_r_240); V a_2 = heff_dup(v_i_242); V a_3 = heff_dup(v_depth_243); V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_2436, v_y_2439); V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2435); r_; });
        }
      }
      V v_t_2442 = heff_arrayKeepsAs_lent(v_xs_2432, v_y_2441, 0);
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_m_2433);
        heff_drop(v_t_2442);
        v_t_2443 = (g_heff_2ebuild_2edriver_2ecloseTypeF_24map1(v_r_240, v_i_242, v_depth_243, MK_INT(1LL), heff_arraySet(v_xs_2432, MK_INT(0LL), v_y_2441)));
      } else {
        heff_drop(v_t_2442);
        v_t_2443 = ({ V a_0 = v_xs_2432; V a_1 = v_r_240; V a_2 = v_i_242; V a_3 = v_depth_243; V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_2433, v_y_2441); V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF_24generate1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2432); r_; });
      }
    }
    V v_t_2444 = ({ V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_vs_2431, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_244_24SSum, TAG_SSum, 1, (V[]){v_t_2444});
  }
  case TAG_SIsTy: {
    V v_t2_2445 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SIsTy = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t2_2445}));
    return heff_tag_at_n(v_ru_24t_244_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2446});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimArray: {
    V v_t2_2447 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SPrimArray = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t2_2447}));
    return heff_tag_at_n(v_ru_24t_244_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2448});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecloseTypeF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam0(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_abandon();
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  heff_drop(v_u_2437);
  return heff_abandon();
}
Clo g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_entry, 6, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF_24generate0(V v_xs_240, V v_r_241, V v_i_242, V v_depth_243, V v_box_24i_244, V v_a_245) {
  int64_t v_i_244 = heff_unbox_word(v_box_24i_244);
  v_a_245 = heff_arrayOwn(v_a_245);
  if (((((int64_t)0ULL) <= v_i_244) && (heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
      V v_e2_246 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_244), 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_246}));
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_i_242;
      V t_3 = v_depth_243;
      int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
      V t_5 = heff_arraySetOwnedIn(v_a_245, heff_box_word(v_i_244), v_t_247);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_i_242 = t_2;
      v_depth_243 = t_3;
      v_i_244 = t_4;
      v_a_245 = t_5;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_241, 2);
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      return v_a_245;
    }
  } else {
  }
top: ;
  if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
    V v_e2_246 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_244), 2);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_246}));
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_i_242;
    V t_3 = v_depth_243;
    int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
    V t_5 = heff_arraySetOwned(v_a_245, heff_box_word(v_i_244), v_t_247);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_i_242 = t_2;
    v_depth_243 = t_3;
    v_i_244 = t_4;
    v_a_245 = t_5;
    goto top;
  } else {
    heff_drop_rec(v_r_241, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_a_245;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ecloseTermF_24generate0(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2ecloseTermF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_24map1_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF_24map1(V v_r_240, V v_i_241, V v_depth_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if ((((int64_t)0ULL) <= v_i_243)) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_p_245 = heff_arrayIndexIn_lent(v_a_244, heff_box_word(v_i_243), 2);
      V v_t_2410;
      switch (heff_tag_of(v_p_245)) {
      case TAG_MkPair: {
        V v_xs_246 = heff_field(v_p_245, 0);
        V v_b_247 = heff_field(v_p_245, 1);
        V v_ru_24p_245_24MkPair = heff_take_reuse_n(v_p_245, 3ULL, 2);
        V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_246)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), v_t_248), v_b_247}));
        v_t_2410 = heff_tag_at_n(v_ru_24p_245_24MkPair, TAG_MkPair, 2, (V[]){v_xs_246, v_t_249});
        break;
      }
      default: heff_nomatch(v_p_245);
      }
      V t_0 = v_r_240;
      V t_1 = v_i_241;
      V t_2 = v_depth_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2410);
      v_r_240 = t_0;
      v_i_241 = t_1;
      v_depth_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_i_241);
      heff_drop(v_depth_242);
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_p_245 = heff_arrayIndex_lent(v_a_244, heff_box_word(v_i_243), 2);
    V v_t_2410;
    switch (heff_tag_of(v_p_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_p_245, 0);
      V v_b_247 = heff_field(v_p_245, 1);
      V v_ru_24p_245_24MkPair = heff_take_reuse_n(v_p_245, 3ULL, 2);
      V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_246)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), v_t_248), v_b_247}));
      v_t_2410 = heff_tag_at_n(v_ru_24p_245_24MkPair, TAG_MkPair, 2, (V[]){v_xs_246, v_t_249});
      break;
    }
    default: heff_nomatch(v_p_245);
    }
    V t_0 = v_r_240;
    V t_1 = v_i_241;
    V t_2 = v_depth_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2410);
    v_r_240 = t_0;
    v_i_241 = t_1;
    v_depth_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    return v_a_244;
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_24map1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseTermF_24map1(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithStruct_str0, 2, "#T");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithStruct_str1, 1, "#");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithStruct_str2, 2, "#T");
V g_heff_2ebuild_2edriver_2ewithStruct_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewithStruct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithStruct_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithStruct(V v_m_240, V v_own_241, V v_t_242) {
top: ;
  V v_mkey_243 = v_m_240;
  V v_own_244 = v_own_241;
  V v_g_245 = heff_take_field(v_t_242, 0);
  V v_t_2432 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ewithStruct_lam0, 1, 1, (V[]){heff_dup(v_g_245)}), v_own_244));
  V v_es_2433 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2432));
  V v_globals_2482;
  switch (heff_tag_of(v_es_2433)) {
  case TAG_Nil: {
    heff_drop(v_mkey_243);
    v_globals_2482 = v_g_245;
    break;
  }
  case TAG_Cons: {
    V v_t_2436 = (g_list_2efoldl_24s1608132097x1207501887(NTAG(TAG_Small), v_es_2433));
    V v_t_2437 = ({ V a_0 = v_t_2436; V b_1 = NTAG(TAG_TopL); V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_2436); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_mkey_243);
      heff_drop_tag(v_es_2433, 2);
      heff_drop(v_t_2437);
      v_globals_2482 = v_g_245;
    } else {
      heff_drop(v_t_2437);
      V v_mkey_2438 = v_mkey_243;
      V v_g_2439 = v_g_245;
      V v_es_2440 = heff_dup(v_es_2433);
      V v_idx_2441 = ({ V a_0 = MK_INT(0LL); V a_1 = v_es_2433; V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ebuild_2edriver_2estructIdxGo(a_0, a_1, a_2)); heff_drop_tag(v_es_2433, 2); r_; });
      V v_mkey_2442 = heff_dup(v_mkey_2438);
      V v_es_2443 = heff_dup(v_es_2440);
      V v_k_2444 = heff_strAppend(v_mkey_2438, ((V)&g_heff_2ebuild_2edriver_2ewithStruct_str0));
      V v_t_2445 = (g_list_2efoldl_24s1608132097x1207501887(NTAG(TAG_Small), v_es_2440));
      V v_t_2446 = ({ V a_0 = v_t_2445; V b_1 = NTAG(TAG_Large); V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_2445); heff_drop(b_1); r_; });
      V v_t_2447;
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        v_t_2447 = NTAG(TAG_LargeU);
      } else {
        heff_drop(v_t_2446);
        v_t_2447 = NTAG(TAG_SmallU);
      }
      V v_tyStx_2448 = heff_tag_n(TAG_SU, 1, (V[]){v_t_2447});
      V v_t_2449 = (g_list_2efoldl_24s1608132097x1207501887(NTAG(TAG_Small), v_es_2440));
      V v_pairs_2450 = ({ V a_0 = v_idx_2441; V a_1 = MK_INT(0LL); V a_2 = v_es_2440; V r_ = (g_heff_2ebuild_2edriver_2estructFieldsGo(a_0, a_1, a_2)); heff_drop(v_idx_2441); r_; });
      V v_t_2451 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2450)));
      V v_t_2452 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2450));
      V v_t_2453 = (g_list_2emap_24s1173914895x100384474(v_pairs_2450));
      V v_t_2454 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2451), v_t_2452, heff_arrayFromList(v_t_2453)});
      V v_bodyStx_2455 = heff_tag_n(TAG_SCode, 1, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_t_2449, v_t_2454, heff_dup(g_heff_2eutil_2edict_2eempty_get())})});
      V v_t_2456 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_2439), heff_dup(v_k_2444), heff_dup(v_tyStx_2448), heff_dup(v_bodyStx_2455)));
      HeffT2 v_t_2457 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_2439), NTAG(TAG_N), heff_dup(v_tyStx_2448), NTAG(TAG_LNil)));
      V v_t_2463;
      {
        V v_field_2459 = v_t_2457.f[1];
        int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
        if ((v_tag_2458 == ((int64_t)0ULL))) {
          V v_x_2460 = v_field_2459;
          v_t_2463 = v_x_2460;
        } else {
          if ((v_tag_2458 == ((int64_t)1ULL))) {
            V v_x11_2461 = v_field_2459;
            heff_drop(v_x11_2461);
            v_t_2463 = heff_abandon();
          } else {
            V v_x_2462 = v_field_2459;
            v_t_2463 = v_x_2462;
          }
        }
      }
      V v_g_27_2464 = (g_heff_2eelab_2eglobals_2eaddEntry(v_k_2444, heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2455, v_tyStx_2448, v_t_2456, v_t_2463}), v_g_2439));
      V v_k_2465 = heff_strAppend(heff_dup(v_mkey_2442), ((V)&g_heff_2ebuild_2edriver_2ewithStruct_str1));
      V v_t_2466 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_strAppend(v_mkey_2442, ((V)&g_heff_2ebuild_2edriver_2ewithStruct_str2))});
      V v_tyStx_2467 = heff_tag_n(TAG_SDecode, 1, (V[]){v_t_2466});
      V v_pairs_2468 = (g_list_2emap_24s265594371x763318798(v_es_2443));
      V v_t_2469 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2468)));
      V v_t_2470 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2468));
      V v_t_2471 = (g_list_2emap_24s1173914895x100384474(v_pairs_2468));
      V v_t_2472 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2469), v_t_2470, heff_arrayFromList(v_t_2471)});
      V v_bodyStx_2473 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2472});
      V v_t_2474 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_27_2464), heff_dup(v_k_2465), heff_dup(v_tyStx_2467), heff_dup(v_bodyStx_2473)));
      HeffT2 v_t_2475 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_27_2464), NTAG(TAG_N), heff_dup(v_tyStx_2467), NTAG(TAG_LNil)));
      V v_t_2481;
      {
        V v_field_2477 = v_t_2475.f[1];
        int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
        if ((v_tag_2476 == ((int64_t)0ULL))) {
          V v_x_2478 = v_field_2477;
          v_t_2481 = v_x_2478;
        } else {
          if ((v_tag_2476 == ((int64_t)1ULL))) {
            V v_x11_2479 = v_field_2477;
            heff_drop(v_x11_2479);
            v_t_2481 = heff_abandon();
          } else {
            V v_x_2480 = v_field_2477;
            v_t_2481 = v_x_2480;
          }
        }
      }
      v_globals_2482 = (g_heff_2eelab_2eglobals_2eaddEntry(v_k_2465, heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2473, v_tyStx_2467, v_t_2474, v_t_2481}), v_g_27_2464));
    }
    break;
  }
  default: heff_nomatch(v_es_2433);
  }
  V v_keys_2483 = heff_take_field(v_t_242, 2);
  V v_broken_2484 = heff_take_field(v_t_242, 3);
  V v_watches_2485 = heff_take_field(v_t_242, 4);
  V v_tests_2486 = heff_take_field(v_t_242, 5);
  V v_spans_2487 = heff_take_field(v_t_242, 6);
  V v_infos_2488 = heff_take_field(v_t_242, 7);
  V v_trace_2489 = heff_take_field(v_t_242, 8);
  V v_unreached_2490 = heff_take_field(v_t_242, 9);
  return ({ V rv_0 = v_globals_2482; V rv_2 = v_keys_2483; V rv_3 = v_broken_2484; V rv_4 = v_watches_2485; V rv_5 = v_tests_2486; V rv_6 = v_spans_2487; V rv_7 = v_infos_2488; V rv_8 = v_trace_2489; V rv_9 = v_unreached_2490; V rr_ = heff_rec_reuse_nf(v_t_242, 2ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithStruct_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithStruct(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2ewithStruct_lam0(V self, V *args) {
  V v_o_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_247 = v_g_245;
  V v_entries_248 = heff_take_field(v_g_247, 1);
  V v_aliases_249 = heff_get_n(v_g_247, 2, 8);
  V v_o_2410 = v_o_246;
  V v_key_2411 = heff_take_field(v_o_2410, 1);
  V v_name_2412 = heff_get_n(v_o_2410, 0, 2);
  V v_k_2413 = heff_dup(v_key_2411);
  HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_248, v_k_2413));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_entries_248);
      heff_drop(v_aliases_249);
      heff_drop(v_k_2413);
      V v_e_2417 = v_field_2416;
      V v_tySyntax_2418 = heff_take_field(v_e_2417, 1);
      V v_type_5f_2419 = heff_get_n(v_e_2417, 3, 4);
      V v_t_2420 = ({ V a_0 = v_type_5f_2419; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_type_5f_2419); r_; });
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_name__key__ty__level, (V[]){v_name_2412, v_key_2411, v_tySyntax_2418, v_t_2420})});
    } else {
      heff_drop(v_field_2416);
      HeffT2 v_t_2421 = ({ V a_0 = v_aliases_249; V a_1 = v_k_2413; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_249); heff_drop(v_k_2413); r_; });
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          V v_k2_2424 = v_field_2423;
          HeffT2 v_t_2425 = ({ V a_0 = v_entries_248; V a_1 = v_k2_2424; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_248); heff_drop(v_k2_2424); r_; });
          {
            V v_field_2427 = v_t_2425.f[1];
            int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
            if ((v_tag_2426 == ((int64_t)0ULL))) {
              V v_e_2428 = v_field_2427;
              V v_tySyntax_2429 = heff_take_field(v_e_2428, 1);
              V v_type_5f_2430 = heff_get_n(v_e_2428, 3, 4);
              V v_t_2431 = ({ V a_0 = v_type_5f_2430; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_type_5f_2430); r_; });
              return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_name__key__ty__level, (V[]){v_name_2412, v_key_2411, v_tySyntax_2429, v_t_2431})});
            } else {
              heff_drop(v_key_2411);
              heff_drop(v_name_2412);
              heff_drop(v_field_2427);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_entries_248);
          heff_drop(v_key_2411);
          heff_drop(v_name_2412);
          heff_drop(v_field_2423);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
}
Clo g_heff_2ebuild_2edriver_2efixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efixOf(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_f_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_n_244, v_m_241, 0)) {
        return heff_dup(v_f_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_m_241;
        v_x1_240 = t_0;
        v_m_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2efixOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edriver_2eownKeyOf_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_o_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_name_244 = heff_dup(heff_rfield(v_o_242, 0));
    V v_key_245 = heff_dup(heff_rfield(v_o_242, 1));
    if (heff_strEq_c_lent(v_name_244, v_x_241, 1)) {
      V v_f_246 = v_key_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_key_245);
      V t_0 = v_rest_243;
      V t_1 = v_x_241;
      v_x1_240 = t_0;
      v_x_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str3, 11, "/package.hf");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str4, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str5, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str6, 33, "module claim is missing: `module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str8, 33, "module claim is missing: `module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str9, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str10, 24, "the module claim names `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str11, 26, "`, but by its path it is `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str12, 11, "`: `module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str13, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str14, 24, "ruled out by the arm at ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str15, 26, "ruled out by the match at ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str16, 58, "this arm never runs: the matches around it have ruled out ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str17, 21, "this arm never runs: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str18, 77, "this equation is never used: the equations above it match every value it does");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabTop_str19, 1, ".");
V g_heff_2ebuild_2edriver_2eelabTop_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabTop_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabTop(V v_s_240, V v_imps_241, V v_direct_242, V v_r_243, V v_t_244) {
top: ;
  V v_diags_245 = heff_take_field(v_r_243, 1);
  V v_arms_246 = heff_take_field(v_r_243, 4);
  V v_fixities_247 = heff_take_field(v_r_243, 2);
  V v_decls_248 = heff_get_n(v_r_243, 0, 5);
  V v_claim_249 = heff_take_field(v_imps_241, 2);
  V v_implicit_2410 = heff_take_field(v_imps_241, 1);
  V v_imports_2411 = heff_get_n(v_imps_241, 0, 4);
  V v_shown_2412 = heff_take_field(v_s_240, 3);
  V v_source_2413 = heff_take_field(v_s_240, 4);
  V v_module_2414 = heff_take_field(v_s_240, 0);
  V v_path_2415 = heff_take_field(v_s_240, 2);
  V v_named_2416 = heff_get_n(v_s_240, 1, 8);
  V v_shown_2417 = v_shown_2412;
  V v_source_2418 = heff_dup(v_source_2413);
  V v_t_2422;
  switch (heff_tag_of(v_claim_249)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2419 = heff_dup(heff_field(v_claim_249, 0));
    V v_listed_2420 = heff_take_field(v_h_2419, 1);
    V v_exposes_2421 = heff_get_n(v_h_2419, 2, 5);
    if ((heff_dup(v_listed_2420) == NTAG(TAG_True))) {
      heff_drop(v_listed_2420);
      v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){v_exposes_2421});
    } else {
      heff_drop(v_listed_2420);
      heff_drop(v_exposes_2421);
      v_t_2422 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_claim_249);
  }
  V v_t_2423 = ({ V a_0 = heff_dup(v_module_2414); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_244, 2)); V r_ = (g_list_2emap_24s262223576x596329185(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_2424 = ({ V a_0 = v_t_2422; V a_1 = v_t_2423; V r_ = (g_heff_2ebuild_2edriver_2eexposedIn(a_0, a_1)); heff_drop(v_t_2422); r_; });
  V v_top_2425 = (g_heff_2ebuild_2edriver_2ewithStruct(heff_dup(v_module_2414), v_t_2424, heff_dup(v_t_244)));
  V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_implicit_2410));
  V v_t_2427 = (g_list_2edrop(v_t_2426, v_imports_2411));
  V v_t_2428 = (g_heff_2ebuild_2edriver_2eagainGo(heff_dup(v_implicit_2410), heff_dup(v_implicit_2410), v_t_2427));
  V v_path_2429 = heff_dup(v_path_2415);
  V v_modName_2430 = v_named_2416;
  V v_g_2431 = heff_take_field(v_t_244, 0);
  V v_own_2432 = ({ V a_0 = heff_dup(v_module_2414); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_244, 2)); V r_ = (g_list_2emap_24s262223576x596329185(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_h_2433 = heff_dup(v_claim_249);
  V v_t_2463;
  if ((heff_strEq_c_lent(v_path_2429, ((V)&g_heff_2ebuild_2edriver_2eelabTop_str2), 2) || ({ int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_path_2429, 0)) - ((int64_t)11ULL)); int c_ = ({ V v_t_24107 = heff_strSlice(heff_dup(v_path_2429), heff_box_word(v_t_2434), heff_strLength_lent(v_path_2429, 0)); int c_ = (heff_strEq_c_lent(v_t_24107, ((V)&g_heff_2ebuild_2edriver_2eelabTop_str3), 2) || (heff_strEq_c_lent(v_path_2429, ((V)&g_heff_2ebuild_2edriver_2eelabTop_str4), 2) || ({ int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_path_2429, 0)) - ((int64_t)9ULL)); int c_ = ({ V v_t_24108 = heff_strSlice(heff_dup(v_path_2429), heff_box_word(v_t_2435), heff_strLength_lent(v_path_2429, 0)); int c_ = heff_strEq_c_lent(v_t_24108, ((V)&g_heff_2ebuild_2edriver_2eelabTop_str5), 2); heff_drop(v_t_24108); c_; }); c_; }))); heff_drop(v_t_24107); c_; }); c_; }))) {
    heff_drop(v_path_2429);
    heff_drop(v_modName_2430);
    heff_drop(v_g_2431);
    heff_drop(v_own_2432);
    heff_drop(v_h_2433);
    v_t_2463 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_path_2429);
    V v_modName_2436 = v_modName_2430;
    V v_g_2437 = v_g_2431;
    V v_own_2438 = v_own_2432;
    V v_x4_2439 = v_h_2433;
    switch (heff_tag_of(v_x4_2439)) {
    case TAG_Nothing: {
      heff_drop(v_g_2437);
      heff_drop(v_own_2438);
      V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabTop_str6), v_modName_2436), ((V)&g_heff_2ebuild_2edriver_2eelabTop_str7));
      V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(156LL), NTAG(TAG_SError), v_t_2440, heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)}), NTAG(TAG_Nothing)});
      v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Just: {
      V v_h_2442 = heff_field(v_x4_2439, 0);
      heff_take_n(v_x4_2439, 1ULL, 1);
      V v_t_2443 = heff_dup(heff_rfield(v_h_2442, 4));
      V v_t_2448;
      switch (heff_tag_of(v_t_2443)) {
      case TAG_Nothing: {
        v_t_2448 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_err_2444 = heff_field(v_t_2443, 0);
        heff_take_n(v_t_2443, 1ULL, 1);
        V v_msg_2445 = heff_take_field(v_err_2444, 1);
        V v_span_2446 = heff_get_n(v_err_2444, 0, 2);
        V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(154LL), NTAG(TAG_SError), v_msg_2445, v_span_2446, NTAG(TAG_Nothing)});
        v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_t_2443);
      }
      V v_modName_2449 = v_modName_2436;
      V v_h_2450 = heff_dup(v_h_2442);
      V v_name_2451 = heff_take_field(v_h_2450, 0);
      V v_span_2452 = heff_get_n(v_h_2450, 3, 5);
      V v_t_2460;
      switch (heff_tag_of(v_name_2451)) {
      case TAG_Nothing: {
        V v_t_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabTop_str8), v_modName_2449), ((V)&g_heff_2ebuild_2edriver_2eelabTop_str9));
        V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(156LL), NTAG(TAG_SError), v_t_2453, v_span_2452, NTAG(TAG_Nothing)});
        v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Just: {
        V v_n_2455 = heff_field(v_name_2451, 0);
        heff_take_n(v_name_2451, 1ULL, 1);
        if (heff_strEq_c_lent(v_n_2455, v_modName_2449, 0)) {
          heff_drop(v_modName_2449);
          heff_drop(v_span_2452);
          heff_drop(v_n_2455);
          v_t_2460 = NTAG(TAG_Nil);
        } else {
          V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabTop_str10), v_n_2455), ((V)&g_heff_2ebuild_2edriver_2eelabTop_str11));
          V v_t_2457 = heff_strAppend(heff_strAppend(v_t_2456, heff_dup(v_modName_2449)), ((V)&g_heff_2ebuild_2edriver_2eelabTop_str12));
          V v_t_2458 = heff_strAppend(heff_strAppend(v_t_2457, v_modName_2449), ((V)&g_heff_2ebuild_2edriver_2eelabTop_str13));
          V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(157LL), NTAG(TAG_SError), v_t_2458, v_span_2452, NTAG(TAG_Nothing)});
          v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_name_2451);
      }
      V v_t_2461 = ({ V a_0 = v_g_2437; V a_1 = v_own_2438; V a_2 = NTAG(TAG_Nil); V a_3 = heff_get_n(v_h_2442, 2, 5); V r_ = (g_heff_2ebuild_2edriver_2eexposedDiagsGo(a_0, a_1, a_2, a_3)); heff_drop(v_own_2438); r_; });
      V v_t_2462 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2460, v_t_2461));
      v_t_2463 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2448, v_t_2462));
      break;
    }
    default: heff_nomatch(v_x4_2439);
    }
  }
  V v_t_2464 = (g_heff_2ebuild_2edriver_2eappendD(v_diags_245, heff_take_field(v_t_244, 1)));
  V v_t_2465 = (g_list_2emap_24s864521685x1610969087(v_t_2464));
  V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_t_244, 9)));
  V v_t_2489 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eelabTop_lam0, 2, 2, (V[]){v_source_2413, v_arms_246}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2466; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
  V v_t_2490 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2465, v_t_2489));
  V v_t_2491 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2463, v_t_2490));
  V v_diags_2492 = (g_heff_2ebuild_2edriver_2eappendD(v_t_2428, v_t_2491));
  V v_own_2493 = ({ V a_0 = heff_dup(v_module_2414); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str19); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_get_n(v_t_244, 2, 10); V r_ = (g_list_2emap_24s262223576x596329185(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_2494 = (g_list_2emap_24s1817208647x1282894070(heff_dup(v_imports_2411)));
  V v_deps_2495 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2494));
  V v_t_2496 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_implicit_2410));
  V v_t_2497 = (g_list_2edrop(v_t_2496, v_imports_2411));
  V v_opens_2498 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2497));
  V v_t_2499 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_implicit_2410; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_implicit_2410); r_; });
  V v_t_24100 = ({ V a_0 = v_t_2499; V a_1 = v_imports_2411; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_imports_2411); r_; });
  V v_aliases_24101 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_24100));
  V v_fixities_24102 = v_fixities_247;
  V v_t_24106;
  switch (heff_tag_of(v_claim_249)) {
  case TAG_Nothing: {
    v_t_24106 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_24103 = heff_field(v_claim_249, 0);
    V v_ru_24claim_249_24Just = heff_take_reuse_n(v_claim_249, 1ULL, 1);
    V v_listed_24104 = heff_take_field(v_h_24103, 1);
    V v_exposes_24105 = heff_get_n(v_h_24103, 2, 5);
    if ((heff_dup(v_listed_24104) == NTAG(TAG_True))) {
      heff_drop(v_listed_24104);
      v_t_24106 = heff_tag_at_n(v_ru_24claim_249_24Just, TAG_Just, 1, (V[]){v_exposes_24105});
    } else {
      heff_drop_cell(v_ru_24claim_249_24Just, 1);
      heff_drop(v_listed_24104);
      heff_drop(v_exposes_24105);
      v_t_24106 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_claim_249);
  }
  return heff_rec_n(14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, (V[]){v_module_2414, v_path_2415, v_shown_2417, v_source_2418, v_decls_248, v_top_2425, v_diags_2492, v_own_2493, v_deps_2495, v_opens_2498, v_aliases_24101, v_fixities_24102, NTAG(TAG_False), v_t_24106});
}
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eelabTop(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edriver_2eelabTop_lam0(V self, V *args) {
  V v_acc_2467 = args[0];
  V v_x_2468 = args[1];
  V v_source_2413 = heff_env(self)[0];
  V v_arms_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_2469 = v_source_2413;
  V v_written_2470 = v_arms_246;
  V v_x3_2471 = v_x_2468;
  V v_t_2488;
  switch (heff_tag_of(v_x3_2471)) {
  case TAG_ArmTaken: {
    heff_take_n(v_x3_2471, 0ULL, 1);
    heff_drop(v_src_2469);
    heff_drop(v_written_2470);
    v_t_2488 = NTAG(TAG_Nil);
    break;
  }
  case TAG_ArmRuledOut: {
    V v_at_2473 = heff_field(v_x3_2471, 0);
    V v_by_2474 = heff_field(v_x3_2471, 1);
    V v_what_2475 = heff_field(v_x3_2471, 2);
    heff_take_n(v_x3_2471, 7ULL, 3);
    V v_t_2476 = (g_list_2eany_24s1119291297x466217959(heff_dup(v_at_2473), v_written_2470));
    if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
      heff_drop(v_t_2476);
      V v_t_2477 = ({ V a_0 = heff_dup(v_by_2474); V a_1 = v_written_2470; V r_ = (g_list_2eany_24s1119291297x466217959(a_0, a_1)); heff_drop(v_written_2470); r_; });
      V v_t_2478;
      if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
        heff_drop(v_t_2477);
        v_t_2478 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str14);
      } else {
        heff_drop(v_t_2477);
        v_t_2478 = ((V)&g_heff_2ebuild_2edriver_2eelabTop_str15);
      }
      V v_t_2479 = ({ V a_0 = v_src_2469; V a_1 = heff_get_n(v_by_2474, 0, 2); V a_2 = MK_INT(1LL); V a_3 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2elineColFrom(a_0, a_1, a_2, a_3)); heff_drop(v_src_2469); r_; });
      V v_note_2480 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_2478, v_t_2479)});
      V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(358LL), NTAG(TAG_SWarning), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabTop_str16), v_what_2475), v_at_2473, v_note_2480});
      v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_src_2469);
      heff_drop(v_written_2470);
      heff_drop(v_at_2473);
      heff_drop_rec(v_by_2474, 2);
      heff_drop(v_what_2475);
      heff_drop(v_t_2476);
      v_t_2488 = NTAG(TAG_Nil);
    }
    break;
  }
  case TAG_ArmCovered: {
    V v_at_2482 = heff_field(v_x3_2471, 0);
    V v_why_2483 = heff_field(v_x3_2471, 1);
    V v_ru_24x3_2471_24ArmCovered = heff_take_reuse_n(v_x3_2471, 3ULL, 2);
    heff_drop(v_src_2469);
    V v_t_2484 = ({ V a_0 = heff_dup(v_at_2482); V a_1 = v_written_2470; V r_ = (g_list_2eany_24s1119291297x466217959(a_0, a_1)); heff_drop(v_written_2470); r_; });
    if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
      heff_drop(v_t_2484);
      V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(359LL), NTAG(TAG_SWarning), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabTop_str17), v_why_2483), v_at_2482, NTAG(TAG_Nothing)});
      v_t_2488 = heff_tag_at_n(v_ru_24x3_2471_24ArmCovered, TAG_Cons, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_at_2482);
      heff_drop(v_why_2483);
      heff_drop_cell(v_ru_24x3_2471_24ArmCovered, 2);
      heff_drop(v_t_2484);
      v_t_2488 = NTAG(TAG_Nil);
    }
    break;
  }
  case TAG_EquationCovered: {
    V v_at_2486 = heff_field(v_x3_2471, 0);
    heff_take_n(v_x3_2471, 1ULL, 1);
    heff_drop(v_src_2469);
    heff_drop(v_written_2470);
    V v_t_2487 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(359LL), NTAG(TAG_SWarning), ((V)&g_heff_2ebuild_2edriver_2eelabTop_str18), v_at_2486, NTAG(TAG_Nothing)});
    v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x3_2471);
  }
  return (g_prelude_2e_2b_2b(v_t_2488, v_acc_2467));
}
Clo g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391(V v_lit_240, V v_lit_241, V v_g_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 8);
    heff_drop(v_lit_241);
    return v_g_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_rest_245 = heff_field(v_x3_243, 1);
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_k_247 = heff_strAppend(v_t_246, heff_dup(v_x_244));
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_k_249 = heff_strAppend(v_t_248, heff_dup(v_x_244));
    V v_t_2410 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_g_242, 4), v_x_244));
    V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_242, 2), heff_dup(v_x_244), v_k_249));
    V v_t_2412 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_242, 3), v_k_247, NTAG(TAG_MkUnit)));
    V v_t_2413 = ({ V rv_2 = v_t_2411; V rv_3 = v_t_2412; V rv_4 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_g_242, 227ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 64527u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2413;
    V t_3 = v_rest_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_g_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabDecls_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabDecls_str1, 1, ".");
Clo g_heff_2ebuild_2edriver_2eelabDecls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabDecls_entry, 7, 0};

V g_heff_2ebuild_2edriver_2eelabDecls(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245, V v_decls_246) {
top: ;
  V v_modName_247 = heff_dup(heff_rfield(v_s_241, 0));
  V v_g0_248 = (g_heff_2ebuild_2edriver_2ewithParseBroken_24s1761392635x1068744391(heff_dup(v_s_241), ((V)&g_heff_2ebuild_2edriver_2eelabDecls_str0), v_g0_244, heff_rfield(v_r_245, 3)));
  V v_t_249 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_g0_248, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2410 = (g_list_2emap_24s1960706388x853997965(v_decls_246));
  V v_t_2411 = ({ V a_0 = v_modName_247; V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabDecls_str1); V a_2 = v_t_249; V a_3 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2etopGo_24s115206646x975860883(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
  return (g_heff_2ebuild_2edriver_2eelabTop(v_s_241, v_imps_242, v_direct_243, v_r_245, v_t_2411));
}
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabDecls(a0, a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eprimDeclsGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eprimDeclsGo(V v_c_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x2_241, 0);
    V v_os_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_245 = heff_take_field(v_o_243, 0);
    V v_key_246 = heff_get_n(v_o_243, 1, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_os_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_name_245);
      heff_drop(v_key_246);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x31_247 = heff_field(v_x3_242, 0);
      V v_sps_248 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_sp_2410 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 2ULL, 2);
        if (heff_strEq_c_lent(v_name_245, v_key_246, 1)) {
          V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__by__span, (V[]){v_key_246, heff_dup(v_c_240), v_sp_2410}), heff_hole()});
          V v_u_2412 = (g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(v_c_240, v_os_244, v_sps_248, heff_dup(v_cell_2411)));
          heff_drop(v_u_2412);
          return v_cell_2411;
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_key_246);
          heff_drop(v_sp_2410);
          V t_0 = v_c_240;
          V t_1 = v_os_244;
          V t_2 = v_sps_248;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      default: return heff_nomatch(v_x31_247);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eprimDeclsGo(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(V v_c_240, V v_x2_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_x3_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_os_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_246 = heff_take_field(v_o_244, 0);
    V v_key_247 = heff_get_n(v_o_244, 1, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_os_245);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_name_246);
      heff_drop(v_key_247);
      return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x31_248 = heff_field(v_x3_242, 0);
      V v_sps_249 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_248)) {
      case TAG_MkPair: {
        V v_sp_2411 = heff_field(v_x31_248, 1);
        heff_take_n(v_x31_248, 2ULL, 2);
        if (heff_strEq_c_lent(v_name_246, v_key_247, 1)) {
          V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__by__span, (V[]){v_key_247, heff_dup(v_c_240), v_sp_2411}), heff_hole()});
          V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
          heff_drop(v_u_2413);
          V t_0 = v_c_240;
          V t_1 = v_os_245;
          V t_2 = v_sps_249;
          V t_3 = v_cell_2412;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_d_243 = t_3;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_key_247);
          heff_drop(v_sp_2411);
          V t_0 = v_c_240;
          V t_1 = v_os_245;
          V t_2 = v_sps_249;
          V t_3 = v_d_243;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_d_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x31_248);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eprimDeclsGo_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2edriver_2ewithDiags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithDiags_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewithDiags(V v_c_240, V v_ds_241) {
top: ;
  switch (heff_tag_of(v_ds_241)) {
  case TAG_Nil: {
    return v_c_240;
  }
  case TAG_Cons: {
    V v_shown_244 = heff_take_field(v_c_240, 2);
    V v_source_245 = heff_take_field(v_c_240, 3);
    V v_decls_246 = heff_take_field(v_c_240, 4);
    V v_top_247 = heff_take_field(v_c_240, 5);
    V v_diags_248 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_c_240, 6), v_ds_241));
    V v_own_249 = heff_take_field(v_c_240, 7);
    V v_deps_2410 = heff_take_field(v_c_240, 8);
    V v_opens_2411 = heff_take_field(v_c_240, 9);
    V v_aliases_2412 = heff_take_field(v_c_240, 10);
    V v_fixities_2413 = heff_take_field(v_c_240, 11);
    V v_cached_2414 = heff_take_field(v_c_240, 12);
    V v_exposes_2415 = heff_take_field(v_c_240, 13);
    return ({ V rv_2 = v_shown_244; V rv_3 = v_source_245; V rv_4 = v_decls_246; V rv_5 = v_top_247; V rv_6 = v_diags_248; V rv_7 = v_own_249; V rv_8 = v_deps_2410; V rv_9 = v_opens_2411; V rv_10 = v_aliases_2412; V rv_11 = v_fixities_2413; V rv_12 = v_cached_2414; V rv_13 = v_exposes_2415; V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 10) = rv_10; heff_rfield(rr_, 11) = rv_11; heff_rfield(rr_, 12) = rv_12; heff_rfield(rr_, 13) = rv_13; rr_; });
  }
  default: return heff_nomatch(v_ds_241);
  }
}
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithDiags(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ewithTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithTwice_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ewithTwice(V v_done_240, V v_imps_241, V v_needed_242, V v_c_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(v_needed_242));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_243, 5)), 6, 10);
  V v_t_246 = (g_heff_2ebuild_2edriver_2eprimDeclsGo(heff_dup(v_c_243), heff_dup(heff_rfield(v_c_243, 7)), v_t_245));
  V v_t_247 = (g_heff_2ebuild_2edriver_2eappendD(v_t_244, v_t_246));
  V v_t_248 = (g_heff_2ebuild_2edriver_2etwicesGo(heff_dup(g_std_2eordmap_2eempty_get()), v_t_247));
  V v_t_249 = (g_list_2ekeepIf_24s14815453x1234467625(heff_dup(v_done_240), heff_dup(v_imps_241), heff_dup(v_c_243), v_t_248));
  V v_t_2410 = (g_list_2emap_24s204237290x1967740547(v_done_240, v_imps_241, heff_dup(v_c_243), v_t_249));
  return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_243, v_t_2410));
}
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ewithTwice(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabNeeding_str0, 3, "by ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabNeeding_str1, 5, ", at ");
V g_heff_2ebuild_2edriver_2eelabNeeding_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eelabNeeding_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2eelabNeeding_lam2(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabNeeding_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabNeeding(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_reached_244) {
top: ;
  V v_needed_247 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam0, 1, 1, (V[]){heff_dup(v_reached_244)}), heff_dup(v_done_240)));
  V v_done_248 = heff_dup(v_done_240);
  V v_s_249 = v_s_241;
  V v_imps_2410 = heff_dup(v_imps_242);
  V v_thaw_2411 = v_thaw_243;
  V v_direct_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam1, 1, 1, (V[]){heff_dup(v_imps_242)}), heff_dup(v_done_240)));
  V v_needed_2416 = heff_dup(v_needed_247);
  V v_done_2417 = heff_dup(v_done_248);
  V v_s_2418 = v_s_249;
  V v_imps_2419 = heff_dup(v_imps_2410);
  V v_x4_2420 = v_thaw_2411;
  V v_direct_2421 = heff_dup(v_direct_2415);
  V v_t_2422 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_2410, 0))));
  V v_t_2423 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2422));
  V v_t_2424 = (g_list_2emap_24s1817208647x1282894070(heff_take_field(v_imps_2410, 1)));
  V v_g_2425 = (g_list_2efoldl_24s1261443129x1682844402(heff_dup(g_heff_2eelab_2eglobals_2eemptyGlobals_get()), v_needed_2416));
  V v_t_2426 = ({ V a_0 = v_g_2425; V a_1 = v_needed_2416; V r_ = (g_list_2efoldl_24s1722922134x788519507(a_0, a_1)); heff_drop(v_needed_2416); r_; });
  V v_t_2427 = ({ V a_0 = heff_dup(v_done_248); V a_1 = v_t_2424; V a_2 = v_t_2426; V a_3 = v_direct_2415; V r_ = (g_heff_2ebuild_2edriver_2ealiasOpen(a_0, a_1, a_2, a_3)); heff_drop(v_t_2424); heff_drop(v_direct_2415); r_; });
  V v_t_2428 = (g_heff_2ebuild_2edriver_2ealiasPairs(heff_get_n(v_imps_2410, 0, 4)));
  V v_t_2429 = ({ V a_0 = v_done_248; V a_1 = v_t_2427; V a_2 = v_t_2428; V r_ = (g_heff_2ebuild_2edriver_2ealiasQualified(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
  V v_g0_2430 = ({ V a_0 = v_done_248; V a_1 = v_t_2423; V a_2 = v_t_2429; V r_ = (g_heff_2ebuild_2edriver_2ewithImportedInstances(a_0, a_1, a_2)); heff_drop(v_done_248); heff_drop(v_t_2423); r_; });
  V v_t_2470;
  switch (heff_tag_of(v_x4_2420)) {
  case TAG_Nothing: {
    V v_done_2431 = v_done_2417;
    V v_s_2432 = v_s_2418;
    V v_imps_2433 = v_imps_2419;
    V v_direct_2434 = v_direct_2421;
    V v_g0_2435 = v_g0_2430;
    V v_done_2436 = v_done_2431;
    V v_s_2437 = heff_dup(v_s_2432);
    V v_imps_2438 = heff_dup(v_imps_2433);
    V v_direct_2439 = heff_dup(v_direct_2434);
    V v_g0_2440 = heff_dup(v_g0_2435);
    V v_t_2441 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()); V a_1 = v_direct_2434; V r_ = (g_list_2efoldl_24s634644062x504497039(a_0, a_1)); heff_drop(v_direct_2434); r_; });
    V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabNeeding_str0), heff_take_field(v_s_2432, 0));
    V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2edriver_2eelabNeeding_str1)), heff_dup(heff_rfield(v_s_2432, 3)));
    V v_o_2452 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam2, 1, 1, (V[]){v_g0_2435}), v_t_2441, NTAG(TAG_False), v_t_2443, heff_get_n(v_s_2432, 3, 8)});
    V v_src_2453 = heff_get_n(v_imps_2433, 3, 4);
    V v_t_2454 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    V v_t_2455 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_2453), v_t_2454, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_r_2456 = (g_heff_2esyntax_2esurface_2ereadLexed(v_src_2453, v_o_2452, v_t_2455));
    V v_t_2457 = heff_dup(heff_rfield(v_s_2437, 7));
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      v_t_2470 = ({ V a_0 = v_done_2436; V a_1 = v_s_2437; V a_2 = v_imps_2438; V a_3 = v_direct_2439; V a_4 = v_g0_2440; V a_5 = heff_dup(v_r_2456); V a_6 = heff_get_n(v_r_2456, 0, 5); V r_ = (g_heff_2ebuild_2edriver_2eelabDecls(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_done_2436); heff_drop(v_direct_2439); r_; });
    } else {
      heff_drop(v_t_2457);
      V v_t_2458 = (g_list_2emap_24s1535007417x1587061701(heff_dup(heff_rfield(v_r_2456, 0))));
      V v_refused_2459 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2458));
      V v_t_2460 = (g_list_2emap_24s1534167768x1221742344(heff_dup(v_refused_2459)));
      V v_t_2461 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_2456, 1), v_t_2460));
      V v_t_2462 = (g_list_2emap_24s1937570095x2110149801(v_refused_2459));
      V v_t_2463 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_2456, 3), v_t_2462));
      V v_t_2464 = heff_rec_n(5, shape_decls__diags__fixities__broken__arms, (V[]){heff_dup(heff_rfield(v_r_2456, 0)), v_t_2461, heff_take_field(v_r_2456, 2), v_t_2463, heff_take_field(v_r_2456, 4)});
      V v_t_2465 = (g_list_2ekeepIf_24s1819141159x1906443669(heff_get_n(v_r_2456, 0, 5)));
      v_t_2470 = ({ V a_0 = v_done_2436; V a_1 = v_s_2437; V a_2 = v_imps_2438; V a_3 = v_direct_2439; V a_4 = v_g0_2440; V a_5 = v_t_2464; V a_6 = v_t_2465; V r_ = (g_heff_2ebuild_2edriver_2eelabDecls(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_done_2436); heff_drop(v_direct_2439); r_; });
    }
    break;
  }
  case TAG_Just: {
    V v_th_2466 = heff_field(v_x4_2420, 0);
    V v_ru_24x4_2420_24Just = heff_take_reuse_n(v_x4_2420, 1ULL, 1);
    heff_drop(v_done_2417);
    heff_drop(v_direct_2421);
    V v_t_2467 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_g0_2430, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2468 = (g_list_2efoldl_24s337463599x663364213(v_t_2467, heff_rfield(v_th_2466, 1)));
    V v_t_2469 = (g_heff_2eelab_2etoplevel_2ethawDone(v_t_2468));
    v_t_2470 = (g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(v_ru_24x4_2420_24Just, v_s_2418, v_imps_2419, v_th_2466, v_t_2469));
    break;
  }
  default: heff_nomatch(v_x4_2420);
  }
  return ({ V a_0 = v_done_240; V a_1 = v_imps_242; V a_2 = v_needed_247; V a_3 = v_t_2470; V r_ = (g_heff_2ebuild_2edriver_2ewithTwice(a_0, a_1, a_2, a_3)); heff_drop(v_needed_247); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2edriver_2eelabNeeding(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_reached_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_245, 0, 14)}));
  return ({ V a_0 = v_t_246; V a_1 = v_reached_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_reached_244); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam1(V self, V *args) {
  V v_c_2412 = args[0];
  V v_imps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2413 = (g_heff_2ebuild_2edriver_2eopenNames(heff_get_n(v_imps_242, 0, 4)));
  V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2412, 0, 14)}));
  return ({ V a_0 = v_t_2414; V a_1 = v_xs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2413); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam2(V self, V *args) {
  V v_x_2444 = args[0];
  V v_g0_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_2445 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(v_g0_2435, v_x_2444));
  {
    V v_field_2447 = v_t_2445.f[1];
    V v_field_2448 = v_t_2445.f[2];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2446 == ((int64_t)0ULL)) ? ({ V v_x_2449 = heff_dup(v_field_2447); int c_ = 1; heff_drop(v_x_2449); c_; }) : ((v_tag_2446 == ((int64_t)1ULL)) || ((v_tag_2446 == ((int64_t)2ULL)) && ({ V v_x_2450 = heff_dup(v_field_2447); int c_ = ({ V v_x_2451 = heff_dup(v_field_2448); int c_ = 1; heff_drop(v_x_2451); c_; }); heff_drop(v_x_2450); c_; })))));
    heff_drop(v_field_2447);
    heff_drop(v_field_2448);
    return v_ret_24bool;
  }
}
Clo g_heff_2ebuild_2edriver_2elean_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elean_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elean(V v_c_240) {
top: ;
  V v_shown_241 = heff_take_field(v_c_240, 2);
  V v_source_242 = heff_take_field(v_c_240, 3);
  V v_decls_243 = heff_take_field(v_c_240, 4);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 7, 10);
  V v_infos_245 = (g_list_2emap_24s214260857x938990544(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 1, 10);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 2, 10);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 10);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 4, 10);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 10);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 10);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 9, 10);
  V v_top_2414 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_t_246, v_t_247, v_t_248, v_t_249, v_t_2410, v_t_2411, v_t_2412, v_infos_245, NTAG(TAG_Nil), v_t_2413});
  V v_diags_2415 = heff_take_field(v_c_240, 6);
  V v_own_2416 = heff_take_field(v_c_240, 7);
  V v_deps_2417 = heff_take_field(v_c_240, 8);
  V v_opens_2418 = heff_take_field(v_c_240, 9);
  V v_aliases_2419 = heff_take_field(v_c_240, 10);
  V v_fixities_2420 = heff_take_field(v_c_240, 11);
  V v_cached_2421 = heff_take_field(v_c_240, 12);
  V v_exposes_2422 = heff_take_field(v_c_240, 13);
  return ({ V rv_2 = v_shown_241; V rv_3 = v_source_242; V rv_4 = v_decls_243; V rv_5 = v_top_2414; V rv_6 = v_diags_2415; V rv_7 = v_own_2416; V rv_8 = v_deps_2417; V rv_9 = v_opens_2418; V rv_10 = v_aliases_2419; V rv_11 = v_fixities_2420; V rv_12 = v_cached_2421; V rv_13 = v_exposes_2422; V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 10) = rv_10; heff_rfield(rr_, 11) = rv_11; heff_rfield(rr_, 12) = rv_12; heff_rfield(rr_, 13) = rv_13; rr_; });
}
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elean(a[0]);
}
Clo g_heff_2ebuild_2edriver_2etraceless_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etraceless_entry, 1, 0};

V g_heff_2ebuild_2edriver_2etraceless(V v_c_240) {
top: ;
  V v_shown_241 = heff_take_field(v_c_240, 2);
  V v_source_242 = heff_take_field(v_c_240, 3);
  V v_decls_243 = heff_take_field(v_c_240, 4);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 1, 10);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 2, 10);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 10);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 4, 10);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 10);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 10);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 7, 10);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 9, 10);
  V v_top_2413 = heff_rec_n(10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, (V[]){v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249, v_t_2410, v_t_2411, NTAG(TAG_Nil), v_t_2412});
  V v_diags_2414 = heff_take_field(v_c_240, 6);
  V v_own_2415 = heff_take_field(v_c_240, 7);
  V v_deps_2416 = heff_take_field(v_c_240, 8);
  V v_opens_2417 = heff_take_field(v_c_240, 9);
  V v_aliases_2418 = heff_take_field(v_c_240, 10);
  V v_fixities_2419 = heff_take_field(v_c_240, 11);
  V v_cached_2420 = heff_take_field(v_c_240, 12);
  V v_exposes_2421 = heff_take_field(v_c_240, 13);
  return ({ V rv_2 = v_shown_241; V rv_3 = v_source_242; V rv_4 = v_decls_243; V rv_5 = v_top_2413; V rv_6 = v_diags_2414; V rv_7 = v_own_2415; V rv_8 = v_deps_2416; V rv_9 = v_opens_2417; V rv_10 = v_aliases_2418; V rv_11 = v_fixities_2419; V rv_12 = v_cached_2420; V rv_13 = v_exposes_2421; V rr_ = heff_rec_reuse_nf(v_c_240, 3ULL, 14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 10) = rv_10; heff_rfield(rr_, 11) = rv_11; heff_rfield(rr_, 12) = rv_12; heff_rfield(rr_, 13) = rv_13; rr_; });
}
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etraceless(a[0]);
}
Clo g_heff_2ebuild_2edriver_2elastChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elastChecked_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elastChecked(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2elastChecked(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str1, 6, "-- >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str2, 4, "-- |");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str3, 0, "");
Clo g_heff_2ebuild_2edriver_2ewatchExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewatchExpect_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ewatchExpect(V v_line_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_line_240, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str0))) {
    if (!heff_strEq_c(heff_strSlice_lent(v_line_240, MK_INT(0LL), MK_INT(6LL), 6), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str1))) {
      if (!heff_strEq_c(heff_strSlice_lent(v_line_240, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str2))) {
        V v_s_241 = heff_strSlice(heff_dup(v_line_240), MK_INT(2LL), heff_strLength_lent(v_line_240, 0));
        V v_t_242 = (g_prelude_2eskipSpaces(v_s_241, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_s_241, 0)) - ((int64_t)1ULL));
        V v_t_244 = (g_prelude_2eskipSpaces(v_s_241, heff_box_word(v_t_243), MK_INT(-1LL)));
        V v_t_245 = heff_strSlice(v_s_241, v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
        V v_x1_246 = heff_bool(heff_strEq_c_lent(v_t_245, ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str3), 2));
        heff_drop(v_t_245);
        if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
          heff_drop(v_x1_246);
          V v_s_247 = heff_strSlice(heff_dup(v_line_240), MK_INT(2LL), heff_strLength_lent(v_line_240, 0));
          V v_t_248 = (g_prelude_2eskipSpaces(v_s_247, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_247, 0)) - ((int64_t)1ULL));
          V v_t_2410 = (g_prelude_2eskipSpaces(v_s_247, heff_box_word(v_t_249), MK_INT(-1LL)));
          V v_t_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
        } else {
          heff_drop(v_x1_246);
          return NTAG(TAG_Nothing);
        }
      } else {
        return NTAG(TAG_Nothing);
      }
    } else {
      return NTAG(TAG_Nothing);
    }
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2ewatchExpect_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ewatchExpect(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2etestsOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2etestsOf_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2etestsOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etestsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestsOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2etestsOf(V v_c_240) {
top: ;
  V v_all_2450 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2etestsOf_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_dup(heff_rfield(v_c_240, 7))));
  return (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2etestsOf_lam1, 1, 2, (V[]){v_c_240, heff_dup(v_all_2450)}), v_all_2450));
}
V g_heff_2ebuild_2edriver_2etestsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestsOf(a[0]);
}
V g_heff_2ebuild_2edriver_2etestsOf_lam0(V self, V *args) {
  V v_o_241 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_242 = v_c_240;
  V v_o_243 = v_o_241;
  V v_g_244 = heff_get_n(heff_get_n(v_c_242, 5, 14), 0, 10);
  V v_entries_245 = heff_take_field(v_g_244, 1);
  V v_aliases_246 = heff_get_n(v_g_244, 2, 8);
  V v_k_247 = heff_get_n(v_o_243, 1, 2);
  HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_245, v_k_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_entries_245);
      heff_drop(v_aliases_246);
      heff_drop(v_k_247);
      V v_e_2411 = v_field_2410;
      V v_t_2412 = heff_get_n(v_e_2411, 1, 4);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_SU: {
        heff_take_n(v_t_2412, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SDecode: {
        V v_t_2414 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        return ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2eisTestEl(a_0)); heff_drop(v_t_2414); r_; });
      }
      case TAG_SFunction: {
        heff_take_n(v_t_2412, 0ULL, 5);
        return NTAG(TAG_False);
      }
      case TAG_SRecord: {
        heff_take_n(v_t_2412, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_SSum: {
        heff_take_n(v_t_2412, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SIsTy: {
        heff_take_n(v_t_2412, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SPrimInt: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimFloat: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimString: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimRune: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimArray: {
        heff_take_n(v_t_2412, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SFixed: {
        heff_take_n(v_t_2412, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2412);
      }
    } else {
      heff_drop(v_field_2410);
      HeffT2 v_t_2427 = ({ V a_0 = v_aliases_246; V a_1 = v_k_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_246); heff_drop(v_k_247); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2428 == ((int64_t)0ULL))) {
          V v_k2_2430 = v_field_2429;
          HeffT2 v_t_2431 = ({ V a_0 = v_entries_245; V a_1 = v_k2_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_245); heff_drop(v_k2_2430); r_; });
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              V v_e_2434 = v_field_2433;
              V v_t_2435 = heff_get_n(v_e_2434, 1, 4);
              switch (heff_tag_of(v_t_2435)) {
              case TAG_SU: {
                heff_take_n(v_t_2435, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SDecode: {
                V v_t_2437 = heff_field(v_t_2435, 0);
                heff_take_n(v_t_2435, 1ULL, 1);
                return ({ V a_0 = v_t_2437; V r_ = (g_heff_2ebuild_2edriver_2eisTestEl(a_0)); heff_drop(v_t_2437); r_; });
              }
              case TAG_SFunction: {
                heff_take_n(v_t_2435, 0ULL, 5);
                return NTAG(TAG_False);
              }
              case TAG_SRecord: {
                heff_take_n(v_t_2435, 0ULL, 3);
                return NTAG(TAG_False);
              }
              case TAG_SSum: {
                heff_take_n(v_t_2435, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SIsTy: {
                heff_take_n(v_t_2435, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SPrimInt: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimFloat: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimString: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimRune: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimArray: {
                heff_take_n(v_t_2435, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SFixed: {
                heff_take_n(v_t_2435, 0ULL, 1);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_2435);
              }
            } else {
              heff_drop(v_field_2433);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop(v_entries_245);
          heff_drop(v_field_2429);
          return NTAG(TAG_False);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2etestsOf_lam2(V self, V *args) {
  V v_t_2452 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_o_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = (g_heff_2ebuild_2edriver_2eownUses(heff_dup(v_c_240), heff_rfield(v_t_2452, 1)));
  V v_t_2454 = (g_heff_2ebuild_2edriver_2ereachOwn(v_c_240, NTAG(TAG_Nil), v_t_2453));
  V v_t_2455 = (g_list_2ekeepIf_24s1823913665x1128491553(v_t_2452, v_t_2454));
  return ({ V a_0 = v_o_2451; V a_1 = v_t_2455; V r_ = (g_list_2eany_24s108509638x1972721376(a_0, a_1)); heff_drop(v_t_2455); r_; });
}
V g_heff_2ebuild_2edriver_2etestsOf_lam1(V self, V *args) {
  V v_o_2451 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_all_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2456 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2etestsOf_lam2, 1, 2, (V[]){v_c_240, v_o_2451}); V a_1 = v_all_2450; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_all_2450); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2456) == NTAG(TAG_True)));
  heff_drop(v_x1_2456);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str11, 4, "Just");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str24, 6, "Differ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str32, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str33, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str37, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str40, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str41, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str43, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str45, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str46, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str48, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str50, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str51, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str52, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str53, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str54, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str55, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str56, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str58, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str59, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str60, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str61, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str62, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str63, 0, "");
Clo g_heff_2ebuild_2edriver_2efailureOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efailureOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2efailureOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_2414 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str7);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str8);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str9);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str10);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str11))) {
    V v_t_2428;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2418 = heff_field(v_v_240, 1);
      v_t_2428 = heff_dup(v_vs_2418);
      break;
    }
    case TAG_VInt: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2428 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2428; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_t_2448;
    {
      V v_field_2431 = v_t_2429.f[1];
      V v_field_2432 = v_t_2429.f[2];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2433 = v_field_2431;
        V v_x12_2434 = v_field_2432;
        heff_drop(v_x12_2434);
        switch (heff_tag_of(v_x_2433)) {
        case TAG_VFun: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str12);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str13);
          break;
        }
        case TAG_VTag: {
          V v_x_2437 = heff_field(v_x_2433, 0);
          heff_take_n(v_x_2433, 1ULL, 2);
          v_t_2448 = v_x_2437;
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str14);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str15);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str16);
          break;
        }
        case TAG_VStr: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str17);
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str18);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str19);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2433, 0ULL, 1);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str20);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2433, 0ULL, 2);
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str21);
          break;
        }
        case TAG_VErased: {
          v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str22);
          break;
        }
        default: heff_nomatch(v_x_2433);
        }
      } else {
        heff_drop(v_field_2431);
        heff_drop(v_field_2432);
        v_t_2448 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str23);
      }
    }
    if (heff_strEq_c(v_t_2448, ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str24))) {
      V v_t_2462;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2452 = heff_field(v_v_240, 1);
        v_t_2462 = heff_dup(v_vs_2452);
        break;
      }
      case TAG_VInt: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2462 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_2463 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2462; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2462); r_; });
      V v_t_24102;
      {
        V v_field_2465 = v_t_2463.f[1];
        V v_field_2466 = v_t_2463.f[2];
        int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
        if ((v_tag_2464 == ((int64_t)0ULL))) {
          V v_x_2467 = v_field_2465;
          V v_x12_2468 = v_field_2466;
          heff_drop(v_x12_2468);
          V v_t_2482;
          switch (heff_tag_of(v_x_2467)) {
          case TAG_VFun: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VTag: {
            V v_vs_2472 = heff_field(v_x_2467, 1);
            heff_take_n(v_x_2467, 2ULL, 2);
            v_t_2482 = v_vs_2472;
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_2467, 0ULL, 1);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_2467, 0ULL, 2);
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VErased: {
            v_t_2482 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_2467);
          }
          HeffT3 v_t_2483 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2482; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2482); r_; });
          {
            V v_field_2485 = v_t_2483.f[1];
            V v_field_2486 = v_t_2483.f[2];
            int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
            if ((v_tag_2484 == ((int64_t)0ULL))) {
              V v_x_2487 = v_field_2485;
              V v_x12_2488 = v_field_2486;
              heff_drop(v_x12_2488);
              switch (heff_tag_of(v_x_2487)) {
              case TAG_VFun: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str25);
                break;
              }
              case TAG_VCons: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str26);
                break;
              }
              case TAG_VTag: {
                heff_take_n(v_x_2487, 0ULL, 2);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str27);
                break;
              }
              case TAG_VInt: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str28);
                break;
              }
              case TAG_VFloat: {
                heff_take_na(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str29);
                break;
              }
              case TAG_VFloat32: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str30);
                break;
              }
              case TAG_VStr: {
                V v_s_2496 = heff_field(v_x_2487, 0);
                heff_take_n(v_x_2487, 1ULL, 1);
                v_t_24102 = v_s_2496;
                break;
              }
              case TAG_VRune: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str31);
                break;
              }
              case TAG_VArr: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str32);
                break;
              }
              case TAG_VBytes: {
                heff_take_n(v_x_2487, 0ULL, 1);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str33);
                break;
              }
              case TAG_VBits: {
                heff_take_n(v_x_2487, 0ULL, 2);
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str34);
                break;
              }
              case TAG_VErased: {
                v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str35);
                break;
              }
              default: heff_nomatch(v_x_2487);
              }
            } else {
              heff_drop(v_field_2485);
              heff_drop(v_field_2486);
              v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str36);
            }
          }
        } else {
          heff_drop(v_field_2465);
          heff_drop(v_field_2466);
          v_t_24102 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str37);
        }
      }
      V v_t_24116;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24106 = heff_field(v_v_240, 1);
        v_t_24116 = heff_dup(v_vs_24106);
        break;
      }
      case TAG_VInt: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24116 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_24117 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_24116; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24116); r_; });
      V v_t_24156;
      {
        V v_field_24119 = v_t_24117.f[1];
        V v_field_24120 = v_t_24117.f[2];
        int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
        if ((v_tag_24118 == ((int64_t)0ULL))) {
          V v_x_24121 = v_field_24119;
          V v_x12_24122 = v_field_24120;
          heff_drop(v_x12_24122);
          V v_t_24136;
          switch (heff_tag_of(v_x_24121)) {
          case TAG_VFun: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VTag: {
            V v_vs_24126 = heff_field(v_x_24121, 1);
            heff_take_n(v_x_24121, 2ULL, 2);
            v_t_24136 = v_vs_24126;
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_24121, 0ULL, 1);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_24121, 0ULL, 2);
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VErased: {
            v_t_24136 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_24121);
          }
          HeffT3 v_t_24137 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24136; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24136); r_; });
          {
            V v_field_24139 = v_t_24137.f[1];
            V v_field_24140 = v_t_24137.f[2];
            int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
            if ((v_tag_24138 == ((int64_t)0ULL))) {
              V v_x_24141 = v_field_24139;
              V v_x12_24142 = v_field_24140;
              heff_drop(v_x12_24142);
              switch (heff_tag_of(v_x_24141)) {
              case TAG_VFun: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str38);
                break;
              }
              case TAG_VCons: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str39);
                break;
              }
              case TAG_VTag: {
                heff_take_n(v_x_24141, 0ULL, 2);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str40);
                break;
              }
              case TAG_VInt: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str41);
                break;
              }
              case TAG_VFloat: {
                heff_take_na(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str42);
                break;
              }
              case TAG_VFloat32: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str43);
                break;
              }
              case TAG_VStr: {
                V v_s_24150 = heff_field(v_x_24141, 0);
                heff_take_n(v_x_24141, 1ULL, 1);
                v_t_24156 = v_s_24150;
                break;
              }
              case TAG_VRune: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str44);
                break;
              }
              case TAG_VArr: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str45);
                break;
              }
              case TAG_VBytes: {
                heff_take_n(v_x_24141, 0ULL, 1);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str46);
                break;
              }
              case TAG_VBits: {
                heff_take_n(v_x_24141, 0ULL, 2);
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str47);
                break;
              }
              case TAG_VErased: {
                v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str48);
                break;
              }
              default: heff_nomatch(v_x_24141);
              }
            } else {
              heff_drop(v_field_24139);
              heff_drop(v_field_24140);
              v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str49);
            }
          }
        } else {
          heff_drop(v_field_24119);
          heff_drop(v_field_24120);
          v_t_24156 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str50);
        }
      }
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_24102, v_t_24156})});
    } else {
      V v_t_24170;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24160 = heff_field(v_v_240, 1);
        v_t_24170 = heff_dup(v_vs_24160);
        break;
      }
      case TAG_VInt: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBytes: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VBits: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24170 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      HeffT3 v_t_24171 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_24170; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24170); r_; });
      V v_t_24210;
      {
        V v_field_24173 = v_t_24171.f[1];
        V v_field_24174 = v_t_24171.f[2];
        int64_t v_tag_24172 = ((int64_t)v_t_24171.f[0]);
        if ((v_tag_24172 == ((int64_t)0ULL))) {
          V v_x_24175 = v_field_24173;
          V v_x12_24176 = v_field_24174;
          heff_drop(v_x12_24176);
          V v_t_24190;
          switch (heff_tag_of(v_x_24175)) {
          case TAG_VFun: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VTag: {
            V v_vs_24180 = heff_field(v_x_24175, 1);
            heff_take_n(v_x_24175, 2ULL, 2);
            v_t_24190 = v_vs_24180;
            break;
          }
          case TAG_VInt: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat: {
            heff_take_na(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VFloat32: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VStr: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VRune: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VArr: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBytes: {
            heff_take_n(v_x_24175, 0ULL, 1);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VBits: {
            heff_take_n(v_x_24175, 0ULL, 2);
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          case TAG_VErased: {
            v_t_24190 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_x_24175);
          }
          HeffT3 v_t_24191 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_24190; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_24190); r_; });
          {
            V v_field_24193 = v_t_24191.f[1];
            V v_field_24194 = v_t_24191.f[2];
            int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
            if ((v_tag_24192 == ((int64_t)0ULL))) {
              V v_x_24195 = v_field_24193;
              V v_x12_24196 = v_field_24194;
              heff_drop(v_x12_24196);
              switch (heff_tag_of(v_x_24195)) {
              case TAG_VFun: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str51);
                break;
              }
              case TAG_VCons: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str52);
                break;
              }
              case TAG_VTag: {
                heff_take_n(v_x_24195, 0ULL, 2);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str53);
                break;
              }
              case TAG_VInt: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str54);
                break;
              }
              case TAG_VFloat: {
                heff_take_na(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str55);
                break;
              }
              case TAG_VFloat32: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str56);
                break;
              }
              case TAG_VStr: {
                V v_s_24204 = heff_field(v_x_24195, 0);
                heff_take_n(v_x_24195, 1ULL, 1);
                v_t_24210 = v_s_24204;
                break;
              }
              case TAG_VRune: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str57);
                break;
              }
              case TAG_VArr: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str58);
                break;
              }
              case TAG_VBytes: {
                heff_take_n(v_x_24195, 0ULL, 1);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str59);
                break;
              }
              case TAG_VBits: {
                heff_take_n(v_x_24195, 0ULL, 2);
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str60);
                break;
              }
              case TAG_VErased: {
                v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str61);
                break;
              }
              default: heff_nomatch(v_x_24195);
              }
            } else {
              heff_drop(v_field_24193);
              heff_drop(v_field_24194);
              v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str62);
            }
          }
        } else {
          heff_drop(v_field_24173);
          heff_drop(v_field_24174);
          v_t_24210 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str63);
        }
      }
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_t_24210})});
    }
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2efailureOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efailureOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str12, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str24, 4, "True");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str25, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str32, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str33, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str37, 4, "Just");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str40, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str41, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str43, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str45, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str46, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str48, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str49, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str50, 8, "property");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str51, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str52, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str53, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str54, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str55, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str56, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str58, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str59, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str60, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str61, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str62, 4, "True");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str63, 4, "runs");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str64, 9, "discarded");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str65, 7, "shrinks");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str66, 6, "labels");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str67, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str68, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str69, 4, "seed");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str70, 7, "goldens");
Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eoutcomeOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eoutcomeOfV(V v_v_240) {
top: ;
  V v_x1_241 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str0); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_VFun: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str1);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str2);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_241, 0ULL, 2);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str3);
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str4);
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str5);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str6);
    break;
  }
  case TAG_VStr: {
    V v_s_249 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    v_t_2415 = v_s_249;
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str7);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str8);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str9);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_241, 0ULL, 2);
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str10);
    break;
  }
  case TAG_VErased: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str11);
    break;
  }
  default: heff_nomatch(v_x1_241);
  }
  V v_x1_2416 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str12); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2430;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str13);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str14);
    break;
  }
  case TAG_VTag: {
    V v_x_2419 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 2);
    v_t_2430 = v_x_2419;
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str15);
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str16);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str17);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str18);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str19);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str20);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str21);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2416, 0ULL, 2);
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str22);
    break;
  }
  case TAG_VErased: {
    v_t_2430 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str23);
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2431 = heff_bool(heff_strEq_c_lent(v_t_2430, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str24), 2));
  heff_drop(v_t_2430);
  V v_v_2432 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str25); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2446;
  switch (heff_tag_of(v_v_2432)) {
  case TAG_VFun: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str26);
    break;
  }
  case TAG_VCons: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str27);
    break;
  }
  case TAG_VTag: {
    V v_x_2435 = heff_dup(heff_field(v_v_2432, 0));
    v_t_2446 = v_x_2435;
    break;
  }
  case TAG_VInt: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str28);
    break;
  }
  case TAG_VFloat: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str29);
    break;
  }
  case TAG_VFloat32: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str30);
    break;
  }
  case TAG_VStr: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str31);
    break;
  }
  case TAG_VRune: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str32);
    break;
  }
  case TAG_VArr: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str33);
    break;
  }
  case TAG_VBytes: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str34);
    break;
  }
  case TAG_VBits: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str35);
    break;
  }
  case TAG_VErased: {
    v_t_2446 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str36);
    break;
  }
  default: heff_nomatch(v_v_2432);
  }
  V v_t_2481;
  if (heff_strEq_c(v_t_2446, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str37))) {
    V v_t_2460;
    switch (heff_tag_of(v_v_2432)) {
    case TAG_VFun: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2450 = heff_field(v_v_2432, 1);
      heff_take_n(v_v_2432, 2ULL, 2);
      v_t_2460 = v_vs_2450;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2432, 0ULL, 1);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_v_2432, 0ULL, 2);
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2460 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_2432);
    }
    HeffT3 v_t_2461 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2460; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2460); r_; });
    V v_t_2480;
    {
      V v_field_2463 = v_t_2461.f[1];
      V v_field_2464 = v_t_2461.f[2];
      int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
      if ((v_tag_2462 == ((int64_t)0ULL))) {
        V v_x_2465 = v_field_2463;
        V v_x12_2466 = v_field_2464;
        heff_drop(v_x12_2466);
        switch (heff_tag_of(v_x_2465)) {
        case TAG_VFun: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str38);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str39);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2465, 0ULL, 2);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str40);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str41);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str42);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str43);
          break;
        }
        case TAG_VStr: {
          V v_s_2474 = heff_field(v_x_2465, 0);
          heff_take_n(v_x_2465, 1ULL, 1);
          v_t_2480 = v_s_2474;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str44);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str45);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2465, 0ULL, 1);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str46);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2465, 0ULL, 2);
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str47);
          break;
        }
        case TAG_VErased: {
          v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str48);
          break;
        }
        default: heff_nomatch(v_x_2465);
        }
      } else {
        heff_drop(v_field_2463);
        heff_drop(v_field_2464);
        v_t_2480 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str49);
      }
    }
    v_t_2481 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2480});
  } else {
    heff_drop(v_v_2432);
    v_t_2481 = NTAG(TAG_Nothing);
  }
  V v_x1_2482 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str50); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2496;
  switch (heff_tag_of(v_x1_2482)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str51);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str52);
    break;
  }
  case TAG_VTag: {
    V v_x_2485 = heff_field(v_x1_2482, 0);
    heff_take_n(v_x1_2482, 1ULL, 2);
    v_t_2496 = v_x_2485;
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str53);
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str54);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str55);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str56);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str57);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str58);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2482, 0ULL, 1);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str59);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2482, 0ULL, 2);
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str60);
    break;
  }
  case TAG_VErased: {
    v_t_2496 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str61);
    break;
  }
  default: heff_nomatch(v_x1_2482);
  }
  V v_t_2497 = heff_bool(heff_strEq_c_lent(v_t_2496, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str62), 2));
  heff_drop(v_t_2496);
  V v_x1_2498 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str63); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24112;
  switch (heff_tag_of(v_x1_2498)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2498, 0ULL, 2);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_24103 = heff_field(v_x1_2498, 0);
    heff_take_n(v_x1_2498, 1ULL, 1);
    v_t_24112 = v_i_24103;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_2498, 0ULL, 1);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_2498, 0ULL, 2);
    v_t_24112 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_24112 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2498);
  }
  V v_x1_24113 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str64); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24127;
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_VFun: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_24113, 0ULL, 2);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_24118 = heff_field(v_x1_24113, 0);
    heff_take_n(v_x1_24113, 1ULL, 1);
    v_t_24127 = v_i_24118;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_24113, 0ULL, 1);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_24113, 0ULL, 2);
    v_t_24127 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_24127 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_24113);
  }
  V v_x1_24128 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str65); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24142;
  switch (heff_tag_of(v_x1_24128)) {
  case TAG_VFun: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_24128, 0ULL, 2);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_24133 = heff_field(v_x1_24128, 0);
    heff_take_n(v_x1_24128, 1ULL, 1);
    v_t_24142 = v_i_24133;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_24128, 0ULL, 2);
    v_t_24142 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_24142 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_24128);
  }
  V v_t_24143 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str66); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24144 = ({ V a_0 = v_t_24143; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_t_24143); r_; });
  V v_t_24145 = (g_list_2emap_24s570961906x1112476114(v_t_24144));
  V v_t_24146 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str67); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24147 = ({ V a_0 = v_t_24146; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_t_24146); r_; });
  V v_t_24148 = (g_list_2emap_24s218655275x981659442(v_t_24147));
  V v_t_24149 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str68); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24150 = ({ V a_0 = v_t_24149; V r_ = (g_heff_2ebuild_2edriver_2efailureOfV(a_0)); heff_drop(v_t_24149); r_; });
  V v_x1_24151 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str69); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24165;
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_VFun: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_24151, 0ULL, 2);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_24156 = heff_field(v_x1_24151, 0);
    heff_take_n(v_x1_24151, 1ULL, 1);
    v_t_24165 = v_i_24156;
    break;
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_24151, 0ULL, 1);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VBits: {
    heff_take_n(v_x1_24151, 0ULL, 2);
    v_t_24165 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_24165 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_24151);
  }
  V v_t_24166 = ({ V a_0 = v_v_240; V b_1 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str70); V r_ = (g_heff_2ebuild_2edriver_2efieldV(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_24167 = ({ V a_0 = v_t_24166; V r_ = (g_heff_2ebuild_2edriver_2elistOfV(a_0)); heff_drop(v_t_24166); r_; });
  V v_t_24168 = (g_list_2emap_24s1517387949x485543551(v_t_24167));
  return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_t_2415, v_t_2431, v_t_2481, v_t_2497, v_t_24112, v_t_24127, v_t_24142, v_t_24145, v_t_24148, v_t_24150, v_t_24165, v_t_24168});
}
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eoutcomeOfV(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eearlierGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eearlierGo_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eearlierGo(V v_x1_240, V v_i_241, V v_x_242, V v_j_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_j_243);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_g_244, 0)), heff_dup(v_x_242))) {
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(v_j_243, v_i_241, 0));
      heff_drop(v_i_241);
      heff_drop(v_j_243);
      return v_ret_24bool;
    } else {
      V t_0 = v_rest_245;
      V t_1 = v_i_241;
      V t_2 = v_x_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_x_242 = t_2;
      v_j_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eearlierGo(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str0, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str2, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str3, 2, " (");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str4, 4, "(..)");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str7, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str8, 2, ")\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str9, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str13, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str14, 4, " as ");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str20, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str24, 1, "\012");
V g_heff_2ebuild_2edriver_2einterface_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2einterface_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2einterface_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2einterface_entry, 1, 0};

V g_heff_2ebuild_2edriver_2einterface(V v_c_240) {
top: ;
  V v_modName_241 = heff_dup(heff_rfield(v_c_240, 0));
  V v_x2_242 = heff_dup(heff_rfield(v_c_240, 13));
  V v_t_249;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2einterface_str0), v_modName_241), ((V)&g_heff_2ebuild_2edriver_2einterface_str1));
    break;
  }
  case TAG_Just: {
    V v_es_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edriver_2einterface_str2), v_modName_241), ((V)&g_heff_2ebuild_2edriver_2einterface_str3));
    V v_x2_245 = (g_list_2emap_24s1611344417x463861413(((V)&g_heff_2ebuild_2edriver_2einterface_str4), ((V)&g_heff_2ebuild_2edriver_2einterface_str5), v_es_243));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2edriver_2einterface_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    v_t_249 = heff_strAppend(heff_strAppend(v_t_244, v_t_248), ((V)&g_heff_2ebuild_2edriver_2einterface_str8));
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_c_2410 = heff_dup(v_c_240);
  V v_opens_2411 = heff_take_field(v_c_2410, 9);
  V v_aliases_2412 = heff_get_n(v_c_2410, 10, 14);
  V v_x2_2413 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ebuild_2edriver_2einterface_str9), ((V)&g_heff_2ebuild_2edriver_2einterface_str10), v_opens_2411));
  V v_t_2416;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ebuild_2edriver_2einterface_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_xs_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str12); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_x2_2417 = (g_list_2emap_24s704486313x1071100879(((V)&g_heff_2ebuild_2edriver_2einterface_str13), ((V)&g_heff_2ebuild_2edriver_2einterface_str14), ((V)&g_heff_2ebuild_2edriver_2einterface_str15), v_aliases_2412));
  V v_t_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ebuild_2edriver_2einterface_str16);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str17); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = heff_strAppend(v_t_2416, v_t_2420);
  V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_c_240, 11)), 0, 2);
  V v_t_2423 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 11)); V a_1 = MK_INT(0LL); V a_2 = v_t_2422; V r_ = (g_heff_2ebuild_2edriver_2efixityLines(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
  V v_t_2424 = heff_rec_n(3, shape_out__multi__first, (V[]){((V)&g_heff_2ebuild_2edriver_2einterface_str18), NTAG(TAG_False), NTAG(TAG_True)});
  V v_t_2425 = (g_heff_2ebuild_2edriver_2eexposedIn(heff_rfield(v_c_240, 13), heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2436 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2einterface_lam0, 1, 1, (V[]){v_c_240}), v_t_2425));
  V v_t_2437 = ({ V a_0 = v_t_2424; V a_1 = v_t_2436; V r_ = (g_list_2efoldl_24f139246788x401086883(a_0, a_1)); heff_drop(v_t_2436); r_; });
  V v_t_2438 = heff_get_n(v_t_2437, 0, 3);
  if (!heff_strEq_c_lent(v_t_249, ((V)&g_heff_2ebuild_2edriver_2einterface_str19), 2)) {
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2439})});
    return ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str20); V a_1 = v_t_249; V b_2 = ((V)&g_heff_2ebuild_2edriver_2einterface_str21); V a_3 = v_t_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f1693511458x1129846322(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop_tag(v_t_2440, 2); r_; });
  } else {
    heff_drop(v_t_249);
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2441})});
    V v_x2_2443 = ({ V b_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str22); V a_1 = v_t_2442; V r_ = (g_list_2ekeepIf_24s930188071x496633547(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2edriver_2einterface_str23);
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str24); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
    }
    default: return heff_nomatch(v_x2_2443);
    }
  }
}
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2einterface(a[0]);
}
V g_heff_2ebuild_2edriver_2einterface_lam1(V self, V *args) {
  V v_k_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2431 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_2430)));
  HeffT2 v_t_2432 = ({ V a_0 = v_m_2429; V a_1 = v_k_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_2429); heff_drop(v_k_2430); r_; });
  {
    V v_field_2434 = v_t_2432.f[1];
    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
    if ((v_tag_2433 == ((int64_t)0ULL))) {
      heff_drop(v_d_2431);
      V v_x_2435 = v_field_2434;
      return v_x_2435;
    } else {
      heff_drop(v_field_2434);
      return v_d_2431;
    }
  }
}
V g_heff_2ebuild_2edriver_2einterface_lam0(V self, V *args) {
  V v_o_2426 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_t_2428 = ({ V b_0 = heff_get_n(v_t_2427, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_2429 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2428; V r_ = (g_list_2efoldl_24s1468236620x1316701813(a_0, a_1)); heff_drop(v_t_2428); r_; });
  return (g_heff_2ebuild_2edriver_2esigEntry(v_c_240, heff_clo_n(g_heff_2ebuild_2edriver_2einterface_lam1, 1, 1, (V[]){v_m_2429}), v_o_2426));
}

HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V v_c_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 10);
  V v_entries_243 = heff_take_field(v_g_242, 1);
  V v_aliases_244 = heff_get_n(v_g_242, 2, 8);
  HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_243, v_k_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_entries_243);
      heff_drop(v_aliases_244);
      V v_e_248 = v_field_247;
      V v_t_249 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 10);
      V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_248, 3, 4)));
      return ({ V a_0 = v_t_249; V a_1 = v_t_2410; HeffT2 r_ = (g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
    } else {
      heff_drop(v_field_247);
      HeffT2 v_t_2411 = ({ V a_0 = v_aliases_244; V a_1 = v_k_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_244); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_k2_2414 = v_field_2413;
          HeffT2 v_t_2415 = ({ V a_0 = v_entries_243; V a_1 = v_k2_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_243); heff_drop(v_k2_2414); r_; });
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              V v_e_2418 = v_field_2417;
              V v_t_2419 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 10);
              V v_t_2420 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2418, 3, 4)));
              return ({ V a_0 = v_t_2419; V a_1 = v_t_2420; HeffT2 r_ = (g_heff_2eelab_2eeffect_2ecomputationEffect_24cpr(a_0, a_1)); heff_drop(v_t_2420); r_; });
            } else {
              heff_drop_rec(v_c_240, 14);
              heff_drop(v_field_2417);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop_rec(v_c_240, 14);
          heff_drop(v_entries_243);
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str2, 16, " has the effect ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_24cpr_str3, 142, ", which is not provided here (a module M provides its effect in M.provider.js, or M.provider.c for C, beside M.hf; `$host` says where it runs)");
V g_heff_2ebuild_2edriver_2efits_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2edriver_2efits_24cpr(V v_handled_240, V v_r_241) {
top: ;
  V v_effect_242 = heff_take_field(v_r_241, 2);
  V v_key_243 = heff_take_field(v_r_241, 1);
  V v_name_244 = heff_get_n(v_r_241, 0, 3);
  V v_t_245 = (g_heff_2eelab_2eeffect_2eleaves(v_effect_242));
  V v_t_249 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2edriver_2efits_24cpr_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), v_t_245));
  V v_ms_2410 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_249));
  switch (heff_tag_of(v_ms_2410)) {
  case TAG_Nil: {
    heff_drop(v_name_244);
    V v_f_2411 = heff_rec_n(2, shape_key__effect, (V[]){v_key_243, v_effect_242});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2411}});
  }
  case TAG_Cons: {
    heff_drop(v_effect_242);
    heff_drop(v_key_243);
    V v_t_2416;
    switch (heff_tag_of(v_ms_2410)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_ms_2410, 0);
      V v_xs_2415 = heff_field(v_ms_2410, 1);
      heff_take_n(v_ms_2410, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_ms_2410);
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(v_name_244, ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str2)), v_t_2416);
    V v_f_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2edriver_2efits_24cpr_str3));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
  }
  default: return ((HeffT2){{heff_nomatch(v_ms_2410)}});
  }
}
V g_heff_2ebuild_2edriver_2efits_24cpr_lam0(V self, V *args) {
  V v_l_246 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_l_246}));
  V v_x1_248 = ({ V a_0 = v_t_247; V a_1 = v_handled_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
Clo g_heff_2ebuild_2edriver_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efits_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efits(V v_handled_240, V v_r_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edriver_2efits_24cpr(v_handled_240, v_r_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_244});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_244});
    }
  }
}
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efits(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2erefusedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2erefusedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2erefusedIn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2erefusedIn(V v_rs_240, V v_s_241) {
top: ;
  V v_library_242 = heff_take_field(v_s_241, 7);
  V v_renames_243 = heff_take_field(v_s_241, 5);
  V v_implicit_244 = heff_take_field(v_s_241, 6);
  V v_source_245 = heff_get_n(v_s_241, 4, 8);
  if ((heff_dup(v_library_242) == NTAG(TAG_True))) {
    heff_drop(v_library_242);
    heff_drop(v_renames_243);
    heff_drop(v_implicit_244);
    heff_drop(v_source_245);
    return NTAG(TAG_Nil);
  } else {
    heff_drop(v_library_242);
    V v_t_246 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_244, v_source_245));
    HeffT4 v_t_247 = ({ V a_0 = v_renames_243; V a_1 = v_t_246; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_243); r_; });
    V v_t_2412;
    {
      V v_field_248 = v_t_247.f[0];
      heff_drop(v_t_247.f[1]);
      heff_drop(v_t_247.f[2]);
      heff_drop(v_t_247.f[3]);
      v_t_2412 = v_field_248;
    }
    V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2erefusedIn_lam0, 1, 1, (V[]){heff_dup(v_rs_240)}), v_t_2412));
    return (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2422));
  }
}
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2erefusedIn(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2erefusedIn_lam0(V self, V *args) {
  V v_i_2413 = args[0];
  V v_rs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2414 = ({ V a_0 = heff_dup(v_i_2413); V a_1 = v_rs_240; HeffT2 r_ = (g_list_2efind_24s582717128x15493447_24cpr(a_0, a_1)); heff_drop(v_rs_240); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_r_2417 = v_field_2416;
      V v_code_2418 = heff_take_field(v_r_2417, 1);
      V v_msg_2419 = heff_take_field(v_r_2417, 2);
      V v_note_2420 = heff_get_n(v_r_2417, 3, 4);
      V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){v_code_2418, NTAG(TAG_SError), v_msg_2419, heff_get_n(v_i_2413, 2, 3), v_note_2420});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
    } else {
      heff_drop_rec(v_i_2413, 3);
      heff_drop(v_field_2416);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eappendLv_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendLv_24tok2_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eappendLv_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2ebuild_2edriver_2eappendLv_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2edriver_2eappendLv_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendLv_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_str1, 1, ".");
Clo g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(V v_tok_240, V v_s_241, V v_imps_242, V v_th_243, V v_t_244) {
top: ;
  V v_claim_245 = heff_take_field(v_imps_242, 2);
  V v_imports_246 = heff_take_field(v_imps_242, 0);
  V v_implicit_247 = heff_get_n(v_imps_242, 1, 4);
  V v_shown_248 = heff_take_field(v_s_241, 3);
  V v_source_249 = heff_take_field(v_s_241, 4);
  V v_module_2410 = heff_take_field(v_s_241, 0);
  V v_path_2411 = heff_get_n(v_s_241, 2, 8);
  V v_shown_2412 = v_shown_248;
  V v_source_2413 = v_source_249;
  V v_t_2417;
  switch (heff_tag_of(v_claim_245)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 1);
    v_t_2417 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2414 = heff_dup(heff_field(v_claim_245, 0));
    V v_listed_2415 = heff_take_field(v_h_2414, 1);
    V v_exposes_2416 = heff_get_n(v_h_2414, 2, 5);
    if ((heff_dup(v_listed_2415) == NTAG(TAG_True))) {
      heff_drop(v_listed_2415);
      v_t_2417 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_exposes_2416});
    } else {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_listed_2415);
      heff_drop(v_exposes_2416);
      v_t_2417 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_claim_245);
  }
  V v_t_2418 = ({ V a_0 = heff_dup(v_module_2410); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_244, 2)); V r_ = (g_list_2emap_24s262223576x596329185(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_2419 = ({ V a_0 = v_t_2417; V a_1 = v_t_2418; V r_ = (g_heff_2ebuild_2edriver_2eexposedIn(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_top_2420 = (g_heff_2ebuild_2edriver_2ewithStruct(heff_dup(v_module_2410), v_t_2419, heff_dup(v_t_244)));
  V v_own_2421 = ({ V a_0 = heff_dup(v_module_2410); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_get_n(v_t_244, 2, 10); V r_ = (g_list_2emap_24s262223576x596329185(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_2422 = (g_list_2emap_24s1817208647x1282894070(heff_dup(v_imports_246)));
  V v_deps_2423 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2422));
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_implicit_247));
  V v_t_2425 = (g_list_2edrop(v_t_2424, v_imports_246));
  V v_opens_2426 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2425));
  V v_t_2427 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_implicit_247; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_implicit_247); r_; });
  V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_imports_246; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_imports_246); r_; });
  V v_aliases_2429 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_2428));
  V v_t_2433;
  switch (heff_tag_of(v_claim_245)) {
  case TAG_Nothing: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2430 = heff_field(v_claim_245, 0);
    V v_ru_24claim_245_24Just = heff_take_reuse_n(v_claim_245, 1ULL, 1);
    V v_listed_2431 = heff_take_field(v_h_2430, 1);
    V v_exposes_2432 = heff_get_n(v_h_2430, 2, 5);
    if ((heff_dup(v_listed_2431) == NTAG(TAG_True))) {
      heff_drop(v_listed_2431);
      v_t_2433 = heff_tag_at_n(v_ru_24claim_245_24Just, TAG_Just, 1, (V[]){v_exposes_2432});
    } else {
      heff_drop_cell(v_ru_24claim_245_24Just, 1);
      heff_drop(v_listed_2431);
      heff_drop(v_exposes_2432);
      v_t_2433 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_claim_245);
  }
  return heff_rec_n(14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, (V[]){v_module_2410, v_path_2411, v_shown_2412, v_source_2413, NTAG(TAG_Nil), v_top_2420, NTAG(TAG_Nil), v_own_2421, v_deps_2423, v_opens_2426, v_aliases_2429, heff_get_n(v_th_243, 0, 3), NTAG(TAG_True), v_t_2433});
}
V g_heff_2ebuild_2edriver_2ethawedChecked_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ethawedChecked_24tok1(a[0], a[1], a[2], a[3], a[4]);
}