// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_Dirs 41877
#define TAG_DirsOnly 64835
#define TAG_Files 59123
#define TAG_FilesBy 64286
#define TAG_Many 40086
#define TAG_None 17785
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Some 35658
#define TAG_Words 20643
#define LBL_arity 294440695
#define LBL_complete 145693389
#define LBL_count 296209705
#define LBL_flags 298871457
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_repeated 308357578
#define LBL_values 1123329101
#define LBL_waiting 1348170899
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
V g_list_2eany_24s442143688x2133738513(V, V);
V g_list_2eany_24s442143688x2133738513_entry(V self, V *a);
extern Clo g_list_2eany_24s442143688x2133738513_clo;
V g_list_2ekeepIf_24f1278780364x1365377410(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_clo;
V g_list_2ekeepIf_24s1419960935x1367201220(V, V, V);
V g_list_2ekeepIf_24s1419960935x1367201220_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1419960935x1367201220_clo;
V g_list_2emap_24f1141799624x1826918381(V, V, V);
V g_list_2emap_24f1141799624x1826918381_entry(V self, V *a);
extern Clo g_list_2emap_24f1141799624x1826918381_clo;
V g_std_2ecli_2ecomplete_2ecompleteAt_241(V, V, V);
V g_std_2ecli_2ecomplete_2ecompleteAt_241_entry(V self, V *a);
extern Clo g_std_2ecli_2ecomplete_2ecompleteAt_241_clo;
HeffT2 g_std_2ecli_2ecomplete_2eposAt_240_24cpr(V, V);
V g_std_2ecli_2ecomplete_2ewhereGo_242(V, V, V, V);
V g_std_2ecli_2ecomplete_2ewhereGo_242_entry(V self, V *a);
extern Clo g_std_2ecli_2ecomplete_2ewhereGo_242_clo;
HeffT2 g_std_2ecli_2elongNamed_24cpr(V, V);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
V g_std_2ecli_2eshortWhere(V, V, V);
V g_std_2ecli_2eshortWhere_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_clo;

HeffT2 g_std_2ecli_2ecomplete_2eposAt_240_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_dup(heff_rfield(v_p_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_p_242)}});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Optional: {
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_p_242)}});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Many: {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_p_242)}});
    }
    case TAG_Some: {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_p_242)}});
    }
    case TAG_Rest: {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_p_242)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2ecli_2ecomplete_2ewhereGo_242_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ecomplete_2ewhereGo_242_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2ecomplete_2ewhereGo_242_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2ecomplete_2ewhereGo_242_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecomplete_2ewhereGo_242_str4, 0, "");
Clo g_std_2ecli_2ecomplete_2ewhereGo_242_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecomplete_2ewhereGo_242_entry, 4, 0};

V g_std_2ecli_2ecomplete_2ewhereGo_242(V v_sh_240, V v_ra_241, V v_st_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_sh_240);
    heff_drop(v_ra_241);
    return v_st_242;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ws_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_st_242, 1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      if (((heff_dup(heff_rfield(v_st_242, 0)) == NTAG(TAG_True)) ? (heff_intLe_c_lent(MK_INT(0LL), v_ra_241, 1) && heff_intLe_c(heff_dup(v_ra_241), heff_dup(heff_rfield(v_st_242, 2)))) : 1)) {
        heff_drop(v_x31_244);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        V v_t_247 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
        V v_t_248 = ({ V rv_0 = NTAG(TAG_False); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        V t_0 = v_sh_240;
        V t_1 = v_ra_241;
        V t_2 = v_t_248;
        V t_3 = v_ws_245;
        v_sh_240 = t_0;
        v_ra_241 = t_1;
        v_st_242 = t_2;
        v_x3_243 = t_3;
        goto top;
      } else {
        if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ecomplete_2ewhereGo_242_str0), 2)) {
          heff_drop(v_x31_244);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          V v_t_249 = ({ V rv_0 = NTAG(TAG_False); V rv_1 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_242, 12ULL, 4, shape_on__waiting__count__given, 240u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          V t_0 = v_sh_240;
          V t_1 = v_ra_241;
          V t_2 = v_t_249;
          V t_3 = v_ws_245;
          v_sh_240 = t_0;
          v_ra_241 = t_1;
          v_st_242 = t_2;
          v_x3_243 = t_3;
          goto top;
        } else {
          if (heff_strEq_c(heff_strSlice_lent(v_x31_244, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ecomplete_2ewhereGo_242_str1))) {
            V v_t_2410 = heff_strSlice(heff_dup(v_x31_244), MK_INT(2LL), heff_strLength_lent(v_x31_244, 0));
            HeffT2 v_t_2411 = ({ V a_0 = heff_dup(v_sh_240); V a_1 = v_t_2410; HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                V v_x_2414 = v_field_2413;
                heff_drop(v_x_2414);
                V v_j_2415 = heff_strFind_lent(((V)&g_std_2ecli_2ecomplete_2ewhereGo_242_str2), v_x31_244, MK_INT(0LL), 5);
                if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
                  heff_drop(v_x31_244);
                  heff_drop_cell(v_ru_24x3_243_24Cons, 2);
                  heff_drop(v_j_2415);
                  V t_0 = v_sh_240;
                  V t_1 = v_ra_241;
                  V t_2 = v_st_242;
                  V t_3 = v_ws_245;
                  v_sh_240 = t_0;
                  v_ra_241 = t_1;
                  v_st_242 = t_2;
                  v_x3_243 = t_3;
                  goto top;
                } else {
                  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_sh_240); V b_1 = heff_strSlice(v_x31_244, MK_INT(2LL), v_j_2415); HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
                  V v_t_2421;
                  {
                    V v_field_2418 = v_t_2416.f[1];
                    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                    if ((v_tag_2417 == ((int64_t)0ULL))) {
                      V v_x_2419 = v_field_2418;
                      heff_drop(v_x_2419);
                      v_t_2421 = ((V)&g_std_2ecli_2ecomplete_2ewhereGo_242_str3);
                    } else {
                      V v_f_2420 = v_field_2418;
                      v_t_2421 = heff_get_n(v_f_2420, 0, 8);
                    }
                  }
                  V v_t_2422 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_dup(heff_rfield(v_st_242, 3))});
                  V v_t_2423 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_3 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_st_242, 4ULL, 4, shape_on__waiting__count__given, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
                  V t_0 = v_sh_240;
                  V t_1 = v_ra_241;
                  V t_2 = v_t_2423;
                  V t_3 = v_ws_245;
                  v_sh_240 = t_0;
                  v_ra_241 = t_1;
                  v_st_242 = t_2;
                  v_x3_243 = t_3;
                  goto top;
                }
              } else {
                heff_drop(v_x31_244);
                V v_f_2424 = v_field_2413;
                V v_t_2425;
                if (heff_strEq_c(heff_dup(heff_rfield(v_f_2424, 2)), ((V)&g_std_2ecli_2ecomplete_2ewhereGo_242_str4))) {
                  v_t_2425 = NTAG(TAG_Nothing);
                } else {
                  v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2424)});
                }
                V v_t_2426 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_2424, 0, 8), heff_dup(heff_rfield(v_st_242, 3))});
                V v_t_2427 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = v_t_2425; V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_242, 4ULL, 4, shape_on__waiting__count__given, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2427;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x3_243 = t_3;
                goto top;
              }
            }
          } else {
            heff_drop_cell(v_ru_24x3_243_24Cons, 2);
            if (((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x31_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_x31_244, MK_INT(0LL), 2)) == ((int64_t)45ULL)))) {
              V v_t_2428 = heff_strSlice(heff_dup(v_x31_244), MK_INT(1LL), heff_strLength(v_x31_244));
              V v_t_2429 = (g_std_2ecli_2eshortWhere(heff_dup(v_sh_240), v_st_242, v_t_2428));
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2429;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x3_243 = t_3;
              goto top;
            } else {
              heff_drop(v_x31_244);
              V v_t_2430 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
              V v_t_2431 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2431;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x3_243 = t_3;
              goto top;
            }
          }
        }
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x31_244);
      heff_drop_cell(v_ru_24x3_243_24Cons, 2);
      V v_t_2433 = ({ V rv_1 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_242, 13ULL, 4, shape_on__waiting__count__given, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V t_0 = v_sh_240;
      V t_1 = v_ra_241;
      V t_2 = v_t_2433;
      V t_3 = v_ws_245;
      v_sh_240 = t_0;
      v_ra_241 = t_1;
      v_st_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_std_2ecli_2ecomplete_2ewhereGo_242_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecomplete_2ewhereGo_242(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2ecli_2ecomplete_2ecompleteAt_241_str0, 1, "-");
HEFF_LIT(g_std_2ecli_2ecomplete_2ecompleteAt_241_str1, 1, "=");
HEFF_LIT(g_std_2ecli_2ecomplete_2ecompleteAt_241_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2ecomplete_2ecompleteAt_241_str3, 6, "--help");
HEFF_LIT(g_std_2ecli_2ecomplete_2ecompleteAt_241_str4, 6, "--help");
V g_std_2ecli_2ecomplete_2ecompleteAt_241_lam0(V self, V *args);
Clo g_std_2ecli_2ecomplete_2ecompleteAt_241_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecomplete_2ecompleteAt_241_entry, 3, 0};

V g_std_2ecli_2ecomplete_2ecompleteAt_241(V v_sh_240, V v_cur_241, V v_st_242) {
top: ;
  V v_waiting_243 = heff_take_field(v_st_242, 1);
  V v_on_244 = heff_take_field(v_st_242, 0);
  V v_count_245 = heff_take_field(v_st_242, 2);
  V v_given_246 = heff_get_n(v_st_242, 3, 4);
  switch (heff_tag_of(v_waiting_243)) {
  case TAG_Nothing: {
    if (((heff_dup(v_on_244) == NTAG(TAG_True)) && ({ V v_x_247 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL))); int c_ = ((heff_intLe_c_lent(MK_INT(0LL), v_x_247, 1) ? ({ V v_y_248 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL))); int c_ = !heff_intLe_c_lent(v_y_248, v_count_245, 0); heff_drop(v_y_248); c_; }) : 1) && heff_strEq_c(heff_strSlice_lent(v_cur_241, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2ecli_2ecomplete_2ecompleteAt_241_str0))); heff_drop(v_x_247); c_; }))) {
      heff_drop(v_on_244);
      heff_drop(v_count_245);
      V v_j_249 = heff_strFind_lent(((V)&g_std_2ecli_2ecomplete_2ecompleteAt_241_str1), v_cur_241, MK_INT(0LL), 5);
      if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
        heff_drop(v_j_249);
        V v_t_2413 = (g_list_2emap_24f1141799624x1826918381(((V)&g_std_2ecli_2ecomplete_2ecompleteAt_241_str2), heff_clo_n(g_std_2ecli_2ecomplete_2ecompleteAt_241_lam0, 1, 1, (V[]){v_given_246}), heff_get_n(v_sh_240, 0, 2)));
        V v_t_2414 = heff_strSlice(((V)&g_std_2ecli_2ecomplete_2ecompleteAt_241_str3), MK_INT(0LL), heff_strLength_lent(v_cur_241, 0));
        V v_t_2416;
        if (heff_strEq_c_lent(v_t_2414, v_cur_241, 1)) {
          V v_t_2415 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_t_2413; V r_ = (g_list_2ekeepIf_24s1419960935x1367201220(b_0, a_1, a_2)); heff_drop(b_0); r_; });
          v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ecomplete_2ecompleteAt_241_str4), v_t_2415});
        } else {
          v_t_2416 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_t_2413; V r_ = (g_list_2ekeepIf_24s1419960935x1367201220(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        }
        return heff_tag_n(TAG_Words, 1, (V[]){v_t_2416});
      } else {
        heff_drop(v_given_246);
        HeffT2 v_t_2417 = ({ V a_0 = v_sh_240; V b_1 = heff_strSlice_lent(v_cur_241, MK_INT(2LL), v_j_249, 2); HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            heff_drop(v_j_249);
            V v_x_2420 = v_field_2419;
            heff_drop(v_x_2420);
            return NTAG(TAG_Nothing);
          } else {
            V v_f_2421 = v_field_2419;
            V v_t_2422 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_cur_241; V b_3 = MK_INT(0LL); V a_4 = v_j_249; V a_5 = MK_INT(1LL); V a_6 = heff_get_n(v_f_2421, 4, 8); V r_ = (g_list_2ekeepIf_24f1278780364x1365377410(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_3); r_; });
            return heff_tag_n(TAG_Words, 1, (V[]){v_t_2422});
          }
        }
      }
    } else {
      heff_drop(v_on_244);
      heff_drop(v_given_246);
      HeffT2 v_t_2423 = ({ V b_0 = heff_get_n(v_sh_240, 1, 2); V a_1 = v_count_245; HeffT2 r_ = (g_std_2ecli_2ecomplete_2eposAt_240_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_p_2426 = v_field_2425;
          V v_t_2427 = heff_get_n(v_p_2426, 2, 3);
          switch (heff_tag_of(v_t_2427)) {
          case TAG_None: {
            return NTAG(TAG_Nothing);
          }
          case TAG_Files: {
            V v_sfx_2428 = heff_field(v_t_2427, 0);
            V v_ru_24t_2427_24Files = heff_take_reuse_n(v_t_2427, 1ULL, 1);
            return heff_tag_at_n(v_ru_24t_2427_24Files, TAG_FilesBy, 1, (V[]){v_sfx_2428});
          }
          case TAG_Dirs: {
            return NTAG(TAG_DirsOnly);
          }
          case TAG_Among: {
            V v_ws_2429 = heff_field(v_t_2427, 0);
            V v_ru_24t_2427_24Among = heff_take_reuse_n(v_t_2427, 1ULL, 1);
            V v_t_2430 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_ws_2429; V r_ = (g_list_2ekeepIf_24s1419960935x1367201220(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            return heff_tag_at_n(v_ru_24t_2427_24Among, TAG_Words, 1, (V[]){v_t_2430});
          }
          default: return heff_nomatch(v_t_2427);
          }
        } else {
          heff_drop(v_field_2425);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
  case TAG_Just: {
    V v_waiting1_2431 = heff_field(v_waiting_243, 0);
    V v_ru_24waiting_243_24Just = heff_take_reuse_n(v_waiting_243, 1ULL, 1);
    heff_drop_rec(v_sh_240, 2);
    heff_drop(v_on_244);
    heff_drop(v_count_245);
    heff_drop(v_given_246);
    V v_values_2432 = heff_take_field(v_waiting1_2431, 4);
    V v_complete_2433 = heff_get_n(v_waiting1_2431, 7, 8);
    switch (heff_tag_of(v_values_2432)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_complete_2433)) {
      case TAG_None: {
        heff_drop_cell(v_ru_24waiting_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Files: {
        V v_sfx_2434 = heff_field(v_complete_2433, 0);
        heff_take_n(v_complete_2433, 1ULL, 1);
        return heff_tag_at_n(v_ru_24waiting_243_24Just, TAG_FilesBy, 1, (V[]){v_sfx_2434});
      }
      case TAG_Dirs: {
        heff_drop_cell(v_ru_24waiting_243_24Just, 1);
        return NTAG(TAG_DirsOnly);
      }
      case TAG_Among: {
        V v_ws_2435 = heff_field(v_complete_2433, 0);
        heff_take_n(v_complete_2433, 1ULL, 1);
        V v_t_2436 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_ws_2435; V r_ = (g_list_2ekeepIf_24s1419960935x1367201220(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        return heff_tag_at_n(v_ru_24waiting_243_24Just, TAG_Words, 1, (V[]){v_t_2436});
      }
      default: return heff_nomatch(v_complete_2433);
      }
    }
    case TAG_Cons: {
      heff_drop(v_complete_2433);
      V v_t_2439 = ({ V b_0 = MK_INT(0LL); V a_1 = v_cur_241; V a_2 = v_values_2432; V r_ = (g_list_2ekeepIf_24s1419960935x1367201220(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      return heff_tag_at_n(v_ru_24waiting_243_24Just, TAG_Words, 1, (V[]){v_t_2439});
    }
    default: return heff_nomatch(v_values_2432);
    }
  }
  default: return heff_nomatch(v_waiting_243);
  }
}
V g_std_2ecli_2ecomplete_2ecompleteAt_241_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecomplete_2ecompleteAt_241(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_std_2ecli_2ecomplete_2ecompleteAt_241_lam0(V self, V *args) {
  V v_f_2410 = args[0];
  V v_given_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_dup(heff_rfield(v_f_2410, 5));
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop_rec(v_f_2410, 8);
    heff_drop(v_given_246);
    heff_drop(v_t_2411);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2411);
    V v_x1_2412 = ({ V a_0 = v_f_2410; V a_1 = v_given_246; V r_ = (g_list_2eany_24s442143688x2133738513(a_0, a_1)); heff_drop(v_given_246); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
    heff_drop(v_x1_2412);
    return v_ret_24bool;
  }
}