// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_MkPath 49630
V g_heff_2eutil_2ehostpath_2eisUnder(V, V, V);
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2eisUnder_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT4 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2eutil_2ehostpath_2enormalize_str0, 2, "..");
HEFF_LIT(g_heff_2eutil_2ehostpath_2enormalize_str1, 2, "..");
HEFF_LIT(g_heff_2eutil_2ehostpath_2enormalize_str2, 2, "..");
HEFF_LIT(g_heff_2eutil_2ehostpath_2enormalize_str3, 2, "..");
Clo g_heff_2eutil_2ehostpath_2enormalize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ehostpath_2enormalize_entry, 2, 0};

V g_heff_2eutil_2ehostpath_2enormalize(V v_st_240, V v_s_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_d_246 = v_field_243;
    V v_a_247 = v_field_244;
    V v_xs_248 = v_field_245;
    V v_xs_249 = (g_list_2efoldl_24s680990791x1764841948(((V)&g_heff_2eutil_2ehostpath_2enormalize_str0), v_a_247, ((V)&g_heff_2eutil_2ehostpath_2enormalize_str1), ((V)&g_heff_2eutil_2ehostpath_2enormalize_str2), ((V)&g_heff_2eutil_2ehostpath_2enormalize_str3), NTAG(TAG_Nil), v_xs_248));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
    V v_t_2411 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_246, v_a_247, v_t_2410});
    return ({ V a_0 = v_st_240; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop_tag(v_t_2411, 3); r_; });
  }
}
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ehostpath_2enormalize(a[0], a[1]);
}
HEFF_LIT(g_heff_2eutil_2ehostpath_2eisUnder_str0, 2, "..");
Clo g_heff_2eutil_2ehostpath_2eisUnder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ehostpath_2eisUnder_entry, 3, 0};

V g_heff_2eutil_2ehostpath_2eisUnder(V v_st_240, V v_dir_241, V v_s_242) {
top: ;
  V v_dir_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
  V v_p_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_s_242));
  HeffT4 v_t_245 = (g_std_2epath_2erelative_24cpr(v_st_240, v_dir_243, v_p_244));
  {
    V v_field_247 = v_t_245.f[1];
    V v_field_248 = v_t_245.f[2];
    V v_field_249 = v_t_245.f[3];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x11_2410 = v_field_247;
      heff_drop(v_x11_2410);
      V v_x12_2411 = v_field_248;
      heff_drop(v_x12_2411);
      V v_xs_2412 = v_field_249;
      V v_t_2413 = v_xs_2412;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nil: {
        return NTAG(TAG_True);
      }
      case TAG_Cons: {
        V v_x11_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 2);
        V v_ret_24bool = heff_bool(!heff_strEq_c_lent(v_x11_2414, ((V)&g_heff_2eutil_2ehostpath_2eisUnder_str0), 2));
        heff_drop(v_x11_2414);
        return v_ret_24bool;
      }
      default: return heff_nomatch(v_t_2413);
      }
    } else {
      heff_drop(v_field_247);
      heff_drop(v_field_248);
      heff_drop(v_field_249);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ehostpath_2eisUnder(a[0], a[1], a[2]);
}