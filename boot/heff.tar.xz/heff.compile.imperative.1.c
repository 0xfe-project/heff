// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_body 9524841
#define LBL_cond 9554921
#define LBL_count 296209705
#define LBL_full 9650006
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_setTo 310686359
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_underLam 296337946
#define LBL_val 326043
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
static uint32_t shape_val__op__cond__sts__tl[] = {LBL_val, LBL_op, LBL_cond, LBL_sts, LBL_tl};
V g_heff_2ecompile_2eimperative_2eallL(V, V);
V g_heff_2ecompile_2eimperative_2eallL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eallL_clo;
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(V);
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_clo;
V g_heff_2ecompile_2eimperative_2earmNamed(V, V);
V g_heff_2ecompile_2eimperative_2earmNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2earmNamed_clo;
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo;
V g_heff_2ecompile_2eimperative_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo;
V g_heff_2ecompile_2eimperative_2econdIf(V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_clo;
V g_heff_2ecompile_2eimperative_2econdIf_24dps(V, V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2edeclBefore(V, V);
V g_heff_2ecompile_2eimperative_2edeclBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclBefore_clo;
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclBefore_24dps_clo;
V g_heff_2ecompile_2eimperative_2edefOf(V, V, V);
V g_heff_2ecompile_2eimperative_2edefOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edefOf_clo;
V g_heff_2ecompile_2eimperative_2efirstNamesTl(V);
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo;
V g_heff_2ecompile_2eimperative_2eisRelCall(V);
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchSet_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2eopTail(V, V);
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopTail_clo;
V g_heff_2ecompile_2eimperative_2epartsCond(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsSt(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsSt_clo;
V g_heff_2ecompile_2eimperative_2epartsTl(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
V g_heff_2ecompile_2eimperative_2erelPrims_get(void);
V g_heff_2ecompile_2eimperative_2esimpleOf(V, V);
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo;
V g_heff_2ecompile_2eimperative_2esinkTest(V, V, V);
V g_heff_2ecompile_2eimperative_2esinkTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esinkTest_clo;
V g_heff_2ecompile_2eimperative_2etailOf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailOf_clo;
V g_heff_2ecompile_2eimperative_2etailSelf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailSelf_clo;
V g_heff_2ecompile_2eimperative_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etestTail_clo;
V g_heff_2ecompile_2eimperative_2etoDest(V, V, V);
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etoDest_clo;
V g_heff_2ecompile_2eimperative_2etraverseN(V, V);
V g_heff_2ecompile_2eimperative_2etraverseN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etraverseN_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1299324685x840794767(V, V);
V g_list_2efoldl_24s1299324685x840794767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1299324685x840794767_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2eimperative_2etraverseN_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2etraverseN_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etraverseN_lam0, 1, 0};
V g_heff_2ecompile_2eimperative_2etraverseN_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etraverseN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etraverseN_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2etraverseN(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eimperative_2etraverseN_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etraverseN_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2etraverseN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etraverseN(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2etraverseN_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2eimperative_2etraverseN_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eimperative_2etraverseN(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2eimperative_2eallL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eallL_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eallL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eallL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2eallL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eimperative_2eisSimple_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisSimple_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisSimple(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(v_fs_2410);
  }
  case TAG_EProj: {
    V v_e_2412 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2417 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2eimperative_2eallL(((V)&g_heff_2ecompile_2eimperative_2eisSimple_clo), v_as_2417));
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_x1_240, 0);
    V v_as_2423 = heff_field(v_x1_240, 1);
    V v_x1_2424 = ({ V a_0 = heff_dup(v_p_2422); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2424) == NTAG(TAG_True))) {
      heff_drop(v_x1_2424);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2424);
      return (g_heff_2ecompile_2eimperative_2eallL(((V)&g_heff_2ecompile_2eimperative_2eisSimple_clo), v_as_2423));
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisSimple(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str0, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str1, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str2, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str3, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str4, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str5, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str6, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str7, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str8, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str9, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str10, 5, "intLt");

static V g_heff_2ecompile_2eimperative_2erelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2erelPrims_st;
static V g_heff_2ecompile_2eimperative_2erelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str10), v_t_244})});
}
V g_heff_2ecompile_2eimperative_2erelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2erelPrims_st)) return g_heff_2ecompile_2eimperative_2erelPrims_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2erelPrims_val, &g_heff_2ecompile_2eimperative_2erelPrims_st, g_heff_2ecompile_2eimperative_2erelPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_str3, 5, "False");
V g_heff_2ecompile_2eimperative_2esinkTest_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esinkTest_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2esinkTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esinkTest_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2esinkTest(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    V v_z_249 = heff_field(v_b_242, 0);
    V v_b2_2410 = heff_field(v_b_242, 1);
    V v_e_2411 = heff_field(v_b_242, 2);
    V v_ru_24b_242_24ELet = heff_take_reuse_n(v_b_242, 7ULL, 3);
    switch (heff_tag_of(v_b2_2410)) {
    case TAG_EVar: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_b2_2410, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      V v_b21_2430 = heff_field(v_b2_2410, 0);
      V v_arms_2431 = heff_field(v_b2_2410, 1);
      V v_ru_24b2_2410_24EMatch = heff_take_reuse_n(v_b2_2410, 3ULL, 2);
      switch (heff_tag_of(v_b21_2430)) {
      case TAG_EVar: {
        V v_y_2432 = heff_field(v_b21_2430, 0);
        V v_ru_24b21_2430_24EVar = heff_take_reuse_n(v_b21_2430, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_240, v_y_2432, 2)) {
          V v_t_2434 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_a_241));
          if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
            heff_drop(v_t_2434);
            V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2431));
            V v_t_2441;
            if (heff_intEq_c(v_t_2435, MK_INT(2LL))) {
              V v_t_2437 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2esinkTest_str0), v_arms_2431));
              switch (heff_tag_of(v_t_2437)) {
              case TAG_Nothing: {
                v_t_2441 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                heff_take_n(v_t_2437, 0ULL, 1);
                V v_t_2439 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2esinkTest_str1), v_arms_2431));
                switch (heff_tag_of(v_t_2439)) {
                case TAG_Nothing: {
                  v_t_2441 = NTAG(TAG_False);
                  break;
                }
                case TAG_Just: {
                  heff_take_n(v_t_2439, 0ULL, 1);
                  v_t_2441 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_t_2439);
                }
                break;
              }
              default: heff_nomatch(v_t_2437);
              }
            } else {
              v_t_2441 = NTAG(TAG_False);
            }
            if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
              heff_drop(v_t_2441);
              V v_x1_2452 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2esinkTest_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), v_arms_2431));
              if ((heff_dup(v_x1_2452) == NTAG(TAG_True))) {
                heff_drop(v_x_240);
                heff_drop(v_a_241);
                heff_drop(v_z_249);
                heff_drop(v_e_2411);
                heff_drop_cell(v_ru_24b_242_24ELet, 3);
                heff_drop(v_arms_2431);
                heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
                heff_drop_cell(v_ru_24b21_2430_24EVar, 1);
                heff_drop(v_x1_2452);
                return NTAG(TAG_Nothing);
              } else {
                heff_drop(v_x1_2452);
                V v_t_2453 = heff_tag_at_n(v_ru_24b2_2410_24EMatch, TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)});
                V v_t_2454 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2453));
                V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)});
                V v_t_2456 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2455));
                V v_t_2457 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2454, v_t_2456}), 0, 2);
                if (heff_intEq_c(v_t_2457, MK_INT(0LL))) {
                  V v_t_2459 = heff_tag_at_n(v_ru_24b_242_24ELet, TAG_ELet, 3, (V[]){v_z_249, heff_tag_n(TAG_EMatch, 2, (V[]){v_a_241, v_arms_2431}), v_e_2411});
                  return heff_tag_at_n(v_ru_24b21_2430_24EVar, TAG_Just, 1, (V[]){v_t_2459});
                } else {
                  heff_drop(v_a_241);
                  heff_drop(v_z_249);
                  heff_drop(v_e_2411);
                  heff_drop_cell(v_ru_24b_242_24ELet, 3);
                  heff_drop(v_arms_2431);
                  heff_drop_cell(v_ru_24b21_2430_24EVar, 1);
                  return NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop(v_x_240);
              heff_drop(v_a_241);
              heff_drop(v_z_249);
              heff_drop(v_e_2411);
              heff_drop_cell(v_ru_24b_242_24ELet, 3);
              heff_drop(v_arms_2431);
              heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
              heff_drop_cell(v_ru_24b21_2430_24EVar, 1);
              heff_drop(v_t_2441);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_x_240);
            heff_drop(v_a_241);
            heff_drop(v_z_249);
            heff_drop(v_e_2411);
            heff_drop_cell(v_ru_24b_242_24ELet, 3);
            heff_drop(v_arms_2431);
            heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
            heff_drop_cell(v_ru_24b21_2430_24EVar, 1);
            heff_drop(v_t_2434);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_a_241);
          heff_drop(v_z_249);
          heff_drop(v_e_2411);
          heff_drop_cell(v_ru_24b_242_24ELet, 3);
          heff_drop(v_arms_2431);
          heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
          heff_drop_cell(v_ru_24b21_2430_24EVar, 1);
          return NTAG(TAG_Nothing);
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        heff_take_n(v_b21_2430, 0ULL, 4);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        heff_take_na(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBytes: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        heff_take_na(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_b21_2430);
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_b2_2410);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_b_242, 0ULL, 4);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_b_242, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    V v_b1_24116 = heff_field(v_b_242, 0);
    V v_arms_24117 = heff_field(v_b_242, 1);
    V v_ru_24b_242_24EMatch = heff_take_reuse_n(v_b_242, 3ULL, 2);
    switch (heff_tag_of(v_b1_24116)) {
    case TAG_EVar: {
      V v_y_24118 = heff_field(v_b1_24116, 0);
      V v_ru_24b1_24116_24EVar = heff_take_reuse_n(v_b1_24116, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_24118, 2)) {
        V v_t_24120 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_a_241));
        if ((heff_dup(v_t_24120) == NTAG(TAG_True))) {
          heff_drop(v_t_24120);
          V v_t_24121 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24117));
          if (heff_intEq_c(v_t_24121, MK_INT(2LL))) {
            V v_t_24123 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2esinkTest_str2), v_arms_24117));
            switch (heff_tag_of(v_t_24123)) {
            case TAG_Nothing: {
              heff_drop(v_x_240);
              heff_drop(v_a_241);
              heff_drop(v_arms_24117);
              heff_drop_cell(v_ru_24b_242_24EMatch, 2);
              heff_drop_cell(v_ru_24b1_24116_24EVar, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              heff_take_n(v_t_24123, 0ULL, 1);
              V v_t_24125 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2esinkTest_str3), v_arms_24117));
              switch (heff_tag_of(v_t_24125)) {
              case TAG_Nothing: {
                heff_drop(v_x_240);
                heff_drop(v_a_241);
                heff_drop(v_arms_24117);
                heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                heff_drop_cell(v_ru_24b1_24116_24EVar, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                heff_take_n(v_t_24125, 0ULL, 1);
                V v_x1_24137 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2esinkTest_lam1, 1, 1, (V[]){v_x_240}), v_arms_24117));
                if ((heff_dup(v_x1_24137) == NTAG(TAG_True))) {
                  heff_drop(v_a_241);
                  heff_drop(v_arms_24117);
                  heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                  heff_drop_cell(v_ru_24b1_24116_24EVar, 1);
                  heff_drop(v_x1_24137);
                  return NTAG(TAG_Nothing);
                } else {
                  heff_drop(v_x1_24137);
                  return heff_tag_at_n(v_ru_24b1_24116_24EVar, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24b_242_24EMatch, TAG_EMatch, 2, (V[]){v_a_241, v_arms_24117})});
                }
              }
              default: return heff_nomatch(v_t_24125);
              }
            }
            default: return heff_nomatch(v_t_24123);
            }
          } else {
            heff_drop(v_x_240);
            heff_drop(v_a_241);
            heff_drop(v_arms_24117);
            heff_drop_cell(v_ru_24b_242_24EMatch, 2);
            heff_drop_cell(v_ru_24b1_24116_24EVar, 1);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_a_241);
          heff_drop(v_arms_24117);
          heff_drop_cell(v_ru_24b_242_24EMatch, 2);
          heff_drop_cell(v_ru_24b1_24116_24EVar, 1);
          heff_drop(v_t_24120);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_arms_24117);
        heff_drop_cell(v_ru_24b_242_24EMatch, 2);
        heff_drop_cell(v_ru_24b1_24116_24EVar, 1);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_b1_24116, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_b1_24116, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_b1_24116, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_b1_24116, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_b1_24116, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24117);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_b1_24116);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_na(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2ecompile_2eimperative_2esinkTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2esinkTest(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2esinkTest_lam0(V self, V *args) {
  V v_a_2442 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2446;
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_b_2445 = heff_field(v_a_2442, 2);
    heff_take_n(v_a_2442, 4ULL, 3);
    v_e_2446 = v_b_2445;
    break;
  }
  default: heff_nomatch(v_a_2442);
  }
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2446), NTAG(TAG_Nil)});
  V v_t_2448 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2447));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
  V v_t_2450 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2449));
  V v_x_2451 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2448, v_t_2450}), 0, 2);
  return heff_intLt(MK_INT(0LL), v_x_2451);
}
V g_heff_2ecompile_2eimperative_2esinkTest_lam1(V self, V *args) {
  V v_a_24127 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_24131;
  switch (heff_tag_of(v_a_24127)) {
  case TAG_MkArm: {
    V v_b_24130 = heff_field(v_a_24127, 2);
    heff_take_n(v_a_24127, 4ULL, 3);
    v_e_24131 = v_b_24130;
    break;
  }
  default: heff_nomatch(v_a_24127);
  }
  V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_24131), NTAG(TAG_Nil)});
  V v_t_24133 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_24132));
  V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_24131, NTAG(TAG_Nil)});
  V v_t_24135 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_24134));
  V v_x_24136 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24133, v_t_24135}), 0, 2);
  return heff_intLt(MK_INT(0LL), v_x_24136);
}
Clo g_heff_2ecompile_2eimperative_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2econdIf(V v_c_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_c_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_c_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PBool: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_c_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_c_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c1_2473 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    V t_0 = v_c1_2473;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2474 = heff_field(v_c_240, 0);
    V v_b_2475 = heff_field(v_c_240, 1);
    V v_c3_2476 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PIf = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_t_2488;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop(v_t_2488);
      V v_t_24100;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_24100 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_24100 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24c_240_24PIf, 3);
        heff_drop(v_t_24100);
        V v_t_24101 = (g_heff_2ecompile_2eimperative_2econdIf(v_b_2475, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_24102 = (g_heff_2ecompile_2eimperative_2econdIf(v_c3_2476, v_t_241, v_e_242));
        V t_0 = v_a_2474;
        V t_1 = v_t_24101;
        V t_2 = v_t_24102;
        v_c_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_24100);
        return heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2474, v_b_2475, v_c3_2476}), v_t_241, v_e_242});
      }
    } else {
      heff_drop(v_t_2488);
      return heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2474, v_b_2475, v_c3_2476}), v_t_241, v_e_242});
    }
  }
  case TAG_PLet: {
    V v_x_24103 = heff_field(v_c_240, 0);
    V v_o_24104 = heff_field(v_c_240, 1);
    V v_c3_24105 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PLet = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_cell_24106 = heff_tag_at_n(v_ru_24c_240_24PLet, TAG_PLet, 3, (V[]){v_x_24103, v_o_24104, heff_hole()});
    V v_u_24107 = (g_heff_2ecompile_2eimperative_2econdIf_24dps(v_c3_24105, v_t_241, v_e_242, heff_dup(v_cell_24106)));
    heff_drop(v_u_24107);
    return v_cell_24106;
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdIf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimperative_2epredLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredLets_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredLets(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_p_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLet: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_o_245 = heff_field(v_x11_242, 1);
      V v_x3_246 = (g_heff_2ecompile_2eimperative_2epredLets(v_rest_243, v_p_241));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_q_247 = heff_field(v_x3_246, 0);
        V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_PLet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_o_245), v_q_247})});
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    case TAG_SDecl: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSet: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIf: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCase: {
      heff_drop(v_p_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epredLets(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str0, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str1, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str2, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str3, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str4, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str5, 10, "$notSimple");
V g_heff_2ecompile_2eimperative_2esimpleOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam3, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam4(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam4, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam9(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam9, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam12(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam12, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam19, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam20(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam20, 1, 0};
Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2esimpleOf(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam0, 1, 1, (V[]){v_x_242});
  }
  case TAG_EGlobal: {
    V v_k_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam1, 1, 1, (V[]){v_k_244});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam3_clo);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam4_clo);
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_e_241, 0);
    V v_ts_2424 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2429 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam5, 1, 1, (V[]){v_g_240}), heff_dup(v_fs_2423)));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam6, 1, 3, (V[]){v_m_2429, v_fs_2423, v_ts_2424});
  }
  case TAG_EProj: {
    V v_e1_2436 = heff_field(v_e_241, 0);
    V v_l_2437 = heff_field(v_e_241, 1);
    V v_sh_2438 = heff_field(v_e_241, 2);
    V v_t_2439 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e1_2436}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam7, 1, 4, (V[]){v_m_2440, v_l_2437, v_sh_2438, v_t_2439});
  }
  case TAG_ETag: {
    V v_t_2445 = heff_field(v_e_241, 0);
    V v_as_2446 = heff_field(v_e_241, 1);
    V v_ts_2447 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2448 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_get_n(v_g_240, 1, 8), v_as_2446));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam8, 1, 3, (V[]){v_m_2448, v_t_2445, v_ts_2447});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam9_clo);
  }
  case TAG_EPrim: {
    V v_p_2457 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam10, 1, 1, (V[]){v_p_2457});
  }
  case TAG_EPrimCall: {
    V v_p_2459 = heff_field(v_e_241, 0);
    V v_as_2460 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_get_n(v_g_240, 1, 8), v_as_2460));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam11, 1, 2, (V[]){v_m_2461, v_p_2459});
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam12_clo);
  }
  case TAG_EInt: {
    V v_i_2470 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam13, 1, 1, (V[]){v_i_2470});
  }
  case TAG_EFloat: {
    V v_x_2472 = heff_tget_v(v_e_241, 0);
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam14, 1, 1, (V[]){v_x_2472});
  }
  case TAG_EStr: {
    V v_s_2474 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam15, 1, 1, (V[]){v_s_2474});
  }
  case TAG_EBytes: {
    V v_s_2476 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam16, 1, 1, (V[]){v_s_2476});
  }
  case TAG_EFixed: {
    V v_w_2478 = heff_field(v_e_241, 0);
    V v_i_2479 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam17, 1, 2, (V[]){v_w_2478, v_i_2479});
  }
  case TAG_EFloat32: {
    V v_x_2481 = heff_tget_v(v_e_241, 0);
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam18, 1, 1, (V[]){v_x_2481});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam19_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam20_clo);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2esimpleOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_x_242}), v_n_243});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_k_244}), v_n_245});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_SLam, 2, (V[]){v_xs_246, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2411})});
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_t_2417 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_n_2416});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str1), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam5(V self, V *args) {
  V v_f_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_f_2425, 1);
    heff_take_n(v_f_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V f_ = heff_get_n(v_g_240, 1, 8);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_fs_2423 = heff_env(self)[1];
  V v_ts_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_n_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_n_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2423, v_x_2432));
    V v_x_2435 = heff_tag_n(TAG_SRec, 2, (V[]){v_t_2434, v_ts_2424});
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam7(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_l_2437 = heff_env(self)[1];
  V v_sh_2438 = heff_env(self)[2];
  V v_t_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_x_2443, v_l_2437, v_sh_2438, v_t_2439}), v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam8(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_t_2445 = heff_env(self)[1];
  V v_ts_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_STag, 3, (V[]){v_t_2445, v_x_2451, v_ts_2447}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam9(V self, V *args) {
  V v_n_2455 = args[0];
  V v_t_2456 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str2), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_n_2455});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam10(V self, V *args) {
  V v_n_2458 = args[0];
  V v_p_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimFn, 1, (V[]){v_p_2457}), v_n_2458});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam11(V self, V *args) {
  V v_n_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_p_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 2, (V[]){v_p_2459, v_x_2464}), v_n_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam12(V self, V *args) {
  V v_n_2468 = args[0];
  V v_t_2469 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str3), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, v_n_2468});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam13(V self, V *args) {
  V v_n_2471 = args[0];
  V v_i_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SInt, 1, (V[]){v_i_2470}), v_n_2471});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam14(V self, V *args) {
  V v_n_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_SFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2472))}), v_n_2473});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam15(V self, V *args) {
  V v_n_2475 = args[0];
  V v_s_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SStr, 1, (V[]){v_s_2474}), v_n_2475});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam16(V self, V *args) {
  V v_n_2477 = args[0];
  V v_s_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SBytes, 1, (V[]){v_s_2476}), v_n_2477});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam17(V self, V *args) {
  V v_n_2480 = args[0];
  V v_w_2478 = heff_env(self)[0];
  V v_i_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 2, (V[]){v_w_2478, v_i_2479}), v_n_2480});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam18(V self, V *args) {
  V v_n_2482 = args[0];
  V v_x_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_SFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2481))}), v_n_2482});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam19(V self, V *args) {
  V v_n_2483 = args[0];
  V v_t_2484 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str4), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2484, v_n_2483});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam20(V self, V *args) {
  V v_n_2487 = args[0];
  V v_t_2488 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str5), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2488, v_n_2487});
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseSet(V v_g_240, V v_x_241, V v_s_242, V v_arms_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam0, 1, 4, (V[]){v_m_244, v_g_240, v_x_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args) {
  V v_arm_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_arm_249, 0);
    V v_vs_2411 = heff_field(v_arm_249, 1);
    V v_b_2412 = heff_field(v_arm_249, 2);
    heff_take_n(v_arm_249, 7ULL, 3);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_x_241, v_b_2412}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam2, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_arm_249);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam1, 1, 2, (V[]){v_g_240, v_x_241}), v_arms_243));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_t_2424;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_247, 0));
        v_t_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_247, 1);
        heff_take_n(v_x_247, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_t_2427, v_x_2420}), NTAG(TAG_Nil)});
      V v_x_2429 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2428));
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2429, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2ematchSet_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2ematchSet_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2ematchSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ematchSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ematchSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ematchSet(V v_g_240, V v_x_241, V v_s_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_243));
  V v_it_2410;
  if (heff_intEq_c(v_t_244, MK_INT(2LL))) {
    V v_t_246 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2ematchSet_str0), v_arms_243));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_it_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_t_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
      V v_t_248 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2ematchSet_str1), v_arms_243));
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop(v_t_247);
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        v_it_2410 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_f_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        v_it_2410 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_f_249})});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      break;
    }
    default: heff_nomatch(v_t_246);
    }
  } else {
    v_it_2410 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_it_2410)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_x_241, v_s_242, v_arms_243);
  }
  case TAG_Just: {
    V v_it1_2411 = heff_field(v_it_2410, 0);
    heff_take_n(v_it_2410, 1ULL, 1);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_MkPair: {
      V v_t_2412 = heff_field(v_it1_2411, 0);
      V v_f_2413 = heff_field(v_it1_2411, 1);
      heff_take_n(v_it1_2411, 3ULL, 2);
      V v_m_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2ematchSet_lam0, 1, 7, (V[]){v_m_2414, v_g_240, v_x_241, v_s_242, v_arms_243, v_t_2412, v_f_2413});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_it_2410);
  }
}
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ematchSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ematchSet_lam0(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_243 = heff_env(self)[4];
  V v_t_2412 = heff_env(self)[5];
  V v_f_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      heff_drop(v_t_2412);
      heff_drop(v_f_2413);
      heff_drop_cell(v_ru_24x2_2416_24MkPair, 2);
      V v_t_2419 = (g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_x_241, v_s_242, v_arms_243));
      V f_ = v_t_2419;
      args[0] = v_n_2418;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2420 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_243);
      V v_m_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 4)), 2, (V[]){heff_dup(v_x_241), v_t_2412}));
      V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2418}));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_n_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        V v_m_2425 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_x_241, v_f_2413}));
        V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_n_2424}));
        switch (heff_tag_of(v_x2_2426)) {
        case TAG_MkPair: {
          V v_x_2427 = heff_field(v_x2_2426, 0);
          V v_n_2428 = heff_field(v_x2_2426, 1);
          heff_take_n(v_x2_2426, 3ULL, 2);
          V v_t_2429 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2420, v_x_2423, v_x_2427}), NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, v_n_2428});
        }
        default: return heff_nomatch(v_x2_2426);
        }
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_x_2417);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
Clo g_heff_2ecompile_2eimperative_2edeclBefore_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2edeclBefore_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), NTAG(TAG_Nil)});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), v_t_246});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_247);
    }
    case TAG_Cons: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_x_240;
      V t_1 = v_x22_245;
      V t_2 = v_cell_2410;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclBefore_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam12(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam19(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam20(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam21(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etoDest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etoDest_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etoDest(V v_g_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam0, 1, 2, (V[]){v_m_244, v_d_241});
  }
  case TAG_EGlobal: {
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam1, 1, 2, (V[]){v_m_2421, v_d_241});
  }
  case TAG_ELam: {
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam2, 1, 2, (V[]){v_m_2439, v_d_241});
  }
  case TAG_EApp: {
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam3, 1, 2, (V[]){v_m_2457, v_d_241});
  }
  case TAG_ELet: {
    V v_y_2473 = heff_field(v_e_242, 0);
    V v_a_2474 = heff_field(v_e_242, 1);
    V v_b_2475 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2476 = (g_heff_2ecompile_2eimperative_2esinkTest(heff_dup(v_y_2473), heff_dup(v_a_2474), heff_dup(v_b_2475)));
    switch (heff_tag_of(v_t_2476)) {
    case TAG_Nothing: {
      V v_m_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_2473, v_a_2474}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam4, 1, 4, (V[]){v_m_2477, v_g_240, v_d_241, v_b_2475});
    }
    case TAG_Just: {
      V v_e2_2487 = heff_field(v_t_2476, 0);
      heff_take_n(v_t_2476, 1ULL, 1);
      heff_drop(v_y_2473);
      heff_drop(v_a_2474);
      heff_drop(v_b_2475);
      V t_0 = v_g_240;
      V t_1 = v_d_241;
      V t_2 = v_e2_2487;
      v_g_240 = t_0;
      v_d_241 = t_1;
      v_e_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_2476);
    }
  }
  case TAG_ERecord: {
    V v_m_2490 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam5, 1, 2, (V[]){v_m_2490, v_d_241});
  }
  case TAG_EProj: {
    V v_m_24110 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam6, 1, 2, (V[]){v_m_24110, v_d_241});
  }
  case TAG_ETag: {
    V v_m_24129 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam7, 1, 2, (V[]){v_m_24129, v_d_241});
  }
  case TAG_EMatch: {
    V v_s_24145 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_24146 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24147 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24146));
    V v_it_24153;
    if (heff_intEq_c(v_t_24147, MK_INT(2LL))) {
      V v_t_24149 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2etoDest_str0), v_arms_24146));
      switch (heff_tag_of(v_t_24149)) {
      case TAG_Nothing: {
        v_it_24153 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_24150 = heff_field(v_t_24149, 0);
        V v_ru_24t_24149_24Just = heff_take_reuse_n(v_t_24149, 1ULL, 1);
        V v_t_24151 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2etoDest_str1), v_arms_24146));
        switch (heff_tag_of(v_t_24151)) {
        case TAG_Nothing: {
          heff_drop(v_t_24150);
          heff_drop_cell(v_ru_24t_24149_24Just, 1);
          v_it_24153 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_24152 = heff_field(v_t_24151, 0);
          heff_take_n(v_t_24151, 1ULL, 1);
          v_it_24153 = heff_tag_at_n(v_ru_24t_24149_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24150, v_f_24152})});
          break;
        }
        default: heff_nomatch(v_t_24151);
        }
        break;
      }
      default: heff_nomatch(v_t_24149);
      }
    } else {
      v_it_24153 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_24153)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      V v_t_24156;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24154 = heff_dup(heff_field(v_d_241, 0));
        v_t_24156 = v_x_24154;
        break;
      }
      case TAG_DLet: {
        V v_x_24155 = heff_dup(heff_field(v_d_241, 0));
        v_t_24156 = v_x_24155;
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_24157 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_24156, v_s_24145, v_arms_24146));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam8, 1, 2, (V[]){v_m_24157, v_d_241});
    }
    case TAG_Just: {
      V v_it1_24165 = heff_field(v_it_24153, 0);
      heff_take_n(v_it_24153, 1ULL, 1);
      switch (heff_tag_of(v_it1_24165)) {
      case TAG_MkPair: {
        V v_t_24166 = heff_field(v_it1_24165, 0);
        V v_f_24167 = heff_field(v_it1_24165, 1);
        heff_take_n(v_it1_24165, 3ULL, 2);
        V v_t_24168 = heff_dup(heff_rfield(v_g_240, 0));
        V v_t_24170;
        if ((heff_dup(v_t_24168) == NTAG(TAG_True))) {
          heff_drop(v_t_24168);
          V v_t_24169 = (g_heff_2ecompile_2eimperative_2econdShaped(v_t_24166));
          if ((heff_dup(v_t_24169) == NTAG(TAG_True))) {
            heff_drop(v_t_24169);
            v_t_24170 = (g_heff_2ecompile_2eimperative_2econdShaped(v_f_24167));
          } else {
            heff_drop(v_f_24167);
            heff_drop(v_t_24169);
            v_t_24170 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_t_24166);
          heff_drop(v_f_24167);
          heff_drop(v_t_24168);
          v_t_24170 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_24170) == NTAG(TAG_True))) {
          heff_drop(v_t_24170);
          V v_m_24171 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
          return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam9, 1, 5, (V[]){v_m_24171, v_d_241, v_g_240, v_s_24145, v_arms_24146});
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_t_24170);
          V v_t_24193;
          switch (heff_tag_of(v_d_241)) {
          case TAG_DSet: {
            V v_x_24191 = heff_dup(heff_field(v_d_241, 0));
            v_t_24193 = v_x_24191;
            break;
          }
          case TAG_DLet: {
            V v_x_24192 = heff_dup(heff_field(v_d_241, 0));
            v_t_24193 = v_x_24192;
            break;
          }
          default: heff_nomatch(v_d_241);
          }
          V v_m_24194 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_24193, v_s_24145, v_arms_24146));
          return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam10, 1, 2, (V[]){v_m_24194, v_d_241});
        }
      }
      default: return heff_nomatch(v_it1_24165);
      }
    }
    default: return heff_nomatch(v_it_24153);
    }
  }
  case TAG_EPrim: {
    V v_m_24203 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam11, 1, 2, (V[]){v_m_24203, v_d_241});
  }
  case TAG_EPrimCall: {
    V v_m_24221 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam12, 1, 2, (V[]){v_m_24221, v_d_241});
  }
  case TAG_ECall: {
    V v_m_24239 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam13, 1, 2, (V[]){v_m_24239, v_d_241});
  }
  case TAG_EInt: {
    V v_m_24256 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam14, 1, 2, (V[]){v_m_24256, v_d_241});
  }
  case TAG_EFloat: {
    V v_m_24273 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam15, 1, 2, (V[]){v_m_24273, v_d_241});
  }
  case TAG_EStr: {
    V v_m_24290 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam16, 1, 2, (V[]){v_m_24290, v_d_241});
  }
  case TAG_EBytes: {
    V v_m_24307 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam17, 1, 2, (V[]){v_m_24307, v_d_241});
  }
  case TAG_EFixed: {
    V v_m_24325 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam18, 1, 2, (V[]){v_m_24325, v_d_241});
  }
  case TAG_EFloat32: {
    V v_m_24342 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam19, 1, 2, (V[]){v_m_24342, v_d_241});
  }
  case TAG_EAbandon: {
    V v_m_24358 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam20, 1, 2, (V[]){v_m_24358, v_d_241});
  }
  case TAG_EFix: {
    V v_m_24376 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam21, 1, 2, (V[]){v_m_24376, v_d_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etoDest(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_o_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_o_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2415 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2417 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2415, v_o_2414});
      break;
    }
    case TAG_DLet: {
      V v_x_2416 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2417 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2416, v_o_2414});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_x_2419 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2418));
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args) {
  V v_n_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_n_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_dup(heff_field(v_x_2424, 0));
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    V v_o_2431;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_MkPair: {
      V v_y_2430 = heff_field(v_x_2424, 1);
      heff_take_n(v_x_2424, 2ULL, 2);
      v_o_2431 = v_y_2430;
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    V v_t_2434;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2432 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2434 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2432, v_o_2431});
      break;
    }
    case TAG_DLet: {
      V v_x_2433 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2434 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2433, v_o_2431});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
    V v_x_2436 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
    return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_n_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_x_2442)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_dup(heff_field(v_x_2442, 0));
      v_t_2446 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_x_2442);
    }
    V v_o_2449;
    switch (heff_tag_of(v_x_2442)) {
    case TAG_MkPair: {
      V v_y_2448 = heff_field(v_x_2442, 1);
      heff_take_n(v_x_2442, 2ULL, 2);
      v_o_2449 = v_y_2448;
      break;
    }
    default: heff_nomatch(v_x_2442);
    }
    V v_t_2452;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2450 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2452 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2450, v_o_2449});
      break;
    }
    case TAG_DLet: {
      V v_x_2451 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2452 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2451, v_o_2449});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_x_2454 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2453));
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2454, v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2464;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_dup(heff_field(v_x_2460, 0));
      v_t_2464 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_o_2467;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_MkPair: {
      V v_y_2466 = heff_field(v_x_2460, 1);
      heff_take_n(v_x_2460, 2ULL, 2);
      v_o_2467 = v_y_2466;
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_t_2470;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2468 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2470 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2468, v_o_2467});
      break;
    }
    case TAG_DLet: {
      V v_x_2469 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2470 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2469, v_o_2467});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_x_2472 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2471));
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_x_2472, v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args) {
  V v_n_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_2475 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_n_2478}));
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_field(v_x2_2479, 0);
    V v_n_2481 = heff_field(v_x2_2479, 1);
    V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
    V v_m_2482 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_b_2475));
    V v_x2_2483 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2481}));
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_MkPair: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_n_2485 = heff_field(v_x2_2483, 1);
      heff_take_n(v_x2_2483, 3ULL, 2);
      V v_x_2486 = (g_prelude_2e_2b_2b(v_x_2480, v_x_2484));
      return heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_MkPair, 2, (V[]){v_x_2486, v_n_2485});
    }
    default: return heff_nomatch(v_x2_2483);
    }
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
    V v_t_2497;
    switch (heff_tag_of(v_x_2493)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_dup(heff_field(v_x_2493, 0));
      v_t_2497 = v_x_2495;
      break;
    }
    default: heff_nomatch(v_x_2493);
    }
    V v_o_24100;
    switch (heff_tag_of(v_x_2493)) {
    case TAG_MkPair: {
      V v_y_2499 = heff_field(v_x_2493, 1);
      heff_take_n(v_x_2493, 2ULL, 2);
      v_o_24100 = v_y_2499;
      break;
    }
    default: heff_nomatch(v_x_2493);
    }
    V v_t_24103;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24101 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24103 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24101, v_o_24100});
      break;
    }
    case TAG_DLet: {
      V v_x_24102 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24103 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24102, v_o_24100});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
    V v_x_24105 = (g_prelude_2e_2b_2b(v_t_2497, v_t_24104));
    return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){v_x_24105, v_n_2494});
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args) {
  V v_n_24111 = args[0];
  V v_m_24110 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24112 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_n_24111}));
  switch (heff_tag_of(v_x2_24112)) {
  case TAG_MkPair: {
    V v_x_24113 = heff_field(v_x2_24112, 0);
    V v_n_24114 = heff_field(v_x2_24112, 1);
    V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
    V v_t_24117;
    switch (heff_tag_of(v_x_24113)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_dup(heff_field(v_x_24113, 0));
      v_t_24117 = v_x_24115;
      break;
    }
    default: heff_nomatch(v_x_24113);
    }
    V v_o_24120;
    switch (heff_tag_of(v_x_24113)) {
    case TAG_MkPair: {
      V v_y_24119 = heff_field(v_x_24113, 1);
      heff_take_n(v_x_24113, 2ULL, 2);
      v_o_24120 = v_y_24119;
      break;
    }
    default: heff_nomatch(v_x_24113);
    }
    V v_t_24123;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24121 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24123 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24121, v_o_24120});
      break;
    }
    case TAG_DLet: {
      V v_x_24122 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24123 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24122, v_o_24120});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
    V v_x_24125 = (g_prelude_2e_2b_2b(v_t_24117, v_t_24124));
    return heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, (V[]){v_x_24125, v_n_24114});
  }
  default: return heff_nomatch(v_x2_24112);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args) {
  V v_n_24130 = args[0];
  V v_m_24129 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24131 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_n_24130}));
  switch (heff_tag_of(v_x2_24131)) {
  case TAG_MkPair: {
    V v_x_24132 = heff_field(v_x2_24131, 0);
    V v_n_24133 = heff_field(v_x2_24131, 1);
    V v_ru_24x2_24131_24MkPair = heff_take_reuse_n(v_x2_24131, 3ULL, 2);
    V v_t_24136;
    switch (heff_tag_of(v_x_24132)) {
    case TAG_MkPair: {
      V v_x_24134 = heff_dup(heff_field(v_x_24132, 0));
      v_t_24136 = v_x_24134;
      break;
    }
    default: heff_nomatch(v_x_24132);
    }
    V v_o_24139;
    switch (heff_tag_of(v_x_24132)) {
    case TAG_MkPair: {
      V v_y_24138 = heff_field(v_x_24132, 1);
      heff_take_n(v_x_24132, 2ULL, 2);
      v_o_24139 = v_y_24138;
      break;
    }
    default: heff_nomatch(v_x_24132);
    }
    V v_t_24142;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24140 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24142 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24140, v_o_24139});
      break;
    }
    case TAG_DLet: {
      V v_x_24141 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24142 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24141, v_o_24139});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24143 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
    V v_x_24144 = (g_prelude_2e_2b_2b(v_t_24136, v_t_24143));
    return heff_tag_at_n(v_ru_24x2_24131_24MkPair, TAG_MkPair, 2, (V[]){v_x_24144, v_n_24133});
  }
  default: return heff_nomatch(v_x2_24131);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args) {
  V v_n_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_n_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_n_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_x_24164;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_24164 = v_x_24160;
      break;
    }
    case TAG_DLet: {
      V v_x_24163 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_x_24164 = (g_heff_2ecompile_2eimperative_2edeclBefore(v_x_24163, v_x_24160));
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_x_24164, v_n_24161});
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args) {
  V v_n_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_s_24145 = heff_env(self)[3];
  V v_arms_24146 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_n_24172}));
  switch (heff_tag_of(v_x2_24173)) {
  case TAG_MkPair: {
    V v_x_24174 = heff_field(v_x2_24173, 0);
    V v_n_24175 = heff_field(v_x2_24173, 1);
    V v_ru_24x2_24173_24MkPair = heff_take_reuse_n(v_x2_24173, 3ULL, 2);
    switch (heff_tag_of(v_x_24174)) {
    case TAG_Nothing: {
      V v_t_24178;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24176 = heff_dup(heff_field(v_d_241, 0));
        v_t_24178 = v_x_24176;
        break;
      }
      case TAG_DLet: {
        V v_x_24177 = heff_dup(heff_field(v_d_241, 0));
        v_t_24178 = v_x_24177;
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_24179 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_24178, v_s_24145, v_arms_24146));
      V v_x2_24180 = heff_tr(heff_call(v_m_24179, 1, (V[]){v_n_24175}));
      switch (heff_tag_of(v_x2_24180)) {
      case TAG_MkPair: {
        V v_x_24181 = heff_field(v_x2_24180, 0);
        V v_n_24182 = heff_field(v_x2_24180, 1);
        heff_take_n(v_x2_24180, 3ULL, 2);
        V v_x_24185;
        switch (heff_tag_of(v_d_241)) {
        case TAG_DSet: {
          heff_take_n(v_d_241, 0ULL, 1);
          v_x_24185 = v_x_24181;
          break;
        }
        case TAG_DLet: {
          V v_x_24184 = heff_field(v_d_241, 0);
          heff_take_n(v_d_241, 1ULL, 1);
          v_x_24185 = (g_heff_2ecompile_2eimperative_2edeclBefore(v_x_24184, v_x_24181));
          break;
        }
        default: heff_nomatch(v_d_241);
        }
        return heff_tag_at_n(v_ru_24x2_24173_24MkPair, TAG_MkPair, 2, (V[]){v_x_24185, v_n_24182});
      }
      default: return heff_nomatch(v_x2_24180);
      }
    }
    case TAG_Just: {
      V v_c_24186 = heff_field(v_x_24174, 0);
      V v_ru_24x_24174_24Just = heff_take_reuse_n(v_x_24174, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_24145);
      heff_drop(v_arms_24146);
      V v_t_24189;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24187 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24189 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24187, heff_tag_at_n(v_ru_24x_24174_24Just, TAG_OBool, 1, (V[]){v_c_24186})});
        break;
      }
      case TAG_DLet: {
        V v_x_24188 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24189 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24188, heff_tag_at_n(v_ru_24x_24174_24Just, TAG_OBool, 1, (V[]){v_c_24186})});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_t_24190 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24189, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_24173_24MkPair, TAG_MkPair, 2, (V[]){v_t_24190, v_n_24175});
    }
    default: return heff_nomatch(v_x_24174);
    }
  }
  default: return heff_nomatch(v_x2_24173);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam10(V self, V *args) {
  V v_n_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_n_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_n_24198 = heff_field(v_x2_24196, 1);
    V v_ru_24x2_24196_24MkPair = heff_take_reuse_n(v_x2_24196, 3ULL, 2);
    V v_x_24201;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_24201 = v_x_24197;
      break;
    }
    case TAG_DLet: {
      V v_x_24200 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_x_24201 = (g_heff_2ecompile_2eimperative_2edeclBefore(v_x_24200, v_x_24197));
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_at_n(v_ru_24x2_24196_24MkPair, TAG_MkPair, 2, (V[]){v_x_24201, v_n_24198});
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam11(V self, V *args) {
  V v_n_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_n_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_n_24207 = heff_field(v_x2_24205, 1);
    V v_ru_24x2_24205_24MkPair = heff_take_reuse_n(v_x2_24205, 3ULL, 2);
    V v_t_24210;
    switch (heff_tag_of(v_x_24206)) {
    case TAG_MkPair: {
      V v_x_24208 = heff_dup(heff_field(v_x_24206, 0));
      v_t_24210 = v_x_24208;
      break;
    }
    default: heff_nomatch(v_x_24206);
    }
    V v_o_24213;
    switch (heff_tag_of(v_x_24206)) {
    case TAG_MkPair: {
      V v_y_24212 = heff_field(v_x_24206, 1);
      heff_take_n(v_x_24206, 2ULL, 2);
      v_o_24213 = v_y_24212;
      break;
    }
    default: heff_nomatch(v_x_24206);
    }
    V v_t_24216;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24214 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24216 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24214, v_o_24213});
      break;
    }
    case TAG_DLet: {
      V v_x_24215 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24216 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24215, v_o_24213});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24217 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24216, NTAG(TAG_Nil)});
    V v_x_24218 = (g_prelude_2e_2b_2b(v_t_24210, v_t_24217));
    return heff_tag_at_n(v_ru_24x2_24205_24MkPair, TAG_MkPair, 2, (V[]){v_x_24218, v_n_24207});
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam12(V self, V *args) {
  V v_n_24222 = args[0];
  V v_m_24221 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24223 = heff_tr(heff_call(v_m_24221, 1, (V[]){v_n_24222}));
  switch (heff_tag_of(v_x2_24223)) {
  case TAG_MkPair: {
    V v_x_24224 = heff_field(v_x2_24223, 0);
    V v_n_24225 = heff_field(v_x2_24223, 1);
    V v_ru_24x2_24223_24MkPair = heff_take_reuse_n(v_x2_24223, 3ULL, 2);
    V v_t_24228;
    switch (heff_tag_of(v_x_24224)) {
    case TAG_MkPair: {
      V v_x_24226 = heff_dup(heff_field(v_x_24224, 0));
      v_t_24228 = v_x_24226;
      break;
    }
    default: heff_nomatch(v_x_24224);
    }
    V v_o_24231;
    switch (heff_tag_of(v_x_24224)) {
    case TAG_MkPair: {
      V v_y_24230 = heff_field(v_x_24224, 1);
      heff_take_n(v_x_24224, 2ULL, 2);
      v_o_24231 = v_y_24230;
      break;
    }
    default: heff_nomatch(v_x_24224);
    }
    V v_t_24234;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24232 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24234 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24232, v_o_24231});
      break;
    }
    case TAG_DLet: {
      V v_x_24233 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24234 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24233, v_o_24231});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24235 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24234, NTAG(TAG_Nil)});
    V v_x_24236 = (g_prelude_2e_2b_2b(v_t_24228, v_t_24235));
    return heff_tag_at_n(v_ru_24x2_24223_24MkPair, TAG_MkPair, 2, (V[]){v_x_24236, v_n_24225});
  }
  default: return heff_nomatch(v_x2_24223);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam13(V self, V *args) {
  V v_n_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_n_24240}));
  switch (heff_tag_of(v_x2_24241)) {
  case TAG_MkPair: {
    V v_x_24242 = heff_field(v_x2_24241, 0);
    V v_n_24243 = heff_field(v_x2_24241, 1);
    V v_ru_24x2_24241_24MkPair = heff_take_reuse_n(v_x2_24241, 3ULL, 2);
    V v_t_24246;
    switch (heff_tag_of(v_x_24242)) {
    case TAG_MkPair: {
      V v_x_24244 = heff_dup(heff_field(v_x_24242, 0));
      v_t_24246 = v_x_24244;
      break;
    }
    default: heff_nomatch(v_x_24242);
    }
    V v_o_24249;
    switch (heff_tag_of(v_x_24242)) {
    case TAG_MkPair: {
      V v_y_24248 = heff_field(v_x_24242, 1);
      heff_take_n(v_x_24242, 2ULL, 2);
      v_o_24249 = v_y_24248;
      break;
    }
    default: heff_nomatch(v_x_24242);
    }
    V v_t_24252;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24250 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24252 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24250, v_o_24249});
      break;
    }
    case TAG_DLet: {
      V v_x_24251 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24252 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24251, v_o_24249});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24253 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24252, NTAG(TAG_Nil)});
    V v_x_24254 = (g_prelude_2e_2b_2b(v_t_24246, v_t_24253));
    return heff_tag_at_n(v_ru_24x2_24241_24MkPair, TAG_MkPair, 2, (V[]){v_x_24254, v_n_24243});
  }
  default: return heff_nomatch(v_x2_24241);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam14(V self, V *args) {
  V v_n_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24258 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_n_24257}));
  switch (heff_tag_of(v_x2_24258)) {
  case TAG_MkPair: {
    V v_x_24259 = heff_field(v_x2_24258, 0);
    V v_n_24260 = heff_field(v_x2_24258, 1);
    V v_ru_24x2_24258_24MkPair = heff_take_reuse_n(v_x2_24258, 3ULL, 2);
    V v_t_24263;
    switch (heff_tag_of(v_x_24259)) {
    case TAG_MkPair: {
      V v_x_24261 = heff_dup(heff_field(v_x_24259, 0));
      v_t_24263 = v_x_24261;
      break;
    }
    default: heff_nomatch(v_x_24259);
    }
    V v_o_24266;
    switch (heff_tag_of(v_x_24259)) {
    case TAG_MkPair: {
      V v_y_24265 = heff_field(v_x_24259, 1);
      heff_take_n(v_x_24259, 2ULL, 2);
      v_o_24266 = v_y_24265;
      break;
    }
    default: heff_nomatch(v_x_24259);
    }
    V v_t_24269;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24267 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24269 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24267, v_o_24266});
      break;
    }
    case TAG_DLet: {
      V v_x_24268 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24269 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24268, v_o_24266});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24270 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24269, NTAG(TAG_Nil)});
    V v_x_24271 = (g_prelude_2e_2b_2b(v_t_24263, v_t_24270));
    return heff_tag_at_n(v_ru_24x2_24258_24MkPair, TAG_MkPair, 2, (V[]){v_x_24271, v_n_24260});
  }
  default: return heff_nomatch(v_x2_24258);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam15(V self, V *args) {
  V v_n_24274 = args[0];
  V v_m_24273 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24275 = heff_tr(heff_call(v_m_24273, 1, (V[]){v_n_24274}));
  switch (heff_tag_of(v_x2_24275)) {
  case TAG_MkPair: {
    V v_x_24276 = heff_field(v_x2_24275, 0);
    V v_n_24277 = heff_field(v_x2_24275, 1);
    V v_ru_24x2_24275_24MkPair = heff_take_reuse_n(v_x2_24275, 3ULL, 2);
    V v_t_24280;
    switch (heff_tag_of(v_x_24276)) {
    case TAG_MkPair: {
      V v_x_24278 = heff_dup(heff_field(v_x_24276, 0));
      v_t_24280 = v_x_24278;
      break;
    }
    default: heff_nomatch(v_x_24276);
    }
    V v_o_24283;
    switch (heff_tag_of(v_x_24276)) {
    case TAG_MkPair: {
      V v_y_24282 = heff_field(v_x_24276, 1);
      heff_take_n(v_x_24276, 2ULL, 2);
      v_o_24283 = v_y_24282;
      break;
    }
    default: heff_nomatch(v_x_24276);
    }
    V v_t_24286;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24284 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24286 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24284, v_o_24283});
      break;
    }
    case TAG_DLet: {
      V v_x_24285 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24286 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24285, v_o_24283});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24287 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24286, NTAG(TAG_Nil)});
    V v_x_24288 = (g_prelude_2e_2b_2b(v_t_24280, v_t_24287));
    return heff_tag_at_n(v_ru_24x2_24275_24MkPair, TAG_MkPair, 2, (V[]){v_x_24288, v_n_24277});
  }
  default: return heff_nomatch(v_x2_24275);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam16(V self, V *args) {
  V v_n_24291 = args[0];
  V v_m_24290 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24292 = heff_tr(heff_call(v_m_24290, 1, (V[]){v_n_24291}));
  switch (heff_tag_of(v_x2_24292)) {
  case TAG_MkPair: {
    V v_x_24293 = heff_field(v_x2_24292, 0);
    V v_n_24294 = heff_field(v_x2_24292, 1);
    V v_ru_24x2_24292_24MkPair = heff_take_reuse_n(v_x2_24292, 3ULL, 2);
    V v_t_24297;
    switch (heff_tag_of(v_x_24293)) {
    case TAG_MkPair: {
      V v_x_24295 = heff_dup(heff_field(v_x_24293, 0));
      v_t_24297 = v_x_24295;
      break;
    }
    default: heff_nomatch(v_x_24293);
    }
    V v_o_24300;
    switch (heff_tag_of(v_x_24293)) {
    case TAG_MkPair: {
      V v_y_24299 = heff_field(v_x_24293, 1);
      heff_take_n(v_x_24293, 2ULL, 2);
      v_o_24300 = v_y_24299;
      break;
    }
    default: heff_nomatch(v_x_24293);
    }
    V v_t_24303;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24301 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24303 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24301, v_o_24300});
      break;
    }
    case TAG_DLet: {
      V v_x_24302 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24303 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24302, v_o_24300});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24304 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24303, NTAG(TAG_Nil)});
    V v_x_24305 = (g_prelude_2e_2b_2b(v_t_24297, v_t_24304));
    return heff_tag_at_n(v_ru_24x2_24292_24MkPair, TAG_MkPair, 2, (V[]){v_x_24305, v_n_24294});
  }
  default: return heff_nomatch(v_x2_24292);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam17(V self, V *args) {
  V v_n_24308 = args[0];
  V v_m_24307 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24309 = heff_tr(heff_call(v_m_24307, 1, (V[]){v_n_24308}));
  switch (heff_tag_of(v_x2_24309)) {
  case TAG_MkPair: {
    V v_x_24310 = heff_field(v_x2_24309, 0);
    V v_n_24311 = heff_field(v_x2_24309, 1);
    V v_ru_24x2_24309_24MkPair = heff_take_reuse_n(v_x2_24309, 3ULL, 2);
    V v_t_24314;
    switch (heff_tag_of(v_x_24310)) {
    case TAG_MkPair: {
      V v_x_24312 = heff_dup(heff_field(v_x_24310, 0));
      v_t_24314 = v_x_24312;
      break;
    }
    default: heff_nomatch(v_x_24310);
    }
    V v_o_24317;
    switch (heff_tag_of(v_x_24310)) {
    case TAG_MkPair: {
      V v_y_24316 = heff_field(v_x_24310, 1);
      heff_take_n(v_x_24310, 2ULL, 2);
      v_o_24317 = v_y_24316;
      break;
    }
    default: heff_nomatch(v_x_24310);
    }
    V v_t_24320;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24318 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24320 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24318, v_o_24317});
      break;
    }
    case TAG_DLet: {
      V v_x_24319 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24320 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24319, v_o_24317});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24321 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24320, NTAG(TAG_Nil)});
    V v_x_24322 = (g_prelude_2e_2b_2b(v_t_24314, v_t_24321));
    return heff_tag_at_n(v_ru_24x2_24309_24MkPair, TAG_MkPair, 2, (V[]){v_x_24322, v_n_24311});
  }
  default: return heff_nomatch(v_x2_24309);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam18(V self, V *args) {
  V v_n_24326 = args[0];
  V v_m_24325 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24327 = heff_tr(heff_call(v_m_24325, 1, (V[]){v_n_24326}));
  switch (heff_tag_of(v_x2_24327)) {
  case TAG_MkPair: {
    V v_x_24328 = heff_field(v_x2_24327, 0);
    V v_n_24329 = heff_field(v_x2_24327, 1);
    V v_ru_24x2_24327_24MkPair = heff_take_reuse_n(v_x2_24327, 3ULL, 2);
    V v_t_24332;
    switch (heff_tag_of(v_x_24328)) {
    case TAG_MkPair: {
      V v_x_24330 = heff_dup(heff_field(v_x_24328, 0));
      v_t_24332 = v_x_24330;
      break;
    }
    default: heff_nomatch(v_x_24328);
    }
    V v_o_24335;
    switch (heff_tag_of(v_x_24328)) {
    case TAG_MkPair: {
      V v_y_24334 = heff_field(v_x_24328, 1);
      heff_take_n(v_x_24328, 2ULL, 2);
      v_o_24335 = v_y_24334;
      break;
    }
    default: heff_nomatch(v_x_24328);
    }
    V v_t_24338;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24336 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24338 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24336, v_o_24335});
      break;
    }
    case TAG_DLet: {
      V v_x_24337 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24338 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24337, v_o_24335});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24339 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24338, NTAG(TAG_Nil)});
    V v_x_24340 = (g_prelude_2e_2b_2b(v_t_24332, v_t_24339));
    return heff_tag_at_n(v_ru_24x2_24327_24MkPair, TAG_MkPair, 2, (V[]){v_x_24340, v_n_24329});
  }
  default: return heff_nomatch(v_x2_24327);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam19(V self, V *args) {
  V v_n_24343 = args[0];
  V v_m_24342 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24344 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_n_24343}));
  switch (heff_tag_of(v_x2_24344)) {
  case TAG_MkPair: {
    V v_x_24345 = heff_field(v_x2_24344, 0);
    V v_n_24346 = heff_field(v_x2_24344, 1);
    V v_ru_24x2_24344_24MkPair = heff_take_reuse_n(v_x2_24344, 3ULL, 2);
    V v_t_24349;
    switch (heff_tag_of(v_x_24345)) {
    case TAG_MkPair: {
      V v_x_24347 = heff_dup(heff_field(v_x_24345, 0));
      v_t_24349 = v_x_24347;
      break;
    }
    default: heff_nomatch(v_x_24345);
    }
    V v_o_24352;
    switch (heff_tag_of(v_x_24345)) {
    case TAG_MkPair: {
      V v_y_24351 = heff_field(v_x_24345, 1);
      heff_take_n(v_x_24345, 2ULL, 2);
      v_o_24352 = v_y_24351;
      break;
    }
    default: heff_nomatch(v_x_24345);
    }
    V v_t_24355;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24353 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24355 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24353, v_o_24352});
      break;
    }
    case TAG_DLet: {
      V v_x_24354 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24355 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24354, v_o_24352});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24356 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24355, NTAG(TAG_Nil)});
    V v_x_24357 = (g_prelude_2e_2b_2b(v_t_24349, v_t_24356));
    return heff_tag_at_n(v_ru_24x2_24344_24MkPair, TAG_MkPair, 2, (V[]){v_x_24357, v_n_24346});
  }
  default: return heff_nomatch(v_x2_24344);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam20(V self, V *args) {
  V v_n_24359 = args[0];
  V v_m_24358 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24360 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_n_24359}));
  switch (heff_tag_of(v_x2_24360)) {
  case TAG_MkPair: {
    V v_x_24361 = heff_field(v_x2_24360, 0);
    V v_n_24362 = heff_field(v_x2_24360, 1);
    V v_ru_24x2_24360_24MkPair = heff_take_reuse_n(v_x2_24360, 3ULL, 2);
    V v_t_24365;
    switch (heff_tag_of(v_x_24361)) {
    case TAG_MkPair: {
      V v_x_24363 = heff_dup(heff_field(v_x_24361, 0));
      v_t_24365 = v_x_24363;
      break;
    }
    default: heff_nomatch(v_x_24361);
    }
    V v_o_24368;
    switch (heff_tag_of(v_x_24361)) {
    case TAG_MkPair: {
      V v_y_24367 = heff_field(v_x_24361, 1);
      heff_take_n(v_x_24361, 2ULL, 2);
      v_o_24368 = v_y_24367;
      break;
    }
    default: heff_nomatch(v_x_24361);
    }
    V v_t_24371;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24369 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24371 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24369, v_o_24368});
      break;
    }
    case TAG_DLet: {
      V v_x_24370 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24371 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24370, v_o_24368});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24372 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24371, NTAG(TAG_Nil)});
    V v_x_24373 = (g_prelude_2e_2b_2b(v_t_24365, v_t_24372));
    return heff_tag_at_n(v_ru_24x2_24360_24MkPair, TAG_MkPair, 2, (V[]){v_x_24373, v_n_24362});
  }
  default: return heff_nomatch(v_x2_24360);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam21(V self, V *args) {
  V v_n_24377 = args[0];
  V v_m_24376 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24378 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_n_24377}));
  switch (heff_tag_of(v_x2_24378)) {
  case TAG_MkPair: {
    V v_x_24379 = heff_field(v_x2_24378, 0);
    V v_n_24380 = heff_field(v_x2_24378, 1);
    V v_ru_24x2_24378_24MkPair = heff_take_reuse_n(v_x2_24378, 3ULL, 2);
    V v_t_24383;
    switch (heff_tag_of(v_x_24379)) {
    case TAG_MkPair: {
      V v_x_24381 = heff_dup(heff_field(v_x_24379, 0));
      v_t_24383 = v_x_24381;
      break;
    }
    default: heff_nomatch(v_x_24379);
    }
    V v_o_24386;
    switch (heff_tag_of(v_x_24379)) {
    case TAG_MkPair: {
      V v_y_24385 = heff_field(v_x_24379, 1);
      heff_take_n(v_x_24379, 2ULL, 2);
      v_o_24386 = v_y_24385;
      break;
    }
    default: heff_nomatch(v_x_24379);
    }
    V v_t_24389;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24387 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24389 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24387, v_o_24386});
      break;
    }
    case TAG_DLet: {
      V v_x_24388 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24389 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24388, v_o_24386});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24390 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24389, NTAG(TAG_Nil)});
    V v_x_24391 = (g_prelude_2e_2b_2b(v_t_24383, v_t_24390));
    return heff_tag_at_n(v_ru_24x2_24378_24MkPair, TAG_MkPair, 2, (V[]){v_x_24391, v_n_24380});
  }
  default: return heff_nomatch(v_x2_24378);
  }
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eopTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopTail_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopTail(V v_g_240, V v_e_241) {
top: ;
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_241}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2eopTail_lam0, 1, 1, (V[]){v_m_242});
}
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopTail(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_n_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_n_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_ss_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_dup(heff_field(v_x_245, 0));
      v_ss_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ss_249)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_Cons: {
      v_t_2415 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_249, heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412})});
      break;
    }
    default: heff_nomatch(v_ss_249);
    }
    return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_n_246});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseTail_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseTail_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseTail(V v_g_240, V v_self_241, V v_s_242, V v_arms_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam0, 1, 4, (V[]){v_m_244, v_g_240, v_self_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseTail(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam1(V self, V *args) {
  V v_arm_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_self_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_arm_249, 0);
    V v_vs_2411 = heff_field(v_arm_249, 1);
    V v_b_2412 = heff_field(v_arm_249, 2);
    heff_take_n(v_arm_249, 7ULL, 3);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2412}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam2, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_arm_249);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam1, 1, 2, (V[]){v_g_240, v_self_241}), v_arms_243));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_ss_2424;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_247, 0));
        v_ss_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_247, 1);
        heff_take_n(v_x_247, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2430;
      switch (heff_tag_of(v_ss_2424)) {
      case TAG_Nil: {
        v_t_2430 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TCase, 2, (V[]){v_t_2427, v_x_2420});
        break;
      }
      case TAG_Cons: {
        v_t_2430 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2424, heff_tag_n(TAG_TCase, 2, (V[]){v_t_2427, v_x_2420})});
        break;
      }
      default: heff_nomatch(v_ss_2424);
      }
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etestTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etestTail_entry, 6, 0};

V g_heff_2ecompile_2eimperative_2etestTail(V v_g_240, V v_self_241, V v_s_242, V v_t_243, V v_f_244, V v_arms_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2etestTail_lam0, 1, 7, (V[]){v_m_246, v_g_240, v_self_241, v_s_242, v_arms_245, v_t_243, v_f_244});
}
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etestTail(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_245 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_f_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2411 = (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_242, v_arms_245));
      V f_ = v_t_2411;
      args[0] = v_n_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_245);
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 2)), 2, (V[]){heff_dup(v_self_241), v_t_243}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2410}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_n_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_f_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_n_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2412, v_x_2415, v_x_2419}), v_n_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etailOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etailOf_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2etailOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etailOf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etailOf(V v_g_240, V v_self_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EGlobal: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELam: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EApp: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eimperative_2esinkTest(heff_dup(v_y_249), heff_dup(v_a_2410), heff_dup(v_b_2411)));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_249, v_a_2410}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam0, 1, 4, (V[]){v_m_2413, v_g_240, v_self_241, v_b_2411});
    }
    case TAG_Just: {
      V v_e2_2435 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      heff_drop(v_y_249);
      heff_drop(v_a_2410);
      heff_drop(v_b_2411);
      return heff_tail(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_e2_2435});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EProj: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ETag: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EMatch: {
    V v_s_2445 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2446 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2447 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2446));
    V v_it_2453;
    if (heff_intEq_c(v_t_2447, MK_INT(2LL))) {
      V v_t_2449 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2etailOf_str0), v_arms_2446));
      switch (heff_tag_of(v_t_2449)) {
      case TAG_Nothing: {
        v_it_2453 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2450 = heff_field(v_t_2449, 0);
        V v_ru_24t_2449_24Just = heff_take_reuse_n(v_t_2449, 1ULL, 1);
        V v_t_2451 = (g_heff_2ecompile_2eimperative_2earmNamed(((V)&g_heff_2ecompile_2eimperative_2etailOf_str1), v_arms_2446));
        switch (heff_tag_of(v_t_2451)) {
        case TAG_Nothing: {
          heff_drop(v_t_2450);
          heff_drop_cell(v_ru_24t_2449_24Just, 1);
          v_it_2453 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2452 = heff_field(v_t_2451, 0);
          heff_take_n(v_t_2451, 1ULL, 1);
          v_it_2453 = heff_tag_at_n(v_ru_24t_2449_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_f_2452})});
          break;
        }
        default: heff_nomatch(v_t_2451);
        }
        break;
      }
      default: heff_nomatch(v_t_2449);
      }
    } else {
      v_it_2453 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2453)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_2445, v_arms_2446));
    }
    case TAG_Just: {
      V v_it1_2454 = heff_field(v_it_2453, 0);
      heff_take_n(v_it_2453, 1ULL, 1);
      switch (heff_tag_of(v_it1_2454)) {
      case TAG_MkPair: {
        V v_t_2455 = heff_field(v_it1_2454, 0);
        V v_f_2456 = heff_field(v_it1_2454, 1);
        heff_take_n(v_it1_2454, 3ULL, 2);
        V v_t_2457 = heff_dup(heff_rfield(v_g_240, 0));
        if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
          heff_drop(v_t_2457);
          switch (heff_tag_of(v_self_241)) {
          case TAG_Nothing: {
            V v_t_2458 = (g_heff_2ecompile_2eimperative_2econdShaped(heff_dup(v_t_2455)));
            if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
              heff_drop(v_t_2458);
              V v_t_2459 = (g_heff_2ecompile_2eimperative_2econdShaped(heff_dup(v_f_2456)));
              if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
                heff_drop(v_t_2459);
                V v_m_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
                return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam1, 1, 7, (V[]){v_m_2460, v_g_240, v_self_241, v_s_2445, v_t_2455, v_f_2456, v_arms_2446});
              } else {
                heff_drop_tag(v_e_242, 2);
                heff_drop(v_t_2459);
                return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2445, v_t_2455, v_f_2456, v_arms_2446));
              }
            } else {
              heff_drop_tag(v_e_242, 2);
              heff_drop(v_t_2458);
              return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2445, v_t_2455, v_f_2456, v_arms_2446));
            }
          }
          case TAG_Just: {
            heff_drop_tag(v_e_242, 2);
            return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2445, v_t_2455, v_f_2456, v_arms_2446));
          }
          default: return heff_nomatch(v_self_241);
          }
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_t_2457);
          return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2445, v_t_2455, v_f_2456, v_arms_2446));
        }
      }
      default: return heff_nomatch(v_it1_2454);
      }
    }
    default: return heff_nomatch(v_it_2453);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EPrimCall: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ECall: {
    V v_k_2472 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2473 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_self_241)) {
    case TAG_Nothing: {
      heff_drop(v_k_2472);
      heff_drop(v_as_2473);
      return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
    }
    case TAG_Just: {
      V v_s_2474 = heff_field(v_self_241, 0);
      heff_take_n(v_self_241, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_s_2474, 0)), v_k_2472)) {
        V v_t_2476 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2473));
        if (heff_intEq_c(v_t_2476, heff_get_n(v_s_2474, 1, 2))) {
          heff_drop_tag(v_e_242, 2);
          V v_m_2478 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_as_2473));
          return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam2, 1, 1, (V[]){v_m_2478});
        } else {
          heff_drop(v_as_2473);
          return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
        }
      } else {
        heff_drop(v_as_2473);
        heff_drop_rec(v_s_2474, 2);
        return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
      }
    }
    default: return heff_nomatch(v_self_241);
    }
  }
  case TAG_EInt: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EStr: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EBytes: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFixed: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat32: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EAbandon: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFix: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etailOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etailOf_lam0(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_b_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2411}));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2417}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_x_2434;
      switch (heff_tag_of(v_x_2416)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2419_24MkPair, 2);
        v_x_2434 = v_x_2420;
        break;
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_x_2420)) {
        case TAG_TSeq: {
          V v_ss2_2424 = heff_field(v_x_2420, 0);
          V v_t2_2425 = heff_field(v_x_2420, 1);
          heff_take_n(v_x_2420, 3ULL, 2);
          V v_t_2426 = (g_prelude_2e_2b_2b(v_x_2416, v_ss2_2424));
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_t_2426, v_t2_2425});
          break;
        }
        case TAG_TReturn: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        case TAG_TLoop: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        case TAG_TIf: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        case TAG_TCase: {
          v_x_2434 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_x_2416, v_x_2420});
          break;
        }
        default: heff_nomatch(v_x_2420);
        }
        break;
      }
      default: heff_nomatch(v_x_2416);
      }
      return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_x_2434, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam1(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_2445 = heff_env(self)[3];
  V v_t_2455 = heff_env(self)[4];
  V v_f_2456 = heff_env(self)[5];
  V v_arms_2446 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    switch (heff_tag_of(v_x_2463)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_2462_24MkPair, 2);
      V v_t_2465 = (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2445, v_t_2455, v_f_2456, v_arms_2446));
      V f_ = v_t_2465;
      args[0] = v_n_2464;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2466 = heff_field(v_x_2463, 0);
      V v_ru_24x_2463_24Just = heff_take_reuse_n(v_x_2463, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_2445);
      heff_drop(v_t_2455);
      heff_drop(v_f_2456);
      heff_drop(v_arms_2446);
      V v_t_2467 = heff_tag_at_n(v_ru_24x_2463_24Just, TAG_TReturn, 1, (V[]){heff_tag_n(TAG_OBool, 1, (V[]){v_c_2466})});
      return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){v_t_2467, v_n_2464});
    }
    default: return heff_nomatch(v_x_2463);
    }
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam2(V self, V *args) {
  V v_n_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2480 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_n_2479}));
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkPair: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    V v_n_2482 = heff_field(v_x2_2480, 1);
    V v_ru_24x2_2480_24MkPair = heff_take_reuse_n(v_x2_2480, 3ULL, 2);
    V v_ss_2485;
    switch (heff_tag_of(v_x_2481)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_dup(heff_field(v_x_2481, 0));
      v_ss_2485 = v_x_2483;
      break;
    }
    default: heff_nomatch(v_x_2481);
    }
    V v_t_2488;
    switch (heff_tag_of(v_x_2481)) {
    case TAG_MkPair: {
      V v_y_2487 = heff_field(v_x_2481, 1);
      heff_take_n(v_x_2481, 2ULL, 2);
      v_t_2488 = v_y_2487;
      break;
    }
    default: heff_nomatch(v_x_2481);
    }
    V v_t_2491;
    switch (heff_tag_of(v_ss_2485)) {
    case TAG_Nil: {
      v_t_2491 = heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2488});
      break;
    }
    case TAG_Cons: {
      v_t_2491 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_2485, heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2488})});
      break;
    }
    default: heff_nomatch(v_ss_2485);
    }
    return heff_tag_at_n(v_ru_24x2_2480_24MkPair, TAG_MkPair, 2, (V[]){v_t_2491, v_n_2482});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_heff_2ecompile_2eimperative_2etailSelf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etailSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etailSelf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etailSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_242, 1);
    return (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2etailSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2422));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_k_2431 = heff_field(v_e_242, 0);
    V v_as_2432 = heff_field(v_e_242, 1);
    if (heff_strEq_c_lent(v_k_2431, v_key_240, 2)) {
      V v_t_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2432));
      return heff_intEq(v_t_2434, v_n_241);
    } else {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etailSelf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eimperative_2etailSelf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eimperative_2etailSelf_lam0(V self, V *args) {
  V v_a_2423 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427;
  switch (heff_tag_of(v_a_2423)) {
  case TAG_MkArm: {
    V v_b_2426 = heff_field(v_a_2423, 2);
    heff_take_n(v_a_2423, 4ULL, 3);
    v_t_2427 = v_b_2426;
    break;
  }
  default: heff_nomatch(v_a_2423);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2427; V r_ = (g_heff_2ecompile_2eimperative_2etailSelf(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
}
Clo g_heff_2ecompile_2eimperative_2edefOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edefOf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2edefOf(V v_g_240, V v_d_241, V v_z_242) {
top: ;
  V v_it_243 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_it_243)) {
  case TAG_EVar: {
    V v_m_245 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_n_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_247})});
      V v_t_2410 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_249});
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, v_n_248});
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  case TAG_EGlobal: {
    V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2414})});
      V v_t_2417 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2416});
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  case TAG_ELam: {
    V v_xs_2418 = heff_field(v_it_243, 0);
    V v_b_2419 = heff_field(v_it_243, 1);
    V v_ru_24it_243_24ELam = heff_take_reuse_n(v_it_243, 3ULL, 2);
    V v_key_2420 = heff_dup(heff_rfield(v_d_241, 0));
    V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
    V v_t_2422 = (g_heff_2ecompile_2eimperative_2etailSelf(heff_dup(v_key_2420), v_t_2421, v_b_2419));
    V v_t_2424;
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__arity, (V[]){v_key_2420, v_t_2423})});
    } else {
      heff_drop(v_key_2420);
      heff_drop(v_t_2422);
      v_t_2424 = NTAG(TAG_Nothing);
    }
    V v_m_2425 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_t_2424, v_b_2419}));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      V v_t_2429 = heff_tag_at_n(v_ru_24it_243_24ELam, TAG_DefFun, 2, (V[]){v_xs_2418, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2427})});
      V v_t_2430 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2429});
      return heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_n_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  case TAG_EApp: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_n_2436 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      V v_t_2437 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2435})});
      V v_t_2438 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2437});
      return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2438, v_n_2436});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  case TAG_ELet: {
    V v_m_2442 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_n_2445 = heff_field(v_x2_2443, 1);
      V v_ru_24x2_2443_24MkPair = heff_take_reuse_n(v_x2_2443, 3ULL, 2);
      V v_t_2446 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2444})});
      V v_t_2447 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2446});
      return heff_tag_at_n(v_ru_24x2_2443_24MkPair, TAG_MkPair, 2, (V[]){v_t_2447, v_n_2445});
    }
    default: return heff_nomatch(v_x2_2443);
    }
  }
  case TAG_ERecord: {
    V v_m_2450 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_MkPair: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_n_2453 = heff_field(v_x2_2451, 1);
      V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
      V v_t_2454 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2452})});
      V v_t_2455 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2454});
      return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){v_t_2455, v_n_2453});
    }
    default: return heff_nomatch(v_x2_2451);
    }
  }
  case TAG_EProj: {
    V v_m_2460 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_n_2463 = heff_field(v_x2_2461, 1);
      V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
      V v_t_2464 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2462})});
      V v_t_2465 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2464});
      return heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_MkPair, 2, (V[]){v_t_2465, v_n_2463});
    }
    default: return heff_nomatch(v_x2_2461);
    }
  }
  case TAG_ETag: {
    V v_m_2469 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_n_2472 = heff_field(v_x2_2470, 1);
      V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
      V v_t_2473 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2471})});
      V v_t_2474 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2473});
      return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){v_t_2474, v_n_2472});
    }
    default: return heff_nomatch(v_x2_2470);
    }
  }
  case TAG_EMatch: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_n_2480 = heff_field(v_x2_2478, 1);
      V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
      V v_t_2481 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2479})});
      V v_t_2482 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2481});
      return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){v_t_2482, v_n_2480});
    }
    default: return heff_nomatch(v_x2_2478);
    }
  }
  case TAG_EPrim: {
    V v_m_2484 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_n_2487 = heff_field(v_x2_2485, 1);
      V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
      V v_t_2488 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2486})});
      V v_t_2489 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2488});
      return heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_MkPair, 2, (V[]){v_t_2489, v_n_2487});
    }
    default: return heff_nomatch(v_x2_2485);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2492 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_n_2495 = heff_field(v_x2_2493, 1);
      V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
      V v_t_2496 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2494})});
      V v_t_2497 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2496});
      return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_t_2497, v_n_2495});
    }
    default: return heff_nomatch(v_x2_2493);
    }
  }
  case TAG_ECall: {
    V v_m_24100 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24101 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_n_24103 = heff_field(v_x2_24101, 1);
      V v_ru_24x2_24101_24MkPair = heff_take_reuse_n(v_x2_24101, 3ULL, 2);
      V v_t_24104 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24102})});
      V v_t_24105 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24104});
      return heff_tag_at_n(v_ru_24x2_24101_24MkPair, TAG_MkPair, 2, (V[]){v_t_24105, v_n_24103});
    }
    default: return heff_nomatch(v_x2_24101);
    }
  }
  case TAG_EInt: {
    V v_m_24107 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_n_24110 = heff_field(v_x2_24108, 1);
      V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
      V v_t_24111 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24109})});
      V v_t_24112 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24111});
      return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){v_t_24112, v_n_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  case TAG_EFloat: {
    V v_m_24114 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_n_24117 = heff_field(v_x2_24115, 1);
      V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
      V v_t_24118 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24116})});
      V v_t_24119 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24118});
      return heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_MkPair, 2, (V[]){v_t_24119, v_n_24117});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  case TAG_EStr: {
    V v_m_24121 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24122 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24122)) {
    case TAG_MkPair: {
      V v_x_24123 = heff_field(v_x2_24122, 0);
      V v_n_24124 = heff_field(v_x2_24122, 1);
      V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
      V v_t_24125 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24123})});
      V v_t_24126 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24125});
      return heff_tag_at_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, (V[]){v_t_24126, v_n_24124});
    }
    default: return heff_nomatch(v_x2_24122);
    }
  }
  case TAG_EBytes: {
    V v_m_24128 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24129 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24129)) {
    case TAG_MkPair: {
      V v_x_24130 = heff_field(v_x2_24129, 0);
      V v_n_24131 = heff_field(v_x2_24129, 1);
      V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
      V v_t_24132 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24130})});
      V v_t_24133 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24132});
      return heff_tag_at_n(v_ru_24x2_24129_24MkPair, TAG_MkPair, 2, (V[]){v_t_24133, v_n_24131});
    }
    default: return heff_nomatch(v_x2_24129);
    }
  }
  case TAG_EFixed: {
    V v_m_24136 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24137 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x2_24137, 0);
      V v_n_24139 = heff_field(v_x2_24137, 1);
      V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
      V v_t_24140 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24138})});
      V v_t_24141 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24140});
      return heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_MkPair, 2, (V[]){v_t_24141, v_n_24139});
    }
    default: return heff_nomatch(v_x2_24137);
    }
  }
  case TAG_EFloat32: {
    V v_m_24143 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24144 = heff_tr(heff_call(v_m_24143, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24144)) {
    case TAG_MkPair: {
      V v_x_24145 = heff_field(v_x2_24144, 0);
      V v_n_24146 = heff_field(v_x2_24144, 1);
      V v_ru_24x2_24144_24MkPair = heff_take_reuse_n(v_x2_24144, 3ULL, 2);
      V v_t_24147 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24145})});
      V v_t_24148 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24147});
      return heff_tag_at_n(v_ru_24x2_24144_24MkPair, TAG_MkPair, 2, (V[]){v_t_24148, v_n_24146});
    }
    default: return heff_nomatch(v_x2_24144);
    }
  }
  case TAG_EAbandon: {
    V v_m_24149 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24150 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24150)) {
    case TAG_MkPair: {
      V v_x_24151 = heff_field(v_x2_24150, 0);
      V v_n_24152 = heff_field(v_x2_24150, 1);
      V v_ru_24x2_24150_24MkPair = heff_take_reuse_n(v_x2_24150, 3ULL, 2);
      V v_t_24153 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24151})});
      V v_t_24154 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24153});
      return heff_tag_at_n(v_ru_24x2_24150_24MkPair, TAG_MkPair, 2, (V[]){v_t_24154, v_n_24152});
    }
    default: return heff_nomatch(v_x2_24150);
    }
  }
  case TAG_EFix: {
    V v_m_24157 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24158 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24158)) {
    case TAG_MkPair: {
      V v_x_24159 = heff_field(v_x2_24158, 0);
      V v_n_24160 = heff_field(v_x2_24158, 1);
      V v_ru_24x2_24158_24MkPair = heff_take_reuse_n(v_x2_24158, 3ULL, 2);
      V v_t_24161 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24159})});
      V v_t_24162 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24161});
      return heff_tag_at_n(v_ru_24x2_24158_24MkPair, TAG_MkPair, 2, (V[]){v_t_24162, v_n_24160});
    }
    default: return heff_nomatch(v_x2_24158);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ecompile_2eimperative_2edefOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edefOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsOp_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsOp_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsOp(V v_r_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_243 = heff_dup(heff_field(v_o_241, 0));
    V v_t_244 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 5), 2, (V[]){v_v_243, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_244});
  }
  case TAG_OCall: {
    V v_as_246 = heff_dup(heff_field(v_o_241, 1));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_246));
    V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsOp_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2410});
  }
  case TAG_OApply: {
    V v_f_2411 = heff_dup(heff_field(v_o_241, 0));
    V v_as_2412 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_2411, v_as_2412})));
    V v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsOp_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2416});
  }
  case TAG_OPrim: {
    V v_as_2418 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2418));
    V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsOp_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2422});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_acc_242});
  }
  case TAG_OBool: {
    V v_c_2423 = heff_dup(heff_field(v_o_241, 0));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 2, (V[]){v_c_2423, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2424});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_249;
  args[1] = v_acc_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam1(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_x_2415 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2415;
  args[1] = v_acc_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam2(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_x_2421 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2421;
  args[1] = v_acc_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsCond(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_PFalse: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_PRel: {
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_b_245 = heff_field(v_x2_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_b_245), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_a_244), v_t_246});
  }
  case TAG_PBool: {
    V v_v_247 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_247), v_acc_242});
  }
  case TAG_PNot: {
    V v_c_248 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_248), v_acc_242});
  }
  case TAG_PIf: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_b_2410 = heff_field(v_x2_241, 1);
    V v_c_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){heff_dup(v_c_2411), v_acc_242}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){heff_dup(v_b_2410), v_t_2412}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_a_249), v_t_2413});
  }
  case TAG_PLet: {
    V v_o_2415 = heff_field(v_x2_241, 1);
    V v_c_2416 = heff_field(v_x2_241, 2);
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 2, (V[]){heff_dup(v_c_2416), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_2415), v_t_2417});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2epartsCond(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimperative_2epartsSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsSt_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsSt(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLet: {
    V v_o_244 = heff_field(v_x2_241, 1);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_244), v_acc_242});
  }
  case TAG_SDecl: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_SSet: {
    V v_o_247 = heff_field(v_x2_241, 1);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_247), v_acc_242});
  }
  case TAG_SIf: {
    V v_c_248 = heff_field(v_x2_241, 0);
    V v_ts_249 = heff_field(v_x2_241, 1);
    V v_fs_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 3)), 2, (V[]){heff_dup(v_fs_2410), v_acc_242}));
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_r_240, 3), 2, (V[]){heff_dup(v_ts_249), v_t_2411}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_248), v_t_2412});
  }
  case TAG_SCase: {
    V v_v_2413 = heff_field(v_x2_241, 0);
    V v_arms_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
    V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsSt_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_acc_242; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_2413), v_t_2421});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsSt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2epartsSt(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimperative_2epartsSt_lam0(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkArm: {
    V v_ss_2420 = heff_field(v_x_2417, 2);
    heff_take_n(v_x_2417, 4ULL, 3);
    V f_ = heff_get_n(v_r_240, 3, 5);
    args[0] = v_ss_2420;
    args[1] = v_acc_2416;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam0, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam1, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam2, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam3, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam5, 2, 0};

static V g_heff_2ecompile_2eimperative_2epk_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2epk_st;
static V g_heff_2ecompile_2eimperative_2epk_init(void) {
  return heff_rec_n(5, shape_val__op__cond__sts__tl, (V[]){((V)&g_heff_2ecompile_2eimperative_2epk_lam0_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam1_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam2_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam3_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam5_clo)});
}
V g_heff_2ecompile_2eimperative_2epk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2epk_st)) return g_heff_2ecompile_2eimperative_2epk_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2epk_val, &g_heff_2ecompile_2eimperative_2epk_st, g_heff_2ecompile_2eimperative_2epk_init);
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args) {
  V v_v_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsVal(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_v_240, v_acc_241));
}
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args) {
  V v_o_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsOp(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_o_242, v_acc_243));
}
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args) {
  V v_c_244 = args[0];
  V v_acc_245 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get()); V a_1 = v_c_244; V a_2 = v_acc_245; V r_ = (g_heff_2ecompile_2eimperative_2epartsCond(a_0, a_1, a_2)); heff_drop(v_c_244); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_248; V a_1 = v_x_2411; V a_2 = v_acc_2410; V r_ = (g_heff_2ecompile_2eimperative_2epartsSt(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args) {
  V v_ss_246 = args[0];
  V v_acc_247 = args[1];
  V v_r_248 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam4, 2, 1, (V[]){v_r_248}); V a_1 = v_acc_247; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args) {
  V v_t_2412 = args[0];
  V v_acc_2413 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get()); V a_1 = v_t_2412; V a_2 = v_acc_2413; V r_ = (g_heff_2ecompile_2eimperative_2epartsTl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V v_v_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SPrimFn: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SLam: {
    V v_v2_2413 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2413)) {
    case TAG_MkBlock: {
      V v_t_2414 = heff_field(v_v2_2413, 0);
      V v_ru_24v2_2413_24MkBlock = heff_take_reuse_n(v_v2_2413, 1ULL, 1);
      V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2413_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2415});
    }
    default: return heff_nomatch(v_v2_2413);
    }
  }
  case TAG_STag: {
    V v_as_2417 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2417));
    V v_t_2420 = ({ V a_0 = v_acc_241; V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2420});
  }
  case TAG_SRec: {
    V v_fs_2421 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2423 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2421));
    V v_t_2424 = ({ V a_0 = v_acc_241; V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2423); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2424});
  }
  case TAG_SProj: {
    V v_w_2425 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2430 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(v_w_2425, v_acc_241, heff_dup(v_cell_2429)));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  case TAG_SPrim: {
    V v_as_2432 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2432));
    V v_t_2434 = ({ V a_0 = v_acc_241; V a_1 = v_t_2433; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2433); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2434});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V v_v_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
  }
  case TAG_SGlobal: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_SInt: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_SFloat: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
  }
  case TAG_SStr: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2412);
  }
  case TAG_SBytes: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
  }
  case TAG_SFixed: {
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2417);
  }
  case TAG_SFloat32: {
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2419);
  }
  case TAG_SPrimFn: {
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2421);
  }
  case TAG_SLam: {
    V v_v2_2423 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2423)) {
    case TAG_MkBlock: {
      V v_t_2424 = heff_field(v_v2_2423, 0);
      V v_ru_24v2_2423_24MkBlock = heff_take_reuse_n(v_v2_2423, 1ULL, 1);
      V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2423_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2425});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2426);
    }
    default: return heff_nomatch(v_v2_2423);
    }
  }
  case TAG_STag: {
    V v_as_2428 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2428));
    V v_t_2431 = ({ V a_0 = v_acc_241; V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2431});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2432);
  }
  case TAG_SRec: {
    V v_fs_2433 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2435 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2433));
    V v_t_2436 = ({ V a_0 = v_acc_241; V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2436});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2437);
  }
  case TAG_SProj: {
    V v_w_2438 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2443 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2442));
    heff_drop(v_u_2443);
    V t_0 = v_w_2438;
    V t_1 = v_acc_241;
    V t_2 = v_cell_2442;
    v_v_240 = t_0;
    v_acc_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_as_2445 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2445));
    V v_t_2447 = ({ V a_0 = v_acc_241; V a_1 = v_t_2446; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2446); r_; });
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2447});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2448);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return v_acc_241;
  }
  case TAG_PFalse: {
    return v_acc_241;
  }
  case TAG_PRel: {
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    V v_acc_245 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_b_244), v_acc_241));
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_a_243), v_acc_245);
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_v_246), v_acc_241);
  }
  case TAG_PNot: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V t_0 = v_c_247;
    V t_1 = v_acc_241;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_PIf: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_c_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2410), v_acc_241}));
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_b_249), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_a_248), v_t_2412});
  }
  case TAG_PLet: {
    V v_o_2414 = heff_field(v_x2_240, 1);
    V v_c_2415 = heff_field(v_x2_240, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2415), v_acc_241}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_2414), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V v_o_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_242 = heff_dup(heff_field(v_o_240, 0));
    V v_t_243 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_242, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_243});
  }
  case TAG_OCall: {
    V v_as_245 = heff_dup(heff_field(v_o_240, 1));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_245));
    V v_t_247 = ({ V a_0 = v_acc_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_247});
  }
  case TAG_OApply: {
    V v_f_248 = heff_dup(heff_field(v_o_240, 0));
    V v_as_249 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_as_249})));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2411});
  }
  case TAG_OPrim: {
    V v_as_2413 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2413));
    V v_t_2415 = ({ V a_0 = v_acc_241; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2415});
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_acc_241});
  }
  case TAG_OBool: {
    V v_c_2416 = heff_dup(heff_field(v_o_240, 0));
    V v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2416); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2417});
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 1);
    V v_acc_244 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_243, v_acc_241));
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_242)));
    return ({ V a_0 = v_acc_244; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_240, 0);
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_246), v_acc_241});
  }
  case TAG_TLoop: {
    V v_vs_247 = heff_field(v_x2_240, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1299324685x840794767(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_TIf: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_t_2410 = heff_field(v_x2_240, 1);
    V v_e_2411 = heff_field(v_x2_240, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 4)), 2, (V[]){heff_dup(v_e_2411), v_acc_241}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 4)), 2, (V[]){heff_dup(v_t_2410), v_t_2412}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_249), v_t_2413});
  }
  case TAG_TCase: {
    V v_v_2414 = heff_field(v_x2_240, 0);
    V v_arms_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2415)));
    V v_t_2417 = ({ V a_0 = v_acc_241; V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s788715611x32297348(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2414), v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopNamesTop_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eopNamesTop(V v_o_240) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_241 = heff_field(v_o_240, 0);
    heff_take_n(v_o_240, 1ULL, 1);
    return ({ V a_0 = v_v_241; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_241); r_; });
  }
  case TAG_OCall: {
    V v_as_243 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_243));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_OApply: {
    V v_f_245 = heff_field(v_o_240, 0);
    V v_as_246 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OApply = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24o_240_24OApply, TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  case TAG_OPrim: {
    V v_as_249 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_249));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_o_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopNamesTop(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2efirstNamesTl_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2efirstNamesTl(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_TSeq: {
    V v_t1_241 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_t1_241)) {
    case TAG_Nil: {
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_st_243 = heff_field(v_t1_241, 0);
      switch (heff_tag_of(v_st_243)) {
      case TAG_SLet: {
        V v_o_246 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_246));
      }
      case TAG_SDecl: {
        return NTAG(TAG_Nil);
      }
      case TAG_SSet: {
        V v_o_249 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_249));
      }
      case TAG_SIf: {
        return NTAG(TAG_Nil);
      }
      case TAG_SCase: {
        V v_v_2413 = heff_field(v_st_243, 0);
        return (g_heff_2ecompile_2eimperative_2evalNamesTop(v_v_2413, NTAG(TAG_Nil)));
      }
      default: return heff_nomatch(v_st_243);
      }
    }
    default: return heff_nomatch(v_t1_241);
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_t_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_2415));
  }
  case TAG_TLoop: {
    V v_vs_2416 = heff_field(v_t_240, 0);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2416)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_TIf: {
    return NTAG(TAG_Nil);
  }
  case TAG_TCase: {
    V v_v_2421 = heff_field(v_t_240, 0);
    return (g_heff_2ecompile_2eimperative_2evalNamesTop(v_v_2421, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2efirstNamesTl(a0); heff_drop(a0); return r;
}