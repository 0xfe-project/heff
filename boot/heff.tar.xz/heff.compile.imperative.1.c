// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_DSets 40405
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_IntShl 35657
#define TAG_IntShr 35663
#define TAG_Keep 49586
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_Panic 15447
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SOnce 21704
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_arity 294440695
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_full 9650006
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_toDest 1077793512
#define LBL_underLam 296337946
#define LBL_val 326043
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo;
V g_heff_2ecompile_2eimperative_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo;
V g_heff_2ecompile_2eimperative_2econdIf(V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_clo;
V g_heff_2ecompile_2eimperative_2econdIf_24dps(V, V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo;
V g_heff_2ecompile_2eimperative_2econdPred(V, V);
V g_heff_2ecompile_2eimperative_2econdPred_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdPred_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore(V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24dps_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965(V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps_clo;
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1_clo;
HeffT4 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2einlinable(V, V, V, V);
V g_heff_2ecompile_2eimperative_2einlinable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2einlinable_clo;
V g_heff_2ecompile_2eimperative_2eisRelCall(V);
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchSet_clo;
V g_heff_2ecompile_2eimperative_2ematchTo(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchTo_clo;
V g_heff_2ecompile_2eimperative_2eonceSt(V, V);
V g_heff_2ecompile_2eimperative_2eonceSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSt_clo;
V g_heff_2ecompile_2eimperative_2eonceSts(V, V, V);
V g_heff_2ecompile_2eimperative_2eonceSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceSts_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(V, V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2_clo;
V g_heff_2ecompile_2eimperative_2eopTail(V, V);
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopTail_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok2_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
V g_heff_2ecompile_2eimperative_2epredLets_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epredLets_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_24tok1_clo;
V g_heff_2ecompile_2eimperative_2esetsOf(V, V, V);
V g_heff_2ecompile_2eimperative_2esetsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esetsOf_clo;
V g_heff_2ecompile_2eimperative_2esimpleOf(V, V);
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo;
HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailOf_clo;
V g_heff_2ecompile_2eimperative_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etestTail_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2econdExpr(V);
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdExpr_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s392821322x1502625120(V);
V g_list_2eall_24s392821322x1502625120_entry(V self, V *a);
extern Clo g_list_2eall_24s392821322x1502625120_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s398044887x377101364(V, V, V);
V g_list_2eany_24s398044887x377101364_entry(V self, V *a);
extern Clo g_list_2eany_24s398044887x377101364_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f1663632568x709545076(V, V, V, V);
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1663632568x709545076_clo;
V g_list_2efoldl_24f2029054136x351940068(V, V, V, V);
V g_list_2efoldl_24f2029054136x351940068_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2029054136x351940068_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2emap_24s94444922x1860431141(V);
V g_list_2emap_24s94444922x1860431141_entry(V self, V *a);
extern Clo g_list_2emap_24s94444922x1860431141_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f339900781x1605227681(V, V);
V g_prelude_2e_2b_2b_24f339900781x1605227681_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f339900781x1605227681_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s1887447647x928396251(V, V);
V g_prelude_2etraverse_24s1887447647x928396251_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1887447647x928396251_clo;
Clo g_heff_2ecompile_2eimperative_2eisSimple_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisSimple_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisSimple(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_list_2eall_24s392821322x1502625120(v_fs_2410);
  }
  case TAG_EProj: {
    V v_e_2412 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2417 = heff_field(v_x1_240, 1);
    return (g_list_2eall(((V)&g_heff_2ecompile_2eimperative_2eisSimple_clo), v_args_2417));
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_x1_240, 0);
    V v_args_2423 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_p_2422)) {
    case TAG_IntShl: {
      return NTAG(TAG_False);
    }
    case TAG_IntShr: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndex: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayGenerate: {
      return NTAG(TAG_False);
    }
    case TAG_Keep: {
      return NTAG(TAG_False);
    }
    case TAG_Panic: {
      return NTAG(TAG_False);
    }
    case TAG_Perform: {
      return NTAG(TAG_False);
    }
    case TAG_PerformAt: {
      return NTAG(TAG_False);
    }
    case TAG_BocWhen: {
      return NTAG(TAG_False);
    }
    case TAG_BocNew: {
      return NTAG(TAG_False);
    }
    case TAG_BocTaken: {
      return NTAG(TAG_False);
    }
    case TAG_BocGiven: {
      return NTAG(TAG_False);
    }
    case TAG_ArrayIndexIn: {
      return NTAG(TAG_False);
    }
    case TAG_FuelTick: {
      return NTAG(TAG_False);
    }
    case TAG_FuelTicks: {
      return NTAG(TAG_False);
    }
    case TAG_CustodianDue: {
      return NTAG(TAG_False);
    }
    case TAG_CustodyIn: {
      return NTAG(TAG_False);
    }
    default: {
      return (g_list_2eall(((V)&g_heff_2ecompile_2eimperative_2eisSimple_clo), v_args_2423));
    }
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisSimple(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str3, 5, "False");
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    V v_z_249 = heff_field(v_b_242, 0);
    V v_b2_2410 = heff_field(v_b_242, 1);
    V v_e_2411 = heff_field(v_b_242, 2);
    V v_ru_24b_242_24ELet = heff_take_reuse_n(v_b_242, 7ULL, 3);
    switch (heff_tag_of(v_b2_2410)) {
    case TAG_EVar: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_b2_2410, 0ULL, 4);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      V v_b21_2430 = heff_field(v_b2_2410, 0);
      V v_arms_2431 = heff_field(v_b2_2410, 1);
      V v_ru_24b2_2410_24EMatch = heff_take_reuse_n(v_b2_2410, 3ULL, 2);
      switch (heff_tag_of(v_b21_2430)) {
      case TAG_EVar: {
        V v_y_2432 = heff_field(v_b21_2430, 0);
        heff_take_n(v_b21_2430, 1ULL, 1);
        V v_t_24208;
        if (heff_strEq_c_lent(v_x_240, v_y_2432, 2)) {
          if (({ V v_c_24218 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_a_241)); int c_ = (heff_dup(v_c_24218) == NTAG(TAG_True)); heff_drop(v_c_24218); c_; })) {
            V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2431));
            V v_t_24222;
            if (heff_intEq_c(v_t_2433, MK_INT(2LL))) {
              HeffT2 v_t_2434 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str0); V a_1 = v_arms_2431; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2436 = v_t_2434.f[1];
                int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
                if ((v_tag_2435 == ((int64_t)0ULL))) {
                  V v_t_2437 = v_field_2436;
                  heff_drop(v_t_2437);
                  HeffT2 v_t_2438 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str1); V a_1 = v_arms_2431; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
                  {
                    V v_field_2440 = v_t_2438.f[1];
                    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                    v_t_24222 = heff_bool(((v_tag_2439 == ((int64_t)0ULL)) && ({ V v_f_2441 = heff_dup(v_field_2440); int c_ = 1; heff_drop(v_f_2441); c_; })));
                    heff_drop(v_field_2440);
                  }
                } else {
                  heff_drop(v_field_2436);
                  v_t_24222 = NTAG(TAG_False);
                }
              }
            } else {
              v_t_24222 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_t_24222)) {
            case TAG_True: {
              v_t_24208 = heff_bool(({ V v_x1_2452 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), v_arms_2431)); int c_ = ((heff_dup(v_x1_2452) == NTAG(TAG_True)) ? 0 : ({ V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2454 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), heff_dup(v_t_2453))); int c_ = ({ V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2456 = (g_heff_2ecompile_2eir_2elamW(v_x_240, heff_dup(v_t_2455))); int c_ = ({ V v_t_24223 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2454), heff_dup(v_t_2456)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_24223, MK_INT(0LL), 2); heff_drop(v_t_24223); c_; }); heff_drop(v_t_2456); c_; }); heff_drop(v_t_2455); c_; }); heff_drop(v_t_2454); c_; }); heff_drop(v_t_2453); c_; })); heff_drop(v_x1_2452); c_; }));
              break;
            }
            case TAG_False: {
              v_t_24208 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_24222);
            }
          } else {
            v_t_24208 = NTAG(TAG_False);
          }
        } else {
          v_t_24208 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_24208)) {
        case TAG_True: {
          V v_t_2457 = heff_tag_re_n(v_ru_24b_242_24ELet, TAG_ELet, 3, 5ULL, (V[]){v_z_249, heff_tag_re_n(v_ru_24b2_2410_24EMatch, TAG_EMatch, 2, 2ULL, (V[]){v_a_241, v_arms_2431}), v_e_2411});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2457}});
        }
        case TAG_False: {
          heff_drop(v_a_241);
          heff_drop(v_z_249);
          heff_drop(v_e_2411);
          heff_drop_cell(v_ru_24b_242_24ELet, 3);
          heff_drop(v_arms_2431);
          heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_24208)}});
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELet: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERecord: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProj: {
        heff_take_n(v_b21_2430, 0ULL, 4);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrim: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECall: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat: {
        heff_take_nf(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStr: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBytes: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFixed: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat32: {
        heff_take_na(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAbandon: {
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBool: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESet: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EValues: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFix: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_b21_2430)}});
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_b2_2410)}});
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_b_242, 0ULL, 4);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_b_242, 0ULL, 3);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_b1_24124 = heff_field(v_b_242, 0);
    V v_arms_24125 = heff_field(v_b_242, 1);
    V v_ru_24b_242_24EMatch = heff_take_reuse_n(v_b_242, 3ULL, 2);
    switch (heff_tag_of(v_b1_24124)) {
    case TAG_EVar: {
      V v_y_24126 = heff_field(v_b1_24124, 0);
      heff_take_n(v_b1_24124, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_24126, 2)) {
        V v_t_24127 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_a_241));
        if ((heff_dup(v_t_24127) == NTAG(TAG_True))) {
          heff_drop(v_t_24127);
          V v_t_24128 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24125));
          if (heff_intEq_c(v_t_24128, MK_INT(2LL))) {
            HeffT2 v_t_24129 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str2); V a_1 = v_arms_24125; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
            {
              V v_field_24131 = v_t_24129.f[1];
              int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
              if ((v_tag_24130 == ((int64_t)0ULL))) {
                V v_t_24132 = v_field_24131;
                heff_drop(v_t_24132);
                HeffT2 v_t_24133 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str3); V a_1 = v_arms_24125; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
                {
                  V v_field_24135 = v_t_24133.f[1];
                  int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                  if ((v_tag_24134 == ((int64_t)0ULL))) {
                    V v_f_24136 = v_field_24135;
                    heff_drop(v_f_24136);
                    V v_x1_24147 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam1, 1, 1, (V[]){heff_dup(v_x_240)}), v_arms_24125));
                    if (!(heff_dup(v_x1_24147) == NTAG(TAG_True))) {
                      heff_drop(v_x1_24147);
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_re_n(v_ru_24b_242_24EMatch, TAG_EMatch, 2, 2ULL, (V[]){v_a_241, v_arms_24125})}});
                    } else {
                      heff_drop(v_a_241);
                      heff_drop(v_arms_24125);
                      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                      heff_drop(v_x1_24147);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  } else {
                    heff_drop(v_a_241);
                    heff_drop(v_arms_24125);
                    heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                    heff_drop(v_field_24135);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop(v_a_241);
                heff_drop(v_arms_24125);
                heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                heff_drop(v_field_24131);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_a_241);
            heff_drop(v_arms_24125);
            heff_drop_cell(v_ru_24b_242_24EMatch, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_a_241);
          heff_drop(v_arms_24125);
          heff_drop_cell(v_ru_24b_242_24EMatch, 2);
          heff_drop(v_t_24127);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_a_241);
        heff_drop(v_arms_24125);
        heff_drop_cell(v_ru_24b_242_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_b1_24124, 0ULL, 3);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_b1_24124, 0ULL, 4);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_b1_24124, 0ULL, 3);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_nf(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_b1_24124, 0ULL, 3);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_b1_24124, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_b1_24124, 0ULL, 2);
      heff_drop(v_a_241);
      heff_drop(v_arms_24125);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_b1_24124)}});
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_nf(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_b_242, 0ULL, 3);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_b_242)}});
  }
}
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam0(V self, V *args) {
  V v_a_2442 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_2446;
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_b_2445 = heff_field(v_a_2442, 2);
    heff_take_n(v_a_2442, 4ULL, 3);
    v_e_2446 = v_b_2445;
    break;
  }
  default: heff_nomatch(v_a_2442);
  }
  V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2446), NTAG(TAG_Nil)});
  V v_t_2448 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_2447));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2446, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  V v_t_2450 = ({ V a_0 = v_x_240; V a_1 = v_t_2449; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_240); r_; });
  V v_x_2451 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2448, v_t_2450}), 0, 2);
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2451, 1));
  heff_drop(v_x_2451);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam1(V self, V *args) {
  V v_a_24137 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_24141;
  switch (heff_tag_of(v_a_24137)) {
  case TAG_MkArm: {
    V v_b_24140 = heff_field(v_a_24137, 2);
    heff_take_n(v_a_24137, 4ULL, 3);
    v_e_24141 = v_b_24140;
    break;
  }
  default: heff_nomatch(v_a_24137);
  }
  V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_24141), NTAG(TAG_Nil)});
  V v_t_24143 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_24142));
  V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_24141, NTAG(TAG_Nil)});
  heff_clo_take(self, 1);
  V v_t_24145 = ({ V a_0 = v_x_240; V a_1 = v_t_24144; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_240); r_; });
  V v_x_24146 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24143, v_t_24145}), 0, 2);
  V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_24146, 1));
  heff_drop(v_x_24146);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2eimperative_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2econdIf(V v_x1_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_PNot: {
    V v_c_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_243;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PIf: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_c_246 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2440;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      break;
    }
    case TAG_PRel: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x1_240_24PIf, 3);
      heff_drop(v_t_2440);
      V v_t_2441 = (g_heff_2ecompile_2eimperative_2econdIf(v_b_245, heff_dup(v_t_241), heff_dup(v_e_242)));
      V v_t_2442 = (g_heff_2ecompile_2eimperative_2econdIf(v_c_246, v_t_241, v_e_242));
      V t_0 = v_a_244;
      V t_1 = v_t_2441;
      V t_2 = v_t_2442;
      v_x1_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2440);
      return heff_tag_at_n(v_ru_24x1_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_244, v_b_245, v_c_246}), v_t_241, v_e_242});
    }
  }
  case TAG_PLet: {
    V v_x_2443 = heff_field(v_x1_240, 0);
    V v_o_2444 = heff_field(v_x1_240, 1);
    V v_c_2445 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PLet = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_cell_2446 = heff_tag_re_n(v_ru_24x1_240_24PLet, TAG_PLet, 3, 3ULL, (V[]){v_x_2443, v_o_2444, heff_hole()});
    V v_u_2447 = (g_heff_2ecompile_2eimperative_2econdIf_24dps(v_c_2445, v_t_241, v_e_242, v_cell_2446));
    heff_drop(v_u_2447);
    return v_cell_2446;
  }
  default: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_x1_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_x1_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  }
}
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdIf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2econdPred_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2econdPred_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdPred_lam0, 1, 0};
V g_heff_2ecompile_2eimperative_2econdPred_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2econdPred_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdPred_lam1, 1, 0};
V g_heff_2ecompile_2eimperative_2econdPred_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2econdPred_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2econdPred_lam4(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2econdPred_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdPred_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2econdPred(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2econdPred_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2econdPred_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_246 = heff_field(v_x2_241, 0);
    V v_a_247 = heff_field(v_x2_241, 1);
    V v_b_248 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_g_249 = v_g_240;
    V v_p_2410 = v_p_246;
    V v_a_2411 = v_a_247;
    V v_b_2412 = v_b_248;
    V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_249, 5)), 1, (V[]){v_a_2411}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2econdPred_lam2, 1, 4, (V[]){v_m_2413, v_g_249, v_b_2412, v_p_2410});
  }
  case TAG_CTest: {
    V v_e_2436 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tail(heff_get_n(v_g_240, 7, 8), 1, (V[]){v_e_2436});
  }
  case TAG_CNot: {
    V v_c_2437 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_2438 = heff_tr(g_heff_2ecompile_2eimperative_2econdPred(v_g_240, v_c_2437));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2econdPred_lam3, 1, 1, (V[]){v_m_2438});
  }
  case TAG_CIf: {
    V v_a_2446 = heff_field(v_x2_241, 0);
    V v_b_2447 = heff_field(v_x2_241, 1);
    V v_c_2448 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2449 = heff_tr(g_heff_2ecompile_2eimperative_2econdPred(heff_dup(v_g_240), v_a_2446));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2econdPred_lam4, 1, 4, (V[]){v_m_2449, v_g_240, v_b_2447, v_c_2448});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2econdPred_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdPred(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2econdPred_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PTrue)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_n_242});
}
V g_heff_2ecompile_2eimperative_2econdPred_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_PFalse)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_n_244});
}
V g_heff_2ecompile_2eimperative_2econdPred_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_g_249 = heff_env(self)[1];
  V v_b_2412 = heff_env(self)[2];
  V v_p_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_g_249, 5, 8), 1, (V[]){v_b_2412}));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2417}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_t_2424;
      switch (heff_tag_of(v_x_2416)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_2416, 0));
        v_t_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_2416);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_2420)) {
      case TAG_MkPair: {
        V v_x_2425 = heff_dup(heff_field(v_x_2420, 0));
        v_t_2427 = v_x_2425;
        break;
      }
      default: heff_nomatch(v_x_2420);
      }
      V v_t_2428 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2419_24MkPair, v_t_2424, v_t_2427));
      V v_t_2431;
      switch (heff_tag_of(v_x_2416)) {
      case TAG_MkPair: {
        V v_y_2430 = heff_field(v_x_2416, 1);
        heff_take_n(v_x_2416, 2ULL, 2);
        v_t_2431 = v_y_2430;
        break;
      }
      default: heff_nomatch(v_x_2416);
      }
      V v_t_2434;
      switch (heff_tag_of(v_x_2420)) {
      case TAG_MkPair: {
        V v_y_2433 = heff_field(v_x_2420, 1);
        heff_take_n(v_x_2420, 2ULL, 2);
        v_t_2434 = v_y_2433;
        break;
      }
      default: heff_nomatch(v_x_2420);
      }
      V v_x_2435 = ({ V a_0 = v_t_2428; V a_1 = heff_tag_n(TAG_PRel, 3, (V[]){v_p_2410, v_t_2431, v_t_2434}); V r_ = (g_heff_2ecompile_2eimperative_2epredLets(a_0, a_1)); heff_drop(v_t_2428); r_; });
      return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2econdPred_lam3(V self, V *args) {
  V v_n_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_n_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_n_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    V v_x_2445;
    switch (heff_tag_of(v_x_2441)) {
    case TAG_Nothing: {
      v_x_2445 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_q_2443 = heff_field(v_x_2441, 0);
      V v_ru_24x_2441_24Just = heff_take_reuse_n(v_x_2441, 1ULL, 1);
      V v_t_2444 = (g_heff_2ecompile_2eimperative_2econdIf(v_q_2443, NTAG(TAG_PFalse), NTAG(TAG_PTrue)));
      v_x_2445 = heff_tag_at_n(v_ru_24x_2441_24Just, TAG_Just, 1, (V[]){v_t_2444});
      break;
    }
    default: heff_nomatch(v_x_2441);
    }
    return heff_tag_re_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2445, v_n_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eimperative_2econdPred_lam4(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_b_2447 = heff_env(self)[2];
  V v_c_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    V v_t_2454 = heff_tr(g_heff_2ecompile_2eimperative_2econdPred(heff_dup(v_g_240), v_b_2447));
    V v_x2_2455 = heff_tr(heff_call(v_t_2454, 1, (V[]){v_n_2453}));
    switch (heff_tag_of(v_x2_2455)) {
    case TAG_MkPair: {
      V v_x_2456 = heff_field(v_x2_2455, 0);
      V v_n_2457 = heff_field(v_x2_2455, 1);
      heff_take_n(v_x2_2455, 3ULL, 2);
      V v_t_2458 = heff_tr(g_heff_2ecompile_2eimperative_2econdPred(v_g_240, v_c_2448));
      V v_x2_2459 = heff_tr(heff_call(v_t_2458, 1, (V[]){v_n_2457}));
      switch (heff_tag_of(v_x2_2459)) {
      case TAG_MkPair: {
        V v_x_2460 = heff_field(v_x2_2459, 0);
        V v_n_2461 = heff_field(v_x2_2459, 1);
        heff_take_n(v_x2_2459, 3ULL, 2);
        V v_x_2466;
        switch (heff_tag_of(v_x_2452)) {
        case TAG_Nothing: {
          heff_drop(v_x_2456);
          heff_drop(v_x_2460);
          v_x_2466 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2462 = heff_field(v_x_2452, 0);
          V v_ru_24x_2452_24Just = heff_take_reuse_n(v_x_2452, 1ULL, 1);
          switch (heff_tag_of(v_x_2456)) {
          case TAG_Nothing: {
            heff_drop(v_x_2460);
            heff_drop(v_a_2462);
            heff_drop_cell(v_ru_24x_2452_24Just, 1);
            v_x_2466 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_b_2463 = heff_field(v_x_2456, 0);
            heff_take_n(v_x_2456, 1ULL, 1);
            switch (heff_tag_of(v_x_2460)) {
            case TAG_Nothing: {
              heff_drop(v_a_2462);
              heff_drop_cell(v_ru_24x_2452_24Just, 1);
              heff_drop(v_b_2463);
              v_x_2466 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_c_2464 = heff_field(v_x_2460, 0);
              heff_take_n(v_x_2460, 1ULL, 1);
              V v_t_2465 = (g_heff_2ecompile_2eimperative_2econdIf(v_a_2462, v_b_2463, v_c_2464));
              v_x_2466 = heff_tag_at_n(v_ru_24x_2452_24Just, TAG_Just, 1, (V[]){v_t_2465});
              break;
            }
            default: heff_nomatch(v_x_2460);
            }
            break;
          }
          default: heff_nomatch(v_x_2456);
          }
          break;
        }
        default: heff_nomatch(v_x_2452);
        }
        return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){v_x_2466, v_n_2461});
      }
      default: return heff_nomatch(v_x2_2459);
      }
    }
    default: return heff_nomatch(v_x2_2455);
    }
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str0, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str1, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str2, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str3, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str4, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str5, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str6, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str7, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str8, 10, "$notSimple");
V g_heff_2ecompile_2eimperative_2esimpleOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam3, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam4(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam4, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam9(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam9, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam12(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam12, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam19, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam20(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam20, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam21(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam21, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam22(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam22, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam23(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam23, 1, 0};
Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2esimpleOf(V v_g_240, V v_x2_241) {
top: ;
  V v_tail_242 = heff_take_field(v_g_240, 2);
  V v_simple_243 = heff_get_n(v_g_240, 1, 8);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_EGlobal: {
    V v_k_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam1, 1, 1, (V[]){v_k_246});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_x2_241, 0);
    V v_b_249 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop(v_simple_243);
    V v_m_2410 = heff_tr(heff_call(v_tail_242, 2, (V[]){NTAG(TAG_Nothing), v_b_249}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam3_clo);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam4_clo);
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_x2_241, 0);
    V v_ts_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop(v_tail_242);
    V v_m_2429 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam5, 1, 1, (V[]){v_simple_243}), heff_dup(v_fs_2423)));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam6, 1, 3, (V[]){v_m_2429, v_fs_2423, v_ts_2424});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_241, 0);
    V v_l_2437 = heff_field(v_x2_241, 1);
    V v_sh_2438 = heff_field(v_x2_241, 2);
    V v_t_2439 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    heff_drop(v_tail_242);
    V v_m_2440 = heff_tr(heff_call(v_simple_243, 1, (V[]){v_e_2436}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam7, 1, 4, (V[]){v_m_2440, v_l_2437, v_sh_2438, v_t_2439});
  }
  case TAG_ETag: {
    V v_t_2445 = heff_field(v_x2_241, 0);
    V v_args_2446 = heff_field(v_x2_241, 1);
    V v_ts_2447 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    heff_drop(v_tail_242);
    V v_m_2448 = (g_prelude_2etraverse_24s1887447647x928396251(v_simple_243, v_args_2446));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam8, 1, 3, (V[]){v_m_2448, v_t_2445, v_ts_2447});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam9_clo);
  }
  case TAG_EPrim: {
    V v_p_2456 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam10, 1, 1, (V[]){v_p_2456});
  }
  case TAG_EPrimCall: {
    V v_p_2458 = heff_field(v_x2_241, 0);
    V v_args_2459 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop(v_tail_242);
    V v_m_2460 = (g_prelude_2etraverse_24s1887447647x928396251(v_simple_243, v_args_2459));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam11, 1, 2, (V[]){v_m_2460, v_p_2458});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam12_clo);
  }
  case TAG_EInt: {
    V v_i_2468 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam13, 1, 1, (V[]){v_i_2468});
  }
  case TAG_EFloat: {
    V v_x_2470 = heff_tget_v(v_x2_241, 0);
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam14, 1, 1, (V[]){v_x_2470});
  }
  case TAG_EStr: {
    V v_s_2472 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam15, 1, 1, (V[]){v_s_2472});
  }
  case TAG_EBytes: {
    V v_s_2474 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam16, 1, 1, (V[]){v_s_2474});
  }
  case TAG_EFixed: {
    V v_w_2476 = heff_field(v_x2_241, 0);
    V v_i_2477 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam17, 1, 2, (V[]){v_w_2476, v_i_2477});
  }
  case TAG_EFloat32: {
    V v_x_2479 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam18, 1, 1, (V[]){v_x_2479});
  }
  case TAG_EAbandon: {
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam19_clo);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam20_clo);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam21_clo);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam22_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_tail_242);
    heff_drop(v_simple_243);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam23_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2esimpleOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_x_244}), v_n_245});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_k_246}), v_n_247});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = heff_tag_n(TAG_SLam, 2, (V[]){v_xs_248, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2413})});
    return heff_tag_re_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2415, v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str0)}), v_n_2418});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam4(V self, V *args) {
  V v_n_2422 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str1)}), v_n_2422});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam5(V self, V *args) {
  V v_f_2425 = args[0];
  V v_simple_243 = heff_env(self)[0];
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_f_2425, 1);
    heff_take_n(v_f_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  heff_clo_take(self, 1);
  V f_ = v_simple_243;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_fs_2423 = heff_env(self)[1];
  V v_ts_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_n_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_n_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2423, v_x_2432));
    V v_x_2435 = heff_tag_n(TAG_SRec, 2, (V[]){v_t_2434, v_ts_2424});
    return heff_tag_re_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2435, v_n_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam7(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_l_2437 = heff_env(self)[1];
  V v_sh_2438 = heff_env(self)[2];
  V v_t_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_x_2443, v_l_2437, v_sh_2438, v_t_2439}), v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam8(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_t_2445 = heff_env(self)[1];
  V v_ts_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_STag, 3, (V[]){v_t_2445, v_x_2451, v_ts_2447}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam9(V self, V *args) {
  V v_n_2455 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str2)}), v_n_2455});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam10(V self, V *args) {
  V v_n_2457 = args[0];
  V v_p_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimFn, 1, (V[]){v_p_2456}), v_n_2457});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam11(V self, V *args) {
  V v_n_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_p_2458 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_n_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_n_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_SPrim, 2, (V[]){v_p_2458, v_x_2463}), v_n_2464});
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam12(V self, V *args) {
  V v_n_2467 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str3)}), v_n_2467});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam13(V self, V *args) {
  V v_n_2469 = args[0];
  V v_i_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SInt, 1, (V[]){v_i_2468}), v_n_2469});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam14(V self, V *args) {
  V v_n_2471 = args[0];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_SFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2470))}), v_n_2471});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam15(V self, V *args) {
  V v_n_2473 = args[0];
  V v_s_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SStr, 1, (V[]){v_s_2472}), v_n_2473});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam16(V self, V *args) {
  V v_n_2475 = args[0];
  V v_s_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SBytes, 1, (V[]){v_s_2474}), v_n_2475});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam17(V self, V *args) {
  V v_n_2478 = args[0];
  V v_w_2476 = heff_env(self)[0];
  V v_i_2477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 2, (V[]){v_w_2476, v_i_2477}), v_n_2478});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam18(V self, V *args) {
  V v_n_2480 = args[0];
  V v_x_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_SFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2479))}), v_n_2480});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam19(V self, V *args) {
  V v_n_2481 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str4)}), v_n_2481});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam20(V self, V *args) {
  V v_n_2483 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str5)}), v_n_2483});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam21(V self, V *args) {
  V v_n_2487 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str6)}), v_n_2487});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam22(V self, V *args) {
  V v_n_2489 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str7)}), v_n_2489});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam23(V self, V *args) {
  V v_n_2492 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str8)}), v_n_2492});
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2ematchSet_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2ematchSet_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2ematchSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ematchSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ematchSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ematchSet(V v_g_240, V v_d_241, V v_s_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_243));
  if (heff_intEq_c(v_t_244, MK_INT(2LL))) {
    HeffT2 v_t_245 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2ematchSet_str0); V a_1 = v_arms_243; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_t_248 = v_field_247;
        HeffT2 v_t_249 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2ematchSet_str1); V a_1 = v_arms_243; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_f_2412 = v_field_2411;
            V v_t_2413 = v_t_248;
            V v_f_2414 = v_f_2412;
            V v_m_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
            return heff_clo_n(g_heff_2ecompile_2eimperative_2ematchSet_lam0, 1, 7, (V[]){v_m_2415, v_g_240, v_d_241, v_s_242, v_arms_243, v_t_2413, v_f_2414});
          } else {
            heff_drop(v_t_248);
            heff_drop(v_field_2411);
            HEFF_LAST return g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_d_241, v_s_242, v_arms_243);
          }
        }
      } else {
        heff_drop(v_field_247);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_d_241, v_s_242, v_arms_243);
      }
    }
  } else {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_d_241, v_s_242, v_arms_243);
  }
}
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ematchSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ematchSet_lam0(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_243 = heff_env(self)[4];
  V v_t_2413 = heff_env(self)[5];
  V v_f_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Nothing: {
      heff_drop(v_t_2413);
      heff_drop(v_f_2414);
      heff_drop_cell(v_ru_24x2_2417_24MkPair, 2);
      V v_t_2420 = (g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_d_241, v_s_242, v_arms_243));
      V f_ = v_t_2420;
      args[0] = v_n_2419;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2421 = heff_field(v_x_2418, 0);
      heff_take_n(v_x_2418, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_243);
      V v_m_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 4)), 2, (V[]){heff_dup(v_d_241), v_t_2413}));
      V v_x2_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2419}));
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x2_2423, 0);
        V v_n_2425 = heff_field(v_x2_2423, 1);
        V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
        V v_m_2426 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_d_241, v_f_2414}));
        V v_x2_2427 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2425}));
        switch (heff_tag_of(v_x2_2427)) {
        case TAG_MkPair: {
          V v_x_2428 = heff_field(v_x2_2427, 0);
          V v_n_2429 = heff_field(v_x2_2427, 1);
          heff_take_n(v_x2_2427, 3ULL, 2);
          V v_t_2430 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2421, v_x_2424, v_x_2428}), NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_n_2429});
        }
        default: return heff_nomatch(v_x2_2427);
        }
      }
      default: return heff_nomatch(v_x2_2423);
      }
    }
    default: return heff_nomatch(v_x_2418);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
Clo g_heff_2ecompile_2eimperative_2edeclsBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclsBefore_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2edeclsBefore(V v_xs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_list_2emap_24s94444922x1860431141(v_xs_240));
  }
  case TAG_Cons: {
    V v_st_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_st_242, NTAG(TAG_Nil)});
      HEFF_LAST return g_prelude_2e_2b_2b_24f339900781x1605227681(v_t_244, v_xs_240);
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_st_242, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2eimperative_2edeclsBefore_24dps(v_xs_240, v_x22_243, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclsBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclsBefore(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclsBefore_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2edeclsBefore_24dps(V v_xs_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2emap_24s94444922x1860431141(v_xs_240));
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_st_244, NTAG(TAG_Nil)});
      V v_t_247 = (g_prelude_2e_2b_2b_24f339900781x1605227681(v_t_246, v_xs_240));
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_247);
    }
    case TAG_Cons: {
      V v_cell_2410 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_st_244, heff_hole()});
      V v_u_2411 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2410);
      V t_0 = v_xs_240;
      V t_1 = v_x22_245;
      V t_2 = v_u_2411;
      v_xs_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclsBefore_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eimperative_2edeclsBefore_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_lit_240}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_st_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_st_242, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_lit_240}), v_t_244});
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_st_242, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24dps(v_lit_240, v_x22_243, v_cell_247));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2ematchTo_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ematchTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ematchTo_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ematchTo(V v_g_240, V v_d_241, V v_s_242, V v_arms_243) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_d_241)) {
  case TAG_DSet: {
    v_t_247 = heff_dup(v_d_241);
    break;
  }
  case TAG_DLet: {
    V v_x_245 = heff_dup(heff_field(v_d_241, 0));
    v_t_247 = heff_tag_n(TAG_DSet, 1, (V[]){v_x_245});
    break;
  }
  case TAG_DSets: {
    v_t_247 = heff_dup(v_d_241);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  V v_m_248 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_247, v_s_242, v_arms_243));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ematchTo_lam0, 1, 2, (V[]){v_m_248, v_d_241});
}
V g_heff_2ecompile_2eimperative_2ematchTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ematchTo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ematchTo_lam0(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_x_2416;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_2416 = v_x_2411;
      break;
    }
    case TAG_DLet: {
      V v_x_2414 = heff_field(v_d_241, 0);
      V v_ru_24d_241_24DLet = heff_take_reuse_n(v_d_241, 1ULL, 1);
      v_x_2416 = (g_heff_2ecompile_2eimperative_2edeclsBefore_24s413105313x961616965_24tok1(v_ru_24d_241_24DLet, v_x_2414, v_x_2411));
      break;
    }
    case TAG_DSets: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_2416 = v_x_2411;
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_re_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_2416, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseTail_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseTail_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseTail(V v_g_240, V v_self_241, V v_s_242, V v_arms_243) {
top: ;
  V v_atom_244 = heff_take_field(v_g_240, 5);
  V v_tail_245 = heff_get_n(v_g_240, 2, 8);
  V v_m_246 = heff_tr(heff_call(v_atom_244, 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam0, 1, 4, (V[]){v_m_246, v_tail_245, v_self_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseTail(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  V v_vs_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_x_2418}), v_n_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_tail_245 = heff_env(self)[0];
  V v_self_241 = heff_env(self)[1];
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_b_2414 = heff_field(v_arm_2411, 2);
    heff_take_n(v_arm_2411, 7ULL, 3);
    heff_clo_take(self, 2);
    V v_m_2415 = heff_tr(heff_call(v_tail_245, 2, (V[]){v_self_241, v_b_2414}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam2, 1, 3, (V[]){v_m_2415, v_t_2412, v_vs_2413});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_tail_245 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2420 = (g_prelude_2etraverse_24s1887447647x928396251(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam1, 1, 2, (V[]){v_tail_245, v_self_241}), v_arms_243));
    V v_x2_2421 = heff_tr(heff_call(v_t_2420, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_n_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      V v_ss_2426;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_dup(heff_field(v_x_249, 0));
        v_ss_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2429;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_y_2428 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2429 = v_y_2428;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2432;
      switch (heff_tag_of(v_ss_2426)) {
      case TAG_Nil: {
        v_t_2432 = heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_TCase, 2, (V[]){v_t_2429, v_x_2422});
        break;
      }
      case TAG_Cons: {
        v_t_2432 = heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2426, heff_tag_n(TAG_TCase, 2, (V[]){v_t_2429, v_x_2422})});
        break;
      }
      default: heff_nomatch(v_ss_2426);
      }
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_n_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etailOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etailOf_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2etailOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam4(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etailOf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etailOf(V v_g_240, V v_self_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EGlobal: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELam: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EApp: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(v_y_249, heff_dup(v_a_2410), heff_dup(v_b_2411)));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_y_249);
        heff_drop(v_a_2410);
        heff_drop(v_b_2411);
        V v_e2_2415 = v_field_2414;
        return heff_tail(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_e2_2415});
      } else {
        heff_drop(v_field_2414);
        V v_m_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_249, v_a_2410}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam0, 1, 4, (V[]){v_m_2416, v_g_240, v_self_241, v_b_2411});
      }
    }
  }
  case TAG_ERecord: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EProj: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ETag: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EMatch: {
    V v_s_2447 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2448 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2449 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2448));
    if (heff_intEq_c(v_t_2449, MK_INT(2LL))) {
      HeffT2 v_t_2450 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2etailOf_str0); V a_1 = v_arms_2448; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2452 = v_t_2450.f[1];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_t_2453 = v_field_2452;
          HeffT2 v_t_2454 = ({ V b_0 = ((V)&g_heff_2ecompile_2eimperative_2etailOf_str1); V a_1 = v_arms_2448; HeffT2 r_ = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_2456 = v_t_2454.f[1];
            int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
            if ((v_tag_2455 == ((int64_t)0ULL))) {
              V v_f_2457 = v_field_2456;
              V v_t_2458 = v_t_2453;
              V v_f_2459 = v_f_2457;
              V v_t_2460 = heff_dup(heff_rfield(v_g_240, 0));
              if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
                heff_drop(v_t_2460);
                switch (heff_tag_of(v_self_241)) {
                case TAG_Nothing: {
                  V v_t_2461 = (g_heff_2ecompile_2eimperative_2econdShaped(heff_dup(v_t_2458)));
                  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
                    heff_drop(v_t_2461);
                    V v_t_2462 = (g_heff_2ecompile_2eimperative_2econdShaped(heff_dup(v_f_2459)));
                    if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
                      heff_drop(v_t_2462);
                      V v_m_2463 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
                      return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam1, 1, 7, (V[]){v_m_2463, v_g_240, v_self_241, v_s_2447, v_t_2458, v_f_2459, v_arms_2448});
                    } else {
                      heff_drop_tag(v_e_242, 2);
                      heff_drop(v_t_2462);
                      return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2447, v_t_2458, v_f_2459, v_arms_2448));
                    }
                  } else {
                    heff_drop_tag(v_e_242, 2);
                    heff_drop(v_t_2461);
                    return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2447, v_t_2458, v_f_2459, v_arms_2448));
                  }
                }
                case TAG_Just: {
                  heff_drop_tag(v_e_242, 2);
                  return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2447, v_t_2458, v_f_2459, v_arms_2448));
                }
                default: return heff_nomatch(v_self_241);
                }
              } else {
                heff_drop_tag(v_e_242, 2);
                heff_drop(v_t_2460);
                return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2447, v_t_2458, v_f_2459, v_arms_2448));
              }
            } else {
              heff_drop_tag(v_e_242, 2);
              heff_drop(v_t_2453);
              heff_drop(v_field_2456);
              return (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_2447, v_arms_2448));
            }
          }
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_field_2452);
          return (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_2447, v_arms_2448));
        }
      }
    } else {
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_2447, v_arms_2448));
    }
  }
  case TAG_EPrim: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EPrimCall: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ECall: {
    V v_k_2475 = heff_dup(heff_field(v_e_242, 0));
    V v_args_2476 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_self_241)) {
    case TAG_Nothing: {
      heff_drop(v_k_2475);
      heff_drop(v_args_2476);
      return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
    }
    case TAG_Just: {
      V v_s_2477 = heff_field(v_self_241, 0);
      heff_take_n(v_self_241, 1ULL, 1);
      V v_key_2478 = heff_take_field(v_s_2477, 0);
      V v_arity_2479 = heff_get_n(v_s_2477, 1, 2);
      if ((heff_strEq_c_lent(v_key_2478, v_k_2475, 0) && ({ V v_t_24138 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2476)); int c_ = heff_intEq_c_lent(v_t_24138, v_arity_2479, 0); heff_drop(v_t_24138); c_; }))) {
        heff_drop_tag(v_e_242, 2);
        heff_drop(v_k_2475);
        heff_drop(v_key_2478);
        heff_drop(v_arity_2479);
        V v_m_2480 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_args_2476));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam2, 1, 1, (V[]){v_m_2480});
      } else {
        heff_drop(v_k_2475);
        heff_drop(v_args_2476);
        heff_drop(v_key_2478);
        heff_drop(v_arity_2479);
        return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
      }
    }
    default: return heff_nomatch(v_self_241);
    }
  }
  case TAG_EInt: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EStr: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EBytes: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFixed: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat32: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EAbandon: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EBool: {
    V v_c_24101 = heff_dup(heff_field(v_e_242, 0));
    V v_m_24102 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam3, 1, 4, (V[]){v_m_24102, v_c_24101, v_g_240, v_self_241});
  }
  case TAG_ESet: {
    V v_xs_24110 = heff_field(v_e_242, 0);
    V v_a_24111 = heff_field(v_e_242, 1);
    V v_b_24112 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_24113 = (g_heff_2ecompile_2eimperative_2esetsOf(heff_dup(v_g_240), v_xs_24110, v_a_24111));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam4, 1, 4, (V[]){v_m_24113, v_g_240, v_self_241, v_b_24112});
  }
  case TAG_EValues: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFix: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etailOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etailOf_lam0(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_b_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2411}));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2420}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_n_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      V v_x_2437;
      switch (heff_tag_of(v_x_2419)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2422_24MkPair, 2);
        v_x_2437 = v_x_2423;
        break;
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_x_2423)) {
        case TAG_TSeq: {
          V v_ss2_2427 = heff_field(v_x_2423, 0);
          V v_t_2428 = heff_field(v_x_2423, 1);
          V v_ru_24x_2423_24TSeq = heff_take_reuse_n(v_x_2423, 3ULL, 2);
          V v_t_2429 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x_2423_24TSeq, v_x_2419, v_ss2_2427));
          v_x_2437 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_TSeq, 2, (V[]){v_t_2429, v_t_2428});
          break;
        }
        case TAG_TReturn: {
          v_x_2437 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_TSeq, 2, (V[]){v_x_2419, v_x_2423});
          break;
        }
        case TAG_TLoop: {
          v_x_2437 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_TSeq, 2, (V[]){v_x_2419, v_x_2423});
          break;
        }
        case TAG_TIf: {
          v_x_2437 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_TSeq, 2, (V[]){v_x_2419, v_x_2423});
          break;
        }
        case TAG_TCase: {
          v_x_2437 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_TSeq, 2, (V[]){v_x_2419, v_x_2423});
          break;
        }
        default: heff_nomatch(v_x_2423);
        }
        break;
      }
      default: heff_nomatch(v_x_2419);
      }
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2437, v_n_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam1(V self, V *args) {
  V v_n_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_2447 = heff_env(self)[3];
  V v_t_2458 = heff_env(self)[4];
  V v_f_2459 = heff_env(self)[5];
  V v_arms_2448 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_n_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_n_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    switch (heff_tag_of(v_x_2466)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_2465_24MkPair, 2);
      V v_t_2468 = (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2447, v_t_2458, v_f_2459, v_arms_2448));
      V f_ = v_t_2468;
      args[0] = v_n_2467;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2469 = heff_field(v_x_2466, 0);
      V v_ru_24x_2466_24Just = heff_take_reuse_n(v_x_2466, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_2447);
      heff_drop(v_t_2458);
      heff_drop(v_f_2459);
      heff_drop(v_arms_2448);
      V v_t_2470 = heff_tag_at_n(v_ru_24x_2466_24Just, TAG_TReturn, 1, (V[]){heff_tag_n(TAG_OBool, 1, (V[]){v_c_2469})});
      return heff_tag_re_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2470, v_n_2467});
    }
    default: return heff_nomatch(v_x_2466);
    }
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam2(V self, V *args) {
  V v_n_2481 = args[0];
  V v_m_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2482 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_n_2481}));
  switch (heff_tag_of(v_x2_2482)) {
  case TAG_MkPair: {
    V v_x_2483 = heff_field(v_x2_2482, 0);
    V v_n_2484 = heff_field(v_x2_2482, 1);
    V v_ru_24x2_2482_24MkPair = heff_take_reuse_n(v_x2_2482, 3ULL, 2);
    V v_ss_2487;
    switch (heff_tag_of(v_x_2483)) {
    case TAG_MkPair: {
      V v_x_2485 = heff_dup(heff_field(v_x_2483, 0));
      v_ss_2487 = v_x_2485;
      break;
    }
    default: heff_nomatch(v_x_2483);
    }
    V v_t_2490;
    switch (heff_tag_of(v_x_2483)) {
    case TAG_MkPair: {
      V v_y_2489 = heff_field(v_x_2483, 1);
      heff_take_n(v_x_2483, 2ULL, 2);
      v_t_2490 = v_y_2489;
      break;
    }
    default: heff_nomatch(v_x_2483);
    }
    V v_t_2493;
    switch (heff_tag_of(v_ss_2487)) {
    case TAG_Nil: {
      v_t_2493 = heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2490});
      break;
    }
    case TAG_Cons: {
      v_t_2493 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_2487, heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2490})});
      break;
    }
    default: heff_nomatch(v_ss_2487);
    }
    return heff_tag_re_n(v_ru_24x2_2482_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2493, v_n_2484});
  }
  default: return heff_nomatch(v_x2_2482);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam3(V self, V *args) {
  V v_n_24103 = args[0];
  V v_m_24102 = heff_env(self)[0];
  V v_c_24101 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_self_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24104 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_n_24103}));
  switch (heff_tag_of(v_x2_24104)) {
  case TAG_MkPair: {
    V v_x_24105 = heff_field(v_x2_24104, 0);
    V v_n_24106 = heff_field(v_x2_24104, 1);
    V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
    switch (heff_tag_of(v_x_24105)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_24104_24MkPair, 2);
      V v_t_24107 = (g_heff_2ecompile_2eir_2econdExpr(v_c_24101));
      V f_ = heff_get_n(v_g_240, 2, 8);
      heff_room[0] = v_self_241;
      heff_room[1] = v_t_24107;
      heff_room[2] = v_n_24106;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    case TAG_Just: {
      V v_c_24108 = heff_field(v_x_24105, 0);
      V v_ru_24x_24105_24Just = heff_take_reuse_n(v_x_24105, 1ULL, 1);
      heff_drop(v_c_24101);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_self_241);
      V v_t_24109 = heff_tag_at_n(v_ru_24x_24105_24Just, TAG_OBool, 1, (V[]){v_c_24108});
      return heff_tag_re_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_TReturn, 1, (V[]){v_t_24109}), v_n_24106});
    }
    default: return heff_nomatch(v_x_24105);
    }
  }
  default: return heff_nomatch(v_x2_24104);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam4(V self, V *args) {
  V v_n_24114 = args[0];
  V v_m_24113 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_b_24112 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24115 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_n_24114}));
  switch (heff_tag_of(v_x2_24115)) {
  case TAG_MkPair: {
    V v_x_24116 = heff_field(v_x2_24115, 0);
    V v_n_24117 = heff_field(v_x2_24115, 1);
    V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
    V v_m_24118 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_24112}));
    V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_n_24117}));
    switch (heff_tag_of(v_x2_24119)) {
    case TAG_MkPair: {
      V v_x_24120 = heff_field(v_x2_24119, 0);
      V v_n_24121 = heff_field(v_x2_24119, 1);
      V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
      V v_x_24134;
      switch (heff_tag_of(v_x_24116)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_24119_24MkPair, 2);
        v_x_24134 = v_x_24120;
        break;
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_x_24120)) {
        case TAG_TSeq: {
          V v_ss2_24124 = heff_field(v_x_24120, 0);
          V v_t_24125 = heff_field(v_x_24120, 1);
          V v_ru_24x_24120_24TSeq = heff_take_reuse_n(v_x_24120, 3ULL, 2);
          V v_t_24126 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x_24120_24TSeq, v_x_24116, v_ss2_24124));
          v_x_24134 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_TSeq, 2, (V[]){v_t_24126, v_t_24125});
          break;
        }
        case TAG_TReturn: {
          v_x_24134 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_TSeq, 2, (V[]){v_x_24116, v_x_24120});
          break;
        }
        case TAG_TLoop: {
          v_x_24134 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_TSeq, 2, (V[]){v_x_24116, v_x_24120});
          break;
        }
        case TAG_TIf: {
          v_x_24134 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_TSeq, 2, (V[]){v_x_24116, v_x_24120});
          break;
        }
        case TAG_TCase: {
          v_x_24134 = heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_TSeq, 2, (V[]){v_x_24116, v_x_24120});
          break;
        }
        default: heff_nomatch(v_x_24120);
        }
        break;
      }
      default: heff_nomatch(v_x_24116);
      }
      return heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_MkPair, 2, (V[]){v_x_24134, v_n_24121});
    }
    default: return heff_nomatch(v_x2_24119);
    }
  }
  default: return heff_nomatch(v_x2_24115);
  }
}

HeffT4 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V v_g_240, V v_d_241, V v_z_242) {
top: ;
  V v_body_243 = heff_take_field(v_d_241, 2);
  V v_key_244 = heff_take_field(v_d_241, 0);
  V v_name_245 = heff_get_n(v_d_241, 1, 3);
  V v_it_246 = v_body_243;
  switch (heff_tag_of(v_it_246)) {
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_it_246, 0);
    V v_b_248 = heff_field(v_it_246, 1);
    V v_ru_24it_246_24ELam = heff_take_reuse_n(v_it_246, 3ULL, 2);
    V v_key_249 = heff_dup(v_key_244);
    V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
    V v_t_2411 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_248), NTAG(TAG_Nil)));
    V v_t_2412 = ({ V a_0 = heff_dup(v_key_249); V a_1 = v_t_2410; V a_2 = v_t_2411; V r_ = (g_list_2eany_24s398044887x377101364(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    V v_t_2414;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__arity, (V[]){v_key_249, v_t_2413})});
    } else {
      heff_drop(v_key_249);
      heff_drop(v_t_2412);
      v_t_2414 = NTAG(TAG_Nothing);
    }
    V v_m_2415 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_t_2414, v_b_248}));
    V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      V v_f_2419 = v_key_244;
      V v_f_2420 = v_name_245;
      V v_t_2421 = heff_tag_at_n(v_ru_24it_246_24ELam, TAG_DefFun, 2, (V[]){v_xs_247, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2417})});
      return ((HeffT4){{v_f_2419, v_f_2420, v_t_2421, v_n_2418}});
    }
    default: return ((HeffT4){{heff_nomatch(v_x2_2416)}});
    }
  }
  default: {
    V v_m_2422 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_246}));
    V v_x2_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_n_2425 = heff_field(v_x2_2423, 1);
      heff_take_n(v_x2_2423, 3ULL, 2);
      V v_f_2426 = v_key_244;
      V v_f_2427 = v_name_245;
      V v_t_2428 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2424})});
      return ((HeffT4){{v_f_2426, v_f_2427, v_t_2428, v_n_2425}});
    }
    default: return ((HeffT4){{heff_nomatch(v_x2_2423)}});
    }
  }
  }
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V v_v_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SPrimFn: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SLam: {
    V v_v2_2413 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2413)) {
    case TAG_MkBlock: {
      V v_t_2414 = heff_field(v_v2_2413, 0);
      V v_ru_24v2_2413_24MkBlock = heff_take_reuse_n(v_v2_2413, 1ULL, 1);
      V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2413_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2415});
    }
    default: return heff_nomatch(v_v2_2413);
    }
  }
  case TAG_STag: {
    V v_args_2417 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2417));
    V v_t_2420 = ({ V a_0 = v_acc_241; V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2420});
  }
  case TAG_SRec: {
    V v_fs_2421 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2423 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2421));
    V v_t_2424 = ({ V a_0 = v_acc_241; V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2423); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2424});
  }
  case TAG_SProj: {
    V v_w_2425 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2430 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(v_w_2425, v_acc_241, v_cell_2429));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  case TAG_SPrim: {
    V v_args_2432 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2432));
    V v_t_2434 = ({ V a_0 = v_acc_241; V a_1 = v_t_2433; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2433); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2434});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V v_v_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_244);
  }
  case TAG_SGlobal: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_246);
  }
  case TAG_SInt: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_248);
  }
  case TAG_SFloat: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2410);
  }
  case TAG_SStr: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2412);
  }
  case TAG_SBytes: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2414);
  }
  case TAG_SFixed: {
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2417);
  }
  case TAG_SFloat32: {
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2419);
  }
  case TAG_SPrimFn: {
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2421);
  }
  case TAG_SLam: {
    V v_v2_2423 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2423)) {
    case TAG_MkBlock: {
      V v_t_2424 = heff_field(v_v2_2423, 0);
      V v_ru_24v2_2423_24MkBlock = heff_take_reuse_n(v_v2_2423, 1ULL, 1);
      V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2423_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2425});
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2426);
    }
    default: return heff_nomatch(v_v2_2423);
    }
  }
  case TAG_STag: {
    V v_args_2428 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2428));
    V v_t_2431 = ({ V a_0 = v_acc_241; V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2431});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2432);
  }
  case TAG_SRec: {
    V v_fs_2433 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2435 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2433));
    V v_t_2436 = ({ V a_0 = v_acc_241; V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2436});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2437);
  }
  case TAG_SProj: {
    V v_w_2438 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2443 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2442);
    V t_0 = v_w_2438;
    V t_1 = v_acc_241;
    V t_2 = v_u_2443;
    v_v_240 = t_0;
    v_acc_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_args_2445 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2445));
    V v_t_2447 = ({ V a_0 = v_acc_241; V a_1 = v_t_2446; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2446); r_; });
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2447});
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_t_2448);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 1);
    V v_acc_244 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_243, v_acc_241));
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_242)));
    HEFF_LAST return g_list_2efoldl_24s2003609603x1707519208(v_acc_244, v_t_245);
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(heff_dup(v_o_246), v_acc_241);
  }
  case TAG_TLoop: {
    V v_vs_247 = heff_field(v_x2_240, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_TIf: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_t_2410 = heff_field(v_x2_240, 1);
    V v_e_2411 = heff_field(v_x2_240, 2);
    V v_acc_2412 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_e_2411, v_acc_241));
    V v_acc_2413 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2410, v_acc_2412));
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(v_c_249, v_acc_2413);
  }
  case TAG_TCase: {
    V v_v_2414 = heff_field(v_x2_240, 0);
    V v_arms_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2415)));
    V v_t_2417 = ({ V a_0 = v_acc_241; V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s788715611x32297348(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2414), v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2einlinable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2einlinable_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2einlinable(V v_x_240, V v_o_241, V v_rest_242, V v_after_243) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OBool: {
    heff_drop(v_rest_242);
    return NTAG(TAG_False);
  }
  default: {
    V v_next_2445;
    switch (heff_tag_of(v_rest_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_after_243)) {
      case TAG_Nothing: {
        v_next_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_245 = heff_field(v_after_243, 0);
        V v_t_246 = heff_dup(v_t_245);
        switch (heff_tag_of(v_t_246)) {
        case TAG_TSeq: {
          V v_t1_247 = heff_field(v_t_246, 0);
          V v_ru_24t_246_24TSeq = heff_take_reuse_n(v_t_246, 1ULL, 2);
          switch (heff_tag_of(v_t1_247)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24t_246_24TSeq, 2);
            v_next_2445 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_st_249 = heff_field(v_t1_247, 0);
            heff_take_n(v_t1_247, 1ULL, 2);
            switch (heff_tag_of(v_st_249)) {
            case TAG_SLet: {
              V v_o_2412 = heff_field(v_st_249, 1);
              heff_take_n(v_st_249, 2ULL, 2);
              v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24t_246_24TSeq, v_o_2412));
              break;
            }
            case TAG_SOnce: {
              V v_o_2414 = heff_field(v_st_249, 1);
              heff_take_n(v_st_249, 2ULL, 2);
              v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24t_246_24TSeq, v_o_2414));
              break;
            }
            case TAG_SDecl: {
              heff_take_n(v_st_249, 0ULL, 1);
              heff_drop_cell(v_ru_24t_246_24TSeq, 2);
              v_next_2445 = NTAG(TAG_Nil);
              break;
            }
            case TAG_SSet: {
              V v_o_2417 = heff_field(v_st_249, 1);
              heff_take_n(v_st_249, 2ULL, 2);
              v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24t_246_24TSeq, v_o_2417));
              break;
            }
            case TAG_SIf: {
              heff_take_n(v_st_249, 0ULL, 3);
              heff_drop_cell(v_ru_24t_246_24TSeq, 2);
              v_next_2445 = NTAG(TAG_Nil);
              break;
            }
            case TAG_SCase: {
              V v_v_2421 = heff_field(v_st_249, 0);
              heff_take_n(v_st_249, 1ULL, 2);
              heff_drop_cell(v_ru_24t_246_24TSeq, 2);
              v_next_2445 = ({ V a_0 = v_v_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2421); r_; });
              break;
            }
            default: heff_nomatch(v_st_249);
            }
            break;
          }
          default: heff_nomatch(v_t1_247);
          }
          break;
        }
        case TAG_TReturn: {
          V v_o_2423 = heff_field(v_t_246, 0);
          heff_take_n(v_t_246, 1ULL, 1);
          v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop(v_o_2423));
          break;
        }
        case TAG_TLoop: {
          V v_vs_2424 = heff_field(v_t_246, 0);
          heff_take_n(v_t_246, 1ULL, 1);
          V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2424));
          v_next_2445 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2425); r_; });
          break;
        }
        case TAG_TIf: {
          heff_take_n(v_t_246, 0ULL, 3);
          v_next_2445 = NTAG(TAG_Nil);
          break;
        }
        case TAG_TCase: {
          V v_v_2429 = heff_field(v_t_246, 0);
          heff_take_n(v_t_246, 1ULL, 2);
          v_next_2445 = ({ V a_0 = v_v_2429; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2429); r_; });
          break;
        }
        default: heff_nomatch(v_t_246);
        }
        break;
      }
      default: heff_nomatch(v_after_243);
      }
      break;
    }
    case TAG_Cons: {
      V v_st_2431 = heff_dup(heff_field(v_rest_242, 0));
      switch (heff_tag_of(v_st_2431)) {
      case TAG_SLet: {
        V v_o_2434 = heff_field(v_st_2431, 1);
        V v_ru_24st_2431_24SLet = heff_take_reuse_n(v_st_2431, 2ULL, 2);
        v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2431_24SLet, v_o_2434));
        break;
      }
      case TAG_SOnce: {
        V v_o_2436 = heff_field(v_st_2431, 1);
        V v_ru_24st_2431_24SOnce = heff_take_reuse_n(v_st_2431, 2ULL, 2);
        v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2431_24SOnce, v_o_2436));
        break;
      }
      case TAG_SDecl: {
        heff_take_n(v_st_2431, 0ULL, 1);
        v_next_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SSet: {
        V v_o_2439 = heff_field(v_st_2431, 1);
        V v_ru_24st_2431_24SSet = heff_take_reuse_n(v_st_2431, 2ULL, 2);
        v_next_2445 = (g_heff_2ecompile_2eimperative_2eopNamesTop_24tok2(v_ru_24st_2431_24SSet, v_o_2439));
        break;
      }
      case TAG_SIf: {
        heff_take_n(v_st_2431, 0ULL, 3);
        v_next_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_SCase: {
        V v_v_2443 = heff_field(v_st_2431, 0);
        heff_take_n(v_st_2431, 1ULL, 2);
        v_next_2445 = ({ V a_0 = v_v_2443; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_2443); r_; });
        break;
      }
      default: heff_nomatch(v_st_2431);
      }
      break;
    }
    default: heff_nomatch(v_rest_242);
    }
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_242));
    V v_t_2447 = (g_list_2efoldl_24s2003609603x1707519208(NTAG(TAG_Nil), v_t_2446));
    V v_t_2449;
    switch (heff_tag_of(v_after_243)) {
    case TAG_Nothing: {
      v_t_2449 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_t_2448 = heff_field(v_after_243, 0);
      v_t_2449 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2448, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_after_243);
    }
    V v_rest_2450 = (g_prelude_2e_2b_2b(v_t_2447, v_t_2449));
    V v_t_2451 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_240; V a_3 = v_next_2445; V r_ = (g_list_2efoldl_24f2029054136x351940068(a_0, a_1, a_2, a_3)); heff_drop(v_next_2445); r_; });
    V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_t_2451, MK_INT(1LL), 2) && ({ V v_t_2452 = (g_list_2efoldl_24f1663632568x709545076(MK_INT(1LL), MK_INT(0LL), v_x_240, v_rest_2450)); int c_ = heff_intEq_c_lent(v_t_2452, MK_INT(1LL), 2); heff_drop(v_t_2452); c_; })));
    heff_drop(v_rest_2450);
    heff_drop(v_t_2451);
    return v_ret_24bool;
  }
  }
}
V g_heff_2ecompile_2eimperative_2einlinable_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eimperative_2einlinable(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eimperative_2eonceSts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eonceSts_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2eonceSts(V v_k_240, V v_x2_241, V v_after_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_240, 5);
    heff_drop(v_after_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_SLet: {
      V v_x_245 = heff_field(v_x21_243, 0);
      V v_o_246 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24SLet = heff_take_reuse_n(v_x21_243, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eimperative_2einlinable(v_x_245, v_o_246, heff_dup(v_rest_244), v_after_242));
      V v_t_2410;
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x21_243_24SLet, 2);
        heff_drop(v_t_247);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_o_246}));
        v_t_2410 = heff_tag_n(TAG_SOnce, 2, (V[]){v_x_245, v_t_248});
      } else {
        heff_drop(v_t_247);
        V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_o_246}));
        v_t_2410 = heff_tag_re_n(v_ru_24x21_243_24SLet, TAG_SLet, 2, 1ULL, (V[]){v_x_245, v_t_249});
      }
      V v_t_2411 = heff_tr(heff_call(heff_get_n(v_k_240, 3, 5), 2, (V[]){v_rest_244, v_after_242}));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_2411});
    }
    case TAG_SOnce: {
      V v_t_2414 = (g_heff_2ecompile_2eimperative_2eonceSt(heff_dup(v_k_240), v_x21_243));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_k_240, 3, 5), 2, (V[]){v_rest_244, v_after_242}));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_t_2415});
    }
    case TAG_SDecl: {
      V v_t_2417 = (g_heff_2ecompile_2eimperative_2eonceSt(heff_dup(v_k_240), v_x21_243));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_k_240, 3, 5), 2, (V[]){v_rest_244, v_after_242}));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_t_2418});
    }
    case TAG_SSet: {
      V v_t_2421 = (g_heff_2ecompile_2eimperative_2eonceSt(heff_dup(v_k_240), v_x21_243));
      V v_t_2422 = heff_tr(heff_call(heff_get_n(v_k_240, 3, 5), 2, (V[]){v_rest_244, v_after_242}));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2421, v_t_2422});
    }
    case TAG_SIf: {
      V v_t_2426 = (g_heff_2ecompile_2eimperative_2eonceSt(heff_dup(v_k_240), v_x21_243));
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 3, 5), 2, (V[]){v_rest_244, v_after_242}));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, v_t_2427});
    }
    case TAG_SCase: {
      V v_t_2430 = (g_heff_2ecompile_2eimperative_2eonceSt(heff_dup(v_k_240), v_x21_243));
      V v_t_2431 = heff_tr(heff_call(heff_get_n(v_k_240, 3, 5), 2, (V[]){v_rest_244, v_after_242}));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2430, v_t_2431});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eonceSts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eonceSts(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1(V v_tok_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_243 = heff_dup(heff_field(v_o_241, 0));
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_243, v_acc_242));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartOp, 1, (V[]){v_o_241}), v_t_244});
  }
  case TAG_OCall: {
    V v_args_246 = heff_dup(heff_field(v_o_241, 1));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_246));
    V v_t_248 = ({ V a_0 = v_acc_242; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartOp, 1, (V[]){v_o_241}), v_t_248});
  }
  case TAG_OApply: {
    V v_f_249 = heff_dup(heff_field(v_o_241, 0));
    V v_args_2410 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_249, v_args_2410})));
    V v_t_2412 = ({ V a_0 = v_acc_242; V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2411); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartOp, 1, (V[]){v_o_241}), v_t_2412});
  }
  case TAG_OPrim: {
    V v_args_2414 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2414));
    V v_t_2416 = ({ V a_0 = v_acc_242; V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartOp, 1, (V[]){v_o_241}), v_t_2416});
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartOp, 1, (V[]){v_o_241}), v_acc_242});
  }
  case TAG_OBool: {
    V v_c_2417 = heff_dup(heff_field(v_o_241, 0));
    V v_t_2418 = ({ V a_0 = v_c_2417; V a_1 = v_acc_242; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2417); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_PartOp, 1, (V[]){v_o_241}), v_t_2418});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_24tok1(a[0], a[1], a[2]);
}