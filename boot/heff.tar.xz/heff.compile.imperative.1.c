// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DLet 13606
#define TAG_DSet 20333
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_arity 294440695
#define LBL_atom 9500184
#define LBL_bindTo 558176963
#define LBL_body 9524841
#define LBL_cond 9554921
#define LBL_count 296209705
#define LBL_full 9650006
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_pred 9944808
#define LBL_setTo 310686359
#define LBL_simple 1044855005
#define LBL_sts 323756
#define LBL_tail 10047767
#define LBL_tl 10463
#define LBL_underLam 296337946
#define LBL_val 326043
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__arity[] = {LBL_key, LBL_arity};
static uint32_t shape_val__op__cond__sts__tl[] = {LBL_val, LBL_op, LBL_cond, LBL_sts, LBL_tl};
V g_heff_2ecompile_2eimperative_2eallL(V, V);
V g_heff_2ecompile_2eimperative_2eallL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eallL_clo;
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(V);
V g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912_clo;
HeffT2 g_heff_2ecompile_2eimperative_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf(V, V);
V g_heff_2ecompile_2eimperative_2eatomsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eatomsOf_clo;
V g_heff_2ecompile_2eimperative_2ecaseSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo;
V g_heff_2ecompile_2eimperative_2ecaseTail(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo;
V g_heff_2ecompile_2eimperative_2econdIf(V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_clo;
V g_heff_2ecompile_2eimperative_2econdIf_24dps(V, V, V, V);
V g_heff_2ecompile_2eimperative_2econdIf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdIf_24dps_clo;
V g_heff_2ecompile_2eimperative_2econdShaped(V);
V g_heff_2ecompile_2eimperative_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2econdShaped_clo;
V g_heff_2ecompile_2eimperative_2edeclBefore(V, V);
V g_heff_2ecompile_2eimperative_2edeclBefore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclBefore_clo;
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2edeclBefore_24dps_clo;
HeffT2 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2efirstNamesTl(V);
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo;
V g_heff_2ecompile_2eimperative_2eisRelCall(V);
V g_heff_2ecompile_2eimperative_2eisRelCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisRelCall_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2ematchSet(V, V, V, V);
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2ematchSet_clo;
V g_heff_2ecompile_2eimperative_2eopNamesTop(V);
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo;
V g_heff_2ecompile_2eimperative_2eopTail(V, V);
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eopTail_clo;
V g_heff_2ecompile_2eimperative_2epartsCond(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_clo;
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V, V);
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo;
V g_heff_2ecompile_2eimperative_2epartsOp(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_clo;
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V, V);
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo;
V g_heff_2ecompile_2eimperative_2epartsSt(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsSt_clo;
V g_heff_2ecompile_2eimperative_2epartsTl(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eimperative_2epartsVal(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo;
V g_heff_2ecompile_2eimperative_2epk_get(void);
V g_heff_2ecompile_2eimperative_2epredLets(V, V);
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epredLets_clo;
HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V, V);
V g_heff_2ecompile_2eimperative_2erelPrims_get(void);
V g_heff_2ecompile_2eimperative_2esimpleOf(V, V);
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo;
HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailOf_clo;
V g_heff_2ecompile_2eimperative_2etailSelf(V, V, V);
V g_heff_2ecompile_2eimperative_2etailSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etailSelf_clo;
V g_heff_2ecompile_2eimperative_2etestTail(V, V, V, V, V, V);
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etestTail_clo;
V g_heff_2ecompile_2eimperative_2etoDest(V, V, V);
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etoDest_clo;
V g_heff_2ecompile_2eimperative_2etraverseN(V, V);
V g_heff_2ecompile_2eimperative_2etraverseN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2etraverseN_clo;
V g_heff_2ecompile_2eimperative_2evalNamesTop(V, V);
V g_heff_2ecompile_2eimperative_2evalNamesTop_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2evalNamesTop_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1299324685x840794767(V, V);
V g_list_2efoldl_24s1299324685x840794767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1299324685x840794767_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1735038056x329845490(V, V);
V g_list_2efoldl_24s1735038056x329845490_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1735038056x329845490_clo;
V g_list_2efoldl_24s2003609603x1707519208(V, V);
V g_list_2efoldl_24s2003609603x1707519208_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2003609603x1707519208_clo;
V g_list_2efoldl_24s634927308x1347712163(V, V);
V g_list_2efoldl_24s634927308x1347712163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s634927308x1347712163_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2eimperative_2etraverseN_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2etraverseN_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etraverseN_lam0, 1, 0};
V g_heff_2ecompile_2eimperative_2etraverseN_lam1(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etraverseN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etraverseN_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2etraverseN(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eimperative_2etraverseN_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etraverseN_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2etraverseN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etraverseN(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2etraverseN_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2eimperative_2etraverseN_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eimperative_2etraverseN(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2eimperative_2eallL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eallL_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eallL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2eallL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2eallL(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eimperative_2eisSimple_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eisSimple_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eisSimple(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2eallL_24s2034742406x913054912(v_fs_2410);
  }
  case TAG_EProj: {
    V v_e_2412 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2412;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2417 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2eimperative_2eallL(((V)&g_heff_2ecompile_2eimperative_2eisSimple_clo), v_as_2417));
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2422 = heff_field(v_x1_240, 0);
    V v_as_2423 = heff_field(v_x1_240, 1);
    V v_x1_2424 = ({ V a_0 = heff_dup(v_p_2422); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_x1_2424) == NTAG(TAG_True))) {
      heff_drop(v_x1_2424);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2424);
      return (g_heff_2ecompile_2eimperative_2eallL(((V)&g_heff_2ecompile_2eimperative_2eisSimple_clo), v_as_2423));
    }
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2eisSimple(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str0, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str1, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str2, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str3, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str4, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str5, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str6, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str7, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str8, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str9, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eimperative_2erelPrims_str10, 5, "intLt");

static V g_heff_2ecompile_2eimperative_2erelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2erelPrims_st;
static V g_heff_2ecompile_2eimperative_2erelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str8), v_t_243})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2erelPrims_str10), v_t_244})});
}
V g_heff_2ecompile_2eimperative_2erelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2erelPrims_st)) return g_heff_2ecompile_2eimperative_2erelPrims_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2erelPrims_val, &g_heff_2ecompile_2eimperative_2erelPrims_st, g_heff_2ecompile_2eimperative_2erelPrims_init);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str3, 5, "False");
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2eimperative_2esinkTest_24cpr(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_EVar: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    V v_z_249 = heff_field(v_b_242, 0);
    V v_b2_2410 = heff_field(v_b_242, 1);
    V v_e_2411 = heff_field(v_b_242, 2);
    V v_ru_24b_242_24ELet = heff_take_reuse_n(v_b_242, 7ULL, 3);
    switch (heff_tag_of(v_b2_2410)) {
    case TAG_EVar: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_b2_2410, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_b2_2410, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      V v_b21_2430 = heff_field(v_b2_2410, 0);
      V v_arms_2431 = heff_field(v_b2_2410, 1);
      V v_ru_24b2_2410_24EMatch = heff_take_reuse_n(v_b2_2410, 3ULL, 2);
      switch (heff_tag_of(v_b21_2430)) {
      case TAG_EVar: {
        V v_y_2432 = heff_field(v_b21_2430, 0);
        heff_take_n(v_b21_2430, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_240, v_y_2432, 2)) {
          V v_t_2434 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_a_241));
          if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
            heff_drop(v_t_2434);
            V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2431));
            V v_t_2447;
            if (heff_intEq_c(v_t_2435, MK_INT(2LL))) {
              HeffT2 v_t_2437 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str0), heff_dup(v_arms_2431)));
              {
                V v_field_2439 = v_t_2437.f[1];
                int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
                if ((v_tag_2438 == ((int64_t)0ULL))) {
                  V v_t_2441 = v_field_2439;
                  heff_drop(v_t_2441);
                  HeffT2 v_t_2442 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str1), heff_dup(v_arms_2431)));
                  {
                    V v_field_2444 = v_t_2442.f[1];
                    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
                    v_t_2447 = heff_bool(((v_tag_2443 == ((int64_t)0ULL)) && ({ V v_f_2446 = heff_dup(v_field_2444); int c_ = 1; heff_drop(v_f_2446); c_; })));
                    heff_drop(v_field_2444);
                  }
                } else {
                  heff_drop(v_field_2439);
                  v_t_2447 = NTAG(TAG_False);
                }
              }
            } else {
              v_t_2447 = NTAG(TAG_False);
            }
            if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
              heff_drop(v_t_2447);
              V v_x1_2458 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam0, 1, 1, (V[]){heff_dup(v_x_240)}), v_arms_2431));
              if ((heff_dup(v_x1_2458) == NTAG(TAG_True))) {
                heff_drop(v_x_240);
                heff_drop(v_a_241);
                heff_drop(v_z_249);
                heff_drop(v_e_2411);
                heff_drop_cell(v_ru_24b_242_24ELet, 3);
                heff_drop(v_arms_2431);
                heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
                heff_drop(v_x1_2458);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              } else {
                heff_drop(v_x1_2458);
                V v_t_2459 = heff_tag_at_n(v_ru_24b2_2410_24EMatch, TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)});
                V v_t_2460 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2459));
                V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2411), NTAG(TAG_Nil)});
                V v_t_2462 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2461));
                V v_t_2463 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2460, v_t_2462}), 0, 2);
                if (heff_intEq_c(v_t_2463, MK_INT(0LL))) {
                  V v_t_2465 = heff_tag_at_n(v_ru_24b_242_24ELet, TAG_ELet, 3, (V[]){v_z_249, heff_tag_n(TAG_EMatch, 2, (V[]){v_a_241, v_arms_2431}), v_e_2411});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2465}});
                } else {
                  heff_drop(v_a_241);
                  heff_drop(v_z_249);
                  heff_drop(v_e_2411);
                  heff_drop_cell(v_ru_24b_242_24ELet, 3);
                  heff_drop(v_arms_2431);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_x_240);
              heff_drop(v_a_241);
              heff_drop(v_z_249);
              heff_drop(v_e_2411);
              heff_drop_cell(v_ru_24b_242_24ELet, 3);
              heff_drop(v_arms_2431);
              heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
              heff_drop(v_t_2447);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_x_240);
            heff_drop(v_a_241);
            heff_drop(v_z_249);
            heff_drop(v_e_2411);
            heff_drop_cell(v_ru_24b_242_24ELet, 3);
            heff_drop(v_arms_2431);
            heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
            heff_drop(v_t_2434);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_a_241);
          heff_drop(v_z_249);
          heff_drop(v_e_2411);
          heff_drop_cell(v_ru_24b_242_24ELet, 3);
          heff_drop(v_arms_2431);
          heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELet: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERecord: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProj: {
        heff_take_n(v_b21_2430, 0ULL, 4);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        heff_take_n(v_b21_2430, 0ULL, 3);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrim: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECall: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat: {
        heff_take_na(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStr: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBytes: {
        heff_take_n(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFixed: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFloat32: {
        heff_take_na(v_b21_2430, 0ULL, 1);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFix: {
        heff_take_n(v_b21_2430, 0ULL, 2);
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_z_249);
        heff_drop(v_e_2411);
        heff_drop_cell(v_ru_24b_242_24ELet, 3);
        heff_drop(v_arms_2431);
        heff_drop_cell(v_ru_24b2_2410_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_b21_2430)}});
      }
    }
    case TAG_EPrim: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_b2_2410, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_b2_2410, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_z_249);
      heff_drop(v_e_2411);
      heff_drop_cell(v_ru_24b_242_24ELet, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_b2_2410)}});
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_b_242, 0ULL, 4);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_b_242, 0ULL, 3);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    V v_b1_24122 = heff_field(v_b_242, 0);
    V v_arms_24123 = heff_field(v_b_242, 1);
    V v_ru_24b_242_24EMatch = heff_take_reuse_n(v_b_242, 3ULL, 2);
    switch (heff_tag_of(v_b1_24122)) {
    case TAG_EVar: {
      V v_y_24124 = heff_field(v_b1_24122, 0);
      heff_take_n(v_b1_24122, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_24124, 2)) {
        V v_t_24126 = (g_heff_2ecompile_2eimperative_2eisRelCall(v_a_241));
        if ((heff_dup(v_t_24126) == NTAG(TAG_True))) {
          heff_drop(v_t_24126);
          V v_t_24127 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24123));
          if (heff_intEq_c(v_t_24127, MK_INT(2LL))) {
            HeffT2 v_t_24129 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str2), heff_dup(v_arms_24123)));
            {
              V v_field_24131 = v_t_24129.f[1];
              int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
              if ((v_tag_24130 == ((int64_t)0ULL))) {
                V v_t_24133 = v_field_24131;
                heff_drop(v_t_24133);
                HeffT2 v_t_24134 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2esinkTest_24cpr_str3), heff_dup(v_arms_24123)));
                {
                  V v_field_24136 = v_t_24134.f[1];
                  int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
                  if ((v_tag_24135 == ((int64_t)0ULL))) {
                    V v_f_24138 = v_field_24136;
                    heff_drop(v_f_24138);
                    V v_x1_24149 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam1, 1, 1, (V[]){v_x_240}), v_arms_24123));
                    if ((heff_dup(v_x1_24149) == NTAG(TAG_True))) {
                      heff_drop(v_a_241);
                      heff_drop(v_arms_24123);
                      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                      heff_drop(v_x1_24149);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    } else {
                      heff_drop(v_x1_24149);
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24b_242_24EMatch, TAG_EMatch, 2, (V[]){v_a_241, v_arms_24123})}});
                    }
                  } else {
                    heff_drop(v_x_240);
                    heff_drop(v_a_241);
                    heff_drop(v_arms_24123);
                    heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                    heff_drop(v_field_24136);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              } else {
                heff_drop(v_x_240);
                heff_drop(v_a_241);
                heff_drop(v_arms_24123);
                heff_drop_cell(v_ru_24b_242_24EMatch, 2);
                heff_drop(v_field_24131);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_x_240);
            heff_drop(v_a_241);
            heff_drop(v_arms_24123);
            heff_drop_cell(v_ru_24b_242_24EMatch, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_x_240);
          heff_drop(v_a_241);
          heff_drop(v_arms_24123);
          heff_drop_cell(v_ru_24b_242_24EMatch, 2);
          heff_drop(v_t_24126);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_x_240);
        heff_drop(v_a_241);
        heff_drop(v_arms_24123);
        heff_drop_cell(v_ru_24b_242_24EMatch, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_EGlobal: {
      heff_take_n(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELam: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_b1_24122, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_b1_24122, 0ULL, 4);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_b1_24122, 0ULL, 3);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_b1_24122, 0ULL, 1);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_b1_24122, 0ULL, 2);
      heff_drop(v_x_240);
      heff_drop(v_a_241);
      heff_drop(v_arms_24123);
      heff_drop_cell(v_ru_24b_242_24EMatch, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_b1_24122)}});
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_b_242, 0ULL, 1);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_b_242, 0ULL, 2);
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_b_242)}});
  }
}
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam0(V self, V *args) {
  V v_a_2448 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_2452;
  switch (heff_tag_of(v_a_2448)) {
  case TAG_MkArm: {
    V v_b_2451 = heff_field(v_a_2448, 2);
    heff_take_n(v_a_2448, 4ULL, 3);
    v_e_2452 = v_b_2451;
    break;
  }
  default: heff_nomatch(v_a_2448);
  }
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_2452), NTAG(TAG_Nil)});
  V v_t_2454 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_2453));
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2452, NTAG(TAG_Nil)});
  V v_t_2456 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_2455));
  V v_x_2457 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2454, v_t_2456}), 0, 2);
  return heff_intLt(MK_INT(0LL), v_x_2457);
}
V g_heff_2ecompile_2eimperative_2esinkTest_24cpr_lam1(V self, V *args) {
  V v_a_24139 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_e_24143;
  switch (heff_tag_of(v_a_24139)) {
  case TAG_MkArm: {
    V v_b_24142 = heff_field(v_a_24139, 2);
    heff_take_n(v_a_24139, 4ULL, 3);
    v_e_24143 = v_b_24142;
    break;
  }
  default: heff_nomatch(v_a_24139);
  }
  V v_t_24144 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_24143), NTAG(TAG_Nil)});
  V v_t_24145 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_24144));
  V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_24143, NTAG(TAG_Nil)});
  V v_t_24147 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_24146));
  V v_x_24148 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24145, v_t_24147}), 0, 2);
  return heff_intLt(MK_INT(0LL), v_x_24148);
}
Clo g_heff_2ecompile_2eimperative_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2econdIf(V v_x1_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_x1_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_x1_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PBool: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_x1_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_x1_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PBool: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      case TAG_PLet: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PBool: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    case TAG_PLet: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_x1_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c_2473 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_c_2473;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_x1_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2474 = heff_field(v_x1_240, 0);
    V v_b_2475 = heff_field(v_x1_240, 1);
    V v_c_2476 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2488;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2488 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PBool: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    case TAG_PLet: {
      v_t_2488 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
      heff_drop(v_t_2488);
      V v_t_24100;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_24100 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_24100 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PBool: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      case TAG_PLet: {
        v_t_24100 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      if ((heff_dup(v_t_24100) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_240_24PIf, 3);
        heff_drop(v_t_24100);
        V v_t_24101 = (g_heff_2ecompile_2eimperative_2econdIf(v_b_2475, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_24102 = (g_heff_2ecompile_2eimperative_2econdIf(v_c_2476, v_t_241, v_e_242));
        V t_0 = v_a_2474;
        V t_1 = v_t_24101;
        V t_2 = v_t_24102;
        v_x1_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_24100);
        return heff_tag_at_n(v_ru_24x1_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2474, v_b_2475, v_c_2476}), v_t_241, v_e_242});
      }
    } else {
      heff_drop(v_t_2488);
      return heff_tag_at_n(v_ru_24x1_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2474, v_b_2475, v_c_2476}), v_t_241, v_e_242});
    }
  }
  case TAG_PLet: {
    V v_x_24103 = heff_field(v_x1_240, 0);
    V v_o_24104 = heff_field(v_x1_240, 1);
    V v_c_24105 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24PLet = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_cell_24106 = heff_tag_at_n(v_ru_24x1_240_24PLet, TAG_PLet, 3, (V[]){v_x_24103, v_o_24104, heff_hole()});
    V v_u_24107 = (g_heff_2ecompile_2eimperative_2econdIf_24dps(v_c_24105, v_t_241, v_e_242, heff_dup(v_cell_24106)));
    heff_drop(v_u_24107);
    return v_cell_24106;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eimperative_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2econdIf(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2eimperative_2epredLets_24cpr(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_SLet: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_o_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      HeffT2 v_t_246 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_rest_243, v_p_241));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_q_2410 = v_field_248;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_PLet, 3, (V[]){v_x_244, v_o_245, v_q_2410})}});
        } else {
          heff_drop(v_x_244);
          heff_drop(v_o_245);
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    case TAG_SDecl: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSet: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIf: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCase: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop(v_p_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eimperative_2epredLets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epredLets_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epredLets(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eimperative_2epredLets_24cpr(v_x1_240, v_p_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eimperative_2epredLets_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epredLets(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str0, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str1, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str2, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str3, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str4, 10, "$notSimple");
HEFF_LIT(g_heff_2ecompile_2eimperative_2esimpleOf_str5, 10, "$notSimple");
V g_heff_2ecompile_2eimperative_2esimpleOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam3, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam4(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam4, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam9(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam9, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam12(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam12, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2esimpleOf_lam19(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam19, 1, 0};
V g_heff_2ecompile_2eimperative_2esimpleOf_lam20(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2esimpleOf_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_lam20, 1, 0};
Clo g_heff_2ecompile_2eimperative_2esimpleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2esimpleOf_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2esimpleOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam0, 1, 1, (V[]){v_x_242});
  }
  case TAG_EGlobal: {
    V v_k_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam1, 1, 1, (V[]){v_k_244});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam3_clo);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam4_clo);
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_x2_241, 0);
    V v_ts_2424 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2429 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam5, 1, 1, (V[]){v_g_240}), heff_dup(v_fs_2423)));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam6, 1, 3, (V[]){v_m_2429, v_fs_2423, v_ts_2424});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_241, 0);
    V v_l_2437 = heff_field(v_x2_241, 1);
    V v_sh_2438 = heff_field(v_x2_241, 2);
    V v_t_2439 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_g_240, 1, 8), 1, (V[]){v_e_2436}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam7, 1, 4, (V[]){v_m_2440, v_l_2437, v_sh_2438, v_t_2439});
  }
  case TAG_ETag: {
    V v_t_2445 = heff_field(v_x2_241, 0);
    V v_as_2446 = heff_field(v_x2_241, 1);
    V v_ts_2447 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2448 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_get_n(v_g_240, 1, 8), v_as_2446));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam8, 1, 3, (V[]){v_m_2448, v_t_2445, v_ts_2447});
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam9_clo);
  }
  case TAG_EPrim: {
    V v_p_2457 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam10, 1, 1, (V[]){v_p_2457});
  }
  case TAG_EPrimCall: {
    V v_p_2459 = heff_field(v_x2_241, 0);
    V v_as_2460 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_get_n(v_g_240, 1, 8), v_as_2460));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam11, 1, 2, (V[]){v_m_2461, v_p_2459});
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam12_clo);
  }
  case TAG_EInt: {
    V v_i_2470 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam13, 1, 1, (V[]){v_i_2470});
  }
  case TAG_EFloat: {
    V v_x_2472 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam14, 1, 1, (V[]){v_x_2472});
  }
  case TAG_EStr: {
    V v_s_2474 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam15, 1, 1, (V[]){v_s_2474});
  }
  case TAG_EBytes: {
    V v_s_2476 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam16, 1, 1, (V[]){v_s_2476});
  }
  case TAG_EFixed: {
    V v_w_2478 = heff_field(v_x2_241, 0);
    V v_i_2479 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam17, 1, 2, (V[]){v_w_2478, v_i_2479});
  }
  case TAG_EFloat32: {
    V v_x_2481 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_g_240, 8);
    return heff_clo_n(g_heff_2ecompile_2eimperative_2esimpleOf_lam18, 1, 1, (V[]){v_x_2481});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam19_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop_rec(v_g_240, 8);
    return ((V)&g_heff_2ecompile_2eimperative_2esimpleOf_lam20_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2esimpleOf(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_x_242}), v_n_243});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_k_244}), v_n_245});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_SLam, 2, (V[]){v_xs_246, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2411})});
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_t_2417 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_n_2416});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam4(V self, V *args) {
  V v_n_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str1), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_n_2421});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam5(V self, V *args) {
  V v_f_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_f_2425)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_f_2425, 1);
    heff_take_n(v_f_2425, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_f_2425);
  }
  V f_ = heff_get_n(v_g_240, 1, 8);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_fs_2423 = heff_env(self)[1];
  V v_ts_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_n_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_n_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2423, v_x_2432));
    V v_x_2435 = heff_tag_n(TAG_SRec, 2, (V[]){v_t_2434, v_ts_2424});
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam7(V self, V *args) {
  V v_n_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_l_2437 = heff_env(self)[1];
  V v_sh_2438 = heff_env(self)[2];
  V v_t_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2441}));
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_MkPair: {
    V v_x_2443 = heff_field(v_x2_2442, 0);
    V v_n_2444 = heff_field(v_x2_2442, 1);
    V v_ru_24x2_2442_24MkPair = heff_take_reuse_n(v_x2_2442, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 4, (V[]){v_x_2443, v_l_2437, v_sh_2438, v_t_2439}), v_n_2444});
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam8(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_t_2445 = heff_env(self)[1];
  V v_ts_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_STag, 3, (V[]){v_t_2445, v_x_2451, v_ts_2447}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam9(V self, V *args) {
  V v_n_2455 = args[0];
  V v_t_2456 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str2), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_n_2455});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam10(V self, V *args) {
  V v_n_2458 = args[0];
  V v_p_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimFn, 1, (V[]){v_p_2457}), v_n_2458});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam11(V self, V *args) {
  V v_n_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_p_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 2, (V[]){v_p_2459, v_x_2464}), v_n_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam12(V self, V *args) {
  V v_n_2468 = args[0];
  V v_t_2469 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str3), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2469, v_n_2468});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam13(V self, V *args) {
  V v_n_2471 = args[0];
  V v_i_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SInt, 1, (V[]){v_i_2470}), v_n_2471});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam14(V self, V *args) {
  V v_n_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_SFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2472))}), v_n_2473});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam15(V self, V *args) {
  V v_n_2475 = args[0];
  V v_s_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SStr, 1, (V[]){v_s_2474}), v_n_2475});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam16(V self, V *args) {
  V v_n_2477 = args[0];
  V v_s_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SBytes, 1, (V[]){v_s_2476}), v_n_2477});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam17(V self, V *args) {
  V v_n_2480 = args[0];
  V v_w_2478 = heff_env(self)[0];
  V v_i_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 2, (V[]){v_w_2478, v_i_2479}), v_n_2480});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam18(V self, V *args) {
  V v_n_2482 = args[0];
  V v_x_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_SFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2481))}), v_n_2482});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam19(V self, V *args) {
  V v_n_2483 = args[0];
  V v_t_2484 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str4), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2484, v_n_2483});
}
V g_heff_2ecompile_2eimperative_2esimpleOf_lam20(V self, V *args) {
  V v_n_2487 = args[0];
  V v_t_2488 = heff_tag_n(TAG_SPrim, 2, (V[]){((V)&g_heff_2ecompile_2eimperative_2esimpleOf_str5), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2488, v_n_2487});
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseSet(V v_g_240, V v_x_241, V v_s_242, V v_arms_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam0, 1, 4, (V[]){v_m_244, v_g_240, v_x_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam1(V self, V *args) {
  V v_arm_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_arm_249, 0);
    V v_vs_2411 = heff_field(v_arm_249, 1);
    V v_b_2412 = heff_field(v_arm_249, 2);
    heff_take_n(v_arm_249, 7ULL, 3);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_x_241, v_b_2412}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam2, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_arm_249);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseSet_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseSet_lam1, 1, 2, (V[]){v_g_240, v_x_241}), v_arms_243));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_t_2424;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_247, 0));
        v_t_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_247, 1);
        heff_take_n(v_x_247, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SCase, 2, (V[]){v_t_2427, v_x_2420}), NTAG(TAG_Nil)});
      V v_x_2429 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2428));
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2429, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2ematchSet_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2ematchSet_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2ematchSet_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ematchSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ematchSet_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ematchSet(V v_g_240, V v_x_241, V v_s_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_243));
  V v_it_2416;
  if (heff_intEq_c(v_t_244, MK_INT(2LL))) {
    HeffT2 v_t_246 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2ematchSet_str0), heff_dup(v_arms_243)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_t_2410 = v_field_248;
        HeffT2 v_t_2411 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2ematchSet_str1), heff_dup(v_arms_243)));
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_f_2415 = v_field_2413;
            v_it_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_f_2415})});
          } else {
            heff_drop(v_t_2410);
            heff_drop(v_field_2413);
            v_it_2416 = NTAG(TAG_Nothing);
          }
        }
      } else {
        heff_drop(v_field_248);
        v_it_2416 = NTAG(TAG_Nothing);
      }
    }
  } else {
    v_it_2416 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_it_2416)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_x_241, v_s_242, v_arms_243);
  }
  case TAG_Just: {
    V v_it1_2417 = heff_field(v_it_2416, 0);
    heff_take_n(v_it_2416, 1ULL, 1);
    switch (heff_tag_of(v_it1_2417)) {
    case TAG_MkPair: {
      V v_t_2418 = heff_field(v_it1_2417, 0);
      V v_f_2419 = heff_field(v_it1_2417, 1);
      heff_take_n(v_it1_2417, 3ULL, 2);
      V v_m_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2ematchSet_lam0, 1, 7, (V[]){v_m_2420, v_g_240, v_x_241, v_s_242, v_arms_243, v_t_2418, v_f_2419});
    }
    default: return heff_nomatch(v_it1_2417);
    }
  }
  default: return heff_nomatch(v_it_2416);
  }
}
V g_heff_2ecompile_2eimperative_2ematchSet_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ematchSet(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ematchSet_lam0(V self, V *args) {
  V v_n_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_243 = heff_env(self)[4];
  V v_t_2418 = heff_env(self)[5];
  V v_f_2419 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2422 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_n_2421}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Nothing: {
      heff_drop(v_t_2418);
      heff_drop(v_f_2419);
      heff_drop_cell(v_ru_24x2_2422_24MkPair, 2);
      V v_t_2425 = (g_heff_2ecompile_2eimperative_2ecaseSet(v_g_240, v_x_241, v_s_242, v_arms_243));
      V f_ = v_t_2425;
      args[0] = v_n_2424;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2426 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_243);
      V v_m_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 4)), 2, (V[]){heff_dup(v_x_241), v_t_2418}));
      V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_n_2424}));
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_MkPair: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_n_2430 = heff_field(v_x2_2428, 1);
        V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
        V v_m_2431 = heff_tr(heff_call(heff_get_n(v_g_240, 4, 8), 2, (V[]){v_x_241, v_f_2419}));
        V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2430}));
        switch (heff_tag_of(v_x2_2432)) {
        case TAG_MkPair: {
          V v_x_2433 = heff_field(v_x2_2432, 0);
          V v_n_2434 = heff_field(v_x2_2432, 1);
          heff_take_n(v_x2_2432, 3ULL, 2);
          V v_t_2435 = heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SIf, 3, (V[]){v_c_2426, v_x_2429, v_x_2433}), NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_t_2435, v_n_2434});
        }
        default: return heff_nomatch(v_x2_2432);
        }
      }
      default: return heff_nomatch(v_x2_2428);
      }
    }
    default: return heff_nomatch(v_x_2423);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
Clo g_heff_2ecompile_2eimperative_2edeclBefore_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2edeclBefore_24dps(V v_x_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), NTAG(TAG_Nil)});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_Nil: {
      V v_t_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_240}), v_t_246});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_247);
    }
    case TAG_Cons: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_st_244, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_x_240;
      V t_1 = v_x22_245;
      V t_2 = v_cell_2410;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2edeclBefore_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2edeclBefore_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etoDest_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam10(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam11(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam12(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam13(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam14(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam15(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam16(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam17(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam18(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam19(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam20(V self, V *args);
V g_heff_2ecompile_2eimperative_2etoDest_lam21(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etoDest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etoDest_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etoDest(V v_g_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam0, 1, 2, (V[]){v_m_244, v_d_241});
  }
  case TAG_EGlobal: {
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam1, 1, 2, (V[]){v_m_2421, v_d_241});
  }
  case TAG_ELam: {
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam2, 1, 2, (V[]){v_m_2439, v_d_241});
  }
  case TAG_EApp: {
    V v_m_2457 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam3, 1, 2, (V[]){v_m_2457, v_d_241});
  }
  case TAG_ELet: {
    V v_y_2473 = heff_field(v_e_242, 0);
    V v_a_2474 = heff_field(v_e_242, 1);
    V v_b_2475 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2476 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(heff_dup(v_y_2473), heff_dup(v_a_2474), heff_dup(v_b_2475)));
    {
      V v_field_2478 = v_t_2476.f[1];
      int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
      if ((v_tag_2477 == ((int64_t)0ULL))) {
        heff_drop(v_y_2473);
        heff_drop(v_a_2474);
        heff_drop(v_b_2475);
        V v_e2_2480 = v_field_2478;
        V t_0 = v_g_240;
        V t_1 = v_d_241;
        V t_2 = v_e2_2480;
        v_g_240 = t_0;
        v_d_241 = t_1;
        v_e_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_2478);
        V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_2473, v_a_2474}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam4, 1, 4, (V[]){v_m_2481, v_g_240, v_d_241, v_b_2475});
      }
    }
  }
  case TAG_ERecord: {
    V v_m_2493 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam5, 1, 2, (V[]){v_m_2493, v_d_241});
  }
  case TAG_EProj: {
    V v_m_24113 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam6, 1, 2, (V[]){v_m_24113, v_d_241});
  }
  case TAG_ETag: {
    V v_m_24132 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam7, 1, 2, (V[]){v_m_24132, v_d_241});
  }
  case TAG_EMatch: {
    V v_s_24148 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_24149 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24150 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_24149));
    V v_it_24162;
    if (heff_intEq_c(v_t_24150, MK_INT(2LL))) {
      HeffT2 v_t_24152 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2etoDest_str0), heff_dup(v_arms_24149)));
      {
        V v_field_24154 = v_t_24152.f[1];
        int64_t v_tag_24153 = ((int64_t)v_t_24152.f[0]);
        if ((v_tag_24153 == ((int64_t)0ULL))) {
          V v_t_24156 = v_field_24154;
          HeffT2 v_t_24157 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2etoDest_str1), heff_dup(v_arms_24149)));
          {
            V v_field_24159 = v_t_24157.f[1];
            int64_t v_tag_24158 = ((int64_t)v_t_24157.f[0]);
            if ((v_tag_24158 == ((int64_t)0ULL))) {
              V v_f_24161 = v_field_24159;
              v_it_24162 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24156, v_f_24161})});
            } else {
              heff_drop(v_t_24156);
              heff_drop(v_field_24159);
              v_it_24162 = NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_field_24154);
          v_it_24162 = NTAG(TAG_Nothing);
        }
      }
    } else {
      v_it_24162 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_24162)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      V v_t_24165;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24163 = heff_dup(heff_field(v_d_241, 0));
        v_t_24165 = v_x_24163;
        break;
      }
      case TAG_DLet: {
        V v_x_24164 = heff_dup(heff_field(v_d_241, 0));
        v_t_24165 = v_x_24164;
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_24166 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_24165, v_s_24148, v_arms_24149));
      return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam8, 1, 2, (V[]){v_m_24166, v_d_241});
    }
    case TAG_Just: {
      V v_it1_24174 = heff_field(v_it_24162, 0);
      heff_take_n(v_it_24162, 1ULL, 1);
      switch (heff_tag_of(v_it1_24174)) {
      case TAG_MkPair: {
        V v_t_24175 = heff_field(v_it1_24174, 0);
        V v_f_24176 = heff_field(v_it1_24174, 1);
        heff_take_n(v_it1_24174, 3ULL, 2);
        V v_t_24177 = heff_dup(heff_rfield(v_g_240, 0));
        V v_t_24179;
        if ((heff_dup(v_t_24177) == NTAG(TAG_True))) {
          heff_drop(v_t_24177);
          V v_t_24178 = (g_heff_2ecompile_2eimperative_2econdShaped(v_t_24175));
          if ((heff_dup(v_t_24178) == NTAG(TAG_True))) {
            heff_drop(v_t_24178);
            v_t_24179 = (g_heff_2ecompile_2eimperative_2econdShaped(v_f_24176));
          } else {
            heff_drop(v_f_24176);
            heff_drop(v_t_24178);
            v_t_24179 = NTAG(TAG_False);
          }
        } else {
          heff_drop(v_t_24175);
          heff_drop(v_f_24176);
          heff_drop(v_t_24177);
          v_t_24179 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_24179) == NTAG(TAG_True))) {
          heff_drop(v_t_24179);
          V v_m_24180 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
          return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam9, 1, 5, (V[]){v_m_24180, v_d_241, v_g_240, v_s_24148, v_arms_24149});
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_t_24179);
          V v_t_24202;
          switch (heff_tag_of(v_d_241)) {
          case TAG_DSet: {
            V v_x_24200 = heff_dup(heff_field(v_d_241, 0));
            v_t_24202 = v_x_24200;
            break;
          }
          case TAG_DLet: {
            V v_x_24201 = heff_dup(heff_field(v_d_241, 0));
            v_t_24202 = v_x_24201;
            break;
          }
          default: heff_nomatch(v_d_241);
          }
          V v_m_24203 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_24202, v_s_24148, v_arms_24149));
          return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam10, 1, 2, (V[]){v_m_24203, v_d_241});
        }
      }
      default: return heff_nomatch(v_it1_24174);
      }
    }
    default: return heff_nomatch(v_it_24162);
    }
  }
  case TAG_EPrim: {
    V v_m_24212 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam11, 1, 2, (V[]){v_m_24212, v_d_241});
  }
  case TAG_EPrimCall: {
    V v_m_24230 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam12, 1, 2, (V[]){v_m_24230, v_d_241});
  }
  case TAG_ECall: {
    V v_m_24248 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam13, 1, 2, (V[]){v_m_24248, v_d_241});
  }
  case TAG_EInt: {
    V v_m_24265 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam14, 1, 2, (V[]){v_m_24265, v_d_241});
  }
  case TAG_EFloat: {
    V v_m_24282 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam15, 1, 2, (V[]){v_m_24282, v_d_241});
  }
  case TAG_EStr: {
    V v_m_24299 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam16, 1, 2, (V[]){v_m_24299, v_d_241});
  }
  case TAG_EBytes: {
    V v_m_24316 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam17, 1, 2, (V[]){v_m_24316, v_d_241});
  }
  case TAG_EFixed: {
    V v_m_24334 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam18, 1, 2, (V[]){v_m_24334, v_d_241});
  }
  case TAG_EFloat32: {
    V v_m_24351 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam19, 1, 2, (V[]){v_m_24351, v_d_241});
  }
  case TAG_EAbandon: {
    V v_m_24367 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam20, 1, 2, (V[]){v_m_24367, v_d_241});
  }
  case TAG_EFix: {
    V v_m_24385 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_242}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2etoDest_lam21, 1, 2, (V[]){v_m_24385, v_d_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etoDest(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etoDest_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_o_2414;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 2ULL, 2);
      v_o_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2417;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2415 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2417 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2415, v_o_2414});
      break;
    }
    case TAG_DLet: {
      V v_x_2416 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2417 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2416, v_o_2414});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_x_2419 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2418));
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam1(V self, V *args) {
  V v_n_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_n_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_dup(heff_field(v_x_2424, 0));
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    V v_o_2431;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_MkPair: {
      V v_y_2430 = heff_field(v_x_2424, 1);
      heff_take_n(v_x_2424, 2ULL, 2);
      v_o_2431 = v_y_2430;
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    V v_t_2434;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2432 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2434 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2432, v_o_2431});
      break;
    }
    case TAG_DLet: {
      V v_x_2433 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2434 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2433, v_o_2431});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
    V v_x_2436 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
    return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_n_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam2(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2446;
    switch (heff_tag_of(v_x_2442)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_dup(heff_field(v_x_2442, 0));
      v_t_2446 = v_x_2444;
      break;
    }
    default: heff_nomatch(v_x_2442);
    }
    V v_o_2449;
    switch (heff_tag_of(v_x_2442)) {
    case TAG_MkPair: {
      V v_y_2448 = heff_field(v_x_2442, 1);
      heff_take_n(v_x_2442, 2ULL, 2);
      v_o_2449 = v_y_2448;
      break;
    }
    default: heff_nomatch(v_x_2442);
    }
    V v_t_2452;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2450 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2452 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2450, v_o_2449});
      break;
    }
    case TAG_DLet: {
      V v_x_2451 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2452 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2451, v_o_2449});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_x_2454 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2453));
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2454, v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam3(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2464;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_dup(heff_field(v_x_2460, 0));
      v_t_2464 = v_x_2462;
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_o_2467;
    switch (heff_tag_of(v_x_2460)) {
    case TAG_MkPair: {
      V v_y_2466 = heff_field(v_x_2460, 1);
      heff_take_n(v_x_2460, 2ULL, 2);
      v_o_2467 = v_y_2466;
      break;
    }
    default: heff_nomatch(v_x_2460);
    }
    V v_t_2470;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_2468 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2470 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_2468, v_o_2467});
      break;
    }
    case TAG_DLet: {
      V v_x_2469 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_2470 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_2469, v_o_2467});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_x_2472 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2471));
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_x_2472, v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam4(V self, V *args) {
  V v_n_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_241 = heff_env(self)[2];
  V v_b_2475 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_n_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_n_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    V v_m_2486 = (g_heff_2ecompile_2eimperative_2etoDest(v_g_240, v_d_241, v_b_2475));
    V v_x2_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_n_2485}));
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_n_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      V v_x_2490 = (g_prelude_2e_2b_2b(v_x_2484, v_x_2488));
      return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){v_x_2490, v_n_2489});
    }
    default: return heff_nomatch(v_x2_2487);
    }
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam5(V self, V *args) {
  V v_n_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_n_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_n_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    V v_t_24100;
    switch (heff_tag_of(v_x_2496)) {
    case TAG_MkPair: {
      V v_x_2498 = heff_dup(heff_field(v_x_2496, 0));
      v_t_24100 = v_x_2498;
      break;
    }
    default: heff_nomatch(v_x_2496);
    }
    V v_o_24103;
    switch (heff_tag_of(v_x_2496)) {
    case TAG_MkPair: {
      V v_y_24102 = heff_field(v_x_2496, 1);
      heff_take_n(v_x_2496, 2ULL, 2);
      v_o_24103 = v_y_24102;
      break;
    }
    default: heff_nomatch(v_x_2496);
    }
    V v_t_24106;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24104 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24106 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24104, v_o_24103});
      break;
    }
    case TAG_DLet: {
      V v_x_24105 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24106 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24105, v_o_24103});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, NTAG(TAG_Nil)});
    V v_x_24108 = (g_prelude_2e_2b_2b(v_t_24100, v_t_24107));
    return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){v_x_24108, v_n_2497});
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam6(V self, V *args) {
  V v_n_24114 = args[0];
  V v_m_24113 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24115 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_n_24114}));
  switch (heff_tag_of(v_x2_24115)) {
  case TAG_MkPair: {
    V v_x_24116 = heff_field(v_x2_24115, 0);
    V v_n_24117 = heff_field(v_x2_24115, 1);
    V v_ru_24x2_24115_24MkPair = heff_take_reuse_n(v_x2_24115, 3ULL, 2);
    V v_t_24120;
    switch (heff_tag_of(v_x_24116)) {
    case TAG_MkPair: {
      V v_x_24118 = heff_dup(heff_field(v_x_24116, 0));
      v_t_24120 = v_x_24118;
      break;
    }
    default: heff_nomatch(v_x_24116);
    }
    V v_o_24123;
    switch (heff_tag_of(v_x_24116)) {
    case TAG_MkPair: {
      V v_y_24122 = heff_field(v_x_24116, 1);
      heff_take_n(v_x_24116, 2ULL, 2);
      v_o_24123 = v_y_24122;
      break;
    }
    default: heff_nomatch(v_x_24116);
    }
    V v_t_24126;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24124 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24126 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24124, v_o_24123});
      break;
    }
    case TAG_DLet: {
      V v_x_24125 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24126 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24125, v_o_24123});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
    V v_x_24128 = (g_prelude_2e_2b_2b(v_t_24120, v_t_24127));
    return heff_tag_at_n(v_ru_24x2_24115_24MkPair, TAG_MkPair, 2, (V[]){v_x_24128, v_n_24117});
  }
  default: return heff_nomatch(v_x2_24115);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam7(V self, V *args) {
  V v_n_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_n_24133}));
  switch (heff_tag_of(v_x2_24134)) {
  case TAG_MkPair: {
    V v_x_24135 = heff_field(v_x2_24134, 0);
    V v_n_24136 = heff_field(v_x2_24134, 1);
    V v_ru_24x2_24134_24MkPair = heff_take_reuse_n(v_x2_24134, 3ULL, 2);
    V v_t_24139;
    switch (heff_tag_of(v_x_24135)) {
    case TAG_MkPair: {
      V v_x_24137 = heff_dup(heff_field(v_x_24135, 0));
      v_t_24139 = v_x_24137;
      break;
    }
    default: heff_nomatch(v_x_24135);
    }
    V v_o_24142;
    switch (heff_tag_of(v_x_24135)) {
    case TAG_MkPair: {
      V v_y_24141 = heff_field(v_x_24135, 1);
      heff_take_n(v_x_24135, 2ULL, 2);
      v_o_24142 = v_y_24141;
      break;
    }
    default: heff_nomatch(v_x_24135);
    }
    V v_t_24145;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24143 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24145 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24143, v_o_24142});
      break;
    }
    case TAG_DLet: {
      V v_x_24144 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24145 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24144, v_o_24142});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24145, NTAG(TAG_Nil)});
    V v_x_24147 = (g_prelude_2e_2b_2b(v_t_24139, v_t_24146));
    return heff_tag_at_n(v_ru_24x2_24134_24MkPair, TAG_MkPair, 2, (V[]){v_x_24147, v_n_24136});
  }
  default: return heff_nomatch(v_x2_24134);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam8(V self, V *args) {
  V v_n_24167 = args[0];
  V v_m_24166 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24168 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_n_24167}));
  switch (heff_tag_of(v_x2_24168)) {
  case TAG_MkPair: {
    V v_x_24169 = heff_field(v_x2_24168, 0);
    V v_n_24170 = heff_field(v_x2_24168, 1);
    V v_ru_24x2_24168_24MkPair = heff_take_reuse_n(v_x2_24168, 3ULL, 2);
    V v_x_24173;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_24173 = v_x_24169;
      break;
    }
    case TAG_DLet: {
      V v_x_24172 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_x_24173 = (g_heff_2ecompile_2eimperative_2edeclBefore(v_x_24172, v_x_24169));
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_at_n(v_ru_24x2_24168_24MkPair, TAG_MkPair, 2, (V[]){v_x_24173, v_n_24170});
  }
  default: return heff_nomatch(v_x2_24168);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam9(V self, V *args) {
  V v_n_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_s_24148 = heff_env(self)[3];
  V v_arms_24149 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24182 = heff_tr(heff_call(v_m_24180, 1, (V[]){v_n_24181}));
  switch (heff_tag_of(v_x2_24182)) {
  case TAG_MkPair: {
    V v_x_24183 = heff_field(v_x2_24182, 0);
    V v_n_24184 = heff_field(v_x2_24182, 1);
    V v_ru_24x2_24182_24MkPair = heff_take_reuse_n(v_x2_24182, 3ULL, 2);
    switch (heff_tag_of(v_x_24183)) {
    case TAG_Nothing: {
      V v_t_24187;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24185 = heff_dup(heff_field(v_d_241, 0));
        v_t_24187 = v_x_24185;
        break;
      }
      case TAG_DLet: {
        V v_x_24186 = heff_dup(heff_field(v_d_241, 0));
        v_t_24187 = v_x_24186;
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_m_24188 = (g_heff_2ecompile_2eimperative_2ematchSet(v_g_240, v_t_24187, v_s_24148, v_arms_24149));
      V v_x2_24189 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_n_24184}));
      switch (heff_tag_of(v_x2_24189)) {
      case TAG_MkPair: {
        V v_x_24190 = heff_field(v_x2_24189, 0);
        V v_n_24191 = heff_field(v_x2_24189, 1);
        heff_take_n(v_x2_24189, 3ULL, 2);
        V v_x_24194;
        switch (heff_tag_of(v_d_241)) {
        case TAG_DSet: {
          heff_take_n(v_d_241, 0ULL, 1);
          v_x_24194 = v_x_24190;
          break;
        }
        case TAG_DLet: {
          V v_x_24193 = heff_field(v_d_241, 0);
          heff_take_n(v_d_241, 1ULL, 1);
          v_x_24194 = (g_heff_2ecompile_2eimperative_2edeclBefore(v_x_24193, v_x_24190));
          break;
        }
        default: heff_nomatch(v_d_241);
        }
        return heff_tag_at_n(v_ru_24x2_24182_24MkPair, TAG_MkPair, 2, (V[]){v_x_24194, v_n_24191});
      }
      default: return heff_nomatch(v_x2_24189);
      }
    }
    case TAG_Just: {
      V v_c_24195 = heff_field(v_x_24183, 0);
      V v_ru_24x_24183_24Just = heff_take_reuse_n(v_x_24183, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_24148);
      heff_drop(v_arms_24149);
      V v_t_24198;
      switch (heff_tag_of(v_d_241)) {
      case TAG_DSet: {
        V v_x_24196 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24198 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24196, heff_tag_at_n(v_ru_24x_24183_24Just, TAG_OBool, 1, (V[]){v_c_24195})});
        break;
      }
      case TAG_DLet: {
        V v_x_24197 = heff_field(v_d_241, 0);
        heff_take_n(v_d_241, 1ULL, 1);
        v_t_24198 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24197, heff_tag_at_n(v_ru_24x_24183_24Just, TAG_OBool, 1, (V[]){v_c_24195})});
        break;
      }
      default: heff_nomatch(v_d_241);
      }
      V v_t_24199 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24198, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x2_24182_24MkPair, TAG_MkPair, 2, (V[]){v_t_24199, v_n_24184});
    }
    default: return heff_nomatch(v_x_24183);
    }
  }
  default: return heff_nomatch(v_x2_24182);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam10(V self, V *args) {
  V v_n_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_n_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_n_24207 = heff_field(v_x2_24205, 1);
    V v_ru_24x2_24205_24MkPair = heff_take_reuse_n(v_x2_24205, 3ULL, 2);
    V v_x_24210;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      heff_take_n(v_d_241, 0ULL, 1);
      v_x_24210 = v_x_24206;
      break;
    }
    case TAG_DLet: {
      V v_x_24209 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_x_24210 = (g_heff_2ecompile_2eimperative_2edeclBefore(v_x_24209, v_x_24206));
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    return heff_tag_at_n(v_ru_24x2_24205_24MkPair, TAG_MkPair, 2, (V[]){v_x_24210, v_n_24207});
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam11(V self, V *args) {
  V v_n_24213 = args[0];
  V v_m_24212 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24214 = heff_tr(heff_call(v_m_24212, 1, (V[]){v_n_24213}));
  switch (heff_tag_of(v_x2_24214)) {
  case TAG_MkPair: {
    V v_x_24215 = heff_field(v_x2_24214, 0);
    V v_n_24216 = heff_field(v_x2_24214, 1);
    V v_ru_24x2_24214_24MkPair = heff_take_reuse_n(v_x2_24214, 3ULL, 2);
    V v_t_24219;
    switch (heff_tag_of(v_x_24215)) {
    case TAG_MkPair: {
      V v_x_24217 = heff_dup(heff_field(v_x_24215, 0));
      v_t_24219 = v_x_24217;
      break;
    }
    default: heff_nomatch(v_x_24215);
    }
    V v_o_24222;
    switch (heff_tag_of(v_x_24215)) {
    case TAG_MkPair: {
      V v_y_24221 = heff_field(v_x_24215, 1);
      heff_take_n(v_x_24215, 2ULL, 2);
      v_o_24222 = v_y_24221;
      break;
    }
    default: heff_nomatch(v_x_24215);
    }
    V v_t_24225;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24223 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24225 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24223, v_o_24222});
      break;
    }
    case TAG_DLet: {
      V v_x_24224 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24225 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24224, v_o_24222});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24226 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24225, NTAG(TAG_Nil)});
    V v_x_24227 = (g_prelude_2e_2b_2b(v_t_24219, v_t_24226));
    return heff_tag_at_n(v_ru_24x2_24214_24MkPair, TAG_MkPair, 2, (V[]){v_x_24227, v_n_24216});
  }
  default: return heff_nomatch(v_x2_24214);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam12(V self, V *args) {
  V v_n_24231 = args[0];
  V v_m_24230 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24232 = heff_tr(heff_call(v_m_24230, 1, (V[]){v_n_24231}));
  switch (heff_tag_of(v_x2_24232)) {
  case TAG_MkPair: {
    V v_x_24233 = heff_field(v_x2_24232, 0);
    V v_n_24234 = heff_field(v_x2_24232, 1);
    V v_ru_24x2_24232_24MkPair = heff_take_reuse_n(v_x2_24232, 3ULL, 2);
    V v_t_24237;
    switch (heff_tag_of(v_x_24233)) {
    case TAG_MkPair: {
      V v_x_24235 = heff_dup(heff_field(v_x_24233, 0));
      v_t_24237 = v_x_24235;
      break;
    }
    default: heff_nomatch(v_x_24233);
    }
    V v_o_24240;
    switch (heff_tag_of(v_x_24233)) {
    case TAG_MkPair: {
      V v_y_24239 = heff_field(v_x_24233, 1);
      heff_take_n(v_x_24233, 2ULL, 2);
      v_o_24240 = v_y_24239;
      break;
    }
    default: heff_nomatch(v_x_24233);
    }
    V v_t_24243;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24241 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24243 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24241, v_o_24240});
      break;
    }
    case TAG_DLet: {
      V v_x_24242 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24243 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24242, v_o_24240});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24243, NTAG(TAG_Nil)});
    V v_x_24245 = (g_prelude_2e_2b_2b(v_t_24237, v_t_24244));
    return heff_tag_at_n(v_ru_24x2_24232_24MkPair, TAG_MkPair, 2, (V[]){v_x_24245, v_n_24234});
  }
  default: return heff_nomatch(v_x2_24232);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam13(V self, V *args) {
  V v_n_24249 = args[0];
  V v_m_24248 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24250 = heff_tr(heff_call(v_m_24248, 1, (V[]){v_n_24249}));
  switch (heff_tag_of(v_x2_24250)) {
  case TAG_MkPair: {
    V v_x_24251 = heff_field(v_x2_24250, 0);
    V v_n_24252 = heff_field(v_x2_24250, 1);
    V v_ru_24x2_24250_24MkPair = heff_take_reuse_n(v_x2_24250, 3ULL, 2);
    V v_t_24255;
    switch (heff_tag_of(v_x_24251)) {
    case TAG_MkPair: {
      V v_x_24253 = heff_dup(heff_field(v_x_24251, 0));
      v_t_24255 = v_x_24253;
      break;
    }
    default: heff_nomatch(v_x_24251);
    }
    V v_o_24258;
    switch (heff_tag_of(v_x_24251)) {
    case TAG_MkPair: {
      V v_y_24257 = heff_field(v_x_24251, 1);
      heff_take_n(v_x_24251, 2ULL, 2);
      v_o_24258 = v_y_24257;
      break;
    }
    default: heff_nomatch(v_x_24251);
    }
    V v_t_24261;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24259 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24261 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24259, v_o_24258});
      break;
    }
    case TAG_DLet: {
      V v_x_24260 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24261 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24260, v_o_24258});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24262 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24261, NTAG(TAG_Nil)});
    V v_x_24263 = (g_prelude_2e_2b_2b(v_t_24255, v_t_24262));
    return heff_tag_at_n(v_ru_24x2_24250_24MkPair, TAG_MkPair, 2, (V[]){v_x_24263, v_n_24252});
  }
  default: return heff_nomatch(v_x2_24250);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam14(V self, V *args) {
  V v_n_24266 = args[0];
  V v_m_24265 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24267 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_n_24266}));
  switch (heff_tag_of(v_x2_24267)) {
  case TAG_MkPair: {
    V v_x_24268 = heff_field(v_x2_24267, 0);
    V v_n_24269 = heff_field(v_x2_24267, 1);
    V v_ru_24x2_24267_24MkPair = heff_take_reuse_n(v_x2_24267, 3ULL, 2);
    V v_t_24272;
    switch (heff_tag_of(v_x_24268)) {
    case TAG_MkPair: {
      V v_x_24270 = heff_dup(heff_field(v_x_24268, 0));
      v_t_24272 = v_x_24270;
      break;
    }
    default: heff_nomatch(v_x_24268);
    }
    V v_o_24275;
    switch (heff_tag_of(v_x_24268)) {
    case TAG_MkPair: {
      V v_y_24274 = heff_field(v_x_24268, 1);
      heff_take_n(v_x_24268, 2ULL, 2);
      v_o_24275 = v_y_24274;
      break;
    }
    default: heff_nomatch(v_x_24268);
    }
    V v_t_24278;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24276 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24278 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24276, v_o_24275});
      break;
    }
    case TAG_DLet: {
      V v_x_24277 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24278 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24277, v_o_24275});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24279 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24278, NTAG(TAG_Nil)});
    V v_x_24280 = (g_prelude_2e_2b_2b(v_t_24272, v_t_24279));
    return heff_tag_at_n(v_ru_24x2_24267_24MkPair, TAG_MkPair, 2, (V[]){v_x_24280, v_n_24269});
  }
  default: return heff_nomatch(v_x2_24267);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam15(V self, V *args) {
  V v_n_24283 = args[0];
  V v_m_24282 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24284 = heff_tr(heff_call(v_m_24282, 1, (V[]){v_n_24283}));
  switch (heff_tag_of(v_x2_24284)) {
  case TAG_MkPair: {
    V v_x_24285 = heff_field(v_x2_24284, 0);
    V v_n_24286 = heff_field(v_x2_24284, 1);
    V v_ru_24x2_24284_24MkPair = heff_take_reuse_n(v_x2_24284, 3ULL, 2);
    V v_t_24289;
    switch (heff_tag_of(v_x_24285)) {
    case TAG_MkPair: {
      V v_x_24287 = heff_dup(heff_field(v_x_24285, 0));
      v_t_24289 = v_x_24287;
      break;
    }
    default: heff_nomatch(v_x_24285);
    }
    V v_o_24292;
    switch (heff_tag_of(v_x_24285)) {
    case TAG_MkPair: {
      V v_y_24291 = heff_field(v_x_24285, 1);
      heff_take_n(v_x_24285, 2ULL, 2);
      v_o_24292 = v_y_24291;
      break;
    }
    default: heff_nomatch(v_x_24285);
    }
    V v_t_24295;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24293 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24295 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24293, v_o_24292});
      break;
    }
    case TAG_DLet: {
      V v_x_24294 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24295 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24294, v_o_24292});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24296 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24295, NTAG(TAG_Nil)});
    V v_x_24297 = (g_prelude_2e_2b_2b(v_t_24289, v_t_24296));
    return heff_tag_at_n(v_ru_24x2_24284_24MkPair, TAG_MkPair, 2, (V[]){v_x_24297, v_n_24286});
  }
  default: return heff_nomatch(v_x2_24284);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam16(V self, V *args) {
  V v_n_24300 = args[0];
  V v_m_24299 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24301 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_n_24300}));
  switch (heff_tag_of(v_x2_24301)) {
  case TAG_MkPair: {
    V v_x_24302 = heff_field(v_x2_24301, 0);
    V v_n_24303 = heff_field(v_x2_24301, 1);
    V v_ru_24x2_24301_24MkPair = heff_take_reuse_n(v_x2_24301, 3ULL, 2);
    V v_t_24306;
    switch (heff_tag_of(v_x_24302)) {
    case TAG_MkPair: {
      V v_x_24304 = heff_dup(heff_field(v_x_24302, 0));
      v_t_24306 = v_x_24304;
      break;
    }
    default: heff_nomatch(v_x_24302);
    }
    V v_o_24309;
    switch (heff_tag_of(v_x_24302)) {
    case TAG_MkPair: {
      V v_y_24308 = heff_field(v_x_24302, 1);
      heff_take_n(v_x_24302, 2ULL, 2);
      v_o_24309 = v_y_24308;
      break;
    }
    default: heff_nomatch(v_x_24302);
    }
    V v_t_24312;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24310 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24312 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24310, v_o_24309});
      break;
    }
    case TAG_DLet: {
      V v_x_24311 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24312 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24311, v_o_24309});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24313 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24312, NTAG(TAG_Nil)});
    V v_x_24314 = (g_prelude_2e_2b_2b(v_t_24306, v_t_24313));
    return heff_tag_at_n(v_ru_24x2_24301_24MkPair, TAG_MkPair, 2, (V[]){v_x_24314, v_n_24303});
  }
  default: return heff_nomatch(v_x2_24301);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam17(V self, V *args) {
  V v_n_24317 = args[0];
  V v_m_24316 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24318 = heff_tr(heff_call(v_m_24316, 1, (V[]){v_n_24317}));
  switch (heff_tag_of(v_x2_24318)) {
  case TAG_MkPair: {
    V v_x_24319 = heff_field(v_x2_24318, 0);
    V v_n_24320 = heff_field(v_x2_24318, 1);
    V v_ru_24x2_24318_24MkPair = heff_take_reuse_n(v_x2_24318, 3ULL, 2);
    V v_t_24323;
    switch (heff_tag_of(v_x_24319)) {
    case TAG_MkPair: {
      V v_x_24321 = heff_dup(heff_field(v_x_24319, 0));
      v_t_24323 = v_x_24321;
      break;
    }
    default: heff_nomatch(v_x_24319);
    }
    V v_o_24326;
    switch (heff_tag_of(v_x_24319)) {
    case TAG_MkPair: {
      V v_y_24325 = heff_field(v_x_24319, 1);
      heff_take_n(v_x_24319, 2ULL, 2);
      v_o_24326 = v_y_24325;
      break;
    }
    default: heff_nomatch(v_x_24319);
    }
    V v_t_24329;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24327 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24329 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24327, v_o_24326});
      break;
    }
    case TAG_DLet: {
      V v_x_24328 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24329 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24328, v_o_24326});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24330 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24329, NTAG(TAG_Nil)});
    V v_x_24331 = (g_prelude_2e_2b_2b(v_t_24323, v_t_24330));
    return heff_tag_at_n(v_ru_24x2_24318_24MkPair, TAG_MkPair, 2, (V[]){v_x_24331, v_n_24320});
  }
  default: return heff_nomatch(v_x2_24318);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam18(V self, V *args) {
  V v_n_24335 = args[0];
  V v_m_24334 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24336 = heff_tr(heff_call(v_m_24334, 1, (V[]){v_n_24335}));
  switch (heff_tag_of(v_x2_24336)) {
  case TAG_MkPair: {
    V v_x_24337 = heff_field(v_x2_24336, 0);
    V v_n_24338 = heff_field(v_x2_24336, 1);
    V v_ru_24x2_24336_24MkPair = heff_take_reuse_n(v_x2_24336, 3ULL, 2);
    V v_t_24341;
    switch (heff_tag_of(v_x_24337)) {
    case TAG_MkPair: {
      V v_x_24339 = heff_dup(heff_field(v_x_24337, 0));
      v_t_24341 = v_x_24339;
      break;
    }
    default: heff_nomatch(v_x_24337);
    }
    V v_o_24344;
    switch (heff_tag_of(v_x_24337)) {
    case TAG_MkPair: {
      V v_y_24343 = heff_field(v_x_24337, 1);
      heff_take_n(v_x_24337, 2ULL, 2);
      v_o_24344 = v_y_24343;
      break;
    }
    default: heff_nomatch(v_x_24337);
    }
    V v_t_24347;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24345 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24347 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24345, v_o_24344});
      break;
    }
    case TAG_DLet: {
      V v_x_24346 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24347 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24346, v_o_24344});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24348 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24347, NTAG(TAG_Nil)});
    V v_x_24349 = (g_prelude_2e_2b_2b(v_t_24341, v_t_24348));
    return heff_tag_at_n(v_ru_24x2_24336_24MkPair, TAG_MkPair, 2, (V[]){v_x_24349, v_n_24338});
  }
  default: return heff_nomatch(v_x2_24336);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam19(V self, V *args) {
  V v_n_24352 = args[0];
  V v_m_24351 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24353 = heff_tr(heff_call(v_m_24351, 1, (V[]){v_n_24352}));
  switch (heff_tag_of(v_x2_24353)) {
  case TAG_MkPair: {
    V v_x_24354 = heff_field(v_x2_24353, 0);
    V v_n_24355 = heff_field(v_x2_24353, 1);
    V v_ru_24x2_24353_24MkPair = heff_take_reuse_n(v_x2_24353, 3ULL, 2);
    V v_t_24358;
    switch (heff_tag_of(v_x_24354)) {
    case TAG_MkPair: {
      V v_x_24356 = heff_dup(heff_field(v_x_24354, 0));
      v_t_24358 = v_x_24356;
      break;
    }
    default: heff_nomatch(v_x_24354);
    }
    V v_o_24361;
    switch (heff_tag_of(v_x_24354)) {
    case TAG_MkPair: {
      V v_y_24360 = heff_field(v_x_24354, 1);
      heff_take_n(v_x_24354, 2ULL, 2);
      v_o_24361 = v_y_24360;
      break;
    }
    default: heff_nomatch(v_x_24354);
    }
    V v_t_24364;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24362 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24364 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24362, v_o_24361});
      break;
    }
    case TAG_DLet: {
      V v_x_24363 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24364 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24363, v_o_24361});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24365 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24364, NTAG(TAG_Nil)});
    V v_x_24366 = (g_prelude_2e_2b_2b(v_t_24358, v_t_24365));
    return heff_tag_at_n(v_ru_24x2_24353_24MkPair, TAG_MkPair, 2, (V[]){v_x_24366, v_n_24355});
  }
  default: return heff_nomatch(v_x2_24353);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam20(V self, V *args) {
  V v_n_24368 = args[0];
  V v_m_24367 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24369 = heff_tr(heff_call(v_m_24367, 1, (V[]){v_n_24368}));
  switch (heff_tag_of(v_x2_24369)) {
  case TAG_MkPair: {
    V v_x_24370 = heff_field(v_x2_24369, 0);
    V v_n_24371 = heff_field(v_x2_24369, 1);
    V v_ru_24x2_24369_24MkPair = heff_take_reuse_n(v_x2_24369, 3ULL, 2);
    V v_t_24374;
    switch (heff_tag_of(v_x_24370)) {
    case TAG_MkPair: {
      V v_x_24372 = heff_dup(heff_field(v_x_24370, 0));
      v_t_24374 = v_x_24372;
      break;
    }
    default: heff_nomatch(v_x_24370);
    }
    V v_o_24377;
    switch (heff_tag_of(v_x_24370)) {
    case TAG_MkPair: {
      V v_y_24376 = heff_field(v_x_24370, 1);
      heff_take_n(v_x_24370, 2ULL, 2);
      v_o_24377 = v_y_24376;
      break;
    }
    default: heff_nomatch(v_x_24370);
    }
    V v_t_24380;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24378 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24380 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24378, v_o_24377});
      break;
    }
    case TAG_DLet: {
      V v_x_24379 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24380 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24379, v_o_24377});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24381 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24380, NTAG(TAG_Nil)});
    V v_x_24382 = (g_prelude_2e_2b_2b(v_t_24374, v_t_24381));
    return heff_tag_at_n(v_ru_24x2_24369_24MkPair, TAG_MkPair, 2, (V[]){v_x_24382, v_n_24371});
  }
  default: return heff_nomatch(v_x2_24369);
  }
}
V g_heff_2ecompile_2eimperative_2etoDest_lam21(V self, V *args) {
  V v_n_24386 = args[0];
  V v_m_24385 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24387 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_n_24386}));
  switch (heff_tag_of(v_x2_24387)) {
  case TAG_MkPair: {
    V v_x_24388 = heff_field(v_x2_24387, 0);
    V v_n_24389 = heff_field(v_x2_24387, 1);
    V v_ru_24x2_24387_24MkPair = heff_take_reuse_n(v_x2_24387, 3ULL, 2);
    V v_t_24392;
    switch (heff_tag_of(v_x_24388)) {
    case TAG_MkPair: {
      V v_x_24390 = heff_dup(heff_field(v_x_24388, 0));
      v_t_24392 = v_x_24390;
      break;
    }
    default: heff_nomatch(v_x_24388);
    }
    V v_o_24395;
    switch (heff_tag_of(v_x_24388)) {
    case TAG_MkPair: {
      V v_y_24394 = heff_field(v_x_24388, 1);
      heff_take_n(v_x_24388, 2ULL, 2);
      v_o_24395 = v_y_24394;
      break;
    }
    default: heff_nomatch(v_x_24388);
    }
    V v_t_24398;
    switch (heff_tag_of(v_d_241)) {
    case TAG_DSet: {
      V v_x_24396 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24398 = heff_tag_n(TAG_SSet, 2, (V[]){v_x_24396, v_o_24395});
      break;
    }
    case TAG_DLet: {
      V v_x_24397 = heff_field(v_d_241, 0);
      heff_take_n(v_d_241, 1ULL, 1);
      v_t_24398 = heff_tag_n(TAG_SLet, 2, (V[]){v_x_24397, v_o_24395});
      break;
    }
    default: heff_nomatch(v_d_241);
    }
    V v_t_24399 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24398, NTAG(TAG_Nil)});
    V v_x_24400 = (g_prelude_2e_2b_2b(v_t_24392, v_t_24399));
    return heff_tag_at_n(v_ru_24x2_24387_24MkPair, TAG_MkPair, 2, (V[]){v_x_24400, v_n_24389});
  }
  default: return heff_nomatch(v_x2_24387);
  }
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2eopTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopTail_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2eopTail(V v_g_240, V v_e_241) {
top: ;
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_g_240, 6, 8), 1, (V[]){v_e_241}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2eopTail_lam0, 1, 1, (V[]){v_m_242});
}
V g_heff_2ecompile_2eimperative_2eopTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopTail(a[0], a[1]);
}
V g_heff_2ecompile_2eimperative_2eopTail_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_n_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_n_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_ss_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_dup(heff_field(v_x_245, 0));
      v_ss_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_y_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_t_2412 = v_y_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_t_2415;
    switch (heff_tag_of(v_ss_249)) {
    case TAG_Nil: {
      v_t_2415 = heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_Cons: {
      v_t_2415 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_249, heff_tag_n(TAG_TReturn, 1, (V[]){v_t_2412})});
      break;
    }
    default: heff_nomatch(v_ss_249);
    }
    return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2415, v_n_246});
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam2(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseTail_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2ecaseTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2ecaseTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2ecaseTail_entry, 4, 0};

V g_heff_2ecompile_2eimperative_2ecaseTail(V v_g_240, V v_self_241, V v_s_242, V v_arms_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 5)), 1, (V[]){v_s_242}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam0, 1, 4, (V[]){v_m_244, v_g_240, v_self_241, v_arms_243});
}
V g_heff_2ecompile_2eimperative_2ecaseTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2ecaseTail(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam2(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  V v_vs_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam1(V self, V *args) {
  V v_arm_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_self_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_arm_249, 0);
    V v_vs_2411 = heff_field(v_arm_249, 1);
    V v_b_2412 = heff_field(v_arm_249, 2);
    heff_take_n(v_arm_249, 7ULL, 3);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2412}));
    return heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam2, 1, 3, (V[]){v_m_2413, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_arm_249);
  }
}
V g_heff_2ecompile_2eimperative_2ecaseTail_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_arms_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2418 = (g_heff_2ecompile_2eimperative_2etraverseN(heff_clo_n(g_heff_2ecompile_2eimperative_2ecaseTail_lam1, 1, 2, (V[]){v_g_240, v_self_241}), v_arms_243));
    V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_n_2421 = heff_field(v_x2_2419, 1);
      V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
      V v_ss_2424;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2422 = heff_dup(heff_field(v_x_247, 0));
        v_ss_2424 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_y_2426 = heff_field(v_x_247, 1);
        heff_take_n(v_x_247, 2ULL, 2);
        v_t_2427 = v_y_2426;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_t_2430;
      switch (heff_tag_of(v_ss_2424)) {
      case TAG_Nil: {
        v_t_2430 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TCase, 2, (V[]){v_t_2427, v_x_2420});
        break;
      }
      case TAG_Cons: {
        v_t_2430 = heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_TSeq, 2, (V[]){v_ss_2424, heff_tag_n(TAG_TCase, 2, (V[]){v_t_2427, v_x_2420})});
        break;
      }
      default: heff_nomatch(v_ss_2424);
      }
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2430, v_n_2421});
    }
    default: return heff_nomatch(v_x2_2419);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etestTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etestTail_entry, 6, 0};

V g_heff_2ecompile_2eimperative_2etestTail(V v_g_240, V v_self_241, V v_s_242, V v_t_243, V v_f_244, V v_arms_245) {
top: ;
  V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){heff_dup(v_s_242)}));
  return heff_clo_n(g_heff_2ecompile_2eimperative_2etestTail_lam0, 1, 7, (V[]){v_m_246, v_g_240, v_self_241, v_s_242, v_arms_245, v_t_243, v_f_244});
}
V g_heff_2ecompile_2eimperative_2etestTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etestTail(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2eimperative_2etestTail_lam0(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_242 = heff_env(self)[3];
  V v_arms_245 = heff_env(self)[4];
  V v_t_243 = heff_env(self)[5];
  V v_f_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop(v_t_243);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2411 = (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_242, v_arms_245));
      V f_ = v_t_2411;
      args[0] = v_n_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop(v_s_242);
      heff_drop(v_arms_245);
      V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 2)), 2, (V[]){heff_dup(v_self_241), v_t_243}));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2410}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_n_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_f_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_n_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_TIf, 3, (V[]){v_c_2412, v_x_2415, v_x_2419}), v_n_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2eimperative_2etailOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eimperative_2etailOf_str1, 5, "False");
V g_heff_2ecompile_2eimperative_2etailOf_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2etailOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etailOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etailOf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etailOf(V v_g_240, V v_self_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EGlobal: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELam: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EApp: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2eimperative_2esinkTest_24cpr(heff_dup(v_y_249), heff_dup(v_a_2410), heff_dup(v_b_2411)));
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_y_249);
        heff_drop(v_a_2410);
        heff_drop(v_b_2411);
        V v_e2_2416 = v_field_2414;
        return heff_tail(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_e2_2416});
      } else {
        heff_drop(v_field_2414);
        V v_m_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 3)), 2, (V[]){v_y_249, v_a_2410}));
        return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam0, 1, 4, (V[]){v_m_2417, v_g_240, v_self_241, v_b_2411});
      }
    }
  }
  case TAG_ERecord: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EProj: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ETag: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EMatch: {
    V v_s_2448 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2449 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_arms_2449));
    V v_it_2462;
    if (heff_intEq_c(v_t_2450, MK_INT(2LL))) {
      HeffT2 v_t_2452 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2etailOf_str0), heff_dup(v_arms_2449)));
      {
        V v_field_2454 = v_t_2452.f[1];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_t_2456 = v_field_2454;
          HeffT2 v_t_2457 = (g_heff_2ecompile_2eimperative_2earmNamed_24cpr(((V)&g_heff_2ecompile_2eimperative_2etailOf_str1), heff_dup(v_arms_2449)));
          {
            V v_field_2459 = v_t_2457.f[1];
            int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
            if ((v_tag_2458 == ((int64_t)0ULL))) {
              V v_f_2461 = v_field_2459;
              v_it_2462 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2456, v_f_2461})});
            } else {
              heff_drop(v_t_2456);
              heff_drop(v_field_2459);
              v_it_2462 = NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_field_2454);
          v_it_2462 = NTAG(TAG_Nothing);
        }
      }
    } else {
      v_it_2462 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2462)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      return (g_heff_2ecompile_2eimperative_2ecaseTail(v_g_240, v_self_241, v_s_2448, v_arms_2449));
    }
    case TAG_Just: {
      V v_it1_2463 = heff_field(v_it_2462, 0);
      heff_take_n(v_it_2462, 1ULL, 1);
      switch (heff_tag_of(v_it1_2463)) {
      case TAG_MkPair: {
        V v_t_2464 = heff_field(v_it1_2463, 0);
        V v_f_2465 = heff_field(v_it1_2463, 1);
        heff_take_n(v_it1_2463, 3ULL, 2);
        V v_t_2466 = heff_dup(heff_rfield(v_g_240, 0));
        if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
          heff_drop(v_t_2466);
          switch (heff_tag_of(v_self_241)) {
          case TAG_Nothing: {
            V v_t_2467 = (g_heff_2ecompile_2eimperative_2econdShaped(heff_dup(v_t_2464)));
            if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
              heff_drop(v_t_2467);
              V v_t_2468 = (g_heff_2ecompile_2eimperative_2econdShaped(heff_dup(v_f_2465)));
              if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
                heff_drop(v_t_2468);
                V v_m_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 7)), 1, (V[]){v_e_242}));
                return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam1, 1, 7, (V[]){v_m_2469, v_g_240, v_self_241, v_s_2448, v_t_2464, v_f_2465, v_arms_2449});
              } else {
                heff_drop_tag(v_e_242, 2);
                heff_drop(v_t_2468);
                return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2448, v_t_2464, v_f_2465, v_arms_2449));
              }
            } else {
              heff_drop_tag(v_e_242, 2);
              heff_drop(v_t_2467);
              return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2448, v_t_2464, v_f_2465, v_arms_2449));
            }
          }
          case TAG_Just: {
            heff_drop_tag(v_e_242, 2);
            return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2448, v_t_2464, v_f_2465, v_arms_2449));
          }
          default: return heff_nomatch(v_self_241);
          }
        } else {
          heff_drop_tag(v_e_242, 2);
          heff_drop(v_t_2466);
          return (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2448, v_t_2464, v_f_2465, v_arms_2449));
        }
      }
      default: return heff_nomatch(v_it1_2463);
      }
    }
    default: return heff_nomatch(v_it_2462);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EPrimCall: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_ECall: {
    V v_k_2481 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2482 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_self_241)) {
    case TAG_Nothing: {
      heff_drop(v_k_2481);
      heff_drop(v_as_2482);
      return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
    }
    case TAG_Just: {
      V v_s_2483 = heff_field(v_self_241, 0);
      heff_take_n(v_self_241, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_s_2483, 0)), v_k_2481)) {
        V v_t_2485 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2482));
        if (heff_intEq_c(v_t_2485, heff_get_n(v_s_2483, 1, 2))) {
          heff_drop_tag(v_e_242, 2);
          V v_m_2487 = (g_heff_2ecompile_2eimperative_2eatomsOf(v_g_240, v_as_2482));
          return heff_clo_n(g_heff_2ecompile_2eimperative_2etailOf_lam2, 1, 1, (V[]){v_m_2487});
        } else {
          heff_drop(v_as_2482);
          return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
        }
      } else {
        heff_drop(v_as_2482);
        heff_drop_rec(v_s_2483, 2);
        return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
      }
    }
    default: return heff_nomatch(v_self_241);
    }
  }
  case TAG_EInt: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EStr: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EBytes: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFixed: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFloat32: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EAbandon: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  case TAG_EFix: {
    heff_drop(v_self_241);
    return (g_heff_2ecompile_2eimperative_2eopTail(v_g_240, v_e_242));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2etailOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2etailOf_lam0(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_b_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_m_2422 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_self_241, v_b_2411}));
    V v_x2_2423 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2421}));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_n_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_x_2438;
      switch (heff_tag_of(v_x_2420)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x2_2423_24MkPair, 2);
        v_x_2438 = v_x_2424;
        break;
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_x_2424)) {
        case TAG_TSeq: {
          V v_ss2_2428 = heff_field(v_x_2424, 0);
          V v_t_2429 = heff_field(v_x_2424, 1);
          heff_take_n(v_x_2424, 3ULL, 2);
          V v_t_2430 = (g_prelude_2e_2b_2b(v_x_2420, v_ss2_2428));
          v_x_2438 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_TSeq, 2, (V[]){v_t_2430, v_t_2429});
          break;
        }
        case TAG_TReturn: {
          v_x_2438 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_TSeq, 2, (V[]){v_x_2420, v_x_2424});
          break;
        }
        case TAG_TLoop: {
          v_x_2438 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_TSeq, 2, (V[]){v_x_2420, v_x_2424});
          break;
        }
        case TAG_TIf: {
          v_x_2438 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_TSeq, 2, (V[]){v_x_2420, v_x_2424});
          break;
        }
        case TAG_TCase: {
          v_x_2438 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_TSeq, 2, (V[]){v_x_2420, v_x_2424});
          break;
        }
        default: heff_nomatch(v_x_2424);
        }
        break;
      }
      default: heff_nomatch(v_x_2420);
      }
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2438, v_n_2425});
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam1(V self, V *args) {
  V v_n_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_self_241 = heff_env(self)[2];
  V v_s_2448 = heff_env(self)[3];
  V v_t_2464 = heff_env(self)[4];
  V v_f_2465 = heff_env(self)[5];
  V v_arms_2449 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_n_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_n_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    switch (heff_tag_of(v_x_2472)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_2471_24MkPair, 2);
      V v_t_2474 = (g_heff_2ecompile_2eimperative_2etestTail(v_g_240, v_self_241, v_s_2448, v_t_2464, v_f_2465, v_arms_2449));
      V f_ = v_t_2474;
      args[0] = v_n_2473;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_c_2475 = heff_field(v_x_2472, 0);
      V v_ru_24x_2472_24Just = heff_take_reuse_n(v_x_2472, 1ULL, 1);
      heff_drop_rec(v_g_240, 8);
      heff_drop(v_s_2448);
      heff_drop(v_t_2464);
      heff_drop(v_f_2465);
      heff_drop(v_arms_2449);
      V v_t_2476 = heff_tag_at_n(v_ru_24x_2472_24Just, TAG_TReturn, 1, (V[]){heff_tag_n(TAG_OBool, 1, (V[]){v_c_2475})});
      return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){v_t_2476, v_n_2473});
    }
    default: return heff_nomatch(v_x_2472);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eimperative_2etailOf_lam2(V self, V *args) {
  V v_n_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_n_2488}));
  switch (heff_tag_of(v_x2_2489)) {
  case TAG_MkPair: {
    V v_x_2490 = heff_field(v_x2_2489, 0);
    V v_n_2491 = heff_field(v_x2_2489, 1);
    V v_ru_24x2_2489_24MkPair = heff_take_reuse_n(v_x2_2489, 3ULL, 2);
    V v_ss_2494;
    switch (heff_tag_of(v_x_2490)) {
    case TAG_MkPair: {
      V v_x_2492 = heff_dup(heff_field(v_x_2490, 0));
      v_ss_2494 = v_x_2492;
      break;
    }
    default: heff_nomatch(v_x_2490);
    }
    V v_t_2497;
    switch (heff_tag_of(v_x_2490)) {
    case TAG_MkPair: {
      V v_y_2496 = heff_field(v_x_2490, 1);
      heff_take_n(v_x_2490, 2ULL, 2);
      v_t_2497 = v_y_2496;
      break;
    }
    default: heff_nomatch(v_x_2490);
    }
    V v_t_24100;
    switch (heff_tag_of(v_ss_2494)) {
    case TAG_Nil: {
      v_t_24100 = heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2497});
      break;
    }
    case TAG_Cons: {
      v_t_24100 = heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_2494, heff_tag_n(TAG_TLoop, 1, (V[]){v_t_2497})});
      break;
    }
    default: heff_nomatch(v_ss_2494);
    }
    return heff_tag_at_n(v_ru_24x2_2489_24MkPair, TAG_MkPair, 2, (V[]){v_t_24100, v_n_2491});
  }
  default: return heff_nomatch(v_x2_2489);
  }
}
V g_heff_2ecompile_2eimperative_2etailSelf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2etailSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2etailSelf_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2etailSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_242, 1);
    return (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eimperative_2etailSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2422));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_k_2431 = heff_field(v_e_242, 0);
    V v_as_2432 = heff_field(v_e_242, 1);
    if (heff_strEq_c_lent(v_k_2431, v_key_240, 2)) {
      V v_t_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2432));
      return heff_intEq(v_t_2434, v_n_241);
    } else {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eimperative_2etailSelf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eimperative_2etailSelf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eimperative_2etailSelf_lam0(V self, V *args) {
  V v_a_2423 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427;
  switch (heff_tag_of(v_a_2423)) {
  case TAG_MkArm: {
    V v_b_2426 = heff_field(v_a_2423, 2);
    heff_take_n(v_a_2423, 4ULL, 3);
    v_t_2427 = v_b_2426;
    break;
  }
  default: heff_nomatch(v_a_2423);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2427; V r_ = (g_heff_2ecompile_2eimperative_2etailSelf(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
}

HeffT2 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V v_g_240, V v_d_241, V v_z_242) {
top: ;
  V v_it_243 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_it_243)) {
  case TAG_EVar: {
    V v_m_245 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_n_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_247})});
      V v_f_2410 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_249});
      return ((HeffT2){{v_f_2410, v_n_248}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  case TAG_EGlobal: {
    V v_m_2412 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      V v_t_2416 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2414})});
      V v_f_2417 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2416});
      return ((HeffT2){{v_f_2417, v_n_2415}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2413)}});
    }
  }
  case TAG_ELam: {
    V v_xs_2418 = heff_field(v_it_243, 0);
    V v_b_2419 = heff_field(v_it_243, 1);
    V v_ru_24it_243_24ELam = heff_take_reuse_n(v_it_243, 3ULL, 2);
    V v_key_2420 = heff_dup(heff_rfield(v_d_241, 0));
    V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
    V v_t_2422 = (g_heff_2ecompile_2eimperative_2etailSelf(heff_dup(v_key_2420), v_t_2421, v_b_2419));
    V v_t_2424;
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2418));
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__arity, (V[]){v_key_2420, v_t_2423})});
    } else {
      heff_drop(v_key_2420);
      heff_drop(v_t_2422);
      v_t_2424 = NTAG(TAG_Nothing);
    }
    V v_m_2425 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){v_t_2424, v_b_2419}));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      V v_t_2429 = heff_tag_at_n(v_ru_24it_243_24ELam, TAG_DefFun, 2, (V[]){v_xs_2418, heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2427})});
      V v_f_2430 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2429});
      return ((HeffT2){{v_f_2430, v_n_2428}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2426)}});
    }
  }
  case TAG_EApp: {
    V v_m_2433 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_n_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      V v_t_2437 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2435})});
      V v_f_2438 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2437});
      return ((HeffT2){{v_f_2438, v_n_2436}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2434)}});
    }
  }
  case TAG_ELet: {
    V v_m_2442 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_n_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      V v_t_2446 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2444})});
      V v_f_2447 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2446});
      return ((HeffT2){{v_f_2447, v_n_2445}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2443)}});
    }
  }
  case TAG_ERecord: {
    V v_m_2450 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2451 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_MkPair: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_n_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      V v_t_2454 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2452})});
      V v_f_2455 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2454});
      return ((HeffT2){{v_f_2455, v_n_2453}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2451)}});
    }
  }
  case TAG_EProj: {
    V v_m_2460 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_n_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      V v_t_2464 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2462})});
      V v_f_2465 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2464});
      return ((HeffT2){{v_f_2465, v_n_2463}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2461)}});
    }
  }
  case TAG_ETag: {
    V v_m_2469 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_n_2472 = heff_field(v_x2_2470, 1);
      heff_take_n(v_x2_2470, 3ULL, 2);
      V v_t_2473 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2471})});
      V v_f_2474 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2473});
      return ((HeffT2){{v_f_2474, v_n_2472}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2470)}});
    }
  }
  case TAG_EMatch: {
    V v_m_2477 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_n_2480 = heff_field(v_x2_2478, 1);
      heff_take_n(v_x2_2478, 3ULL, 2);
      V v_t_2481 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2479})});
      V v_f_2482 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2481});
      return ((HeffT2){{v_f_2482, v_n_2480}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2478)}});
    }
  }
  case TAG_EPrim: {
    V v_m_2484 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_n_2487 = heff_field(v_x2_2485, 1);
      heff_take_n(v_x2_2485, 3ULL, 2);
      V v_t_2488 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2486})});
      V v_f_2489 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2488});
      return ((HeffT2){{v_f_2489, v_n_2487}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2485)}});
    }
  }
  case TAG_EPrimCall: {
    V v_m_2492 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2493)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x2_2493, 0);
      V v_n_2495 = heff_field(v_x2_2493, 1);
      heff_take_n(v_x2_2493, 3ULL, 2);
      V v_t_2496 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_2494})});
      V v_f_2497 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_2496});
      return ((HeffT2){{v_f_2497, v_n_2495}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2493)}});
    }
  }
  case TAG_ECall: {
    V v_m_24100 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24101 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_n_24103 = heff_field(v_x2_24101, 1);
      heff_take_n(v_x2_24101, 3ULL, 2);
      V v_t_24104 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24102})});
      V v_f_24105 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24104});
      return ((HeffT2){{v_f_24105, v_n_24103}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24101)}});
    }
  }
  case TAG_EInt: {
    V v_m_24107 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_n_24110 = heff_field(v_x2_24108, 1);
      heff_take_n(v_x2_24108, 3ULL, 2);
      V v_t_24111 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24109})});
      V v_f_24112 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24111});
      return ((HeffT2){{v_f_24112, v_n_24110}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24108)}});
    }
  }
  case TAG_EFloat: {
    V v_m_24114 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_n_24117 = heff_field(v_x2_24115, 1);
      heff_take_n(v_x2_24115, 3ULL, 2);
      V v_t_24118 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24116})});
      V v_f_24119 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24118});
      return ((HeffT2){{v_f_24119, v_n_24117}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24115)}});
    }
  }
  case TAG_EStr: {
    V v_m_24121 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24122 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24122)) {
    case TAG_MkPair: {
      V v_x_24123 = heff_field(v_x2_24122, 0);
      V v_n_24124 = heff_field(v_x2_24122, 1);
      heff_take_n(v_x2_24122, 3ULL, 2);
      V v_t_24125 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24123})});
      V v_f_24126 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24125});
      return ((HeffT2){{v_f_24126, v_n_24124}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24122)}});
    }
  }
  case TAG_EBytes: {
    V v_m_24128 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24129 = heff_tr(heff_call(v_m_24128, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24129)) {
    case TAG_MkPair: {
      V v_x_24130 = heff_field(v_x2_24129, 0);
      V v_n_24131 = heff_field(v_x2_24129, 1);
      heff_take_n(v_x2_24129, 3ULL, 2);
      V v_t_24132 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24130})});
      V v_f_24133 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24132});
      return ((HeffT2){{v_f_24133, v_n_24131}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24129)}});
    }
  }
  case TAG_EFixed: {
    V v_m_24136 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24137 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x2_24137, 0);
      V v_n_24139 = heff_field(v_x2_24137, 1);
      heff_take_n(v_x2_24137, 3ULL, 2);
      V v_t_24140 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24138})});
      V v_f_24141 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24140});
      return ((HeffT2){{v_f_24141, v_n_24139}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24137)}});
    }
  }
  case TAG_EFloat32: {
    V v_m_24143 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24144 = heff_tr(heff_call(v_m_24143, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24144)) {
    case TAG_MkPair: {
      V v_x_24145 = heff_field(v_x2_24144, 0);
      V v_n_24146 = heff_field(v_x2_24144, 1);
      heff_take_n(v_x2_24144, 3ULL, 2);
      V v_t_24147 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24145})});
      V v_f_24148 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24147});
      return ((HeffT2){{v_f_24148, v_n_24146}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24144)}});
    }
  }
  case TAG_EAbandon: {
    V v_m_24149 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24150 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24150)) {
    case TAG_MkPair: {
      V v_x_24151 = heff_field(v_x2_24150, 0);
      V v_n_24152 = heff_field(v_x2_24150, 1);
      heff_take_n(v_x2_24150, 3ULL, 2);
      V v_t_24153 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24151})});
      V v_f_24154 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24153});
      return ((HeffT2){{v_f_24154, v_n_24152}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24150)}});
    }
  }
  case TAG_EFix: {
    V v_m_24157 = heff_tr(heff_call(heff_get_n(v_g_240, 2, 8), 2, (V[]){NTAG(TAG_Nothing), v_it_243}));
    V v_x2_24158 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24158)) {
    case TAG_MkPair: {
      V v_x_24159 = heff_field(v_x2_24158, 0);
      V v_n_24160 = heff_field(v_x2_24158, 1);
      heff_take_n(v_x2_24158, 3ULL, 2);
      V v_t_24161 = heff_tag_n(TAG_DefVal, 1, (V[]){heff_tag_n(TAG_MkBlock, 1, (V[]){v_x_24159})});
      V v_f_24162 = heff_tag_n(TAG_MkDef, 3, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 1, 3), v_t_24161});
      return ((HeffT2){{v_f_24162, v_n_24160}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24158)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_243)}});
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam0(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsOp_lam1(V self, V *args);
V g_heff_2ecompile_2eimperative_2epartsOp_lam2(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsOp(V v_r_240, V v_o_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_o_241)) {
  case TAG_OSimple: {
    V v_v_243 = heff_dup(heff_field(v_o_241, 0));
    V v_t_244 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 5), 2, (V[]){v_v_243, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_244});
  }
  case TAG_OCall: {
    V v_as_246 = heff_dup(heff_field(v_o_241, 1));
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_246));
    V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsOp_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2410});
  }
  case TAG_OApply: {
    V v_f_2411 = heff_dup(heff_field(v_o_241, 0));
    V v_as_2412 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_2411, v_as_2412})));
    V v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsOp_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2416});
  }
  case TAG_OPrim: {
    V v_as_2418 = heff_dup(heff_field(v_o_241, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2418));
    V v_t_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsOp_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_acc_242; V a_2 = v_t_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2422});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_r_240, 5);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_acc_242});
  }
  case TAG_OBool: {
    V v_c_2423 = heff_dup(heff_field(v_o_241, 0));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 2, (V[]){v_c_2423, v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_241}), v_t_2424});
  }
  default: return heff_nomatch(v_o_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_249;
  args[1] = v_acc_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam1(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_x_2415 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2415;
  args[1] = v_acc_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2eimperative_2epartsOp_lam2(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_x_2421 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 5);
  args[0] = v_x_2421;
  args[1] = v_acc_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsCond(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_PFalse: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_PRel: {
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_b_245 = heff_field(v_x2_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_b_245), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_a_244), v_t_246});
  }
  case TAG_PBool: {
    V v_v_247 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_247), v_acc_242});
  }
  case TAG_PNot: {
    V v_c_248 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_248), v_acc_242});
  }
  case TAG_PIf: {
    V v_a_249 = heff_field(v_x2_241, 0);
    V v_b_2410 = heff_field(v_x2_241, 1);
    V v_c_2411 = heff_field(v_x2_241, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){heff_dup(v_c_2411), v_acc_242}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){heff_dup(v_b_2410), v_t_2412}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_a_249), v_t_2413});
  }
  case TAG_PLet: {
    V v_o_2415 = heff_field(v_x2_241, 1);
    V v_c_2416 = heff_field(v_x2_241, 2);
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 2, (V[]){heff_dup(v_c_2416), v_acc_242}));
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_2415), v_t_2417});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2epartsCond(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimperative_2epartsSt_lam0(V self, V *args);
Clo g_heff_2ecompile_2eimperative_2epartsSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsSt_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsSt(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLet: {
    V v_o_244 = heff_field(v_x2_241, 1);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_244), v_acc_242});
  }
  case TAG_SDecl: {
    heff_drop_rec(v_r_240, 5);
    return v_acc_242;
  }
  case TAG_SSet: {
    V v_o_247 = heff_field(v_x2_241, 1);
    return heff_tail(heff_get_n(v_r_240, 1, 5), 2, (V[]){heff_dup(v_o_247), v_acc_242});
  }
  case TAG_SIf: {
    V v_c_248 = heff_field(v_x2_241, 0);
    V v_ts_249 = heff_field(v_x2_241, 1);
    V v_fs_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 3)), 2, (V[]){heff_dup(v_fs_2410), v_acc_242}));
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_r_240, 3), 2, (V[]){heff_dup(v_ts_249), v_t_2411}));
    return heff_tail(heff_get_n(v_r_240, 2, 5), 2, (V[]){heff_dup(v_c_248), v_t_2412});
  }
  case TAG_SCase: {
    V v_v_2413 = heff_field(v_x2_241, 0);
    V v_arms_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2414)));
    V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epartsSt_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_acc_242; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    return heff_tail(heff_get_n(v_r_240, 0, 5), 2, (V[]){heff_dup(v_v_2413), v_t_2421});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eimperative_2epartsSt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eimperative_2epartsSt(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eimperative_2epartsSt_lam0(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_MkArm: {
    V v_ss_2420 = heff_field(v_x_2417, 2);
    heff_take_n(v_x_2417, 4ULL, 3);
    V f_ = heff_get_n(v_r_240, 3, 5);
    args[0] = v_ss_2420;
    args[1] = v_acc_2416;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam0, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam1, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam2, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args);
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam3, 2, 0};
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args); static Clo g_heff_2ecompile_2eimperative_2epk_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epk_lam5, 2, 0};

static V g_heff_2ecompile_2eimperative_2epk_val;
static HEFF_ONCE g_heff_2ecompile_2eimperative_2epk_st;
static V g_heff_2ecompile_2eimperative_2epk_init(void) {
  return heff_rec_n(5, shape_val__op__cond__sts__tl, (V[]){((V)&g_heff_2ecompile_2eimperative_2epk_lam0_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam1_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam2_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam3_clo), ((V)&g_heff_2ecompile_2eimperative_2epk_lam5_clo)});
}
V g_heff_2ecompile_2eimperative_2epk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eimperative_2epk_st)) return g_heff_2ecompile_2eimperative_2epk_val;
  return heff_global(&g_heff_2ecompile_2eimperative_2epk_val, &g_heff_2ecompile_2eimperative_2epk_st, g_heff_2ecompile_2eimperative_2epk_init);
}
V g_heff_2ecompile_2eimperative_2epk_lam0(V self, V *args) {
  V v_v_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsVal(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_v_240, v_acc_241));
}
V g_heff_2ecompile_2eimperative_2epk_lam1(V self, V *args) {
  V v_o_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2ecompile_2eimperative_2epartsOp(heff_dup(g_heff_2ecompile_2eimperative_2epk_get()), v_o_242, v_acc_243));
}
V g_heff_2ecompile_2eimperative_2epk_lam2(V self, V *args) {
  V v_c_244 = args[0];
  V v_acc_245 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get()); V a_1 = v_c_244; V a_2 = v_acc_245; V r_ = (g_heff_2ecompile_2eimperative_2epartsCond(a_0, a_1, a_2)); heff_drop(v_c_244); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam4(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_248; V a_1 = v_x_2411; V a_2 = v_acc_2410; V r_ = (g_heff_2ecompile_2eimperative_2epartsSt(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam3(V self, V *args) {
  V v_ss_246 = args[0];
  V v_acc_247 = args[1];
  V v_r_248 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get());
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_246));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eimperative_2epk_lam4, 2, 1, (V[]){v_r_248}); V a_1 = v_acc_247; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2eimperative_2epk_lam5(V self, V *args) {
  V v_t_2412 = args[0];
  V v_acc_2413 = args[1];
  return ({ V a_0 = heff_dup(g_heff_2ecompile_2eimperative_2epk_get()); V a_1 = v_t_2412; V a_2 = v_acc_2413; V r_ = (g_heff_2ecompile_2eimperative_2epartsTl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V v_v_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SStr: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SBytes: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFixed: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SFloat32: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SPrimFn: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
  }
  case TAG_SLam: {
    V v_v2_2413 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2413)) {
    case TAG_MkBlock: {
      V v_t_2414 = heff_field(v_v2_2413, 0);
      V v_ru_24v2_2413_24MkBlock = heff_take_reuse_n(v_v2_2413, 1ULL, 1);
      V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2413_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2415});
    }
    default: return heff_nomatch(v_v2_2413);
    }
  }
  case TAG_STag: {
    V v_as_2417 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2417));
    V v_t_2420 = ({ V a_0 = v_acc_241; V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2419); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2420});
  }
  case TAG_SRec: {
    V v_fs_2421 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2423 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2421));
    V v_t_2424 = ({ V a_0 = v_acc_241; V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2423); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2424});
  }
  case TAG_SProj: {
    V v_w_2425 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2430 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(v_w_2425, v_acc_241, heff_dup(v_cell_2429)));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  case TAG_SPrim: {
    V v_as_2432 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2432));
    V v_t_2434 = ({ V a_0 = v_acc_241; V a_1 = v_t_2433; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2433); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2434});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry, 3, 0};

V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(V v_v_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_SVar: {
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_244);
  }
  case TAG_SGlobal: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_SInt: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_SFloat: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
  }
  case TAG_SStr: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2412);
  }
  case TAG_SBytes: {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
  }
  case TAG_SFixed: {
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2417);
  }
  case TAG_SFloat32: {
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2419);
  }
  case TAG_SPrimFn: {
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_acc_241});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2421);
  }
  case TAG_SLam: {
    V v_v2_2423 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_2423)) {
    case TAG_MkBlock: {
      V v_t_2424 = heff_field(v_v2_2423, 0);
      V v_ru_24v2_2423_24MkBlock = heff_take_reuse_n(v_v2_2423, 1ULL, 1);
      V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a_0, a_1)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24v2_2423_24MkBlock, TAG_PartVal, 1, (V[]){v_v_240}), v_t_2425});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2426);
    }
    default: return heff_nomatch(v_v2_2423);
    }
  }
  case TAG_STag: {
    V v_as_2428 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2428));
    V v_t_2431 = ({ V a_0 = v_acc_241; V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2431});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2432);
  }
  case TAG_SRec: {
    V v_fs_2433 = heff_dup(heff_field(v_v_240, 0));
    V v_t_2435 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2433));
    V v_t_2436 = ({ V a_0 = v_acc_241; V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2436});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2437);
  }
  case TAG_SProj: {
    V v_w_2438 = heff_dup(heff_field(v_v_240, 0));
    V v_cell_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), heff_hole()});
    V v_u_2443 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2442));
    heff_drop(v_u_2443);
    V t_0 = v_w_2438;
    V t_1 = v_acc_241;
    V t_2 = v_cell_2442;
    v_v_240 = t_0;
    v_acc_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_as_2445 = heff_dup(heff_field(v_v_240, 1));
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2445));
    V v_t_2447 = ({ V a_0 = v_acc_241; V a_1 = v_t_2446; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2446); r_; });
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartVal, 1, (V[]){v_v_240}), v_t_2447});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2448);
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PTrue: {
    return v_acc_241;
  }
  case TAG_PFalse: {
    return v_acc_241;
  }
  case TAG_PRel: {
    V v_a_243 = heff_field(v_x2_240, 1);
    V v_b_244 = heff_field(v_x2_240, 2);
    V v_acc_245 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_b_244), v_acc_241));
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_a_243), v_acc_245);
  }
  case TAG_PBool: {
    V v_v_246 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_v_246), v_acc_241);
  }
  case TAG_PNot: {
    V v_c_247 = heff_field(v_x2_240, 0);
    V t_0 = v_c_247;
    V t_1 = v_acc_241;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_PIf: {
    V v_a_248 = heff_field(v_x2_240, 0);
    V v_b_249 = heff_field(v_x2_240, 1);
    V v_c_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2410), v_acc_241}));
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_b_249), v_t_2411}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_a_248), v_t_2412});
  }
  case TAG_PLet: {
    V v_o_2414 = heff_field(v_x2_240, 1);
    V v_c_2415 = heff_field(v_x2_240, 2);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_2415), v_acc_241}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_2414), v_t_2416});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(V v_o_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_242 = heff_dup(heff_field(v_o_240, 0));
    V v_t_243 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(v_v_242, v_acc_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_243});
  }
  case TAG_OCall: {
    V v_as_245 = heff_dup(heff_field(v_o_240, 1));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_245));
    V v_t_247 = ({ V a_0 = v_acc_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_246); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_247});
  }
  case TAG_OApply: {
    V v_f_248 = heff_dup(heff_field(v_o_240, 0));
    V v_as_249 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_as_249})));
    V v_t_2411 = ({ V a_0 = v_acc_241; V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2410); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2411});
  }
  case TAG_OPrim: {
    V v_as_2413 = heff_dup(heff_field(v_o_240, 1));
    V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2413));
    V v_t_2415 = ({ V a_0 = v_acc_241; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s634927308x1347712163(a_0, a_1)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2415});
  }
  case TAG_OAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_acc_241});
  }
  case TAG_OBool: {
    V v_c_2416 = heff_dup(heff_field(v_o_240, 0));
    V v_t_2417 = ({ V a_0 = v_c_2416; V a_1 = v_acc_241; V r_ = heff_tr(g_heff_2ecompile_2eimperative_2epartsCond_24s1965116114x717239437(a_0, a_1)); heff_drop(v_c_2416); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PartOp, 1, (V[]){v_o_240}), v_t_2417});
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2epartsOp_24s1881101281x987252639(a[0], a[1]);
}
Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry, 2, 0};

V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 1);
    V v_acc_244 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_243, v_acc_241));
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_242)));
    return ({ V a_0 = v_acc_244; V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s2003609603x1707519208(a_0, a_1)); heff_drop(v_t_245); r_; });
  }
  case TAG_TReturn: {
    V v_o_246 = heff_field(v_x2_240, 0);
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 1)), 2, (V[]){heff_dup(v_o_246), v_acc_241});
  }
  case TAG_TLoop: {
    V v_vs_247 = heff_field(v_x2_240, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
    return ({ V a_0 = v_acc_241; V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1299324685x840794767(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_TIf: {
    V v_c_249 = heff_field(v_x2_240, 0);
    V v_t_2410 = heff_field(v_x2_240, 1);
    V v_e_2411 = heff_field(v_x2_240, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 4)), 2, (V[]){heff_dup(v_e_2411), v_acc_241}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 4)), 2, (V[]){heff_dup(v_t_2410), v_t_2412}));
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 2)), 2, (V[]){heff_dup(v_c_249), v_t_2413});
  }
  case TAG_TCase: {
    V v_v_2414 = heff_field(v_x2_240, 0);
    V v_arms_2415 = heff_field(v_x2_240, 1);
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2415)));
    V v_t_2417 = ({ V a_0 = v_acc_241; V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s788715611x32297348(a_0, a_1)); heff_drop(v_t_2416); r_; });
    return heff_tail(heff_dup(heff_rfield(g_heff_2ecompile_2eimperative_2epk_get(), 0)), 2, (V[]){heff_dup(v_v_2414), v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eimperative_2eopNamesTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2eopNamesTop_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2eopNamesTop(V v_o_240) {
top: ;
  switch (heff_tag_of(v_o_240)) {
  case TAG_OSimple: {
    V v_v_241 = heff_field(v_o_240, 0);
    heff_take_n(v_o_240, 1ULL, 1);
    return ({ V a_0 = v_v_241; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eimperative_2evalNamesTop(a_0, a_1)); heff_drop(v_v_241); r_; });
  }
  case TAG_OCall: {
    V v_as_243 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_243));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_244); r_; });
  }
  case TAG_OApply: {
    V v_f_245 = heff_field(v_o_240, 0);
    V v_as_246 = heff_field(v_o_240, 1);
    V v_ru_24o_240_24OApply = heff_take_reuse_n(v_o_240, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24o_240_24OApply, TAG_Cons, 2, (V[]){v_f_245, v_as_246})));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  case TAG_OPrim: {
    V v_as_249 = heff_field(v_o_240, 1);
    heff_take_n(v_o_240, 2ULL, 2);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_249));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2410); r_; });
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_o_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_o_240);
  }
}
V g_heff_2ecompile_2eimperative_2eopNamesTop_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eimperative_2eopNamesTop(a[0]);
}
Clo g_heff_2ecompile_2eimperative_2efirstNamesTl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eimperative_2efirstNamesTl_entry, 1, 0};

V g_heff_2ecompile_2eimperative_2efirstNamesTl(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_TSeq: {
    V v_t1_241 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_t1_241)) {
    case TAG_Nil: {
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_st_243 = heff_field(v_t1_241, 0);
      switch (heff_tag_of(v_st_243)) {
      case TAG_SLet: {
        V v_o_246 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_246));
      }
      case TAG_SDecl: {
        return NTAG(TAG_Nil);
      }
      case TAG_SSet: {
        V v_o_249 = heff_field(v_st_243, 1);
        HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_249));
      }
      case TAG_SIf: {
        return NTAG(TAG_Nil);
      }
      case TAG_SCase: {
        V v_v_2413 = heff_field(v_st_243, 0);
        return (g_heff_2ecompile_2eimperative_2evalNamesTop(v_v_2413, NTAG(TAG_Nil)));
      }
      default: return heff_nomatch(v_st_243);
      }
    }
    default: return heff_nomatch(v_t1_241);
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_t_240, 0);
    HEFF_LAST return g_heff_2ecompile_2eimperative_2eopNamesTop(heff_dup(v_o_2415));
  }
  case TAG_TLoop: {
    V v_vs_2416 = heff_field(v_t_240, 0);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2416)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1735038056x329845490(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_TIf: {
    return NTAG(TAG_Nil);
  }
  case TAG_TCase: {
    V v_v_2421 = heff_field(v_t_240, 0);
    return (g_heff_2ecompile_2eimperative_2evalNamesTop(v_v_2421, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2ecompile_2eimperative_2efirstNamesTl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eimperative_2efirstNamesTl(a0); heff_drop(a0); return r;
}