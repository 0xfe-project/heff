// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_Among 19600
#define TAG_BadShape 33347
#define TAG_Dirs 41877
#define TAG_DirsOnly 64835
#define TAG_Extra 49222
#define TAG_Fail 27959
#define TAG_Files 59123
#define TAG_FilesBy 64286
#define TAG_Help 25956
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_NoValue 57584
#define TAG_None 17785
#define TAG_NotIn 31836
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Out 27098
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Some 35657
#define TAG_SwitchValue 32207
#define TAG_Unknown 64328
#define TAG_Words 20643
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_complete 145693389
#define LBL_count 296209705
#define LBL_doc 309170
#define LBL_flag 9641011
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_give 9668568
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_sh 10428
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_take 10047822
#define LBL_values 1123329101
#define LBL_waiting 1348170899
static uint32_t shape_flags__pos[] = {LBL_flags, LBL_pos};
static uint32_t shape_give__ap__flag__pos[] = {LBL_give, LBL_ap, LBL_flag, LBL_pos};
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
static uint32_t shape_pos__flags[] = {LBL_pos, LBL_flags};
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
static uint32_t shape_shape__take[] = {LBL_shape, LBL_take};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s150576211x246752688(V, V, V, V, V, V, V);
V g_list_2eany_24s150576211x246752688_entry(V self, V *a);
extern Clo g_list_2eany_24s150576211x246752688_clo;
V g_list_2eany_24s193691892x499187556(V, V, V, V);
V g_list_2eany_24s193691892x499187556_entry(V self, V *a);
extern Clo g_list_2eany_24s193691892x499187556_clo;
V g_list_2eany_24s70593242x1575694473(V, V);
V g_list_2eany_24s70593242x1575694473_entry(V self, V *a);
extern Clo g_list_2eany_24s70593242x1575694473_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24f1490579794x1456232270(V, V, V, V, V, V, V);
V g_list_2efilter_24f1490579794x1456232270_entry(V self, V *a);
extern Clo g_list_2efilter_24f1490579794x1456232270_clo;
V g_list_2efilter_24f419751885x381357165(V, V);
V g_list_2efilter_24f419751885x381357165_entry(V self, V *a);
extern Clo g_list_2efilter_24f419751885x381357165_clo;
V g_list_2efilter_24s1200694983x1257685262(V, V);
V g_list_2efilter_24s1200694983x1257685262_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_clo;
V g_list_2efilter_24s1623010005x1805617852(V);
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_clo;
V g_list_2efilter_24s2009824277x1398398543(V, V, V);
V g_list_2efilter_24s2009824277x1398398543_entry(V self, V *a);
extern Clo g_list_2efilter_24s2009824277x1398398543_clo;
V g_list_2efilter_24s2016771181x401513202(V, V, V);
V g_list_2efilter_24s2016771181x401513202_entry(V self, V *a);
extern Clo g_list_2efilter_24s2016771181x401513202_clo;
V g_list_2efilter_24s561186959x2071570661(V, V, V);
V g_list_2efilter_24s561186959x2071570661_entry(V self, V *a);
extern Clo g_list_2efilter_24s561186959x2071570661_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s1541406305x377496150(V, V);
V g_list_2efind_24s1541406305x377496150_entry(V self, V *a);
extern Clo g_list_2efind_24s1541406305x377496150_clo;
V g_list_2efind_24s1839921325x671097810(V, V);
V g_list_2efind_24s1839921325x671097810_entry(V self, V *a);
extern Clo g_list_2efind_24s1839921325x671097810_clo;
V g_list_2efind_24s575827429x1292946038(V, V);
V g_list_2efind_24s575827429x1292946038_entry(V self, V *a);
extern Clo g_list_2efind_24s575827429x1292946038_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f130772758x674845987(V, V, V, V);
V g_list_2emap_24f130772758x674845987_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_clo;
V g_list_2emap_24f130772758x674845987_24f797488600x357897558(V, V, V, V);
V g_list_2emap_24f130772758x674845987_24f797488600x357897558_entry(V self, V *a);
extern Clo g_list_2emap_24f130772758x674845987_24f797488600x357897558_clo;
V g_list_2emap_24f134831722x1788320834(V, V, V);
V g_list_2emap_24f134831722x1788320834_entry(V self, V *a);
extern Clo g_list_2emap_24f134831722x1788320834_clo;
V g_list_2emap_24f1690623035x874154762(V, V, V, V, V, V);
V g_list_2emap_24f1690623035x874154762_entry(V self, V *a);
extern Clo g_list_2emap_24f1690623035x874154762_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1412546768x2004463577(V, V, V, V);
V g_list_2emap_24s1412546768x2004463577_entry(V self, V *a);
extern Clo g_list_2emap_24s1412546768x2004463577_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1854779998x1713580578(V);
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
V g_std_2ecli_2ebashScript(V);
V g_std_2ecli_2ebashScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ebashScript_clo;
V g_std_2ecli_2ecandidatesText(V, V);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2ecommandsText(V, V);
V g_std_2ecli_2ecommandsText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecommandsText_clo;
V g_std_2ecli_2ecompleteAt(V, V, V);
V g_std_2ecli_2ecompleteAt_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteAt_clo;
V g_std_2ecli_2ecompleteWords(V, V, V);
V g_std_2ecli_2ecompleteWords_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteWords_clo;
V g_std_2ecli_2edistance(V, V);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
V g_std_2ecli_2edupOf(V);
V g_std_2ecli_2edupOf_entry(V self, V *a);
extern Clo g_std_2ecli_2edupOf_clo;
V g_std_2ecli_2efirstJust(V, V);
V g_std_2ecli_2efirstJust_entry(V self, V *a);
extern Clo g_std_2ecli_2efirstJust_clo;
V g_std_2ecli_2efishScript(V);
V g_std_2ecli_2efishScript_entry(V self, V *a);
extern Clo g_std_2ecli_2efishScript_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagProblem(V, V);
V g_std_2ecli_2eflagProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagProblem_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2egroupsGo(V, V);
V g_std_2ecli_2egroupsGo_entry(V self, V *a);
extern Clo g_std_2ecli_2egroupsGo_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2ehelpOf(V, V);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2einitOf(V);
V g_std_2ecli_2einitOf_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_clo;
V g_std_2ecli_2einitOf_24dps(V, V);
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_24dps_clo;
V g_std_2ecli_2elastOf(V);
V g_std_2ecli_2elastOf_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOf_clo;
V g_std_2ecli_2elastOnly(V);
V g_std_2ecli_2elastOnly_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOnly_clo;
V g_std_2ecli_2elastOr(V, V);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2ecli_2elongF_24s1119688962x564470218(V, V, V);
V g_std_2ecli_2elongF_24s1119688962x564470218_entry(V self, V *a);
extern Clo g_std_2ecli_2elongF_24s1119688962x564470218_clo;
V g_std_2ecli_2elongNamed(V, V);
V g_std_2ecli_2elongNamed_entry(V self, V *a);
extern Clo g_std_2ecli_2elongNamed_clo;
V g_std_2ecli_2elookupL(V, V);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2enearest(V, V);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2enextGo(V, V, V, V, V, V);
V g_std_2ecli_2enextGo_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_clo;
V g_std_2ecli_2enextGo_24dps(V, V, V, V, V, V, V);
V g_std_2ecli_2enextGo_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_24dps_clo;
V g_std_2ecli_2eorList(V);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_std_2ecli_2eorList_24acc(V, V);
V g_std_2ecli_2eorList_24acc_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_24acc_clo;
V g_std_2ecli_2eoutcomeOf(V, V, V);
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eoutcomeOf_clo;
V g_std_2ecli_2eparse(V, V);
V g_std_2ecli_2eparse_entry(V self, V *a);
extern Clo g_std_2ecli_2eparse_clo;
V g_std_2ecli_2eposAt(V, V);
V g_std_2ecli_2eposAt_entry(V self, V *a);
extern Clo g_std_2ecli_2eposAt_clo;
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2ecli_2ereadLine(V, V, V);
V g_std_2ecli_2ereadLine_entry(V self, V *a);
extern Clo g_std_2ecli_2ereadLine_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
V g_std_2ecli_2eshapeProblem(V);
V g_std_2ecli_2eshapeProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eshapeProblem_clo;
V g_std_2ecli_2eshells_get(void);
V g_std_2ecli_2eshortF_24s1014269042x1715098139(V, V, V);
V g_std_2ecli_2eshortF_24s1014269042x1715098139_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortF_24s1014269042x1715098139_clo;
V g_std_2ecli_2eshortWhere(V, V, V);
V g_std_2ecli_2eshortWhere_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_clo;
V g_std_2ecli_2eusage(V, V);
V g_std_2ecli_2eusage_entry(V self, V *a);
extern Clo g_std_2ecli_2eusage_clo;
V g_std_2ecli_2ewhereGo(V, V, V, V);
V g_std_2ecli_2ewhereGo_entry(V self, V *a);
extern Clo g_std_2ecli_2ewhereGo_clo;
V g_std_2ecli_2ewordsF_24s1352288509x2021617997(V, V);
V g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry(V self, V *a);
extern Clo g_std_2ecli_2ewordsF_24s1352288509x2021617997_clo;
V g_std_2ecli_2ezshScript(V);
V g_std_2ecli_2ezshScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ezshScript_clo;
Clo g_std_2ecli_2elastS_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastS_entry, 1, 0};

V g_std_2ecli_2elastS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastS(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2elookupL_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elookupL_entry, 2, 0};

V g_std_2ecli_2elookupL(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_240, v_x_244, 0)) {
        heff_drop(v_k_240);
        return heff_dup(v_vs_245);
      } else {
        V t_0 = v_k_240;
        V t_1 = v_rest_243;
        v_k_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elookupL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2elookupL(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2ereading_lam1(V self, V *args);
V g_std_2ecli_2ereading_lam0(V self, V *args); static Clo g_std_2ecli_2ereading_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam0, 1, 0};
V g_std_2ecli_2ereading_lam3(V self, V *args);
V g_std_2ecli_2ereading_lam2(V self, V *args); static Clo g_std_2ecli_2ereading_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam2, 2, 0};
V g_std_2ecli_2ereading_lam5(V self, V *args);
V g_std_2ecli_2ereading_lam4(V self, V *args); static Clo g_std_2ecli_2ereading_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam4, 1, 0};
V g_std_2ecli_2ereading_lam7(V self, V *args); static Clo g_std_2ecli_2ereading_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam7, 2, 0};
V g_std_2ecli_2ereading_lam6(V self, V *args); static Clo g_std_2ecli_2ereading_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam6, 1, 0};

static V g_std_2ecli_2ereading_val;
static HEFF_ONCE g_std_2ecli_2ereading_st;
static V g_std_2ecli_2ereading_init(void) {
  return heff_rec_n(4, shape_give__ap__flag__pos, (V[]){((V)&g_std_2ecli_2ereading_lam0_clo), ((V)&g_std_2ecli_2ereading_lam2_clo), ((V)&g_std_2ecli_2ereading_lam4_clo), ((V)&g_std_2ecli_2ereading_lam6_clo)});
}
V g_std_2ecli_2ereading_get(void) {
  if (HEFF_DONE(g_std_2ecli_2ereading_st)) return g_std_2ecli_2ereading_val;
  return heff_global(&g_std_2ecli_2ereading_val, &g_std_2ecli_2ereading_st, g_std_2ecli_2ereading_init);
}
V g_std_2ecli_2ereading_lam1(V self, V *args) {
  V v_x_242 = args[0];
  V v_x_243 = args[1];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_242);
  heff_drop(v_x_243);
  return v_x_240;
}
V g_std_2ecli_2ereading_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_t_241 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_241, heff_clo_n(g_std_2ecli_2ereading_lam1, 2, 1, (V[]){v_x_240})});
}
V g_std_2ecli_2ereading_lam3(V self, V *args) {
  V v_groups_2412 = args[0];
  V v_fl_2413 = args[1];
  V v_f_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_f_244, 0)), 1, 2);
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_list_2edrop(v_t_2415, heff_dup(v_groups_2412)));
  V v_t_2417 = heff_tr(heff_call(heff_get_n(v_x_245, 1, 2), 2, (V[]){v_t_2416, heff_dup(v_fl_2413)}));
  V f_ = heff_get_n(v_f_244, 1, 2);
  heff_room[0] = v_groups_2412;
  heff_room[1] = v_fl_2413;
  heff_room[2] = v_t_2417;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2ecli_2ereading_lam2(V self, V *args) {
  V v_f_244 = args[0];
  V v_x_245 = args[1];
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_f_244, 0)), 0, 2);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_245, 0)), 0, 2);
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, v_t_247));
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_f_244, 0)), 1, 2);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_x_245, 0)), 1, 2);
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
  return heff_rec_n(2, shape_shape__take, (V[]){heff_rec_n(2, shape_flags__pos, (V[]){v_t_248, v_t_2411}), heff_clo_n(g_std_2ecli_2ereading_lam3, 2, 2, (V[]){v_f_244, v_x_245})});
}
V g_std_2ecli_2ereading_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_given_2422 = args[1];
  V v_fl_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  return ({ V a_0 = heff_get_n(v_fl_2418, 0, 8); V a_1 = v_given_2422; V r_ = (g_std_2ecli_2elookupL(a_0, a_1)); heff_drop(v_given_2422); r_; });
}
V g_std_2ecli_2ereading_lam4(V self, V *args) {
  V v_fl_2418 = args[0];
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_fl_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_rec_n(2, shape_flags__pos, (V[]){v_t_2419, NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2420, heff_clo_n(g_std_2ecli_2ereading_lam5, 2, 1, (V[]){v_fl_2418})});
}
V g_std_2ecli_2ereading_lam7(V self, V *args) {
  V v_groups_2426 = args[0];
  V v_x_2427 = args[1];
  heff_drop(v_x_2427);
  switch (heff_tag_of(v_groups_2426)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_groups_2426, 0);
    heff_take_n(v_groups_2426, 1ULL, 2);
    return v_x_2428;
  }
  default: return heff_nomatch(v_groups_2426);
  }
}
V g_std_2ecli_2ereading_lam6(V self, V *args) {
  V v_p_2423 = args[0];
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2423, NTAG(TAG_Nil)});
  V v_t_2425 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), v_t_2424});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2425, ((V)&g_std_2ecli_2ereading_lam7_clo)});
}
Clo g_std_2ecli_2edupOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2edupOf_entry, 1, 0};

V g_std_2ecli_2edupOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
    V v_t_244 = (g_list_2eany(v_t_243, v_rest_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2edupOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2edupOf(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2elastOnly_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOnly_entry, 1, 0};

V g_std_2ecli_2elastOnly(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_t_245 = heff_dup(heff_rfield(v_p_241, 1));
      switch (heff_tag_of(v_t_245)) {
      case TAG_One: {
        V t_0 = v_x12_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_Optional: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))});
      }
      case TAG_Many: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))});
      }
      case TAG_Some: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))});
      }
      case TAG_Rest: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_p_241, 0))});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastOnly(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eshapeProblem_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str1, 1, "-");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str3, 26, "a short name is one letter");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str4, 4, "help");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str5, 1, "h");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str6, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str7, 1, "=");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str8, 69, "--help and -h are the library's; a long name is not empty, has no `=`");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str9, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str10, 23, "a switch takes no value");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str11, 41, " is every word, so no flag could be given");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str12, 54, " takes more or less than one word, and is not the last");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str13, 1, "-");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str14, 6, " twice");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str15, 2, "--");
HEFF_LIT(g_std_2ecli_2eshapeProblem_str16, 6, " twice");
Clo g_std_2ecli_2eshapeProblem_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshapeProblem_entry, 1, 0};

V g_std_2ecli_2eshapeProblem(V v_sh_240) {
top: ;
  V v_t_241 = (g_list_2emap_24s1854779998x1713580578(heff_dup(heff_rfield(v_sh_240, 0))));
  V v_t_242 = ({ V a_0 = v_t_241; V r_ = (g_std_2ecli_2edupOf(a_0)); heff_drop(v_t_241); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = (g_list_2efilter_24f419751885x381357165(((V)&g_std_2ecli_2eshapeProblem_str0), heff_dup(heff_rfield(v_sh_240, 0))));
    V v_t_244 = ({ V a_0 = v_t_243; V r_ = (g_std_2ecli_2edupOf(a_0)); heff_drop(v_t_243); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_list_2eany_24s193691892x499187556(MK_INT(1LL), ((V)&g_std_2ecli_2eshapeProblem_str1), ((V)&g_std_2ecli_2eshapeProblem_str2), heff_rfield(v_sh_240, 0)));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop_rec(v_sh_240, 2);
        heff_drop(v_t_245);
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_std_2ecli_2eshapeProblem_str3)});
      } else {
        heff_drop(v_t_245);
        V v_t_246 = (g_list_2eany_24s150576211x246752688(((V)&g_std_2ecli_2eshapeProblem_str4), ((V)&g_std_2ecli_2eshapeProblem_str5), ((V)&g_std_2ecli_2eshapeProblem_str6), ((V)&g_std_2ecli_2eshapeProblem_str7), MK_INT(0LL), MK_INT(0LL), heff_rfield(v_sh_240, 0)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop_rec(v_sh_240, 2);
          heff_drop(v_t_246);
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_std_2ecli_2eshapeProblem_str8)});
        } else {
          heff_drop(v_t_246);
          V v_t_247 = (g_list_2eany_24s70593242x1575694473(((V)&g_std_2ecli_2eshapeProblem_str9), heff_rfield(v_sh_240, 0)));
          if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
            heff_drop_rec(v_sh_240, 2);
            heff_drop(v_t_247);
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_std_2ecli_2eshapeProblem_str10)});
          } else {
            heff_drop(v_t_247);
            V v_t_248 = (g_std_2ecli_2elastOnly(heff_rfield(v_sh_240, 1)));
            switch (heff_tag_of(v_t_248)) {
            case TAG_Nothing: {
              V v_t_249 = heff_take_field(v_sh_240, 1);
              switch (heff_tag_of(v_t_249)) {
              case TAG_Nil: {
                heff_drop_rec(v_sh_240, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_p_2410 = heff_field(v_t_249, 0);
                heff_take_n(v_t_249, 1ULL, 2);
                V v_t_2412 = heff_take_field(v_p_2410, 1);
                switch (heff_tag_of(v_t_2412)) {
                case TAG_One: {
                  heff_drop_rec(v_sh_240, 2);
                  heff_drop_rec(v_p_2410, 3);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Optional: {
                  heff_drop_rec(v_sh_240, 2);
                  heff_drop_rec(v_p_2410, 3);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Many: {
                  heff_drop_rec(v_sh_240, 2);
                  heff_drop_rec(v_p_2410, 3);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Some: {
                  heff_drop_rec(v_sh_240, 2);
                  heff_drop_rec(v_p_2410, 3);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Rest: {
                  V v_t_2413 = heff_get_n(v_sh_240, 0, 2);
                  switch (heff_tag_of(v_t_2413)) {
                  case TAG_Nil: {
                    heff_drop_rec(v_p_2410, 3);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Cons: {
                    heff_take_n(v_t_2413, 0ULL, 2);
                    V v_t_2416 = heff_strAppend(heff_get_n(v_p_2410, 0, 3), ((V)&g_std_2ecli_2eshapeProblem_str11));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
                  }
                  default: return heff_nomatch(v_t_2413);
                  }
                }
                default: return heff_nomatch(v_t_2412);
                }
              }
              default: return heff_nomatch(v_t_249);
              }
            }
            case TAG_Just: {
              V v_m_2417 = heff_field(v_t_248, 0);
              V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
              heff_drop_rec(v_sh_240, 2);
              return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_m_2417, ((V)&g_std_2ecli_2eshapeProblem_str12))});
            }
            default: return heff_nomatch(v_t_248);
            }
          }
        }
      }
    }
    case TAG_Just: {
      V v_x_2418 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop_rec(v_sh_240, 2);
      V v_t_2419 = heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_str13), heff_strAppend(v_x_2418, ((V)&g_std_2ecli_2eshapeProblem_str14)));
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_2419});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop_rec(v_sh_240, 2);
    V v_t_2421 = heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_str15), heff_strAppend(v_x_2420, ((V)&g_std_2ecli_2eshapeProblem_str16)));
    return heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2eshapeProblem_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshapeProblem(a[0]);
}
Clo g_std_2ecli_2elongNamed_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elongNamed_entry, 2, 0};

V g_std_2ecli_2elongNamed(V v_sh_240, V v_x_241) {
top: ;
  V v_t_242 = (g_list_2efind_24s1839921325x671097810(heff_dup(v_x_241), heff_rfield(v_sh_240, 0)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_fs_243 = (g_list_2efilter_24s561186959x2071570661(MK_INT(0LL), v_x_241, heff_get_n(v_sh_240, 0, 2)));
    switch (heff_tag_of(v_fs_243)) {
    case TAG_Nil: {
      V v_t_244 = (g_list_2emap_24s1854779998x1713580578(v_fs_243));
      return heff_tag_n(TAG_Left, 1, (V[]){v_t_244});
    }
    case TAG_Cons: {
      V v_f_245 = heff_dup(heff_field(v_fs_243, 0));
      V v_fs2_246 = heff_dup(heff_field(v_fs_243, 1));
      switch (heff_tag_of(v_fs2_246)) {
      case TAG_Nil: {
        heff_drop_tag(v_fs_243, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){v_f_245});
      }
      case TAG_Cons: {
        heff_take_n(v_fs2_246, 0ULL, 2);
        heff_drop(v_f_245);
        V v_t_249 = (g_list_2emap_24s1854779998x1713580578(v_fs_243));
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_249});
      }
      default: return heff_nomatch(v_fs2_246);
      }
    }
    default: return heff_nomatch(v_fs_243);
    }
  }
  case TAG_Just: {
    V v_f_2410 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop_rec(v_sh_240, 2);
    heff_drop(v_x_241);
    return heff_tag_at_n(v_ru_24t_242_24Just, TAG_Right, 1, (V[]){v_f_2410});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2elongNamed_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2elongNamed(a[0], a[1]);
}
Clo g_std_2ecli_2ecellOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecellOf_entry, 6, 0};

V g_std_2ecli_2ecellOf(V v_a_240, V v_c_241, V v_up_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  V v_x_246 = heff_intAdd(v_up_242, MK_INT(1LL));
  V v_y_247 = heff_intAdd(v_left_244, MK_INT(1LL));
  V v_x_249;
  if (heff_intLe_c(heff_dup(v_x_246), heff_dup(v_y_247))) {
    heff_drop(v_y_247);
    v_x_249 = v_x_246;
  } else {
    heff_drop(v_x_246);
    v_x_249 = v_y_247;
  }
  V v_t_2410 = heff_strByteAt(v_a_240, heff_intSub(v_i_245, MK_INT(1LL)));
  V v_t_2412;
  if (heff_intEq_c(v_t_2410, v_c_241)) {
    v_t_2412 = MK_INT(0LL);
  } else {
    v_t_2412 = MK_INT(1LL);
  }
  V v_y_2413 = heff_intAdd(v_diag_243, v_t_2412);
  if (heff_intLe_c(heff_dup(v_x_249), heff_dup(v_y_2413))) {
    heff_drop(v_y_2413);
    return v_x_249;
  } else {
    heff_drop(v_x_249);
    return v_y_2413;
  }
}
V g_std_2ecli_2ecellOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecellOf(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2enextGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enextGo_entry, 6, 0};

V g_std_2ecli_2enextGo(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_a_240);
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_up_246 = heff_field(v_x3_242, 0);
    V v_ups_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_246), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_t_2410 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_246), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V v_u_2411 = (g_std_2ecli_2enextGo_24dps(v_a_240, v_c_241, v_ups_247, v_up_246, v_t_2410, heff_intAdd(v_i_245, MK_INT(1LL)), heff_dup(v_cell_249)));
    heff_drop(v_u_2411);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2enextGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enextGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2enextGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enextGo_24dps_entry, 7, 0};

V g_std_2ecli_2enextGo_24dps(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_a_240);
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_up_247 = heff_field(v_x3_242, 0);
    V v_ups_248 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_249 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_247), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V v_t_2412 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_247), v_diag_243, v_left_244, heff_dup(v_i_245)));
    V t_0 = v_a_240;
    V t_1 = v_c_241;
    V t_2 = v_ups_248;
    V t_3 = v_up_247;
    V t_4 = v_t_2412;
    V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
    V t_6 = v_cell_2410;
    v_a_240 = t_0;
    v_c_241 = t_1;
    v_x3_242 = t_2;
    v_diag_243 = t_3;
    v_left_244 = t_4;
    v_i_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2enextGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enextGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_std_2ecli_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOr_entry, 2, 0};

V g_std_2ecli_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_d_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2elastOr(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2edistance_lam0(V self, V *args);
Clo g_std_2ecli_2edistance_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2edistance_entry, 2, 0};

V g_std_2ecli_2edistance(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_strLength_lent(v_a_240, 0), MK_INT(1LL));
  V v_t_243 = (g_list_2erange(MK_INT(0LL), v_t_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_2414 = ({ V a_0 = heff_clo_n(g_std_2ecli_2edistance_lam0, 2, 2, (V[]){v_a_240, v_b_241}); V a_1 = v_t_243; V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2414; V r_ = (g_std_2ecli_2elastOr(a_0, a_1)); heff_drop(v_t_2414); r_; });
}
V g_std_2ecli_2edistance_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2edistance(a[0], a[1]);
}
V g_std_2ecli_2edistance_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_j_246 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_b_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_xs_248 = heff_dup(heff_field(v_row_245, 1));
    v_t_249 = v_xs_248;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  V v_t_2412;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_row_245, 0);
    heff_take_n(v_row_245, 1ULL, 2);
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  V v_t_2413 = (g_std_2ecli_2enextGo(v_a_240, heff_strByteAt_lent(v_b_241, v_j_246, 1), v_t_249, v_t_2412, heff_intAdd(heff_dup(v_j_246), MK_INT(1LL)), MK_INT(1LL)));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_j_246, MK_INT(1LL)), v_t_2413});
}
V g_std_2ecli_2enearest_lam0(V self, V *args);
Clo g_std_2ecli_2enearest_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enearest_entry, 2, 0};

V g_std_2ecli_2enearest(V v_sh_240, V v_x_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_std_2ecli_2enearest_lam0, 2, 1, (V[]){v_x_241}); V a_1 = NTAG(TAG_Nothing); V b_2 = heff_get_n(v_sh_240, 0, 2); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2enearest_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enearest(a[0], a[1]);
}
V g_std_2ecli_2enearest_lam0(V self, V *args) {
  V v_best_242 = args[0];
  V v_f_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_std_2ecli_2edistance(heff_dup(heff_rfield(v_f_243, 0)), heff_dup(v_x_241)));
  if (heff_intLe_c(v_t_244, MK_INT(2LL))) {
    if (heff_intLe_c(heff_strLength_lent(v_x_241, 0), MK_INT(16LL))) {
      switch (heff_tag_of(v_best_242)) {
      case TAG_Nothing: {
        heff_drop(v_x_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
      }
      case TAG_Just: {
        V v_b_247 = heff_dup(heff_field(v_best_242, 0));
        V v_t_248 = (g_std_2ecli_2edistance(heff_dup(heff_rfield(v_f_243, 0)), heff_dup(v_x_241)));
        V v_t_249 = (g_std_2ecli_2edistance(v_b_247, v_x_241));
        if (heff_intLt_c(v_t_248, v_t_249)) {
          heff_drop_tag(v_best_242, 1);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
        } else {
          heff_drop_rec(v_f_243, 8);
          return v_best_242;
        }
      }
      default: return heff_nomatch(v_best_242);
      }
    } else {
      heff_drop_rec(v_f_243, 8);
      heff_drop(v_x_241);
      return v_best_242;
    }
  } else {
    heff_drop_rec(v_f_243, 8);
    heff_drop(v_x_241);
    return v_best_242;
  }
}
Clo g_std_2ecli_2erestIndex_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erestIndex_entry, 2, 0};

V g_std_2ecli_2erestIndex(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_dup(heff_rfield(v_x11_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Optional: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Many: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Some: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Rest: {
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2erestIndex_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2erestIndex(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str0, 1, "=");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str3, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str4, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str5, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str6, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str7, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str8, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_str9, 2, "--");
Clo g_std_2ecli_2elongF_24s1119688962x564470218_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elongF_24s1119688962x564470218_entry, 3, 0};

V g_std_2ecli_2elongF_24s1119688962x564470218(V v_at_240, V v_ws_241, V v_body_242) {
top: ;
  V v_j_243 = (g_prelude_2estrFind(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str0), heff_dup(v_body_242), MK_INT(0LL)));
  V v_t_245;
  if (heff_intLt_c(heff_dup(v_j_243), MK_INT(0LL))) {
    heff_drop(v_j_243);
    v_t_245 = NTAG(TAG_Nothing);
  } else {
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_j_243});
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_std_2ecli_2elongNamed(heff_dup(heff_rfield(v_at_240, 0)), heff_dup(v_body_242)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Left: {
      V v_cands_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Left = heff_take_reuse_n(v_t_246, 1ULL, 1);
      heff_drop(v_ws_241);
      V v_t_2411;
      switch (heff_tag_of(v_cands_247)) {
      case TAG_Nil: {
        V v_t_248 = (g_std_2ecli_2enearest(heff_get_n(v_at_240, 0, 5), heff_dup(v_body_242)));
        v_t_2411 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str1), v_body_242), v_t_248});
        break;
      }
      case TAG_Cons: {
        heff_drop_rec(v_at_240, 5);
        v_t_2411 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str2), v_body_242), v_cands_247});
        break;
      }
      default: heff_nomatch(v_cands_247);
      }
      return heff_tag_at_n(v_ru_24t_246_24Left, TAG_Left, 1, (V[]){v_t_2411});
    }
    case TAG_Right: {
      V v_f_2412 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Right = heff_take_reuse_n(v_t_246, 1ULL, 1);
      heff_drop(v_body_242);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_2412, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str3))) {
        heff_drop_cell(v_ru_24t_246_24Right, 1);
        V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2412, 0, 8), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str4)});
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_at_240, 4)});
        V v_t_2416 = ({ V rv_4 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2416, v_ws_241));
      } else {
        switch (heff_tag_of(v_ws_241)) {
        case TAG_Nil: {
          heff_drop_rec(v_at_240, 5);
          V v_t_2417 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str5), heff_get_n(v_f_2412, 0, 8));
          return heff_tag_at_n(v_ru_24t_246_24Right, TAG_Left, 1, (V[]){heff_tag_n(TAG_NoValue, 1, (V[]){v_t_2417})});
        }
        case TAG_Cons: {
          V v_v_2418 = heff_field(v_ws_241, 0);
          V v_ws2_2419 = heff_field(v_ws_241, 1);
          V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
          heff_drop_cell(v_ru_24t_246_24Right, 1);
          V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2412, 0, 8), v_v_2418});
          V v_t_2421 = heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_dup(heff_rfield(v_at_240, 4))});
          V v_t_2422 = ({ V rv_4 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
          return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2422, v_ws2_2419));
        }
        default: return heff_nomatch(v_ws_241);
        }
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_Just: {
    V v_i_2423 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_2424 = (g_std_2ecli_2elongNamed(heff_dup(heff_rfield(v_at_240, 0)), heff_strSlice_lent(v_body_242, MK_INT(0LL), v_i_2423, 2)));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Left: {
      V v_cands_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      heff_drop(v_ws_241);
      V v_x_2426 = heff_strSlice(v_body_242, MK_INT(0LL), v_i_2423);
      V v_t_2430;
      switch (heff_tag_of(v_cands_2425)) {
      case TAG_Nil: {
        V v_t_2427 = (g_std_2ecli_2enearest(heff_get_n(v_at_240, 0, 5), heff_dup(v_x_2426)));
        v_t_2430 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str6), v_x_2426), v_t_2427});
        break;
      }
      case TAG_Cons: {
        heff_drop_rec(v_at_240, 5);
        v_t_2430 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str7), v_x_2426), v_cands_2425});
        break;
      }
      default: heff_nomatch(v_cands_2425);
      }
      return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Left, 1, (V[]){v_t_2430});
    }
    case TAG_Right: {
      V v_f_2431 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_2431, 2)), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str8))) {
        heff_drop_rec(v_at_240, 5);
        heff_drop(v_ws_241);
        heff_drop(v_body_242);
        heff_drop(v_i_2423);
        V v_t_2433 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str9), heff_get_n(v_f_2431, 0, 8));
        return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Left, 1, (V[]){heff_tag_n(TAG_SwitchValue, 1, (V[]){v_t_2433})});
      } else {
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        V v_t_2434 = heff_strSlice(heff_dup(v_body_242), heff_intAdd(v_i_2423, MK_INT(1LL)), heff_strLength(v_body_242));
        V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2431, 0, 8), v_t_2434});
        V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_take_field(v_at_240, 4)});
        V v_t_2437 = ({ V rv_4 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2437, v_ws_241));
      }
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_std_2ecli_2elongF_24s1119688962x564470218_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2elongF_24s1119688962x564470218(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str2, 1, "-");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str3, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str4, 0, "");
HEFF_LIT(g_std_2ecli_2eshortF_24s1014269042x1715098139_str5, 1, "-");
Clo g_std_2ecli_2eshortF_24s1014269042x1715098139_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortF_24s1014269042x1715098139_entry, 3, 0};

V g_std_2ecli_2eshortF_24s1014269042x1715098139(V v_at_240, V v_ws_241, V v_cl_242) {
top: ;
  if (heff_strEq_c_lent(v_cl_242, ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str0), 2)) {
    heff_drop(v_cl_242);
    return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_at_240, v_ws_241));
  } else {
    V v_x_244 = heff_strSlice_lent(v_cl_242, MK_INT(0LL), MK_INT(1LL), 6);
    V v_t_247;
    if (heff_strEq_c_lent(v_x_244, ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str1), 2)) {
      heff_drop(v_x_244);
      v_t_247 = NTAG(TAG_Nothing);
    } else {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_at_240, 0)), 0, 2);
      v_t_247 = ({ V a_0 = v_x_244; V a_1 = v_t_246; V r_ = (g_list_2efind_24s575827429x1292946038(a_0, a_1)); heff_drop(v_t_246); r_; });
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop_rec(v_at_240, 5);
      heff_drop(v_ws_241);
      V v_t_248 = heff_strAppend(((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str2), heff_strSlice(v_cl_242, MK_INT(0LL), MK_INT(1LL)));
      V v_t_249 = heff_tag_n(TAG_Unknown, 2, (V[]){v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_Left, 1, (V[]){v_t_249});
    }
    case TAG_Just: {
      V v_f_2410 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_2410, 2)), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str3))) {
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2410, 0, 8), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str4)});
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_take_field(v_at_240, 4)});
        V v_t_2414 = ({ V rv_4 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        V v_t_2415 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
        V t_0 = v_t_2414;
        V t_1 = v_ws_241;
        V t_2 = v_t_2415;
        v_at_240 = t_0;
        v_ws_241 = t_1;
        v_cl_242 = t_2;
        goto top;
      } else {
        if (heff_intLt_c(MK_INT(1LL), heff_strLength_lent(v_cl_242, 0))) {
          heff_drop_cell(v_ru_24t_247_24Just, 1);
          V v_t_2417 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
          V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2410, 0, 8), v_t_2417});
          V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_take_field(v_at_240, 4)});
          V v_t_2420 = ({ V rv_4 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
          return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2420, v_ws_241));
        } else {
          heff_drop(v_cl_242);
          switch (heff_tag_of(v_ws_241)) {
          case TAG_Nil: {
            heff_drop_rec(v_at_240, 5);
            V v_t_2421 = heff_strAppend(((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str5), heff_get_n(v_f_2410, 1, 8));
            return heff_tag_at_n(v_ru_24t_247_24Just, TAG_Left, 1, (V[]){heff_tag_n(TAG_NoValue, 1, (V[]){v_t_2421})});
          }
          case TAG_Cons: {
            V v_v_2422 = heff_field(v_ws_241, 0);
            V v_ws2_2423 = heff_field(v_ws_241, 1);
            V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
            heff_drop_cell(v_ru_24t_247_24Just, 1);
            V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2410, 0, 8), v_v_2422});
            V v_t_2425 = heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_dup(heff_rfield(v_at_240, 4))});
            V v_t_2426 = ({ V rv_4 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_at_240, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2426, v_ws2_2423));
          }
          default: return heff_nomatch(v_ws_241);
          }
        }
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_std_2ecli_2eshortF_24s1014269042x1715098139_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortF_24s1014269042x1715098139(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_str1, 6, "--help");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_str2, 2, "-h");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_str3, 2, "--");
Clo g_std_2ecli_2ewordsF_24s1352288509x2021617997_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry, 2, 0};

V g_std_2ecli_2ewordsF_24s1352288509x2021617997(V v_at_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_at_240, 3)));
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_at_240, 4, 5)));
    return heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_pos__flags, (V[]){v_t_242, v_t_243})});
  }
  case TAG_Cons: {
    V v_w_244 = heff_field(v_x3_241, 0);
    V v_ws_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_at_240, 2));
    V v_t_249 = heff_bool(((heff_dup(v_t_246) == NTAG(TAG_True)) ? (heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_at_240, 1))) && ({ V v_x_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_at_240, 3))); int c_ = heff_intLe_c(heff_dup(heff_rfield(v_at_240, 1)), heff_dup(v_x_248)); heff_drop(v_x_248); c_; })) : 1));
    heff_drop(v_t_246);
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_at_2410 = ({ V rv_2 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_at_240, 27ULL, 5, shape_sh__ra__on__ps__fs, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_w_244, heff_dup(heff_rfield(v_at_2410, 3))});
      V v_t_2412 = ({ V rv_3 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_at_2410, 23ULL, 5, shape_sh__ra__on__ps__fs, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V t_0 = v_t_2412;
      V t_1 = v_ws_245;
      v_at_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_249);
      if (heff_strEq_c_lent(v_w_244, ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str0), 2)) {
        heff_drop(v_w_244);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        V v_t_2414 = ({ V rv_2 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_at_240, 27ULL, 5, shape_sh__ra__on__ps__fs, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V t_0 = v_t_2414;
        V t_1 = v_ws_245;
        v_at_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      } else {
        V v_t_2416 = heff_bool((heff_strEq_c_lent(v_w_244, ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str1), 2) || heff_strEq_c_lent(v_w_244, ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str2), 2)));
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop_rec(v_at_240, 5);
          heff_drop(v_w_244);
          heff_drop(v_ws_245);
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          heff_drop(v_t_2416);
          return heff_tag_n(TAG_Left, 1, (V[]){NTAG(TAG_Help)});
        } else {
          heff_drop(v_t_2416);
          if (heff_strEq_c(heff_strSlice_lent(v_w_244, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str3))) {
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            V v_t_2418 = heff_strSlice(heff_dup(v_w_244), MK_INT(2LL), heff_strLength(v_w_244));
            return (g_std_2ecli_2elongF_24s1119688962x564470218(v_at_240, v_ws_245, v_t_2418));
          } else {
            if (heff_intLe_c(MK_INT(2LL), heff_strLength_lent(v_w_244, 0))) {
              if (heff_intEq_c(heff_strByteAt_lent(v_w_244, MK_INT(0LL), 2), MK_INT(45LL))) {
                heff_drop_cell(v_ru_24x3_241_24Cons, 2);
                V v_t_2421 = heff_strSlice(heff_dup(v_w_244), MK_INT(1LL), heff_strLength(v_w_244));
                return (g_std_2ecli_2eshortF_24s1014269042x1715098139(v_at_240, v_ws_245, v_t_2421));
              } else {
                V v_t_2422 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_w_244, heff_dup(heff_rfield(v_at_240, 3))});
                V v_t_2423 = ({ V rv_3 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_at_240, 23ULL, 5, shape_sh__ra__on__ps__fs, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                V t_0 = v_t_2423;
                V t_1 = v_ws_245;
                v_at_240 = t_0;
                v_x3_241 = t_1;
                goto top;
              }
            } else {
              V v_t_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_w_244, heff_dup(heff_rfield(v_at_240, 3))});
              V v_t_2425 = ({ V rv_3 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_at_240, 23ULL, 5, shape_sh__ra__on__ps__fs, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
              V t_0 = v_t_2425;
              V t_1 = v_ws_245;
              v_at_240 = t_0;
              v_x3_241 = t_1;
              goto top;
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ewordsF_24s1352288509x2021617997(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eflagProblem_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagProblem_str3, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagProblem_str4, 2, "--");
V g_std_2ecli_2eflagProblem_lam0(V self, V *args);
Clo g_std_2ecli_2eflagProblem_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagProblem_entry, 2, 0};

V g_std_2ecli_2eflagProblem(V v_fs_240, V v_f_241) {
top: ;
  V v_t_242 = (g_list_2efilter_24s1200694983x1257685262(heff_dup(heff_rfield(v_f_241, 0)), heff_dup(v_fs_240)));
  V v_x1_243 = (g_list_2emap_24s1173914895x100384474(v_t_242));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = heff_dup(heff_rfield(v_f_241, 6));
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_243, 0ULL, 2);
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_fs_240);
    heff_drop(v_t_246);
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_f_241, 2)), ((V)&g_std_2ecli_2eflagProblem_str0))) {
      v_t_248 = ((V)&g_std_2ecli_2eflagProblem_str1);
    } else {
      v_t_248 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str2), heff_dup(heff_rfield(v_f_241, 2)));
    }
    V v_t_249 = heff_strAppend(heff_get_n(v_f_241, 0, 8), v_t_248);
    V v_t_2410 = heff_tag_n(TAG_MissingFlag, 1, (V[]){heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str3), v_t_249)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_t_246);
    V v_t_2411 = (g_list_2efilter_24s1200694983x1257685262(heff_dup(heff_rfield(v_f_241, 0)), v_fs_240));
    V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_t_2411));
    V v_t_2419 = ({ V a_0 = heff_clo_n(g_std_2ecli_2eflagProblem_lam0, 1, 1, (V[]){heff_dup(v_f_241)}); V a_1 = v_t_2412; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_2412); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      heff_drop_rec(v_f_241, 8);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_2420 = heff_field(v_t_2419, 0);
      V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
      V v_t_2421 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str4), heff_take_field(v_f_241, 0));
      V v_t_2422 = heff_tag_n(TAG_NotIn, 3, (V[]){v_t_2421, v_v_2420, heff_get_n(v_f_241, 4, 8)});
      return heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){v_t_2422});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
}
V g_std_2ecli_2eflagProblem_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagProblem(a[0], a[1]);
}
V g_std_2ecli_2eflagProblem_lam0(V self, V *args) {
  V v_v_2413 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_dup(heff_rfield(v_f_241, 4));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nil: {
    heff_drop(v_v_2413);
    heff_drop_rec(v_f_241, 8);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2414, 0ULL, 2);
    V v_t_2417 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_v_2413}));
    V v_x1_2418 = ({ V a_0 = v_t_2417; V b_1 = heff_get_n(v_f_241, 4, 8); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
    heff_drop(v_x1_2418);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_t_2414);
  }
}
Clo g_std_2ecli_2efirstJust_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2efirstJust_entry, 2, 0};

V g_std_2ecli_2efirstJust(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_g_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V t_0 = v_g_240;
      V t_1 = v_xs_243;
      v_g_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_y_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_y_245});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2efirstJust_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2efirstJust(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2egroupsGo_str0, 3, "...");
Clo g_std_2ecli_2egroupsGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2egroupsGo_entry, 2, 0};

V g_std_2ecli_2egroupsGo(V v_x1_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_ws_241)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_w_242 = heff_field(v_ws_241, 0);
      heff_take_n(v_ws_241, 1ULL, 2);
      return heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Extra, 1, (V[]){v_w_242})});
    }
    default: return heff_nomatch(v_ws_241);
    }
  }
  case TAG_Cons: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_ps_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_m_246 = heff_take_field(v_x11_244, 0);
    V v_t_247 = heff_get_n(v_x11_244, 1, 3);
    switch (heff_tag_of(v_t_247)) {
    case TAG_One: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Missing, 1, (V[]){v_m_246})});
      }
      case TAG_Cons: {
        V v_w_248 = heff_field(v_ws_241, 0);
        V v_ws2_249 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        heff_drop(v_m_246);
        V v_x2_2410 = (g_std_2ecli_2egroupsGo(v_ps_245, v_ws2_249));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Left: {
          V v_p_2411 = heff_field(v_x2_2410, 0);
          V v_ru_24x2_2410_24Left = heff_take_reuse_n(v_x2_2410, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_w_248);
          heff_drop_cell(v_ru_24ws_241_24Cons, 2);
          return heff_tag_at_n(v_ru_24x2_2410_24Left, TAG_Left, 1, (V[]){v_p_2411});
        }
        case TAG_Right: {
          V v_gs_2412 = heff_field(v_x2_2410, 0);
          V v_ru_24x2_2410_24Right = heff_take_reuse_n(v_x2_2410, 1ULL, 1);
          V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_248, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_2410_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_gs_2412})});
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      default: return heff_nomatch(v_ws_241);
      }
    }
    case TAG_Optional: {
      heff_drop(v_m_246);
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        V v_x2_2414 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_Left: {
          V v_p_2415 = heff_field(v_x2_2414, 0);
          V v_ru_24x2_2414_24Left = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          return heff_tag_at_n(v_ru_24x2_2414_24Left, TAG_Left, 1, (V[]){v_p_2415});
        }
        case TAG_Right: {
          V v_gs_2416 = heff_field(v_x2_2414, 0);
          V v_ru_24x2_2414_24Right = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
          V v_t_2417 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_gs_2416});
          return heff_tag_at_n(v_ru_24x2_2414_24Right, TAG_Right, 1, (V[]){v_t_2417});
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      case TAG_Cons: {
        V v_w_2418 = heff_field(v_ws_241, 0);
        V v_ws2_2419 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        V v_x2_2420 = (g_std_2ecli_2egroupsGo(v_ps_245, v_ws2_2419));
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Left: {
          V v_p_2421 = heff_field(v_x2_2420, 0);
          V v_ru_24x2_2420_24Left = heff_take_reuse_n(v_x2_2420, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_w_2418);
          heff_drop_cell(v_ru_24ws_241_24Cons, 2);
          return heff_tag_at_n(v_ru_24x2_2420_24Left, TAG_Left, 1, (V[]){v_p_2421});
        }
        case TAG_Right: {
          V v_gs_2422 = heff_field(v_x2_2420, 0);
          V v_ru_24x2_2420_24Right = heff_take_reuse_n(v_x2_2420, 1ULL, 1);
          V v_t_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_2418, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_2420_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_gs_2422})});
        }
        default: return heff_nomatch(v_x2_2420);
        }
      }
      default: return heff_nomatch(v_ws_241);
      }
    }
    case TAG_Many: {
      heff_drop(v_m_246);
      V v_x2_2424 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_Left: {
        V v_p_2425 = heff_field(v_x2_2424, 0);
        V v_ru_24x2_2424_24Left = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
        heff_drop(v_ws_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_tag_at_n(v_ru_24x2_2424_24Left, TAG_Left, 1, (V[]){v_p_2425});
      }
      case TAG_Right: {
        V v_gs_2426 = heff_field(v_x2_2424, 0);
        V v_ru_24x2_2424_24Right = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x2_2424_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2426})});
      }
      default: return heff_nomatch(v_x2_2424);
      }
    }
    case TAG_Some: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_t_2427 = heff_tag_n(TAG_Missing, 1, (V[]){heff_strAppend(v_m_246, ((V)&g_std_2ecli_2egroupsGo_str0))});
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2427});
      }
      case TAG_Cons: {
        heff_drop(v_m_246);
        V v_x2_2430 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x2_2430)) {
        case TAG_Left: {
          V v_p_2431 = heff_field(v_x2_2430, 0);
          V v_ru_24x2_2430_24Left = heff_take_reuse_n(v_x2_2430, 1ULL, 1);
          heff_drop_tag(v_ws_241, 2);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          return heff_tag_at_n(v_ru_24x2_2430_24Left, TAG_Left, 1, (V[]){v_p_2431});
        }
        case TAG_Right: {
          V v_gs_2432 = heff_field(v_x2_2430, 0);
          V v_ru_24x2_2430_24Right = heff_take_reuse_n(v_x2_2430, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x2_2430_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2432})});
        }
        default: return heff_nomatch(v_x2_2430);
        }
      }
      default: return heff_nomatch(v_ws_241);
      }
    }
    case TAG_Rest: {
      heff_drop(v_m_246);
      V v_x2_2433 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Left: {
        V v_p_2434 = heff_field(v_x2_2433, 0);
        V v_ru_24x2_2433_24Left = heff_take_reuse_n(v_x2_2433, 1ULL, 1);
        heff_drop(v_ws_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24Left, TAG_Left, 1, (V[]){v_p_2434});
      }
      case TAG_Right: {
        V v_gs_2435 = heff_field(v_x2_2433, 0);
        V v_ru_24x2_2433_24Right = heff_take_reuse_n(v_x2_2433, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x2_2433_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2435})});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2egroupsGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2egroupsGo(a[0], a[1]);
}
V g_std_2ecli_2eparse_lam0(V self, V *args);
Clo g_std_2ecli_2eparse_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eparse_entry, 2, 0};

V g_std_2ecli_2eparse(V v_t_240, V v_ws_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_t_243 = (g_std_2ecli_2eshapeProblem(heff_get_n(v_t_242, 0, 2)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_245 = heff_get_n(v_t_244, 0, 2);
    V v_t_246 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_245, 1), MK_INT(0LL)));
    V v_at_247 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){v_sh_245, v_t_246, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_at_247, v_ws_241));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Left = heff_take_reuse_n(v_t_248, 1ULL, 1);
      heff_drop(v_t_240);
      return heff_tag_at_n(v_ru_24t_248_24Left, TAG_Left, 1, (V[]){v_p_249});
    }
    case TAG_Right: {
      V v_sp_2410 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Right = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2411 = heff_tr(heff_call(((V)&g_std_2ecli_2eflagProblem_clo), 1, (V[]){heff_dup(heff_rfield(v_sp_2410, 1))}));
      V v_t_2412 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
      V v_t_2413 = heff_get_n(heff_get_n(v_t_2412, 0, 2), 0, 2);
      V v_t_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_std_2ecli_2efirstJust(a_0, a_1)); heff_drop(v_t_2413); r_; });
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        V v_t_2415 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
        V v_t_2416 = heff_get_n(heff_get_n(v_t_2415, 0, 2), 1, 2);
        V v_t_2417 = (g_std_2ecli_2egroupsGo(v_t_2416, heff_dup(heff_rfield(v_sp_2410, 0))));
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Left: {
          V v_p_2418 = heff_field(v_t_2417, 0);
          V v_ru_24t_2417_24Left = heff_take_reuse_n(v_t_2417, 1ULL, 1);
          heff_drop(v_t_240);
          heff_drop_rec(v_sp_2410, 2);
          heff_drop_cell(v_ru_24t_248_24Right, 1);
          return heff_tag_at_n(v_ru_24t_2417_24Left, TAG_Left, 1, (V[]){v_p_2418});
        }
        case TAG_Right: {
          V v_gs_2419 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          V v_t_2420 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2421 = heff_tr(heff_call(v_t_240, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2422 = heff_get_n(heff_get_n(v_t_2421, 0, 2), 0, 2);
          V v_t_2426 = (g_list_2emap(heff_clo_n(g_std_2ecli_2eparse_lam0, 1, 1, (V[]){v_sp_2410}), v_t_2422));
          V v_t_2427 = heff_tr(heff_call(heff_get_n(v_t_2420, 1, 2), 2, (V[]){v_gs_2419, v_t_2426}));
          return heff_tag_at_n(v_ru_24t_248_24Right, TAG_Right, 1, (V[]){v_t_2427});
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      case TAG_Just: {
        V v_p_2428 = heff_field(v_t_2414, 0);
        V v_ru_24t_2414_24Just = heff_take_reuse_n(v_t_2414, 1ULL, 1);
        heff_drop(v_t_240);
        heff_drop_rec(v_sp_2410, 2);
        heff_drop_cell(v_ru_24t_248_24Right, 1);
        return heff_tag_at_n(v_ru_24t_2414_24Just, TAG_Left, 1, (V[]){v_p_2428});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_Just: {
    V v_why_2429 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_t_240);
    heff_drop(v_ws_241);
    return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){heff_tag_n(TAG_BadShape, 1, (V[]){v_why_2429})});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2eparse_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eparse(a[0], a[1]);
}
V g_std_2ecli_2eparse_lam0(V self, V *args) {
  V v_f_2423 = args[0];
  V v_sp_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = (g_list_2efilter_24s1200694983x1257685262(heff_dup(heff_rfield(v_f_2423, 0)), heff_get_n(v_sp_2410, 1, 2)));
  V v_t_2425 = (g_list_2emap_24s1173914895x100384474(v_t_2424));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2423, 0, 8), v_t_2425});
}
HEFF_LIT(g_std_2ecli_2eshortWhere_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eshortWhere_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eshortWhere_str2, 0, "");
Clo g_std_2ecli_2eshortWhere_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortWhere_entry, 3, 0};

V g_std_2ecli_2eshortWhere(V v_sh_240, V v_st_241, V v_cl_242) {
top: ;
  if (heff_strEq_c_lent(v_cl_242, ((V)&g_std_2ecli_2eshortWhere_str0), 2)) {
    heff_drop_rec(v_sh_240, 2);
    heff_drop(v_cl_242);
    return v_st_241;
  } else {
    V v_x_244 = heff_strSlice_lent(v_cl_242, MK_INT(0LL), MK_INT(1LL), 6);
    V v_t_246;
    if (heff_strEq_c_lent(v_x_244, ((V)&g_std_2ecli_2eshortWhere_str1), 2)) {
      heff_drop(v_x_244);
      v_t_246 = NTAG(TAG_Nothing);
    } else {
      v_t_246 = (g_list_2efind_24s575827429x1292946038(v_x_244, heff_rfield(v_sh_240, 0)));
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop_rec(v_sh_240, 2);
      heff_drop(v_cl_242);
      return v_st_241;
    }
    case TAG_Just: {
      V v_f_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_f_247, 2)), ((V)&g_std_2ecli_2eshortWhere_str2))) {
        heff_drop_cell(v_ru_24t_246_24Just, 1);
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_f_247, 0, 8), heff_take_field(v_st_241, 3)});
        V v_t_2410 = ({ V rv_1 = NTAG(TAG_Nothing); V rv_3 = v_t_249; V rr_ = heff_rec_reuse_nf(v_st_241, 5ULL, 4, shape_on__waiting__count__given, 51u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_t_2411 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
        V t_0 = v_sh_240;
        V t_1 = v_t_2410;
        V t_2 = v_t_2411;
        v_sh_240 = t_0;
        v_st_241 = t_1;
        v_cl_242 = t_2;
        goto top;
      } else {
        heff_drop_rec(v_sh_240, 2);
        V v_t_2413;
        if (heff_intLt_c(MK_INT(1LL), heff_strLength(v_cl_242))) {
          heff_drop_cell(v_ru_24t_246_24Just, 1);
          v_t_2413 = NTAG(TAG_Nothing);
        } else {
          v_t_2413 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){heff_dup(v_f_247)});
        }
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_f_247, 0, 8), heff_take_field(v_st_241, 3)});
        return ({ V rv_1 = v_t_2413; V rv_3 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_st_241, 5ULL, 4, shape_on__waiting__count__given, 51u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_std_2ecli_2eshortWhere_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortWhere(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2ecli_2ewhereGo_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ewhereGo_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2ewhereGo_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2ewhereGo_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ewhereGo_str4, 0, "");
Clo g_std_2ecli_2ewhereGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ewhereGo_entry, 4, 0};

V g_std_2ecli_2ewhereGo(V v_sh_240, V v_ra_241, V v_st_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sh_240);
    heff_drop(v_ra_241);
    return v_st_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_ws_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_st_242, 1));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_dup(heff_rfield(v_st_242, 0));
      V v_t_249 = heff_bool(((heff_dup(v_t_247) == NTAG(TAG_True)) ? (heff_intLe_c(MK_INT(0LL), heff_dup(v_ra_241)) && heff_intLe_c(heff_dup(v_ra_241), heff_dup(heff_rfield(v_st_242, 2)))) : 1));
      heff_drop(v_t_247);
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_x41_244);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_t_249);
        V v_t_2410 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
        V v_t_2411 = ({ V rv_0 = NTAG(TAG_False); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        V t_0 = v_sh_240;
        V t_1 = v_ra_241;
        V t_2 = v_t_2411;
        V t_3 = v_ws_245;
        v_sh_240 = t_0;
        v_ra_241 = t_1;
        v_st_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_249);
        if (heff_strEq_c_lent(v_x41_244, ((V)&g_std_2ecli_2ewhereGo_str0), 2)) {
          heff_drop(v_x41_244);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          V v_t_2413 = ({ V rv_0 = NTAG(TAG_False); V rv_1 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_242, 12ULL, 4, shape_on__waiting__count__given, 240u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          V t_0 = v_sh_240;
          V t_1 = v_ra_241;
          V t_2 = v_t_2413;
          V t_3 = v_ws_245;
          v_sh_240 = t_0;
          v_ra_241 = t_1;
          v_st_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        } else {
          if (heff_strEq_c(heff_strSlice_lent(v_x41_244, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ewhereGo_str1))) {
            V v_t_2415 = heff_strSlice(heff_dup(v_x41_244), MK_INT(2LL), heff_strLength_lent(v_x41_244, 0));
            V v_t_2416 = (g_std_2ecli_2elongNamed(heff_dup(v_sh_240), v_t_2415));
            V v_t_2419;
            switch (heff_tag_of(v_t_2416)) {
            case TAG_Left: {
              heff_take_n(v_t_2416, 0ULL, 1);
              v_t_2419 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Right: {
              V v_f_2418 = heff_field(v_t_2416, 0);
              V v_ru_24t_2416_24Right = heff_take_reuse_n(v_t_2416, 1ULL, 1);
              v_t_2419 = heff_tag_at_n(v_ru_24t_2416_24Right, TAG_Just, 1, (V[]){v_f_2418});
              break;
            }
            default: heff_nomatch(v_t_2416);
            }
            switch (heff_tag_of(v_t_2419)) {
            case TAG_Nothing: {
              V v_j_2420 = (g_prelude_2estrFind(((V)&g_std_2ecli_2ewhereGo_str2), heff_dup(v_x41_244), MK_INT(0LL)));
              if (heff_intLt_c(heff_dup(v_j_2420), MK_INT(0LL))) {
                heff_drop(v_x41_244);
                heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                heff_drop(v_j_2420);
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_st_242;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              } else {
                V v_t_2422 = (g_std_2ecli_2elongNamed(heff_dup(v_sh_240), heff_strSlice(v_x41_244, MK_INT(2LL), v_j_2420)));
                V v_t_2425;
                switch (heff_tag_of(v_t_2422)) {
                case TAG_Left: {
                  heff_take_n(v_t_2422, 0ULL, 1);
                  v_t_2425 = ((V)&g_std_2ecli_2ewhereGo_str3);
                  break;
                }
                case TAG_Right: {
                  V v_f_2424 = heff_field(v_t_2422, 0);
                  heff_take_n(v_t_2422, 1ULL, 1);
                  v_t_2425 = heff_get_n(v_f_2424, 0, 8);
                  break;
                }
                default: heff_nomatch(v_t_2422);
                }
                V v_t_2426 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_dup(heff_rfield(v_st_242, 3))});
                V v_t_2427 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_st_242, 4ULL, 4, shape_on__waiting__count__given, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2427;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
            }
            case TAG_Just: {
              V v_f_2428 = heff_field(v_t_2419, 0);
              V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
              heff_drop(v_x41_244);
              V v_t_2430;
              if (heff_strEq_c(heff_dup(heff_rfield(v_f_2428, 2)), ((V)&g_std_2ecli_2ewhereGo_str4))) {
                heff_drop_cell(v_ru_24t_2419_24Just, 1);
                v_t_2430 = NTAG(TAG_Nothing);
              } else {
                v_t_2430 = heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){heff_dup(v_f_2428)});
              }
              V v_t_2431 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_f_2428, 0, 8), heff_dup(heff_rfield(v_st_242, 3))});
              V v_t_2432 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = v_t_2430; V rv_3 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_st_242, 4ULL, 4, shape_on__waiting__count__given, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2432;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x4_243 = t_3;
              goto top;
            }
            default: return heff_nomatch(v_t_2419);
            }
          } else {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            if (heff_intLe_c(MK_INT(2LL), heff_strLength_lent(v_x41_244, 0))) {
              if (heff_intEq_c(heff_strByteAt_lent(v_x41_244, MK_INT(0LL), 2), MK_INT(45LL))) {
                V v_t_2435 = heff_strSlice(heff_dup(v_x41_244), MK_INT(1LL), heff_strLength(v_x41_244));
                V v_t_2436 = (g_std_2ecli_2eshortWhere(heff_dup(v_sh_240), v_st_242, v_t_2435));
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2436;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              } else {
                heff_drop(v_x41_244);
                V v_t_2437 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
                V v_t_2438 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2438;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
            } else {
              heff_drop(v_x41_244);
              V v_t_2439 = heff_intAdd(heff_take_field(v_st_242, 2), MK_INT(1LL));
              V v_t_2440 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = NTAG(TAG_Nothing); V rv_2 = v_t_2439; V rr_ = heff_rec_reuse_nf(v_st_242, 8ULL, 4, shape_on__waiting__count__given, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2440;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x4_243 = t_3;
              goto top;
            }
          }
        }
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_x41_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2442 = ({ V rv_1 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_242, 13ULL, 4, shape_on__waiting__count__given, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V t_0 = v_sh_240;
      V t_1 = v_ra_241;
      V t_2 = v_t_2442;
      V t_3 = v_ws_245;
      v_sh_240 = t_0;
      v_ra_241 = t_1;
      v_st_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2ewhereGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ewhereGo(a[0], a[1], a[2], a[3]);
}
Clo g_std_2ecli_2eposAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eposAt_entry, 2, 0};

V g_std_2ecli_2eposAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_dup(heff_rfield(v_p_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Optional: {
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Many: {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_Some: {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_Rest: {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eposAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eposAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2ecompleteAt_str0, 1, "-");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str1, 1, "=");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2ecompleteAt_str3, 6, "--help");
V g_std_2ecli_2ecompleteAt_lam0(V self, V *args);
Clo g_std_2ecli_2ecompleteAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteAt_entry, 3, 0};

V g_std_2ecli_2ecompleteAt(V v_sh_240, V v_st_241, V v_cur_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_241, 1));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_dup(heff_rfield(v_st_241, 0));
    V v_t_249 = heff_bool(((heff_dup(v_t_244) == NTAG(TAG_True)) && ({ V v_x_245 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL))); int c_ = ({ V v_x1_248 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(v_x_245)) && ({ V v_y_247 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL))); int c_ = heff_intLe_c(heff_dup(v_y_247), heff_dup(heff_rfield(v_st_241, 2))); heff_drop(v_y_247); c_; }))); int c_ = ((heff_dup(v_x1_248) == NTAG(TAG_True)) ? 0 : heff_strEq_c(heff_strSlice_lent(v_cur_242, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2ecli_2ecompleteAt_str0))); heff_drop(v_x1_248); c_; }); heff_drop(v_x_245); c_; })));
    heff_drop(v_t_244);
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_j_2410 = (g_prelude_2estrFind(((V)&g_std_2ecli_2ecompleteAt_str1), heff_dup(v_cur_242), MK_INT(0LL)));
      V v_t_2412;
      if (heff_intLt_c(heff_dup(v_j_2410), MK_INT(0LL))) {
        heff_drop(v_j_2410);
        v_t_2412 = NTAG(TAG_Nothing);
      } else {
        v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2410});
      }
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        V v_t_2417 = (g_list_2emap_24f134831722x1788320834(((V)&g_std_2ecli_2ecompleteAt_str2), heff_clo_n(g_std_2ecli_2ecompleteAt_lam0, 1, 1, (V[]){v_st_241}), heff_get_n(v_sh_240, 0, 2)));
        V v_t_2418 = (g_list_2efilter_24s2009824277x1398398543(MK_INT(0LL), v_cur_242, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ecompleteAt_str3), v_t_2417})));
        return heff_tag_n(TAG_Words, 1, (V[]){v_t_2418});
      }
      case TAG_Just: {
        V v_i_2419 = heff_field(v_t_2412, 0);
        V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 1ULL, 1);
        heff_drop_rec(v_st_241, 4);
        V v_t_2420 = (g_std_2ecli_2elongNamed(v_sh_240, heff_strSlice_lent(v_cur_242, MK_INT(2LL), v_i_2419, 2)));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Left: {
          heff_take_n(v_t_2420, 0ULL, 1);
          heff_drop(v_cur_242);
          heff_drop(v_i_2419);
          heff_drop_cell(v_ru_24t_2412_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Right: {
          V v_f_2422 = heff_field(v_t_2420, 0);
          heff_take_n(v_t_2420, 1ULL, 1);
          V v_t_2423 = (g_list_2efilter_24f1490579794x1456232270(MK_INT(0LL), heff_dup(v_cur_242), v_cur_242, MK_INT(0LL), v_i_2419, MK_INT(1LL), heff_get_n(v_f_2422, 4, 8)));
          return heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Words, 1, (V[]){v_t_2423});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_t_2412);
      }
    } else {
      heff_drop(v_t_249);
      V v_t_2424 = ({ V b_0 = heff_get_n(v_sh_240, 1, 2); V a_1 = heff_get_n(v_st_241, 2, 4); V r_ = (g_std_2ecli_2eposAt(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_2424)) {
      case TAG_Nothing: {
        heff_drop(v_cur_242);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_p_2425 = heff_field(v_t_2424, 0);
        V v_ru_24t_2424_24Just = heff_take_reuse_n(v_t_2424, 1ULL, 1);
        V v_t_2426 = heff_get_n(v_p_2425, 2, 3);
        switch (heff_tag_of(v_t_2426)) {
        case TAG_None: {
          heff_drop(v_cur_242);
          heff_drop_cell(v_ru_24t_2424_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Files: {
          V v_sfx_2427 = heff_field(v_t_2426, 0);
          heff_take_n(v_t_2426, 1ULL, 1);
          heff_drop(v_cur_242);
          return heff_tag_at_n(v_ru_24t_2424_24Just, TAG_FilesBy, 1, (V[]){v_sfx_2427});
        }
        case TAG_Dirs: {
          heff_drop(v_cur_242);
          heff_drop_cell(v_ru_24t_2424_24Just, 1);
          return NTAG(TAG_DirsOnly);
        }
        case TAG_Among: {
          V v_ws_2428 = heff_field(v_t_2426, 0);
          heff_take_n(v_t_2426, 1ULL, 1);
          V v_t_2429 = (g_list_2efilter_24s2009824277x1398398543(MK_INT(0LL), v_cur_242, v_ws_2428));
          return heff_tag_at_n(v_ru_24t_2424_24Just, TAG_Words, 1, (V[]){v_t_2429});
        }
        default: return heff_nomatch(v_t_2426);
        }
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
  }
  case TAG_Just: {
    V v_f_2430 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_sh_240, 2);
    heff_drop_rec(v_st_241, 4);
    V v_t_2431 = heff_dup(heff_rfield(v_f_2430, 4));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nil: {
      V v_t_2432 = heff_get_n(v_f_2430, 7, 8);
      switch (heff_tag_of(v_t_2432)) {
      case TAG_None: {
        heff_drop(v_cur_242);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Files: {
        V v_sfx_2433 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        heff_drop(v_cur_242);
        return heff_tag_at_n(v_ru_24t_243_24Just, TAG_FilesBy, 1, (V[]){v_sfx_2433});
      }
      case TAG_Dirs: {
        heff_drop(v_cur_242);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_DirsOnly);
      }
      case TAG_Among: {
        V v_ws_2434 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        V v_t_2435 = (g_list_2efilter_24s2009824277x1398398543(MK_INT(0LL), v_cur_242, v_ws_2434));
        return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Words, 1, (V[]){v_t_2435});
      }
      default: return heff_nomatch(v_t_2432);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_2431, 0ULL, 2);
      V v_t_2438 = (g_list_2efilter_24s2009824277x1398398543(MK_INT(0LL), v_cur_242, heff_get_n(v_f_2430, 4, 8)));
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Words, 1, (V[]){v_t_2438});
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2ecompleteAt_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecompleteAt(a[0], a[1], a[2]);
}
V g_std_2ecli_2ecompleteAt_lam0(V self, V *args) {
  V v_f_2413 = args[0];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_take_field(v_f_2413, 5);
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2414) == NTAG(TAG_True)) || ({ V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_f_2413, 0))})); int c_ = ({ V v_x1_2416 = (g_list_2eany(heff_dup(v_t_2415), heff_rfield(v_st_241, 3))); int c_ = !(heff_dup(v_x1_2416) == NTAG(TAG_True)); heff_drop(v_x1_2416); c_; }); heff_drop(v_t_2415); c_; })));
  heff_drop_rec(v_f_2413, 8);
  heff_drop_rec(v_st_241, 4);
  heff_drop(v_t_2414);
  return v_ret_24bool;
}
HEFF_LIT(g_std_2ecli_2eflagWord_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagWord_str1, 1, "]");
HEFF_LIT(g_std_2ecli_2eflagWord_str2, 3, "[--");
HEFF_LIT(g_std_2ecli_2eflagWord_str3, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagWord_str4, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagWord_str5, 1, "]");
HEFF_LIT(g_std_2ecli_2eflagWord_str6, 1, " ");
HEFF_LIT(g_std_2ecli_2eflagWord_str7, 3, "[--");
Clo g_std_2ecli_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagWord_entry, 1, 0};

V g_std_2ecli_2eflagWord(V v_f_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2eflagWord_str0))) {
    V v_t_242 = heff_strAppend(heff_get_n(v_f_240, 0, 8), ((V)&g_std_2ecli_2eflagWord_str1));
    return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str2), v_t_242);
  } else {
    V v_t_243 = heff_take_field(v_f_240, 6);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2eflagWord_str3), heff_take_field(v_f_240, 2));
      V v_t_245 = heff_strAppend(heff_get_n(v_f_240, 0, 8), v_t_244);
      return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str4), v_t_245);
    } else {
      heff_drop(v_t_243);
      V v_t_246 = heff_strAppend(heff_take_field(v_f_240, 2), ((V)&g_std_2ecli_2eflagWord_str5));
      V v_t_247 = heff_strAppend(heff_get_n(v_f_240, 0, 8), heff_strAppend(((V)&g_std_2ecli_2eflagWord_str6), v_t_246));
      return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str7), v_t_247);
    }
  }
}
V g_std_2ecli_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagWord(a[0]);
}
HEFF_LIT(g_std_2ecli_2eheadOf_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str3, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str5, 1, " ");
Clo g_std_2ecli_2eheadOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eheadOf_entry, 1, 0};

V g_std_2ecli_2eheadOf(V v_k_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_sh_242 = heff_get_n(v_t_241, 0, 2);
  V v_t_243 = (g_list_2emap_24s2029999044x514618413(heff_take_field(v_sh_242, 1)));
  V v_t_244 = (g_list_2emap_24s1281445768x1036802655(heff_get_n(v_sh_242, 0, 2)));
  V v_xs_245 = (g_prelude_2e_2b_2b(v_t_243, v_t_244));
  V v_t_248;
  switch (heff_tag_of(v_xs_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_std_2ecli_2eheadOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_245, 0);
    V v_xs_247 = heff_field(v_xs_245, 1);
    heff_take_n(v_xs_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_xs_245);
  }
  if (heff_strEq_c(v_t_248, ((V)&g_std_2ecli_2eheadOf_str2))) {
    return heff_get_n(v_k_240, 0, 4);
  } else {
    V v_t_2410 = heff_tr(heff_call(heff_take_field(v_k_240, 3), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_2411 = heff_get_n(v_t_2410, 0, 2);
    V v_t_2412 = (g_list_2emap_24s2029999044x514618413(heff_take_field(v_sh_2411, 1)));
    V v_t_2413 = (g_list_2emap_24s1281445768x1036802655(heff_get_n(v_sh_2411, 0, 2)));
    V v_xs_2414 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
    V v_t_2417;
    switch (heff_tag_of(v_xs_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_std_2ecli_2eheadOf_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_xs_2414, 0);
      V v_xs_2416 = heff_field(v_xs_2414, 1);
      heff_take_n(v_xs_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str4); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_xs_2414);
    }
    return heff_strAppend(heff_get_n(v_k_240, 0, 4), heff_strAppend(((V)&g_std_2ecli_2eheadOf_str5), v_t_2417));
  }
}
V g_std_2ecli_2eheadOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eheadOf(a[0]);
}
HEFF_LIT(g_std_2ecli_2eline2_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eline2_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str3, 1, "\012");
HEFF_LIT(g_std_2ecli_2eline2_str4, 2, "  ");
HEFF_LIT(g_std_2ecli_2eline2_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2eline2_str6, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str8, 2, "  ");
Clo g_std_2ecli_2eline2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eline2_entry, 2, 0};

V g_std_2ecli_2eline2(V v_x_240, V v_doc_241) {
top: ;
  if (heff_intLt_c(MK_INT(26LL), heff_strLength_lent(v_x_240, 0))) {
    V v_x2_243 = (g_list_2ereplicate(MK_INT(30LL), ((V)&g_std_2ecli_2eline2_str0)));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_std_2ecli_2eline2_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_strAppend(((V)&g_std_2ecli_2eline2_str3), heff_strAppend(v_t_246, v_doc_241));
    return heff_strAppend(((V)&g_std_2ecli_2eline2_str4), heff_strAppend(v_x_240, v_t_247));
  } else {
    V v_t_248 = heff_intSub(MK_INT(28LL), heff_strLength_lent(v_x_240, 0));
    V v_x2_249 = (g_list_2ereplicate(v_t_248, ((V)&g_std_2ecli_2eline2_str5)));
    V v_t_2412;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_std_2ecli_2eline2_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_xs_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str7); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    V v_t_2413 = heff_strAppend(v_x_240, heff_strAppend(v_t_2412, v_doc_241));
    return heff_strAppend(((V)&g_std_2ecli_2eline2_str8), v_t_2413);
  }
}
V g_std_2ecli_2eline2_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eline2(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eusage_str0, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2eusage_str1, 12, " COMMAND ...");
HEFF_LIT(g_std_2ecli_2eusage_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eusage_str3, 14, "help [COMMAND]");
HEFF_LIT(g_std_2ecli_2eusage_str4, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2eusage_str5, 17, "completions SHELL");
HEFF_LIT(g_std_2ecli_2eusage_str6, 48, "a completion script for SHELL: fish, bash or zsh");
HEFF_LIT(g_std_2ecli_2eusage_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eusage_str8, 1, "\012");
HEFF_LIT(g_std_2ecli_2eusage_str9, 1, "\012");
Clo g_std_2ecli_2eusage_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eusage_entry, 2, 0};

V g_std_2ecli_2eusage(V v_prog_240, V v_cs_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2eusage_str0), heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2eusage_str1)));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eusage_str2), NTAG(TAG_Nil)});
  V v_t_244 = (g_list_2efilter_24s1623010005x1805617852(v_cs_241));
  V v_t_245 = (g_list_2emap_24s296585291x885335139(v_t_244));
  V v_t_246 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str3), ((V)&g_std_2ecli_2eusage_str4)));
  V v_t_247 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str5), ((V)&g_std_2ecli_2eusage_str6)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})));
  V v_x2_2410 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_243}), v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_std_2ecli_2eusage_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_std_2ecli_2eusage_str8); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strAppend(v_t_2413, ((V)&g_std_2ecli_2eusage_str9));
}
V g_std_2ecli_2eusage_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eusage(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eflagLine_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str1, 4, "    ");
HEFF_LIT(g_std_2ecli_2eflagLine_str2, 2, ", ");
HEFF_LIT(g_std_2ecli_2eflagLine_str3, 1, "-");
HEFF_LIT(g_std_2ecli_2eflagLine_str4, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str5, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str6, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagLine_str7, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagLine_str8, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str9, 0, "");
HEFF_LIT(g_std_2ecli_2eflagLine_str10, 2, ", ");
HEFF_LIT(g_std_2ecli_2eflagLine_str11, 2, " (");
HEFF_LIT(g_std_2ecli_2eflagLine_str12, 1, ")");
Clo g_std_2ecli_2eflagLine_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagLine_entry, 1, 0};

V g_std_2ecli_2eflagLine(V v_f_240) {
top: ;
  V v_t_243;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 1)), ((V)&g_std_2ecli_2eflagLine_str0))) {
    v_t_243 = ((V)&g_std_2ecli_2eflagLine_str1);
  } else {
    V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_f_240, 1)), ((V)&g_std_2ecli_2eflagLine_str2));
    v_t_243 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str3), v_t_242);
  }
  V v_t_245;
  if (heff_strEq_c(heff_dup(heff_rfield(v_f_240, 2)), ((V)&g_std_2ecli_2eflagLine_str4))) {
    v_t_245 = ((V)&g_std_2ecli_2eflagLine_str5);
  } else {
    v_t_245 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str6), heff_dup(heff_rfield(v_f_240, 2)));
  }
  V v_t_246 = heff_strAppend(heff_take_field(v_f_240, 0), v_t_245);
  V v_t_247 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_std_2ecli_2eflagLine_str7), v_t_246));
  V v_t_248 = heff_dup(heff_rfield(v_f_240, 4));
  V v_t_2415;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_std_2ecli_2eflagLine_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_248, 0ULL, 2);
    V v_t_2411 = heff_dup(heff_rfield(v_f_240, 4));
    V v_t_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_std_2ecli_2eflagLine_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_t_2411, 0);
      V v_xs_2413 = heff_field(v_t_2411, 1);
      heff_take_n(v_t_2411, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_std_2ecli_2eflagLine_str10); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    v_t_2415 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str11), heff_strAppend(v_t_2414, ((V)&g_std_2ecli_2eflagLine_str12)));
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_t_2416 = heff_strAppend(heff_get_n(v_f_240, 3, 8), v_t_2415);
  return (g_std_2ecli_2eline2(v_t_247, v_t_2416));
}
V g_std_2ecli_2eflagLine_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagLine(a[0]);
}
HEFF_LIT(g_std_2ecli_2ehelpOf_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2ehelpOf_str1, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2ehelpOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str4, 6, "flags:");
HEFF_LIT(g_std_2ecli_2ehelpOf_str5, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2ehelpOf_str7, 1, "\012");
Clo g_std_2ecli_2ehelpOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ehelpOf_entry, 2, 0};

V g_std_2ecli_2ehelpOf(V v_prog_240, V v_k_241) {
top: ;
  V v_t_242 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
  V v_t_243 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str0), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_k_241, 1), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str1), v_t_243), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str2), v_t_244})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_x1_247 = heff_get_n(heff_get_n(v_t_246, 0, 2), 0, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_241, 4);
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ru_24x1_247_24Cons = heff_take_reuse_n(v_x1_247, 0ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_k_241, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_2411 = heff_get_n(heff_get_n(v_t_2410, 0, 2), 0, 2);
    V v_t_2412 = (g_list_2emap_24s1753874608x910016727(v_t_2411));
    v_t_2413 = heff_tag_at_n(v_ru_24x1_247_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str4), v_t_2412})});
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_x2_2414 = (g_prelude_2e_2b_2b(v_t_245, v_t_2413));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_std_2ecli_2ehelpOf_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2ehelpOf_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  return heff_strAppend(v_t_2417, ((V)&g_std_2ecli_2ehelpOf_str7));
}
V g_std_2ecli_2ehelpOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ehelpOf(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eorList_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_str2, 2, ", ");
Clo g_std_2ecli_2eorList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_entry, 1, 0};

V g_std_2ecli_2eorList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2eorList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_std_2ecli_2eorList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_std_2ecli_2eorList_str2));
        return (g_std_2ecli_2eorList_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eorList_24acc_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_24acc_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_24acc_str2, 2, ", ");
Clo g_std_2ecli_2eorList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_24acc_entry, 2, 0};

V g_std_2ecli_2eorList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_std_2ecli_2eorList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_strAppend(heff_dup(v_x_242), heff_strAppend(((V)&g_std_2ecli_2eorList_24acc_str1), heff_dup(v_y_244)));
        return heff_strAppend(v_acc_241, v_t_246);
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(v_acc_241, heff_dup(v_x_242));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_std_2ecli_2eorList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eproblemSaid_str0, 8, "no flag ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str1, 4, "; --");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str2, 1, "\?");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str3, 8, "no flag ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str4, 14, " takes a value");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str5, 15, " takes no value");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str6, 2, "--");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str7, 17, " is the start of ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str8, 10, " is wanted");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str9, 6, ", not ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str10, 4, " is ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str11, 9, "expected ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str12, 16, "too many words: ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str13, 4, "help");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str14, 34, "the command is described wrongly: ");
Clo g_std_2ecli_2eproblemSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eproblemSaid_entry, 1, 0};

V g_std_2ecli_2eproblemSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Unknown: {
    V v_w_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nothing: {
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str0), heff_dup(v_w_241));
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x12_242, 0);
      V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str1), heff_strAppend(heff_dup(v_s_243), ((V)&g_std_2ecli_2eproblemSaid_str2)));
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str3), heff_strAppend(heff_dup(v_w_241), v_t_244));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_NoValue: {
    V v_w_245 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_245), ((V)&g_std_2ecli_2eproblemSaid_str4));
  }
  case TAG_SwitchValue: {
    V v_w_246 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_246), ((V)&g_std_2ecli_2eproblemSaid_str5));
  }
  case TAG_Ambiguous: {
    V v_w_247 = heff_field(v_x1_240, 0);
    V v_cands_248 = heff_field(v_x1_240, 1);
    V v_t_249 = (g_list_2emap_24s231073986x752637537(((V)&g_std_2ecli_2eproblemSaid_str6), heff_dup(v_cands_248)));
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_std_2ecli_2eorList(a_0)); heff_drop(v_t_249); r_; });
    return heff_strAppend(heff_dup(v_w_247), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str7), v_t_2410));
  }
  case TAG_MissingFlag: {
    V v_w_2411 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_2411), ((V)&g_std_2ecli_2eproblemSaid_str8));
  }
  case TAG_NotIn: {
    V v_w_2412 = heff_field(v_x1_240, 0);
    V v_v_2413 = heff_field(v_x1_240, 1);
    V v_vs_2414 = heff_field(v_x1_240, 2);
    V v_t_2415 = (g_std_2ecli_2eorList(v_vs_2414));
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str9), heff_dup(v_v_2413)));
    return heff_strAppend(heff_dup(v_w_2412), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str10), v_t_2416));
  }
  case TAG_Missing: {
    V v_m_2417 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str11), heff_dup(v_m_2417));
  }
  case TAG_Extra: {
    V v_w_2418 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str12), heff_dup(v_w_2418));
  }
  case TAG_Help: {
    return ((V)&g_std_2ecli_2eproblemSaid_str13);
  }
  case TAG_BadShape: {
    V v_why_2419 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str14), heff_dup(v_why_2419));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eproblemSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eproblemSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eshells_str0, 3, "zsh");
HEFF_LIT(g_std_2ecli_2eshells_str1, 4, "fish");
HEFF_LIT(g_std_2ecli_2eshells_str2, 4, "bash");

static V g_std_2ecli_2eshells_val;
static HEFF_ONCE g_std_2ecli_2eshells_st;
static V g_std_2ecli_2eshells_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str0), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str2), v_t_240})});
}
V g_std_2ecli_2eshells_get(void) {
  if (HEFF_DONE(g_std_2ecli_2eshells_st)) return g_std_2ecli_2eshells_val;
  return heff_global(&g_std_2ecli_2eshells_val, &g_std_2ecli_2eshells_st, g_std_2ecli_2eshells_init);
}
HEFF_LIT(g_std_2ecli_2ecandidatesText_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str1, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str4, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str5, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str6, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str7, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str8, 7, ":files ");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str9, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str10, 6, ":dirs\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str11, 0, "");
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args);
Clo g_std_2ecli_2ecandidatesText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecandidatesText_entry, 2, 0};

V g_std_2ecli_2ecandidatesText(V v_sh_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Words: {
    V v_ws_242 = heff_field(v_x2_241, 0);
    V v_x2_2411 = (g_list_2emap(heff_clo_n(g_std_2ecli_2ecandidatesText_lam0, 1, 1, (V[]){v_sh_240}), heff_dup(v_ws_242)));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      return ((V)&g_std_2ecli_2ecandidatesText_str6);
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return ({ V a_0 = ((V)&g_std_2ecli_2ecandidatesText_str7); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  case TAG_FilesBy: {
    V v_sfx_2414 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_sh_240, 2);
    return heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str8), heff_strAppend(heff_dup(v_sfx_2414), ((V)&g_std_2ecli_2ecandidatesText_str9)));
  }
  case TAG_DirsOnly: {
    heff_drop_rec(v_sh_240, 2);
    return ((V)&g_std_2ecli_2ecandidatesText_str10);
  }
  case TAG_Nothing: {
    heff_drop_rec(v_sh_240, 2);
    return ((V)&g_std_2ecli_2ecandidatesText_str11);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecandidatesText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecandidatesText(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args) {
  V v_w_243 = args[0];
  V v_sh_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_doc_248;
  if (heff_strEq_c(heff_strSlice_lent(v_w_243, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ecandidatesText_str0))) {
    V v_t_245 = heff_strSlice(heff_dup(v_w_243), MK_INT(2LL), heff_strLength_lent(v_w_243, 0));
    V v_t_246 = ({ V a_0 = v_t_245; V b_1 = heff_get_n(v_sh_240, 0, 2); V r_ = (g_list_2efind_24s1839921325x671097810(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_doc_248 = ((V)&g_std_2ecli_2ecandidatesText_str1);
      break;
    }
    case TAG_Just: {
      V v_f_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_doc_248 = heff_get_n(v_f_247, 3, 8);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
  } else {
    heff_drop_rec(v_sh_240, 2);
    v_doc_248 = ((V)&g_std_2ecli_2ecandidatesText_str2);
  }
  V v_t_2410;
  if (heff_strEq_c_lent(v_doc_248, ((V)&g_std_2ecli_2ecandidatesText_str3), 2)) {
    heff_drop(v_doc_248);
    v_t_2410 = v_w_243;
  } else {
    v_t_2410 = heff_strAppend(v_w_243, heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str4), v_doc_248));
  }
  return heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2ecandidatesText_str5));
}
HEFF_LIT(g_std_2ecli_2ecommandsText_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str1, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecommandsText_str2, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecommandsText_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str5, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecommandsText_str6, 29, "a completion script for SHELL");
HEFF_LIT(g_std_2ecli_2ecommandsText_str7, 4, "help");
HEFF_LIT(g_std_2ecli_2ecommandsText_str8, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2ecommandsText_str9, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str10, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecommandsText_str11, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecommandsText_str12, 0, "");
HEFF_LIT(g_std_2ecli_2ecommandsText_str13, 0, "");
Clo g_std_2ecli_2ecommandsText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecommandsText_entry, 2, 0};

V g_std_2ecli_2ecommandsText(V v_cs_240, V v_cur_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24f1690623035x874154762(((V)&g_std_2ecli_2ecommandsText_str0), ((V)&g_std_2ecli_2ecommandsText_str1), ((V)&g_std_2ecli_2ecommandsText_str2), MK_INT(0LL), heff_dup(v_cur_241), v_cs_240));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_std_2ecli_2ecommandsText_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_std_2ecli_2ecommandsText_str4); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecommandsText_str5), ((V)&g_std_2ecli_2ecommandsText_str6)}), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecommandsText_str7), ((V)&g_std_2ecli_2ecommandsText_str8)}), v_t_246});
  V v_xs_248 = (g_list_2efilter_24s2016771181x401513202(MK_INT(0LL), v_cur_241, v_t_247));
  V v_x2_249 = (g_list_2emap_24s1412546768x2004463577(((V)&g_std_2ecli_2ecommandsText_str9), ((V)&g_std_2ecli_2ecommandsText_str10), ((V)&g_std_2ecli_2ecommandsText_str11), v_xs_248));
  V v_t_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_std_2ecli_2ecommandsText_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2ecommandsText_str13); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  return heff_strAppend(v_t_245, v_t_2412);
}
V g_std_2ecli_2ecommandsText_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecommandsText(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2ecompleteWords_str0, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str1, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str5, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str7, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str8, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str9, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str10, 0, "");
Clo g_std_2ecli_2ecompleteWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteWords_entry, 3, 0};

V g_std_2ecli_2ecompleteWords(V v_cs_240, V v_x2_241, V v_cur_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_std_2ecli_2ecommandsText(v_cs_240, v_cur_242));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x21_243, ((V)&g_std_2ecli_2ecompleteWords_str0), 2)) {
      switch (heff_tag_of(v_x22_244)) {
      case TAG_Nil: {
        V v_x2_246 = (g_list_2emap_24f130772758x674845987_24f797488600x357897558(((V)&g_std_2ecli_2ecompleteWords_str1), MK_INT(0LL), v_cur_242, v_cs_240));
        switch (heff_tag_of(v_x2_246)) {
        case TAG_Nil: {
          return ((V)&g_std_2ecli_2ecompleteWords_str2);
        }
        case TAG_Cons: {
          V v_x_247 = heff_field(v_x2_246, 0);
          V v_xs_248 = heff_field(v_x2_246, 1);
          heff_take_n(v_x2_246, 3ULL, 2);
          return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        }
        default: return heff_nomatch(v_x2_246);
        }
      }
      case TAG_Cons: {
        V v_t_2411 = ({ V a_0 = heff_dup(v_x21_243); V a_1 = v_cs_240; V r_ = (g_list_2efind_24s1541406305x377496150(a_0, a_1)); heff_drop(v_cs_240); r_; });
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nothing: {
          heff_drop(v_cur_242);
          return ((V)&g_std_2ecli_2ecompleteWords_str4);
        }
        case TAG_Just: {
          V v_k_2412 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 1);
          V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2412, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2414 = heff_tr(heff_call(heff_get_n(v_k_2412, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_sh_2415 = heff_get_n(v_t_2414, 0, 2);
          V v_t_2416 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2415, 1), MK_INT(0LL)));
          V v_t_2417 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
          V v_t_2418 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2415), v_t_2416, v_t_2417, heff_dup(v_x22_244)));
          V v_t_2419 = (g_std_2ecli_2ecompleteAt(v_sh_2415, v_t_2418, v_cur_242));
          return ({ V a_0 = heff_get_n(v_t_2413, 0, 2); V a_1 = v_t_2419; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2419); r_; });
        }
        default: return heff_nomatch(v_t_2411);
        }
      }
      default: return heff_nomatch(v_x22_244);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_243, ((V)&g_std_2ecli_2ecompleteWords_str5), 2)) {
        switch (heff_tag_of(v_x22_244)) {
        case TAG_Nil: {
          heff_drop(v_cs_240);
          V v_x2_2421 = (g_list_2emap_24f130772758x674845987(((V)&g_std_2ecli_2ecompleteWords_str6), MK_INT(0LL), v_cur_242, heff_dup(g_std_2ecli_2eshells_get())));
          switch (heff_tag_of(v_x2_2421)) {
          case TAG_Nil: {
            return ((V)&g_std_2ecli_2ecompleteWords_str7);
          }
          case TAG_Cons: {
            V v_x_2422 = heff_field(v_x2_2421, 0);
            V v_xs_2423 = heff_field(v_x2_2421, 1);
            heff_take_n(v_x2_2421, 3ULL, 2);
            return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          }
          default: return heff_nomatch(v_x2_2421);
          }
        }
        case TAG_Cons: {
          V v_t_2426 = ({ V a_0 = heff_dup(v_x21_243); V a_1 = v_cs_240; V r_ = (g_list_2efind_24s1541406305x377496150(a_0, a_1)); heff_drop(v_cs_240); r_; });
          switch (heff_tag_of(v_t_2426)) {
          case TAG_Nothing: {
            heff_drop(v_cur_242);
            return ((V)&g_std_2ecli_2ecompleteWords_str9);
          }
          case TAG_Just: {
            V v_k_2427 = heff_field(v_t_2426, 0);
            heff_take_n(v_t_2426, 1ULL, 1);
            V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2427, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2429 = heff_tr(heff_call(heff_get_n(v_k_2427, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2430 = heff_get_n(v_t_2429, 0, 2);
            V v_t_2431 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2430, 1), MK_INT(0LL)));
            V v_t_2432 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2433 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2430), v_t_2431, v_t_2432, heff_dup(v_x22_244)));
            V v_t_2434 = (g_std_2ecli_2ecompleteAt(v_sh_2430, v_t_2433, v_cur_242));
            return ({ V a_0 = heff_get_n(v_t_2428, 0, 2); V a_1 = v_t_2434; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2434); r_; });
          }
          default: return heff_nomatch(v_t_2426);
          }
        }
        default: return heff_nomatch(v_x22_244);
        }
      } else {
        V v_t_2435 = ({ V a_0 = heff_dup(v_x21_243); V a_1 = v_cs_240; V r_ = (g_list_2efind_24s1541406305x377496150(a_0, a_1)); heff_drop(v_cs_240); r_; });
        switch (heff_tag_of(v_t_2435)) {
        case TAG_Nothing: {
          heff_drop(v_cur_242);
          return ((V)&g_std_2ecli_2ecompleteWords_str10);
        }
        case TAG_Just: {
          V v_k_2436 = heff_field(v_t_2435, 0);
          heff_take_n(v_t_2435, 1ULL, 1);
          V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2436, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2438 = heff_tr(heff_call(heff_get_n(v_k_2436, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_sh_2439 = heff_get_n(v_t_2438, 0, 2);
          V v_t_2440 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2439, 1), MK_INT(0LL)));
          V v_t_2441 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
          V v_t_2442 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2439), v_t_2440, v_t_2441, heff_dup(v_x22_244)));
          V v_t_2443 = (g_std_2ecli_2ecompleteAt(v_sh_2439, v_t_2442, v_cur_242));
          return ({ V a_0 = heff_get_n(v_t_2437, 0, 2); V a_1 = v_t_2443; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2443); r_; });
        }
        default: return heff_nomatch(v_t_2435);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecompleteWords_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecompleteWords(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_entry, 1, 0};

V g_std_2ecli_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_std_2ecli_2einitOf_24dps(v_x12_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf(a[0]);
}
Clo g_std_2ecli_2einitOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_24dps_entry, 2, 0};

V g_std_2ecli_2einitOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x12_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf_24dps(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2elastOf_str0, 0, "");
Clo g_std_2ecli_2elastOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOf_entry, 1, 0};

V g_std_2ecli_2elastOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2elastOf_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2efishScript_str0, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2efishScript_str1, 18, " completions fish`");
HEFF_LIT(g_std_2ecli_2efishScript_str2, 2, "# ");
HEFF_LIT(g_std_2ecli_2efishScript_str3, 11, "function __");
HEFF_LIT(g_std_2ecli_2efishScript_str4, 9, "_complete");
HEFF_LIT(g_std_2ecli_2efishScript_str5, 16, "    set -l out (");
HEFF_LIT(g_std_2ecli_2efishScript_str6, 17, " complete $words)");
HEFF_LIT(g_std_2ecli_2efishScript_str7, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2efishScript_str8, 3, " -e");
HEFF_LIT(g_std_2ecli_2efishScript_str9, 11, " -f -a '(__");
HEFF_LIT(g_std_2ecli_2efishScript_str10, 11, "_complete)'");
HEFF_LIT(g_std_2ecli_2efishScript_str11, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2efishScript_str12, 3, "end");
HEFF_LIT(g_std_2ecli_2efishScript_str13, 30, "            printf '%s\\n' $out");
HEFF_LIT(g_std_2ecli_2efishScript_str14, 7, "    end");
HEFF_LIT(g_std_2ecli_2efishScript_str15, 57, "            __fish_complete_directories (commandline -ct)");
HEFF_LIT(g_std_2ecli_2efishScript_str16, 16, "        case '*'");
HEFF_LIT(g_std_2ecli_2efishScript_str17, 75, "            __fish_complete_suffix (string replace ':files ' '' -- $out[1])");
HEFF_LIT(g_std_2ecli_2efishScript_str18, 20, "        case ':dirs'");
HEFF_LIT(g_std_2ecli_2efishScript_str19, 20, "    switch \"$out[1]\"");
HEFF_LIT(g_std_2ecli_2efishScript_str20, 23, "        case ':files *'");
HEFF_LIT(g_std_2ecli_2efishScript_str21, 19, "    set -e words[1]");
HEFF_LIT(g_std_2ecli_2efishScript_str22, 53, "    set -l words (commandline -opc) (commandline -ct)");
HEFF_LIT(g_std_2ecli_2efishScript_str23, 1, "\012");
Clo g_std_2ecli_2efishScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2efishScript_entry, 1, 0};

V g_std_2ecli_2efishScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str0), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str1)));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str2), heff_strAppend(heff_dup(v_prog_240), v_t_241));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str4)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str6)));
  V v_t_245 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str7), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str8)));
  V v_t_246 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str9), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str10)));
  V v_t_247 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str11), heff_strAppend(v_prog_240, v_t_246));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str12), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str14), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str16), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str18), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str20), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str21), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str22), v_t_2414})});
  return ({ V a_0 = ((V)&g_std_2ecli_2efishScript_str23); V a_1 = v_t_242; V a_2 = v_t_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2415, 2); r_; });
}
V g_std_2ecli_2efishScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2efishScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2ebashScript_str0, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ebashScript_str1, 18, " completions bash`");
HEFF_LIT(g_std_2ecli_2ebashScript_str2, 2, "# ");
HEFF_LIT(g_std_2ecli_2ebashScript_str3, 1, "_");
HEFF_LIT(g_std_2ecli_2ebashScript_str4, 4, "() {");
HEFF_LIT(g_std_2ecli_2ebashScript_str5, 49, "  while IFS= read -r w; do out+=(\"$w\"); done < <(");
HEFF_LIT(g_std_2ecli_2ebashScript_str6, 26, " complete \"${words[@]:1}\")");
HEFF_LIT(g_std_2ecli_2ebashScript_str7, 1, " ");
HEFF_LIT(g_std_2ecli_2ebashScript_str8, 26, "complete -o filenames -F _");
HEFF_LIT(g_std_2ecli_2ebashScript_str9, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ebashScript_str10, 1, "}");
HEFF_LIT(g_std_2ecli_2ebashScript_str11, 25, "        COMPREPLY+=(\"$w\")");
HEFF_LIT(g_std_2ecli_2ebashScript_str12, 13, "      done ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str13, 22, "        w=${w%%$'\\t'*}");
HEFF_LIT(g_std_2ecli_2ebashScript_str14, 77, "        if [[ $last == *=* ]]; then w=${w#*=}; [[ $cur == = ]] && w=\"=$w\"; fi");
HEFF_LIT(g_std_2ecli_2ebashScript_str15, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ebashScript_str16, 30, "      for w in \"${out[@]}\"; do");
HEFF_LIT(g_std_2ecli_2ebashScript_str17, 103, "    ':files '*) COMPREPLY=($(compgen -d -- \"$cur\") $(compgen -f -X \"!*${out[0]#:files }\" -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str18, 51, "    ':dirs') COMPREPLY=($(compgen -d -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str19, 14, "  COMPREPLY=()");
HEFF_LIT(g_std_2ecli_2ebashScript_str20, 21, "  case \"${out[0]}\" in");
HEFF_LIT(g_std_2ecli_2ebashScript_str21, 31, "  last=${words[${#words[@]}-1]}");
HEFF_LIT(g_std_2ecli_2ebashScript_str22, 28, "  read -ra words <<< \"$line\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str23, 58, "  [[ $line == *' ' || ${#words[@]} -eq 1 ]] && words+=('')");
HEFF_LIT(g_std_2ecli_2ebashScript_str24, 75, "  local line=${COMP_LINE:0:COMP_POINT} cur=${COMP_WORDS[COMP_CWORD]} w last");
HEFF_LIT(g_std_2ecli_2ebashScript_str25, 20, "  local -a words out");
HEFF_LIT(g_std_2ecli_2ebashScript_str26, 1, "\012");
Clo g_std_2ecli_2ebashScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ebashScript_entry, 1, 0};

V g_std_2ecli_2ebashScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str0), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str1)));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str2), heff_strAppend(heff_dup(v_prog_240), v_t_241));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str4)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str6)));
  V v_t_245 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ebashScript_str7), v_prog_240));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2ebashScript_str8), v_t_245), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str10), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str12), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str14), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str16), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str18), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str20), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str21), heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str22), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str23), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str24), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str25), v_t_2414})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ebashScript_str26); V a_1 = v_t_242; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2415}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2ebashScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ebashScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2ezshScript_str0, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ezshScript_str1, 17, " completions zsh`");
HEFF_LIT(g_std_2ecli_2ezshScript_str2, 2, "# ");
HEFF_LIT(g_std_2ecli_2ezshScript_str3, 1, "_");
HEFF_LIT(g_std_2ecli_2ezshScript_str4, 4, "() {");
HEFF_LIT(g_std_2ecli_2ezshScript_str5, 16, "  out=(\"${(@f)$(");
HEFF_LIT(g_std_2ecli_2ezshScript_str6, 38, " complete \"${(@)words[2,CURRENT]}\")}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str7, 16, "      _describe ");
HEFF_LIT(g_std_2ecli_2ezshScript_str8, 9, " cands ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2ezshScript_str10, 4, "; fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str11, 21, " \"$@\"; else compdef _");
HEFF_LIT(g_std_2ecli_2ezshScript_str12, 10, " ]; then _");
HEFF_LIT(g_std_2ecli_2ezshScript_str13, 24, "if [ \"$funcstack[1]\" = _");
HEFF_LIT(g_std_2ecli_2ezshScript_str14, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ezshScript_str15, 1, "}");
HEFF_LIT(g_std_2ecli_2ezshScript_str16, 10, "      done");
HEFF_LIT(g_std_2ecli_2ezshScript_str17, 32, "          cands+=(\"${l//:/\\\\:}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str18, 10, "        fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str19, 55, "          cands+=(\"${${l%%$'\\t'*}//:/\\\\:}:${l#*$'\\t'}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str20, 12, "        else");
HEFF_LIT(g_std_2ecli_2ezshScript_str21, 31, "        [[ -z $l ]] && continue");
HEFF_LIT(g_std_2ecli_2ezshScript_str22, 36, "        if [[ $l == *$'\\t'* ]]; then");
HEFF_LIT(g_std_2ecli_2ezshScript_str23, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ezshScript_str24, 23, "      for l in $out; do");
HEFF_LIT(g_std_2ecli_2ezshScript_str25, 49, "    ':files '*) _files -g \"*${out[1]#:files }\" ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str26, 25, "    ':dirs') _files -/ ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str27, 17, "  case $out[1] in");
HEFF_LIT(g_std_2ecli_2ezshScript_str28, 20, "  local -a out cands");
HEFF_LIT(g_std_2ecli_2ezshScript_str29, 9, "  local l");
HEFF_LIT(g_std_2ecli_2ezshScript_str30, 1, "\012");
HEFF_LIT(g_std_2ecli_2ezshScript_str31, 9, "#compdef ");
Clo g_std_2ecli_2ezshScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ezshScript_entry, 1, 0};

V g_std_2ecli_2ezshScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str0), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str1)));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str2), heff_strAppend(heff_dup(v_prog_240), v_t_241));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str4)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str6)));
  V v_t_245 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str7), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str8)));
  V v_t_246 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str9), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str10)));
  V v_t_247 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str11), heff_strAppend(heff_dup(v_prog_240), v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str12), heff_strAppend(heff_dup(v_prog_240), v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str13), heff_strAppend(heff_dup(v_prog_240), v_t_248));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str15), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str18), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str20), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str22), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str24), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str26), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str27), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str28), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str29), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2419})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ezshScript_str30); V a_1 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str31), v_prog_240); V a_2 = v_t_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2420, 2); r_; });
}
V g_std_2ecli_2ezshScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ezshScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str1, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str2, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str3, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str7, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str8, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str9, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str10, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str11, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str12, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str13, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str14, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str15, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str16, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str17, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str18, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str19, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str20, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str21, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str22, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str23, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str24, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str25, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str26, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str27, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str28, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str29, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str30, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str31, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str32, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str33, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str34, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str35, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str36, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str37, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str38, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str39, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str40, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str41, 1, "\012");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str42, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str43, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_str44, 1, " ");
Clo g_std_2ecli_2eoutcomeOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eoutcomeOf_entry, 3, 0};

V g_std_2ecli_2eoutcomeOf(V v_prog_240, V v_k_241, V v_ws_242) {
top: ;
  V v_it_243 = (g_std_2ecli_2eparse(heff_dup(heff_rfield(v_k_241, 3)), v_ws_242));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_Unknown: {
      V v_t_247 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 2); r_; });
      V v_t_248 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_249 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str0), heff_strAppend(v_t_248, ((V)&g_std_2ecli_2eoutcomeOf_str1)));
      V v_t_2410 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str2), heff_strAppend(heff_dup(v_prog_240), v_t_249));
      V v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str3), heff_strAppend(v_t_247, v_t_2410));
      V v_t_2412 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2411);
      V v_t_2413 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str4), v_t_2412));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2413});
    }
    case TAG_NoValue: {
      V v_t_2415 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2416 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2417 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str5), heff_strAppend(v_t_2416, ((V)&g_std_2ecli_2eoutcomeOf_str6)));
      V v_t_2418 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str7), heff_strAppend(heff_dup(v_prog_240), v_t_2417));
      V v_t_2419 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str8), heff_strAppend(v_t_2415, v_t_2418));
      V v_t_2420 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2419);
      V v_t_2421 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str9), v_t_2420));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2421});
    }
    case TAG_SwitchValue: {
      V v_t_2423 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2424 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2425 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str10), heff_strAppend(v_t_2424, ((V)&g_std_2ecli_2eoutcomeOf_str11)));
      V v_t_2426 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str12), heff_strAppend(heff_dup(v_prog_240), v_t_2425));
      V v_t_2427 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str13), heff_strAppend(v_t_2423, v_t_2426));
      V v_t_2428 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2427);
      V v_t_2429 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str14), v_t_2428));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2429});
    }
    case TAG_Ambiguous: {
      V v_t_2432 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 2); r_; });
      V v_t_2433 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2434 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str15), heff_strAppend(v_t_2433, ((V)&g_std_2ecli_2eoutcomeOf_str16)));
      V v_t_2435 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str17), heff_strAppend(heff_dup(v_prog_240), v_t_2434));
      V v_t_2436 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str18), heff_strAppend(v_t_2432, v_t_2435));
      V v_t_2437 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2436);
      V v_t_2438 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str19), v_t_2437));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2438});
    }
    case TAG_MissingFlag: {
      V v_t_2440 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2441 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2442 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str20), heff_strAppend(v_t_2441, ((V)&g_std_2ecli_2eoutcomeOf_str21)));
      V v_t_2443 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str22), heff_strAppend(heff_dup(v_prog_240), v_t_2442));
      V v_t_2444 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str23), heff_strAppend(v_t_2440, v_t_2443));
      V v_t_2445 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2444);
      V v_t_2446 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str24), v_t_2445));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2446});
    }
    case TAG_NotIn: {
      V v_t_2450 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 3); r_; });
      V v_t_2451 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2452 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str25), heff_strAppend(v_t_2451, ((V)&g_std_2ecli_2eoutcomeOf_str26)));
      V v_t_2453 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str27), heff_strAppend(heff_dup(v_prog_240), v_t_2452));
      V v_t_2454 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str28), heff_strAppend(v_t_2450, v_t_2453));
      V v_t_2455 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2454);
      V v_t_2456 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str29), v_t_2455));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2456});
    }
    case TAG_Missing: {
      V v_t_2458 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2459 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2460 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str30), heff_strAppend(v_t_2459, ((V)&g_std_2ecli_2eoutcomeOf_str31)));
      V v_t_2461 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str32), heff_strAppend(heff_dup(v_prog_240), v_t_2460));
      V v_t_2462 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str33), heff_strAppend(v_t_2458, v_t_2461));
      V v_t_2463 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2462);
      V v_t_2464 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str34), v_t_2463));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2464});
    }
    case TAG_Extra: {
      V v_t_2466 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2467 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2468 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str35), heff_strAppend(v_t_2467, ((V)&g_std_2ecli_2eoutcomeOf_str36)));
      V v_t_2469 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str37), heff_strAppend(heff_dup(v_prog_240), v_t_2468));
      V v_t_2470 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str38), heff_strAppend(v_t_2466, v_t_2469));
      V v_t_2471 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2470);
      V v_t_2472 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str39), v_t_2471));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2472});
    }
    case TAG_Help: {
      V v_t_2473 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_241));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Out, 1, (V[]){v_t_2473});
    }
    case TAG_BadShape: {
      V v_t_2475 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2476 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2477 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str40), heff_strAppend(v_t_2476, ((V)&g_std_2ecli_2eoutcomeOf_str41)));
      V v_t_2478 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str42), heff_strAppend(heff_dup(v_prog_240), v_t_2477));
      V v_t_2479 = heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str43), heff_strAppend(v_t_2475, v_t_2478));
      V v_t_2480 = heff_strAppend(heff_get_n(v_k_241, 0, 4), v_t_2479);
      V v_t_2481 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str44), v_t_2480));
      return heff_tag_at_n(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2481});
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_Right: {
    V v_x_2482 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse_n(v_it_243, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop_rec(v_k_241, 4);
    return heff_tag_at_n(v_ru_24it_243_24Right, TAG_Run, 1, (V[]){v_x_2482});
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eoutcomeOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2ecli_2ereadLine_str0, 4, "help");
HEFF_LIT(g_std_2ecli_2ereadLine_str1, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str2, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_str3, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str4, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_str5, 6, "--help");
HEFF_LIT(g_std_2ecli_2ereadLine_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str7, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_str8, 2, "-h");
HEFF_LIT(g_std_2ecli_2ereadLine_str9, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str10, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_str11, 11, "completions");
HEFF_LIT(g_std_2ecli_2ereadLine_str12, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str13, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_str14, 4, "fish");
HEFF_LIT(g_std_2ecli_2ereadLine_str15, 4, "bash");
HEFF_LIT(g_std_2ecli_2ereadLine_str16, 3, "zsh");
HEFF_LIT(g_std_2ecli_2ereadLine_str17, 6, ", not ");
HEFF_LIT(g_std_2ecli_2ereadLine_str18, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str19, 25, " completions: a shell is ");
HEFF_LIT(g_std_2ecli_2ereadLine_str20, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str21, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_str22, 8, "complete");
HEFF_LIT(g_std_2ecli_2ereadLine_str23, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_str24, 13, ": no command ");
Clo g_std_2ecli_2ereadLine_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereadLine_entry, 3, 0};

V g_std_2ecli_2ereadLine(V v_prog_240, V v_cs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_t_243 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
    return heff_tag_n(TAG_Out, 1, (V[]){v_t_243});
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_str0), 2)) {
      switch (heff_tag_of(v_x32_245)) {
      case TAG_Nil: {
        V v_t_247 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
        return heff_tag_n(TAG_Out, 1, (V[]){v_t_247});
      }
      case TAG_Cons: {
        V v_w_248 = heff_field(v_x32_245, 0);
        V v_x322_249 = heff_field(v_x32_245, 1);
        switch (heff_tag_of(v_x322_249)) {
        case TAG_Nil: {
          V v_t_2410 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_w_248), v_cs_241));
          switch (heff_tag_of(v_t_2410)) {
          case TAG_Nothing: {
            V v_t_2411 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
            V v_t_2412 = heff_strAppend(heff_dup(v_w_248), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str1), v_t_2411));
            V v_t_2413 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str2), v_t_2412));
            return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2413});
          }
          case TAG_Just: {
            V v_k_2414 = heff_field(v_t_2410, 0);
            V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
            heff_drop(v_cs_241);
            V v_t_2415 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_2414));
            return heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Out, 1, (V[]){v_t_2415});
          }
          default: return heff_nomatch(v_t_2410);
          }
        }
        case TAG_Cons: {
          V v_t_2418 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_x31_244), v_cs_241));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nothing: {
            V v_t_2419 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
            V v_t_2420 = heff_strAppend(heff_dup(v_x31_244), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str3), v_t_2419));
            V v_t_2421 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str4), v_t_2420));
            return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2421});
          }
          case TAG_Just: {
            V v_k_2422 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 1);
            heff_drop(v_cs_241);
            HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2422, heff_dup(v_x32_245));
          }
          default: return heff_nomatch(v_t_2418);
          }
        }
        default: return heff_nomatch(v_x322_249);
        }
      }
      default: return heff_nomatch(v_x32_245);
      }
    } else {
      if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_str5), 2)) {
        switch (heff_tag_of(v_x32_245)) {
        case TAG_Nil: {
          V v_t_2424 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
          return heff_tag_n(TAG_Out, 1, (V[]){v_t_2424});
        }
        case TAG_Cons: {
          V v_t_2427 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_x31_244), v_cs_241));
          switch (heff_tag_of(v_t_2427)) {
          case TAG_Nothing: {
            V v_t_2428 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
            V v_t_2429 = heff_strAppend(heff_dup(v_x31_244), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str6), v_t_2428));
            V v_t_2430 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str7), v_t_2429));
            return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2430});
          }
          case TAG_Just: {
            V v_k_2431 = heff_field(v_t_2427, 0);
            heff_take_n(v_t_2427, 1ULL, 1);
            heff_drop(v_cs_241);
            HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2431, heff_dup(v_x32_245));
          }
          default: return heff_nomatch(v_t_2427);
          }
        }
        default: return heff_nomatch(v_x32_245);
        }
      } else {
        if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_str8), 2)) {
          switch (heff_tag_of(v_x32_245)) {
          case TAG_Nil: {
            V v_t_2433 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
            return heff_tag_n(TAG_Out, 1, (V[]){v_t_2433});
          }
          case TAG_Cons: {
            V v_t_2436 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_x31_244), v_cs_241));
            switch (heff_tag_of(v_t_2436)) {
            case TAG_Nothing: {
              V v_t_2437 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
              V v_t_2438 = heff_strAppend(heff_dup(v_x31_244), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str9), v_t_2437));
              V v_t_2439 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str10), v_t_2438));
              return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2439});
            }
            case TAG_Just: {
              V v_k_2440 = heff_field(v_t_2436, 0);
              heff_take_n(v_t_2436, 1ULL, 1);
              heff_drop(v_cs_241);
              HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2440, heff_dup(v_x32_245));
            }
            default: return heff_nomatch(v_t_2436);
            }
          }
          default: return heff_nomatch(v_x32_245);
          }
        } else {
          if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_str11), 2)) {
            switch (heff_tag_of(v_x32_245)) {
            case TAG_Nil: {
              V v_t_2442 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_x31_244), v_cs_241));
              switch (heff_tag_of(v_t_2442)) {
              case TAG_Nothing: {
                V v_t_2443 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                V v_t_2444 = heff_strAppend(heff_dup(v_x31_244), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str12), v_t_2443));
                V v_t_2445 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str13), v_t_2444));
                return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2445});
              }
              case TAG_Just: {
                V v_k_2446 = heff_field(v_t_2442, 0);
                heff_take_n(v_t_2442, 1ULL, 1);
                heff_drop(v_cs_241);
                HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2446, heff_dup(v_x32_245));
              }
              default: return heff_nomatch(v_t_2442);
              }
            }
            case TAG_Cons: {
              V v_sh_2447 = heff_field(v_x32_245, 0);
              V v_x322_2448 = heff_field(v_x32_245, 1);
              switch (heff_tag_of(v_x322_2448)) {
              case TAG_Nil: {
                heff_drop(v_cs_241);
                if (heff_strEq_c_lent(v_sh_2447, ((V)&g_std_2ecli_2ereadLine_str14), 2)) {
                  V v_t_2450 = (g_std_2ecli_2efishScript(v_prog_240));
                  return heff_tag_n(TAG_Out, 1, (V[]){v_t_2450});
                } else {
                  if (heff_strEq_c_lent(v_sh_2447, ((V)&g_std_2ecli_2ereadLine_str15), 2)) {
                    V v_t_2452 = (g_std_2ecli_2ebashScript(v_prog_240));
                    return heff_tag_n(TAG_Out, 1, (V[]){v_t_2452});
                  } else {
                    if (heff_strEq_c_lent(v_sh_2447, ((V)&g_std_2ecli_2ereadLine_str16), 2)) {
                      V v_t_2454 = (g_std_2ecli_2ezshScript(v_prog_240));
                      return heff_tag_n(TAG_Out, 1, (V[]){v_t_2454});
                    } else {
                      V v_t_2455 = ({ V b_0 = heff_dup(g_std_2ecli_2eshells_get()); V r_ = (g_std_2ecli_2eorList(b_0)); heff_drop(b_0); r_; });
                      V v_t_2456 = heff_strAppend(((V)&g_std_2ecli_2ereadLine_str17), heff_strAppend(heff_dup(v_sh_2447), ((V)&g_std_2ecli_2ereadLine_str18)));
                      V v_t_2457 = heff_strAppend(((V)&g_std_2ecli_2ereadLine_str19), heff_strAppend(v_t_2455, v_t_2456));
                      return heff_tag_n(TAG_Fail, 1, (V[]){heff_strAppend(v_prog_240, v_t_2457)});
                    }
                  }
                }
              }
              case TAG_Cons: {
                V v_t_2460 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_x31_244), v_cs_241));
                switch (heff_tag_of(v_t_2460)) {
                case TAG_Nothing: {
                  V v_t_2461 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                  V v_t_2462 = heff_strAppend(heff_dup(v_x31_244), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str20), v_t_2461));
                  V v_t_2463 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str21), v_t_2462));
                  return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2463});
                }
                case TAG_Just: {
                  V v_k_2464 = heff_field(v_t_2460, 0);
                  heff_take_n(v_t_2460, 1ULL, 1);
                  heff_drop(v_cs_241);
                  HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2464, heff_dup(v_x32_245));
                }
                default: return heff_nomatch(v_t_2460);
                }
              }
              default: return heff_nomatch(v_x322_2448);
              }
            }
            default: return heff_nomatch(v_x32_245);
            }
          } else {
            if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_str22), 2)) {
              heff_drop(v_prog_240);
              V v_t_2466 = (g_std_2ecli_2einitOf(heff_dup(v_x32_245)));
              V v_t_2467 = (g_std_2ecli_2elastOf(v_x32_245));
              V v_t_2468 = ({ V a_0 = v_cs_241; V a_1 = v_t_2466; V a_2 = v_t_2467; V r_ = (g_std_2ecli_2ecompleteWords(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
              return heff_tag_n(TAG_Out, 1, (V[]){v_t_2468});
            } else {
              V v_t_2469 = (g_list_2efind_24s1541406305x377496150(heff_dup(v_x31_244), v_cs_241));
              switch (heff_tag_of(v_t_2469)) {
              case TAG_Nothing: {
                V v_t_2470 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                V v_t_2471 = heff_strAppend(heff_dup(v_x31_244), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str23), v_t_2470));
                V v_t_2472 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str24), v_t_2471));
                return heff_tag_n(TAG_Fail, 1, (V[]){v_t_2472});
              }
              case TAG_Just: {
                V v_k_2473 = heff_field(v_t_2469, 0);
                heff_take_n(v_t_2469, 1ULL, 1);
                heff_drop(v_cs_241);
                HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2473, heff_dup(v_x32_245));
              }
              default: return heff_nomatch(v_t_2469);
              }
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2ereadLine_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_std_2ecli_2ereadLine(a[0], a[1], a2); heff_drop(a2); return r;
}