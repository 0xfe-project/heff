// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_Among 19600
#define TAG_BadShape 33347
#define TAG_Dirs 41877
#define TAG_DirsOnly 64835
#define TAG_Extra 49222
#define TAG_Fail 27959
#define TAG_Files 59123
#define TAG_FilesBy 64286
#define TAG_Help 25956
#define TAG_Left 13886
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_NoValue 57584
#define TAG_None 17785
#define TAG_NotIn 31836
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Out 27098
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Some 35657
#define TAG_SwitchValue 32207
#define TAG_Unknown 64328
#define TAG_Words 20643
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_complete 145693389
#define LBL_count 296209705
#define LBL_doc 309170
#define LBL_flag 9641011
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_give 9668568
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_repeated 308357578
#define LBL_required 351999471
#define LBL_sh 10428
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_take 10047822
#define LBL_values 1123329101
#define LBL_waiting 1348170899
static uint32_t shape_flags__pos[] = {LBL_flags, LBL_pos};
static uint32_t shape_give__ap__flag__pos[] = {LBL_give, LBL_ap, LBL_flag, LBL_pos};
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
static uint32_t shape_pos__flags[] = {LBL_pos, LBL_flags};
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
static uint32_t shape_shape__take[] = {LBL_shape, LBL_take};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1231799341x1378938612(V, V);
V g_list_2eany_24s1231799341x1378938612_entry(V self, V *a);
extern Clo g_list_2eany_24s1231799341x1378938612_clo;
V g_list_2eany_24s699824326x1365177236(V, V, V, V, V, V);
V g_list_2eany_24s699824326x1365177236_entry(V self, V *a);
extern Clo g_list_2eany_24s699824326x1365177236_clo;
V g_list_2eany_24s8708556x2121103388(V, V, V, V);
V g_list_2eany_24s8708556x2121103388_entry(V self, V *a);
extern Clo g_list_2eany_24s8708556x2121103388_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s2048945121x1749617505(V, V);
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a);
extern Clo g_list_2efilter_24s2048945121x1749617505_clo;
V g_list_2efilter_24s581973887x894775069(V);
V g_list_2efilter_24s581973887x894775069_entry(V self, V *a);
extern Clo g_list_2efilter_24s581973887x894775069_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1230413390x1744519585(V, V);
V g_list_2emap_24s1230413390x1744519585_entry(V self, V *a);
extern Clo g_list_2emap_24s1230413390x1744519585_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1821466936x1723477761(V);
V g_list_2emap_24s1821466936x1723477761_entry(V self, V *a);
extern Clo g_list_2emap_24s1821466936x1723477761_clo;
V g_list_2emap_24s1896835896x1330972393(V, V, V, V);
V g_list_2emap_24s1896835896x1330972393_entry(V self, V *a);
extern Clo g_list_2emap_24s1896835896x1330972393_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s483092743x614910894(V);
V g_list_2emap_24s483092743x614910894_entry(V self, V *a);
extern Clo g_list_2emap_24s483092743x614910894_clo;
V g_list_2emap_24s791123004x231442264(V, V);
V g_list_2emap_24s791123004x231442264_entry(V self, V *a);
extern Clo g_list_2emap_24s791123004x231442264_clo;
V g_list_2emap_24s832649871x524798512(V);
V g_list_2emap_24s832649871x524798512_entry(V self, V *a);
extern Clo g_list_2emap_24s832649871x524798512_clo;
V g_list_2emap_24s876522837x2005194065(V, V, V, V);
V g_list_2emap_24s876522837x2005194065_entry(V self, V *a);
extern Clo g_list_2emap_24s876522837x2005194065_clo;
V g_list_2emap_24s989117243x1797506341(V);
V g_list_2emap_24s989117243x1797506341_entry(V self, V *a);
extern Clo g_list_2emap_24s989117243x1797506341_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2ebashScript(V);
V g_std_2ecli_2ebashScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ebashScript_clo;
V g_std_2ecli_2ecandidatesText(V, V);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2ecommandsText(V, V);
V g_std_2ecli_2ecommandsText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecommandsText_clo;
V g_std_2ecli_2ecompleteAt(V, V, V);
V g_std_2ecli_2ecompleteAt_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteAt_clo;
V g_std_2ecli_2ecompleteWords(V, V, V);
V g_std_2ecli_2ecompleteWords_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteWords_clo;
V g_std_2ecli_2edistance(V, V);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
V g_std_2ecli_2edupOf(V);
V g_std_2ecli_2edupOf_entry(V self, V *a);
extern Clo g_std_2ecli_2edupOf_clo;
V g_std_2ecli_2efirstJust(V, V);
V g_std_2ecli_2efirstJust_entry(V self, V *a);
extern Clo g_std_2ecli_2efirstJust_clo;
V g_std_2ecli_2efishScript(V);
V g_std_2ecli_2efishScript_entry(V self, V *a);
extern Clo g_std_2ecli_2efishScript_clo;
V g_std_2ecli_2eflagLine(V);
V g_std_2ecli_2eflagLine_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagLine_clo;
V g_std_2ecli_2eflagProblem(V, V);
V g_std_2ecli_2eflagProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagProblem_clo;
V g_std_2ecli_2eflagWord(V);
V g_std_2ecli_2eflagWord_entry(V self, V *a);
extern Clo g_std_2ecli_2eflagWord_clo;
V g_std_2ecli_2egroupsGo(V, V);
V g_std_2ecli_2egroupsGo_entry(V self, V *a);
extern Clo g_std_2ecli_2egroupsGo_clo;
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2ehelpOf(V, V);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2einitOf(V);
V g_std_2ecli_2einitOf_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_clo;
V g_std_2ecli_2elastOf(V);
V g_std_2ecli_2elastOf_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOf_clo;
V g_std_2ecli_2elastOnly(V);
V g_std_2ecli_2elastOnly_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOnly_clo;
V g_std_2ecli_2elastOr(V, V);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2ecli_2elongF_24s1119688962x564470218(V, V, V);
V g_std_2ecli_2elongF_24s1119688962x564470218_entry(V self, V *a);
extern Clo g_std_2ecli_2elongF_24s1119688962x564470218_clo;
V g_std_2ecli_2elongNamed(V, V);
V g_std_2ecli_2elongNamed_entry(V self, V *a);
extern Clo g_std_2ecli_2elongNamed_clo;
V g_std_2ecli_2elookupL(V, V);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2enearest(V, V);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2enextGo(V, V, V, V, V, V);
V g_std_2ecli_2enextGo_entry(V self, V *a);
extern Clo g_std_2ecli_2enextGo_clo;
V g_std_2ecli_2eorList(V);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_std_2ecli_2eoutcomeOf(V, V, V);
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eoutcomeOf_clo;
V g_std_2ecli_2eparse(V, V);
V g_std_2ecli_2eparse_entry(V self, V *a);
extern Clo g_std_2ecli_2eparse_clo;
V g_std_2ecli_2eposAt(V, V);
V g_std_2ecli_2eposAt_entry(V self, V *a);
extern Clo g_std_2ecli_2eposAt_clo;
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
V g_std_2ecli_2ereadLine(V, V, V);
V g_std_2ecli_2ereadLine_entry(V self, V *a);
extern Clo g_std_2ecli_2ereadLine_clo;
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
V g_std_2ecli_2eshapeProblem(V);
V g_std_2ecli_2eshapeProblem_entry(V self, V *a);
extern Clo g_std_2ecli_2eshapeProblem_clo;
V g_std_2ecli_2eshells_get(void);
V g_std_2ecli_2eshortF_24s1014269042x1715098139(V, V, V);
V g_std_2ecli_2eshortF_24s1014269042x1715098139_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortF_24s1014269042x1715098139_clo;
V g_std_2ecli_2eshortWhere(V, V, V);
V g_std_2ecli_2eshortWhere_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_clo;
V g_std_2ecli_2eusage(V, V);
V g_std_2ecli_2eusage_entry(V self, V *a);
extern Clo g_std_2ecli_2eusage_clo;
V g_std_2ecli_2ewhereGo(V, V, V, V);
V g_std_2ecli_2ewhereGo_entry(V self, V *a);
extern Clo g_std_2ecli_2ewhereGo_clo;
V g_std_2ecli_2ewordsF_24s1352288509x2021617997(V, V);
V g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry(V self, V *a);
extern Clo g_std_2ecli_2ewordsF_24s1352288509x2021617997_clo;
V g_std_2ecli_2ezshScript(V);
V g_std_2ecli_2ezshScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ezshScript_clo;
Clo g_std_2ecli_2elastS_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastS_entry, 1, 0};

V g_std_2ecli_2elastS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastS_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2elastS(a[0]); heff_drop(a[0]); return r;
}
Clo g_std_2ecli_2elookupL_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elookupL_entry, 2, 0};

V g_std_2ecli_2elookupL(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_240), heff_dup(v_x_244))) {
        heff_drop(v_k_240);
        return heff_dup(v_vs_245);
      } else {
        V t_0 = v_k_240;
        V t_1 = v_rest_243;
        v_k_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elookupL_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2elookupL(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_std_2ecli_2ereading_lam1(V self, V *args);
V g_std_2ecli_2ereading_lam0(V self, V *args); static Clo g_std_2ecli_2ereading_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam0, 1, 0};
V g_std_2ecli_2ereading_lam3(V self, V *args);
V g_std_2ecli_2ereading_lam2(V self, V *args); static Clo g_std_2ecli_2ereading_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam2, 2, 0};
V g_std_2ecli_2ereading_lam5(V self, V *args);
V g_std_2ecli_2ereading_lam4(V self, V *args); static Clo g_std_2ecli_2ereading_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam4, 1, 0};
V g_std_2ecli_2ereading_lam7(V self, V *args); static Clo g_std_2ecli_2ereading_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam7, 2, 0};
V g_std_2ecli_2ereading_lam6(V self, V *args); static Clo g_std_2ecli_2ereading_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam6, 1, 0};

static V g_std_2ecli_2ereading_val;
static int g_std_2ecli_2ereading_st;
static V g_std_2ecli_2ereading_init(void) {
  return heff_rec(4, shape_give__ap__flag__pos, (V[]){((V)&g_std_2ecli_2ereading_lam0_clo), ((V)&g_std_2ecli_2ereading_lam2_clo), ((V)&g_std_2ecli_2ereading_lam4_clo), ((V)&g_std_2ecli_2ereading_lam6_clo)});
}
V g_std_2ecli_2ereading_get(void) {
  if (g_std_2ecli_2ereading_st == 2) return g_std_2ecli_2ereading_val;
  if (g_std_2ecli_2ereading_st == 1) heff_fail("defined by itself");
  g_std_2ecli_2ereading_st = 1;
  g_std_2ecli_2ereading_val = heff_tr(g_std_2ecli_2ereading_init());
  g_std_2ecli_2ereading_st = 2;
  return g_std_2ecli_2ereading_val;
}
V g_std_2ecli_2ereading_lam1(V self, V *args) {
  V v_x_242 = args[0];
  V v_x_243 = args[1];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_242);
  heff_drop(v_x_243);
  return v_x_240;
}
V g_std_2ecli_2ereading_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_t_241 = heff_rec(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_rec(2, shape_shape__take, (V[]){v_t_241, heff_clo(g_std_2ecli_2ereading_lam1, 2, 1, (V[]){v_x_240})});
}
V g_std_2ecli_2ereading_lam3(V self, V *args) {
  V v_groups_2412 = args[0];
  V v_fl_2413 = args[1];
  V v_f_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_get(heff_get(heff_dup(v_f_244), LBL_shape), LBL_pos);
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2414; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_list_2edrop(v_t_2415, heff_dup(v_groups_2412)));
  V v_t_2417 = heff_tr(heff_apply(heff_get(v_x_245, LBL_take), 2, (V[]){v_t_2416, heff_dup(v_fl_2413)}));
  return heff_tail(heff_get(v_f_244, LBL_take), 3, (V[]){v_groups_2412, v_fl_2413, v_t_2417});
}
V g_std_2ecli_2ereading_lam2(V self, V *args) {
  V v_f_244 = args[0];
  V v_x_245 = args[1];
  V v_t_246 = heff_get(heff_get(heff_dup(v_f_244), LBL_shape), LBL_flags);
  V v_t_247 = heff_get(heff_get(heff_dup(v_x_245), LBL_shape), LBL_flags);
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_246, v_t_247));
  V v_t_249 = heff_get(heff_get(heff_dup(v_f_244), LBL_shape), LBL_pos);
  V v_t_2410 = heff_get(heff_get(heff_dup(v_x_245), LBL_shape), LBL_pos);
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
  return heff_rec(2, shape_shape__take, (V[]){heff_rec(2, shape_flags__pos, (V[]){v_t_248, v_t_2411}), heff_clo(g_std_2ecli_2ereading_lam3, 2, 2, (V[]){v_f_244, v_x_245})});
}
V g_std_2ecli_2ereading_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_given_2422 = args[1];
  V v_fl_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  return ({ V a_0 = heff_get(v_fl_2418, LBL_long); V a_1 = v_given_2422; V r_ = (g_std_2ecli_2elookupL(a_0, a_1)); heff_drop(v_given_2422); r_; });
}
V g_std_2ecli_2ereading_lam4(V self, V *args) {
  V v_fl_2418 = args[0];
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_fl_2418), NTAG(TAG_Nil)});
  V v_t_2420 = heff_rec(2, shape_flags__pos, (V[]){v_t_2419, NTAG(TAG_Nil)});
  return heff_rec(2, shape_shape__take, (V[]){v_t_2420, heff_clo(g_std_2ecli_2ereading_lam5, 2, 1, (V[]){v_fl_2418})});
}
V g_std_2ecli_2ereading_lam7(V self, V *args) {
  V v_groups_2426 = args[0];
  V v_x_2427 = args[1];
  heff_drop(v_x_2427);
  switch (heff_tag_of(v_groups_2426)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_2428 = heff_field(v_groups_2426, 0);
    heff_take_n(v_groups_2426, 1ULL, 2);
    return v_g_2428;
  }
  default: return heff_nomatch(v_groups_2426);
  }
}
V g_std_2ecli_2ereading_lam6(V self, V *args) {
  V v_p_2423 = args[0];
  V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){v_p_2423, NTAG(TAG_Nil)});
  V v_t_2425 = heff_rec(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), v_t_2424});
  return heff_rec(2, shape_shape__take, (V[]){v_t_2425, ((V)&g_std_2ecli_2ereading_lam7_clo)});
}
Clo g_std_2ecli_2edupOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2edupOf_entry, 1, 0};

V g_std_2ecli_2edupOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
    V v_t_244 = (g_list_2eany(v_t_243, v_rest_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_False: {
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2edupOf_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2edupOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_std_2ecli_2elastOnly_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOnly_entry, 1, 0};

V g_std_2ecli_2elastOnly(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_t_245 = heff_get(heff_dup(v_p_241), LBL_arity);
      switch (heff_tag_of(v_t_245)) {
      case TAG_One: {
        V t_0 = v_x12_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_Optional: {
        return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_p_241), LBL_meta)});
      }
      case TAG_Many: {
        return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_p_241), LBL_meta)});
      }
      case TAG_Some: {
        return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_p_241), LBL_meta)});
      }
      case TAG_Rest: {
        return heff_tag(TAG_Just, 1, (V[]){heff_get(heff_dup(v_p_241), LBL_meta)});
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOnly_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2elastOnly(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_std_2ecli_2eshapeProblem_str3 = {{0x80000000u, K_STR, 0}, 26, 26, {97, 32, 115, 104, 111, 114, 116, 32, 110, 97, 109, 101, 32, 105, 115, 32, 111, 110, 101, 32, 108, 101, 116, 116, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eshapeProblem_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[69]; } g_std_2ecli_2eshapeProblem_str8 = {{0x80000000u, K_STR, 0}, 69, 69, {45, 45, 104, 101, 108, 112, 32, 97, 110, 100, 32, 45, 104, 32, 97, 114, 101, 32, 116, 104, 101, 32, 108, 105, 98, 114, 97, 114, 121, 39, 115, 59, 32, 97, 32, 108, 111, 110, 103, 32, 110, 97, 109, 101, 32, 105, 115, 32, 110, 111, 116, 32, 101, 109, 112, 116, 121, 44, 32, 104, 97, 115, 32, 110, 111, 32, 96, 61, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_std_2ecli_2eshapeProblem_str10 = {{0x80000000u, K_STR, 0}, 23, 23, {97, 32, 115, 119, 105, 116, 99, 104, 32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[41]; } g_std_2ecli_2eshapeProblem_str11 = {{0x80000000u, K_STR, 0}, 41, 41, {32, 105, 115, 32, 101, 118, 101, 114, 121, 32, 119, 111, 114, 100, 44, 32, 115, 111, 32, 110, 111, 32, 102, 108, 97, 103, 32, 99, 111, 117, 108, 100, 32, 98, 101, 32, 103, 105, 118, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[54]; } g_std_2ecli_2eshapeProblem_str12 = {{0x80000000u, K_STR, 0}, 54, 54, {32, 116, 97, 107, 101, 115, 32, 109, 111, 114, 101, 32, 111, 114, 32, 108, 101, 115, 115, 32, 116, 104, 97, 110, 32, 111, 110, 101, 32, 119, 111, 114, 100, 44, 32, 97, 110, 100, 32, 105, 115, 32, 110, 111, 116, 32, 116, 104, 101, 32, 108, 97, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshapeProblem_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2eshapeProblem_str14 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 116, 119, 105, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eshapeProblem_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2eshapeProblem_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 116, 119, 105, 99, 101}};
Clo g_std_2ecli_2eshapeProblem_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshapeProblem_entry, 1, 0};

V g_std_2ecli_2eshapeProblem(V v_sh_240) {
top: ;
  V v_t_241 = (g_list_2emap_24s832649871x524798512(heff_get(heff_dup(v_sh_240), LBL_flags)));
  V v_t_242 = ({ V a_0 = v_t_241; V r_ = (g_std_2ecli_2edupOf(a_0)); heff_drop(v_t_241); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = (g_list_2emap_24s483092743x614910894(heff_get(heff_dup(v_sh_240), LBL_flags)));
    V v_t_244 = (g_list_2efilter_24s2048945121x1749617505(((V)&g_std_2ecli_2eshapeProblem_str0), v_t_243));
    V v_t_245 = ({ V a_0 = v_t_244; V r_ = (g_std_2ecli_2edupOf(a_0)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = ((V)&g_std_2ecli_2eshapeProblem_str1); V a_2 = ((V)&g_std_2ecli_2eshapeProblem_str2); V b_3 = heff_get(heff_dup(v_sh_240), LBL_flags); V r_ = (g_list_2eany_24s8708556x2121103388(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_sh_240);
        return heff_tag(TAG_Just, 1, (V[]){((V)&g_std_2ecli_2eshapeProblem_str3)});
      }
      case TAG_False: {
        V v_t_247 = ({ V a_0 = ((V)&g_std_2ecli_2eshapeProblem_str4); V a_1 = ((V)&g_std_2ecli_2eshapeProblem_str5); V a_2 = ((V)&g_std_2ecli_2eshapeProblem_str6); V a_3 = ((V)&g_std_2ecli_2eshapeProblem_str7); V a_4 = MK_INT(0LL); V b_5 = heff_get(heff_dup(v_sh_240), LBL_flags); V r_ = (g_list_2eany_24s699824326x1365177236(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(b_5); r_; });
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_sh_240);
          return heff_tag(TAG_Just, 1, (V[]){((V)&g_std_2ecli_2eshapeProblem_str8)});
        }
        case TAG_False: {
          V v_t_248 = ({ V a_0 = ((V)&g_std_2ecli_2eshapeProblem_str9); V b_1 = heff_get(heff_dup(v_sh_240), LBL_flags); V r_ = (g_list_2eany_24s1231799341x1378938612(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_t_248)) {
          case TAG_True: {
            heff_drop(v_sh_240);
            return heff_tag(TAG_Just, 1, (V[]){((V)&g_std_2ecli_2eshapeProblem_str10)});
          }
          case TAG_False: {
            V v_t_249 = ({ V b_0 = heff_get(heff_dup(v_sh_240), LBL_pos); V r_ = (g_std_2ecli_2elastOnly(b_0)); heff_drop(b_0); r_; });
            switch (heff_tag_of(v_t_249)) {
            case TAG_Nothing: {
              V v_t_2410 = heff_get(heff_dup(v_sh_240), LBL_pos);
              switch (heff_tag_of(v_t_2410)) {
              case TAG_Nil: {
                heff_drop(v_sh_240);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_p_2411 = heff_field(v_t_2410, 0);
                heff_take_n(v_t_2410, 1ULL, 2);
                V v_t_2413 = heff_get(heff_dup(v_p_2411), LBL_arity);
                switch (heff_tag_of(v_t_2413)) {
                case TAG_One: {
                  heff_drop(v_sh_240);
                  heff_drop(v_p_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Optional: {
                  heff_drop(v_sh_240);
                  heff_drop(v_p_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Many: {
                  heff_drop(v_sh_240);
                  heff_drop(v_p_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Some: {
                  heff_drop(v_sh_240);
                  heff_drop(v_p_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Rest: {
                  V v_t_2414 = heff_get(v_sh_240, LBL_flags);
                  switch (heff_tag_of(v_t_2414)) {
                  case TAG_Nil: {
                    heff_drop(v_p_2411);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Cons: {
                    heff_take_n(v_t_2414, 0ULL, 2);
                    V v_t_2417 = heff_strAppend(heff_get(v_p_2411, LBL_meta), ((V)&g_std_2ecli_2eshapeProblem_str11));
                    return heff_tag(TAG_Just, 1, (V[]){v_t_2417});
                  }
                  default: return heff_nomatch(v_t_2414);
                  }
                }
                default: return heff_nomatch(v_t_2413);
                }
              }
              default: return heff_nomatch(v_t_2410);
              }
            }
            case TAG_Just: {
              V v_m_2418 = heff_field(v_t_249, 0);
              V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
              heff_drop(v_sh_240);
              return heff_tag_at(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_m_2418, ((V)&g_std_2ecli_2eshapeProblem_str12))});
            }
            default: return heff_nomatch(v_t_249);
            }
          }
          default: return heff_nomatch(v_t_248);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_Just: {
      V v_x_2419 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
      heff_drop(v_sh_240);
      V v_t_2420 = heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_str13), heff_strAppend(v_x_2419, ((V)&g_std_2ecli_2eshapeProblem_str14)));
      return heff_tag_at(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2420});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_sh_240);
    V v_t_2422 = heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_str15), heff_strAppend(v_x_2421, ((V)&g_std_2ecli_2eshapeProblem_str16)));
    return heff_tag_at(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_t_2422});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2ecli_2eshapeProblem_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshapeProblem(a[0]);
}
V g_std_2ecli_2elongNamed_lam0(V self, V *args);
V g_std_2ecli_2elongNamed_lam1(V self, V *args);
Clo g_std_2ecli_2elongNamed_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elongNamed_entry, 2, 0};

V g_std_2ecli_2elongNamed(V v_sh_240, V v_x_241) {
top: ;
  V v_t_243 = ({ V a_0 = heff_clo(g_std_2ecli_2elongNamed_lam0, 1, 1, (V[]){heff_dup(v_x_241)}); V b_1 = heff_get(heff_dup(v_sh_240), LBL_flags); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_fs_246 = (g_list_2efilter(heff_clo(g_std_2ecli_2elongNamed_lam1, 1, 1, (V[]){v_x_241}), heff_get(v_sh_240, LBL_flags)));
    switch (heff_tag_of(v_fs_246)) {
    case TAG_Nil: {
      return heff_tag(TAG_Left, 1, (V[]){(g_list_2emap_24s832649871x524798512(v_fs_246))});
    }
    case TAG_Cons: {
      V v_f_247 = heff_dup(heff_field(v_fs_246, 0));
      V v_fs2_248 = heff_dup(heff_field(v_fs_246, 1));
      switch (heff_tag_of(v_fs2_248)) {
      case TAG_Nil: {
        heff_drop_tag(v_fs_246, 2);
        return heff_tag(TAG_Right, 1, (V[]){v_f_247});
      }
      case TAG_Cons: {
        heff_take_n(v_fs2_248, 0ULL, 2);
        heff_drop(v_f_247);
        return heff_tag(TAG_Left, 1, (V[]){(g_list_2emap_24s832649871x524798512(v_fs_246))});
      }
      default: return heff_nomatch(v_fs2_248);
      }
    }
    default: return heff_nomatch(v_fs_246);
    }
  }
  case TAG_Just: {
    V v_f_2411 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_sh_240);
    heff_drop(v_x_241);
    return heff_tag_at(v_ru_24t_243_24Just, TAG_Right, 1, (V[]){v_f_2411});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2elongNamed_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2elongNamed(a[0], a[1]);
}
V g_std_2ecli_2elongNamed_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_f_242, LBL_long), v_x_241);
}
V g_std_2ecli_2elongNamed_lam1(V self, V *args) {
  V v_f_244 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_strSlice(heff_get(v_f_244, LBL_long), MK_INT(0LL), heff_strLength(heff_dup(v_x_241)));
  return heff_strEq(v_t_245, v_x_241);
}
Clo g_std_2ecli_2ecellOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecellOf_entry, 6, 0};

V g_std_2ecli_2ecellOf(V v_a_240, V v_c_241, V v_up_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  V v_a_246 = heff_intAdd(v_up_242, MK_INT(1LL));
  V v_b_247 = heff_intAdd(v_left_244, MK_INT(1LL));
  V v_a_249;
  if (heff_intLe_c(heff_dup(v_a_246), heff_dup(v_b_247))) {
    heff_drop(v_b_247);
    v_a_249 = v_a_246;
  } else {
    heff_drop(v_a_246);
    v_a_249 = v_b_247;
  }
  V v_t_2410 = heff_strCharCode(v_a_240, heff_intSub(v_i_245, MK_INT(1LL)));
  V v_t_2412;
  if (heff_intEq_c(v_t_2410, v_c_241)) {
    v_t_2412 = MK_INT(0LL);
  } else {
    v_t_2412 = MK_INT(1LL);
  }
  V v_b_2413 = heff_intAdd(v_diag_243, v_t_2412);
  if (heff_intLe_c(heff_dup(v_a_249), heff_dup(v_b_2413))) {
    heff_drop(v_b_2413);
    return v_a_249;
  } else {
    heff_drop(v_a_249);
    return v_b_2413;
  }
}
V g_std_2ecli_2ecellOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecellOf(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2enextGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enextGo_entry, 6, 0};

V g_std_2ecli_2enextGo(V v_a_240, V v_c_241, V v_x3_242, V v_diag_243, V v_left_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_a_240);
    heff_drop(v_c_241);
    heff_drop(v_diag_243);
    heff_drop(v_left_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_up_246 = heff_field(v_x3_242, 0);
    V v_ups_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_246), heff_dup(v_diag_243), heff_dup(v_left_244), heff_dup(v_i_245)));
    V v_t_249 = (g_std_2ecli_2ecellOf(heff_dup(v_a_240), heff_dup(v_c_241), heff_dup(v_up_246), v_diag_243, v_left_244, heff_dup(v_i_245)));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_std_2ecli_2enextGo(v_a_240, v_c_241, v_ups_247, v_up_246, v_t_249, heff_intAdd(v_i_245, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2enextGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enextGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_std_2ecli_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOr_entry, 2, 0};

V g_std_2ecli_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_d_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elastOr_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2elastOr(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_std_2ecli_2edistance_lam0(V self, V *args);
Clo g_std_2ecli_2edistance_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2edistance_entry, 2, 0};

V g_std_2ecli_2edistance(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_strLength(heff_dup(v_a_240)), MK_INT(1LL));
  V v_t_243 = (g_list_2erange(MK_INT(0LL), v_t_242));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_strLength(heff_dup(v_b_241))));
  V v_t_2413 = ({ V a_0 = heff_clo(g_std_2ecli_2edistance_lam0, 2, 2, (V[]){v_a_240, v_b_241}); V a_1 = v_t_243; V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2413; V r_ = (g_std_2ecli_2elastOr(a_0, a_1)); heff_drop(v_t_2413); r_; });
}
V g_std_2ecli_2edistance_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2edistance(a[0], a[1]);
}
V g_std_2ecli_2edistance_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_j_246 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_b_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_xs_248 = heff_dup(heff_field(v_row_245, 1));
    v_t_249 = v_xs_248;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  V v_t_2412;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_row_245, 0);
    heff_take_n(v_row_245, 1ULL, 2);
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  return heff_tag(TAG_Cons, 2, (V[]){heff_intAdd(heff_dup(v_j_246), MK_INT(1LL)), (g_std_2ecli_2enextGo(v_a_240, heff_strCharCode(v_b_241, heff_dup(v_j_246)), v_t_249, v_t_2412, heff_intAdd(v_j_246, MK_INT(1LL)), MK_INT(1LL)))});
}
V g_std_2ecli_2enearest_lam0(V self, V *args);
Clo g_std_2ecli_2enearest_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enearest_entry, 2, 0};

V g_std_2ecli_2enearest(V v_sh_240, V v_x_241) {
top: ;
  return ({ V a_0 = heff_clo(g_std_2ecli_2enearest_lam0, 2, 1, (V[]){v_x_241}); V a_1 = NTAG(TAG_Nothing); V b_2 = heff_get(v_sh_240, LBL_flags); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2enearest_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2enearest(a[0], a[1]);
}
V g_std_2ecli_2enearest_lam0(V self, V *args) {
  V v_best_242 = args[0];
  V v_f_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_std_2ecli_2edistance(heff_get(heff_dup(v_f_243), LBL_long), heff_dup(v_x_241)));
  if (heff_intLe_c(v_t_244, MK_INT(2LL))) {
    if (heff_intLe_c(heff_strLength(heff_dup(v_x_241)), MK_INT(16LL))) {
      switch (heff_tag_of(v_best_242)) {
      case TAG_Nothing: {
        heff_drop(v_x_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_get(v_f_243, LBL_long)});
      }
      case TAG_Just: {
        V v_b_247 = heff_dup(heff_field(v_best_242, 0));
        V v_t_248 = (g_std_2ecli_2edistance(heff_get(heff_dup(v_f_243), LBL_long), heff_dup(v_x_241)));
        V v_t_249 = (g_std_2ecli_2edistance(v_b_247, v_x_241));
        if (heff_intLt_c(v_t_248, v_t_249)) {
          heff_drop_tag(v_best_242, 1);
          return heff_tag(TAG_Just, 1, (V[]){heff_get(v_f_243, LBL_long)});
        } else {
          heff_drop(v_f_243);
          return v_best_242;
        }
      }
      default: return heff_nomatch(v_best_242);
      }
    } else {
      heff_drop(v_f_243);
      heff_drop(v_x_241);
      return v_best_242;
    }
  } else {
    heff_drop(v_f_243);
    heff_drop(v_x_241);
    return v_best_242;
  }
}
Clo g_std_2ecli_2erestIndex_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erestIndex_entry, 2, 0};

V g_std_2ecli_2erestIndex(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_get(heff_dup(v_p_242), LBL_arity);
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Optional: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Many: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Some: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Rest: {
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2erestIndex_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2erestIndex(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2elongF_24s1119688962x564470218_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2elongF_24s1119688962x564470218_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2elongF_24s1119688962x564470218_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2elongF_24s1119688962x564470218_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2elongF_24s1119688962x564470218_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2elongF_24s1119688962x564470218_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2elongF_24s1119688962x564470218_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2elongF_24s1119688962x564470218_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2elongF_24s1119688962x564470218_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2elongF_24s1119688962x564470218_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
Clo g_std_2ecli_2elongF_24s1119688962x564470218_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elongF_24s1119688962x564470218_entry, 3, 0};

V g_std_2ecli_2elongF_24s1119688962x564470218(V v_at_240, V v_ws_241, V v_body_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str0), heff_dup(v_body_242), MK_INT(0LL)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_std_2ecli_2elongNamed(heff_get(heff_dup(v_at_240), LBL_sh), heff_dup(v_body_242)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Left: {
      V v_cands_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Left = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_ws_241);
      V v_t_248;
      switch (heff_tag_of(v_cands_245)) {
      case TAG_Nil: {
        v_t_248 = heff_tag(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str1), heff_dup(v_body_242)), (g_std_2ecli_2enearest(heff_get(v_at_240, LBL_sh), v_body_242))});
        break;
      }
      case TAG_Cons: {
        heff_drop(v_at_240);
        v_t_248 = heff_tag(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str2), v_body_242), v_cands_245});
        break;
      }
      default: heff_nomatch(v_cands_245);
      }
      return heff_tag_at(v_ru_24t_244_24Left, TAG_Left, 1, (V[]){v_t_248});
    }
    case TAG_Right: {
      V v_f_249 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Right = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_body_242);
      if (heff_strEq_c(heff_get(heff_dup(v_f_249), LBL_meta), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str3))) {
        heff_drop_cell(v_ru_24t_244_24Right, 1);
        V v_t_2411 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_f_249, LBL_long), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str4)});
        V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, heff_get(heff_dup(v_at_240), LBL_fs)});
        V v_t_2413 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), heff_get(v_at_240, LBL_ps), v_t_2412});
        return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2413, v_ws_241));
      } else {
        switch (heff_tag_of(v_ws_241)) {
        case TAG_Nil: {
          heff_drop(v_at_240);
          V v_t_2414 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str5), heff_get(v_f_249, LBL_long));
          return heff_tag_at(v_ru_24t_244_24Right, TAG_Left, 1, (V[]){heff_tag(TAG_NoValue, 1, (V[]){v_t_2414})});
        }
        case TAG_Cons: {
          V v_v_2415 = heff_field(v_ws_241, 0);
          V v_ws2_2416 = heff_field(v_ws_241, 1);
          V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
          heff_drop_cell(v_ru_24t_244_24Right, 1);
          V v_t_2417 = heff_tag_at(v_ru_24ws_241_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_f_249, LBL_long), v_v_2415});
          V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, heff_get(heff_dup(v_at_240), LBL_fs)});
          V v_t_2419 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), heff_get(v_at_240, LBL_ps), v_t_2418});
          return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2419, v_ws2_2416));
        }
        default: return heff_nomatch(v_ws_241);
        }
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_i_2420 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2421 = (g_std_2ecli_2elongNamed(heff_get(heff_dup(v_at_240), LBL_sh), heff_strSlice(heff_dup(v_body_242), MK_INT(0LL), heff_dup(v_i_2420))));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Left: {
      V v_cands_2422 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      heff_drop(v_ws_241);
      V v_x_2423 = heff_strSlice(v_body_242, MK_INT(0LL), v_i_2420);
      V v_t_2426;
      switch (heff_tag_of(v_cands_2422)) {
      case TAG_Nil: {
        v_t_2426 = heff_tag(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str6), heff_dup(v_x_2423)), (g_std_2ecli_2enearest(heff_get(v_at_240, LBL_sh), v_x_2423))});
        break;
      }
      case TAG_Cons: {
        heff_drop(v_at_240);
        v_t_2426 = heff_tag(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str7), v_x_2423), v_cands_2422});
        break;
      }
      default: heff_nomatch(v_cands_2422);
      }
      return heff_tag_at(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){v_t_2426});
    }
    case TAG_Right: {
      V v_f_2427 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      if (heff_strEq_c(heff_get(heff_dup(v_f_2427), LBL_meta), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str8))) {
        heff_drop(v_at_240);
        heff_drop(v_ws_241);
        heff_drop(v_body_242);
        heff_drop(v_i_2420);
        V v_t_2429 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_str9), heff_get(v_f_2427, LBL_long));
        return heff_tag_at(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){heff_tag(TAG_SwitchValue, 1, (V[]){v_t_2429})});
      } else {
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        V v_t_2430 = heff_strSlice(heff_dup(v_body_242), heff_intAdd(v_i_2420, MK_INT(1LL)), heff_strLength(v_body_242));
        V v_t_2431 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_f_2427, LBL_long), v_t_2430});
        V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_t_2431, heff_get(heff_dup(v_at_240), LBL_fs)});
        V v_t_2433 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), heff_get(v_at_240, LBL_ps), v_t_2432});
        return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2433, v_ws_241));
      }
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2elongF_24s1119688962x564470218_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2elongF_24s1119688962x564470218(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortF_24s1014269042x1715098139_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortF_24s1014269042x1715098139_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortF_24s1014269042x1715098139_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortF_24s1014269042x1715098139_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortF_24s1014269042x1715098139_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortF_24s1014269042x1715098139_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
V g_std_2ecli_2eshortF_24s1014269042x1715098139_lam0(V self, V *args);
Clo g_std_2ecli_2eshortF_24s1014269042x1715098139_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortF_24s1014269042x1715098139_entry, 3, 0};

V g_std_2ecli_2eshortF_24s1014269042x1715098139(V v_at_240, V v_ws_241, V v_cl_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_cl_242), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str0))) {
    heff_drop(v_cl_242);
    return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_at_240, v_ws_241));
  } else {
    V v_x_244 = heff_strSlice(heff_dup(v_cl_242), MK_INT(0LL), MK_INT(1LL));
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str1))) {
      heff_drop(v_x_244);
      v_t_248 = NTAG(TAG_Nothing);
    } else {
      V v_t_246 = heff_get(heff_get(heff_dup(v_at_240), LBL_sh), LBL_flags);
      v_t_248 = ({ V a_0 = heff_clo(g_std_2ecli_2eshortF_24s1014269042x1715098139_lam0, 1, 1, (V[]){v_x_244}); V a_1 = v_t_246; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_246); r_; });
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_at_240);
      heff_drop(v_ws_241);
      V v_t_249 = heff_strAppend(((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str2), heff_strSlice(v_cl_242, MK_INT(0LL), MK_INT(1LL)));
      V v_t_2410 = heff_tag(TAG_Unknown, 2, (V[]){v_t_249, NTAG(TAG_Nothing)});
      return heff_tag(TAG_Left, 1, (V[]){v_t_2410});
    }
    case TAG_Just: {
      V v_f_2411 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      if (heff_strEq_c(heff_get(heff_dup(v_f_2411), LBL_meta), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str3))) {
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        V v_t_2413 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_f_2411, LBL_long), ((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str4)});
        V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, heff_get(heff_dup(v_at_240), LBL_fs)});
        V v_t_2415 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), heff_get(v_at_240, LBL_ps), v_t_2414});
        V v_t_2416 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
        V t_0 = v_t_2415;
        V t_1 = v_ws_241;
        V t_2 = v_t_2416;
        v_at_240 = t_0;
        v_ws_241 = t_1;
        v_cl_242 = t_2;
        goto top;
      } else {
        if (heff_intLt_c(MK_INT(1LL), heff_strLength(heff_dup(v_cl_242)))) {
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          V v_t_2418 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
          V v_t_2419 = heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_f_2411, LBL_long), v_t_2418});
          V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, heff_get(heff_dup(v_at_240), LBL_fs)});
          V v_t_2421 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), heff_get(v_at_240, LBL_ps), v_t_2420});
          return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2421, v_ws_241));
        } else {
          heff_drop(v_cl_242);
          switch (heff_tag_of(v_ws_241)) {
          case TAG_Nil: {
            heff_drop(v_at_240);
            V v_t_2422 = heff_strAppend(((V)&g_std_2ecli_2eshortF_24s1014269042x1715098139_str5), heff_get(v_f_2411, LBL_short));
            return heff_tag_at(v_ru_24t_248_24Just, TAG_Left, 1, (V[]){heff_tag(TAG_NoValue, 1, (V[]){v_t_2422})});
          }
          case TAG_Cons: {
            V v_v_2423 = heff_field(v_ws_241, 0);
            V v_ws2_2424 = heff_field(v_ws_241, 1);
            V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
            heff_drop_cell(v_ru_24t_248_24Just, 1);
            V v_t_2425 = heff_tag_at(v_ru_24ws_241_24Cons, TAG_MkPair, 2, (V[]){heff_get(v_f_2411, LBL_long), v_v_2423});
            V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, heff_get(heff_dup(v_at_240), LBL_fs)});
            V v_t_2427 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), heff_get(v_at_240, LBL_ps), v_t_2426});
            return (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_t_2427, v_ws2_2424));
          }
          default: return heff_nomatch(v_ws_241);
          }
        }
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
V g_std_2ecli_2eshortF_24s1014269042x1715098139_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortF_24s1014269042x1715098139(a[0], a[1], a[2]);
}
V g_std_2ecli_2eshortF_24s1014269042x1715098139_lam0(V self, V *args) {
  V v_f_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_f_247, LBL_short), v_x_244);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ewordsF_24s1352288509x2021617997_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ewordsF_24s1352288509x2021617997_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ewordsF_24s1352288509x2021617997_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ewordsF_24s1352288509x2021617997_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
Clo g_std_2ecli_2ewordsF_24s1352288509x2021617997_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry, 2, 0};

V g_std_2ecli_2ewordsF_24s1352288509x2021617997(V v_at_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(heff_dup(v_at_240), LBL_ps)));
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get(v_at_240, LBL_fs)));
    return heff_tag(TAG_Right, 1, (V[]){heff_rec(2, shape_pos__flags, (V[]){v_t_242, v_t_243})});
  }
  case TAG_Cons: {
    V v_w_244 = heff_field(v_x3_241, 0);
    V v_ws_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246 = heff_get(heff_dup(v_at_240), LBL_on);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      if (heff_intLe_c(MK_INT(0LL), heff_get(heff_dup(v_at_240), LBL_ra))) {
        V v_a_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get(heff_dup(v_at_240), LBL_ps); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        v_t_249 = heff_intLe(heff_get(heff_dup(v_at_240), LBL_ra), v_a_248);
      } else {
        v_t_249 = NTAG(TAG_False);
      }
      break;
    }
    case TAG_False: {
      v_t_249 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_at_2410 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), NTAG(TAG_False), heff_get(heff_dup(v_at_240), LBL_ps), heff_get(v_at_240, LBL_fs)});
      V v_t_2411 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_w_244, heff_get(heff_dup(v_at_2410), LBL_ps)});
      V v_t_2412 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_2410), LBL_sh), heff_get(heff_dup(v_at_2410), LBL_ra), heff_get(heff_dup(v_at_2410), LBL_on), v_t_2411, heff_get(v_at_2410, LBL_fs)});
      V t_0 = v_t_2412;
      V t_1 = v_ws_245;
      v_at_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    case TAG_False: {
      if (heff_strEq_c(heff_dup(v_w_244), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str0))) {
        heff_drop(v_w_244);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        V v_t_2414 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), NTAG(TAG_False), heff_get(heff_dup(v_at_240), LBL_ps), heff_get(v_at_240, LBL_fs)});
        V t_0 = v_t_2414;
        V t_1 = v_ws_245;
        v_at_240 = t_0;
        v_x3_241 = t_1;
        goto top;
      } else {
        V v_t_2416;
        if (heff_strEq_c(heff_dup(v_w_244), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str1))) {
          v_t_2416 = NTAG(TAG_True);
        } else {
          v_t_2416 = heff_strEq(heff_dup(v_w_244), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str2));
        }
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          heff_drop(v_at_240);
          heff_drop(v_w_244);
          heff_drop(v_ws_245);
          heff_drop_cell(v_ru_24x3_241_24Cons, 2);
          return heff_tag(TAG_Left, 1, (V[]){NTAG(TAG_Help)});
        }
        case TAG_False: {
          if (heff_strEq_c(heff_strSlice(heff_dup(v_w_244), MK_INT(0LL), MK_INT(2LL)), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_str3))) {
            heff_drop_cell(v_ru_24x3_241_24Cons, 2);
            V v_t_2418 = heff_strSlice(heff_dup(v_w_244), MK_INT(2LL), heff_strLength(v_w_244));
            return (g_std_2ecli_2elongF_24s1119688962x564470218(v_at_240, v_ws_245, v_t_2418));
          } else {
            if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_w_244)))) {
              if (heff_intEq_c(heff_strCharCode(heff_dup(v_w_244), MK_INT(0LL)), MK_INT(45LL))) {
                heff_drop_cell(v_ru_24x3_241_24Cons, 2);
                V v_t_2421 = heff_strSlice(heff_dup(v_w_244), MK_INT(1LL), heff_strLength(v_w_244));
                return (g_std_2ecli_2eshortF_24s1014269042x1715098139(v_at_240, v_ws_245, v_t_2421));
              } else {
                V v_t_2422 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_w_244, heff_get(heff_dup(v_at_240), LBL_ps)});
                V v_t_2423 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), v_t_2422, heff_get(v_at_240, LBL_fs)});
                V t_0 = v_t_2423;
                V t_1 = v_ws_245;
                v_at_240 = t_0;
                v_x3_241 = t_1;
                goto top;
              }
            } else {
              V v_t_2424 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_w_244, heff_get(heff_dup(v_at_240), LBL_ps)});
              V v_t_2425 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){heff_get(heff_dup(v_at_240), LBL_sh), heff_get(heff_dup(v_at_240), LBL_ra), heff_get(heff_dup(v_at_240), LBL_on), v_t_2424, heff_get(v_at_240, LBL_fs)});
              V t_0 = v_t_2425;
              V t_1 = v_ws_245;
              v_at_240 = t_0;
              v_x3_241 = t_1;
              goto top;
            }
          }
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_std_2ecli_2ewordsF_24s1352288509x2021617997_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ewordsF_24s1352288509x2021617997(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagProblem_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagProblem_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagProblem_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagProblem_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagProblem_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
V g_std_2ecli_2eflagProblem_lam0(V self, V *args);
V g_std_2ecli_2eflagProblem_lam1(V self, V *args);
V g_std_2ecli_2eflagProblem_lam2(V self, V *args);
Clo g_std_2ecli_2eflagProblem_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagProblem_entry, 2, 0};

V g_std_2ecli_2eflagProblem(V v_fs_240, V v_f_241) {
top: ;
  V v_t_246 = (g_list_2efilter(heff_clo(g_std_2ecli_2eflagProblem_lam0, 1, 1, (V[]){heff_dup(v_f_241)}), heff_dup(v_fs_240)));
  V v_x1_247 = (g_list_2emap_24s1173914895x100384474(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = heff_get(heff_dup(v_f_241), LBL_required);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_247, 0ULL, 2);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_fs_240);
    V v_t_2412;
    if (heff_strEq_c(heff_get(heff_dup(v_f_241), LBL_meta), ((V)&g_std_2ecli_2eflagProblem_str0))) {
      v_t_2412 = ((V)&g_std_2ecli_2eflagProblem_str1);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str2), heff_get(heff_dup(v_f_241), LBL_meta));
    }
    V v_t_2413 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str3), heff_strAppend(heff_get(v_f_241, LBL_long), v_t_2412));
    return heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MissingFlag, 1, (V[]){v_t_2413})});
  }
  case TAG_False: {
    V v_t_2418 = (g_list_2efilter(heff_clo(g_std_2ecli_2eflagProblem_lam1, 1, 1, (V[]){heff_dup(v_f_241)}), v_fs_240));
    V v_t_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
    V v_t_2427 = ({ V a_0 = heff_clo(g_std_2ecli_2eflagProblem_lam2, 1, 1, (V[]){heff_dup(v_f_241)}); V a_1 = v_t_2419; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_2419); r_; });
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      heff_drop(v_f_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_2428 = heff_field(v_t_2427, 0);
      V v_ru_24t_2427_24Just = heff_take_reuse_n(v_t_2427, 1ULL, 1);
      V v_t_2429 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_str4), heff_get(heff_dup(v_f_241), LBL_long));
      V v_t_2430 = heff_tag(TAG_NotIn, 3, (V[]){v_t_2429, v_v_2428, heff_get(v_f_241, LBL_values)});
      return heff_tag_at(v_ru_24t_2427_24Just, TAG_Just, 1, (V[]){v_t_2430});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_std_2ecli_2eflagProblem_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagProblem(a[0], a[1]);
}
V g_std_2ecli_2eflagProblem_lam0(V self, V *args) {
  V v_p_242 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245;
  switch (heff_tag_of(v_p_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_p_242, 0);
    heff_take_n(v_p_242, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_p_242);
  }
  return heff_strEq(v_t_245, heff_get(v_f_241, LBL_long));
}
V g_std_2ecli_2eflagProblem_lam1(V self, V *args) {
  V v_p_2414 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_p_2414, 0);
    heff_take_n(v_p_2414, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  return heff_strEq(v_t_2417, heff_get(v_f_241, LBL_long));
}
V g_std_2ecli_2eflagProblem_lam2(V self, V *args) {
  V v_v_2420 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_get(heff_dup(v_f_241), LBL_values);
  V v_x1_2424;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nil: {
    v_x1_2424 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2421, 0ULL, 2);
    v_x1_2424 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_True: {
    heff_drop(v_v_2420);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    V v_t_2425 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_v_2420}));
    V v_x1_2426 = ({ V a_0 = v_t_2425; V b_1 = heff_get(v_f_241, LBL_values); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2426)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2426);
    }
  }
  default: return heff_nomatch(v_x1_2424);
  }
}
Clo g_std_2ecli_2efirstJust_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2efirstJust_entry, 2, 0};

V g_std_2ecli_2efirstJust(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_g_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V t_0 = v_g_240;
      V t_1 = v_xs_243;
      v_g_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_y_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_y_245});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2efirstJust_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2efirstJust(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2egroupsGo_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 46, 46}};
Clo g_std_2ecli_2egroupsGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2egroupsGo_entry, 2, 0};

V g_std_2ecli_2egroupsGo(V v_x1_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_ws_241)) {
    case TAG_Nil: {
      return heff_tag(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_w_242 = heff_field(v_ws_241, 0);
      heff_take_n(v_ws_241, 1ULL, 2);
      return heff_tag(TAG_Left, 1, (V[]){heff_tag(TAG_Extra, 1, (V[]){v_w_242})});
    }
    default: return heff_nomatch(v_ws_241);
    }
  }
  case TAG_Cons: {
    V v_p_244 = heff_field(v_x1_240, 0);
    V v_ps_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_get(heff_dup(v_p_244), LBL_arity);
    switch (heff_tag_of(v_t_246)) {
    case TAG_One: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_t_247 = heff_tag(TAG_Missing, 1, (V[]){heff_get(v_p_244, LBL_meta)});
        return heff_tag(TAG_Left, 1, (V[]){v_t_247});
      }
      case TAG_Cons: {
        V v_w_248 = heff_field(v_ws_241, 0);
        V v_ws2_249 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        heff_drop(v_p_244);
        V v_x2_2410 = (g_std_2ecli_2egroupsGo(v_ps_245, v_ws2_249));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Left: {
          V v_p_2411 = heff_field(v_x2_2410, 0);
          V v_ru_24x2_2410_24Left = heff_take_reuse_n(v_x2_2410, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_w_248);
          heff_drop_cell(v_ru_24ws_241_24Cons, 2);
          return heff_tag_at(v_ru_24x2_2410_24Left, TAG_Left, 1, (V[]){v_p_2411});
        }
        case TAG_Right: {
          V v_gs_2412 = heff_field(v_x2_2410, 0);
          V v_ru_24x2_2410_24Right = heff_take_reuse_n(v_x2_2410, 1ULL, 1);
          V v_t_2413 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_248, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x2_2410_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_gs_2412})});
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      default: return heff_nomatch(v_ws_241);
      }
    }
    case TAG_Optional: {
      heff_drop(v_p_244);
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        V v_x2_2414 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_Left: {
          V v_p_2415 = heff_field(v_x2_2414, 0);
          V v_ru_24x2_2414_24Left = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          return heff_tag_at(v_ru_24x2_2414_24Left, TAG_Left, 1, (V[]){v_p_2415});
        }
        case TAG_Right: {
          V v_gs_2416 = heff_field(v_x2_2414, 0);
          V v_ru_24x2_2414_24Right = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
          V v_t_2417 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_gs_2416});
          return heff_tag_at(v_ru_24x2_2414_24Right, TAG_Right, 1, (V[]){v_t_2417});
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      case TAG_Cons: {
        V v_w_2418 = heff_field(v_ws_241, 0);
        V v_ws2_2419 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        V v_x2_2420 = (g_std_2ecli_2egroupsGo(v_ps_245, v_ws2_2419));
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Left: {
          V v_p_2421 = heff_field(v_x2_2420, 0);
          V v_ru_24x2_2420_24Left = heff_take_reuse_n(v_x2_2420, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_w_2418);
          heff_drop_cell(v_ru_24ws_241_24Cons, 2);
          return heff_tag_at(v_ru_24x2_2420_24Left, TAG_Left, 1, (V[]){v_p_2421});
        }
        case TAG_Right: {
          V v_gs_2422 = heff_field(v_x2_2420, 0);
          V v_ru_24x2_2420_24Right = heff_take_reuse_n(v_x2_2420, 1ULL, 1);
          V v_t_2423 = heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_2418, NTAG(TAG_Nil)});
          return heff_tag_at(v_ru_24x2_2420_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_gs_2422})});
        }
        default: return heff_nomatch(v_x2_2420);
        }
      }
      default: return heff_nomatch(v_ws_241);
      }
    }
    case TAG_Many: {
      heff_drop(v_p_244);
      V v_x2_2424 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_Left: {
        V v_p_2425 = heff_field(v_x2_2424, 0);
        V v_ru_24x2_2424_24Left = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
        heff_drop(v_ws_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_tag_at(v_ru_24x2_2424_24Left, TAG_Left, 1, (V[]){v_p_2425});
      }
      case TAG_Right: {
        V v_gs_2426 = heff_field(v_x2_2424, 0);
        V v_ru_24x2_2424_24Right = heff_take_reuse_n(v_x2_2424, 1ULL, 1);
        return heff_tag_at(v_ru_24x2_2424_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2426})});
      }
      default: return heff_nomatch(v_x2_2424);
      }
    }
    case TAG_Some: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_t_2427 = heff_strAppend(heff_get(v_p_244, LBL_meta), ((V)&g_std_2ecli_2egroupsGo_str0));
        return heff_tag(TAG_Left, 1, (V[]){heff_tag(TAG_Missing, 1, (V[]){v_t_2427})});
      }
      case TAG_Cons: {
        heff_drop(v_p_244);
        V v_x2_2430 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x2_2430)) {
        case TAG_Left: {
          V v_p_2431 = heff_field(v_x2_2430, 0);
          V v_ru_24x2_2430_24Left = heff_take_reuse_n(v_x2_2430, 1ULL, 1);
          heff_drop_tag(v_ws_241, 2);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          return heff_tag_at(v_ru_24x2_2430_24Left, TAG_Left, 1, (V[]){v_p_2431});
        }
        case TAG_Right: {
          V v_gs_2432 = heff_field(v_x2_2430, 0);
          V v_ru_24x2_2430_24Right = heff_take_reuse_n(v_x2_2430, 1ULL, 1);
          return heff_tag_at(v_ru_24x2_2430_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2432})});
        }
        default: return heff_nomatch(v_x2_2430);
        }
      }
      default: return heff_nomatch(v_ws_241);
      }
    }
    case TAG_Rest: {
      heff_drop(v_p_244);
      V v_x2_2433 = (g_std_2ecli_2egroupsGo(v_ps_245, NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Left: {
        V v_p_2434 = heff_field(v_x2_2433, 0);
        V v_ru_24x2_2433_24Left = heff_take_reuse_n(v_x2_2433, 1ULL, 1);
        heff_drop(v_ws_241);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_tag_at(v_ru_24x2_2433_24Left, TAG_Left, 1, (V[]){v_p_2434});
      }
      case TAG_Right: {
        V v_gs_2435 = heff_field(v_x2_2433, 0);
        V v_ru_24x2_2433_24Right = heff_take_reuse_n(v_x2_2433, 1ULL, 1);
        return heff_tag_at(v_ru_24x2_2433_24Right, TAG_Right, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2435})});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2egroupsGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2egroupsGo(a[0], a[1]);
}
V g_std_2ecli_2eparse_lam1(V self, V *args);
V g_std_2ecli_2eparse_lam0(V self, V *args);
Clo g_std_2ecli_2eparse_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eparse_entry, 2, 0};

V g_std_2ecli_2eparse(V v_t_240, V v_ws_241) {
top: ;
  V v_t_242 = heff_tr(heff_apply(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_t_243 = (g_std_2ecli_2eshapeProblem(heff_get(v_t_242, LBL_shape)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_245 = heff_get(v_t_244, LBL_shape);
    V v_t_246 = ({ V b_0 = heff_get(heff_dup(v_sh_245), LBL_pos); V a_1 = MK_INT(0LL); V r_ = (g_std_2ecli_2erestIndex(b_0, a_1)); heff_drop(b_0); r_; });
    V v_at_247 = heff_rec(5, shape_sh__ra__on__ps__fs, (V[]){v_sh_245, v_t_246, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997(v_at_247, v_ws_241));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Left = heff_take_reuse_n(v_t_248, 1ULL, 1);
      heff_drop(v_t_240);
      return heff_tag_at(v_ru_24t_248_24Left, TAG_Left, 1, (V[]){v_p_249});
    }
    case TAG_Right: {
      V v_sp_2410 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Right = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2411 = heff_tr(heff_apply(((V)&g_std_2ecli_2eflagProblem_clo), 1, (V[]){heff_get(heff_dup(v_sp_2410), LBL_flags)}));
      V v_t_2412 = heff_tr(heff_apply(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
      V v_t_2413 = heff_get(heff_get(v_t_2412, LBL_shape), LBL_flags);
      V v_t_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_std_2ecli_2efirstJust(a_0, a_1)); heff_drop(v_t_2413); r_; });
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        V v_t_2415 = heff_tr(heff_apply(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
        V v_t_2416 = heff_get(heff_get(v_t_2415, LBL_shape), LBL_pos);
        V v_t_2417 = (g_std_2ecli_2egroupsGo(v_t_2416, heff_get(heff_dup(v_sp_2410), LBL_pos)));
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Left: {
          V v_p_2418 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          heff_drop(v_t_240);
          heff_drop(v_sp_2410);
          return heff_tag_at(v_ru_24t_248_24Right, TAG_Left, 1, (V[]){v_p_2418});
        }
        case TAG_Right: {
          V v_gs_2419 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          V v_t_2420 = heff_tr(heff_apply(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2421 = heff_tr(heff_apply(v_t_240, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2422 = heff_get(heff_get(v_t_2421, LBL_shape), LBL_flags);
          V v_t_2429 = (g_list_2emap(heff_clo(g_std_2ecli_2eparse_lam0, 1, 1, (V[]){v_sp_2410}), v_t_2422));
          V v_t_2430 = heff_tr(heff_apply(heff_get(v_t_2420, LBL_take), 2, (V[]){v_gs_2419, v_t_2429}));
          return heff_tag_at(v_ru_24t_248_24Right, TAG_Right, 1, (V[]){v_t_2430});
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      case TAG_Just: {
        V v_p_2431 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        heff_drop(v_t_240);
        heff_drop(v_sp_2410);
        return heff_tag_at(v_ru_24t_248_24Right, TAG_Left, 1, (V[]){v_p_2431});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_Just: {
    V v_why_2432 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_t_240);
    heff_drop(v_ws_241);
    return heff_tag_at(v_ru_24t_243_24Just, TAG_Left, 1, (V[]){heff_tag(TAG_BadShape, 1, (V[]){v_why_2432})});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2eparse_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eparse(a[0], a[1]);
}
V g_std_2ecli_2eparse_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_f_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427;
  switch (heff_tag_of(v_p_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_p_2424, 0);
    heff_take_n(v_p_2424, 1ULL, 2);
    v_t_2427 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_p_2424);
  }
  return heff_strEq(v_t_2427, heff_get(v_f_2423, LBL_long));
}
V g_std_2ecli_2eparse_lam0(V self, V *args) {
  V v_f_2423 = args[0];
  V v_sp_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_list_2efilter(heff_clo(g_std_2ecli_2eparse_lam1, 1, 1, (V[]){heff_dup(v_f_2423)}), heff_get(v_sp_2410, LBL_flags)));
  return heff_tag(TAG_MkPair, 2, (V[]){heff_get(v_f_2423, LBL_long), (g_list_2emap_24s1173914895x100384474(v_t_2428))});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortWhere_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortWhere_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eshortWhere_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_std_2ecli_2eshortWhere_lam0(V self, V *args);
Clo g_std_2ecli_2eshortWhere_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortWhere_entry, 3, 0};

V g_std_2ecli_2eshortWhere(V v_sh_240, V v_st_241, V v_cl_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_cl_242), ((V)&g_std_2ecli_2eshortWhere_str0))) {
    heff_drop(v_sh_240);
    heff_drop(v_cl_242);
    return v_st_241;
  } else {
    V v_x_244 = heff_strSlice(heff_dup(v_cl_242), MK_INT(0LL), MK_INT(1LL));
    V v_t_247;
    if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_std_2ecli_2eshortWhere_str1))) {
      heff_drop(v_x_244);
      v_t_247 = NTAG(TAG_Nothing);
    } else {
      v_t_247 = ({ V a_0 = heff_clo(g_std_2ecli_2eshortWhere_lam0, 1, 1, (V[]){v_x_244}); V b_1 = heff_get(heff_dup(v_sh_240), LBL_flags); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_sh_240);
      heff_drop(v_cl_242);
      return v_st_241;
    }
    case TAG_Just: {
      V v_f_248 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
      if (heff_strEq_c(heff_get(heff_dup(v_f_248), LBL_meta), ((V)&g_std_2ecli_2eshortWhere_str2))) {
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_f_248, LBL_long), heff_get(heff_dup(v_st_241), LBL_given)});
        V v_t_2411 = heff_rec(4, shape_on__waiting__count__given, (V[]){heff_get(heff_dup(v_st_241), LBL_on), NTAG(TAG_Nothing), heff_get(v_st_241, LBL_count), v_t_2410});
        V v_t_2412 = heff_strSlice(heff_dup(v_cl_242), MK_INT(1LL), heff_strLength(v_cl_242));
        V t_0 = v_sh_240;
        V t_1 = v_t_2411;
        V t_2 = v_t_2412;
        v_sh_240 = t_0;
        v_st_241 = t_1;
        v_cl_242 = t_2;
        goto top;
      } else {
        heff_drop(v_sh_240);
        V v_t_2414;
        if (heff_intLt_c(MK_INT(1LL), heff_strLength(v_cl_242))) {
          heff_drop_cell(v_ru_24t_247_24Just, 1);
          v_t_2414 = NTAG(TAG_Nothing);
        } else {
          v_t_2414 = heff_tag_at(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){heff_dup(v_f_248)});
        }
        V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_f_248, LBL_long), heff_get(heff_dup(v_st_241), LBL_given)});
        return heff_rec(4, shape_on__waiting__count__given, (V[]){heff_get(heff_dup(v_st_241), LBL_on), v_t_2414, heff_get(v_st_241, LBL_count), v_t_2415});
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_std_2ecli_2eshortWhere_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eshortWhere(a[0], a[1], a[2]);
}
V g_std_2ecli_2eshortWhere_lam0(V self, V *args) {
  V v_f_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_f_246, LBL_short), v_x_244);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ewhereGo_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ewhereGo_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ewhereGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ewhereGo_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ewhereGo_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2ecli_2ewhereGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ewhereGo_entry, 4, 0};

V g_std_2ecli_2ewhereGo(V v_sh_240, V v_ra_241, V v_st_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sh_240);
    heff_drop(v_ra_241);
    return v_st_242;
  }
  case TAG_Cons: {
    V v_w_244 = heff_field(v_x4_243, 0);
    V v_ws_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_get(heff_dup(v_st_242), LBL_waiting);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_t_247 = heff_get(heff_dup(v_st_242), LBL_on);
      V v_t_249;
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        if (heff_intLe_c(MK_INT(0LL), heff_dup(v_ra_241))) {
          v_t_249 = heff_intLe(heff_dup(v_ra_241), heff_get(heff_dup(v_st_242), LBL_count));
        } else {
          v_t_249 = NTAG(TAG_False);
        }
        break;
      }
      case TAG_False: {
        v_t_249 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        heff_drop(v_w_244);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_st_242), LBL_count), MK_INT(1LL));
        V v_t_2411 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_False), NTAG(TAG_Nothing), v_t_2410, heff_get(v_st_242, LBL_given)});
        V t_0 = v_sh_240;
        V t_1 = v_ra_241;
        V t_2 = v_t_2411;
        V t_3 = v_ws_245;
        v_sh_240 = t_0;
        v_ra_241 = t_1;
        v_st_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_False: {
        if (heff_strEq_c(heff_dup(v_w_244), ((V)&g_std_2ecli_2ewhereGo_str0))) {
          heff_drop(v_w_244);
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          V v_t_2413 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_False), NTAG(TAG_Nothing), heff_get(heff_dup(v_st_242), LBL_count), heff_get(v_st_242, LBL_given)});
          V t_0 = v_sh_240;
          V t_1 = v_ra_241;
          V t_2 = v_t_2413;
          V t_3 = v_ws_245;
          v_sh_240 = t_0;
          v_ra_241 = t_1;
          v_st_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        } else {
          if (heff_strEq_c(heff_strSlice(heff_dup(v_w_244), MK_INT(0LL), MK_INT(2LL)), ((V)&g_std_2ecli_2ewhereGo_str1))) {
            V v_t_2415 = heff_strSlice(heff_dup(v_w_244), MK_INT(2LL), heff_strLength(heff_dup(v_w_244)));
            V v_t_2416 = (g_std_2ecli_2elongNamed(heff_dup(v_sh_240), v_t_2415));
            V v_t_2419;
            switch (heff_tag_of(v_t_2416)) {
            case TAG_Left: {
              heff_take_n(v_t_2416, 0ULL, 1);
              v_t_2419 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Right: {
              V v_f_2418 = heff_field(v_t_2416, 0);
              V v_ru_24t_2416_24Right = heff_take_reuse_n(v_t_2416, 1ULL, 1);
              v_t_2419 = heff_tag_at(v_ru_24t_2416_24Right, TAG_Just, 1, (V[]){v_f_2418});
              break;
            }
            default: heff_nomatch(v_t_2416);
            }
            switch (heff_tag_of(v_t_2419)) {
            case TAG_Nothing: {
              V v_t_2420 = (g_prelude_2eindexFrom(((V)&g_std_2ecli_2ewhereGo_str2), heff_dup(v_w_244), MK_INT(0LL)));
              switch (heff_tag_of(v_t_2420)) {
              case TAG_Nothing: {
                heff_drop(v_w_244);
                heff_drop_cell(v_ru_24x4_243_24Cons, 2);
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_st_242;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
              case TAG_Just: {
                V v_i_2421 = heff_field(v_t_2420, 0);
                heff_take_n(v_t_2420, 1ULL, 1);
                V v_t_2422 = (g_std_2ecli_2elongNamed(heff_dup(v_sh_240), heff_strSlice(v_w_244, MK_INT(2LL), v_i_2421)));
                V v_t_2425;
                switch (heff_tag_of(v_t_2422)) {
                case TAG_Left: {
                  heff_take_n(v_t_2422, 0ULL, 1);
                  v_t_2425 = ((V)&g_std_2ecli_2ewhereGo_str3);
                  break;
                }
                case TAG_Right: {
                  V v_f_2424 = heff_field(v_t_2422, 0);
                  heff_take_n(v_t_2422, 1ULL, 1);
                  v_t_2425 = heff_get(v_f_2424, LBL_long);
                  break;
                }
                default: heff_nomatch(v_t_2422);
                }
                V v_t_2426 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_get(heff_dup(v_st_242), LBL_given)});
                V v_t_2427 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), heff_get(v_st_242, LBL_count), v_t_2426});
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2427;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
              default: return heff_nomatch(v_t_2420);
              }
            }
            case TAG_Just: {
              V v_f_2428 = heff_field(v_t_2419, 0);
              V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
              heff_drop(v_w_244);
              V v_t_2430;
              if (heff_strEq_c(heff_get(heff_dup(v_f_2428), LBL_meta), ((V)&g_std_2ecli_2ewhereGo_str4))) {
                heff_drop_cell(v_ru_24t_2419_24Just, 1);
                v_t_2430 = NTAG(TAG_Nothing);
              } else {
                v_t_2430 = heff_tag_at(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){heff_dup(v_f_2428)});
              }
              V v_t_2431 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_get(v_f_2428, LBL_long), heff_get(heff_dup(v_st_242), LBL_given)});
              V v_t_2432 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), v_t_2430, heff_get(v_st_242, LBL_count), v_t_2431});
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2432;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x4_243 = t_3;
              goto top;
            }
            default: return heff_nomatch(v_t_2419);
            }
          } else {
            heff_drop_cell(v_ru_24x4_243_24Cons, 2);
            if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_w_244)))) {
              if (heff_intEq_c(heff_strCharCode(heff_dup(v_w_244), MK_INT(0LL)), MK_INT(45LL))) {
                V v_t_2435 = heff_strSlice(heff_dup(v_w_244), MK_INT(1LL), heff_strLength(v_w_244));
                V v_t_2436 = (g_std_2ecli_2eshortWhere(heff_dup(v_sh_240), v_st_242, v_t_2435));
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2436;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              } else {
                heff_drop(v_w_244);
                V v_t_2437 = heff_intAdd(heff_get(heff_dup(v_st_242), LBL_count), MK_INT(1LL));
                V v_t_2438 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), v_t_2437, heff_get(v_st_242, LBL_given)});
                V t_0 = v_sh_240;
                V t_1 = v_ra_241;
                V t_2 = v_t_2438;
                V t_3 = v_ws_245;
                v_sh_240 = t_0;
                v_ra_241 = t_1;
                v_st_242 = t_2;
                v_x4_243 = t_3;
                goto top;
              }
            } else {
              heff_drop(v_w_244);
              V v_t_2439 = heff_intAdd(heff_get(heff_dup(v_st_242), LBL_count), MK_INT(1LL));
              V v_t_2440 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), v_t_2439, heff_get(v_st_242, LBL_given)});
              V t_0 = v_sh_240;
              V t_1 = v_ra_241;
              V t_2 = v_t_2440;
              V t_3 = v_ws_245;
              v_sh_240 = t_0;
              v_ra_241 = t_1;
              v_st_242 = t_2;
              v_x4_243 = t_3;
              goto top;
            }
          }
        }
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_w_244);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2442 = heff_rec(4, shape_on__waiting__count__given, (V[]){heff_get(heff_dup(v_st_242), LBL_on), NTAG(TAG_Nothing), heff_get(heff_dup(v_st_242), LBL_count), heff_get(v_st_242, LBL_given)});
      V t_0 = v_sh_240;
      V t_1 = v_ra_241;
      V t_2 = v_t_2442;
      V t_3 = v_ws_245;
      v_sh_240 = t_0;
      v_ra_241 = t_1;
      v_st_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2ecli_2ewhereGo_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ewhereGo(a[0], a[1], a[2], a[3]);
}
Clo g_std_2ecli_2eposAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eposAt_entry, 2, 0};

V g_std_2ecli_2eposAt(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_get(heff_dup(v_p_242), LBL_arity);
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Optional: {
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
      } else {
        V t_0 = v_ps_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
    case TAG_Many: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_Some: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_Rest: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eposAt_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2eposAt(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteAt_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteAt_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ecompleteAt_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ecompleteAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
V g_std_2ecli_2ecompleteAt_lam0(V self, V *args);
V g_std_2ecli_2ecompleteAt_lam1(V self, V *args);
V g_std_2ecli_2ecompleteAt_lam2(V self, V *args);
V g_std_2ecli_2ecompleteAt_lam3(V self, V *args);
V g_std_2ecli_2ecompleteAt_lam4(V self, V *args);
V g_std_2ecli_2ecompleteAt_lam5(V self, V *args);
V g_std_2ecli_2ecompleteAt_lam6(V self, V *args);
Clo g_std_2ecli_2ecompleteAt_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteAt_entry, 3, 0};

V g_std_2ecli_2ecompleteAt(V v_sh_240, V v_st_241, V v_cur_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_st_241), LBL_waiting);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_get(heff_dup(v_st_241), LBL_on);
    V v_t_249;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V v_a_245 = ({ V b_0 = heff_get(heff_dup(v_sh_240), LBL_pos); V a_1 = MK_INT(0LL); V r_ = (g_std_2ecli_2erestIndex(b_0, a_1)); heff_drop(b_0); r_; });
      V v_x1_248;
      if (heff_intLe_c(MK_INT(0LL), v_a_245)) {
        V v_b_247 = ({ V b_0 = heff_get(heff_dup(v_sh_240), LBL_pos); V a_1 = MK_INT(0LL); V r_ = (g_std_2ecli_2erestIndex(b_0, a_1)); heff_drop(b_0); r_; });
        v_x1_248 = heff_intLe(v_b_247, heff_get(heff_dup(v_st_241), LBL_count));
      } else {
        v_x1_248 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_x1_248)) {
      case TAG_True: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_249 = heff_strEq(heff_strSlice(heff_dup(v_cur_242), MK_INT(0LL), MK_INT(1LL)), ((V)&g_std_2ecli_2ecompleteAt_str0));
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      break;
    }
    case TAG_False: {
      v_t_249 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = (g_prelude_2eindexFrom(((V)&g_std_2ecli_2ecompleteAt_str1), heff_dup(v_cur_242), MK_INT(0LL)));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        V v_t_2415 = (g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteAt_lam0, 1, 1, (V[]){v_st_241}), heff_get(v_sh_240, LBL_flags)));
        V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ecompleteAt_str2), (g_list_2emap_24s791123004x231442264(((V)&g_std_2ecli_2ecompleteAt_str3), v_t_2415))});
        return heff_tag(TAG_Words, 1, (V[]){(g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteAt_lam1, 1, 1, (V[]){v_cur_242}), v_t_2416))});
      }
      case TAG_Just: {
        V v_i_2419 = heff_field(v_t_2410, 0);
        V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
        heff_drop(v_st_241);
        V v_t_2420 = (g_std_2ecli_2elongNamed(v_sh_240, heff_strSlice(heff_dup(v_cur_242), MK_INT(2LL), heff_dup(v_i_2419))));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Left: {
          heff_take_n(v_t_2420, 0ULL, 1);
          heff_drop(v_cur_242);
          heff_drop(v_i_2419);
          heff_drop_cell(v_ru_24t_2410_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Right: {
          V v_f_2422 = heff_field(v_t_2420, 0);
          heff_take_n(v_t_2420, 1ULL, 1);
          V v_t_2425 = (g_list_2emap(heff_clo(g_std_2ecli_2ecompleteAt_lam2, 1, 2, (V[]){heff_dup(v_cur_242), v_i_2419}), heff_get(v_f_2422, LBL_values)));
          return heff_tag_at(v_ru_24t_2410_24Just, TAG_Words, 1, (V[]){(g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteAt_lam3, 1, 1, (V[]){v_cur_242}), v_t_2425))});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    case TAG_False: {
      V v_t_2428 = ({ V b_0 = heff_get(v_sh_240, LBL_pos); V a_1 = heff_get(v_st_241, LBL_count); V r_ = (g_std_2ecli_2eposAt(b_0, a_1)); heff_drop(b_0); r_; });
      switch (heff_tag_of(v_t_2428)) {
      case TAG_Nothing: {
        heff_drop(v_cur_242);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_p_2429 = heff_field(v_t_2428, 0);
        V v_ru_24t_2428_24Just = heff_take_reuse_n(v_t_2428, 1ULL, 1);
        V v_t_2430 = heff_get(v_p_2429, LBL_complete);
        switch (heff_tag_of(v_t_2430)) {
        case TAG_None: {
          heff_drop(v_cur_242);
          heff_drop_cell(v_ru_24t_2428_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Files: {
          V v_sfx_2431 = heff_field(v_t_2430, 0);
          heff_take_n(v_t_2430, 1ULL, 1);
          heff_drop(v_cur_242);
          return heff_tag_at(v_ru_24t_2428_24Just, TAG_FilesBy, 1, (V[]){v_sfx_2431});
        }
        case TAG_Dirs: {
          heff_drop(v_cur_242);
          heff_drop_cell(v_ru_24t_2428_24Just, 1);
          return NTAG(TAG_DirsOnly);
        }
        case TAG_Among: {
          V v_ws_2432 = heff_field(v_t_2430, 0);
          heff_take_n(v_t_2430, 1ULL, 1);
          return heff_tag_at(v_ru_24t_2428_24Just, TAG_Words, 1, (V[]){(g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteAt_lam4, 1, 1, (V[]){v_cur_242}), v_ws_2432))});
        }
        default: return heff_nomatch(v_t_2430);
        }
      }
      default: return heff_nomatch(v_t_2428);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_Just: {
    V v_f_2435 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_sh_240);
    heff_drop(v_st_241);
    V v_t_2436 = heff_get(heff_dup(v_f_2435), LBL_values);
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nil: {
      V v_t_2437 = heff_get(v_f_2435, LBL_complete);
      switch (heff_tag_of(v_t_2437)) {
      case TAG_None: {
        heff_drop(v_cur_242);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Files: {
        V v_sfx_2438 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 1);
        heff_drop(v_cur_242);
        return heff_tag_at(v_ru_24t_243_24Just, TAG_FilesBy, 1, (V[]){v_sfx_2438});
      }
      case TAG_Dirs: {
        heff_drop(v_cur_242);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        return NTAG(TAG_DirsOnly);
      }
      case TAG_Among: {
        V v_ws_2439 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 1);
        return heff_tag_at(v_ru_24t_243_24Just, TAG_Words, 1, (V[]){(g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteAt_lam5, 1, 1, (V[]){v_cur_242}), v_ws_2439))});
      }
      default: return heff_nomatch(v_t_2437);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_t_2436, 0ULL, 2);
      return heff_tag_at(v_ru_24t_243_24Just, TAG_Words, 1, (V[]){(g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteAt_lam6, 1, 1, (V[]){v_cur_242}), heff_get(v_f_2435, LBL_values)))});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2ecompleteAt_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecompleteAt(a[0], a[1], a[2]);
}
V g_std_2ecli_2ecompleteAt_lam0(V self, V *args) {
  V v_f_2411 = args[0];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_get(heff_dup(v_f_2411), LBL_repeated);
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_f_2411);
    heff_drop(v_st_241);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_2413 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_get(v_f_2411, LBL_long)}));
    V v_x1_2414 = ({ V a_0 = v_t_2413; V b_1 = heff_get(v_st_241, LBL_given); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2414);
    }
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_std_2ecli_2ecompleteAt_lam1(V self, V *args) {
  V v_w_2417 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_strSlice(v_w_2417, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2418, v_cur_242);
}
V g_std_2ecli_2ecompleteAt_lam2(V self, V *args) {
  V v_v_2423 = args[0];
  V v_cur_242 = heff_env(self)[0];
  V v_i_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_strSlice(v_cur_242, MK_INT(0LL), heff_intAdd(v_i_2419, MK_INT(1LL)));
  return heff_strAppend(v_t_2424, v_v_2423);
}
V g_std_2ecli_2ecompleteAt_lam3(V self, V *args) {
  V v_w_2426 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_strSlice(v_w_2426, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2427, v_cur_242);
}
V g_std_2ecli_2ecompleteAt_lam4(V self, V *args) {
  V v_w_2433 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_strSlice(v_w_2433, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2434, v_cur_242);
}
V g_std_2ecli_2ecompleteAt_lam5(V self, V *args) {
  V v_w_2440 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_strSlice(v_w_2440, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2441, v_cur_242);
}
V g_std_2ecli_2ecompleteAt_lam6(V self, V *args) {
  V v_w_2444 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_strSlice(v_w_2444, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2445, v_cur_242);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagWord_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2eflagWord_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagWord_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagWord_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagWord_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2eflagWord_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {91, 45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagWord_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagWord_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
Clo g_std_2ecli_2eflagWord_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagWord_entry, 1, 0};

V g_std_2ecli_2eflagWord(V v_f_240) {
top: ;
  if (heff_strEq_c(heff_get(heff_dup(v_f_240), LBL_meta), ((V)&g_std_2ecli_2eflagWord_str0))) {
    return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str1), heff_strAppend(heff_get(v_f_240, LBL_long), ((V)&g_std_2ecli_2eflagWord_str2)));
  } else {
    V v_t_242 = heff_get(heff_dup(v_f_240), LBL_required);
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str3), heff_strAppend(heff_get(heff_dup(v_f_240), LBL_long), heff_strAppend(((V)&g_std_2ecli_2eflagWord_str4), heff_get(v_f_240, LBL_meta))));
    }
    case TAG_False: {
      return heff_strAppend(((V)&g_std_2ecli_2eflagWord_str5), heff_strAppend(heff_get(heff_dup(v_f_240), LBL_long), heff_strAppend(((V)&g_std_2ecli_2eflagWord_str6), heff_strAppend(heff_get(v_f_240, LBL_meta), ((V)&g_std_2ecli_2eflagWord_str7)))));
    }
    default: return heff_nomatch(v_t_242);
    }
  }
}
V g_std_2ecli_2eflagWord_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagWord(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eheadOf_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eheadOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eheadOf_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eheadOf_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eheadOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eheadOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_std_2ecli_2eheadOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eheadOf_entry, 1, 0};

V g_std_2ecli_2eheadOf(V v_k_240) {
top: ;
  V v_t_241 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_sh_242 = heff_get(v_t_241, LBL_shape);
  V v_t_243 = (g_list_2emap_24s2029999044x514618413(heff_get(heff_dup(v_sh_242), LBL_pos)));
  V v_t_244 = (g_list_2emap_24s1281445768x1036802655(heff_get(v_sh_242, LBL_flags)));
  V v_xs_245 = (g_prelude_2e_2b_2b(v_t_243, v_t_244));
  V v_t_248;
  switch (heff_tag_of(v_xs_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_std_2ecli_2eheadOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_245, 0);
    V v_xs_247 = heff_field(v_xs_245, 1);
    heff_take_n(v_xs_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_xs_245);
  }
  if (heff_strEq_c(v_t_248, ((V)&g_std_2ecli_2eheadOf_str2))) {
    return heff_get(v_k_240, LBL_name);
  } else {
    V v_t_2410 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_2411 = heff_get(v_t_2410, LBL_shape);
    V v_t_2412 = (g_list_2emap_24s2029999044x514618413(heff_get(heff_dup(v_sh_2411), LBL_pos)));
    V v_t_2413 = (g_list_2emap_24s1281445768x1036802655(heff_get(v_sh_2411, LBL_flags)));
    V v_xs_2414 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2413));
    V v_t_2417;
    switch (heff_tag_of(v_xs_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_std_2ecli_2eheadOf_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_xs_2414, 0);
      V v_xs_2416 = heff_field(v_xs_2414, 1);
      heff_take_n(v_xs_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str4); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_xs_2414);
    }
    return heff_strAppend(heff_get(v_k_240, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eheadOf_str5), v_t_2417));
  }
}
V g_std_2ecli_2eheadOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eheadOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eline2_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eline2_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eline2_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
Clo g_std_2ecli_2eline2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eline2_entry, 2, 0};

V g_std_2ecli_2eline2(V v_x_240, V v_doc_241) {
top: ;
  if (heff_intLt_c(MK_INT(26LL), heff_strLength(heff_dup(v_x_240)))) {
    V v_x2_243 = (g_list_2ereplicate(MK_INT(30LL), ((V)&g_std_2ecli_2eline2_str0)));
    V v_t_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_t_246 = ((V)&g_std_2ecli_2eline2_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_t_246 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    return heff_strAppend(((V)&g_std_2ecli_2eline2_str3), heff_strAppend(v_x_240, heff_strAppend(((V)&g_std_2ecli_2eline2_str4), heff_strAppend(v_t_246, v_doc_241))));
  } else {
    V v_t_247 = heff_intSub(MK_INT(28LL), heff_strLength(heff_dup(v_x_240)));
    V v_x2_248 = (g_list_2ereplicate(v_t_247, ((V)&g_std_2ecli_2eline2_str5)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_std_2ecli_2eline2_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str7); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(((V)&g_std_2ecli_2eline2_str8), heff_strAppend(v_x_240, heff_strAppend(v_t_2411, v_doc_241)));
  }
}
V g_std_2ecli_2eline2_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eline2(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_std_2ecli_2eusage_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_std_2ecli_2eusage_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 67, 79, 77, 77, 65, 78, 68, 32, 46, 46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eusage_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_std_2ecli_2eusage_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {104, 101, 108, 112, 32, 91, 67, 79, 77, 77, 65, 78, 68, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_std_2ecli_2eusage_str4 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 105, 115, 44, 32, 111, 114, 32, 97, 32, 99, 111, 109, 109, 97, 110, 100, 39, 115, 32, 102, 108, 97, 103, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_std_2ecli_2eusage_str5 = {{0x80000000u, K_STR, 0}, 17, 17, {99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115, 32, 83, 72, 69, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[48]; } g_std_2ecli_2eusage_str6 = {{0x80000000u, K_STR, 0}, 48, 48, {97, 32, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 32, 115, 99, 114, 105, 112, 116, 32, 102, 111, 114, 32, 83, 72, 69, 76, 76, 58, 32, 102, 105, 115, 104, 44, 32, 98, 97, 115, 104, 32, 111, 114, 32, 122, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eusage_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eusage_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eusage_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_std_2ecli_2eusage_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eusage_entry, 2, 0};

V g_std_2ecli_2eusage(V v_prog_240, V v_cs_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2eusage_str0), heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2eusage_str1)));
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eusage_str2), NTAG(TAG_Nil)});
  V v_t_244 = (g_list_2efilter_24s581973887x894775069(v_cs_241));
  V v_t_245 = (g_list_2emap_24s989117243x1797506341(v_t_244));
  V v_t_246 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str3), ((V)&g_std_2ecli_2eusage_str4)));
  V v_t_247 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str5), ((V)&g_std_2ecli_2eusage_str6)));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, heff_tag(TAG_Cons, 2, (V[]){v_t_246, v_t_248})));
  V v_x2_2410 = (g_prelude_2e_2b_2b(heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_243}), v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_std_2ecli_2eusage_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_t_2413 = ({ V a_0 = ((V)&g_std_2ecli_2eusage_str8); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_strAppend(v_t_2413, ((V)&g_std_2ecli_2eusage_str9));
}
V g_std_2ecli_2eusage_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eusage(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eflagLine_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagLine_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagLine_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagLine_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eflagLine_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eflagLine_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_std_2ecli_2eflagLine_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eflagLine_entry, 1, 0};

V g_std_2ecli_2eflagLine(V v_f_240) {
top: ;
  V v_t_242;
  if (heff_strEq_c(heff_get(heff_dup(v_f_240), LBL_short), ((V)&g_std_2ecli_2eflagLine_str0))) {
    v_t_242 = ((V)&g_std_2ecli_2eflagLine_str1);
  } else {
    v_t_242 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str2), heff_strAppend(heff_get(heff_dup(v_f_240), LBL_short), ((V)&g_std_2ecli_2eflagLine_str3)));
  }
  V v_t_244;
  if (heff_strEq_c(heff_get(heff_dup(v_f_240), LBL_meta), ((V)&g_std_2ecli_2eflagLine_str4))) {
    v_t_244 = ((V)&g_std_2ecli_2eflagLine_str5);
  } else {
    v_t_244 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str6), heff_get(heff_dup(v_f_240), LBL_meta));
  }
  V v_t_245 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_std_2ecli_2eflagLine_str7), heff_strAppend(heff_get(heff_dup(v_f_240), LBL_long), v_t_244)));
  V v_t_246 = heff_get(heff_dup(v_f_240), LBL_values);
  V v_t_2413;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    v_t_2413 = ((V)&g_std_2ecli_2eflagLine_str8);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    V v_t_249 = heff_get(heff_dup(v_f_240), LBL_values);
    V v_t_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_std_2ecli_2eflagLine_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_t_249, 0);
      V v_xs_2411 = heff_field(v_t_249, 1);
      heff_take_n(v_t_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2eflagLine_str10); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    v_t_2413 = heff_strAppend(((V)&g_std_2ecli_2eflagLine_str11), heff_strAppend(v_t_2412, ((V)&g_std_2ecli_2eflagLine_str12)));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2414 = heff_strAppend(heff_get(v_f_240, LBL_doc), v_t_2413);
  return (g_std_2ecli_2eline2(v_t_245, v_t_2414));
}
V g_std_2ecli_2eflagLine_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eflagLine(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_std_2ecli_2ehelpOf_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ehelpOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ehelpOf_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ehelpOf_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {102, 108, 97, 103, 115, 58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ehelpOf_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ehelpOf_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ehelpOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ehelpOf_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_std_2ecli_2ehelpOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ehelpOf_entry, 2, 0};

V g_std_2ecli_2ehelpOf(V v_prog_240, V v_k_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str0), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str1), (g_std_2ecli_2eheadOf(heff_dup(v_k_241))))));
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_k_241), LBL_doc), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str2), v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(v_k_241), LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_x1_246 = heff_get(heff_get(v_t_245, LBL_shape), LBL_flags);
  V v_t_2412;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ru_24x1_246_24Cons = heff_take_reuse_n(v_x1_246, 0ULL, 2);
    V v_t_249 = heff_tr(heff_apply(heff_get(v_k_241, LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_2410 = heff_get(heff_get(v_t_249, LBL_shape), LBL_flags);
    V v_t_2411 = heff_tag_at(v_ru_24x1_246_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str3), (g_list_2emap_24s1753874608x910016727(v_t_2410))});
    v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str4), v_t_2411});
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_x2_2413 = (g_prelude_2e_2b_2b(v_t_244, v_t_2412));
  V v_t_2416;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_std_2ecli_2ehelpOf_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_xs_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    v_t_2416 = ({ V a_0 = ((V)&g_std_2ecli_2ehelpOf_str6); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  return heff_strAppend(v_t_2416, ((V)&g_std_2ecli_2ehelpOf_str7));
}
V g_std_2ecli_2ehelpOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ehelpOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eorList_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eorList_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 111, 114, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eorList_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
Clo g_std_2ecli_2eorList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_entry, 1, 0};

V g_std_2ecli_2eorList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2eorList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_std_2ecli_2eorList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_std_2ecli_2eorList_str2), (g_std_2ecli_2eorList(v_x12_242))));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2eorList(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eproblemSaid_str0 = {{0x80000000u, K_STR, 0}, 8, 8, {110, 111, 32, 102, 108, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eproblemSaid_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {110, 111, 32, 102, 108, 97, 103, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eproblemSaid_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {59, 32, 45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eproblemSaid_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_std_2ecli_2eproblemSaid_str4 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 116, 97, 107, 101, 115, 32, 97, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_std_2ecli_2eproblemSaid_str5 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 116, 97, 107, 101, 115, 32, 110, 111, 32, 118, 97, 108, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eproblemSaid_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_std_2ecli_2eproblemSaid_str7 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 105, 115, 32, 116, 104, 101, 32, 115, 116, 97, 114, 116, 32, 111, 102, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_std_2ecli_2eproblemSaid_str8 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 105, 115, 32, 119, 97, 110, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eproblemSaid_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2eproblemSaid_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {44, 32, 110, 111, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_std_2ecli_2eproblemSaid_str11 = {{0x80000000u, K_STR, 0}, 9, 9, {101, 120, 112, 101, 99, 116, 101, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_std_2ecli_2eproblemSaid_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {116, 111, 111, 32, 109, 97, 110, 121, 32, 119, 111, 114, 100, 115, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eproblemSaid_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_std_2ecli_2eproblemSaid_str14 = {{0x80000000u, K_STR, 0}, 34, 34, {116, 104, 101, 32, 99, 111, 109, 109, 97, 110, 100, 32, 105, 115, 32, 100, 101, 115, 99, 114, 105, 98, 101, 100, 32, 119, 114, 111, 110, 103, 108, 121, 58, 32}};
Clo g_std_2ecli_2eproblemSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eproblemSaid_entry, 1, 0};

V g_std_2ecli_2eproblemSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Unknown: {
    V v_w_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nothing: {
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str0), heff_dup(v_w_241));
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x12_242, 0);
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str1), heff_strAppend(heff_dup(v_w_241), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str2), heff_strAppend(heff_dup(v_s_243), ((V)&g_std_2ecli_2eproblemSaid_str3)))));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_NoValue: {
    V v_w_244 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_244), ((V)&g_std_2ecli_2eproblemSaid_str4));
  }
  case TAG_SwitchValue: {
    V v_w_245 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_245), ((V)&g_std_2ecli_2eproblemSaid_str5));
  }
  case TAG_Ambiguous: {
    V v_w_246 = heff_field(v_x1_240, 0);
    V v_cands_247 = heff_field(v_x1_240, 1);
    V v_t_248 = (g_list_2emap_24s1367796012x2117543847(((V)&g_std_2ecli_2eproblemSaid_str6), heff_dup(v_cands_247)));
    return heff_strAppend(heff_dup(v_w_246), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str7), ({ V a_0 = v_t_248; V r_ = (g_std_2ecli_2eorList(a_0)); heff_drop(v_t_248); r_; })));
  }
  case TAG_MissingFlag: {
    V v_w_249 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_249), ((V)&g_std_2ecli_2eproblemSaid_str8));
  }
  case TAG_NotIn: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_v_2411 = heff_field(v_x1_240, 1);
    V v_vs_2412 = heff_field(v_x1_240, 2);
    V v_t_2413 = (g_std_2ecli_2eorList(v_vs_2412));
    return heff_strAppend(heff_dup(v_w_2410), heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str9), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str10), heff_dup(v_v_2411)))));
  }
  case TAG_Missing: {
    V v_m_2414 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str11), heff_dup(v_m_2414));
  }
  case TAG_Extra: {
    V v_w_2415 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str12), heff_dup(v_w_2415));
  }
  case TAG_Help: {
    return ((V)&g_std_2ecli_2eproblemSaid_str13);
  }
  case TAG_BadShape: {
    V v_why_2416 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str14), heff_dup(v_why_2416));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eproblemSaid_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2eproblemSaid(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2eshells_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {122, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eshells_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {102, 105, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2eshells_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 97, 115, 104}};

static V g_std_2ecli_2eshells_val;
static int g_std_2ecli_2eshells_st;
static V g_std_2ecli_2eshells_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str0), NTAG(TAG_Nil)});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eshells_str2), v_t_240})});
}
V g_std_2ecli_2eshells_get(void) {
  if (g_std_2ecli_2eshells_st == 2) return g_std_2ecli_2eshells_val;
  if (g_std_2ecli_2eshells_st == 1) heff_fail("defined by itself");
  g_std_2ecli_2eshells_st = 1;
  g_std_2ecli_2eshells_val = heff_tr(g_std_2ecli_2eshells_init());
  g_std_2ecli_2eshells_st = 2;
  return g_std_2ecli_2eshells_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ecandidatesText_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_std_2ecli_2ecandidatesText_str8 = {{0x80000000u, K_STR, 0}, 7, 7, {58, 102, 105, 108, 101, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ecandidatesText_str10 = {{0x80000000u, K_STR, 0}, 6, 6, {58, 100, 105, 114, 115, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecandidatesText_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_std_2ecli_2ecandidatesText_lam1(V self, V *args);
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args);
Clo g_std_2ecli_2ecandidatesText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecandidatesText_entry, 2, 0};

V g_std_2ecli_2ecandidatesText(V v_sh_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Words: {
    V v_ws_242 = heff_field(v_x2_241, 0);
    V v_x2_2412 = (g_list_2emap(heff_clo(g_std_2ecli_2ecandidatesText_lam0, 1, 1, (V[]){v_sh_240}), heff_dup(v_ws_242)));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      return ((V)&g_std_2ecli_2ecandidatesText_str6);
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return ({ V a_0 = ((V)&g_std_2ecli_2ecandidatesText_str7); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_FilesBy: {
    V v_sfx_2415 = heff_field(v_x2_241, 0);
    heff_drop(v_sh_240);
    return heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str8), heff_strAppend(heff_dup(v_sfx_2415), ((V)&g_std_2ecli_2ecandidatesText_str9)));
  }
  case TAG_DirsOnly: {
    heff_drop(v_sh_240);
    return ((V)&g_std_2ecli_2ecandidatesText_str10);
  }
  case TAG_Nothing: {
    heff_drop(v_sh_240);
    return ((V)&g_std_2ecli_2ecandidatesText_str11);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecandidatesText_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2ecandidatesText(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_std_2ecli_2ecandidatesText_lam1(V self, V *args) {
  V v_f_245 = args[0];
  V v_w_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_strSlice(heff_dup(v_w_243), MK_INT(2LL), heff_strLength(v_w_243));
  return heff_strEq(heff_get(v_f_245, LBL_long), v_t_246);
}
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args) {
  V v_w_243 = args[0];
  V v_sh_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_doc_249;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_w_243), MK_INT(0LL), MK_INT(2LL)), ((V)&g_std_2ecli_2ecandidatesText_str0))) {
    V v_t_247 = ({ V a_0 = heff_clo(g_std_2ecli_2ecandidatesText_lam1, 1, 1, (V[]){heff_dup(v_w_243)}); V b_1 = heff_get(v_sh_240, LBL_flags); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_doc_249 = ((V)&g_std_2ecli_2ecandidatesText_str1);
      break;
    }
    case TAG_Just: {
      V v_f_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_doc_249 = heff_get(v_f_248, LBL_doc);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
  } else {
    heff_drop(v_sh_240);
    v_doc_249 = ((V)&g_std_2ecli_2ecandidatesText_str2);
  }
  V v_t_2411;
  if (heff_strEq_c(heff_dup(v_doc_249), ((V)&g_std_2ecli_2ecandidatesText_str3))) {
    heff_drop(v_doc_249);
    v_t_2411 = v_w_243;
  } else {
    v_t_2411 = heff_strAppend(v_w_243, heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str4), v_doc_249));
  }
  return heff_strAppend(v_t_2411, ((V)&g_std_2ecli_2ecandidatesText_str5));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_std_2ecli_2ecommandsText_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[29]; } g_std_2ecli_2ecommandsText_str6 = {{0x80000000u, K_STR, 0}, 29, 29, {97, 32, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 32, 115, 99, 114, 105, 112, 116, 32, 102, 111, 114, 32, 83, 72, 69, 76, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ecommandsText_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_std_2ecli_2ecommandsText_str8 = {{0x80000000u, K_STR, 0}, 26, 26, {116, 104, 105, 115, 44, 32, 111, 114, 32, 97, 32, 99, 111, 109, 109, 97, 110, 100, 39, 115, 32, 102, 108, 97, 103, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {9}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecommandsText_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_std_2ecli_2ecommandsText_lam0(V self, V *args);
V g_std_2ecli_2ecommandsText_lam1(V self, V *args);
Clo g_std_2ecli_2ecommandsText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecommandsText_entry, 2, 0};

V g_std_2ecli_2ecommandsText(V v_cs_240, V v_cur_241) {
top: ;
  V v_xs_245 = (g_list_2efilter(heff_clo(g_std_2ecli_2ecommandsText_lam0, 1, 1, (V[]){heff_dup(v_cur_241)}), v_cs_240));
  V v_x2_246 = (g_list_2emap_24s1896835896x1330972393(((V)&g_std_2ecli_2ecommandsText_str0), ((V)&g_std_2ecli_2ecommandsText_str1), ((V)&g_std_2ecli_2ecommandsText_str2), v_xs_245));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_std_2ecli_2ecommandsText_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_std_2ecli_2ecommandsText_str4); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecommandsText_str5), ((V)&g_std_2ecli_2ecommandsText_str6)}), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecommandsText_str7), ((V)&g_std_2ecli_2ecommandsText_str8)}), v_t_2410});
  V v_xs_2417 = (g_list_2efilter(heff_clo(g_std_2ecli_2ecommandsText_lam1, 1, 1, (V[]){v_cur_241}), v_t_2411));
  V v_x2_2418 = (g_list_2emap_24s876522837x2005194065(((V)&g_std_2ecli_2ecommandsText_str9), ((V)&g_std_2ecli_2ecommandsText_str10), ((V)&g_std_2ecli_2ecommandsText_str11), v_xs_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_std_2ecli_2ecommandsText_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_std_2ecli_2ecommandsText_str13); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  return heff_strAppend(v_t_249, v_t_2421);
}
V g_std_2ecli_2ecommandsText_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ecommandsText(a[0], a[1]);
}
V g_std_2ecli_2ecommandsText_lam0(V self, V *args) {
  V v_k_242 = args[0];
  V v_cur_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = heff_get(heff_dup(v_k_242), LBL_shown);
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = heff_strSlice(heff_get(v_k_242, LBL_name), MK_INT(0LL), heff_strLength(heff_dup(v_cur_241)));
    return heff_strEq(v_t_244, v_cur_241);
  }
  case TAG_False: {
    heff_drop(v_k_242);
    heff_drop(v_cur_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2ecli_2ecommandsText_lam1(V self, V *args) {
  V v_p_2412 = args[0];
  V v_cur_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_w_2415;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_2412, 0);
    heff_take_n(v_p_2412, 1ULL, 2);
    v_w_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2416 = heff_strSlice(v_w_2415, MK_INT(0LL), heff_strLength(heff_dup(v_cur_241)));
  return heff_strEq(v_t_2416, v_cur_241);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ecompleteWords_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_std_2ecli_2ecompleteWords_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ecompleteWords_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_std_2ecli_2ecompleteWords_lam0(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam1(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam2(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam3(V self, V *args);
V g_std_2ecli_2ecompleteWords_lam4(V self, V *args);
Clo g_std_2ecli_2ecompleteWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteWords_entry, 3, 0};

V g_std_2ecli_2ecompleteWords(V v_cs_240, V v_x2_241, V v_cur_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_std_2ecli_2ecommandsText(v_cs_240, v_cur_242));
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x21_243), ((V)&g_std_2ecli_2ecompleteWords_str0))) {
      switch (heff_tag_of(v_x22_244)) {
      case TAG_Nil: {
        V v_t_246 = (g_list_2efilter_24s581973887x894775069(v_cs_240));
        V v_ws_247 = (g_list_2emap_24s1821466936x1723477761(v_t_246));
        V v_xs_2410 = (g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteWords_lam0, 1, 1, (V[]){v_cur_242}), v_ws_247));
        V v_x2_2411 = (g_list_2emap_24s1230413390x1744519585(((V)&g_std_2ecli_2ecompleteWords_str1), v_xs_2410));
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          return ((V)&g_std_2ecli_2ecompleteWords_str2);
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      case TAG_Cons: {
        V v_t_2417 = ({ V a_0 = heff_clo(g_std_2ecli_2ecompleteWords_lam1, 1, 1, (V[]){heff_dup(v_x21_243)}); V a_1 = v_cs_240; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_cs_240); r_; });
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Nothing: {
          heff_drop(v_cur_242);
          return ((V)&g_std_2ecli_2ecompleteWords_str4);
        }
        case TAG_Just: {
          V v_k_2418 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(v_k_2418), LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2420 = heff_tr(heff_apply(heff_get(v_k_2418, LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_sh_2421 = heff_get(v_t_2420, LBL_shape);
          V v_t_2422 = ({ V b_0 = heff_get(heff_dup(v_sh_2421), LBL_pos); V a_1 = MK_INT(0LL); V r_ = (g_std_2ecli_2erestIndex(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2423 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
          V v_t_2424 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2421), v_t_2422, v_t_2423, heff_dup(v_x22_244)));
          V v_t_2425 = (g_std_2ecli_2ecompleteAt(v_sh_2421, v_t_2424, v_cur_242));
          return ({ V a_0 = heff_get(v_t_2419, LBL_shape); V a_1 = v_t_2425; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2425); r_; });
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      default: return heff_nomatch(v_x22_244);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x21_243), ((V)&g_std_2ecli_2ecompleteWords_str5))) {
        switch (heff_tag_of(v_x22_244)) {
        case TAG_Nil: {
          heff_drop(v_cs_240);
          V v_xs_2429 = (g_list_2efilter(heff_clo(g_std_2ecli_2ecompleteWords_lam2, 1, 1, (V[]){v_cur_242}), heff_dup(g_std_2ecli_2eshells_get())));
          V v_x2_2430 = (g_list_2emap_24s1230413390x1744519585(((V)&g_std_2ecli_2ecompleteWords_str6), v_xs_2429));
          switch (heff_tag_of(v_x2_2430)) {
          case TAG_Nil: {
            return ((V)&g_std_2ecli_2ecompleteWords_str7);
          }
          case TAG_Cons: {
            V v_x_2431 = heff_field(v_x2_2430, 0);
            V v_xs_2432 = heff_field(v_x2_2430, 1);
            heff_take_n(v_x2_2430, 3ULL, 2);
            return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str8); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
          }
          default: return heff_nomatch(v_x2_2430);
          }
        }
        case TAG_Cons: {
          V v_t_2436 = ({ V a_0 = heff_clo(g_std_2ecli_2ecompleteWords_lam3, 1, 1, (V[]){heff_dup(v_x21_243)}); V a_1 = v_cs_240; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_cs_240); r_; });
          switch (heff_tag_of(v_t_2436)) {
          case TAG_Nothing: {
            heff_drop(v_cur_242);
            return ((V)&g_std_2ecli_2ecompleteWords_str9);
          }
          case TAG_Just: {
            V v_k_2437 = heff_field(v_t_2436, 0);
            heff_take_n(v_t_2436, 1ULL, 1);
            V v_t_2438 = heff_tr(heff_apply(heff_get(heff_dup(v_k_2437), LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2439 = heff_tr(heff_apply(heff_get(v_k_2437, LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2440 = heff_get(v_t_2439, LBL_shape);
            V v_t_2441 = ({ V b_0 = heff_get(heff_dup(v_sh_2440), LBL_pos); V a_1 = MK_INT(0LL); V r_ = (g_std_2ecli_2erestIndex(b_0, a_1)); heff_drop(b_0); r_; });
            V v_t_2442 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2443 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2440), v_t_2441, v_t_2442, heff_dup(v_x22_244)));
            V v_t_2444 = (g_std_2ecli_2ecompleteAt(v_sh_2440, v_t_2443, v_cur_242));
            return ({ V a_0 = heff_get(v_t_2438, LBL_shape); V a_1 = v_t_2444; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2444); r_; });
          }
          default: return heff_nomatch(v_t_2436);
          }
        }
        default: return heff_nomatch(v_x22_244);
        }
      } else {
        V v_t_2446 = ({ V a_0 = heff_clo(g_std_2ecli_2ecompleteWords_lam4, 1, 1, (V[]){heff_dup(v_x21_243)}); V a_1 = v_cs_240; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_cs_240); r_; });
        switch (heff_tag_of(v_t_2446)) {
        case TAG_Nothing: {
          heff_drop(v_cur_242);
          return ((V)&g_std_2ecli_2ecompleteWords_str10);
        }
        case TAG_Just: {
          V v_k_2447 = heff_field(v_t_2446, 0);
          heff_take_n(v_t_2446, 1ULL, 1);
          V v_t_2448 = heff_tr(heff_apply(heff_get(heff_dup(v_k_2447), LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2449 = heff_tr(heff_apply(heff_get(v_k_2447, LBL_args), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_sh_2450 = heff_get(v_t_2449, LBL_shape);
          V v_t_2451 = ({ V b_0 = heff_get(heff_dup(v_sh_2450), LBL_pos); V a_1 = MK_INT(0LL); V r_ = (g_std_2ecli_2erestIndex(b_0, a_1)); heff_drop(b_0); r_; });
          V v_t_2452 = heff_rec(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
          V v_t_2453 = (g_std_2ecli_2ewhereGo(heff_dup(v_sh_2450), v_t_2451, v_t_2452, heff_dup(v_x22_244)));
          V v_t_2454 = (g_std_2ecli_2ecompleteAt(v_sh_2450, v_t_2453, v_cur_242));
          return ({ V a_0 = heff_get(v_t_2448, LBL_shape); V a_1 = v_t_2454; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2454); r_; });
        }
        default: return heff_nomatch(v_t_2446);
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecompleteWords_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2ecompleteWords(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_std_2ecli_2ecompleteWords_lam0(V self, V *args) {
  V v_w_248 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_strSlice(v_w_248, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_249, v_cur_242);
}
V g_std_2ecli_2ecompleteWords_lam1(V self, V *args) {
  V v_k_2416 = args[0];
  V v_x21_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2416, LBL_name), v_x21_243);
}
V g_std_2ecli_2ecompleteWords_lam2(V self, V *args) {
  V v_w_2427 = args[0];
  V v_cur_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_strSlice(v_w_2427, MK_INT(0LL), heff_strLength(heff_dup(v_cur_242)));
  return heff_strEq(v_t_2428, v_cur_242);
}
V g_std_2ecli_2ecompleteWords_lam3(V self, V *args) {
  V v_k_2435 = args[0];
  V v_x21_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2435, LBL_name), v_x21_243);
}
V g_std_2ecli_2ecompleteWords_lam4(V self, V *args) {
  V v_k_2445 = args[0];
  V v_x21_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2445, LBL_name), v_x21_243);
}
Clo g_std_2ecli_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_entry, 1, 0};

V g_std_2ecli_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_std_2ecli_2einitOf(v_x12_242))});
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2elastOf_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2ecli_2elastOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOf_entry, 1, 0};

V g_std_2ecli_2elastOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2elastOf_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOf_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2elastOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2efishScript_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_std_2ecli_2efishScript_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {58, 32, 119, 114, 105, 116, 116, 101, 110, 32, 98, 121, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_std_2ecli_2efishScript_str2 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115, 32, 102, 105, 115, 104, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_std_2ecli_2efishScript_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {102, 117, 110, 99, 116, 105, 111, 110, 32, 95, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_std_2ecli_2efishScript_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {95, 99, 111, 109, 112, 108, 101, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_std_2ecli_2efishScript_str5 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 32, 32, 115, 101, 116, 32, 45, 108, 32, 111, 117, 116, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_std_2ecli_2efishScript_str6 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 99, 111, 109, 112, 108, 101, 116, 101, 32, 36, 119, 111, 114, 100, 115, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_std_2ecli_2efishScript_str7 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 111, 109, 112, 108, 101, 116, 101, 32, 45, 99, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2efishScript_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 45, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_std_2ecli_2efishScript_str9 = {{0x80000000u, K_STR, 0}, 12, 12, {99, 111, 109, 112, 108, 101, 116, 101, 32, 45, 99, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_std_2ecli_2efishScript_str10 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 45, 102, 32, 45, 97, 32, 39, 40, 95, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_std_2ecli_2efishScript_str11 = {{0x80000000u, K_STR, 0}, 11, 11, {95, 99, 111, 109, 112, 108, 101, 116, 101, 41, 39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2efishScript_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_std_2ecli_2efishScript_str13 = {{0x80000000u, K_STR, 0}, 30, 30, {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 112, 114, 105, 110, 116, 102, 32, 39, 37, 115, 92, 110, 39, 32, 36, 111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_std_2ecli_2efishScript_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 32, 32, 32, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[57]; } g_std_2ecli_2efishScript_str15 = {{0x80000000u, K_STR, 0}, 57, 57, {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 95, 95, 102, 105, 115, 104, 95, 99, 111, 109, 112, 108, 101, 116, 101, 95, 100, 105, 114, 101, 99, 116, 111, 114, 105, 101, 115, 32, 40, 99, 111, 109, 109, 97, 110, 100, 108, 105, 110, 101, 32, 45, 99, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_std_2ecli_2efishScript_str16 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 32, 32, 32, 32, 32, 32, 99, 97, 115, 101, 32, 39, 42, 39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_std_2ecli_2efishScript_str17 = {{0x80000000u, K_STR, 0}, 75, 75, {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 95, 95, 102, 105, 115, 104, 95, 99, 111, 109, 112, 108, 101, 116, 101, 95, 115, 117, 102, 102, 105, 120, 32, 40, 115, 116, 114, 105, 110, 103, 32, 114, 101, 112, 108, 97, 99, 101, 32, 39, 58, 102, 105, 108, 101, 115, 32, 39, 32, 39, 39, 32, 45, 45, 32, 36, 111, 117, 116, 91, 49, 93, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_std_2ecli_2efishScript_str18 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 32, 32, 32, 32, 32, 32, 32, 99, 97, 115, 101, 32, 39, 58, 100, 105, 114, 115, 39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_std_2ecli_2efishScript_str19 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 32, 32, 32, 115, 119, 105, 116, 99, 104, 32, 34, 36, 111, 117, 116, 91, 49, 93, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_std_2ecli_2efishScript_str20 = {{0x80000000u, K_STR, 0}, 23, 23, {32, 32, 32, 32, 32, 32, 32, 32, 99, 97, 115, 101, 32, 39, 58, 102, 105, 108, 101, 115, 32, 42, 39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_std_2ecli_2efishScript_str21 = {{0x80000000u, K_STR, 0}, 19, 19, {32, 32, 32, 32, 115, 101, 116, 32, 45, 101, 32, 119, 111, 114, 100, 115, 91, 49, 93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[53]; } g_std_2ecli_2efishScript_str22 = {{0x80000000u, K_STR, 0}, 53, 53, {32, 32, 32, 32, 115, 101, 116, 32, 45, 108, 32, 119, 111, 114, 100, 115, 32, 40, 99, 111, 109, 109, 97, 110, 100, 108, 105, 110, 101, 32, 45, 111, 112, 99, 41, 32, 40, 99, 111, 109, 109, 97, 110, 100, 108, 105, 110, 101, 32, 45, 99, 116, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2efishScript_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_std_2ecli_2efishScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2efishScript_entry, 1, 0};

V g_std_2ecli_2efishScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str0), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2efishScript_str1), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str2)))));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str4)));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str6)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str7), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2efishScript_str8)));
  V v_t_245 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str9), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2efishScript_str10), heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2efishScript_str11)))));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str12), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str13), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str14), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str15), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str16), v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str17), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str18), v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str19), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str20), v_t_2410})});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str21), heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_2411})});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str22), v_t_2412})});
  return ({ V a_0 = ((V)&g_std_2ecli_2efishScript_str23); V a_1 = v_t_241; V a_2 = v_t_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2413, 2); r_; });
}
V g_std_2ecli_2efishScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2efishScript(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ebashScript_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_std_2ecli_2ebashScript_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {58, 32, 119, 114, 105, 116, 116, 101, 110, 32, 98, 121, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[18]; } g_std_2ecli_2ebashScript_str2 = {{0x80000000u, K_STR, 0}, 18, 18, {32, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115, 32, 98, 97, 115, 104, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ebashScript_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ebashScript_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {40, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_std_2ecli_2ebashScript_str5 = {{0x80000000u, K_STR, 0}, 49, 49, {32, 32, 119, 104, 105, 108, 101, 32, 73, 70, 83, 61, 32, 114, 101, 97, 100, 32, 45, 114, 32, 119, 59, 32, 100, 111, 32, 111, 117, 116, 43, 61, 40, 34, 36, 119, 34, 41, 59, 32, 100, 111, 110, 101, 32, 60, 32, 60, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_std_2ecli_2ebashScript_str6 = {{0x80000000u, K_STR, 0}, 26, 26, {32, 99, 111, 109, 112, 108, 101, 116, 101, 32, 34, 36, 123, 119, 111, 114, 100, 115, 91, 64, 93, 58, 49, 125, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_std_2ecli_2ebashScript_str7 = {{0x80000000u, K_STR, 0}, 26, 26, {99, 111, 109, 112, 108, 101, 116, 101, 32, 45, 111, 32, 102, 105, 108, 101, 110, 97, 109, 101, 115, 32, 45, 70, 32, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ebashScript_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ebashScript_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 101, 115, 97, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ebashScript_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_std_2ecli_2ebashScript_str11 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 32, 32, 32, 32, 32, 32, 32, 67, 79, 77, 80, 82, 69, 80, 76, 89, 43, 61, 40, 34, 36, 119, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ebashScript_str12 = {{0x80000000u, K_STR, 0}, 13, 13, {32, 32, 32, 32, 32, 32, 100, 111, 110, 101, 32, 59, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_std_2ecli_2ebashScript_str13 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 32, 32, 32, 32, 32, 32, 32, 119, 61, 36, 123, 119, 37, 37, 36, 39, 92, 116, 39, 42, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[77]; } g_std_2ecli_2ebashScript_str14 = {{0x80000000u, K_STR, 0}, 77, 77, {32, 32, 32, 32, 32, 32, 32, 32, 105, 102, 32, 91, 91, 32, 36, 108, 97, 115, 116, 32, 61, 61, 32, 42, 61, 42, 32, 93, 93, 59, 32, 116, 104, 101, 110, 32, 119, 61, 36, 123, 119, 35, 42, 61, 125, 59, 32, 91, 91, 32, 36, 99, 117, 114, 32, 61, 61, 32, 61, 32, 93, 93, 32, 38, 38, 32, 119, 61, 34, 61, 36, 119, 34, 59, 32, 102, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ebashScript_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 32, 32, 42, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[30]; } g_std_2ecli_2ebashScript_str16 = {{0x80000000u, K_STR, 0}, 30, 30, {32, 32, 32, 32, 32, 32, 102, 111, 114, 32, 119, 32, 105, 110, 32, 34, 36, 123, 111, 117, 116, 91, 64, 93, 125, 34, 59, 32, 100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[103]; } g_std_2ecli_2ebashScript_str17 = {{0x80000000u, K_STR, 0}, 103, 103, {32, 32, 32, 32, 39, 58, 102, 105, 108, 101, 115, 32, 39, 42, 41, 32, 67, 79, 77, 80, 82, 69, 80, 76, 89, 61, 40, 36, 40, 99, 111, 109, 112, 103, 101, 110, 32, 45, 100, 32, 45, 45, 32, 34, 36, 99, 117, 114, 34, 41, 32, 36, 40, 99, 111, 109, 112, 103, 101, 110, 32, 45, 102, 32, 45, 88, 32, 34, 33, 42, 36, 123, 111, 117, 116, 91, 48, 93, 35, 58, 102, 105, 108, 101, 115, 32, 125, 34, 32, 45, 45, 32, 34, 36, 99, 117, 114, 34, 41, 41, 32, 59, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[51]; } g_std_2ecli_2ebashScript_str18 = {{0x80000000u, K_STR, 0}, 51, 51, {32, 32, 32, 32, 39, 58, 100, 105, 114, 115, 39, 41, 32, 67, 79, 77, 80, 82, 69, 80, 76, 89, 61, 40, 36, 40, 99, 111, 109, 112, 103, 101, 110, 32, 45, 100, 32, 45, 45, 32, 34, 36, 99, 117, 114, 34, 41, 41, 32, 59, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_std_2ecli_2ebashScript_str19 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 32, 67, 79, 77, 80, 82, 69, 80, 76, 89, 61, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_std_2ecli_2ebashScript_str20 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 32, 99, 97, 115, 101, 32, 34, 36, 123, 111, 117, 116, 91, 48, 93, 125, 34, 32, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_std_2ecli_2ebashScript_str21 = {{0x80000000u, K_STR, 0}, 31, 31, {32, 32, 108, 97, 115, 116, 61, 36, 123, 119, 111, 114, 100, 115, 91, 36, 123, 35, 119, 111, 114, 100, 115, 91, 64, 93, 125, 45, 49, 93, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_std_2ecli_2ebashScript_str22 = {{0x80000000u, K_STR, 0}, 28, 28, {32, 32, 114, 101, 97, 100, 32, 45, 114, 97, 32, 119, 111, 114, 100, 115, 32, 60, 60, 60, 32, 34, 36, 108, 105, 110, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[58]; } g_std_2ecli_2ebashScript_str23 = {{0x80000000u, K_STR, 0}, 58, 58, {32, 32, 91, 91, 32, 36, 108, 105, 110, 101, 32, 61, 61, 32, 42, 39, 32, 39, 32, 124, 124, 32, 36, 123, 35, 119, 111, 114, 100, 115, 91, 64, 93, 125, 32, 45, 101, 113, 32, 49, 32, 93, 93, 32, 38, 38, 32, 119, 111, 114, 100, 115, 43, 61, 40, 39, 39, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[75]; } g_std_2ecli_2ebashScript_str24 = {{0x80000000u, K_STR, 0}, 75, 75, {32, 32, 108, 111, 99, 97, 108, 32, 108, 105, 110, 101, 61, 36, 123, 67, 79, 77, 80, 95, 76, 73, 78, 69, 58, 48, 58, 67, 79, 77, 80, 95, 80, 79, 73, 78, 84, 125, 32, 99, 117, 114, 61, 36, 123, 67, 79, 77, 80, 95, 87, 79, 82, 68, 83, 91, 67, 79, 77, 80, 95, 67, 87, 79, 82, 68, 93, 125, 32, 119, 32, 108, 97, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_std_2ecli_2ebashScript_str25 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 32, 108, 111, 99, 97, 108, 32, 45, 97, 32, 119, 111, 114, 100, 115, 32, 111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ebashScript_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_std_2ecli_2ebashScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ebashScript_entry, 1, 0};

V g_std_2ecli_2ebashScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str0), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ebashScript_str1), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str2)))));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str4)));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str6)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str7), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ebashScript_str8), v_prog_240)));
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str10), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str12), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str13), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str14), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str15), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str16), v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str17), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str18), v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str19), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str20), v_t_2410})});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str21), heff_tag(TAG_Cons, 2, (V[]){v_t_243, v_t_2411})});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str22), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str23), v_t_2412})});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str24), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str25), v_t_2413})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ebashScript_str26); V a_1 = v_t_241; V b_2 = heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2414}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2ebashScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ebashScript(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ezshScript_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {35, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_std_2ecli_2ezshScript_str1 = {{0x80000000u, K_STR, 0}, 14, 14, {58, 32, 119, 114, 105, 116, 116, 101, 110, 32, 98, 121, 32, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_std_2ecli_2ezshScript_str2 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115, 32, 122, 115, 104, 96}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ezshScript_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ezshScript_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {40, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_std_2ecli_2ezshScript_str5 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 111, 117, 116, 61, 40, 34, 36, 123, 40, 64, 102, 41, 36, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[38]; } g_std_2ecli_2ezshScript_str6 = {{0x80000000u, K_STR, 0}, 38, 38, {32, 99, 111, 109, 112, 108, 101, 116, 101, 32, 34, 36, 123, 40, 64, 41, 119, 111, 114, 100, 115, 91, 50, 44, 67, 85, 82, 82, 69, 78, 84, 93, 125, 34, 41, 125, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_std_2ecli_2ezshScript_str7 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 32, 32, 32, 32, 95, 100, 101, 115, 99, 114, 105, 98, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_std_2ecli_2ezshScript_str8 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 99, 97, 110, 100, 115, 32, 59, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_std_2ecli_2ezshScript_str9 = {{0x80000000u, K_STR, 0}, 24, 24, {105, 102, 32, 91, 32, 34, 36, 102, 117, 110, 99, 115, 116, 97, 99, 107, 91, 49, 93, 34, 32, 61, 32, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_std_2ecli_2ezshScript_str10 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 93, 59, 32, 116, 104, 101, 110, 32, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[21]; } g_std_2ecli_2ezshScript_str11 = {{0x80000000u, K_STR, 0}, 21, 21, {32, 34, 36, 64, 34, 59, 32, 101, 108, 115, 101, 32, 99, 111, 109, 112, 100, 101, 102, 32, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ezshScript_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ezshScript_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {59, 32, 102, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ezshScript_str14 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 101, 115, 97, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ezshScript_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_std_2ecli_2ezshScript_str16 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 32, 32, 32, 32, 32, 100, 111, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[32]; } g_std_2ecli_2ezshScript_str17 = {{0x80000000u, K_STR, 0}, 32, 32, {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 99, 97, 110, 100, 115, 43, 61, 40, 34, 36, 123, 108, 47, 47, 58, 47, 92, 92, 58, 125, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_std_2ecli_2ezshScript_str18 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 32, 32, 32, 32, 32, 32, 32, 102, 105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_std_2ecli_2ezshScript_str19 = {{0x80000000u, K_STR, 0}, 55, 55, {32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 99, 97, 110, 100, 115, 43, 61, 40, 34, 36, 123, 36, 123, 108, 37, 37, 36, 39, 92, 116, 39, 42, 125, 47, 47, 58, 47, 92, 92, 58, 125, 58, 36, 123, 108, 35, 42, 36, 39, 92, 116, 39, 125, 34, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_std_2ecli_2ezshScript_str20 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 32, 32, 32, 32, 32, 32, 32, 101, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_std_2ecli_2ezshScript_str21 = {{0x80000000u, K_STR, 0}, 31, 31, {32, 32, 32, 32, 32, 32, 32, 32, 91, 91, 32, 45, 122, 32, 36, 108, 32, 93, 93, 32, 38, 38, 32, 99, 111, 110, 116, 105, 110, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[36]; } g_std_2ecli_2ezshScript_str22 = {{0x80000000u, K_STR, 0}, 36, 36, {32, 32, 32, 32, 32, 32, 32, 32, 105, 102, 32, 91, 91, 32, 36, 108, 32, 61, 61, 32, 42, 36, 39, 92, 116, 39, 42, 32, 93, 93, 59, 32, 116, 104, 101, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ezshScript_str23 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 32, 32, 42, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_std_2ecli_2ezshScript_str24 = {{0x80000000u, K_STR, 0}, 23, 23, {32, 32, 32, 32, 32, 32, 102, 111, 114, 32, 108, 32, 105, 110, 32, 36, 111, 117, 116, 59, 32, 100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[49]; } g_std_2ecli_2ezshScript_str25 = {{0x80000000u, K_STR, 0}, 49, 49, {32, 32, 32, 32, 39, 58, 102, 105, 108, 101, 115, 32, 39, 42, 41, 32, 95, 102, 105, 108, 101, 115, 32, 45, 103, 32, 34, 42, 36, 123, 111, 117, 116, 91, 49, 93, 35, 58, 102, 105, 108, 101, 115, 32, 125, 34, 32, 59, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_std_2ecli_2ezshScript_str26 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 32, 32, 32, 39, 58, 100, 105, 114, 115, 39, 41, 32, 95, 102, 105, 108, 101, 115, 32, 45, 47, 32, 59, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_std_2ecli_2ezshScript_str27 = {{0x80000000u, K_STR, 0}, 17, 17, {32, 32, 99, 97, 115, 101, 32, 36, 111, 117, 116, 91, 49, 93, 32, 105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_std_2ecli_2ezshScript_str28 = {{0x80000000u, K_STR, 0}, 20, 20, {32, 32, 108, 111, 99, 97, 108, 32, 45, 97, 32, 111, 117, 116, 32, 99, 97, 110, 100, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_std_2ecli_2ezshScript_str29 = {{0x80000000u, K_STR, 0}, 9, 9, {32, 32, 108, 111, 99, 97, 108, 32, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ezshScript_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_std_2ecli_2ezshScript_str31 = {{0x80000000u, K_STR, 0}, 9, 9, {35, 99, 111, 109, 112, 100, 101, 102, 32}};
Clo g_std_2ecli_2ezshScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ezshScript_entry, 1, 0};

V g_std_2ecli_2ezshScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str0), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ezshScript_str1), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str2)))));
  V v_t_242 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str3), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str4)));
  V v_t_243 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str5), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str6)));
  V v_t_244 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str7), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str8)));
  V v_t_245 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str9), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ezshScript_str10), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ezshScript_str11), heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ezshScript_str12), heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str13)))))))));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str14), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str15), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str16), heff_tag(TAG_Cons, 2, (V[]){v_t_244, v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str17), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str18), v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str19), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str20), v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str21), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str22), v_t_2410})});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str23), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str24), v_t_2411})});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str25), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str26), v_t_2412})});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str27), v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str28), heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str29), v_t_2414})});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_t_241, heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_2415})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ezshScript_str30); V a_1 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str31), v_prog_240); V a_2 = v_t_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2416, 2); r_; });
}
V g_std_2ecli_2ezshScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ezshScript(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str7 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str12 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str17 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str21 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str22 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str26 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str27 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str32 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str37 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2eoutcomeOf_str41 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2eoutcomeOf_str42 = {{0x80000000u, K_STR, 0}, 8, 8, {10, 117, 115, 97, 103, 101, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2eoutcomeOf_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_std_2ecli_2eoutcomeOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eoutcomeOf_entry, 3, 0};

V g_std_2ecli_2eoutcomeOf(V v_prog_240, V v_k_241, V v_ws_242) {
top: ;
  V v_it_243 = (g_std_2ecli_2eparse(heff_get(heff_dup(v_k_241), LBL_args), v_ws_242));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Left: {
    V v_it1_244 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Left = heff_take_reuse_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_Unknown: {
      V v_t_247 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 2); r_; });
      V v_t_248 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_249 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str0), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str1), heff_strAppend(v_t_247, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str2), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str3), heff_strAppend(v_t_248, ((V)&g_std_2ecli_2eoutcomeOf_str4))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_249});
    }
    case TAG_NoValue: {
      V v_t_2411 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2412 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2413 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str5), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str6), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str7), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str8), heff_strAppend(v_t_2412, ((V)&g_std_2ecli_2eoutcomeOf_str9))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2413});
    }
    case TAG_SwitchValue: {
      V v_t_2415 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2416 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2417 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str10), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str11), heff_strAppend(v_t_2415, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str12), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str13), heff_strAppend(v_t_2416, ((V)&g_std_2ecli_2eoutcomeOf_str14))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2417});
    }
    case TAG_Ambiguous: {
      V v_t_2420 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 2); r_; });
      V v_t_2421 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2422 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str15), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str16), heff_strAppend(v_t_2420, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str17), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str18), heff_strAppend(v_t_2421, ((V)&g_std_2ecli_2eoutcomeOf_str19))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2422});
    }
    case TAG_MissingFlag: {
      V v_t_2424 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2425 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2426 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str20), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str21), heff_strAppend(v_t_2424, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str22), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str23), heff_strAppend(v_t_2425, ((V)&g_std_2ecli_2eoutcomeOf_str24))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2426});
    }
    case TAG_NotIn: {
      V v_t_2430 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 3); r_; });
      V v_t_2431 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2432 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str25), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str26), heff_strAppend(v_t_2430, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str27), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str28), heff_strAppend(v_t_2431, ((V)&g_std_2ecli_2eoutcomeOf_str29))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2432});
    }
    case TAG_Missing: {
      V v_t_2434 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2435 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2436 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str30), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str31), heff_strAppend(v_t_2434, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str32), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str33), heff_strAppend(v_t_2435, ((V)&g_std_2ecli_2eoutcomeOf_str34))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2436});
    }
    case TAG_Extra: {
      V v_t_2438 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2439 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2440 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str35), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str36), heff_strAppend(v_t_2438, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str37), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str38), heff_strAppend(v_t_2439, ((V)&g_std_2ecli_2eoutcomeOf_str39))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2440});
    }
    case TAG_Help: {
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Out, 1, (V[]){(g_std_2ecli_2ehelpOf(v_prog_240, v_k_241))});
    }
    case TAG_BadShape: {
      V v_t_2442 = ({ V a_0 = v_it1_244; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop_tag(v_it1_244, 1); r_; });
      V v_t_2443 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
      V v_t_2444 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str40), heff_strAppend(heff_get(v_k_241, LBL_name), heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str41), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str42), heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2eoutcomeOf_str43), heff_strAppend(v_t_2443, ((V)&g_std_2ecli_2eoutcomeOf_str44))))))))));
      return heff_tag_at(v_ru_24it_243_24Left, TAG_Fail, 1, (V[]){v_t_2444});
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_Right: {
    V v_x_2445 = heff_field(v_it_243, 0);
    V v_ru_24it_243_24Right = heff_take_reuse_n(v_it_243, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_k_241);
    return heff_tag_at(v_ru_24it_243_24Right, TAG_Run, 1, (V[]){v_x_2445});
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_std_2ecli_2eoutcomeOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eoutcomeOf(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ereadLine_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str1 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str3 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ereadLine_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {45, 45, 104, 101, 108, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str6 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2ecli_2ereadLine_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str9 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_std_2ecli_2ereadLine_str11 = {{0x80000000u, K_STR, 0}, 11, 11, {99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str12 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ereadLine_str14 = {{0x80000000u, K_STR, 0}, 4, 4, {102, 105, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_std_2ecli_2ereadLine_str15 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2ecli_2ereadLine_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {122, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[25]; } g_std_2ecli_2ereadLine_str17 = {{0x80000000u, K_STR, 0}, 25, 25, {32, 99, 111, 109, 112, 108, 101, 116, 105, 111, 110, 115, 58, 32, 97, 32, 115, 104, 101, 108, 108, 32, 105, 115, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_std_2ecli_2ereadLine_str18 = {{0x80000000u, K_STR, 0}, 6, 6, {44, 32, 110, 111, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str20 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_std_2ecli_2ereadLine_str22 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 111, 109, 112, 108, 101, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_std_2ecli_2ereadLine_str23 = {{0x80000000u, K_STR, 0}, 13, 13, {58, 32, 110, 111, 32, 99, 111, 109, 109, 97, 110, 100, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2ecli_2ereadLine_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_std_2ecli_2ereadLine_lam0(V self, V *args);
V g_std_2ecli_2ereadLine_lam1(V self, V *args);
V g_std_2ecli_2ereadLine_lam2(V self, V *args);
V g_std_2ecli_2ereadLine_lam3(V self, V *args);
V g_std_2ecli_2ereadLine_lam4(V self, V *args);
V g_std_2ecli_2ereadLine_lam5(V self, V *args);
V g_std_2ecli_2ereadLine_lam6(V self, V *args);
Clo g_std_2ecli_2ereadLine_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereadLine_entry, 3, 0};

V g_std_2ecli_2ereadLine(V v_prog_240, V v_cs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2eusage(v_prog_240, v_cs_241))});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(v_x31_243), ((V)&g_std_2ecli_2ereadLine_str0))) {
      switch (heff_tag_of(v_x32_244)) {
      case TAG_Nil: {
        return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2eusage(v_prog_240, v_cs_241))});
      }
      case TAG_Cons: {
        V v_w_246 = heff_field(v_x32_244, 0);
        V v_x322_247 = heff_field(v_x32_244, 1);
        switch (heff_tag_of(v_x322_247)) {
        case TAG_Nil: {
          V v_t_249 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam0, 1, 1, (V[]){heff_dup(v_w_246)}), v_cs_241));
          switch (heff_tag_of(v_t_249)) {
          case TAG_Nothing: {
            V v_t_2410 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str1), heff_strAppend(heff_dup(v_w_246), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str2), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
            return heff_tag(TAG_Fail, 1, (V[]){v_t_2410});
          }
          case TAG_Just: {
            V v_k_2411 = heff_field(v_t_249, 0);
            V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
            heff_drop(v_cs_241);
            return heff_tag_at(v_ru_24t_249_24Just, TAG_Out, 1, (V[]){(g_std_2ecli_2ehelpOf(v_prog_240, v_k_2411))});
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        case TAG_Cons: {
          V v_t_2415 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam1, 1, 1, (V[]){heff_dup(v_x31_243)}), v_cs_241));
          switch (heff_tag_of(v_t_2415)) {
          case TAG_Nothing: {
            V v_t_2416 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str3), heff_strAppend(heff_dup(v_x31_243), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str4), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
            return heff_tag(TAG_Fail, 1, (V[]){v_t_2416});
          }
          case TAG_Just: {
            V v_k_2417 = heff_field(v_t_2415, 0);
            heff_take_n(v_t_2415, 1ULL, 1);
            heff_drop(v_cs_241);
            HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2417, heff_dup(v_x32_244));
          }
          default: return heff_nomatch(v_t_2415);
          }
        }
        default: return heff_nomatch(v_x322_247);
        }
      }
      default: return heff_nomatch(v_x32_244);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x31_243), ((V)&g_std_2ecli_2ereadLine_str5))) {
        switch (heff_tag_of(v_x32_244)) {
        case TAG_Nil: {
          return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2eusage(v_prog_240, v_cs_241))});
        }
        case TAG_Cons: {
          V v_t_2422 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam2, 1, 1, (V[]){heff_dup(v_x31_243)}), v_cs_241));
          switch (heff_tag_of(v_t_2422)) {
          case TAG_Nothing: {
            V v_t_2423 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str6), heff_strAppend(heff_dup(v_x31_243), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str7), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
            return heff_tag(TAG_Fail, 1, (V[]){v_t_2423});
          }
          case TAG_Just: {
            V v_k_2424 = heff_field(v_t_2422, 0);
            heff_take_n(v_t_2422, 1ULL, 1);
            heff_drop(v_cs_241);
            HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2424, heff_dup(v_x32_244));
          }
          default: return heff_nomatch(v_t_2422);
          }
        }
        default: return heff_nomatch(v_x32_244);
        }
      } else {
        if (heff_strEq_c(heff_dup(v_x31_243), ((V)&g_std_2ecli_2ereadLine_str8))) {
          switch (heff_tag_of(v_x32_244)) {
          case TAG_Nil: {
            return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2eusage(v_prog_240, v_cs_241))});
          }
          case TAG_Cons: {
            V v_t_2429 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam3, 1, 1, (V[]){heff_dup(v_x31_243)}), v_cs_241));
            switch (heff_tag_of(v_t_2429)) {
            case TAG_Nothing: {
              V v_t_2430 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str9), heff_strAppend(heff_dup(v_x31_243), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str10), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
              return heff_tag(TAG_Fail, 1, (V[]){v_t_2430});
            }
            case TAG_Just: {
              V v_k_2431 = heff_field(v_t_2429, 0);
              heff_take_n(v_t_2429, 1ULL, 1);
              heff_drop(v_cs_241);
              HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2431, heff_dup(v_x32_244));
            }
            default: return heff_nomatch(v_t_2429);
            }
          }
          default: return heff_nomatch(v_x32_244);
          }
        } else {
          if (heff_strEq_c(heff_dup(v_x31_243), ((V)&g_std_2ecli_2ereadLine_str11))) {
            switch (heff_tag_of(v_x32_244)) {
            case TAG_Nil: {
              V v_t_2434 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam4, 1, 1, (V[]){heff_dup(v_x31_243)}), v_cs_241));
              switch (heff_tag_of(v_t_2434)) {
              case TAG_Nothing: {
                V v_t_2435 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str12), heff_strAppend(heff_dup(v_x31_243), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str13), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
                return heff_tag(TAG_Fail, 1, (V[]){v_t_2435});
              }
              case TAG_Just: {
                V v_k_2436 = heff_field(v_t_2434, 0);
                heff_take_n(v_t_2434, 1ULL, 1);
                heff_drop(v_cs_241);
                HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2436, heff_dup(v_x32_244));
              }
              default: return heff_nomatch(v_t_2434);
              }
            }
            case TAG_Cons: {
              V v_sh_2437 = heff_field(v_x32_244, 0);
              V v_x322_2438 = heff_field(v_x32_244, 1);
              switch (heff_tag_of(v_x322_2438)) {
              case TAG_Nil: {
                heff_drop(v_cs_241);
                if (heff_strEq_c(heff_dup(v_sh_2437), ((V)&g_std_2ecli_2ereadLine_str14))) {
                  return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2efishScript(v_prog_240))});
                } else {
                  if (heff_strEq_c(heff_dup(v_sh_2437), ((V)&g_std_2ecli_2ereadLine_str15))) {
                    return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2ebashScript(v_prog_240))});
                  } else {
                    if (heff_strEq_c(heff_dup(v_sh_2437), ((V)&g_std_2ecli_2ereadLine_str16))) {
                      return heff_tag(TAG_Out, 1, (V[]){(g_std_2ecli_2ezshScript(v_prog_240))});
                    } else {
                      V v_t_2442 = ({ V b_0 = heff_dup(g_std_2ecli_2eshells_get()); V r_ = (g_std_2ecli_2eorList(b_0)); heff_drop(b_0); r_; });
                      V v_t_2443 = heff_strAppend(v_prog_240, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str17), heff_strAppend(v_t_2442, heff_strAppend(((V)&g_std_2ecli_2ereadLine_str18), heff_strAppend(heff_dup(v_sh_2437), ((V)&g_std_2ecli_2ereadLine_str19))))));
                      return heff_tag(TAG_Fail, 1, (V[]){v_t_2443});
                    }
                  }
                }
              }
              case TAG_Cons: {
                V v_t_2447 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam5, 1, 1, (V[]){heff_dup(v_x31_243)}), v_cs_241));
                switch (heff_tag_of(v_t_2447)) {
                case TAG_Nothing: {
                  V v_t_2448 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str20), heff_strAppend(heff_dup(v_x31_243), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str21), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
                  return heff_tag(TAG_Fail, 1, (V[]){v_t_2448});
                }
                case TAG_Just: {
                  V v_k_2449 = heff_field(v_t_2447, 0);
                  heff_take_n(v_t_2447, 1ULL, 1);
                  heff_drop(v_cs_241);
                  HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2449, heff_dup(v_x32_244));
                }
                default: return heff_nomatch(v_t_2447);
                }
              }
              default: return heff_nomatch(v_x322_2438);
              }
            }
            default: return heff_nomatch(v_x32_244);
            }
          } else {
            if (heff_strEq_c(heff_dup(v_x31_243), ((V)&g_std_2ecli_2ereadLine_str22))) {
              heff_drop(v_prog_240);
              V v_t_2451 = (g_std_2ecli_2einitOf(heff_dup(v_x32_244)));
              V v_t_2452 = (g_std_2ecli_2elastOf(v_x32_244));
              return heff_tag(TAG_Out, 1, (V[]){({ V a_0 = v_cs_241; V a_1 = v_t_2451; V a_2 = v_t_2452; V r_ = (g_std_2ecli_2ecompleteWords(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; })});
            } else {
              V v_t_2454 = (g_list_2efind(heff_clo(g_std_2ecli_2ereadLine_lam6, 1, 1, (V[]){heff_dup(v_x31_243)}), v_cs_241));
              switch (heff_tag_of(v_t_2454)) {
              case TAG_Nothing: {
                V v_t_2455 = heff_strAppend(heff_dup(v_prog_240), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str23), heff_strAppend(heff_dup(v_x31_243), heff_strAppend(((V)&g_std_2ecli_2ereadLine_str24), (g_std_2ecli_2eusage(v_prog_240, v_cs_241))))));
                return heff_tag(TAG_Fail, 1, (V[]){v_t_2455});
              }
              case TAG_Just: {
                V v_k_2456 = heff_field(v_t_2454, 0);
                heff_take_n(v_t_2454, 1ULL, 1);
                heff_drop(v_cs_241);
                HEFF_LAST return g_std_2ecli_2eoutcomeOf(v_prog_240, v_k_2456, heff_dup(v_x32_244));
              }
              default: return heff_nomatch(v_t_2454);
              }
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2ecli_2ereadLine_entry(V self, V *a) {
  (void)self;
  V r = g_std_2ecli_2ereadLine(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_std_2ecli_2ereadLine_lam0(V self, V *args) {
  V v_k_248 = args[0];
  V v_w_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_248, LBL_name), v_w_246);
}
V g_std_2ecli_2ereadLine_lam1(V self, V *args) {
  V v_k_2414 = args[0];
  V v_x31_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2414, LBL_name), v_x31_243);
}
V g_std_2ecli_2ereadLine_lam2(V self, V *args) {
  V v_k_2421 = args[0];
  V v_x31_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2421, LBL_name), v_x31_243);
}
V g_std_2ecli_2ereadLine_lam3(V self, V *args) {
  V v_k_2428 = args[0];
  V v_x31_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2428, LBL_name), v_x31_243);
}
V g_std_2ecli_2ereadLine_lam4(V self, V *args) {
  V v_k_2433 = args[0];
  V v_x31_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2433, LBL_name), v_x31_243);
}
V g_std_2ecli_2ereadLine_lam5(V self, V *args) {
  V v_k_2446 = args[0];
  V v_x31_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2446, LBL_name), v_x31_243);
}
V g_std_2ecli_2ereadLine_lam6(V self, V *args) {
  V v_k_2453 = args[0];
  V v_x31_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_k_2453, LBL_name), v_x31_243);
}