// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define LBL_above 293969847
#define LBL_aliases 1464806715
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_exposes 1070285678
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_instances 1653559473
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_own 320000
#define LBL_renames 1324191545
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
static uint32_t shape_fixities__defs__hashes[] = {LBL_fixities, LBL_defs, LBL_hashes};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
static uint32_t shape_name__key__isInstance__span__ty__body[] = {LBL_name, LBL_key, LBL_isInstance, LBL_span, LBL_ty, LBL_body};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
HeffT2 g_heff_2ebuild_2ecache_2eallJust_24cpr(V);
V g_heff_2ebuild_2ecache_2eassocOf(V);
V g_heff_2ebuild_2ecache_2eassocOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eassocOf_clo;
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
V g_heff_2ebuild_2ecache_2efixSig(V);
V g_heff_2ebuild_2ecache_2efixSig_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efixSig_clo;
HeffT2 g_heff_2ebuild_2ecache_2efreeze_24cpr(V, V, V, V);
V g_heff_2ebuild_2ecache_2efreezeDef(V, V, V);
V g_heff_2ebuild_2ecache_2efreezeDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreezeDef_clo;
V g_heff_2ebuild_2ecache_2efreezeFix(V);
V g_heff_2ebuild_2ecache_2efreezeFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreezeFix_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecache_2eimportsHold(V, V, V, V);
V g_heff_2ebuild_2ecache_2eimportsHold_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eimportsHold_clo;
V g_heff_2ebuild_2ecache_2einstanceSig(V, V, V);
V g_heff_2ebuild_2ecache_2einstanceSig_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2einstanceSig_clo;
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
HeffT2 g_heff_2ebuild_2ecache_2emeltFix_24cpr(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
HeffT2 g_heff_2ebuild_2ecache_2emeltFrom_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2eneedsOf(V);
V g_heff_2ebuild_2ecache_2eneedsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eneedsOf_clo;
V g_heff_2ebuild_2ecache_2ensHashOf(V, V);
V g_heff_2ebuild_2ecache_2ensHashOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ensHashOf_clo;
V g_heff_2ebuild_2ecache_2enubCa(V);
V g_heff_2ebuild_2ecache_2enubCa_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2enubCa_clo;
V g_heff_2ebuild_2ecache_2enubCa_24dps(V, V);
V g_heff_2ebuild_2ecache_2enubCa_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2enubCa_24dps_clo;
V g_heff_2ebuild_2ecache_2eversion_get(void);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2ecache_2ezipCa(V, V);
V g_heff_2ebuild_2ecache_2ezipCa_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ezipCa_clo;
V g_heff_2ebuild_2ecache_2ezipCa_24dps(V, V, V);
V g_heff_2ebuild_2ecache_2ezipCa_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ezipCa_24dps_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448_clo;
V g_heff_2ebuild_2edriver_2eexposedOwn(V);
V g_heff_2ebuild_2edriver_2eexposedOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedOwn_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V, V, V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1547578820x1498276962(V, V);
V g_list_2eany_24s1547578820x1498276962_entry(V self, V *a);
extern Clo g_list_2eany_24s1547578820x1498276962_clo;
V g_list_2eany_24s1631644720x1952242925(V, V);
V g_list_2eany_24s1631644720x1952242925_entry(V self, V *a);
extern Clo g_list_2eany_24s1631644720x1952242925_clo;
V g_list_2eany_24s1662685276x243749136(V, V);
V g_list_2eany_24s1662685276x243749136_entry(V self, V *a);
extern Clo g_list_2eany_24s1662685276x243749136_clo;
HeffT2 g_list_2efind_24s1327702553x1694210434_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f700195413x1431112932(V, V, V);
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a);
extern Clo g_list_2efoldl_24f700195413x1431112932_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s518608766x1858781247(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s518608766x1858781247_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518608766x1858781247_clo;
V g_list_2efoldl_24s655081849x360568693(V, V, V, V);
V g_list_2efoldl_24s655081849x360568693_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655081849x360568693_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1749649202x1754028860(V, V);
V g_list_2emap_24f1749649202x1754028860_entry(V self, V *a);
extern Clo g_list_2emap_24f1749649202x1754028860_clo;
V g_list_2emap_24s1418045490x2076674085(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s159747708x343809768(V, V, V, V, V, V, V);
V g_list_2emap_24s159747708x343809768_entry(V self, V *a);
extern Clo g_list_2emap_24s159747708x343809768_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s564507054x318389057(V, V);
V g_list_2emap_24s564507054x318389057_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_clo;
V g_list_2emap_24s900318151x1569363206(V, V, V);
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_strLt_get(void);
HEFF_LIT(g_heff_2ebuild_2ecache_2eversion_str0, 18, "heff-cache-port/85");

static V g_heff_2ebuild_2ecache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ecache_2eversion_st;
static V g_heff_2ebuild_2ecache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ecache_2eversion_str0);
}
V g_heff_2ebuild_2ecache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecache_2eversion_st)) return g_heff_2ebuild_2ecache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ecache_2eversion_val, &g_heff_2ebuild_2ecache_2eversion_st, g_heff_2ebuild_2ecache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2eversionDir_str0, 3, "v84");

static V g_heff_2ebuild_2ecache_2eversionDir_val;
static HEFF_ONCE g_heff_2ebuild_2ecache_2eversionDir_st;
static V g_heff_2ebuild_2ecache_2eversionDir_init(void) {
  return ((V)&g_heff_2ebuild_2ecache_2eversionDir_str0);
}
V g_heff_2ebuild_2ecache_2eversionDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecache_2eversionDir_st)) return g_heff_2ebuild_2ecache_2eversionDir_val;
  return heff_global(&g_heff_2ebuild_2ecache_2eversionDir_val, &g_heff_2ebuild_2ecache_2eversionDir_st, g_heff_2ebuild_2ecache_2eversionDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ehashGo_str0, 1, "-");
Clo g_heff_2ebuild_2ecache_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ehashGo_entry, 4, 0};

V g_heff_2ebuild_2ecache_2ehashGo(V v_s_240, V v_box_24i_241, V v_box_24a_242, V v_box_24b_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_a_242 = heff_unbox_word(v_box_24a_242);
  int64_t v_b_243 = heff_unbox_word(v_box_24b_243);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ehashGo_str0), heff_intShow(heff_box_word(v_b_243)));
    return heff_strAppend(heff_intShow(heff_box_word(v_a_242)), v_t_244);
  } else {
    int64_t v_t_245 = ((v_a_242 * ((int64_t)1000003ULL)) + heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    int64_t v_t_246 = ((v_t_245 + ((int64_t)1ULL)) % ((int64_t)2147483647ULL));
    int64_t v_t_247 = ((v_b_243 * ((int64_t)999983ULL)) + heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    int64_t v_t_248 = ((v_t_247 + ((int64_t)1ULL)) % ((int64_t)2147483629ULL));
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = v_t_246;
    int64_t t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2ehashGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ecache_2enubCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2enubCa_entry, 1, 0};

V g_heff_2ebuild_2ecache_2enubCa(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2ebuild_2ecache_2enubCa_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2enubCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2enubCa(a[0]);
}
Clo g_heff_2ebuild_2ecache_2enubCa_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2enubCa_24dps_entry, 2, 0};

V g_heff_2ebuild_2ecache_2enubCa_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2enubCa_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2enubCa_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str4, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str7, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str9, 5, "\012(..)");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str10, 2, "\012+");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str11, 2, "\012-");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str13, 1, "\012");
V g_heff_2ebuild_2ecache_2edefHashOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2edefHashOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2edefHashOne_entry, 3, 0};

V g_heff_2ebuild_2ecache_2edefHashOne(V v_m_240, V v_c_241, V v_o_242) {
top: ;
  V v_key_243 = heff_take_field(v_o_242, 1);
  V v_name_244 = heff_get_n(v_o_242, 0, 2);
  V v_top_245 = heff_take_field(v_c_241, 5);
  V v_exposes_246 = heff_get_n(v_c_241, 13, 14);
  HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_m_240, v_key_243));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_key_243);
      heff_drop(v_name_244);
      heff_drop_rec(v_top_245, 9);
      heff_drop(v_exposes_246);
      V v_x_2410 = v_field_249;
      heff_drop(v_x_2410);
      return v_m_240;
    } else {
      heff_drop(v_field_249);
      V v_g_2411 = heff_get_n(v_top_245, 0, 9);
      V v_entries_2412 = heff_take_field(v_g_2411, 1);
      V v_aliases_2413 = heff_get_n(v_g_2411, 2, 8);
      V v_k_2414 = heff_dup(v_key_243);
      HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_2412, v_k_2414));
      V v_t_2423;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          heff_drop(v_entries_2412);
          heff_drop(v_aliases_2413);
          heff_drop(v_k_2414);
          V v_e_2418 = v_field_2417;
          v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_e_2418});
        } else {
          heff_drop(v_field_2417);
          HeffT2 v_t_2419 = ({ V a_0 = v_aliases_2413; V a_1 = v_k_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_2413); heff_drop(v_k_2414); r_; });
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_k2_2422 = v_field_2421;
              v_t_2423 = ({ V a_0 = v_entries_2412; V a_1 = v_k2_2422; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_entries_2412); heff_drop(v_k2_2422); r_; });
            } else {
              heff_drop(v_entries_2412);
              heff_drop(v_field_2421);
              v_t_2423 = NTAG(TAG_Nothing);
            }
          }
        }
      }
      switch (heff_tag_of(v_t_2423)) {
      case TAG_Nothing: {
        heff_drop(v_key_243);
        heff_drop(v_name_244);
        heff_drop(v_exposes_246);
        return v_m_240;
      }
      case TAG_Just: {
        V v_e_2424 = heff_field(v_t_2423, 0);
        heff_take_n(v_t_2423, 1ULL, 1);
        V v_tySyntax_2425 = heff_take_field(v_e_2424, 1);
        V v_syntax_2426 = heff_get_n(v_e_2424, 0, 4);
        V v_x2_2427 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_tySyntax_2425, NTAG(TAG_Nil)));
        V v_t_2430;
        switch (heff_tag_of(v_x2_2427)) {
        case TAG_Nil: {
          v_t_2430 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2428 = heff_field(v_x2_2427, 0);
          V v_xs_2429 = heff_field(v_x2_2427, 1);
          heff_take_n(v_x2_2427, 3ULL, 2);
          v_t_2430 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str1); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2427);
        }
        V v_x2_2431 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_syntax_2426), NTAG(TAG_Nil)));
        V v_t_2434;
        switch (heff_tag_of(v_x2_2431)) {
        case TAG_Nil: {
          v_t_2434 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str2);
          break;
        }
        case TAG_Cons: {
          V v_x_2432 = heff_field(v_x2_2431, 0);
          V v_xs_2433 = heff_field(v_x2_2431, 1);
          heff_take_n(v_x2_2431, 3ULL, 2);
          v_t_2434 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str3); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2431);
        }
        V v_t_2435 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_tySyntax_2425));
        V v_t_2436 = (g_heff_2eelab_2erename_2enubFirst(v_t_2435));
        V v_t_2437 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_syntax_2426));
        V v_t_2438 = (g_heff_2eelab_2erename_2enubFirst(v_t_2437));
        V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2436, v_t_2438));
        V v_t_2440 = (g_heff_2ebuild_2ecache_2enubCa(v_t_2439));
        V v_t_2441 = (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2440));
        V v_x2_2448 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2edefHashOne_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_2441));
        V v_t_2451;
        switch (heff_tag_of(v_x2_2448)) {
        case TAG_Nil: {
          v_t_2451 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2449 = heff_field(v_x2_2448, 0);
          V v_xs_2450 = heff_field(v_x2_2448, 1);
          heff_take_n(v_x2_2448, 3ULL, 2);
          v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str7); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2448);
        }
        V v_x_2452 = v_name_244;
        V v_t_2456;
        switch (heff_tag_of(v_exposes_246)) {
        case TAG_Nothing: {
          heff_drop(v_x_2452);
          v_t_2456 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str8);
          break;
        }
        case TAG_Just: {
          V v_es_2453 = heff_field(v_exposes_246, 0);
          heff_take_n(v_exposes_246, 1ULL, 1);
          V v_t_2454 = (g_list_2eany_24s1662685276x243749136(v_x_2452, v_es_2453));
          if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
            heff_drop(v_x_2452);
            heff_drop(v_es_2453);
            heff_drop(v_t_2454);
            v_t_2456 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str9);
          } else {
            heff_drop(v_t_2454);
            V v_t_2455 = ({ V a_0 = v_x_2452; V a_1 = v_es_2453; V r_ = (g_list_2eany_24s1631644720x1952242925(a_0, a_1)); heff_drop(v_x_2452); heff_drop(v_es_2453); r_; });
            if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
              heff_drop(v_t_2455);
              v_t_2456 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str10);
            } else {
              heff_drop(v_t_2455);
              v_t_2456 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str11);
            }
          }
          break;
        }
        default: heff_nomatch(v_exposes_246);
        }
        V v_t_2457 = heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str12), heff_strAppend(v_t_2451, v_t_2456));
        V v_t_2458 = heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str13), heff_strAppend(v_t_2434, v_t_2457));
        V v_s_2459 = heff_strAppend(v_t_2430, v_t_2458);
        V v_t_2460 = ({ V a_0 = v_s_2459; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ebuild_2ecache_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2459); r_; });
        HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_m_240, v_key_243, v_t_2460);
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
  }
}
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2edefHashOne(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecache_2edefHashOne_lam0(V self, V *args) {
  V v_k_2442 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2443 = ({ V a_0 = v_m_240; V a_1 = v_k_2442; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2447;
  {
    V v_field_2445 = v_t_2443.f[1];
    int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
    if ((v_tag_2444 == ((int64_t)0ULL))) {
      V v_x_2446 = v_field_2445;
      v_t_2447 = v_x_2446;
    } else {
      heff_drop(v_field_2445);
      v_t_2447 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str4);
    }
  }
  return heff_strAppend(v_k_2442, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str5), v_t_2447));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str0, 2, "#T");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str1, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str4, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str5, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str6, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str9, 1, ",");
V g_heff_2ebuild_2ecache_2ewholeHash_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2ewholeHash_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2ewholeHash_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ewholeHash_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ewholeHash(V v_m_240, V v_c_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_c_241, 0)), ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str0));
  V v_t_243 = (g_heff_2ebuild_2edriver_2eexposedOwn(heff_dup(v_c_241)));
  V v_x2_2410 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ewholeHash_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_243));
  V v_s_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_s_2413 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_s_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str4); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2414 = ({ V a_0 = v_s_2413; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ebuild_2ecache_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2413); r_; });
  V v_t_2415 = (g_std_2emap_2einsert_24s93785294x875597928(heff_dup(v_m_240), v_t_242, v_t_2414));
  V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_c_241, 0)), ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str5));
  V v_t_2417 = (g_heff_2ebuild_2edriver_2eexposedOwn(v_c_241));
  V v_x2_2424 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ewholeHash_lam1, 1, 1, (V[]){v_m_240}), v_t_2417));
  V v_s_2427;
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_Nil: {
    v_s_2427 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_xs_2426 = heff_field(v_x2_2424, 1);
    heff_take_n(v_x2_2424, 3ULL, 2);
    v_s_2427 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str9); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2424);
  }
  V v_t_2428 = ({ V a_0 = v_s_2427; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ebuild_2ecache_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2427); r_; });
  return (g_std_2emap_2einsert_24s93785294x875597928(v_t_2415, v_t_2416, v_t_2428));
}
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ewholeHash(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2ewholeHash_lam0(V self, V *args) {
  V v_o_244 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V a_0 = v_m_240; V a_1 = heff_rfield(v_o_244, 1); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_249;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_247);
      v_t_249 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str1);
    }
  }
  return heff_strAppend(heff_get_n(v_o_244, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ewholeHash_str2), v_t_249));
}
V g_heff_2ebuild_2ecache_2ewholeHash_lam1(V self, V *args) {
  V v_o_2418 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2419 = ({ V a_0 = v_m_240; V a_1 = heff_rfield(v_o_2418, 1); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2423;
  {
    V v_field_2421 = v_t_2419.f[1];
    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
    if ((v_tag_2420 == ((int64_t)0ULL))) {
      V v_x_2422 = v_field_2421;
      v_t_2423 = v_x_2422;
    } else {
      heff_drop(v_field_2421);
      v_t_2423 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str6);
    }
  }
  return heff_strAppend(heff_get_n(v_o_2418, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ewholeHash_str7), v_t_2423));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str1, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str2, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str7, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str8, 1, ">");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str10, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str11, 1, "|");
Clo g_heff_2ebuild_2ecache_2efixSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efixSig_entry, 1, 0};

V g_heff_2ebuild_2ecache_2efixSig(V v_f_240) {
top: ;
  V v_groups_241 = heff_take_field(v_f_240, 0);
  V v_above_242 = heff_get_n(v_f_240, 1, 2);
  V v_x2_243 = (g_list_2emap_24s1418045490x2076674085(((V)&g_heff_2ebuild_2ecache_2efixSig_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecache_2efixSig_str1), ((V)&g_heff_2ebuild_2ecache_2efixSig_str2), ((V)&g_heff_2ebuild_2ecache_2efixSig_str3), ((V)&g_heff_2ebuild_2ecache_2efixSig_str4), ((V)&g_heff_2ebuild_2ecache_2efixSig_str5), v_groups_241));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str7); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_list_2emap_24s564507054x318389057(((V)&g_heff_2ebuild_2ecache_2efixSig_str8), v_above_242));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str10); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  return heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efixSig_str11), v_t_2410));
}
V g_heff_2ebuild_2ecache_2efixSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2efixSig(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str2, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str5, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str7, 1, ":");
V g_heff_2ebuild_2ecache_2einstanceSig_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2einstanceSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2einstanceSig_entry, 3, 0};

V g_heff_2ebuild_2ecache_2einstanceSig(V v_hashes_240, V v_c_241, V v_k_242) {
top: ;
  V v_g_243 = heff_get_n(heff_get_n(v_c_241, 5, 14), 0, 9);
  V v_entries_244 = heff_take_field(v_g_243, 1);
  V v_aliases_245 = heff_get_n(v_g_243, 2, 8);
  HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_244, v_k_242));
  V v_t_2414;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_entries_244);
      heff_drop(v_aliases_245);
      V v_e_249 = v_field_248;
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_e_249});
    } else {
      heff_drop(v_field_248);
      HeffT2 v_t_2410 = ({ V a_0 = v_aliases_245; V a_1 = v_k_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_245); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k2_2413 = v_field_2412;
          v_t_2414 = ({ V a_0 = v_entries_244; V a_1 = v_k2_2413; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_entries_244); heff_drop(v_k2_2413); r_; });
        } else {
          heff_drop(v_entries_244);
          heff_drop(v_field_2412);
          v_t_2414 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    return v_k_242;
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    V v_x2_2416 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(heff_rfield(v_e_2415, 1), NTAG(TAG_Nil)));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str1); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2420 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_get_n(v_e_2415, 1, 4)));
    V v_t_2421 = (g_heff_2eelab_2erename_2enubFirst(v_t_2420));
    V v_t_2422 = (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2421));
    V v_x2_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2einstanceSig_lam0, 1, 1, (V[]){heff_dup(v_hashes_240)}), v_t_2422));
    V v_t_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_t_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str5); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    V v_s_2433 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2einstanceSig_str6), v_t_2432));
    V v_t_2434 = ({ V a_0 = v_s_2433; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ebuild_2ecache_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2433); r_; });
    return heff_strAppend(v_k_242, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2einstanceSig_str7), v_t_2434));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2ecache_2einstanceSig_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2einstanceSig(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecache_2einstanceSig_lam0(V self, V *args) {
  V v_r_2423 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = ({ V a_0 = v_hashes_240; V a_1 = v_r_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_hashes_240); r_; });
  V v_t_2428;
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2426;
      v_t_2428 = v_x_2427;
    } else {
      heff_drop(v_field_2426);
      v_t_2428 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str2);
    }
  }
  return heff_strAppend(v_r_2423, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2einstanceSig_str3), v_t_2428));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str1, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str2, 1, "*");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str3, 4, "(..)");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str6, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str8, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str9, 1, "|");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str10, 1, "|");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str11, 1, "|");
V g_heff_2ebuild_2ecache_2ensHashOf_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2ensHashOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2ensHashOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ensHashOf_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ensHashOf(V v_hashes_240, V v_c_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_241, 7))));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_dup(heff_rfield(v_c_241, 13));
  V v_t_2411;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_2411 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str2);
    break;
  }
  case TAG_Just: {
    V v_es_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_x2_248 = (g_list_2emap_24s900318151x1569363206(((V)&g_heff_2ebuild_2ecache_2ensHashOf_str3), ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str4), v_es_247));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str6); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2412 = (g_heff_2ebuild_2ecache_2efixSig(heff_dup(heff_rfield(v_c_241, 11))));
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 0, 9);
  V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2413, 7, 8)));
  V v_t_2415 = (g_list_2emap_24f1749649202x1754028860(heff_dup(v_c_241), v_t_2414));
  V v_t_2418 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecache_2ensHashOf_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_t_2415));
  V v_x2_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ensHashOf_lam1, 1, 2, (V[]){heff_dup(v_hashes_240), v_c_241}), v_t_2418));
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_t_2424 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ensHashOf_str9), v_t_2423));
  V v_t_2425 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ensHashOf_str10), v_t_2424));
  V v_s_2426 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ensHashOf_str11), v_t_2425));
  return ({ V a_0 = v_s_2426; V a_1 = MK_INT(0LL); V a_2 = MK_INT(5381LL); V a_3 = MK_INT(7919LL); V r_ = (g_heff_2ebuild_2ecache_2ehashGo(a_0, a_1, a_2, a_3)); heff_drop(v_s_2426); r_; });
}
V g_heff_2ebuild_2ecache_2ensHashOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2ensHashOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecache_2ensHashOf_lam0(V self, V *args) {
  V v_k_2416 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2ebuild_2edriver_2eexposedOwn(v_c_241));
  return ({ V a_0 = v_k_2416; V a_1 = v_t_2417; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s773255692x715699448(a_0, a_1)); heff_drop(v_k_2416); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2ecache_2ensHashOf_lam1(V self, V *args) {
  V v_k_2419 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_hashes_240; V a_1 = v_c_241; V a_2 = v_k_2419; V r_ = (g_heff_2ebuild_2ecache_2einstanceSig(a_0, a_1, a_2)); heff_drop(v_hashes_240); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str1, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str2, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str6, 1, ":");
Clo g_heff_2ebuild_2ecache_2efreezeFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreezeFix_entry, 1, 0};

V g_heff_2ebuild_2ecache_2efreezeFix(V v_f_240) {
top: ;
  V v_groups_241 = heff_take_field(v_f_240, 0);
  V v_above_242 = heff_get_n(v_f_240, 1, 2);
  V v_xs_243 = v_groups_241;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
  V v_t_246 = (g_list_2efoldl_24s518608766x1858781247(((V)&g_heff_2ebuild_2ecache_2efreezeFix_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str1), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str2), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str3), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str4), NTAG(TAG_Nil), v_t_245));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_244), v_t_246});
  V v_xs_248 = v_above_242;
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  V v_t_2411 = (g_list_2efoldl_24s655081849x360568693(((V)&g_heff_2ebuild_2ecache_2efreezeFix_str5), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str6), NTAG(TAG_Nil), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_249), v_t_2411});
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2412));
}
V g_heff_2ebuild_2ecache_2efreezeFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2efreezeFix(a[0]);
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2eneedsOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2eneedsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eneedsOf_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eneedsOf(V v_c_240) {
top: ;
  V v_own_241 = heff_take_field(v_c_240, 7);
  V v_top_242 = heff_get_n(v_c_240, 5, 14);
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_own_241)));
  V v_t_2435 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2eneedsOf_lam0, 2, 1, (V[]){v_top_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_2436 = (g_heff_2ebuild_2ecache_2enubCa(v_t_2435));
  V v_t_2441 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecache_2eneedsOf_lam1, 1, 1, (V[]){v_own_241}), v_t_2436));
  return (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2441));
}
V g_heff_2ebuild_2ecache_2eneedsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eneedsOf(a[0]);
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_top_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_246 = heff_get_n(v_top_242, 0, 9);
  V v_entries_247 = heff_take_field(v_g_246, 1);
  V v_aliases_248 = heff_get_n(v_g_246, 2, 8);
  V v_k_249 = heff_get_n(v_x_245, 1, 2);
  HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_247, v_k_249));
  V v_t_2434;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_entries_247);
      heff_drop(v_aliases_248);
      heff_drop(v_k_249);
      V v_e_2413 = v_field_2412;
      V v_tySyntax_2414 = heff_take_field(v_e_2413, 1);
      V v_syntax_2415 = heff_get_n(v_e_2413, 0, 4);
      V v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_tySyntax_2414));
      V v_t_2417 = (g_heff_2eelab_2erename_2enubFirst(v_t_2416));
      V v_t_2418 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_syntax_2415));
      V v_t_2419 = (g_heff_2eelab_2erename_2enubFirst(v_t_2418));
      v_t_2434 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
    } else {
      heff_drop(v_field_2412);
      HeffT2 v_t_2420 = ({ V a_0 = v_aliases_248; V a_1 = v_k_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_248); heff_drop(v_k_249); r_; });
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_k2_2423 = v_field_2422;
          HeffT2 v_t_2424 = ({ V a_0 = v_entries_247; V a_1 = v_k2_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_entries_247); heff_drop(v_k2_2423); r_; });
          {
            V v_field_2426 = v_t_2424.f[1];
            int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
            if ((v_tag_2425 == ((int64_t)0ULL))) {
              V v_e_2427 = v_field_2426;
              V v_tySyntax_2428 = heff_take_field(v_e_2427, 1);
              V v_syntax_2429 = heff_get_n(v_e_2427, 0, 4);
              V v_t_2430 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_tySyntax_2428));
              V v_t_2431 = (g_heff_2eelab_2erename_2enubFirst(v_t_2430));
              V v_t_2432 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_syntax_2429));
              V v_t_2433 = (g_heff_2eelab_2erename_2enubFirst(v_t_2432));
              v_t_2434 = (g_prelude_2e_2b_2b(v_t_2431, v_t_2433));
            } else {
              heff_drop(v_field_2426);
              v_t_2434 = NTAG(TAG_Nil);
            }
          }
        } else {
          heff_drop(v_entries_247);
          heff_drop(v_field_2422);
          v_t_2434 = NTAG(TAG_Nil);
        }
      }
    }
  }
  return (g_prelude_2e_2b_2b(v_t_2434, v_acc_244));
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam1(V self, V *args) {
  V v_k_2437 = args[0];
  V v_own_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2438 = (g_list_2emap_24s152505078x225062837(v_own_241));
  V v_t_2439 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_2437}));
  V v_x1_2440 = ({ V a_0 = v_t_2439; V a_1 = v_xs_2438; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2438); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2440) == NTAG(TAG_True)));
  heff_drop(v_x1_2440);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str2, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str3, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str4, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str9, 1, " ");
Clo g_heff_2ebuild_2ecache_2efreezeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreezeDef_entry, 3, 0};

V g_heff_2ebuild_2ecache_2efreezeDef(V v_hashes_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_key_245 = heff_take_field(v_o_243, 1);
    V v_name_246 = heff_get_n(v_o_243, 0, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_MkPair: {
      V v_sp_248 = heff_field(v_x32_244, 1);
      V v_ru_24x32_244_24MkPair = heff_take_reuse_n(v_x32_244, 2ULL, 2);
      V v_start_249 = heff_take_field(v_sp_248, 0);
      V v_end_2410 = heff_get_n(v_sp_248, 1, 2);
      V v_g_2411 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 0, 9);
      V v_entries_2412 = heff_take_field(v_g_2411, 1);
      V v_aliases_2413 = heff_get_n(v_g_2411, 2, 8);
      V v_k_2414 = heff_dup(v_key_245);
      HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_entries_2412, v_k_2414));
      V v_t_2423;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          heff_drop(v_entries_2412);
          heff_drop(v_aliases_2413);
          heff_drop(v_k_2414);
          V v_e_2418 = v_field_2417;
          v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){v_e_2418});
        } else {
          heff_drop(v_field_2417);
          HeffT2 v_t_2419 = ({ V a_0 = v_aliases_2413; V a_1 = v_k_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_aliases_2413); heff_drop(v_k_2414); r_; });
          {
            V v_field_2421 = v_t_2419.f[1];
            int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
            if ((v_tag_2420 == ((int64_t)0ULL))) {
              V v_k2_2422 = v_field_2421;
              v_t_2423 = ({ V a_0 = v_entries_2412; V a_1 = v_k2_2422; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_entries_2412); heff_drop(v_k2_2422); r_; });
            } else {
              heff_drop(v_entries_2412);
              heff_drop(v_field_2421);
              v_t_2423 = NTAG(TAG_Nothing);
            }
          }
        }
      }
      switch (heff_tag_of(v_t_2423)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_241, 14);
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop(v_key_245);
        heff_drop(v_name_246);
        heff_drop_cell(v_ru_24x32_244_24MkPair, 2);
        heff_drop(v_start_249);
        heff_drop(v_end_2410);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_2424 = heff_field(v_t_2423, 0);
        V v_ru_24t_2423_24Just = heff_take_reuse_n(v_t_2423, 1ULL, 1);
        V v_tySyntax_2425 = heff_take_field(v_e_2424, 1);
        V v_syntax_2426 = heff_get_n(v_e_2424, 0, 4);
        V v_s_2427 = v_name_246;
        V v_t_2428 = heff_intShow(heff_strLength_lent(v_s_2427, 0));
        V v_t_2429 = heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str0), v_s_2427));
        V v_s_2430 = heff_dup(v_key_245);
        V v_t_2431 = heff_intShow(heff_strLength_lent(v_s_2430, 0));
        V v_t_2432 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str1), v_s_2430));
        V v_t_2433 = heff_get_n(heff_get_n(v_c_241, 5, 14), 0, 9);
        V v_x1_2434 = ({ V a_0 = v_key_245; V b_1 = heff_get_n(v_t_2433, 7, 8); V r_ = (g_list_2eany_24s1547578820x1498276962(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2435;
        if ((heff_dup(v_x1_2434) == NTAG(TAG_True))) {
          heff_drop(v_x1_2434);
          v_t_2435 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str2);
        } else {
          heff_drop(v_x1_2434);
          v_t_2435 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str3);
        }
        HeffT2 v_t_2436 = ({ V a_0 = v_hashes_240; V a_1 = v_key_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_key_245); r_; });
        V v_t_2442;
        {
          V v_field_2438 = v_t_2436.f[1];
          int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
          V v_s_2440;
          if ((v_tag_2437 == ((int64_t)0ULL))) {
            V v_x_2439 = v_field_2438;
            v_s_2440 = v_x_2439;
          } else {
            heff_drop(v_field_2438);
            v_s_2440 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str4);
          }
          V v_t_2441 = heff_intShow(heff_strLength_lent(v_s_2440, 0));
          v_t_2442 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str5), v_s_2440));
        }
        V v_x2_2443 = ({ V a_0 = v_tySyntax_2425; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_tySyntax_2425); r_; });
        V v_t_2446;
        switch (heff_tag_of(v_x2_2443)) {
        case TAG_Nil: {
          v_t_2446 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2444 = heff_field(v_x2_2443, 0);
          V v_xs_2445 = heff_field(v_x2_2443, 1);
          heff_take_n(v_x2_2443, 3ULL, 2);
          v_t_2446 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str7); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2443);
        }
        V v_x2_2447 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_syntax_2426, NTAG(TAG_Nil)));
        V v_t_2450;
        switch (heff_tag_of(v_x2_2447)) {
        case TAG_Nil: {
          v_t_2450 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2448 = heff_field(v_x2_2447, 0);
          V v_xs_2449 = heff_field(v_x2_2447, 1);
          heff_take_n(v_x2_2447, 3ULL, 2);
          v_t_2450 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str9); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2447);
        }
        V v_t_2451 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
        V v_t_2452 = heff_tag_at_n(v_ru_24x32_244_24MkPair, TAG_Cons, 2, (V[]){heff_intShow(v_end_2410), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2451})});
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_start_249), v_t_2452});
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2453})});
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2454})});
        return heff_tag_at_n(v_ru_24t_2423_24Just, TAG_Just, 1, (V[]){v_t_2455});
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2efreezeDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2efreezeDef(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ecache_2ezipCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ezipCa_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ezipCa(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2ecache_2ezipCa_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2ezipCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ezipCa(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecache_2ezipCa_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ezipCa_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecache_2ezipCa_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2ezipCa_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ezipCa_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2ecache_2eallJust_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_244 = (g_heff_2ebuild_2ecache_2eallJust_24cpr(v_x12_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_ys_247 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_ys_247})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_243);
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str6, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_24cpr_str10, 1, " ");
V g_heff_2ebuild_2ecache_2efreeze_24cpr_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2efreeze_24cpr_lam1(V self, V *args);
V g_heff_2ebuild_2ecache_2efreeze_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2ebuild_2ecache_2efreeze_24cpr(V v_hashes_240, V v_done_241, V v_s_242, V v_c_243) {
top: ;
  V v_module_244 = heff_take_field(v_s_242, 0);
  V v_renames_245 = heff_take_field(v_s_242, 5);
  V v_implicit_246 = heff_take_field(v_s_242, 6);
  V v_source_247 = heff_get_n(v_s_242, 4, 8);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_243, 5)), 6, 9);
  V v_t_249 = (g_heff_2ebuild_2ecache_2ezipCa(heff_dup(heff_rfield(v_c_243, 7)), v_t_248));
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_24cpr_lam0, 1, 2, (V[]){heff_dup(v_hashes_240), heff_dup(v_c_243)}), v_t_249));
  HeffT2 v_t_2412 = (g_heff_2ebuild_2ecache_2eallJust_24cpr(v_t_2411));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_defs_2415 = v_field_2414;
      V v_t_2416 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ecache_2eversion_get())));
      V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str0), heff_dup(g_heff_2ebuild_2ecache_2eversion_get())));
      V v_s_2418 = v_module_244;
      V v_t_2419 = heff_intShow(heff_strLength_lent(v_s_2418, 0));
      V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str1), v_s_2418));
      V v_s_2421 = (g_heff_2ebuild_2ecache_2ehashGo(heff_rfield(v_c_243, 3), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      V v_t_2422 = heff_intShow(heff_strLength_lent(v_s_2421, 0));
      V v_t_2423 = heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str2), v_s_2421));
      V v_t_2424 = (g_heff_2ebuild_2ecache_2efreezeFix(heff_dup(heff_rfield(v_c_243, 11))));
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2424})});
      V v_t_2426 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_246, v_source_247));
      V v_t_2427 = ({ V a_0 = v_renames_245; V a_1 = v_t_2426; V r_ = (g_heff_2esyntax_2eimport_2erenamed(a_0, a_1)); heff_drop(v_renames_245); r_; });
      V v_imps_2428 = heff_get_n(v_t_2427, 0, 4);
      V v_t_2429 = (g_list_2emap_24s1817208647x1282894070(v_imps_2428));
      V v_xs_2430 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2429));
      V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2430));
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
      V v_t_2445 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_24cpr_lam1, 2, 2, (V[]){v_done_241, heff_dup(v_hashes_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2432; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2431), v_t_2445});
      V v_xs_2447 = (g_heff_2ebuild_2ecache_2eneedsOf(v_c_243));
      V v_t_2448 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2447));
      V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2447));
      V v_t_2463 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_24cpr_lam2, 2, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2449; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2449); r_; });
      V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2448), v_t_2463});
      V v_t_2465 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_defs_2415));
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2415));
      V v_t_2467 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2466; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2466); r_; });
      V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2465), v_t_2467});
      V v_t_2469 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2468));
      V v_t_2470 = (g_prelude_2e_2b_2b(v_t_2446, v_t_2469));
      V v_x2_2471 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2425}), v_t_2470));
      V v_f_2474;
      switch (heff_tag_of(v_x2_2471)) {
      case TAG_Nil: {
        v_f_2474 = ((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2472 = heff_field(v_x2_2471, 0);
        V v_xs_2473 = heff_field(v_x2_2471, 1);
        heff_take_n(v_x2_2471, 3ULL, 2);
        v_f_2474 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str10); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2471);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2474}});
    } else {
      heff_drop(v_done_241);
      heff_drop_rec(v_c_243, 14);
      heff_drop(v_module_244);
      heff_drop(v_renames_245);
      heff_drop(v_implicit_246);
      heff_drop(v_source_247);
      heff_drop(v_field_2414);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2ecache_2efreeze_24cpr_lam0(V self, V *args) {
  V v_p_2410 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_hashes_240; V a_1 = v_c_243; V a_2 = v_p_2410; V r_ = (g_heff_2ebuild_2ecache_2efreezeDef(a_0, a_1, a_2)); heff_drop(v_hashes_240); r_; });
}
V g_heff_2ebuild_2ecache_2efreeze_24cpr_lam1(V self, V *args) {
  V v_acc_2433 = args[0];
  V v_x_2434 = args[1];
  V v_done_241 = heff_env(self)[0];
  V v_hashes_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2435 = (g_list_2efind_24s1327702553x1694210434_24cpr(v_x_2434, v_done_241));
  V v_b_2439;
  {
    V v_field_2437 = v_t_2435.f[1];
    int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
    if ((v_tag_2436 == ((int64_t)0ULL))) {
      V v_d_2438 = v_field_2437;
      v_b_2439 = ({ V a_0 = v_hashes_240; V a_1 = v_d_2438; V r_ = (g_heff_2ebuild_2ecache_2ensHashOf(a_0, a_1)); heff_drop(v_hashes_240); r_; });
    } else {
      heff_drop(v_hashes_240);
      heff_drop(v_field_2437);
      v_b_2439 = ((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str3);
    }
  }
  V v_t_2440 = heff_intShow(heff_strLength_lent(v_x_2434, 0));
  V v_t_2441 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str4), v_x_2434));
  V v_t_2442 = heff_intShow(heff_strLength_lent(v_b_2439, 0));
  V v_t_2443 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str5), v_b_2439));
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2444}), v_acc_2433));
}
V g_heff_2ebuild_2ecache_2efreeze_24cpr_lam2(V self, V *args) {
  V v_acc_2450 = args[0];
  V v_x_2451 = args[1];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2452 = ({ V a_0 = v_hashes_240; V a_1 = v_x_2451; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_hashes_240); r_; });
  V v_t_2462;
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    V v_b_2456;
    if ((v_tag_2453 == ((int64_t)0ULL))) {
      V v_x_2455 = v_field_2454;
      v_b_2456 = v_x_2455;
    } else {
      heff_drop(v_field_2454);
      v_b_2456 = ((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str6);
    }
    V v_t_2457 = heff_intShow(heff_strLength_lent(v_x_2451, 0));
    V v_t_2458 = heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str7), v_x_2451));
    V v_t_2459 = heff_intShow(heff_strLength_lent(v_b_2456, 0));
    V v_t_2460 = heff_strAppend(v_t_2459, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_24cpr_str8), v_b_2456));
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
    v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2461});
  }
  return (g_prelude_2e_2b_2b(v_t_2462, v_acc_2450));
}
V g_heff_2ebuild_2ecache_2eassocOf_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam0, 2, 0};
V g_heff_2ebuild_2ecache_2eassocOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam1, 2, 0};
V g_heff_2ebuild_2ecache_2eassocOf_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam2, 2, 0};
Clo g_heff_2ebuild_2ecache_2eassocOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eassocOf(V v_x1_240) {
top: ;
  if (heff_intEq_c_lent(v_x1_240, MK_INT(0LL), 2)) {
    heff_drop(v_x1_240);
    return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam0_clo);
  } else {
    if (heff_intEq_c_lent(v_x1_240, MK_INT(1LL), 2)) {
      heff_drop(v_x1_240);
      return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam1_clo);
    } else {
      if (heff_intEq_c(v_x1_240, MK_INT(2LL))) {
        return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam2_clo);
      } else {
        return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
      }
    }
  }
}
V g_heff_2ebuild_2ecache_2eassocOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eassocOf(a[0]);
}
V g_heff_2ebuild_2ecache_2eassocOf_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_i_242 = args[1];
  heff_drop(v_s_241);
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocLeft), v_i_242});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_243});
}
V g_heff_2ebuild_2ecache_2eassocOf_lam1(V self, V *args) {
  V v_s_244 = args[0];
  V v_i_245 = args[1];
  heff_drop(v_s_244);
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocRight), v_i_245});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
}
V g_heff_2ebuild_2ecache_2eassocOf_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_i_248 = args[1];
  heff_drop(v_s_247);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocNone), v_i_248});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFixGroup_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltFixGroup(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ecache_2emeltFixGroup_lam0, 3, 2, (V[]){v_x_2412, v_x_246}), v_s_240, v_j_2413));
            }
            default: return heff_nomatch(v_x31_2411);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_246);
            heff_drop(v_field_2410);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltFixGroup(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_lam0(V self, V *args) {
  V v_loosest_2414 = args[0];
  V v_s_2415 = args[1];
  V v_i_2416 = args[2];
  V v_x_2412 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_2415, v_i_2416));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x31_2420 = v_field_2419;
      switch (heff_tag_of(v_x31_2420)) {
      case TAG_MkPair: {
        V v_x_2421 = heff_field(v_x31_2420, 0);
        V v_j_2422 = heff_field(v_x31_2420, 1);
        V v_ru_24x31_2420_24MkPair = heff_take_reuse_n(v_x31_2420, 3ULL, 2);
        HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2415, v_j_2422));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_x31_2426 = v_field_2425;
            switch (heff_tag_of(v_x31_2426)) {
            case TAG_MkPair: {
              V v_x_2427 = heff_field(v_x31_2426, 0);
              V v_j_2428 = heff_field(v_x31_2426, 1);
              heff_take_n(v_x31_2426, 3ULL, 2);
              HeffT2 v_t_2429 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2427, v_s_2415, v_j_2428));
              {
                V v_field_2431 = v_t_2429.f[1];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_x31_2432 = v_field_2431;
                  switch (heff_tag_of(v_x31_2432)) {
                  case TAG_MkPair: {
                    V v_x_2433 = heff_field(v_x31_2432, 0);
                    V v_j_2434 = heff_field(v_x31_2432, 1);
                    heff_take_n(v_x31_2432, 3ULL, 2);
                    V v_m_2435 = (g_heff_2ebuild_2ecache_2eassocOf(v_x_2412));
                    V v_x3_2436 = heff_tr(heff_call(v_m_2435, 2, (V[]){v_s_2415, v_j_2434}));
                    switch (heff_tag_of(v_x3_2436)) {
                    case TAG_Nothing: {
                      heff_drop(v_loosest_2414);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2421);
                      heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                      heff_drop(v_x_2433);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2437 = heff_field(v_x3_2436, 0);
                      V v_ru_24x3_2436_24Just = heff_take_reuse_n(v_x3_2436, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2437)) {
                      case TAG_MkPair: {
                        V v_x_2438 = heff_field(v_x31_2437, 0);
                        V v_j_2439 = heff_field(v_x31_2437, 1);
                        heff_take_n(v_x31_2437, 3ULL, 2);
                        V v_t_2440 = heff_tag_at_n(v_ru_24x31_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){v_x_246, v_x_2438, v_x_2433, v_loosest_2414, v_x_2421}), v_j_2439});
                        return heff_tag_at_n(v_ru_24x3_2436_24Just, TAG_Just, 1, (V[]){v_t_2440});
                      }
                      default: return heff_nomatch(v_x31_2437);
                      }
                    }
                    default: return heff_nomatch(v_x3_2436);
                    }
                  }
                  default: return heff_nomatch(v_x31_2432);
                  }
                } else {
                  heff_drop(v_loosest_2414);
                  heff_drop(v_s_2415);
                  heff_drop(v_x_2412);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2421);
                  heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                  heff_drop(v_field_2431);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2426);
            }
          } else {
            heff_drop(v_loosest_2414);
            heff_drop(v_s_2415);
            heff_drop(v_x_2412);
            heff_drop(v_x_246);
            heff_drop(v_x_2421);
            heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
            heff_drop(v_field_2425);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2420);
      }
    } else {
      heff_drop(v_loosest_2414);
      heff_drop(v_s_2415);
      heff_drop(v_x_2412);
      heff_drop(v_x_246);
      heff_drop(v_field_2419);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ebuild_2ecache_2emeltFix_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_24cpr(v_x_246, heff_dup(v_s_240), v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = ({ V a_0 = v_x_2418; V a_1 = v_s_240; V a_2 = v_j_2419; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_24cpr(a_0, a_1, a_2)); heff_drop(v_s_240); r_; });
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          V v_t_2426 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_x_2412, v_x_2424}), v_j_2425});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2426}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                        }
                      } else {
                        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                        heff_drop(v_x_2412);
                        heff_drop(v_field_2422);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2416);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltDef_str0, 1, "\012");
V g_heff_2ebuild_2ecache_2emeltDef_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltDef_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltDef(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ecache_2emeltDef_lam0, 3, 2, (V[]){v_x_246, v_x_2412}), v_s_240, v_j_2413));
            }
            default: return heff_nomatch(v_x31_2411);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_246);
            heff_drop(v_field_2410);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltDef(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2emeltDef_lam0(V self, V *args) {
  V v_isInstance_2414 = args[0];
  V v_s_2415 = args[1];
  V v_i_2416 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_2415, v_i_2416));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_x31_2420 = v_field_2419;
      switch (heff_tag_of(v_x31_2420)) {
      case TAG_MkPair: {
        V v_x_2421 = heff_field(v_x31_2420, 0);
        V v_j_2422 = heff_field(v_x31_2420, 1);
        V v_ru_24x31_2420_24MkPair = heff_take_reuse_n(v_x31_2420, 3ULL, 2);
        HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2415, v_j_2422));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_x31_2426 = v_field_2425;
            switch (heff_tag_of(v_x31_2426)) {
            case TAG_MkPair: {
              V v_x_2427 = heff_field(v_x31_2426, 0);
              V v_j_2428 = heff_field(v_x31_2426, 1);
              heff_take_n(v_x31_2426, 3ULL, 2);
              HeffT2 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2415, v_j_2428));
              {
                V v_field_2431 = v_t_2429.f[1];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_x31_2432 = v_field_2431;
                  switch (heff_tag_of(v_x31_2432)) {
                  case TAG_MkPair: {
                    V v_x_2433 = heff_field(v_x31_2432, 0);
                    V v_j_2434 = heff_field(v_x31_2432, 1);
                    heff_take_n(v_x31_2432, 3ULL, 2);
                    HeffT2 v_t_2435 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2415, v_j_2434));
                    {
                      V v_field_2437 = v_t_2435.f[1];
                      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                      if ((v_tag_2436 == ((int64_t)0ULL))) {
                        V v_x31_2438 = v_field_2437;
                        switch (heff_tag_of(v_x31_2438)) {
                        case TAG_MkPair: {
                          V v_x_2439 = heff_field(v_x31_2438, 0);
                          V v_j_2440 = heff_field(v_x31_2438, 1);
                          heff_take_n(v_x31_2438, 3ULL, 2);
                          HeffT2 v_t_2441 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2439, heff_dup(v_s_2415), v_j_2440));
                          {
                            V v_field_2443 = v_t_2441.f[1];
                            int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                            if ((v_tag_2442 == ((int64_t)0ULL))) {
                              V v_x31_2444 = v_field_2443;
                              switch (heff_tag_of(v_x31_2444)) {
                              case TAG_MkPair: {
                                V v_x_2445 = heff_field(v_x31_2444, 0);
                                V v_j_2446 = heff_field(v_x31_2444, 1);
                                heff_take_n(v_x31_2444, 3ULL, 2);
                                HeffT2 v_t_2447 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2415, v_j_2446));
                                {
                                  V v_field_2449 = v_t_2447.f[1];
                                  int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                                  if ((v_tag_2448 == ((int64_t)0ULL))) {
                                    V v_x31_2450 = v_field_2449;
                                    switch (heff_tag_of(v_x31_2450)) {
                                    case TAG_MkPair: {
                                      V v_x_2451 = heff_field(v_x31_2450, 0);
                                      V v_j_2452 = heff_field(v_x31_2450, 1);
                                      heff_take_n(v_x31_2450, 3ULL, 2);
                                      HeffT2 v_t_2453 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2451, v_s_2415, v_j_2452));
                                      {
                                        V v_field_2455 = v_t_2453.f[1];
                                        int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                                        if ((v_tag_2454 == ((int64_t)0ULL))) {
                                          V v_x31_2456 = v_field_2455;
                                          switch (heff_tag_of(v_x31_2456)) {
                                          case TAG_MkPair: {
                                            V v_x_2457 = heff_field(v_x31_2456, 0);
                                            V v_j_2458 = heff_field(v_x31_2456, 1);
                                            heff_take_n(v_x31_2456, 3ULL, 2);
                                            V v_t_2459 = heff_rec_n(6, shape_name__key__isInstance__span__ty__body, (V[]){v_x_246, heff_dup(v_x_2412), v_isInstance_2414, heff_rec_n(2, shape_start__end, (V[]){v_x_2427, v_x_2433}), v_x_2445, v_x_2457});
                                            V v_t_2460 = heff_strAppend(v_x_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2emeltDef_str0), v_x_2421));
                                            V v_t_2461 = heff_tag_at_n(v_ru_24x31_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2459, v_t_2460}), v_j_2458});
                                            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2461});
                                          }
                                          default: return heff_nomatch(v_x31_2456);
                                          }
                                        } else {
                                          heff_drop(v_isInstance_2414);
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2412);
                                          heff_drop(v_x_2421);
                                          heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                                          heff_drop(v_x_2427);
                                          heff_drop(v_x_2433);
                                          heff_drop(v_x_2445);
                                          heff_drop(v_field_2455);
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                    default: return heff_nomatch(v_x31_2450);
                                    }
                                  } else {
                                    heff_drop(v_isInstance_2414);
                                    heff_drop(v_s_2415);
                                    heff_drop(v_x_246);
                                    heff_drop(v_x_2412);
                                    heff_drop(v_x_2421);
                                    heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                                    heff_drop(v_x_2427);
                                    heff_drop(v_x_2433);
                                    heff_drop(v_x_2445);
                                    heff_drop(v_field_2449);
                                    return NTAG(TAG_Nothing);
                                  }
                                }
                              }
                              default: return heff_nomatch(v_x31_2444);
                              }
                            } else {
                              heff_drop(v_isInstance_2414);
                              heff_drop(v_s_2415);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2412);
                              heff_drop(v_x_2421);
                              heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                              heff_drop(v_x_2427);
                              heff_drop(v_x_2433);
                              heff_drop(v_field_2443);
                              return NTAG(TAG_Nothing);
                            }
                          }
                        }
                        default: return heff_nomatch(v_x31_2438);
                        }
                      } else {
                        heff_drop(v_isInstance_2414);
                        heff_drop(v_s_2415);
                        heff_drop(v_x_246);
                        heff_drop(v_x_2412);
                        heff_drop(v_x_2421);
                        heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                        heff_drop(v_x_2427);
                        heff_drop(v_x_2433);
                        heff_drop(v_field_2437);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2432);
                  }
                } else {
                  heff_drop(v_isInstance_2414);
                  heff_drop(v_s_2415);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_x_2421);
                  heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                  heff_drop(v_x_2427);
                  heff_drop(v_field_2431);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2426);
            }
          } else {
            heff_drop(v_isInstance_2414);
            heff_drop(v_s_2415);
            heff_drop(v_x_246);
            heff_drop(v_x_2412);
            heff_drop(v_x_2421);
            heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
            heff_drop(v_field_2425);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2420);
      }
    } else {
      heff_drop(v_isInstance_2414);
      heff_drop(v_s_2415);
      heff_drop(v_x_246);
      heff_drop(v_x_2412);
      heff_drop(v_field_2419);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2eimportsHold_str0, 1, "\?");
V g_heff_2ebuild_2ecache_2eimportsHold_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2eimportsHold_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eimportsHold_entry, 4, 0};

V g_heff_2ebuild_2ecache_2eimportsHold(V v_hashes_240, V v_done_241, V v_s_242, V v_ns_243) {
top: ;
  V v_renames_244 = heff_take_field(v_s_242, 5);
  V v_implicit_245 = heff_take_field(v_s_242, 6);
  V v_source_246 = heff_get_n(v_s_242, 4, 8);
  V v_t_2415 = (g_list_2eall(heff_clo_n(g_heff_2ebuild_2ecache_2eimportsHold_lam0, 1, 2, (V[]){v_done_241, heff_dup(v_hashes_240)}), v_ns_243));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2415) == NTAG(TAG_True)) && ({ V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ns_243)); int c_ = ({ V v_t_2416 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_implicit_245), heff_dup(v_source_246))); int c_ = ({ V v_t_2417 = (g_heff_2esyntax_2eimport_2erenamed(v_renames_244, heff_dup(v_t_2416))); int c_ = ({ V v_imps_2418 = heff_dup(heff_rfield(v_t_2417, 0)); int c_ = ({ V v_t_2419 = (g_list_2emap_24s1817208647x1282894070(heff_dup(v_imps_2418))); int c_ = ({ V v_t_2421 = (g_list_2efoldl_24f700195413x1431112932(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_2419))); int c_ = heff_intEq_c_lent(v_t_2420, v_t_2421, 0); heff_drop(v_t_2421); c_; }); heff_drop(v_t_2419); c_; }); heff_drop(v_imps_2418); c_; }); heff_drop(v_t_2417); c_; }); heff_drop(v_t_2416); c_; }); heff_drop(v_t_2420); c_; })));
  heff_drop(v_renames_244);
  heff_drop(v_implicit_245);
  heff_drop(v_source_246);
  heff_drop(v_t_2415);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecache_2eimportsHold_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2ecache_2eimportsHold(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecache_2eimportsHold_lam0(V self, V *args) {
  V v_x3_247 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hashes_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_247)) {
  case TAG_MkPair: {
    V v_m_248 = heff_field(v_x3_247, 0);
    V v_h_249 = heff_field(v_x3_247, 1);
    heff_take_n(v_x3_247, 3ULL, 2);
    HeffT2 v_t_2410 = ({ V a_0 = v_m_248; V a_1 = v_done_241; HeffT2 r_ = (g_list_2efind_24s1327702553x1694210434_24cpr(a_0, a_1)); heff_drop(v_m_248); r_; });
    V v_t_2414;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_d_2413 = v_field_2412;
        v_t_2414 = ({ V a_0 = v_hashes_240; V a_1 = v_d_2413; V r_ = (g_heff_2ebuild_2ecache_2ensHashOf(a_0, a_1)); heff_drop(v_hashes_240); r_; });
      } else {
        heff_drop(v_hashes_240);
        heff_drop(v_field_2412);
        v_t_2414 = ((V)&g_heff_2ebuild_2ecache_2eimportsHold_str0);
      }
    }
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2414, v_h_249, 0));
    heff_drop(v_h_249);
    heff_drop(v_t_2414);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x3_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str4, 1, "\?");
V g_heff_2ebuild_2ecache_2emeltFrom_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ecache_2emeltFrom_24cpr(V v_hashes_240, V v_done_241, V v_s_242, V v_s_243, V v_i_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_243, v_i_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x31_248 = v_field_247;
      switch (heff_tag_of(v_x31_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x31_248, 0);
        V v_j_2410 = heff_field(v_x31_248, 1);
        V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
        if (heff_strEq_c(v_x_249, heff_dup(g_heff_2ebuild_2ecache_2eversion_get()))) {
          V v_x_2411 = NTAG(TAG_MkUnit);
          V v_j_2412 = v_j_2410;
          HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_243, v_j_2412));
          {
            V v_field_2415 = v_t_2413.f[1];
            int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
            if ((v_tag_2414 == ((int64_t)0ULL))) {
              V v_x31_2416 = v_field_2415;
              switch (heff_tag_of(v_x31_2416)) {
              case TAG_MkPair: {
                V v_x_2417 = heff_field(v_x31_2416, 0);
                V v_j_2418 = heff_field(v_x31_2416, 1);
                V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
                if (heff_strEq_c(v_x_2417, heff_dup(heff_rfield(v_s_242, 0)))) {
                  V v_x_2419 = (g_heff_2ebuild_2ecache_2ehashGo(heff_rfield(v_s_242, 4), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
                  HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_243, v_j_2418));
                  {
                    V v_field_2422 = v_t_2420.f[1];
                    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                    if ((v_tag_2421 == ((int64_t)0ULL))) {
                      V v_x31_2423 = v_field_2422;
                      switch (heff_tag_of(v_x31_2423)) {
                      case TAG_MkPair: {
                        V v_x_2424 = heff_field(v_x31_2423, 0);
                        V v_j_2425 = heff_field(v_x31_2423, 1);
                        heff_take_n(v_x31_2423, 3ULL, 2);
                        if (heff_strEq_c(v_x_2424, v_x_2419)) {
                          HeffT2 v_t_2426 = (g_heff_2ebuild_2ecache_2emeltFix_24cpr(heff_dup(v_s_243), v_j_2425));
                          {
                            V v_field_2428 = v_t_2426.f[1];
                            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                            if ((v_tag_2427 == ((int64_t)0ULL))) {
                              V v_x31_2429 = v_field_2428;
                              switch (heff_tag_of(v_x31_2429)) {
                              case TAG_MkPair: {
                                V v_x_2430 = heff_field(v_x31_2429, 0);
                                V v_j_2431 = heff_field(v_x31_2429, 1);
                                heff_take_n(v_x31_2429, 3ULL, 2);
                                HeffT2 v_t_2432 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_243, v_j_2431));
                                {
                                  V v_field_2434 = v_t_2432.f[1];
                                  int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                                  if ((v_tag_2433 == ((int64_t)0ULL))) {
                                    V v_x31_2435 = v_field_2434;
                                    switch (heff_tag_of(v_x31_2435)) {
                                    case TAG_MkPair: {
                                      V v_x_2436 = heff_field(v_x31_2435, 0);
                                      V v_j_2437 = heff_field(v_x31_2435, 1);
                                      heff_take_n(v_x31_2435, 3ULL, 2);
                                      HeffT2 v_t_2438 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(v_x_2436, v_s_243, v_j_2437));
                                      {
                                        V v_field_2440 = v_t_2438.f[1];
                                        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                                        if ((v_tag_2439 == ((int64_t)0ULL))) {
                                          V v_x31_2441 = v_field_2440;
                                          switch (heff_tag_of(v_x31_2441)) {
                                          case TAG_MkPair: {
                                            V v_x_2442 = heff_field(v_x31_2441, 0);
                                            V v_j_2443 = heff_field(v_x31_2441, 1);
                                            heff_take_n(v_x31_2441, 3ULL, 2);
                                            V v_x1_2444 = ({ V a_0 = v_hashes_240; V a_1 = v_done_241; V a_2 = v_s_242; V a_3 = v_x_2442; V r_ = (g_heff_2ebuild_2ecache_2eimportsHold(a_0, a_1, a_2, a_3)); heff_drop(v_x_2442); r_; });
                                            if ((heff_dup(v_x1_2444) == NTAG(TAG_True))) {
                                              heff_drop(v_x1_2444);
                                              HeffT2 v_t_2445 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_243, v_j_2443));
                                              {
                                                V v_field_2447 = v_t_2445.f[1];
                                                int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
                                                if ((v_tag_2446 == ((int64_t)0ULL))) {
                                                  V v_x31_2448 = v_field_2447;
                                                  switch (heff_tag_of(v_x31_2448)) {
                                                  case TAG_MkPair: {
                                                    V v_x_2449 = heff_field(v_x31_2448, 0);
                                                    V v_j_2450 = heff_field(v_x31_2448, 1);
                                                    heff_take_n(v_x31_2448, 3ULL, 2);
                                                    HeffT2 v_t_2451 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_24cpr(v_x_2449, v_s_243, v_j_2450));
                                                    {
                                                      V v_field_2453 = v_t_2451.f[1];
                                                      int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
                                                      if ((v_tag_2452 == ((int64_t)0ULL))) {
                                                        V v_x31_2454 = v_field_2453;
                                                        switch (heff_tag_of(v_x31_2454)) {
                                                        case TAG_MkPair: {
                                                          V v_x_2455 = heff_field(v_x31_2454, 0);
                                                          V v_j_2456 = heff_field(v_x31_2454, 1);
                                                          heff_take_n(v_x31_2454, 3ULL, 2);
                                                          V v_x1_2465 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2emeltFrom_24cpr_lam0, 1, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = v_x_2455; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_x_2455); r_; });
                                                          if ((heff_dup(v_x1_2465) == NTAG(TAG_True))) {
                                                            heff_drop(v_x1_2465);
                                                            HeffT2 v_t_2466 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_243, v_j_2456));
                                                            {
                                                              V v_field_2468 = v_t_2466.f[1];
                                                              int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
                                                              if ((v_tag_2467 == ((int64_t)0ULL))) {
                                                                V v_x31_2469 = v_field_2468;
                                                                switch (heff_tag_of(v_x31_2469)) {
                                                                case TAG_MkPair: {
                                                                  V v_x_2470 = heff_field(v_x31_2469, 0);
                                                                  V v_j_2471 = heff_field(v_x31_2469, 1);
                                                                  heff_take_n(v_x31_2469, 3ULL, 2);
                                                                  HeffT2 v_t_2472 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_24cpr(v_x_2470, v_s_243, v_j_2471));
                                                                  {
                                                                    V v_field_2474 = v_t_2472.f[1];
                                                                    int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
                                                                    if ((v_tag_2473 == ((int64_t)0ULL))) {
                                                                      V v_x31_2475 = v_field_2474;
                                                                      switch (heff_tag_of(v_x31_2475)) {
                                                                      case TAG_MkPair: {
                                                                        V v_x_2476 = heff_field(v_x31_2475, 0);
                                                                        V v_j_2477 = heff_field(v_x31_2475, 1);
                                                                        heff_take_n(v_x31_2475, 3ULL, 2);
                                                                        V v_t_2478 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x31_2416_24MkPair, heff_dup(v_x_2476)));
                                                                        V v_t_2479 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str1); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str2); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str3); V a_5 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str4); V a_6 = v_x_2476; V r_ = (g_list_2emap_24s159747708x343809768(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
                                                                        V v_x_2480 = heff_rec_n(3, shape_fixities__defs__hashes, (V[]){v_x_2430, v_t_2478, v_t_2479});
                                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2480, v_j_2477})}});
                                                                      }
                                                                      default: return ((HeffT2){{heff_nomatch(v_x31_2475)}});
                                                                      }
                                                                    } else {
                                                                      heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                                                      heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                                                      heff_drop(v_x_2430);
                                                                      heff_drop(v_field_2474);
                                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                    }
                                                                  }
                                                                }
                                                                default: return ((HeffT2){{heff_nomatch(v_x31_2469)}});
                                                                }
                                                              } else {
                                                                heff_drop(v_s_243);
                                                                heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                                                heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                                                heff_drop(v_x_2430);
                                                                heff_drop(v_field_2468);
                                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                              }
                                                            }
                                                          } else {
                                                            heff_drop(v_s_243);
                                                            heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                                            heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                                            heff_drop(v_x_2430);
                                                            heff_drop(v_j_2456);
                                                            heff_drop(v_x1_2465);
                                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                          }
                                                        }
                                                        default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
                                                        }
                                                      } else {
                                                        heff_drop(v_s_243);
                                                        heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                                        heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                                        heff_drop(v_x_2430);
                                                        heff_drop(v_field_2453);
                                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                      }
                                                    }
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_2448)}});
                                                  }
                                                } else {
                                                  heff_drop(v_s_243);
                                                  heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                                  heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                                  heff_drop(v_x_2430);
                                                  heff_drop(v_field_2447);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              heff_drop(v_s_243);
                                              heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                              heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                              heff_drop(v_x_2430);
                                              heff_drop(v_j_2443);
                                              heff_drop(v_x1_2444);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                                          }
                                        } else {
                                          heff_drop(v_done_241);
                                          heff_drop_rec(v_s_242, 8);
                                          heff_drop(v_s_243);
                                          heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                          heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                          heff_drop(v_x_2430);
                                          heff_drop(v_field_2440);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2435)}});
                                    }
                                  } else {
                                    heff_drop(v_done_241);
                                    heff_drop_rec(v_s_242, 8);
                                    heff_drop(v_s_243);
                                    heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                                    heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                                    heff_drop(v_x_2430);
                                    heff_drop(v_field_2434);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2429)}});
                              }
                            } else {
                              heff_drop(v_done_241);
                              heff_drop_rec(v_s_242, 8);
                              heff_drop(v_s_243);
                              heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                              heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                              heff_drop(v_field_2428);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_done_241);
                          heff_drop_rec(v_s_242, 8);
                          heff_drop(v_s_243);
                          heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                          heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                          heff_drop(v_j_2425);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                      }
                    } else {
                      heff_drop(v_done_241);
                      heff_drop_rec(v_s_242, 8);
                      heff_drop(v_s_243);
                      heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                      heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                      heff_drop(v_x_2419);
                      heff_drop(v_field_2422);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_done_241);
                  heff_drop_rec(v_s_242, 8);
                  heff_drop(v_s_243);
                  heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                  heff_drop(v_j_2418);
                  heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
              }
            } else {
              heff_drop(v_done_241);
              heff_drop_rec(v_s_242, 8);
              heff_drop(v_s_243);
              heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
              heff_drop(v_field_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_done_241);
          heff_drop_rec(v_s_242, 8);
          heff_drop(v_s_243);
          heff_drop(v_j_2410);
          heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_248)}});
      }
    } else {
      heff_drop(v_done_241);
      heff_drop_rec(v_s_242, 8);
      heff_drop(v_s_243);
      heff_drop(v_field_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2ecache_2emeltFrom_24cpr_lam0(V self, V *args) {
  V v_x2_2457 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_x2_2457, 0);
    V v_h_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    HeffT2 v_t_2460 = ({ V a_0 = v_hashes_240; V a_1 = v_k_2458; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_hashes_240); heff_drop(v_k_2458); r_; });
    V v_t_2464;
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_x_2463 = v_field_2462;
        v_t_2464 = v_x_2463;
      } else {
        heff_drop(v_field_2462);
        v_t_2464 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_24cpr_str0);
      }
    }
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2464, v_h_2459, 0));
    heff_drop(v_h_2459);
    heff_drop(v_t_2464);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_2457);
  }
}