// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define LBL_above 293969847
#define LBL_aliases 1464806715
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_key 315609
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_own 320000
#define LBL_renames 1324191545
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
static uint32_t shape_fixities__defs__hashes[] = {LBL_fixities, LBL_defs, LBL_hashes};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
static uint32_t shape_name__key__span__ty__body[] = {LBL_name, LBL_key, LBL_span, LBL_ty, LBL_body};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2ecache_2eallJust(V);
V g_heff_2ebuild_2ecache_2eallJust_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eallJust_clo;
V g_heff_2ebuild_2ecache_2eassocOf(V);
V g_heff_2ebuild_2ecache_2eassocOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eassocOf_clo;
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
V g_heff_2ebuild_2ecache_2efixSig(V);
V g_heff_2ebuild_2ecache_2efixSig_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efixSig_clo;
V g_heff_2ebuild_2ecache_2efreeze(V, V, V, V);
V g_heff_2ebuild_2ecache_2efreeze_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreeze_clo;
V g_heff_2ebuild_2ecache_2efreezeDef(V, V, V);
V g_heff_2ebuild_2ecache_2efreezeDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreezeDef_clo;
V g_heff_2ebuild_2ecache_2efreezeFix(V);
V g_heff_2ebuild_2ecache_2efreezeFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreezeFix_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecache_2eimportsHold(V, V, V);
V g_heff_2ebuild_2ecache_2eimportsHold_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eimportsHold_clo;
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
V g_heff_2ebuild_2ecache_2emeltFrom(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2emeltFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFrom_clo;
V g_heff_2ebuild_2ecache_2eneedsOf(V);
V g_heff_2ebuild_2ecache_2eneedsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eneedsOf_clo;
V g_heff_2ebuild_2ecache_2ensOf(V, V);
V g_heff_2ebuild_2ecache_2ensOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ensOf_clo;
V g_heff_2ebuild_2ecache_2enubCa(V);
V g_heff_2ebuild_2ecache_2enubCa_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2enubCa_clo;
V g_heff_2ebuild_2ecache_2eversion_get(void);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2ecache_2ezipCa(V, V);
V g_heff_2ebuild_2ecache_2ezipCa_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ezipCa_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370710786x897780937(V, V, V, V);
V g_list_2efoldl_24s1370710786x897780937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370710786x897780937_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s196488697x1402130510(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s196488697x1402130510_entry(V self, V *a);
extern Clo g_list_2efoldl_24s196488697x1402130510_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1176007509x671449441(V, V, V, V, V);
V g_list_2emap_24s1176007509x671449441_entry(V self, V *a);
extern Clo g_list_2emap_24s1176007509x671449441_clo;
V g_list_2emap_24s1522665373x570032865(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1522665373x570032865_entry(V self, V *a);
extern Clo g_list_2emap_24s1522665373x570032865_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s2063150796x1704946690(V);
V g_list_2emap_24s2063150796x1704946690_entry(V self, V *a);
extern Clo g_list_2emap_24s2063150796x1704946690_clo;
V g_list_2emap_24s424270175x1918189508(V);
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a);
extern Clo g_list_2emap_24s424270175x1918189508_clo;
V g_list_2emap_24s634984521x2042558081(V);
V g_list_2emap_24s634984521x2042558081_entry(V self, V *a);
extern Clo g_list_2emap_24s634984521x2042558081_clo;
V g_list_2emap_24s738510110x679538579(V, V);
V g_list_2emap_24s738510110x679538579_entry(V self, V *a);
extern Clo g_list_2emap_24s738510110x679538579_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_strLt_get(void);
HEFF_LIT(g_heff_2ebuild_2ecache_2eversion_str0, 18, "heff-cache-port/33");

static V g_heff_2ebuild_2ecache_2eversion_val;
static int g_heff_2ebuild_2ecache_2eversion_st;
static V g_heff_2ebuild_2ecache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ecache_2eversion_str0);
}
V g_heff_2ebuild_2ecache_2eversion_get(void) {
  if (g_heff_2ebuild_2ecache_2eversion_st == 2) return g_heff_2ebuild_2ecache_2eversion_val;
  if (g_heff_2ebuild_2ecache_2eversion_st == 1) heff_fail("defined by itself");
  g_heff_2ebuild_2ecache_2eversion_st = 1;
  g_heff_2ebuild_2ecache_2eversion_val = heff_tr(g_heff_2ebuild_2ecache_2eversion_init());
  g_heff_2ebuild_2ecache_2eversion_st = 2;
  return g_heff_2ebuild_2ecache_2eversion_val;
}
HEFF_LIT(g_heff_2ebuild_2ecache_2eversionDir_str0, 3, "v33");

static V g_heff_2ebuild_2ecache_2eversionDir_val;
static int g_heff_2ebuild_2ecache_2eversionDir_st;
static V g_heff_2ebuild_2ecache_2eversionDir_init(void) {
  return ((V)&g_heff_2ebuild_2ecache_2eversionDir_str0);
}
V g_heff_2ebuild_2ecache_2eversionDir_get(void) {
  if (g_heff_2ebuild_2ecache_2eversionDir_st == 2) return g_heff_2ebuild_2ecache_2eversionDir_val;
  if (g_heff_2ebuild_2ecache_2eversionDir_st == 1) heff_fail("defined by itself");
  g_heff_2ebuild_2ecache_2eversionDir_st = 1;
  g_heff_2ebuild_2ecache_2eversionDir_val = heff_tr(g_heff_2ebuild_2ecache_2eversionDir_init());
  g_heff_2ebuild_2ecache_2eversionDir_st = 2;
  return g_heff_2ebuild_2ecache_2eversionDir_val;
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ehashGo_str0, 1, "-");
Clo g_heff_2ebuild_2ecache_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ehashGo_entry, 4, 0};

V g_heff_2ebuild_2ecache_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_strAppend(heff_intShow(v_a_242), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ehashGo_str0), heff_intShow(v_b_243)));
  } else {
    V v_t_245 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_247 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_248 = heff_intMod(heff_intAdd(v_t_247, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_246;
    V t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ehashGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecache_2enubCa_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2enubCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2enubCa_entry, 1, 0};

V g_heff_2ebuild_2ecache_2enubCa(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecache_2enubCa_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2ebuild_2ecache_2enubCa(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2enubCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2enubCa(a[0]);
}
V g_heff_2ebuild_2ecache_2enubCa_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str4, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str7, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str9, 1, "\012");
V g_heff_2ebuild_2ecache_2edefHashOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2edefHashOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2edefHashOne_entry, 3, 0};

V g_heff_2ebuild_2ecache_2edefHashOne(V v_m_240, V v_c_241, V v_o_242) {
top: ;
  V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_o_242, 1)), v_m_240));
  V v_t_245;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop_rec(v_c_241, 13);
    heff_drop_rec(v_o_242, 2);
    return v_m_240;
  }
  case TAG_False: {
    V v_g_246 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
    V v_k_247 = heff_dup(heff_rfield(v_o_242, 1));
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_247), heff_rfield(v_g_246, 1)));
    V v_t_2412;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(v_k_247, heff_rfield(v_g_246, 2)));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop_rec(v_g_246, 6);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_k2_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        v_t_2412 = ({ V a_0 = v_k2_2410; V b_1 = heff_get_n(v_g_246, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    case TAG_Just: {
      V v_e_2411 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      heff_drop_rec(v_g_246, 6);
      heff_drop(v_k_247);
      v_t_2412 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_e_2411});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop_rec(v_o_242, 2);
      return v_m_240;
    }
    case TAG_Just: {
      V v_e_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_x2_2414 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(heff_rfield(v_e_2413, 1), NTAG(TAG_Nil)));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_x2_2418 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(heff_rfield(v_e_2413, 0)), NTAG(TAG_Nil)));
      V v_t_2421;
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_xs_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str3); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2418);
      }
      V v_t_2422 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_rfield(v_e_2413, 1)));
      V v_t_2423 = (g_heff_2eelab_2erename_2enubFirst(v_t_2422));
      V v_t_2424 = ({ V b_0 = heff_get_n(v_e_2413, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
      V v_t_2425 = (g_heff_2eelab_2erename_2enubFirst(v_t_2424));
      V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2425));
      V v_t_2427 = (g_heff_2ebuild_2ecache_2enubCa(v_t_2426));
      V v_t_2428 = (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2427));
      V v_x2_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2edefHashOne_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_2428));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str7); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      V v_s_2437 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str8), heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str9), v_t_2436))));
      V v_t_2438 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2437, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      HEFF_LAST return g_map_2einsert_24s1341440536x470972936(heff_get_n(v_o_242, 1, 2), v_t_2438, v_m_240);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2edefHashOne(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecache_2edefHashOne_lam0(V self, V *args) {
  V v_k_2429 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2430 = ({ V a_0 = heff_dup(v_k_2429); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2432;
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_Nothing: {
    v_t_2432 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str4);
    break;
  }
  case TAG_Just: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    heff_take_n(v_x2_2430, 1ULL, 1);
    v_t_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x2_2430);
  }
  return heff_strAppend(v_k_2429, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str5), v_t_2432));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str1, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str4, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str5, 2, "#T");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str6, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str9, 1, ",");
V g_heff_2ebuild_2ecache_2ewholeHash_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2ewholeHash_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2ewholeHash_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ewholeHash_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ewholeHash(V v_m_240, V v_c_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_c_241, 0)), ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str0));
  V v_x2_247 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ewholeHash_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), heff_dup(heff_rfield(v_c_241, 7))));
  V v_s_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_s_2410 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_s_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2410, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  V v_t_2412 = heff_strAppend(heff_take_field(v_c_241, 0), ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str5));
  V v_x2_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ewholeHash_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), heff_get_n(v_c_241, 7, 13)));
  V v_s_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_s_2420 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_s_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str9); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2420, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  V v_t_2422 = (g_map_2einsert_24s1341440536x470972936(v_t_2412, v_t_2421, v_m_240));
  return (g_map_2einsert_24s1341440536x470972936(v_t_242, v_t_2411, v_t_2422));
}
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ewholeHash(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2ewholeHash_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = ({ V a_0 = heff_dup(heff_rfield(v_o_243, 1)); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str1);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return heff_strAppend(heff_get_n(v_o_243, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ewholeHash_str2), v_t_246));
}
V g_heff_2ebuild_2ecache_2ewholeHash_lam1(V self, V *args) {
  V v_o_2413 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2414 = ({ V a_0 = heff_dup(heff_rfield(v_o_2413, 1)); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  return heff_strAppend(heff_get_n(v_o_2413, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ewholeHash_str7), v_t_2416));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str1, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str2, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str7, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str8, 1, ">");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str10, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str11, 1, "|");
Clo g_heff_2ebuild_2ecache_2efixSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efixSig_entry, 1, 0};

V g_heff_2ebuild_2ecache_2efixSig(V v_f_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s1522665373x570032865(((V)&g_heff_2ebuild_2ecache_2efixSig_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecache_2efixSig_str1), ((V)&g_heff_2ebuild_2ecache_2efixSig_str2), ((V)&g_heff_2ebuild_2ecache_2efixSig_str3), ((V)&g_heff_2ebuild_2ecache_2efixSig_str4), ((V)&g_heff_2ebuild_2ecache_2efixSig_str5), heff_take_field(v_f_240, 0)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str7); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_list_2emap_24s738510110x679538579(((V)&g_heff_2ebuild_2ecache_2efixSig_str8), heff_get_n(v_f_240, 1, 2)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str10); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efixSig_str11), v_t_248));
}
V g_heff_2ebuild_2ecache_2efixSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2efixSig(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str1, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str2, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str6, 1, ":");
Clo g_heff_2ebuild_2ecache_2efreezeFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreezeFix_entry, 1, 0};

V g_heff_2ebuild_2ecache_2efreezeFix(V v_f_240) {
top: ;
  V v_xs_241 = heff_take_field(v_f_240, 0);
  V v_t_242 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_242), (g_list_2efoldl_24s196488697x1402130510(((V)&g_heff_2ebuild_2ecache_2efreezeFix_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str1), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str2), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str3), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str4), NTAG(TAG_Nil), v_t_243))});
  V v_xs_245 = heff_get_n(v_f_240, 1, 2);
  V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_246), (g_list_2efoldl_24s1370710786x897780937(((V)&g_heff_2ebuild_2ecache_2efreezeFix_str5), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str6), NTAG(TAG_Nil), v_t_247))});
  return (g_prelude_2e_2b_2b(v_t_244, v_t_248));
}
V g_heff_2ebuild_2ecache_2efreezeFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2efreezeFix(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ensOf_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensOf_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensOf_str2, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensOf_str3, 1, "|");
V g_heff_2ebuild_2ecache_2ensOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2ensOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ensOf_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ensOf(V v_done_240, V v_m_241) {
top: ;
  V v_t_243 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2ecache_2ensOf_lam0, 1, 1, (V[]){v_m_241}), v_done_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ecache_2ensOf_str0);
  }
  case TAG_Just: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x2_245 = (g_list_2emap_24s2063150796x1704946690(heff_take_field(v_d_244, 7)));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecache_2ensOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ensOf_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_s_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ensOf_str3), (g_heff_2ebuild_2ecache_2efixSig(heff_get_n(v_d_244, 11, 13)))));
    return (g_heff_2ebuild_2ecache_2ehashGo(v_s_249, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2ecache_2ensOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2ecache_2ensOf(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ebuild_2ecache_2ensOf_lam0(V self, V *args) {
  V v_d_242 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_d_242, 0, 13), v_m_241);
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2eneedsOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2eneedsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eneedsOf_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eneedsOf(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2eneedsOf_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_2422 = (g_heff_2ebuild_2ecache_2enubCa(v_t_2421));
  V v_t_2427 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecache_2eneedsOf_lam1, 1, 1, (V[]){v_c_240}), v_t_2422));
  return (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2427));
}
V g_heff_2ebuild_2ecache_2eneedsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eneedsOf(a[0]);
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_244 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
  V v_k_245 = heff_get_n(v_x_243, 1, 2);
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_245), heff_rfield(v_g_244, 1)));
  V v_t_2420;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_k_245, heff_rfield(v_g_244, 2)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_244, 6);
      v_t_2420 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_k2_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = v_k2_248; V b_1 = heff_get_n(v_g_244, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_e_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2411 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_rfield(v_e_2410, 1)));
        V v_t_2412 = (g_heff_2eelab_2erename_2enubFirst(v_t_2411));
        V v_t_2413 = ({ V b_0 = heff_get_n(v_e_2410, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
        V v_t_2414 = (g_heff_2eelab_2erename_2enubFirst(v_t_2413));
        v_t_2420 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    heff_drop_rec(v_g_244, 6);
    heff_drop(v_k_245);
    V v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_rfield(v_e_2415, 1)));
    V v_t_2417 = (g_heff_2eelab_2erename_2enubFirst(v_t_2416));
    V v_t_2418 = ({ V b_0 = heff_get_n(v_e_2415, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
    V v_t_2419 = (g_heff_2eelab_2erename_2enubFirst(v_t_2418));
    v_t_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_242));
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam1(V self, V *args) {
  V v_k_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2424 = (g_list_2emap_24s634984521x2042558081(heff_get_n(v_c_240, 7, 13)));
  V v_t_2425 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_k_2423}));
  V v_x1_2426 = ({ V a_0 = v_t_2425; V a_1 = v_xs_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2424); r_; });
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str2, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str7, 1, " ");
Clo g_heff_2ebuild_2ecache_2efreezeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreezeDef_entry, 3, 0};

V g_heff_2ebuild_2ecache_2efreezeDef(V v_hashes_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_MkPair: {
      V v_sp_246 = heff_field(v_x32_244, 1);
      V v_ru_24x32_244_24MkPair = heff_take_reuse_n(v_x32_244, 2ULL, 2);
      V v_g_247 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
      V v_k_248 = heff_dup(heff_rfield(v_o_243, 1));
      V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_248), heff_rfield(v_g_247, 1)));
      V v_t_2413;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        V v_t_2410 = (g_map_2elookup_24s1546226666x2146984184(v_k_248, heff_rfield(v_g_247, 2)));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Nothing: {
          heff_drop_rec(v_g_247, 6);
          v_t_2413 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_k2_2411 = heff_field(v_t_2410, 0);
          heff_take_n(v_t_2410, 1ULL, 1);
          v_t_2413 = ({ V a_0 = v_k2_2411; V b_1 = heff_get_n(v_g_247, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        break;
      }
      case TAG_Just: {
        V v_e_2412 = heff_field(v_t_249, 0);
        V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
        heff_drop_rec(v_g_247, 6);
        heff_drop(v_k_248);
        v_t_2413 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_e_2412});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop_rec(v_o_243, 2);
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_sp_246, 2);
        heff_drop_cell(v_ru_24x32_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_2414 = heff_field(v_t_2413, 0);
        V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
        V v_s_2415 = heff_take_field(v_o_243, 0);
        V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_s_2415)));
        V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str0), v_s_2415));
        V v_s_2418 = heff_dup(heff_rfield(v_o_243, 1));
        V v_t_2419 = heff_intShow(heff_strLength(heff_dup(v_s_2418)));
        V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str1), v_s_2418));
        V v_x2_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_get_n(v_o_243, 1, 2), v_hashes_240));
        V v_s_2423;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nothing: {
          v_s_2423 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str2);
          break;
        }
        case TAG_Just: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          heff_take_n(v_x2_2421, 1ULL, 1);
          v_s_2423 = v_x_2422;
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        V v_t_2424 = heff_intShow(heff_strLength(heff_dup(v_s_2423)));
        V v_t_2425 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str3), v_s_2423));
        V v_t_2426 = heff_intShow(heff_take_field(v_sp_246, 0));
        V v_t_2427 = heff_intShow(heff_get_n(v_sp_246, 1, 2));
        V v_x2_2428 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(heff_rfield(v_e_2414, 1), NTAG(TAG_Nil)));
        V v_t_2431;
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_Nil: {
          v_t_2431 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_2429 = heff_field(v_x2_2428, 0);
          V v_xs_2430 = heff_field(v_x2_2428, 1);
          heff_take_n(v_x2_2428, 3ULL, 2);
          v_t_2431 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str5); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2428);
        }
        V v_x2_2432 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_get_n(v_e_2414, 0, 4), NTAG(TAG_Nil)));
        V v_t_2435;
        switch (heff_tag_of(v_x2_2432)) {
        case TAG_Nil: {
          v_t_2435 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2433 = heff_field(v_x2_2432, 0);
          V v_xs_2434 = heff_field(v_x2_2432, 1);
          heff_take_n(v_x2_2432, 3ULL, 2);
          v_t_2435 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str7); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2432);
        }
        V v_t_2436 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
        V v_t_2437 = heff_tag_at_n(v_ru_24x32_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2438})});
        return heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){v_t_2439});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2efreezeDef_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2ecache_2efreezeDef(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2ebuild_2ecache_2ezipCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ezipCa_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ezipCa(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2ebuild_2ecache_2ezipCa(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2ezipCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ezipCa(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecache_2eallJust_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eallJust_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eallJust(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_x2_244 = (g_heff_2ebuild_2ecache_2eallJust(v_x12_242));
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ys_245 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_ys_245})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2eallJust_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eallJust(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str5, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str6, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str9, 1, " ");
V g_heff_2ebuild_2ecache_2efreeze_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2efreeze_lam1(V self, V *args);
V g_heff_2ebuild_2ecache_2efreeze_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecache_2efreeze_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreeze_entry, 4, 0};

V g_heff_2ebuild_2ecache_2efreeze(V v_hashes_240, V v_done_241, V v_s_242, V v_c_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_243, 5)), 6, 9);
  V v_t_245 = (g_heff_2ebuild_2ecache_2ezipCa(heff_dup(heff_rfield(v_c_243, 7)), v_t_244));
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_lam0, 1, 2, (V[]){heff_dup(v_hashes_240), heff_dup(v_c_243)}), v_t_245));
  V v_t_248 = (g_heff_2ebuild_2ecache_2eallJust(v_t_247));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_242, 7);
    heff_drop_rec(v_c_243, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_defs_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ecache_2eversion_get())));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str0), heff_dup(g_heff_2ebuild_2ecache_2eversion_get())));
    V v_s_2412 = heff_take_field(v_s_242, 0);
    V v_t_2413 = heff_intShow(heff_strLength(heff_dup(v_s_2412)));
    V v_t_2414 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str1), v_s_2412));
    V v_s_2415 = (g_heff_2ebuild_2ecache_2ehashGo(heff_dup(heff_rfield(v_c_243, 3)), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_s_2415)));
    V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str2), v_s_2415));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, (g_heff_2ebuild_2ecache_2efreezeFix(heff_dup(heff_rfield(v_c_243, 11))))});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2418})});
    V v_t_2420 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 3)));
    V v_t_2421 = ({ V b_0 = heff_get_n(v_s_242, 4, 7); V a_1 = v_t_2420; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_imps_2422 = heff_get_n(v_t_2421, 0, 3);
    V v_t_2423 = (g_list_2emap_24s424270175x1918189508(v_imps_2422));
    V v_xs_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_lam1, 2, 1, (V[]){heff_dup(v_done_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; })});
    V v_xs_2439 = (g_heff_2ebuild_2ecache_2eneedsOf(v_c_243));
    V v_t_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2439));
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2439));
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2440), ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_lam2, 2, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2441; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2441); r_; })});
    V v_t_2457 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_defs_249));
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_249));
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2457), ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2458; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2458); r_; })});
    V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2456, v_t_2459));
    V v_t_2461 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2460));
    V v_x2_2462 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2461));
    V v_t_2465;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_xs_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      v_t_2465 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str9); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2465});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecache_2efreeze_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2ecache_2efreeze(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ebuild_2ecache_2efreeze_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_hashes_240; V a_1 = v_c_243; V a_2 = v_p_246; V r_ = (g_heff_2ebuild_2ecache_2efreezeDef(a_0, a_1, a_2)); heff_drop(v_hashes_240); r_; });
}
V g_heff_2ebuild_2ecache_2efreeze_lam1(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_done_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2428), ({ V a_0 = v_done_241; V a_1 = v_x_2428; V r_ = (g_heff_2ebuild_2ecache_2ensOf(a_0, a_1)); heff_drop(v_done_241); r_; })});
  V v_t_2437;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_a_2430 = heff_field(v_x1_2429, 0);
    V v_b_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    V v_t_2432 = heff_intShow(heff_strLength(heff_dup(v_a_2430)));
    V v_t_2433 = heff_strAppend(v_t_2432, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str3), v_a_2430));
    V v_t_2434 = heff_intShow(heff_strLength(heff_dup(v_b_2431)));
    V v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str4), v_b_2431));
    V v_t_2436 = heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
    v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2436});
    break;
  }
  default: heff_nomatch(v_x1_2429);
  }
  return (g_prelude_2e_2b_2b(v_t_2437, v_acc_2427));
}
V g_heff_2ebuild_2ecache_2efreeze_lam2(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_x_2443 = args[1];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2444 = ({ V a_0 = heff_dup(v_x_2443); V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
  V v_t_2446;
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_Nothing: {
    v_t_2446 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    heff_take_n(v_x2_2444, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x2_2444);
  }
  V v_x1_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2443, v_t_2446});
  V v_t_2455;
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_MkPair: {
    V v_a_2448 = heff_field(v_x1_2447, 0);
    V v_b_2449 = heff_field(v_x1_2447, 1);
    V v_ru_24x1_2447_24MkPair = heff_take_reuse_n(v_x1_2447, 3ULL, 2);
    V v_t_2450 = heff_intShow(heff_strLength(heff_dup(v_a_2448)));
    V v_t_2451 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str6), v_a_2448));
    V v_t_2452 = heff_intShow(heff_strLength(heff_dup(v_b_2449)));
    V v_t_2453 = heff_strAppend(v_t_2452, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str7), v_b_2449));
    V v_t_2454 = heff_tag_at_n(v_ru_24x1_2447_24MkPair, TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2454});
    break;
  }
  default: heff_nomatch(v_x1_2447);
  }
  return (g_prelude_2e_2b_2b(v_t_2455, v_acc_2442));
}
V g_heff_2ebuild_2ecache_2eassocOf_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam0, 2, 0};
V g_heff_2ebuild_2ecache_2eassocOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam1, 2, 0};
V g_heff_2ebuild_2ecache_2eassocOf_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam2, 2, 0};
Clo g_heff_2ebuild_2ecache_2eassocOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eassocOf(V v_x1_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_x1_240), MK_INT(0LL))) {
    heff_drop(v_x1_240);
    return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam0_clo);
  } else {
    if (heff_intEq_c(heff_dup(v_x1_240), MK_INT(1LL))) {
      heff_drop(v_x1_240);
      return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam1_clo);
    } else {
      if (heff_intEq_c(v_x1_240, MK_INT(2LL))) {
        return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam2_clo);
      } else {
        return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
      }
    }
  }
}
V g_heff_2ebuild_2ecache_2eassocOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eassocOf(a[0]);
}
V g_heff_2ebuild_2ecache_2eassocOf_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocLeft), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ebuild_2ecache_2eassocOf_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_i_247 = args[1];
  heff_drop(v_s_246);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocRight), v_i_247});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
}
V g_heff_2ebuild_2ecache_2eassocOf_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_i_2411 = args[1];
  heff_drop(v_s_2410);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocNone), v_i_2411});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFixGroup_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltFixGroup(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_245));
      V v_x3_2411;
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        v_x3_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_x_2410 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_248));
          v_x3_2411 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_j_249})});
          break;
        }
        default: heff_nomatch(v_x31_247);
        }
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop(v_x_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        heff_take_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          heff_take_n(v_x31_2412, 3ULL, 2);
          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ecache_2emeltFixGroup_lam0, 3, 2, (V[]){v_x_2413, v_x_244}), v_s_240, v_j_2414));
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2411);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltFixGroup(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_lam0(V self, V *args) {
  V v_loosest_2415 = args[0];
  V v_s_2416 = args[1];
  V v_i_2417 = args[2];
  V v_x_2413 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2418 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_2416), v_i_2417));
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_Nothing: {
    heff_drop(v_loosest_2415);
    heff_drop(v_s_2416);
    heff_drop(v_x_2413);
    heff_drop(v_x_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2419 = heff_field(v_x3_2418, 0);
    V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
    switch (heff_tag_of(v_x31_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x31_2419, 0);
      V v_j_2421 = heff_field(v_x31_2419, 1);
      V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
      V v_x3_2422 = (g_heff_2ebuild_2edecoder_2ebind_24s4558495x638074279(heff_dup(v_s_2416), v_j_2421));
      switch (heff_tag_of(v_x3_2422)) {
      case TAG_Nothing: {
        heff_drop(v_loosest_2415);
        heff_drop(v_s_2416);
        heff_drop(v_x_2413);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x3_2418_24Just, 1);
        heff_drop(v_x_2420);
        heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2423 = heff_field(v_x3_2422, 0);
        heff_take_n(v_x3_2422, 1ULL, 1);
        switch (heff_tag_of(v_x31_2423)) {
        case TAG_MkPair: {
          V v_x_2424 = heff_field(v_x31_2423, 0);
          V v_j_2425 = heff_field(v_x31_2423, 1);
          heff_take_n(v_x31_2423, 3ULL, 2);
          V v_m_2426 = (g_heff_2ebuild_2ecache_2eassocOf(v_x_2413));
          V v_x3_2427 = heff_tr(heff_apply(v_m_2426, 2, (V[]){v_s_2416, v_j_2425}));
          switch (heff_tag_of(v_x3_2427)) {
          case TAG_Nothing: {
            heff_drop(v_loosest_2415);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x3_2418_24Just, 1);
            heff_drop(v_x_2420);
            heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
            heff_drop(v_x_2424);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2428 = heff_field(v_x3_2427, 0);
            heff_take_n(v_x3_2427, 1ULL, 1);
            switch (heff_tag_of(v_x31_2428)) {
            case TAG_MkPair: {
              V v_x_2429 = heff_field(v_x31_2428, 0);
              V v_j_2430 = heff_field(v_x31_2428, 1);
              heff_take_n(v_x31_2428, 3ULL, 2);
              V v_t_2431 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){v_x_244, v_x_2429, v_x_2424, v_loosest_2415, v_x_2420}), v_j_2430});
              return heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_Just, 1, (V[]){v_t_2431});
            }
            default: return heff_nomatch(v_x31_2428);
            }
          }
          default: return heff_nomatch(v_x3_2427);
          }
        }
        default: return heff_nomatch(v_x31_2423);
        }
      }
      default: return heff_nomatch(v_x3_2422);
      }
    }
    default: return heff_nomatch(v_x31_2419);
    }
  }
  default: return heff_nomatch(v_x3_2418);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltDef_str0, 1, "\012");
Clo g_heff_2ebuild_2ecache_2emeltDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltDef_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltDef(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_249));
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
            heff_drop_cell(v_ru_24x3_246_24Just, 1);
            heff_drop(v_x_248);
            heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              V v_x3_2414 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_2413));
              V v_x3_2419;
              switch (heff_tag_of(v_x3_2414)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x3_242_24Just, 1);
                v_x3_2419 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2415 = heff_field(v_x3_2414, 0);
                heff_take_n(v_x3_2414, 1ULL, 1);
                switch (heff_tag_of(v_x31_2415)) {
                case TAG_MkPair: {
                  V v_x_2416 = heff_field(v_x31_2415, 0);
                  V v_j_2417 = heff_field(v_x31_2415, 1);
                  heff_take_n(v_x31_2415, 3ULL, 2);
                  V v_x_2418 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_2416));
                  v_x3_2419 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2418, v_j_2417})});
                  break;
                }
                default: heff_nomatch(v_x31_2415);
                }
                break;
              }
              default: heff_nomatch(v_x3_2414);
              }
              switch (heff_tag_of(v_x3_2419)) {
              case TAG_Nothing: {
                heff_drop(v_s_240);
                heff_drop(v_x_244);
                heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                heff_drop_cell(v_ru_24x3_246_24Just, 1);
                heff_drop(v_x_248);
                heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                heff_drop_cell(v_ru_24x3_2410_24Just, 1);
                heff_drop(v_x_2412);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2420 = heff_field(v_x3_2419, 0);
                heff_take_n(v_x3_2419, 1ULL, 1);
                switch (heff_tag_of(v_x31_2420)) {
                case TAG_MkPair: {
                  V v_x_2421 = heff_field(v_x31_2420, 0);
                  V v_j_2422 = heff_field(v_x31_2420, 1);
                  heff_take_n(v_x31_2420, 3ULL, 2);
                  V v_x3_2423 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_2422));
                  V v_x3_2428;
                  switch (heff_tag_of(v_x3_2423)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                    heff_drop_cell(v_ru_24x3_246_24Just, 1);
                    v_x3_2428 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2424 = heff_field(v_x3_2423, 0);
                    heff_take_n(v_x3_2423, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2424)) {
                    case TAG_MkPair: {
                      V v_x_2425 = heff_field(v_x31_2424, 0);
                      V v_j_2426 = heff_field(v_x31_2424, 1);
                      heff_take_n(v_x31_2424, 3ULL, 2);
                      V v_x_2427 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_2425));
                      v_x3_2428 = heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_j_2426})});
                      break;
                    }
                    default: heff_nomatch(v_x31_2424);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2423);
                  }
                  switch (heff_tag_of(v_x3_2428)) {
                  case TAG_Nothing: {
                    heff_drop(v_s_240);
                    heff_drop(v_x_244);
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                    heff_drop_cell(v_ru_24x3_2410_24Just, 1);
                    heff_drop(v_x_2412);
                    heff_drop(v_x_2421);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2429 = heff_field(v_x3_2428, 0);
                    heff_take_n(v_x3_2428, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2429)) {
                    case TAG_MkPair: {
                      V v_x_2430 = heff_field(v_x31_2429, 0);
                      V v_j_2431 = heff_field(v_x31_2429, 1);
                      heff_take_n(v_x31_2429, 3ULL, 2);
                      V v_x3_2432 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_2431));
                      V v_x3_2437;
                      switch (heff_tag_of(v_x3_2432)) {
                      case TAG_Nothing: {
                        v_x3_2437 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2433 = heff_field(v_x3_2432, 0);
                        heff_take_n(v_x3_2432, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2433)) {
                        case TAG_MkPair: {
                          V v_x_2434 = heff_field(v_x31_2433, 0);
                          V v_j_2435 = heff_field(v_x31_2433, 1);
                          heff_take_n(v_x31_2433, 3ULL, 2);
                          V v_t_2436 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2434));
                          v_x3_2437 = heff_tr(heff_apply(v_t_2436, 2, (V[]){heff_dup(v_s_240), v_j_2435}));
                          break;
                        }
                        default: heff_nomatch(v_x31_2433);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2432);
                      }
                      switch (heff_tag_of(v_x3_2437)) {
                      case TAG_Nothing: {
                        heff_drop(v_s_240);
                        heff_drop(v_x_244);
                        heff_drop(v_x_248);
                        heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                        heff_drop_cell(v_ru_24x3_2410_24Just, 1);
                        heff_drop(v_x_2412);
                        heff_drop(v_x_2421);
                        heff_drop(v_x_2430);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2438 = heff_field(v_x3_2437, 0);
                        heff_take_n(v_x3_2437, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2438)) {
                        case TAG_MkPair: {
                          V v_x_2439 = heff_field(v_x31_2438, 0);
                          V v_j_2440 = heff_field(v_x31_2438, 1);
                          heff_take_n(v_x31_2438, 3ULL, 2);
                          V v_x3_2441 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_240), v_j_2440));
                          V v_x3_2446;
                          switch (heff_tag_of(v_x3_2441)) {
                          case TAG_Nothing: {
                            heff_drop(v_s_240);
                            v_x3_2446 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_x31_2442 = heff_field(v_x3_2441, 0);
                            heff_take_n(v_x3_2441, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2442)) {
                            case TAG_MkPair: {
                              V v_x_2443 = heff_field(v_x31_2442, 0);
                              V v_j_2444 = heff_field(v_x31_2442, 1);
                              heff_take_n(v_x31_2442, 3ULL, 2);
                              V v_t_2445 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2443));
                              v_x3_2446 = heff_tr(heff_apply(v_t_2445, 2, (V[]){v_s_240, v_j_2444}));
                              break;
                            }
                            default: heff_nomatch(v_x31_2442);
                            }
                            break;
                          }
                          default: heff_nomatch(v_x3_2441);
                          }
                          switch (heff_tag_of(v_x3_2446)) {
                          case TAG_Nothing: {
                            heff_drop(v_x_244);
                            heff_drop(v_x_248);
                            heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                            heff_drop_cell(v_ru_24x3_2410_24Just, 1);
                            heff_drop(v_x_2412);
                            heff_drop(v_x_2421);
                            heff_drop(v_x_2430);
                            heff_drop(v_x_2439);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_2447 = heff_field(v_x3_2446, 0);
                            heff_take_n(v_x3_2446, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2447)) {
                            case TAG_MkPair: {
                              V v_x_2448 = heff_field(v_x31_2447, 0);
                              V v_j_2449 = heff_field(v_x31_2447, 1);
                              heff_take_n(v_x31_2447, 3ULL, 2);
                              V v_t_2450 = heff_rec_n(5, shape_name__key__span__ty__body, (V[]){v_x_244, heff_dup(v_x_248), heff_rec_n(2, shape_start__end, (V[]){v_x_2421, v_x_2430}), v_x_2439, v_x_2448});
                              V v_t_2451 = heff_strAppend(v_x_248, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2emeltDef_str0), v_x_2412));
                              V v_t_2452 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_t_2451}), v_j_2449});
                              return heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_Just, 1, (V[]){v_t_2452});
                            }
                            default: return heff_nomatch(v_x31_2447);
                            }
                          }
                          default: return heff_nomatch(v_x3_2446);
                          }
                        }
                        default: return heff_nomatch(v_x31_2438);
                        }
                      }
                      default: return heff_nomatch(v_x3_2437);
                      }
                    }
                    default: return heff_nomatch(v_x31_2429);
                    }
                  }
                  default: return heff_nomatch(v_x3_2428);
                  }
                }
                default: return heff_nomatch(v_x31_2420);
                }
              }
              default: return heff_nomatch(v_x3_2419);
              }
            }
            default: return heff_nomatch(v_x31_2411);
            }
          }
          default: return heff_nomatch(v_x3_2410);
          }
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltDef(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2eimportsHold_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2eimportsHold_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eimportsHold_entry, 3, 0};

V g_heff_2ebuild_2ecache_2eimportsHold(V v_done_240, V v_s_241, V v_ns_242) {
top: ;
  V v_t_247 = (g_list_2eall(heff_clo_n(g_heff_2ebuild_2ecache_2eimportsHold_lam0, 1, 1, (V[]){heff_dup(v_done_240)}), v_ns_242));
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ns_242));
    V v_t_249 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_s_241, 5), heff_take_field(v_s_241, 3)));
    V v_t_2410 = ({ V b_0 = heff_get_n(v_s_241, 4, 7); V a_1 = v_t_249; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_imps_2411 = heff_get_n(v_t_2410, 0, 3);
    V v_t_2412 = (g_list_2emap_24s424270175x1918189508(v_imps_2411));
    V v_xs_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
    V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2413; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    return heff_intEq(v_t_248, v_t_2414);
  }
  case TAG_False: {
    heff_drop_rec(v_s_241, 7);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ebuild_2ecache_2eimportsHold_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2ecache_2eimportsHold(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[2]); return r;
}
V g_heff_2ebuild_2ecache_2eimportsHold_lam0(V self, V *args) {
  V v_x2_243 = args[0];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_m_244 = heff_field(v_x2_243, 0);
    V v_h_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_t_246 = ({ V a_0 = v_done_240; V a_1 = v_m_244; V r_ = (g_heff_2ebuild_2ecache_2ensOf(a_0, a_1)); heff_drop(v_done_240); r_; });
    return heff_strEq(v_t_246, v_h_245);
  }
  default: return heff_nomatch(v_x2_243);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str2, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str3, 1, "\?");
V g_heff_2ebuild_2ecache_2emeltFrom_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2emeltFrom_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecache_2emeltFrom_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFrom_lam2, 2, 0};
V g_heff_2ebuild_2ecache_2emeltFrom_lam3(V self, V *args);
V g_heff_2ebuild_2ecache_2emeltFrom_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecache_2emeltFrom_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFrom_lam4, 2, 0};
V g_heff_2ebuild_2ecache_2emeltFrom_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFrom_entry, 5, 0};

V g_heff_2ebuild_2ecache_2emeltFrom(V v_hashes_240, V v_done_241, V v_s_242, V v_s_243, V v_i_244) {
top: ;
  V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_243), v_i_244));
  V v_x3_2411;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    v_x3_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      if (heff_strEq_c(v_x_247, heff_dup(g_heff_2ebuild_2ecache_2eversion_get()))) {
        V v_t_2410 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_248});
        v_x3_2411 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2410});
      } else {
        heff_drop_cell(v_ru_24x3_245_24Just, 1);
        heff_drop(v_j_248);
        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
        v_x3_2411 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x31_246);
    }
    break;
  }
  default: heff_nomatch(v_x3_245);
  }
  switch (heff_tag_of(v_x3_2411)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_242, 7);
    heff_drop(v_s_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2412 = heff_field(v_x3_2411, 0);
    V v_ru_24x3_2411_24Just = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_MkPair: {
      V v_j_2414 = heff_field(v_x31_2412, 1);
      V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 2ULL, 2);
      V v_x3_2415 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_243), v_j_2414));
      V v_x3_2421;
      switch (heff_tag_of(v_x3_2415)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_2411_24Just, 1);
        heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
        v_x3_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2416 = heff_field(v_x3_2415, 0);
        heff_take_n(v_x3_2415, 1ULL, 1);
        switch (heff_tag_of(v_x31_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x31_2416, 0);
          V v_j_2418 = heff_field(v_x31_2416, 1);
          heff_take_n(v_x31_2416, 3ULL, 2);
          if (heff_strEq_c(v_x_2417, heff_dup(heff_rfield(v_s_242, 0)))) {
            V v_t_2420 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_2418});
            v_x3_2421 = heff_tag_at_n(v_ru_24x3_2411_24Just, TAG_Just, 1, (V[]){v_t_2420});
          } else {
            heff_drop_cell(v_ru_24x3_2411_24Just, 1);
            heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
            heff_drop(v_j_2418);
            v_x3_2421 = NTAG(TAG_Nothing);
          }
          break;
        }
        default: heff_nomatch(v_x31_2416);
        }
        break;
      }
      default: heff_nomatch(v_x3_2415);
      }
      switch (heff_tag_of(v_x3_2421)) {
      case TAG_Nothing: {
        heff_drop_rec(v_s_242, 7);
        heff_drop(v_s_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2422 = heff_field(v_x3_2421, 0);
        heff_take_n(v_x3_2421, 1ULL, 1);
        switch (heff_tag_of(v_x31_2422)) {
        case TAG_MkPair: {
          V v_j_2424 = heff_field(v_x31_2422, 1);
          heff_take_n(v_x31_2422, 2ULL, 2);
          V v_x_2425 = (g_heff_2ebuild_2ecache_2ehashGo(heff_dup(heff_rfield(v_s_242, 3)), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
          V v_m_2434 = heff_clo_n(g_heff_2ebuild_2ecache_2emeltFrom_lam0, 2, 1, (V[]){v_x_2425});
          V v_x3_2435 = heff_tr(heff_apply(v_m_2434, 2, (V[]){heff_dup(v_s_243), v_j_2424}));
          switch (heff_tag_of(v_x3_2435)) {
          case TAG_Nothing: {
            heff_drop_rec(v_s_242, 7);
            heff_drop(v_s_243);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2436 = heff_field(v_x3_2435, 0);
            heff_take_n(v_x3_2435, 1ULL, 1);
            switch (heff_tag_of(v_x31_2436)) {
            case TAG_MkPair: {
              V v_j_2438 = heff_field(v_x31_2436, 1);
              heff_take_n(v_x31_2436, 2ULL, 2);
              return (g_heff_2ebuild_2edecoder_2ebind_24s175898238x1158484984(heff_clo_n(g_heff_2ebuild_2ecache_2emeltFrom_lam1, 3, 3, (V[]){heff_dup(v_done_241), v_s_242, heff_dup(v_hashes_240)}), v_s_243, v_j_2438));
            }
            default: return heff_nomatch(v_x31_2436);
            }
          }
          default: return heff_nomatch(v_x3_2435);
          }
        }
        default: return heff_nomatch(v_x31_2422);
        }
      }
      default: return heff_nomatch(v_x3_2421);
      }
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_x3_2411);
  }
}
V g_heff_2ebuild_2ecache_2emeltFrom_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ebuild_2ecache_2emeltFrom(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
V g_heff_2ebuild_2ecache_2emeltFrom_lam0(V self, V *args) {
  V v_s_2426 = args[0];
  V v_i_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2428 = (g_heff_2ebuild_2edecoder_2estr(v_s_2426, v_i_2427));
  switch (heff_tag_of(v_x3_2428)) {
  case TAG_Nothing: {
    heff_drop(v_x_2425);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2429 = heff_field(v_x3_2428, 0);
    V v_ru_24x3_2428_24Just = heff_take_reuse_n(v_x3_2428, 1ULL, 1);
    switch (heff_tag_of(v_x31_2429)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x31_2429, 0);
      V v_j_2431 = heff_field(v_x31_2429, 1);
      V v_ru_24x31_2429_24MkPair = heff_take_reuse_n(v_x31_2429, 3ULL, 2);
      if (heff_strEq_c(v_x_2430, v_x_2425)) {
        V v_t_2433 = heff_tag_at_n(v_ru_24x31_2429_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_2431});
        return heff_tag_at_n(v_ru_24x3_2428_24Just, TAG_Just, 1, (V[]){v_t_2433});
      } else {
        heff_drop_cell(v_ru_24x3_2428_24Just, 1);
        heff_drop(v_j_2431);
        heff_drop_cell(v_ru_24x31_2429_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x31_2429);
    }
  }
  default: return heff_nomatch(v_x3_2428);
  }
}
V g_heff_2ebuild_2ecache_2emeltFrom_lam2(V self, V *args) {
  V v_s_2447 = args[0];
  V v_i_2448 = args[1];
  heff_drop(v_s_2447);
  V v_t_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_i_2448});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2449});
}
V g_heff_2ebuild_2ecache_2emeltFrom_lam3(V self, V *args) {
  V v_x2_2459 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_k_2460 = heff_field(v_x2_2459, 0);
    V v_h_2461 = heff_field(v_x2_2459, 1);
    heff_take_n(v_x2_2459, 3ULL, 2);
    V v_x2_2462 = ({ V a_0 = v_k_2460; V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
    V v_t_2464;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nothing: {
      v_t_2464 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      heff_take_n(v_x2_2462, 1ULL, 1);
      v_t_2464 = v_x_2463;
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    return heff_strEq(v_t_2464, v_h_2461);
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ebuild_2ecache_2emeltFrom_lam4(V self, V *args) {
  V v_s_2466 = args[0];
  V v_i_2467 = args[1];
  heff_drop(v_s_2466);
  V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_i_2467});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2468});
}
V g_heff_2ebuild_2ecache_2emeltFrom_lam1(V self, V *args) {
  V v_fixities_2439 = args[0];
  V v_s_2440 = args[1];
  V v_i_2441 = args[2];
  V v_done_241 = heff_env(self)[0];
  V v_s_242 = heff_env(self)[1];
  V v_hashes_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x3_2442 = (g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168(heff_dup(v_s_2440), v_i_2441));
  switch (heff_tag_of(v_x3_2442)) {
  case TAG_Nothing: {
    heff_drop(v_fixities_2439);
    heff_drop(v_s_2440);
    heff_drop(v_done_241);
    heff_drop_rec(v_s_242, 7);
    heff_drop(v_hashes_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2443 = heff_field(v_x3_2442, 0);
    V v_ru_24x3_2442_24Just = heff_take_reuse_n(v_x3_2442, 1ULL, 1);
    switch (heff_tag_of(v_x31_2443)) {
    case TAG_MkPair: {
      V v_x_2444 = heff_field(v_x31_2443, 0);
      V v_j_2445 = heff_field(v_x31_2443, 1);
      heff_take_n(v_x31_2443, 3ULL, 2);
      V v_x1_2446 = ({ V a_0 = v_done_241; V a_1 = v_s_242; V a_2 = v_x_2444; V r_ = (g_heff_2ebuild_2ecache_2eimportsHold(a_0, a_1, a_2)); heff_drop(v_done_241); heff_drop(v_x_2444); r_; });
      V v_m_2450;
      switch (heff_tag_of(v_x1_2446)) {
      case TAG_True: {
        v_m_2450 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_lam2_clo);
        break;
      }
      case TAG_False: {
        v_m_2450 = ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
        break;
      }
      default: heff_nomatch(v_x1_2446);
      }
      V v_x3_2451 = heff_tr(heff_apply(v_m_2450, 2, (V[]){heff_dup(v_s_2440), v_j_2445}));
      switch (heff_tag_of(v_x3_2451)) {
      case TAG_Nothing: {
        heff_drop(v_fixities_2439);
        heff_drop(v_s_2440);
        heff_drop(v_hashes_240);
        heff_drop_cell(v_ru_24x3_2442_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2452 = heff_field(v_x3_2451, 0);
        heff_take_n(v_x3_2451, 1ULL, 1);
        switch (heff_tag_of(v_x31_2452)) {
        case TAG_MkPair: {
          V v_j_2454 = heff_field(v_x31_2452, 1);
          heff_take_n(v_x31_2452, 2ULL, 2);
          V v_x3_2455 = (g_heff_2ebuild_2edecoder_2ebind_24s1423786112x2002309168(heff_dup(v_s_2440), v_j_2454));
          switch (heff_tag_of(v_x3_2455)) {
          case TAG_Nothing: {
            heff_drop(v_fixities_2439);
            heff_drop(v_s_2440);
            heff_drop(v_hashes_240);
            heff_drop_cell(v_ru_24x3_2442_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2456 = heff_field(v_x3_2455, 0);
            heff_take_n(v_x3_2455, 1ULL, 1);
            switch (heff_tag_of(v_x31_2456)) {
            case TAG_MkPair: {
              V v_x_2457 = heff_field(v_x31_2456, 0);
              V v_j_2458 = heff_field(v_x31_2456, 1);
              heff_take_n(v_x31_2456, 3ULL, 2);
              V v_x1_2465 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2emeltFrom_lam3, 1, 1, (V[]){v_hashes_240}); V a_1 = v_x_2457; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_x_2457); r_; });
              V v_m_2469;
              switch (heff_tag_of(v_x1_2465)) {
              case TAG_True: {
                v_m_2469 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_lam4_clo);
                break;
              }
              case TAG_False: {
                v_m_2469 = ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
                break;
              }
              default: heff_nomatch(v_x1_2465);
              }
              V v_x3_2470 = heff_tr(heff_apply(v_m_2469, 2, (V[]){heff_dup(v_s_2440), v_j_2458}));
              switch (heff_tag_of(v_x3_2470)) {
              case TAG_Nothing: {
                heff_drop(v_fixities_2439);
                heff_drop(v_s_2440);
                heff_drop_cell(v_ru_24x3_2442_24Just, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2471 = heff_field(v_x3_2470, 0);
                heff_take_n(v_x3_2470, 1ULL, 1);
                switch (heff_tag_of(v_x31_2471)) {
                case TAG_MkPair: {
                  V v_j_2473 = heff_field(v_x31_2471, 1);
                  heff_take_n(v_x31_2471, 2ULL, 2);
                  V v_x3_2474 = (g_heff_2ebuild_2edecoder_2ebind_24s1960447580x1521569455(v_s_2440, v_j_2473));
                  switch (heff_tag_of(v_x3_2474)) {
                  case TAG_Nothing: {
                    heff_drop(v_fixities_2439);
                    heff_drop_cell(v_ru_24x3_2442_24Just, 1);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2475 = heff_field(v_x3_2474, 0);
                    heff_take_n(v_x3_2474, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2475)) {
                    case TAG_MkPair: {
                      V v_x_2476 = heff_field(v_x31_2475, 0);
                      V v_j_2477 = heff_field(v_x31_2475, 1);
                      heff_take_n(v_x31_2475, 3ULL, 2);
                      V v_t_2478 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2476)));
                      V v_t_2479 = (g_list_2emap_24s1176007509x671449441(((V)&g_heff_2ebuild_2ecache_2emeltFrom_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecache_2emeltFrom_str2), ((V)&g_heff_2ebuild_2ecache_2emeltFrom_str3), v_x_2476));
                      V v_x_2480 = heff_rec_n(3, shape_fixities__defs__hashes, (V[]){v_fixities_2439, v_t_2478, v_t_2479});
                      return heff_tag_at_n(v_ru_24x3_2442_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2480, v_j_2477})});
                    }
                    default: return heff_nomatch(v_x31_2475);
                    }
                  }
                  default: return heff_nomatch(v_x3_2474);
                  }
                }
                default: return heff_nomatch(v_x31_2471);
                }
              }
              default: return heff_nomatch(v_x3_2470);
              }
            }
            default: return heff_nomatch(v_x31_2456);
            }
          }
          default: return heff_nomatch(v_x3_2455);
          }
        }
        default: return heff_nomatch(v_x31_2452);
        }
      }
      default: return heff_nomatch(v_x3_2451);
      }
    }
    default: return heff_nomatch(v_x31_2443);
    }
  }
  default: return heff_nomatch(v_x3_2442);
  }
}