// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define LBL_above 293969847
#define LBL_aliases 1464806715
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_defs 9574869
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_instances 1653559473
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_ops 319788
#define LBL_own 320000
#define LBL_renames 1324191545
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
static uint32_t shape_fixities__defs__hashes[] = {LBL_fixities, LBL_defs, LBL_hashes};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
static uint32_t shape_name__key__isInstance__span__ty__body[] = {LBL_name, LBL_key, LBL_isInstance, LBL_span, LBL_ty, LBL_body};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2ecache_2eallJust(V);
V g_heff_2ebuild_2ecache_2eallJust_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eallJust_clo;
V g_heff_2ebuild_2ecache_2eassocOf(V);
V g_heff_2ebuild_2ecache_2eassocOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eassocOf_clo;
V g_heff_2ebuild_2ecache_2edefHashOne(V, V, V);
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2edefHashOne_clo;
V g_heff_2ebuild_2ecache_2efixSig(V);
V g_heff_2ebuild_2ecache_2efixSig_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efixSig_clo;
V g_heff_2ebuild_2ecache_2efreeze(V, V, V, V);
V g_heff_2ebuild_2ecache_2efreeze_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreeze_clo;
V g_heff_2ebuild_2ecache_2efreezeDef(V, V, V);
V g_heff_2ebuild_2ecache_2efreezeDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreezeDef_clo;
V g_heff_2ebuild_2ecache_2efreezeFix(V);
V g_heff_2ebuild_2ecache_2efreezeFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2efreezeFix_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecache_2eimportsHold(V, V, V, V);
V g_heff_2ebuild_2ecache_2eimportsHold_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eimportsHold_clo;
V g_heff_2ebuild_2ecache_2einstanceSig(V, V, V);
V g_heff_2ebuild_2ecache_2einstanceSig_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2einstanceSig_clo;
V g_heff_2ebuild_2ecache_2emeltDef(V, V);
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltDef_clo;
V g_heff_2ebuild_2ecache_2emeltFix(V, V);
V g_heff_2ebuild_2ecache_2emeltFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFix_clo;
V g_heff_2ebuild_2ecache_2emeltFixGroup(V, V);
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo;
V g_heff_2ebuild_2ecache_2emeltFrom(V, V, V, V, V);
V g_heff_2ebuild_2ecache_2emeltFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2emeltFrom_clo;
V g_heff_2ebuild_2ecache_2eneedsOf(V);
V g_heff_2ebuild_2ecache_2eneedsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2eneedsOf_clo;
V g_heff_2ebuild_2ecache_2ensHashOf(V, V);
V g_heff_2ebuild_2ecache_2ensHashOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ensHashOf_clo;
V g_heff_2ebuild_2ecache_2enubCa(V);
V g_heff_2ebuild_2ecache_2enubCa_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2enubCa_clo;
V g_heff_2ebuild_2ecache_2enubCa_24dps(V, V);
V g_heff_2ebuild_2ecache_2enubCa_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2enubCa_24dps_clo;
V g_heff_2ebuild_2ecache_2eversion_get(void);
V g_heff_2ebuild_2ecache_2eversionDir_get(void);
V g_heff_2ebuild_2ecache_2ewholeHash(V, V);
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ewholeHash_clo;
V g_heff_2ebuild_2ecache_2ezipCa(V, V);
V g_heff_2ebuild_2ecache_2ezipCa_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ezipCa_clo;
V g_heff_2ebuild_2ecache_2ezipCa_24dps(V, V, V);
V g_heff_2ebuild_2ecache_2ezipCa_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ezipCa_24dps_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1868716698x184030185(V, V);
V g_list_2eany_24s1868716698x184030185_entry(V self, V *a);
extern Clo g_list_2eany_24s1868716698x184030185_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efind_24s487054388x274730225(V, V);
V g_list_2efind_24s487054388x274730225_entry(V self, V *a);
extern Clo g_list_2efind_24s487054388x274730225_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f700195413x1431112932(V, V, V);
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a);
extern Clo g_list_2efoldl_24f700195413x1431112932_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s518608766x1858781247(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s518608766x1858781247_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518608766x1858781247_clo;
V g_list_2efoldl_24s655081849x360568693(V, V, V, V);
V g_list_2efoldl_24s655081849x360568693_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655081849x360568693_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1260271301x348779032(V, V);
V g_list_2emap_24f1260271301x348779032_entry(V self, V *a);
extern Clo g_list_2emap_24f1260271301x348779032_clo;
V g_list_2emap_24s1418045490x2076674085(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1418045490x2076674085_entry(V self, V *a);
extern Clo g_list_2emap_24s1418045490x2076674085_clo;
V g_list_2emap_24s1492905679x736823775(V, V, V, V, V);
V g_list_2emap_24s1492905679x736823775_entry(V self, V *a);
extern Clo g_list_2emap_24s1492905679x736823775_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s564507054x318389057(V, V);
V g_list_2emap_24s564507054x318389057_entry(V self, V *a);
extern Clo g_list_2emap_24s564507054x318389057_clo;
V g_list_2esortBy(V, V);
V g_list_2esortBy_entry(V self, V *a);
extern Clo g_list_2esortBy_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_strLt_get(void);
HEFF_LIT(g_heff_2ebuild_2ecache_2eversion_str0, 18, "heff-cache-port/49");

static V g_heff_2ebuild_2ecache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ecache_2eversion_st;
static V g_heff_2ebuild_2ecache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ecache_2eversion_str0);
}
V g_heff_2ebuild_2ecache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecache_2eversion_st)) return g_heff_2ebuild_2ecache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ecache_2eversion_val, &g_heff_2ebuild_2ecache_2eversion_st, g_heff_2ebuild_2ecache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2eversionDir_str0, 3, "v49");

static V g_heff_2ebuild_2ecache_2eversionDir_val;
static HEFF_ONCE g_heff_2ebuild_2ecache_2eversionDir_st;
static V g_heff_2ebuild_2ecache_2eversionDir_init(void) {
  return ((V)&g_heff_2ebuild_2ecache_2eversionDir_str0);
}
V g_heff_2ebuild_2ecache_2eversionDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecache_2eversionDir_st)) return g_heff_2ebuild_2ecache_2eversionDir_val;
  return heff_global(&g_heff_2ebuild_2ecache_2eversionDir_val, &g_heff_2ebuild_2ecache_2eversionDir_st, g_heff_2ebuild_2ecache_2eversionDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ehashGo_str0, 1, "-");
Clo g_heff_2ebuild_2ecache_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ehashGo_entry, 4, 0};

V g_heff_2ebuild_2ecache_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ehashGo_str0), heff_intShow(v_b_243));
    return heff_strAppend(heff_intShow(v_a_242), v_t_245);
  } else {
    V v_t_246 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_247 = heff_intMod(heff_intAdd(v_t_246, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_248 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_249 = heff_intMod(heff_intAdd(v_t_248, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_247;
    V t_3 = v_t_249;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ehashGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2ecache_2enubCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2enubCa_entry, 1, 0};

V g_heff_2ebuild_2ecache_2enubCa(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s727803713x1346936525(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2ebuild_2ecache_2enubCa_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2enubCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2enubCa(a[0]);
}
Clo g_heff_2ebuild_2ecache_2enubCa_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2enubCa_24dps_entry, 2, 0};

V g_heff_2ebuild_2ecache_2enubCa_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s727803713x1346936525(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2enubCa_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2enubCa_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str4, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str7, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2edefHashOne_str9, 1, "\012");
V g_heff_2ebuild_2ecache_2edefHashOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2edefHashOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2edefHashOne_entry, 3, 0};

V g_heff_2ebuild_2ecache_2edefHashOne(V v_m_240, V v_c_241, V v_o_242) {
top: ;
  V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_o_242, 1)), v_m_240));
  V v_t_245;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop_rec(v_c_241, 13);
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_t_245);
    return v_m_240;
  } else {
    heff_drop(v_t_245);
    V v_g_246 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
    V v_k_247 = heff_dup(heff_rfield(v_o_242, 1));
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_247), heff_rfield(v_g_246, 1)));
    V v_t_2412;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(v_k_247, heff_rfield(v_g_246, 2)));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop_rec(v_g_246, 7);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_k2_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        v_t_2412 = ({ V a_0 = v_k2_2410; V b_1 = heff_get_n(v_g_246, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    case TAG_Just: {
      V v_e_2411 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      heff_drop_rec(v_g_246, 7);
      heff_drop(v_k_247);
      v_t_2412 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_e_2411});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      heff_drop_rec(v_o_242, 2);
      return v_m_240;
    }
    case TAG_Just: {
      V v_e_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_x2_2414 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(heff_rfield(v_e_2413, 1), NTAG(TAG_Nil)));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str1); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_x2_2418 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(heff_rfield(v_e_2413, 0)), NTAG(TAG_Nil)));
      V v_t_2421;
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_xs_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str3); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2418);
      }
      V v_t_2422 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_rfield(v_e_2413, 1)));
      V v_t_2423 = (g_heff_2eelab_2erename_2enubFirst(v_t_2422));
      V v_t_2424 = ({ V b_0 = heff_get_n(v_e_2413, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
      V v_t_2425 = (g_heff_2eelab_2erename_2enubFirst(v_t_2424));
      V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2423, v_t_2425));
      V v_t_2427 = (g_heff_2ebuild_2ecache_2enubCa(v_t_2426));
      V v_t_2428 = (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2427));
      V v_x2_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2edefHashOne_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_t_2428));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str7); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      V v_t_2437 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str8), v_t_2436));
      V v_s_2438 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str9), v_t_2437));
      V v_t_2439 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2438, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      HEFF_LAST return g_map_2einsert_24s1341440536x470972936(heff_get_n(v_o_242, 1, 2), v_t_2439, v_m_240);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
}
V g_heff_2ebuild_2ecache_2edefHashOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2edefHashOne(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecache_2edefHashOne_lam0(V self, V *args) {
  V v_k_2429 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2430 = ({ V a_0 = heff_dup(v_k_2429); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2432;
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_Nothing: {
    v_t_2432 = ((V)&g_heff_2ebuild_2ecache_2edefHashOne_str4);
    break;
  }
  case TAG_Just: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    heff_take_n(v_x2_2430, 1ULL, 1);
    v_t_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x2_2430);
  }
  return heff_strAppend(v_k_2429, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2edefHashOne_str5), v_t_2432));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str1, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str4, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str5, 2, "#T");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str6, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ewholeHash_str9, 1, ",");
V g_heff_2ebuild_2ecache_2ewholeHash_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2ewholeHash_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2ewholeHash_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ewholeHash_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ewholeHash(V v_m_240, V v_c_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_c_241, 0)), ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str0));
  V v_x2_247 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ewholeHash_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), heff_dup(heff_rfield(v_c_241, 7))));
  V v_s_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_s_2410 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_s_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2410, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  V v_t_2412 = heff_strAppend(heff_take_field(v_c_241, 0), ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str5));
  V v_x2_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ewholeHash_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), heff_get_n(v_c_241, 7, 13)));
  V v_s_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_s_2420 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_s_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str9); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2420, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
  V v_t_2422 = (g_map_2einsert_24s1341440536x470972936(v_t_2412, v_t_2421, v_m_240));
  return (g_map_2einsert_24s1341440536x470972936(v_t_242, v_t_2411, v_t_2422));
}
V g_heff_2ebuild_2ecache_2ewholeHash_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ewholeHash(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2ewholeHash_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_244 = ({ V a_0 = heff_dup(heff_rfield(v_o_243, 1)); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str1);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return heff_strAppend(heff_get_n(v_o_243, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ewholeHash_str2), v_t_246));
}
V g_heff_2ebuild_2ecache_2ewholeHash_lam1(V self, V *args) {
  V v_o_2413 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2414 = ({ V a_0 = heff_dup(heff_rfield(v_o_2413, 1)); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecache_2ewholeHash_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  return heff_strAppend(heff_get_n(v_o_2413, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ewholeHash_str7), v_t_2416));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str1, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str2, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str7, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str8, 1, ">");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str10, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecache_2efixSig_str11, 1, "|");
Clo g_heff_2ebuild_2ecache_2efixSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efixSig_entry, 1, 0};

V g_heff_2ebuild_2ecache_2efixSig(V v_f_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s1418045490x2076674085(((V)&g_heff_2ebuild_2ecache_2efixSig_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecache_2efixSig_str1), ((V)&g_heff_2ebuild_2ecache_2efixSig_str2), ((V)&g_heff_2ebuild_2ecache_2efixSig_str3), ((V)&g_heff_2ebuild_2ecache_2efixSig_str4), ((V)&g_heff_2ebuild_2ecache_2efixSig_str5), heff_take_field(v_f_240, 0)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str7); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_list_2emap_24s564507054x318389057(((V)&g_heff_2ebuild_2ecache_2efixSig_str8), heff_get_n(v_f_240, 1, 2)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efixSig_str10); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efixSig_str11), v_t_248));
}
V g_heff_2ebuild_2ecache_2efixSig_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2efixSig(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str2, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str5, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2einstanceSig_str7, 1, ":");
V g_heff_2ebuild_2ecache_2einstanceSig_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2einstanceSig_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2einstanceSig_entry, 3, 0};

V g_heff_2ebuild_2ecache_2einstanceSig(V v_hashes_240, V v_c_241, V v_k_242) {
top: ;
  V v_g_243 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
  V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_242), heff_rfield(v_g_243, 1)));
  V v_t_248;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_242), heff_rfield(v_g_243, 2)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_243, 7);
      v_t_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_k2_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      v_t_248 = ({ V a_0 = v_k2_246; V b_1 = heff_get_n(v_g_243, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  case TAG_Just: {
    V v_e_247 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    heff_drop_rec(v_g_243, 7);
    v_t_248 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_e_247});
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    return v_k_242;
  }
  case TAG_Just: {
    V v_e_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_x2_2410 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(heff_rfield(v_e_249, 1), NTAG(TAG_Nil)));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_t_2414 = ({ V b_0 = heff_get_n(v_e_249, 1, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(b_0)); heff_drop(b_0); r_; });
    V v_t_2415 = (g_heff_2eelab_2erename_2enubFirst(v_t_2414));
    V v_t_2416 = (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2415));
    V v_x2_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2einstanceSig_lam0, 1, 1, (V[]){heff_dup(v_hashes_240)}), v_t_2416));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str5); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_s_2425 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2einstanceSig_str6), v_t_2424));
    V v_t_2426 = (g_heff_2ebuild_2ecache_2ehashGo(v_s_2425, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    return heff_strAppend(v_k_242, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2einstanceSig_str7), v_t_2426));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecache_2einstanceSig_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2einstanceSig(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecache_2einstanceSig_lam0(V self, V *args) {
  V v_r_2417 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = ({ V a_0 = heff_dup(v_r_2417); V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    v_t_2420 = ((V)&g_heff_2ebuild_2ecache_2einstanceSig_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    heff_take_n(v_x2_2418, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  return heff_strAppend(v_r_2417, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2einstanceSig_str3), v_t_2420));
}
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str1, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str3, 1, ",");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str4, 1, "|");
HEFF_LIT(g_heff_2ebuild_2ecache_2ensHashOf_str5, 1, "|");
V g_heff_2ebuild_2ecache_2ensHashOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2ensHashOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ensHashOf_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ensHashOf(V v_hashes_240, V v_c_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_241, 7))));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = (g_heff_2ebuild_2ecache_2efixSig(heff_dup(heff_rfield(v_c_241, 11))));
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 0, 9);
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_247, 6, 7)));
  V v_t_249 = (g_list_2emap_24f1260271301x348779032(heff_dup(v_c_241), v_t_248));
  V v_x2_2411 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2ensHashOf_lam0, 1, 2, (V[]){heff_dup(v_hashes_240), v_c_241}), v_t_249));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2ensHashOf_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ensHashOf_str4), v_t_2414));
  V v_s_2416 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2ensHashOf_str5), v_t_2415));
  return (g_heff_2ebuild_2ecache_2ehashGo(v_s_2416, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
}
V g_heff_2ebuild_2ecache_2ensHashOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2ensHashOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecache_2ensHashOf_lam0(V self, V *args) {
  V v_k_2410 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  V v_c_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_hashes_240; V a_1 = v_c_241; V a_2 = v_k_2410; V r_ = (g_heff_2ebuild_2ecache_2einstanceSig(a_0, a_1, a_2)); heff_drop(v_hashes_240); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str1, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str2, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeFix_str6, 1, ":");
Clo g_heff_2ebuild_2ecache_2efreezeFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreezeFix_entry, 1, 0};

V g_heff_2ebuild_2ecache_2efreezeFix(V v_f_240) {
top: ;
  V v_xs_241 = heff_take_field(v_f_240, 0);
  V v_t_242 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_241));
  V v_t_244 = (g_list_2efoldl_24s518608766x1858781247(((V)&g_heff_2ebuild_2ecache_2efreezeFix_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str1), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str2), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str3), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str4), NTAG(TAG_Nil), v_t_243));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_242), v_t_244});
  V v_xs_246 = heff_get_n(v_f_240, 1, 2);
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  V v_t_249 = (g_list_2efoldl_24s655081849x360568693(((V)&g_heff_2ebuild_2ecache_2efreezeFix_str5), ((V)&g_heff_2ebuild_2ecache_2efreezeFix_str6), NTAG(TAG_Nil), v_t_248));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_247), v_t_249});
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2410));
}
V g_heff_2ebuild_2ecache_2efreezeFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2efreezeFix(a[0]);
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2eneedsOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecache_2eneedsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eneedsOf_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eneedsOf(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2eneedsOf_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_2422 = (g_heff_2ebuild_2ecache_2enubCa(v_t_2421));
  V v_t_2427 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecache_2eneedsOf_lam1, 1, 1, (V[]){v_c_240}), v_t_2422));
  return (g_list_2esortBy(heff_dup(g_strLt_get()), v_t_2427));
}
V g_heff_2ebuild_2ecache_2eneedsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eneedsOf(a[0]);
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_244 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
  V v_k_245 = heff_get_n(v_x_243, 1, 2);
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_245), heff_rfield(v_g_244, 1)));
  V v_t_2420;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(v_k_245, heff_rfield(v_g_244, 2)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_244, 7);
      v_t_2420 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_k2_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_t_249 = ({ V a_0 = v_k2_248; V b_1 = heff_get_n(v_g_244, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_e_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_t_2411 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_rfield(v_e_2410, 1)));
        V v_t_2412 = (g_heff_2eelab_2erename_2enubFirst(v_t_2411));
        V v_t_2413 = ({ V b_0 = heff_get_n(v_e_2410, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
        V v_t_2414 = (g_heff_2eelab_2erename_2enubFirst(v_t_2413));
        v_t_2420 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2414));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    heff_drop_rec(v_g_244, 7);
    heff_drop(v_k_245);
    V v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_rfield(v_e_2415, 1)));
    V v_t_2417 = (g_heff_2eelab_2erename_2enubFirst(v_t_2416));
    V v_t_2418 = ({ V b_0 = heff_get_n(v_e_2415, 0, 4); V r_ = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(b_0)); heff_drop(b_0); r_; });
    V v_t_2419 = (g_heff_2eelab_2erename_2enubFirst(v_t_2418));
    v_t_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_242));
}
V g_heff_2ebuild_2ecache_2eneedsOf_lam1(V self, V *args) {
  V v_k_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_2424 = (g_list_2emap_24s152505078x225062837(heff_get_n(v_c_240, 7, 13)));
  V v_t_2425 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_2423}));
  V v_x1_2426 = ({ V a_0 = v_t_2425; V a_1 = v_xs_2424; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2424); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
  heff_drop(v_x1_2426);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str2, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str3, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str4, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreezeDef_str9, 1, " ");
Clo g_heff_2ebuild_2ecache_2efreezeDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreezeDef_entry, 3, 0};

V g_heff_2ebuild_2ecache_2efreezeDef(V v_hashes_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_MkPair: {
      V v_sp_246 = heff_field(v_x32_244, 1);
      V v_ru_24x32_244_24MkPair = heff_take_reuse_n(v_x32_244, 2ULL, 2);
      V v_g_247 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 0, 9);
      V v_k_248 = heff_dup(heff_rfield(v_o_243, 1));
      V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_248), heff_rfield(v_g_247, 1)));
      V v_t_2413;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        V v_t_2410 = (g_map_2elookup_24s1546226666x2146984184(v_k_248, heff_rfield(v_g_247, 2)));
        switch (heff_tag_of(v_t_2410)) {
        case TAG_Nothing: {
          heff_drop_rec(v_g_247, 7);
          v_t_2413 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_k2_2411 = heff_field(v_t_2410, 0);
          heff_take_n(v_t_2410, 1ULL, 1);
          v_t_2413 = ({ V a_0 = v_k2_2411; V b_1 = heff_get_n(v_g_247, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        break;
      }
      case TAG_Just: {
        V v_e_2412 = heff_field(v_t_249, 0);
        V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
        heff_drop_rec(v_g_247, 7);
        heff_drop(v_k_248);
        v_t_2413 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_e_2412});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_241, 13);
        heff_drop_rec(v_o_243, 2);
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_sp_246, 2);
        heff_drop_cell(v_ru_24x32_244_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_2414 = heff_field(v_t_2413, 0);
        V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
        V v_s_2415 = heff_take_field(v_o_243, 0);
        V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_s_2415)));
        V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str0), v_s_2415));
        V v_s_2418 = heff_dup(heff_rfield(v_o_243, 1));
        V v_t_2419 = heff_intShow(heff_strLength(heff_dup(v_s_2418)));
        V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str1), v_s_2418));
        V v_t_2421 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
        V v_x1_2422 = ({ V a_0 = heff_dup(heff_rfield(v_o_243, 1)); V b_1 = heff_get_n(v_t_2421, 6, 7); V r_ = (g_list_2eany_24s1868716698x184030185(a_0, b_1)); heff_drop(b_1); r_; });
        V v_t_2423;
        if ((heff_dup(v_x1_2422) == NTAG(TAG_True))) {
          heff_drop(v_x1_2422);
          v_t_2423 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str2);
        } else {
          heff_drop(v_x1_2422);
          v_t_2423 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str3);
        }
        V v_x2_2424 = (g_map_2elookup_24s1546226666x2146984184(heff_get_n(v_o_243, 1, 2), v_hashes_240));
        V v_s_2426;
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_Nothing: {
          v_s_2426 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str4);
          break;
        }
        case TAG_Just: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          heff_take_n(v_x2_2424, 1ULL, 1);
          v_s_2426 = v_x_2425;
          break;
        }
        default: heff_nomatch(v_x2_2424);
        }
        V v_t_2427 = heff_intShow(heff_strLength(heff_dup(v_s_2426)));
        V v_t_2428 = heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreezeDef_str5), v_s_2426));
        V v_t_2429 = heff_intShow(heff_take_field(v_sp_246, 0));
        V v_t_2430 = heff_intShow(heff_get_n(v_sp_246, 1, 2));
        V v_x2_2431 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(heff_rfield(v_e_2414, 1), NTAG(TAG_Nil)));
        V v_t_2434;
        switch (heff_tag_of(v_x2_2431)) {
        case TAG_Nil: {
          v_t_2434 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2432 = heff_field(v_x2_2431, 0);
          V v_xs_2433 = heff_field(v_x2_2431, 1);
          heff_take_n(v_x2_2431, 3ULL, 2);
          v_t_2434 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str7); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2431);
        }
        V v_x2_2435 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_get_n(v_e_2414, 0, 4), NTAG(TAG_Nil)));
        V v_t_2438;
        switch (heff_tag_of(v_x2_2435)) {
        case TAG_Nil: {
          v_t_2438 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2436 = heff_field(v_x2_2435, 0);
          V v_xs_2437 = heff_field(v_x2_2435, 1);
          heff_take_n(v_x2_2435, 3ULL, 2);
          v_t_2438 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreezeDef_str9); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2435);
        }
        V v_t_2439 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag_at_n(v_ru_24x32_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2430, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2439})});
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2440})});
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2441})});
        return heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2442})});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2efreezeDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecache_2efreezeDef(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ecache_2ezipCa_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ezipCa_entry, 2, 0};

V g_heff_2ebuild_2ecache_2ezipCa(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2ecache_2ezipCa_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2ezipCa_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ezipCa(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecache_2ezipCa_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2ezipCa_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecache_2ezipCa_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2ezipCa_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2ezipCa_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ecache_2eallJust_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eallJust_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eallJust(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_x12_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_x2_244 = (g_heff_2ebuild_2ecache_2eallJust(v_x12_242));
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_ys_245 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_ys_245})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecache_2eallJust_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eallJust(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str3, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str6, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecache_2efreeze_str10, 1, " ");
V g_heff_2ebuild_2ecache_2efreeze_lam0(V self, V *args);
V g_heff_2ebuild_2ecache_2efreeze_lam1(V self, V *args);
V g_heff_2ebuild_2ecache_2efreeze_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecache_2efreeze_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2efreeze_entry, 4, 0};

V g_heff_2ebuild_2ecache_2efreeze(V v_hashes_240, V v_done_241, V v_s_242, V v_c_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_243, 5)), 6, 9);
  V v_t_245 = (g_heff_2ebuild_2ecache_2ezipCa(heff_dup(heff_rfield(v_c_243, 7)), v_t_244));
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_lam0, 1, 2, (V[]){heff_dup(v_hashes_240), heff_dup(v_c_243)}), v_t_245));
  V v_t_248 = (g_heff_2ebuild_2ecache_2eallJust(v_t_247));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_242, 7);
    heff_drop_rec(v_c_243, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_defs_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ecache_2eversion_get())));
    V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str0), heff_dup(g_heff_2ebuild_2ecache_2eversion_get())));
    V v_s_2412 = heff_take_field(v_s_242, 0);
    V v_t_2413 = heff_intShow(heff_strLength(heff_dup(v_s_2412)));
    V v_t_2414 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str1), v_s_2412));
    V v_s_2415 = (g_heff_2ebuild_2ecache_2ehashGo(heff_dup(heff_rfield(v_c_243, 3)), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    V v_t_2416 = heff_intShow(heff_strLength(heff_dup(v_s_2415)));
    V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str2), v_s_2415));
    V v_t_2418 = (g_heff_2ebuild_2ecache_2efreezeFix(heff_dup(heff_rfield(v_c_243, 11))));
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2418})});
    V v_t_2420 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 3)));
    V v_t_2421 = ({ V b_0 = heff_get_n(v_s_242, 4, 7); V a_1 = v_t_2420; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
    V v_imps_2422 = heff_get_n(v_t_2421, 0, 3);
    V v_t_2423 = (g_list_2emap_24s1817208647x1282894070(v_imps_2422));
    V v_xs_2424 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2423));
    V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    V v_t_2441 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_lam1, 2, 2, (V[]){heff_dup(v_done_241), heff_dup(v_hashes_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2441});
    V v_xs_2443 = (g_heff_2ebuild_2ecache_2eneedsOf(v_c_243));
    V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2443));
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
    V v_t_2460 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2efreeze_lam2, 2, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2445; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2445); r_; });
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2444), v_t_2460});
    V v_t_2462 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_defs_249));
    V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_249));
    V v_t_2464 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2463; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2463); r_; });
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2462), v_t_2464});
    V v_t_2466 = (g_prelude_2e_2b_2b(v_t_2461, v_t_2465));
    V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2442, v_t_2466));
    V v_x2_2468 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2419}), v_t_2467));
    V v_t_2471;
    switch (heff_tag_of(v_x2_2468)) {
    case TAG_Nil: {
      v_t_2471 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2469 = heff_field(v_x2_2468, 0);
      V v_xs_2470 = heff_field(v_x2_2468, 1);
      heff_take_n(v_x2_2468, 3ULL, 2);
      v_t_2471 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str10); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2468);
    }
    return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecache_2efreeze_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecache_2efreeze(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecache_2efreeze_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_hashes_240; V a_1 = v_c_243; V a_2 = v_p_246; V r_ = (g_heff_2ebuild_2ecache_2efreezeDef(a_0, a_1, a_2)); heff_drop(v_hashes_240); r_; });
}
V g_heff_2ebuild_2ecache_2efreeze_lam1(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_done_241 = heff_env(self)[0];
  V v_hashes_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = ({ V a_0 = heff_dup(v_x_2428); V a_1 = v_done_241; V r_ = (g_list_2efind_24s487054388x274730225(a_0, a_1)); heff_drop(v_done_241); r_; });
  V v_t_2431;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nothing: {
    heff_drop(v_hashes_240);
    v_t_2431 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str3);
    break;
  }
  case TAG_Just: {
    V v_d_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    v_t_2431 = ({ V a_0 = v_hashes_240; V a_1 = v_d_2430; V r_ = (g_heff_2ebuild_2ecache_2ensHashOf(a_0, a_1)); heff_drop(v_hashes_240); r_; });
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  V v_x1_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_t_2431});
  V v_t_2440;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_MkPair: {
    V v_a_2433 = heff_field(v_x1_2432, 0);
    V v_b_2434 = heff_field(v_x1_2432, 1);
    V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
    V v_t_2435 = heff_intShow(heff_strLength(heff_dup(v_a_2433)));
    V v_t_2436 = heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str4), v_a_2433));
    V v_t_2437 = heff_intShow(heff_strLength(heff_dup(v_b_2434)));
    V v_t_2438 = heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str5), v_b_2434));
    V v_t_2439 = heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
    v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2439});
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  return (g_prelude_2e_2b_2b(v_t_2440, v_acc_2427));
}
V g_heff_2ebuild_2ecache_2efreeze_lam2(V self, V *args) {
  V v_acc_2446 = args[0];
  V v_x_2447 = args[1];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2448 = ({ V a_0 = heff_dup(v_x_2447); V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
  V v_t_2450;
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_Nothing: {
    v_t_2450 = ((V)&g_heff_2ebuild_2ecache_2efreeze_str6);
    break;
  }
  case TAG_Just: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    heff_take_n(v_x2_2448, 1ULL, 1);
    v_t_2450 = v_x_2449;
    break;
  }
  default: heff_nomatch(v_x2_2448);
  }
  V v_x1_2451 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_t_2450});
  V v_t_2459;
  switch (heff_tag_of(v_x1_2451)) {
  case TAG_MkPair: {
    V v_a_2452 = heff_field(v_x1_2451, 0);
    V v_b_2453 = heff_field(v_x1_2451, 1);
    V v_ru_24x1_2451_24MkPair = heff_take_reuse_n(v_x1_2451, 3ULL, 2);
    V v_t_2454 = heff_intShow(heff_strLength(heff_dup(v_a_2452)));
    V v_t_2455 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str7), v_a_2452));
    V v_t_2456 = heff_intShow(heff_strLength(heff_dup(v_b_2453)));
    V v_t_2457 = heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2efreeze_str8), v_b_2453));
    V v_t_2458 = heff_tag_at_n(v_ru_24x1_2451_24MkPair, TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
    v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2458});
    break;
  }
  default: heff_nomatch(v_x1_2451);
  }
  return (g_prelude_2e_2b_2b(v_t_2459, v_acc_2446));
}
V g_heff_2ebuild_2ecache_2eassocOf_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam0, 2, 0};
V g_heff_2ebuild_2ecache_2eassocOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam1, 2, 0};
V g_heff_2ebuild_2ecache_2eassocOf_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecache_2eassocOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_lam2, 2, 0};
Clo g_heff_2ebuild_2ecache_2eassocOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eassocOf_entry, 1, 0};

V g_heff_2ebuild_2ecache_2eassocOf(V v_x1_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_x1_240), MK_INT(0LL))) {
    heff_drop(v_x1_240);
    return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam0_clo);
  } else {
    if (heff_intEq_c(heff_dup(v_x1_240), MK_INT(1LL))) {
      heff_drop(v_x1_240);
      return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam1_clo);
    } else {
      if (heff_intEq_c(v_x1_240, MK_INT(2LL))) {
        return ((V)&g_heff_2ebuild_2ecache_2eassocOf_lam2_clo);
      } else {
        return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
      }
    }
  }
}
V g_heff_2ebuild_2ecache_2eassocOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2eassocOf(a[0]);
}
V g_heff_2ebuild_2ecache_2eassocOf_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  heff_drop(v_s_242);
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocLeft), v_i_243});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
}
V g_heff_2ebuild_2ecache_2eassocOf_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_i_247 = args[1];
  heff_drop(v_s_246);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocRight), v_i_247});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
}
V g_heff_2ebuild_2ecache_2eassocOf_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_i_2411 = args[1];
  heff_drop(v_s_2410);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_AssocNone), v_i_2411});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltFixGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFixGroup_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltFixGroup(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop(v_x_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ecache_2emeltFixGroup_lam0, 3, 2, (V[]){v_x_248, v_x_244}), v_s_240, v_j_249));
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltFixGroup(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2emeltFixGroup_lam0(V self, V *args) {
  V v_loosest_2410 = args[0];
  V v_s_2411 = args[1];
  V v_i_2412 = args[2];
  V v_x_248 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2413 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_2411), v_i_2412));
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nothing: {
    heff_drop(v_loosest_2410);
    heff_drop(v_s_2411);
    heff_drop(v_x_248);
    heff_drop(v_x_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2414 = heff_field(v_x3_2413, 0);
    V v_ru_24x3_2413_24Just = heff_take_reuse_n(v_x3_2413, 1ULL, 1);
    switch (heff_tag_of(v_x31_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x31_2414, 0);
      V v_j_2416 = heff_field(v_x31_2414, 1);
      V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
      V v_x3_2417 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_2411), v_j_2416));
      V v_x3_2421;
      switch (heff_tag_of(v_x3_2417)) {
      case TAG_Nothing: {
        v_x3_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2418 = heff_field(v_x3_2417, 0);
        heff_take_n(v_x3_2417, 1ULL, 1);
        switch (heff_tag_of(v_x31_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x31_2418, 0);
          V v_j_2420 = heff_field(v_x31_2418, 1);
          heff_take_n(v_x31_2418, 3ULL, 2);
          v_x3_2421 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2419, heff_dup(v_s_2411), v_j_2420));
          break;
        }
        default: heff_nomatch(v_x31_2418);
        }
        break;
      }
      default: heff_nomatch(v_x3_2417);
      }
      switch (heff_tag_of(v_x3_2421)) {
      case TAG_Nothing: {
        heff_drop(v_loosest_2410);
        heff_drop(v_s_2411);
        heff_drop(v_x_248);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x3_2413_24Just, 1);
        heff_drop(v_x_2415);
        heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2422 = heff_field(v_x3_2421, 0);
        heff_take_n(v_x3_2421, 1ULL, 1);
        switch (heff_tag_of(v_x31_2422)) {
        case TAG_MkPair: {
          V v_x_2423 = heff_field(v_x31_2422, 0);
          V v_j_2424 = heff_field(v_x31_2422, 1);
          heff_take_n(v_x31_2422, 3ULL, 2);
          V v_m_2425 = (g_heff_2ebuild_2ecache_2eassocOf(v_x_248));
          V v_x3_2426 = heff_tr(heff_call(v_m_2425, 2, (V[]){v_s_2411, v_j_2424}));
          switch (heff_tag_of(v_x3_2426)) {
          case TAG_Nothing: {
            heff_drop(v_loosest_2410);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x3_2413_24Just, 1);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
            heff_drop(v_x_2423);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2427 = heff_field(v_x3_2426, 0);
            heff_take_n(v_x3_2426, 1ULL, 1);
            switch (heff_tag_of(v_x31_2427)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_field(v_x31_2427, 0);
              V v_j_2429 = heff_field(v_x31_2427, 1);
              heff_take_n(v_x31_2427, 3ULL, 2);
              V v_t_2430 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){v_x_244, v_x_2428, v_x_2423, v_loosest_2410, v_x_2415}), v_j_2429});
              return heff_tag_at_n(v_ru_24x3_2413_24Just, TAG_Just, 1, (V[]){v_t_2430});
            }
            default: return heff_nomatch(v_x31_2427);
            }
          }
          default: return heff_nomatch(v_x3_2426);
          }
        }
        default: return heff_nomatch(v_x31_2422);
        }
      }
      default: return heff_nomatch(v_x3_2421);
      }
    }
    default: return heff_nomatch(v_x31_2414);
    }
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
Clo g_heff_2ebuild_2ecache_2emeltFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFix_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltFix(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_i_241));
  V v_x3_246;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    v_x3_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      v_x3_246 = (g_heff_2ebuild_2edecoder_2etimes_24s2047245715x172085216(v_x_244, heff_dup(v_s_240), v_j_245));
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_247 = heff_field(v_x3_246, 0);
    V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_247, 0);
      V v_j_249 = heff_field(v_x31_247, 1);
      V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
      V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_249));
      V v_x3_2414;
      switch (heff_tag_of(v_x3_2410)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        v_x3_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2411 = heff_field(v_x3_2410, 0);
        heff_take_n(v_x3_2410, 1ULL, 1);
        switch (heff_tag_of(v_x31_2411)) {
        case TAG_MkPair: {
          V v_x_2412 = heff_field(v_x31_2411, 0);
          V v_j_2413 = heff_field(v_x31_2411, 1);
          heff_take_n(v_x31_2411, 3ULL, 2);
          v_x3_2414 = (g_heff_2ebuild_2edecoder_2etimes_24s1706431346x766574499(v_x_2412, v_s_240, v_j_2413));
          break;
        }
        default: heff_nomatch(v_x31_2411);
        }
        break;
      }
      default: heff_nomatch(v_x3_2410);
      }
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_246_24Just, 1);
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2415 = heff_field(v_x3_2414, 0);
        heff_take_n(v_x3_2414, 1ULL, 1);
        switch (heff_tag_of(v_x31_2415)) {
        case TAG_MkPair: {
          V v_x_2416 = heff_field(v_x31_2415, 0);
          V v_j_2417 = heff_field(v_x31_2415, 1);
          heff_take_n(v_x31_2415, 3ULL, 2);
          V v_t_2418 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_x_248, v_x_2416}), v_j_2417});
          return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){v_t_2418});
        }
        default: return heff_nomatch(v_x31_2415);
        }
      }
      default: return heff_nomatch(v_x3_2414);
      }
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2ecache_2emeltFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltFix(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltDef_str0, 1, "\012");
V g_heff_2ebuild_2ecache_2emeltDef_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltDef_entry, 2, 0};

V g_heff_2ebuild_2ecache_2emeltDef(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop(v_x_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ecache_2emeltDef_lam0, 3, 2, (V[]){v_x_244, v_x_248}), v_s_240, v_j_249));
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecache_2emeltDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecache_2emeltDef(a[0], a[1]);
}
V g_heff_2ebuild_2ecache_2emeltDef_lam0(V self, V *args) {
  V v_isInstance_2410 = args[0];
  V v_s_2411 = args[1];
  V v_i_2412 = args[2];
  V v_x_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x3_2413 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_2411), v_i_2412));
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nothing: {
    heff_drop(v_isInstance_2410);
    heff_drop(v_s_2411);
    heff_drop(v_x_244);
    heff_drop(v_x_248);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2414 = heff_field(v_x3_2413, 0);
    V v_ru_24x3_2413_24Just = heff_take_reuse_n(v_x3_2413, 1ULL, 1);
    switch (heff_tag_of(v_x31_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x31_2414, 0);
      V v_j_2416 = heff_field(v_x31_2414, 1);
      V v_ru_24x31_2414_24MkPair = heff_take_reuse_n(v_x31_2414, 3ULL, 2);
      V v_x3_2417 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_2411), v_j_2416));
      switch (heff_tag_of(v_x3_2417)) {
      case TAG_Nothing: {
        heff_drop(v_isInstance_2410);
        heff_drop(v_s_2411);
        heff_drop(v_x_244);
        heff_drop(v_x_248);
        heff_drop_cell(v_ru_24x3_2413_24Just, 1);
        heff_drop(v_x_2415);
        heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2418 = heff_field(v_x3_2417, 0);
        heff_take_n(v_x3_2417, 1ULL, 1);
        switch (heff_tag_of(v_x31_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x31_2418, 0);
          V v_j_2420 = heff_field(v_x31_2418, 1);
          heff_take_n(v_x31_2418, 3ULL, 2);
          V v_x3_2421 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_2411), v_j_2420));
          switch (heff_tag_of(v_x3_2421)) {
          case TAG_Nothing: {
            heff_drop(v_isInstance_2410);
            heff_drop(v_s_2411);
            heff_drop(v_x_244);
            heff_drop(v_x_248);
            heff_drop_cell(v_ru_24x3_2413_24Just, 1);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
            heff_drop(v_x_2419);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2422 = heff_field(v_x3_2421, 0);
            heff_take_n(v_x3_2421, 1ULL, 1);
            switch (heff_tag_of(v_x31_2422)) {
            case TAG_MkPair: {
              V v_x_2423 = heff_field(v_x31_2422, 0);
              V v_j_2424 = heff_field(v_x31_2422, 1);
              heff_take_n(v_x31_2422, 3ULL, 2);
              V v_x3_2425 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2411), v_j_2424));
              V v_x3_2429;
              switch (heff_tag_of(v_x3_2425)) {
              case TAG_Nothing: {
                v_x3_2429 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2426 = heff_field(v_x3_2425, 0);
                heff_take_n(v_x3_2425, 1ULL, 1);
                switch (heff_tag_of(v_x31_2426)) {
                case TAG_MkPair: {
                  V v_x_2427 = heff_field(v_x31_2426, 0);
                  V v_j_2428 = heff_field(v_x31_2426, 1);
                  heff_take_n(v_x31_2426, 3ULL, 2);
                  v_x3_2429 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2427, heff_dup(v_s_2411), v_j_2428));
                  break;
                }
                default: heff_nomatch(v_x31_2426);
                }
                break;
              }
              default: heff_nomatch(v_x3_2425);
              }
              switch (heff_tag_of(v_x3_2429)) {
              case TAG_Nothing: {
                heff_drop(v_isInstance_2410);
                heff_drop(v_s_2411);
                heff_drop(v_x_244);
                heff_drop(v_x_248);
                heff_drop_cell(v_ru_24x3_2413_24Just, 1);
                heff_drop(v_x_2415);
                heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
                heff_drop(v_x_2419);
                heff_drop(v_x_2423);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2430 = heff_field(v_x3_2429, 0);
                heff_take_n(v_x3_2429, 1ULL, 1);
                switch (heff_tag_of(v_x31_2430)) {
                case TAG_MkPair: {
                  V v_x_2431 = heff_field(v_x31_2430, 0);
                  V v_j_2432 = heff_field(v_x31_2430, 1);
                  heff_take_n(v_x31_2430, 3ULL, 2);
                  V v_x3_2433 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2411), v_j_2432));
                  V v_x3_2437;
                  switch (heff_tag_of(v_x3_2433)) {
                  case TAG_Nothing: {
                    heff_drop(v_s_2411);
                    v_x3_2437 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2434 = heff_field(v_x3_2433, 0);
                    heff_take_n(v_x3_2433, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2434)) {
                    case TAG_MkPair: {
                      V v_x_2435 = heff_field(v_x31_2434, 0);
                      V v_j_2436 = heff_field(v_x31_2434, 1);
                      heff_take_n(v_x31_2434, 3ULL, 2);
                      v_x3_2437 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2435, v_s_2411, v_j_2436));
                      break;
                    }
                    default: heff_nomatch(v_x31_2434);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2433);
                  }
                  switch (heff_tag_of(v_x3_2437)) {
                  case TAG_Nothing: {
                    heff_drop(v_isInstance_2410);
                    heff_drop(v_x_244);
                    heff_drop(v_x_248);
                    heff_drop_cell(v_ru_24x3_2413_24Just, 1);
                    heff_drop(v_x_2415);
                    heff_drop_cell(v_ru_24x31_2414_24MkPair, 2);
                    heff_drop(v_x_2419);
                    heff_drop(v_x_2423);
                    heff_drop(v_x_2431);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2438 = heff_field(v_x3_2437, 0);
                    heff_take_n(v_x3_2437, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2438)) {
                    case TAG_MkPair: {
                      V v_x_2439 = heff_field(v_x31_2438, 0);
                      V v_j_2440 = heff_field(v_x31_2438, 1);
                      heff_take_n(v_x31_2438, 3ULL, 2);
                      V v_t_2441 = heff_rec_n(6, shape_name__key__isInstance__span__ty__body, (V[]){v_x_244, heff_dup(v_x_248), v_isInstance_2410, heff_rec_n(2, shape_start__end, (V[]){v_x_2419, v_x_2423}), v_x_2431, v_x_2439});
                      V v_t_2442 = heff_strAppend(v_x_248, heff_strAppend(((V)&g_heff_2ebuild_2ecache_2emeltDef_str0), v_x_2415));
                      V v_t_2443 = heff_tag_at_n(v_ru_24x31_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, v_t_2442}), v_j_2440});
                      return heff_tag_at_n(v_ru_24x3_2413_24Just, TAG_Just, 1, (V[]){v_t_2443});
                    }
                    default: return heff_nomatch(v_x31_2438);
                    }
                  }
                  default: return heff_nomatch(v_x3_2437);
                  }
                }
                default: return heff_nomatch(v_x31_2430);
                }
              }
              default: return heff_nomatch(v_x3_2429);
              }
            }
            default: return heff_nomatch(v_x31_2422);
            }
          }
          default: return heff_nomatch(v_x3_2421);
          }
        }
        default: return heff_nomatch(v_x31_2418);
        }
      }
      default: return heff_nomatch(v_x3_2417);
      }
    }
    default: return heff_nomatch(v_x31_2414);
    }
  }
  default: return heff_nomatch(v_x3_2413);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2eimportsHold_str0, 1, "\?");
V g_heff_2ebuild_2ecache_2eimportsHold_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2eimportsHold_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2eimportsHold_entry, 4, 0};

V g_heff_2ebuild_2ecache_2eimportsHold(V v_hashes_240, V v_done_241, V v_s_242, V v_ns_243) {
top: ;
  V v_t_2410 = (g_list_2eall(heff_clo_n(g_heff_2ebuild_2ecache_2eimportsHold_lam0, 1, 2, (V[]){heff_dup(v_done_241), heff_dup(v_hashes_240)}), v_ns_243));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2410) == NTAG(TAG_True)) && ({ V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ns_243)); int c_ = ({ V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_242, 5)), heff_dup(heff_rfield(v_s_242, 3)))); int c_ = ({ V v_t_2413 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_242, 4), heff_dup(v_t_2412))); int c_ = ({ V v_imps_2414 = heff_dup(heff_rfield(v_t_2413, 0)); int c_ = ({ V v_t_2415 = (g_list_2emap_24s1817208647x1282894070(heff_dup(v_imps_2414))); int c_ = ({ V v_t_2416 = (g_list_2efoldl_24f700195413x1431112932(MK_INT(1LL), MK_INT(0LL), heff_dup(v_t_2415))); int c_ = heff_intEq_c(heff_dup(v_t_2411), heff_dup(v_t_2416)); heff_drop(v_t_2416); c_; }); heff_drop(v_t_2415); c_; }); heff_drop(v_imps_2414); c_; }); heff_drop(v_t_2413); c_; }); heff_drop(v_t_2412); c_; }); heff_drop(v_t_2411); c_; })));
  heff_drop_rec(v_s_242, 7);
  heff_drop(v_t_2410);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecache_2eimportsHold_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2ecache_2eimportsHold(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecache_2eimportsHold_lam0(V self, V *args) {
  V v_x3_244 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hashes_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_244)) {
  case TAG_MkPair: {
    V v_m_245 = heff_field(v_x3_244, 0);
    V v_h_246 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    V v_t_247 = ({ V a_0 = v_m_245; V a_1 = v_done_241; V r_ = (g_list_2efind_24s487054388x274730225(a_0, a_1)); heff_drop(v_done_241); r_; });
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_hashes_240);
      v_t_249 = ((V)&g_heff_2ebuild_2ecache_2eimportsHold_str0);
      break;
    }
    case TAG_Just: {
      V v_d_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = ({ V a_0 = v_hashes_240; V a_1 = v_d_248; V r_ = (g_heff_2ebuild_2ecache_2ensHashOf(a_0, a_1)); heff_drop(v_hashes_240); r_; });
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return heff_strEq(v_t_249, v_h_246);
  }
  default: return heff_nomatch(v_x3_244);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str0, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str2, 1, "\?");
HEFF_LIT(g_heff_2ebuild_2ecache_2emeltFrom_str3, 1, "\?");
V g_heff_2ebuild_2ecache_2emeltFrom_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecache_2emeltFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecache_2emeltFrom_entry, 5, 0};

V g_heff_2ebuild_2ecache_2emeltFrom(V v_hashes_240, V v_done_241, V v_s_242, V v_s_243, V v_i_244) {
top: ;
  V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_243), v_i_244));
  V v_t_2411;
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      if (heff_strEq_c(v_x_247, heff_dup(g_heff_2ebuild_2ecache_2eversion_get()))) {
        V v_t_2410 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_248});
        v_t_2411 = heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2410});
      } else {
        heff_drop_cell(v_ru_24x3_245_24Just, 1);
        heff_drop(v_j_248);
        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
        v_t_2411 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x31_246);
    }
    break;
  }
  default: heff_nomatch(v_x3_245);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_242, 7);
    heff_drop(v_s_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2412 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    switch (heff_tag_of(v_x31_2412)) {
    case TAG_MkPair: {
      V v_j_2414 = heff_field(v_x31_2412, 1);
      V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 2ULL, 2);
      V v_x3_2415 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_243), v_j_2414));
      V v_t_2421;
      switch (heff_tag_of(v_x3_2415)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_2411_24Just, 1);
        heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2416 = heff_field(v_x3_2415, 0);
        heff_take_n(v_x3_2415, 1ULL, 1);
        switch (heff_tag_of(v_x31_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x31_2416, 0);
          V v_j_2418 = heff_field(v_x31_2416, 1);
          heff_take_n(v_x31_2416, 3ULL, 2);
          if (heff_strEq_c(v_x_2417, heff_dup(heff_rfield(v_s_242, 0)))) {
            V v_t_2420 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_2418});
            v_t_2421 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2420});
          } else {
            heff_drop_cell(v_ru_24t_2411_24Just, 1);
            heff_drop_cell(v_ru_24x31_2412_24MkPair, 2);
            heff_drop(v_j_2418);
            v_t_2421 = NTAG(TAG_Nothing);
          }
          break;
        }
        default: heff_nomatch(v_x31_2416);
        }
        break;
      }
      default: heff_nomatch(v_x3_2415);
      }
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nothing: {
        heff_drop_rec(v_s_242, 7);
        heff_drop(v_s_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2422 = heff_field(v_t_2421, 0);
        V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
        switch (heff_tag_of(v_x31_2422)) {
        case TAG_MkPair: {
          V v_j_2424 = heff_field(v_x31_2422, 1);
          V v_ru_24x31_2422_24MkPair = heff_take_reuse_n(v_x31_2422, 2ULL, 2);
          V v_x_2425 = (g_heff_2ebuild_2ecache_2ehashGo(heff_dup(heff_rfield(v_s_242, 3)), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
          V v_x3_2426 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_243), v_j_2424));
          V v_t_2432;
          switch (heff_tag_of(v_x3_2426)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24t_2421_24Just, 1);
            heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
            heff_drop(v_x_2425);
            v_t_2432 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2427 = heff_field(v_x3_2426, 0);
            heff_take_n(v_x3_2426, 1ULL, 1);
            switch (heff_tag_of(v_x31_2427)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_field(v_x31_2427, 0);
              V v_j_2429 = heff_field(v_x31_2427, 1);
              heff_take_n(v_x31_2427, 3ULL, 2);
              if (heff_strEq_c(v_x_2428, v_x_2425)) {
                V v_t_2431 = heff_tag_at_n(v_ru_24x31_2422_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_2429});
                v_t_2432 = heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){v_t_2431});
              } else {
                heff_drop_cell(v_ru_24t_2421_24Just, 1);
                heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
                heff_drop(v_j_2429);
                v_t_2432 = NTAG(TAG_Nothing);
              }
              break;
            }
            default: heff_nomatch(v_x31_2427);
            }
            break;
          }
          default: heff_nomatch(v_x3_2426);
          }
          switch (heff_tag_of(v_t_2432)) {
          case TAG_Nothing: {
            heff_drop_rec(v_s_242, 7);
            heff_drop(v_s_243);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2433 = heff_field(v_t_2432, 0);
            V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 1ULL, 1);
            switch (heff_tag_of(v_x31_2433)) {
            case TAG_MkPair: {
              V v_j_2435 = heff_field(v_x31_2433, 1);
              heff_take_n(v_x31_2433, 2ULL, 2);
              V v_x3_2436 = (g_heff_2ebuild_2ecache_2emeltFix(heff_dup(v_s_243), v_j_2435));
              switch (heff_tag_of(v_x3_2436)) {
              case TAG_Nothing: {
                heff_drop_rec(v_s_242, 7);
                heff_drop(v_s_243);
                heff_drop_cell(v_ru_24t_2432_24Just, 1);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2437 = heff_field(v_x3_2436, 0);
                heff_take_n(v_x3_2436, 1ULL, 1);
                switch (heff_tag_of(v_x31_2437)) {
                case TAG_MkPair: {
                  V v_x_2438 = heff_field(v_x31_2437, 0);
                  V v_j_2439 = heff_field(v_x31_2437, 1);
                  heff_take_n(v_x31_2437, 3ULL, 2);
                  V v_x3_2440 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_243), v_j_2439));
                  V v_x3_2444;
                  switch (heff_tag_of(v_x3_2440)) {
                  case TAG_Nothing: {
                    v_x3_2444 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2441 = heff_field(v_x3_2440, 0);
                    heff_take_n(v_x3_2440, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2441)) {
                    case TAG_MkPair: {
                      V v_x_2442 = heff_field(v_x31_2441, 0);
                      V v_j_2443 = heff_field(v_x31_2441, 1);
                      heff_take_n(v_x31_2441, 3ULL, 2);
                      v_x3_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652(v_x_2442, heff_dup(v_s_243), v_j_2443));
                      break;
                    }
                    default: heff_nomatch(v_x31_2441);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2440);
                  }
                  switch (heff_tag_of(v_x3_2444)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_s_242, 7);
                    heff_drop(v_s_243);
                    heff_drop_cell(v_ru_24t_2432_24Just, 1);
                    heff_drop(v_x_2438);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2445 = heff_field(v_x3_2444, 0);
                    heff_take_n(v_x3_2444, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2445)) {
                    case TAG_MkPair: {
                      V v_x_2446 = heff_field(v_x31_2445, 0);
                      V v_j_2447 = heff_field(v_x31_2445, 1);
                      heff_take_n(v_x31_2445, 3ULL, 2);
                      V v_x1_2448 = ({ V a_0 = v_hashes_240; V a_1 = v_done_241; V a_2 = v_s_242; V a_3 = v_x_2446; V r_ = (g_heff_2ebuild_2ecache_2eimportsHold(a_0, a_1, a_2, a_3)); heff_drop(v_x_2446); r_; });
                      if ((heff_dup(v_x1_2448) == NTAG(TAG_True))) {
                        heff_drop(v_x1_2448);
                        V v_x3_2449 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_243), v_j_2447));
                        V v_x3_2453;
                        switch (heff_tag_of(v_x3_2449)) {
                        case TAG_Nothing: {
                          v_x3_2453 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_2450 = heff_field(v_x3_2449, 0);
                          heff_take_n(v_x3_2449, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2450)) {
                          case TAG_MkPair: {
                            V v_x_2451 = heff_field(v_x31_2450, 0);
                            V v_j_2452 = heff_field(v_x31_2450, 1);
                            heff_take_n(v_x31_2450, 3ULL, 2);
                            v_x3_2453 = (g_heff_2ebuild_2edecoder_2etimes_24s2039252922x623302652(v_x_2451, heff_dup(v_s_243), v_j_2452));
                            break;
                          }
                          default: heff_nomatch(v_x31_2450);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_2449);
                        }
                        switch (heff_tag_of(v_x3_2453)) {
                        case TAG_Nothing: {
                          heff_drop(v_s_243);
                          heff_drop_cell(v_ru_24t_2432_24Just, 1);
                          heff_drop(v_x_2438);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2454 = heff_field(v_x3_2453, 0);
                          heff_take_n(v_x3_2453, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2454)) {
                          case TAG_MkPair: {
                            V v_x_2455 = heff_field(v_x31_2454, 0);
                            V v_j_2456 = heff_field(v_x31_2454, 1);
                            heff_take_n(v_x31_2454, 3ULL, 2);
                            V v_x1_2463 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecache_2emeltFrom_lam0, 1, 1, (V[]){heff_dup(v_hashes_240)}); V a_1 = v_x_2455; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_x_2455); r_; });
                            if ((heff_dup(v_x1_2463) == NTAG(TAG_True))) {
                              heff_drop(v_x1_2463);
                              V v_x3_2464 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_243), v_j_2456));
                              V v_x3_2468;
                              switch (heff_tag_of(v_x3_2464)) {
                              case TAG_Nothing: {
                                heff_drop(v_s_243);
                                v_x3_2468 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x31_2465 = heff_field(v_x3_2464, 0);
                                heff_take_n(v_x3_2464, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2465)) {
                                case TAG_MkPair: {
                                  V v_x_2466 = heff_field(v_x31_2465, 0);
                                  V v_j_2467 = heff_field(v_x31_2465, 1);
                                  heff_take_n(v_x31_2465, 3ULL, 2);
                                  v_x3_2468 = (g_heff_2ebuild_2edecoder_2etimes_24s1644202200x1933687349(v_x_2466, v_s_243, v_j_2467));
                                  break;
                                }
                                default: heff_nomatch(v_x31_2465);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x3_2464);
                              }
                              switch (heff_tag_of(v_x3_2468)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24t_2432_24Just, 1);
                                heff_drop(v_x_2438);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_2469 = heff_field(v_x3_2468, 0);
                                heff_take_n(v_x3_2468, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2469)) {
                                case TAG_MkPair: {
                                  V v_x_2470 = heff_field(v_x31_2469, 0);
                                  V v_j_2471 = heff_field(v_x31_2469, 1);
                                  heff_take_n(v_x31_2469, 3ULL, 2);
                                  V v_t_2472 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2470)));
                                  V v_t_2473 = (g_list_2emap_24s1492905679x736823775(((V)&g_heff_2ebuild_2ecache_2emeltFrom_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecache_2emeltFrom_str2), ((V)&g_heff_2ebuild_2ecache_2emeltFrom_str3), v_x_2470));
                                  V v_x_2474 = heff_rec_n(3, shape_fixities__defs__hashes, (V[]){v_x_2438, v_t_2472, v_t_2473});
                                  return heff_tag_at_n(v_ru_24t_2432_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2474, v_j_2471})});
                                }
                                default: return heff_nomatch(v_x31_2469);
                                }
                              }
                              default: return heff_nomatch(v_x3_2468);
                              }
                            } else {
                              heff_drop(v_s_243);
                              heff_drop_cell(v_ru_24t_2432_24Just, 1);
                              heff_drop(v_x_2438);
                              heff_drop(v_j_2456);
                              heff_drop(v_x1_2463);
                              return NTAG(TAG_Nothing);
                            }
                          }
                          default: return heff_nomatch(v_x31_2454);
                          }
                        }
                        default: return heff_nomatch(v_x3_2453);
                        }
                      } else {
                        heff_drop(v_s_243);
                        heff_drop_cell(v_ru_24t_2432_24Just, 1);
                        heff_drop(v_x_2438);
                        heff_drop(v_j_2447);
                        heff_drop(v_x1_2448);
                        return NTAG(TAG_Nothing);
                      }
                    }
                    default: return heff_nomatch(v_x31_2445);
                    }
                  }
                  default: return heff_nomatch(v_x3_2444);
                  }
                }
                default: return heff_nomatch(v_x31_2437);
                }
              }
              default: return heff_nomatch(v_x3_2436);
              }
            }
            default: return heff_nomatch(v_x31_2433);
            }
          }
          default: return heff_nomatch(v_t_2432);
          }
        }
        default: return heff_nomatch(v_x31_2422);
        }
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_x31_2412);
    }
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2ecache_2emeltFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecache_2emeltFrom(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecache_2emeltFrom_lam0(V self, V *args) {
  V v_x2_2457 = args[0];
  V v_hashes_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_k_2458 = heff_field(v_x2_2457, 0);
    V v_h_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    V v_x2_2460 = ({ V a_0 = v_k_2458; V a_1 = v_hashes_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_hashes_240); r_; });
    V v_t_2462;
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_Nothing: {
      v_t_2462 = ((V)&g_heff_2ebuild_2ecache_2emeltFrom_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      heff_take_n(v_x2_2460, 1ULL, 1);
      v_t_2462 = v_x_2461;
      break;
    }
    default: heff_nomatch(v_x2_2460);
    }
    return heff_strEq(v_t_2462, v_h_2459);
  }
  default: return heff_nomatch(v_x2_2457);
  }
}