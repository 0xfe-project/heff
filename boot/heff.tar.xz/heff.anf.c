// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_name 9869138
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2eanf_2eallA_24s205992343x559097137(V);
V g_heff_2eanf_2eallA_24s205992343x559097137_entry(V self, V *a);
extern Clo g_heff_2eanf_2eallA_24s205992343x559097137_clo;
V g_heff_2eanf_2eallA_24s844060492x1361949956(V);
V g_heff_2eanf_2eallA_24s844060492x1361949956_entry(V self, V *a);
extern Clo g_heff_2eanf_2eallA_24s844060492x1361949956_clo;
V g_heff_2eanf_2eappendRight(V, V, V);
V g_heff_2eanf_2eappendRight_entry(V self, V *a);
extern Clo g_heff_2eanf_2eappendRight_clo;
V g_heff_2eanf_2ebindAs(V, V);
V g_heff_2eanf_2ebindAs_entry(V self, V *a);
extern Clo g_heff_2eanf_2ebindAs_clo;
V g_heff_2eanf_2ebindAtom(V, V);
V g_heff_2eanf_2ebindAtom_entry(V self, V *a);
extern Clo g_heff_2eanf_2ebindAtom_clo;
V g_heff_2eanf_2eflatLet(V, V, V);
V g_heff_2eanf_2eflatLet_entry(V self, V *a);
extern Clo g_heff_2eanf_2eflatLet_clo;
V g_heff_2eanf_2einPlace(V);
V g_heff_2eanf_2einPlace_entry(V self, V *a);
extern Clo g_heff_2eanf_2einPlace_clo;
V g_heff_2eanf_2einitOf(V);
V g_heff_2eanf_2einitOf_entry(V self, V *a);
extern Clo g_heff_2eanf_2einitOf_clo;
V g_heff_2eanf_2elastOf(V);
V g_heff_2eanf_2elastOf_entry(V self, V *a);
extern Clo g_heff_2eanf_2elastOf_clo;
V g_heff_2eanf_2enorm(V);
V g_heff_2eanf_2enorm_entry(V self, V *a);
extern Clo g_heff_2eanf_2enorm_clo;
V g_heff_2eanf_2eoperandsWith(V, V, V);
V g_heff_2eanf_2eoperandsWith_entry(V self, V *a);
extern Clo g_heff_2eanf_2eoperandsWith_clo;
V g_heff_2eanf_2eprimN(V, V, V);
V g_heff_2eanf_2eprimN_entry(V self, V *a);
extern Clo g_heff_2eanf_2eprimN_clo;
V g_heff_2eanf_2etagN(V, V, V, V);
V g_heff_2eanf_2etagN_entry(V self, V *a);
extern Clo g_heff_2eanf_2etagN_clo;
V g_heff_2eanf_2etraverseN_24s370440749x1414765501(V);
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_entry(V self, V *a);
extern Clo g_heff_2eanf_2etraverseN_24s370440749x1414765501_clo;
V g_heff_2eanf_2etraverseN_24s975503381x1824309035(V);
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_entry(V self, V *a);
extern Clo g_heff_2eanf_2etraverseN_24s975503381x1824309035_clo;
V g_heff_2eanf_2evalue(V);
V g_heff_2eanf_2evalue_entry(V self, V *a);
extern Clo g_heff_2eanf_2evalue_clo;
V g_heff_2esimplify_2eprimFails(V);
V g_heff_2esimplify_2eprimFails_entry(V self, V *a);
extern Clo g_heff_2esimplify_2eprimFails_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2eanf_2evalue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2evalue_entry, 1, 0};

V g_heff_2eanf_2evalue(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ERecord: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EProj: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ETag: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrimCall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eanf_2evalue_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eanf_2evalue(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eanf_2eallA_24s844060492x1361949956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2eallA_24s844060492x1361949956_entry, 1, 0};

V g_heff_2eanf_2eallA_24s844060492x1361949956(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eanf_2evalue(v_x_241));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eanf_2eallA_24s844060492x1361949956_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eanf_2eallA_24s844060492x1361949956(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eanf_2eallA_24s205992343x559097137_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2eallA_24s205992343x559097137_entry, 1, 0};

V g_heff_2eanf_2eallA_24s205992343x559097137(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2432;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eanf_2eallA_24s205992343x559097137_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eanf_2eallA_24s205992343x559097137(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eanf_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2einPlace_entry, 1, 0};

V g_heff_2eanf_2einPlace(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EGlobal: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ELet: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_ERecord: {
    V v_fs_24126 = heff_field(v_e_240, 0);
    V v_t_24127 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_24126)));
    return ({ V a_0 = v_t_24127; V r_ = (g_heff_2eanf_2eallA_24s844060492x1361949956(a_0)); heff_drop(v_t_24127); r_; });
  }
  case TAG_EProj: {
    V v_e1_24128 = heff_field(v_e_240, 0);
    switch (heff_tag_of(v_e1_24128)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_24128);
    }
  }
  case TAG_ETag: {
    V v_as_24160 = heff_field(v_e_240, 1);
    HEFF_LAST return g_heff_2eanf_2eallA_24s844060492x1361949956(v_as_24160);
  }
  case TAG_EMatch: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrim: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EPrimCall: {
    V v_p_24222 = heff_field(v_e_240, 0);
    V v_as_24223 = heff_field(v_e_240, 1);
    V v_x1_24224 = (g_heff_2esimplify_2eprimFails(heff_dup(v_p_24222)));
    switch (heff_tag_of(v_x1_24224)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eanf_2eallA_24s205992343x559097137(v_as_24223);
    }
    default: return heff_nomatch(v_x1_24224);
    }
  }
  case TAG_ECall: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EInt: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EStr: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFixed: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFloat32: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EAbandon: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  case TAG_EFix: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      return NTAG(TAG_True);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_True);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_True);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat: {
      return NTAG(TAG_True);
    }
    case TAG_EStr: {
      return NTAG(TAG_True);
    }
    case TAG_EFixed: {
      return NTAG(TAG_True);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_True);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_240);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eanf_2einPlace_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eanf_2einPlace(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAs_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
V g_heff_2eanf_2ebindAs_lam0(V self, V *args);
V g_heff_2eanf_2ebindAs_lam1(V self, V *args);
V g_heff_2eanf_2ebindAs_lam2(V self, V *args);
V g_heff_2eanf_2ebindAs_lam3(V self, V *args);
V g_heff_2eanf_2ebindAs_lam4(V self, V *args);
V g_heff_2eanf_2ebindAs_lam5(V self, V *args);
V g_heff_2eanf_2ebindAs_lam6(V self, V *args);
V g_heff_2eanf_2ebindAs_lam7(V self, V *args);
V g_heff_2eanf_2ebindAs_lam8(V self, V *args);
V g_heff_2eanf_2ebindAs_lam9(V self, V *args);
V g_heff_2eanf_2ebindAs_lam10(V self, V *args);
V g_heff_2eanf_2ebindAs_lam11(V self, V *args);
V g_heff_2eanf_2ebindAs_lam12(V self, V *args);
V g_heff_2eanf_2ebindAs_lam13(V self, V *args);
V g_heff_2eanf_2ebindAs_lam14(V self, V *args);
V g_heff_2eanf_2ebindAs_lam15(V self, V *args);
V g_heff_2eanf_2ebindAs_lam16(V self, V *args);
V g_heff_2eanf_2ebindAs_lam17(V self, V *args);
V g_heff_2eanf_2ebindAs_lam18(V self, V *args);
Clo g_heff_2eanf_2ebindAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2ebindAs_entry, 2, 0};

V g_heff_2eanf_2ebindAs(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_EGlobal: {
    V v_t_2411 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_ELam: {
    V v_t_2420 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_EApp: {
    V v_t_2429 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_ELet: {
    V v_y_2436 = heff_field(v_e_240, 0);
    V v_c_2437 = heff_field(v_e_240, 1);
    V v_d_2438 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2439 = heff_tr(g_heff_2eanf_2ebindAs(v_d_2438, v_k_241));
    return heff_clo(g_heff_2eanf_2ebindAs_lam4, 1, 3, (V[]){v_m_2439, v_y_2436, v_c_2437});
  }
  case TAG_ERecord: {
    V v_t_2445 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_EProj: {
    V v_t_2454 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2454)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_ETag: {
    V v_t_2463 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2463)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2463);
    }
  }
  case TAG_EMatch: {
    V v_t_2472 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_EPrim: {
    V v_t_2480 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2480)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2480);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2489 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2489)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2489);
    }
  }
  case TAG_ECall: {
    V v_t_2498 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_2498)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2498);
    }
  }
  case TAG_EInt: {
    V v_t_24106 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24106)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24106);
    }
  }
  case TAG_EFloat: {
    V v_t_24114 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24114)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24114);
    }
  }
  case TAG_EStr: {
    V v_t_24122 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24122)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24122);
    }
  }
  case TAG_EFixed: {
    V v_t_24131 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24131)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24131);
    }
  }
  case TAG_EFloat32: {
    V v_t_24139 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24139)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24139);
    }
  }
  case TAG_EAbandon: {
    V v_t_24146 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24146)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24146);
    }
  }
  case TAG_EFix: {
    V v_t_24155 = (g_heff_2eanf_2einPlace(v_e_240));
    switch (heff_tag_of(v_t_24155)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAs_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24155);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eanf_2ebindAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2ebindAs(a[0], a[1]);
}
V g_heff_2eanf_2ebindAs_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_245 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str0), heff_intShow(heff_dup(v_n_244)));
  V v_m_246 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_245)})}));
  V v_x2_247 = heff_tr(heff_apply(v_m_246, 1, (V[]){heff_intAdd(v_n_244, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_245, v_e_240, v_x_248}), v_n_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2eanf_2ebindAs_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str1), heff_intShow(heff_dup(v_n_2412)));
  V v_m_2414 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2413)})}));
  V v_x2_2415 = heff_tr(heff_apply(v_m_2414, 1, (V[]){heff_intAdd(v_n_2412, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_n_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2413, v_e_240, v_x_2416}), v_n_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2eanf_2ebindAs_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str2), heff_intShow(heff_dup(v_n_2421)));
  V v_m_2423 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)})}));
  V v_x2_2424 = heff_tr(heff_apply(v_m_2423, 1, (V[]){heff_intAdd(v_n_2421, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2422, v_e_240, v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2eanf_2ebindAs_lam3(V self, V *args) {
  V v_n_2430 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2431 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str3), heff_intShow(heff_dup(v_n_2430)));
  V v_m_2432 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2431)})}));
  V v_x2_2433 = heff_tr(heff_apply(v_m_2432, 1, (V[]){heff_intAdd(v_n_2430, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2431, v_e_240, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2eanf_2ebindAs_lam4(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_y_2436 = heff_env(self)[1];
  V v_c_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2441 = heff_tr(heff_apply(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_y_2436, v_c_2437, v_x_2442}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2eanf_2ebindAs_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2447 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str4), heff_intShow(heff_dup(v_n_2446)));
  V v_m_2448 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2447)})}));
  V v_x2_2449 = heff_tr(heff_apply(v_m_2448, 1, (V[]){heff_intAdd(v_n_2446, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2447, v_e_240, v_x_2450}), v_n_2451});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2eanf_2ebindAs_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2456 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str5), heff_intShow(heff_dup(v_n_2455)));
  V v_m_2457 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2456)})}));
  V v_x2_2458 = heff_tr(heff_apply(v_m_2457, 1, (V[]){heff_intAdd(v_n_2455, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_n_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2456, v_e_240, v_x_2459}), v_n_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2eanf_2ebindAs_lam7(V self, V *args) {
  V v_n_2464 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2465 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str6), heff_intShow(heff_dup(v_n_2464)));
  V v_m_2466 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2465)})}));
  V v_x2_2467 = heff_tr(heff_apply(v_m_2466, 1, (V[]){heff_intAdd(v_n_2464, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_n_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2465, v_e_240, v_x_2468}), v_n_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2eanf_2ebindAs_lam8(V self, V *args) {
  V v_n_2473 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2474 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str7), heff_intShow(heff_dup(v_n_2473)));
  V v_m_2475 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2474)})}));
  V v_x2_2476 = heff_tr(heff_apply(v_m_2475, 1, (V[]){heff_intAdd(v_n_2473, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_n_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2474, v_e_240, v_x_2477}), v_n_2478});
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2eanf_2ebindAs_lam9(V self, V *args) {
  V v_n_2481 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2482 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str8), heff_intShow(heff_dup(v_n_2481)));
  V v_m_2483 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2482)})}));
  V v_x2_2484 = heff_tr(heff_apply(v_m_2483, 1, (V[]){heff_intAdd(v_n_2481, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2482, v_e_240, v_x_2485}), v_n_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2eanf_2ebindAs_lam10(V self, V *args) {
  V v_n_2490 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2491 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str9), heff_intShow(heff_dup(v_n_2490)));
  V v_m_2492 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2491)})}));
  V v_x2_2493 = heff_tr(heff_apply(v_m_2492, 1, (V[]){heff_intAdd(v_n_2490, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_n_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2491, v_e_240, v_x_2494}), v_n_2495});
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2eanf_2ebindAs_lam11(V self, V *args) {
  V v_n_2499 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24100 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str10), heff_intShow(heff_dup(v_n_2499)));
  V v_m_24101 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24100)})}));
  V v_x2_24102 = heff_tr(heff_apply(v_m_24101, 1, (V[]){heff_intAdd(v_n_2499, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24102)) {
  case TAG_MkPair: {
    V v_x_24103 = heff_field(v_x2_24102, 0);
    V v_n_24104 = heff_field(v_x2_24102, 1);
    V v_ru_24x2_24102_24MkPair = heff_take_reuse_n(v_x2_24102, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24100, v_e_240, v_x_24103}), v_n_24104});
  }
  default: return heff_nomatch(v_x2_24102);
  }
}
V g_heff_2eanf_2ebindAs_lam12(V self, V *args) {
  V v_n_24107 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24108 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str11), heff_intShow(heff_dup(v_n_24107)));
  V v_m_24109 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24108)})}));
  V v_x2_24110 = heff_tr(heff_apply(v_m_24109, 1, (V[]){heff_intAdd(v_n_24107, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24110)) {
  case TAG_MkPair: {
    V v_x_24111 = heff_field(v_x2_24110, 0);
    V v_n_24112 = heff_field(v_x2_24110, 1);
    V v_ru_24x2_24110_24MkPair = heff_take_reuse_n(v_x2_24110, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24108, v_e_240, v_x_24111}), v_n_24112});
  }
  default: return heff_nomatch(v_x2_24110);
  }
}
V g_heff_2eanf_2ebindAs_lam13(V self, V *args) {
  V v_n_24115 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24116 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str12), heff_intShow(heff_dup(v_n_24115)));
  V v_m_24117 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24116)})}));
  V v_x2_24118 = heff_tr(heff_apply(v_m_24117, 1, (V[]){heff_intAdd(v_n_24115, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24118)) {
  case TAG_MkPair: {
    V v_x_24119 = heff_field(v_x2_24118, 0);
    V v_n_24120 = heff_field(v_x2_24118, 1);
    V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24118_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24116, v_e_240, v_x_24119}), v_n_24120});
  }
  default: return heff_nomatch(v_x2_24118);
  }
}
V g_heff_2eanf_2ebindAs_lam14(V self, V *args) {
  V v_n_24123 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24124 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str13), heff_intShow(heff_dup(v_n_24123)));
  V v_m_24125 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24124)})}));
  V v_x2_24126 = heff_tr(heff_apply(v_m_24125, 1, (V[]){heff_intAdd(v_n_24123, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_field(v_x2_24126, 0);
    V v_n_24128 = heff_field(v_x2_24126, 1);
    V v_ru_24x2_24126_24MkPair = heff_take_reuse_n(v_x2_24126, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24126_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24124, v_e_240, v_x_24127}), v_n_24128});
  }
  default: return heff_nomatch(v_x2_24126);
  }
}
V g_heff_2eanf_2ebindAs_lam15(V self, V *args) {
  V v_n_24132 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24133 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str14), heff_intShow(heff_dup(v_n_24132)));
  V v_m_24134 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24133)})}));
  V v_x2_24135 = heff_tr(heff_apply(v_m_24134, 1, (V[]){heff_intAdd(v_n_24132, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_n_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24133, v_e_240, v_x_24136}), v_n_24137});
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2eanf_2ebindAs_lam16(V self, V *args) {
  V v_n_24140 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24141 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str15), heff_intShow(heff_dup(v_n_24140)));
  V v_m_24142 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24141)})}));
  V v_x2_24143 = heff_tr(heff_apply(v_m_24142, 1, (V[]){heff_intAdd(v_n_24140, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24143)) {
  case TAG_MkPair: {
    V v_x_24144 = heff_field(v_x2_24143, 0);
    V v_n_24145 = heff_field(v_x2_24143, 1);
    V v_ru_24x2_24143_24MkPair = heff_take_reuse_n(v_x2_24143, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24141, v_e_240, v_x_24144}), v_n_24145});
  }
  default: return heff_nomatch(v_x2_24143);
  }
}
V g_heff_2eanf_2ebindAs_lam17(V self, V *args) {
  V v_n_24147 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24148 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str16), heff_intShow(heff_dup(v_n_24147)));
  V v_m_24149 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24148)})}));
  V v_x2_24150 = heff_tr(heff_apply(v_m_24149, 1, (V[]){heff_intAdd(v_n_24147, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24150)) {
  case TAG_MkPair: {
    V v_x_24151 = heff_field(v_x2_24150, 0);
    V v_n_24152 = heff_field(v_x2_24150, 1);
    V v_ru_24x2_24150_24MkPair = heff_take_reuse_n(v_x2_24150, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24150_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24148, v_e_240, v_x_24151}), v_n_24152});
  }
  default: return heff_nomatch(v_x2_24150);
  }
}
V g_heff_2eanf_2ebindAs_lam18(V self, V *args) {
  V v_n_24156 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24157 = heff_strAppend(((V)&g_heff_2eanf_2ebindAs_str17), heff_intShow(heff_dup(v_n_24156)));
  V v_m_24158 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24157)})}));
  V v_x2_24159 = heff_tr(heff_apply(v_m_24158, 1, (V[]){heff_intAdd(v_n_24156, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_n_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24157, v_e_240, v_x_24160}), v_n_24161});
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eanf_2ebindAtom_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {116, 36}};
V g_heff_2eanf_2ebindAtom_lam0(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam1(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam2(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam3(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam4(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam5(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam6(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam7(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam8(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam9(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam10(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam11(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam12(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam13(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam14(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam15(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam16(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam17(V self, V *args);
V g_heff_2eanf_2ebindAtom_lam18(V self, V *args);
Clo g_heff_2eanf_2ebindAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2ebindAtom_entry, 2, 0};

V g_heff_2eanf_2ebindAtom(V v_e_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_2432;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam0, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_EGlobal: {
    V v_t_2469;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2469 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2469 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_2469)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam1, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_2469);
    }
  }
  case TAG_ELam: {
    V v_t_24107;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24107 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24107 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24107)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam2, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24107);
    }
  }
  case TAG_EApp: {
    V v_t_24145;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24145)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam3, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24145);
    }
  }
  case TAG_ELet: {
    V v_y_24152 = heff_field(v_e_240, 0);
    V v_c_24153 = heff_field(v_e_240, 1);
    V v_d_24154 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_24155 = heff_tr(g_heff_2eanf_2ebindAtom(v_d_24154, v_k_241));
    return heff_clo(g_heff_2eanf_2ebindAtom_lam4, 1, 3, (V[]){v_m_24155, v_y_24152, v_c_24153});
  }
  case TAG_ERecord: {
    V v_t_24190;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24190 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24190 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24190)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam5, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24190);
    }
  }
  case TAG_EProj: {
    V v_t_24228;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24228 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24228 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24228)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam6, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24228);
    }
  }
  case TAG_ETag: {
    V v_t_24266;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24266 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24266)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam7, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24266);
    }
  }
  case TAG_EMatch: {
    V v_t_24304;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24304 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24304 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24304)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam8, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24304);
    }
  }
  case TAG_EPrim: {
    V v_t_24341;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24341 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24341 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24341)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam9, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24341);
    }
  }
  case TAG_EPrimCall: {
    V v_t_24379;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24379 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24379 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24379)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam10, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24379);
    }
  }
  case TAG_ECall: {
    V v_t_24417;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24417 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24417 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24417)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam11, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24417);
    }
  }
  case TAG_EInt: {
    V v_t_24454;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24454 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24454 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24454)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam12, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24454);
    }
  }
  case TAG_EFloat: {
    V v_t_24491;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24491 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24491 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24491)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam13, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24491);
    }
  }
  case TAG_EStr: {
    V v_t_24528;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24528 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24528 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24528)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam14, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24528);
    }
  }
  case TAG_EFixed: {
    V v_t_24566;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24566 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24566 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24566)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam15, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24566);
    }
  }
  case TAG_EFloat32: {
    V v_t_24603;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24603 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24603 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24603)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam16, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24603);
    }
  }
  case TAG_EAbandon: {
    V v_t_24639;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24639 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24639 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24639)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam17, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24639);
    }
  }
  case TAG_EFix: {
    V v_t_24677;
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_24677 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_24677 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    switch (heff_tag_of(v_t_24677)) {
    case TAG_True: {
      return heff_tail(v_k_241, 1, (V[]){v_e_240});
    }
    case TAG_False: {
      return heff_clo(g_heff_2eanf_2ebindAtom_lam18, 1, 2, (V[]){v_k_241, v_e_240});
    }
    default: return heff_nomatch(v_t_24677);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eanf_2ebindAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2ebindAtom(a[0], a[1]);
}
V g_heff_2eanf_2ebindAtom_lam0(V self, V *args) {
  V v_n_2433 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2434 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str0), heff_intShow(heff_dup(v_n_2433)));
  V v_m_2435 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2434)})}));
  V v_x2_2436 = heff_tr(heff_apply(v_m_2435, 1, (V[]){heff_intAdd(v_n_2433, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2434, v_e_240, v_x_2437}), v_n_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2eanf_2ebindAtom_lam1(V self, V *args) {
  V v_n_2470 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2471 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str1), heff_intShow(heff_dup(v_n_2470)));
  V v_m_2472 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_2471)})}));
  V v_x2_2473 = heff_tr(heff_apply(v_m_2472, 1, (V[]){heff_intAdd(v_n_2470, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_MkPair: {
    V v_x_2474 = heff_field(v_x2_2473, 0);
    V v_n_2475 = heff_field(v_x2_2473, 1);
    V v_ru_24x2_2473_24MkPair = heff_take_reuse_n(v_x2_2473, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2471, v_e_240, v_x_2474}), v_n_2475});
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
V g_heff_2eanf_2ebindAtom_lam2(V self, V *args) {
  V v_n_24108 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24109 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str2), heff_intShow(heff_dup(v_n_24108)));
  V v_m_24110 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24109)})}));
  V v_x2_24111 = heff_tr(heff_apply(v_m_24110, 1, (V[]){heff_intAdd(v_n_24108, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24111)) {
  case TAG_MkPair: {
    V v_x_24112 = heff_field(v_x2_24111, 0);
    V v_n_24113 = heff_field(v_x2_24111, 1);
    V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24109, v_e_240, v_x_24112}), v_n_24113});
  }
  default: return heff_nomatch(v_x2_24111);
  }
}
V g_heff_2eanf_2ebindAtom_lam3(V self, V *args) {
  V v_n_24146 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24147 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str3), heff_intShow(heff_dup(v_n_24146)));
  V v_m_24148 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24147)})}));
  V v_x2_24149 = heff_tr(heff_apply(v_m_24148, 1, (V[]){heff_intAdd(v_n_24146, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkPair: {
    V v_x_24150 = heff_field(v_x2_24149, 0);
    V v_n_24151 = heff_field(v_x2_24149, 1);
    V v_ru_24x2_24149_24MkPair = heff_take_reuse_n(v_x2_24149, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24149_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24147, v_e_240, v_x_24150}), v_n_24151});
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
V g_heff_2eanf_2ebindAtom_lam4(V self, V *args) {
  V v_n_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_y_24152 = heff_env(self)[1];
  V v_c_24153 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24157 = heff_tr(heff_apply(v_m_24155, 1, (V[]){v_n_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_MkPair: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    V v_n_24159 = heff_field(v_x2_24157, 1);
    V v_ru_24x2_24157_24MkPair = heff_take_reuse_n(v_x2_24157, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_y_24152, v_c_24153, v_x_24158}), v_n_24159});
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2eanf_2ebindAtom_lam5(V self, V *args) {
  V v_n_24191 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24192 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str4), heff_intShow(heff_dup(v_n_24191)));
  V v_m_24193 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24192)})}));
  V v_x2_24194 = heff_tr(heff_apply(v_m_24193, 1, (V[]){heff_intAdd(v_n_24191, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24194)) {
  case TAG_MkPair: {
    V v_x_24195 = heff_field(v_x2_24194, 0);
    V v_n_24196 = heff_field(v_x2_24194, 1);
    V v_ru_24x2_24194_24MkPair = heff_take_reuse_n(v_x2_24194, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24192, v_e_240, v_x_24195}), v_n_24196});
  }
  default: return heff_nomatch(v_x2_24194);
  }
}
V g_heff_2eanf_2ebindAtom_lam6(V self, V *args) {
  V v_n_24229 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24230 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str5), heff_intShow(heff_dup(v_n_24229)));
  V v_m_24231 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24230)})}));
  V v_x2_24232 = heff_tr(heff_apply(v_m_24231, 1, (V[]){heff_intAdd(v_n_24229, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24232)) {
  case TAG_MkPair: {
    V v_x_24233 = heff_field(v_x2_24232, 0);
    V v_n_24234 = heff_field(v_x2_24232, 1);
    V v_ru_24x2_24232_24MkPair = heff_take_reuse_n(v_x2_24232, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24230, v_e_240, v_x_24233}), v_n_24234});
  }
  default: return heff_nomatch(v_x2_24232);
  }
}
V g_heff_2eanf_2ebindAtom_lam7(V self, V *args) {
  V v_n_24267 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24268 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str6), heff_intShow(heff_dup(v_n_24267)));
  V v_m_24269 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24268)})}));
  V v_x2_24270 = heff_tr(heff_apply(v_m_24269, 1, (V[]){heff_intAdd(v_n_24267, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24270)) {
  case TAG_MkPair: {
    V v_x_24271 = heff_field(v_x2_24270, 0);
    V v_n_24272 = heff_field(v_x2_24270, 1);
    V v_ru_24x2_24270_24MkPair = heff_take_reuse_n(v_x2_24270, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24268, v_e_240, v_x_24271}), v_n_24272});
  }
  default: return heff_nomatch(v_x2_24270);
  }
}
V g_heff_2eanf_2ebindAtom_lam8(V self, V *args) {
  V v_n_24305 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24306 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str7), heff_intShow(heff_dup(v_n_24305)));
  V v_m_24307 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24306)})}));
  V v_x2_24308 = heff_tr(heff_apply(v_m_24307, 1, (V[]){heff_intAdd(v_n_24305, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24308)) {
  case TAG_MkPair: {
    V v_x_24309 = heff_field(v_x2_24308, 0);
    V v_n_24310 = heff_field(v_x2_24308, 1);
    V v_ru_24x2_24308_24MkPair = heff_take_reuse_n(v_x2_24308, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24306, v_e_240, v_x_24309}), v_n_24310});
  }
  default: return heff_nomatch(v_x2_24308);
  }
}
V g_heff_2eanf_2ebindAtom_lam9(V self, V *args) {
  V v_n_24342 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24343 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str8), heff_intShow(heff_dup(v_n_24342)));
  V v_m_24344 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24343)})}));
  V v_x2_24345 = heff_tr(heff_apply(v_m_24344, 1, (V[]){heff_intAdd(v_n_24342, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24345)) {
  case TAG_MkPair: {
    V v_x_24346 = heff_field(v_x2_24345, 0);
    V v_n_24347 = heff_field(v_x2_24345, 1);
    V v_ru_24x2_24345_24MkPair = heff_take_reuse_n(v_x2_24345, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24345_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24343, v_e_240, v_x_24346}), v_n_24347});
  }
  default: return heff_nomatch(v_x2_24345);
  }
}
V g_heff_2eanf_2ebindAtom_lam10(V self, V *args) {
  V v_n_24380 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24381 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str9), heff_intShow(heff_dup(v_n_24380)));
  V v_m_24382 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24381)})}));
  V v_x2_24383 = heff_tr(heff_apply(v_m_24382, 1, (V[]){heff_intAdd(v_n_24380, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24383)) {
  case TAG_MkPair: {
    V v_x_24384 = heff_field(v_x2_24383, 0);
    V v_n_24385 = heff_field(v_x2_24383, 1);
    V v_ru_24x2_24383_24MkPair = heff_take_reuse_n(v_x2_24383, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24381, v_e_240, v_x_24384}), v_n_24385});
  }
  default: return heff_nomatch(v_x2_24383);
  }
}
V g_heff_2eanf_2ebindAtom_lam11(V self, V *args) {
  V v_n_24418 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24419 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str10), heff_intShow(heff_dup(v_n_24418)));
  V v_m_24420 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24419)})}));
  V v_x2_24421 = heff_tr(heff_apply(v_m_24420, 1, (V[]){heff_intAdd(v_n_24418, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24421)) {
  case TAG_MkPair: {
    V v_x_24422 = heff_field(v_x2_24421, 0);
    V v_n_24423 = heff_field(v_x2_24421, 1);
    V v_ru_24x2_24421_24MkPair = heff_take_reuse_n(v_x2_24421, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24419, v_e_240, v_x_24422}), v_n_24423});
  }
  default: return heff_nomatch(v_x2_24421);
  }
}
V g_heff_2eanf_2ebindAtom_lam12(V self, V *args) {
  V v_n_24455 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24456 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str11), heff_intShow(heff_dup(v_n_24455)));
  V v_m_24457 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24456)})}));
  V v_x2_24458 = heff_tr(heff_apply(v_m_24457, 1, (V[]){heff_intAdd(v_n_24455, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24458)) {
  case TAG_MkPair: {
    V v_x_24459 = heff_field(v_x2_24458, 0);
    V v_n_24460 = heff_field(v_x2_24458, 1);
    V v_ru_24x2_24458_24MkPair = heff_take_reuse_n(v_x2_24458, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24456, v_e_240, v_x_24459}), v_n_24460});
  }
  default: return heff_nomatch(v_x2_24458);
  }
}
V g_heff_2eanf_2ebindAtom_lam13(V self, V *args) {
  V v_n_24492 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24493 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str12), heff_intShow(heff_dup(v_n_24492)));
  V v_m_24494 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24493)})}));
  V v_x2_24495 = heff_tr(heff_apply(v_m_24494, 1, (V[]){heff_intAdd(v_n_24492, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24495)) {
  case TAG_MkPair: {
    V v_x_24496 = heff_field(v_x2_24495, 0);
    V v_n_24497 = heff_field(v_x2_24495, 1);
    V v_ru_24x2_24495_24MkPair = heff_take_reuse_n(v_x2_24495, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24493, v_e_240, v_x_24496}), v_n_24497});
  }
  default: return heff_nomatch(v_x2_24495);
  }
}
V g_heff_2eanf_2ebindAtom_lam14(V self, V *args) {
  V v_n_24529 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24530 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str13), heff_intShow(heff_dup(v_n_24529)));
  V v_m_24531 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24530)})}));
  V v_x2_24532 = heff_tr(heff_apply(v_m_24531, 1, (V[]){heff_intAdd(v_n_24529, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24532)) {
  case TAG_MkPair: {
    V v_x_24533 = heff_field(v_x2_24532, 0);
    V v_n_24534 = heff_field(v_x2_24532, 1);
    V v_ru_24x2_24532_24MkPair = heff_take_reuse_n(v_x2_24532, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24532_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24530, v_e_240, v_x_24533}), v_n_24534});
  }
  default: return heff_nomatch(v_x2_24532);
  }
}
V g_heff_2eanf_2ebindAtom_lam15(V self, V *args) {
  V v_n_24567 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24568 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str14), heff_intShow(heff_dup(v_n_24567)));
  V v_m_24569 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24568)})}));
  V v_x2_24570 = heff_tr(heff_apply(v_m_24569, 1, (V[]){heff_intAdd(v_n_24567, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24570)) {
  case TAG_MkPair: {
    V v_x_24571 = heff_field(v_x2_24570, 0);
    V v_n_24572 = heff_field(v_x2_24570, 1);
    V v_ru_24x2_24570_24MkPair = heff_take_reuse_n(v_x2_24570, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24570_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24568, v_e_240, v_x_24571}), v_n_24572});
  }
  default: return heff_nomatch(v_x2_24570);
  }
}
V g_heff_2eanf_2ebindAtom_lam16(V self, V *args) {
  V v_n_24604 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24605 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str15), heff_intShow(heff_dup(v_n_24604)));
  V v_m_24606 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24605)})}));
  V v_x2_24607 = heff_tr(heff_apply(v_m_24606, 1, (V[]){heff_intAdd(v_n_24604, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24607)) {
  case TAG_MkPair: {
    V v_x_24608 = heff_field(v_x2_24607, 0);
    V v_n_24609 = heff_field(v_x2_24607, 1);
    V v_ru_24x2_24607_24MkPair = heff_take_reuse_n(v_x2_24607, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24607_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24605, v_e_240, v_x_24608}), v_n_24609});
  }
  default: return heff_nomatch(v_x2_24607);
  }
}
V g_heff_2eanf_2ebindAtom_lam17(V self, V *args) {
  V v_n_24640 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24641 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str16), heff_intShow(heff_dup(v_n_24640)));
  V v_m_24642 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24641)})}));
  V v_x2_24643 = heff_tr(heff_apply(v_m_24642, 1, (V[]){heff_intAdd(v_n_24640, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24643)) {
  case TAG_MkPair: {
    V v_x_24644 = heff_field(v_x2_24643, 0);
    V v_n_24645 = heff_field(v_x2_24643, 1);
    V v_ru_24x2_24643_24MkPair = heff_take_reuse_n(v_x2_24643, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24643_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24641, v_e_240, v_x_24644}), v_n_24645});
  }
  default: return heff_nomatch(v_x2_24643);
  }
}
V g_heff_2eanf_2ebindAtom_lam18(V self, V *args) {
  V v_n_24678 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24679 = heff_strAppend(((V)&g_heff_2eanf_2ebindAtom_str17), heff_intShow(heff_dup(v_n_24678)));
  V v_m_24680 = heff_tr(heff_apply(v_k_241, 1, (V[]){heff_tag(TAG_EVar, 1, (V[]){heff_dup(v_x_24679)})}));
  V v_x2_24681 = heff_tr(heff_apply(v_m_24680, 1, (V[]){heff_intAdd(v_n_24678, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24681)) {
  case TAG_MkPair: {
    V v_x_24682 = heff_field(v_x2_24681, 0);
    V v_n_24683 = heff_field(v_x2_24681, 1);
    V v_ru_24x2_24681_24MkPair = heff_take_reuse_n(v_x2_24681, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_24681_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_24679, v_e_240, v_x_24682}), v_n_24683});
  }
  default: return heff_nomatch(v_x2_24681);
  }
}
V g_heff_2eanf_2eoperandsWith_lam2(V self, V *args);
V g_heff_2eanf_2eoperandsWith_lam1(V self, V *args);
V g_heff_2eanf_2eoperandsWith_lam0(V self, V *args);
Clo g_heff_2eanf_2eoperandsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2eoperandsWith_entry, 3, 0};

V g_heff_2eanf_2eoperandsWith(V v_go_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_apply(heff_dup(v_go_240), 1, (V[]){v_a_243}));
    return heff_clo(g_heff_2eanf_2eoperandsWith_lam0, 1, 4, (V[]){v_m_245, v_go_240, v_rest_244, v_k_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eanf_2eoperandsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2eoperandsWith(a[0], a[1], a[2]);
}
V g_heff_2eanf_2eoperandsWith_lam2(V self, V *args) {
  V v_rest_27_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_a_27_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_Cons, 2, (V[]){v_a_27_2410, v_rest_27_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eanf_2eoperandsWith_lam1(V self, V *args) {
  V v_a_27_2410 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_rest_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eanf_2eoperandsWith(v_go_240, v_rest_244, heff_clo(g_heff_2eanf_2eoperandsWith_lam2, 1, 2, (V[]){v_k_242, v_a_27_2410})));
}
V g_heff_2eanf_2eoperandsWith_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_apply(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    V v_t_2412 = heff_tr(g_heff_2eanf_2ebindAs(v_x_248, heff_clo(g_heff_2eanf_2eoperandsWith_lam1, 1, 3, (V[]){v_go_240, v_rest_244, v_k_242})));
    V f_ = v_t_2412;
    args[0] = v_n_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2eanf_2eflatLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2eflatLet_entry, 3, 0};

V g_heff_2eanf_2eflatLet(V v_x_240, V v_a_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_a_241)) {
  case TAG_EVar: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELam: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EApp: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ELet: {
    V v_y_249 = heff_field(v_a_241, 0);
    V v_c_2410 = heff_field(v_a_241, 1);
    V v_d_2411 = heff_field(v_a_241, 2);
    V v_ru_24a_241_24ELet = heff_take_reuse_n(v_a_241, 7ULL, 3);
    return heff_tag_at(v_ru_24a_241_24ELet, TAG_ELet, 3, (V[]){v_y_249, v_c_2410, (g_heff_2eanf_2eflatLet(v_x_240, v_d_2411, v_b_242))});
  }
  case TAG_ERecord: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EProj: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ETag: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EMatch: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrim: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EPrimCall: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_ECall: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EInt: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EStr: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFixed: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFloat32: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  case TAG_EFix: {
    return heff_tag(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_b_242});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2eanf_2eflatLet_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2eflatLet(a[0], a[1], a[2]);
}
Clo g_heff_2eanf_2elastOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2elastOf_entry, 1, 0};

V g_heff_2eanf_2elastOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eanf_2elastOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eanf_2elastOf(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eanf_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2einitOf_entry, 1, 0};

V g_heff_2eanf_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eanf_2einitOf(v_x12_242))});
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eanf_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2einitOf(a[0]);
}
V g_heff_2eanf_2etagN_lam0(V self, V *args);
V g_heff_2eanf_2etagN_lam1(V self, V *args);
V g_heff_2eanf_2etagN_lam2(V self, V *args);
V g_heff_2eanf_2etagN_lam3(V self, V *args);
V g_heff_2eanf_2etagN_lam4(V self, V *args);
V g_heff_2eanf_2etagN_lam5(V self, V *args);
V g_heff_2eanf_2etagN_lam6(V self, V *args);
V g_heff_2eanf_2etagN_lam7(V self, V *args);
V g_heff_2eanf_2etagN_lam8(V self, V *args);
V g_heff_2eanf_2etagN_lam9(V self, V *args);
V g_heff_2eanf_2etagN_lam10(V self, V *args);
V g_heff_2eanf_2etagN_lam11(V self, V *args);
V g_heff_2eanf_2etagN_lam14(V self, V *args);
V g_heff_2eanf_2etagN_lam13(V self, V *args);
V g_heff_2eanf_2etagN_lam12(V self, V *args);
V g_heff_2eanf_2etagN_lam15(V self, V *args);
V g_heff_2eanf_2etagN_lam16(V self, V *args);
V g_heff_2eanf_2etagN_lam17(V self, V *args);
V g_heff_2eanf_2etagN_lam18(V self, V *args);
V g_heff_2eanf_2etagN_lam19(V self, V *args);
V g_heff_2eanf_2etagN_lam20(V self, V *args);
V g_heff_2eanf_2etagN_lam21(V self, V *args);
Clo g_heff_2eanf_2etagN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2etagN_entry, 4, 0};

V g_heff_2eanf_2etagN(V v_go_240, V v_t_241, V v_as_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam0, 2, 1, (V[]){v_t_241})));
  }
  case TAG_Just: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_EVar: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam1, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EGlobal: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam2, 2, 1, (V[]){v_t_241})));
    }
    case TAG_ELam: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam3, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EApp: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam4, 2, 1, (V[]){v_t_241})));
    }
    case TAG_ELet: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam5, 2, 1, (V[]){v_t_241})));
    }
    case TAG_ERecord: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam6, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EProj: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam7, 2, 1, (V[]){v_t_241})));
    }
    case TAG_ETag: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam8, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EMatch: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam9, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EPrim: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam10, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EPrimCall: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam11, 2, 1, (V[]){v_t_241})));
    }
    case TAG_ECall: {
      V v_g_2448 = heff_field(v_x41_246, 0);
      V v_bs_2449 = heff_field(v_x41_246, 1);
      V v_t_2450 = (g_heff_2eanf_2einitOf(v_as_242));
      return (g_heff_2eanf_2eoperandsWith(heff_dup(v_go_240), v_t_2450, heff_clo(g_heff_2eanf_2etagN_lam12, 1, 4, (V[]){v_go_240, heff_dup(v_bs_2449), heff_dup(v_g_2448), v_t_241})));
    }
    case TAG_EInt: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam15, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EFloat: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam16, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EStr: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam17, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EFixed: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam18, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EFloat32: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam19, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EAbandon: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam20, 2, 1, (V[]){v_t_241})));
    }
    case TAG_EFix: {
      return (g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2etagN_lam21, 2, 1, (V[]){v_t_241})));
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eanf_2etagN_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eanf_2etagN(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2eanf_2etagN_lam0(V self, V *args) {
  V v_as_27_244 = args[0];
  V v_n_245 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_244}), v_n_245});
}
V g_heff_2eanf_2etagN_lam1(V self, V *args) {
  V v_as_27_248 = args[0];
  V v_n_249 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_248}), v_n_249});
}
V g_heff_2eanf_2etagN_lam2(V self, V *args) {
  V v_as_27_2411 = args[0];
  V v_n_2412 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2411}), v_n_2412});
}
V g_heff_2eanf_2etagN_lam3(V self, V *args) {
  V v_as_27_2415 = args[0];
  V v_n_2416 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2415}), v_n_2416});
}
V g_heff_2eanf_2etagN_lam4(V self, V *args) {
  V v_as_27_2419 = args[0];
  V v_n_2420 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2419}), v_n_2420});
}
V g_heff_2eanf_2etagN_lam5(V self, V *args) {
  V v_as_27_2424 = args[0];
  V v_n_2425 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2424}), v_n_2425});
}
V g_heff_2eanf_2etagN_lam6(V self, V *args) {
  V v_as_27_2427 = args[0];
  V v_n_2428 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2427}), v_n_2428});
}
V g_heff_2eanf_2etagN_lam7(V self, V *args) {
  V v_as_27_2431 = args[0];
  V v_n_2432 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2431}), v_n_2432});
}
V g_heff_2eanf_2etagN_lam8(V self, V *args) {
  V v_as_27_2435 = args[0];
  V v_n_2436 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2435}), v_n_2436});
}
V g_heff_2eanf_2etagN_lam9(V self, V *args) {
  V v_as_27_2439 = args[0];
  V v_n_2440 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2439}), v_n_2440});
}
V g_heff_2eanf_2etagN_lam10(V self, V *args) {
  V v_as_27_2442 = args[0];
  V v_n_2443 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2442}), v_n_2443});
}
V g_heff_2eanf_2etagN_lam11(V self, V *args) {
  V v_as_27_2446 = args[0];
  V v_n_2447 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2446}), v_n_2447});
}
V g_heff_2eanf_2etagN_lam14(V self, V *args) {
  V v_n_2455 = args[0];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2454, v_n_2455});
}
V g_heff_2eanf_2etagN_lam13(V self, V *args) {
  V v_bs_27_2452 = args[0];
  V v_g_2448 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_ini_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_g_2448, v_bs_27_2452}), NTAG(TAG_Nil)});
  V v_x_2454 = heff_tag(TAG_ETag, 2, (V[]){v_t_241, (g_prelude_2e_2b_2b(v_ini_2451, v_t_2453))});
  return heff_clo(g_heff_2eanf_2etagN_lam14, 1, 1, (V[]){v_x_2454});
}
V g_heff_2eanf_2etagN_lam12(V self, V *args) {
  V v_ini_2451 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_bs_2449 = heff_env(self)[1];
  V v_g_2448 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eanf_2eoperandsWith(v_go_240, v_bs_2449, heff_clo(g_heff_2eanf_2etagN_lam13, 1, 3, (V[]){v_g_2448, v_t_241, v_ini_2451})));
}
V g_heff_2eanf_2etagN_lam15(V self, V *args) {
  V v_as_27_2457 = args[0];
  V v_n_2458 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2457}), v_n_2458});
}
V g_heff_2eanf_2etagN_lam16(V self, V *args) {
  V v_as_27_2460 = args[0];
  V v_n_2461 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2460}), v_n_2461});
}
V g_heff_2eanf_2etagN_lam17(V self, V *args) {
  V v_as_27_2463 = args[0];
  V v_n_2464 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2463}), v_n_2464});
}
V g_heff_2eanf_2etagN_lam18(V self, V *args) {
  V v_as_27_2467 = args[0];
  V v_n_2468 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2467}), v_n_2468});
}
V g_heff_2eanf_2etagN_lam19(V self, V *args) {
  V v_as_27_2470 = args[0];
  V v_n_2471 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2470}), v_n_2471});
}
V g_heff_2eanf_2etagN_lam20(V self, V *args) {
  V v_as_27_2472 = args[0];
  V v_n_2473 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2472}), v_n_2473});
}
V g_heff_2eanf_2etagN_lam21(V self, V *args) {
  V v_as_27_2476 = args[0];
  V v_n_2477 = args[1];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_241, v_as_27_2476}), v_n_2477});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eanf_2eappendRight_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
V g_heff_2eanf_2eappendRight_lam0(V self, V *args);
V g_heff_2eanf_2eappendRight_lam1(V self, V *args);
V g_heff_2eanf_2eappendRight_lam2(V self, V *args);
V g_heff_2eanf_2eappendRight_lam3(V self, V *args);
V g_heff_2eanf_2eappendRight_lam4(V self, V *args);
V g_heff_2eanf_2eappendRight_lam5(V self, V *args);
V g_heff_2eanf_2eappendRight_lam6(V self, V *args);
V g_heff_2eanf_2eappendRight_lam7(V self, V *args);
V g_heff_2eanf_2eappendRight_lam8(V self, V *args);
V g_heff_2eanf_2eappendRight_lam9(V self, V *args);
V g_heff_2eanf_2eappendRight_lam10(V self, V *args);
V g_heff_2eanf_2eappendRight_lam11(V self, V *args);
V g_heff_2eanf_2eappendRight_lam14(V self, V *args);
V g_heff_2eanf_2eappendRight_lam13(V self, V *args);
V g_heff_2eanf_2eappendRight_lam12(V self, V *args);
V g_heff_2eanf_2eappendRight_lam15(V self, V *args);
V g_heff_2eanf_2eappendRight_lam16(V self, V *args);
V g_heff_2eanf_2eappendRight_lam17(V self, V *args);
V g_heff_2eanf_2eappendRight_lam18(V self, V *args);
V g_heff_2eanf_2eappendRight_lam19(V self, V *args);
V g_heff_2eanf_2eappendRight_lam20(V self, V *args);
V g_heff_2eanf_2eappendRight_lam21(V self, V *args);
V g_heff_2eanf_2eappendRight_lam22(V self, V *args);
V g_heff_2eanf_2eappendRight_lam23(V self, V *args);
V g_heff_2eanf_2eappendRight_lam24(V self, V *args);
Clo g_heff_2eanf_2eappendRight_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2eappendRight_entry, 3, 0};

V g_heff_2eanf_2eappendRight(V v_go_240, V v_e_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_m_244 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam0, 1, 2, (V[]){v_m_244, v_k_242});
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam1, 1, 2, (V[]){v_m_2411, v_k_242});
  }
  case TAG_ELam: {
    V v_m_2419 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam2, 1, 2, (V[]){v_m_2419, v_k_242});
  }
  case TAG_EApp: {
    V v_m_2427 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam3, 1, 2, (V[]){v_m_2427, v_k_242});
  }
  case TAG_ELet: {
    V v_m_2436 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam4, 1, 2, (V[]){v_m_2436, v_k_242});
  }
  case TAG_ERecord: {
    V v_m_2443 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam5, 1, 2, (V[]){v_m_2443, v_k_242});
  }
  case TAG_EProj: {
    V v_m_2451 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam6, 1, 2, (V[]){v_m_2451, v_k_242});
  }
  case TAG_ETag: {
    V v_m_2459 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam7, 1, 2, (V[]){v_m_2459, v_k_242});
  }
  case TAG_EMatch: {
    V v_m_2467 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam8, 1, 2, (V[]){v_m_2467, v_k_242});
  }
  case TAG_EPrim: {
    V v_m_2474 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam9, 1, 2, (V[]){v_m_2474, v_k_242});
  }
  case TAG_EPrimCall: {
    V v_p_2480 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_2481 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_2481)) {
    case TAG_Nil: {
      heff_drop(v_p_2480);
      V v_m_2482 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
      return heff_clo(g_heff_2eanf_2eappendRight_lam10, 1, 2, (V[]){v_m_2482, v_k_242});
    }
    case TAG_Cons: {
      V v_a_2488 = heff_field(v_e2_2481, 0);
      V v_e22_2489 = heff_field(v_e2_2481, 1);
      V v_ru_24e2_2481_24Cons = heff_take_reuse_n(v_e2_2481, 3ULL, 2);
      switch (heff_tag_of(v_e22_2489)) {
      case TAG_Nil: {
        heff_drop(v_p_2480);
        heff_drop(v_a_2488);
        heff_drop_cell(v_ru_24e2_2481_24Cons, 2);
        V v_m_2490 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
        return heff_clo(g_heff_2eanf_2eappendRight_lam11, 1, 2, (V[]){v_m_2490, v_k_242});
      }
      case TAG_Cons: {
        V v_b_2496 = heff_field(v_e22_2489, 0);
        V v_e222_2497 = heff_field(v_e22_2489, 1);
        V v_ru_24e22_2489_24Cons = heff_take_reuse_n(v_e22_2489, 3ULL, 2);
        switch (heff_tag_of(v_e222_2497)) {
        case TAG_Nil: {
          heff_drop_tag(v_e_241, 2);
          if (heff_strEq_c(heff_dup(v_p_2480), ((V)&g_heff_2eanf_2eappendRight_str0))) {
            heff_drop_cell(v_ru_24e2_2481_24Cons, 2);
            heff_drop_cell(v_ru_24e22_2489_24Cons, 2);
            V v_m_2499 = heff_tr(heff_apply(heff_dup(v_go_240), 1, (V[]){v_a_2488}));
            return heff_clo(g_heff_2eanf_2eappendRight_lam12, 1, 5, (V[]){v_m_2499, v_go_240, v_b_2496, v_p_2480, v_k_242});
          } else {
            V v_t_24109 = heff_tag_at(v_ru_24e2_2481_24Cons, TAG_Cons, 2, (V[]){v_b_2496, NTAG(TAG_Nil)});
            V v_t_24110 = heff_tag_at(v_ru_24e22_2489_24Cons, TAG_EPrimCall, 2, (V[]){v_p_2480, heff_tag(TAG_Cons, 2, (V[]){v_a_2488, v_t_24109})});
            V v_m_24111 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_t_24110}));
            return heff_clo(g_heff_2eanf_2eappendRight_lam15, 1, 2, (V[]){v_m_24111, v_k_242});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2497, 0ULL, 2);
          heff_drop(v_p_2480);
          heff_drop(v_a_2488);
          heff_drop_cell(v_ru_24e2_2481_24Cons, 2);
          heff_drop(v_b_2496);
          heff_drop_cell(v_ru_24e22_2489_24Cons, 2);
          V v_m_24119 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
          return heff_clo(g_heff_2eanf_2eappendRight_lam16, 1, 2, (V[]){v_m_24119, v_k_242});
        }
        default: return heff_nomatch(v_e222_2497);
        }
      }
      default: return heff_nomatch(v_e22_2489);
      }
    }
    default: return heff_nomatch(v_e2_2481);
    }
  }
  case TAG_ECall: {
    V v_g_24125 = heff_field(v_e_241, 0);
    V v_bs_24126 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    HEFF_LAST return g_heff_2eanf_2eoperandsWith(v_go_240, v_bs_24126, heff_clo(g_heff_2eanf_2eappendRight_lam17, 1, 2, (V[]){v_k_242, v_g_24125}));
  }
  case TAG_EInt: {
    V v_m_24129 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam18, 1, 2, (V[]){v_m_24129, v_k_242});
  }
  case TAG_EFloat: {
    V v_m_24136 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam19, 1, 2, (V[]){v_m_24136, v_k_242});
  }
  case TAG_EStr: {
    V v_m_24143 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam20, 1, 2, (V[]){v_m_24143, v_k_242});
  }
  case TAG_EFixed: {
    V v_m_24151 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam21, 1, 2, (V[]){v_m_24151, v_k_242});
  }
  case TAG_EFloat32: {
    V v_m_24158 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam22, 1, 2, (V[]){v_m_24158, v_k_242});
  }
  case TAG_EAbandon: {
    V v_m_24164 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam23, 1, 2, (V[]){v_m_24164, v_k_242});
  }
  case TAG_EFix: {
    V v_m_24172 = heff_tr(heff_apply(v_go_240, 1, (V[]){v_e_241}));
    return heff_clo(g_heff_2eanf_2eappendRight_lam24, 1, 2, (V[]){v_m_24172, v_k_242});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2eanf_2eappendRight_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2eappendRight(a[0], a[1], a[2]);
}
V g_heff_2eanf_2eappendRight_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_tr(g_heff_2eanf_2ebindAs(v_x_247, v_k_242));
    V f_ = v_t_249;
    args[0] = v_n_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eanf_2eappendRight_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    heff_take_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2414, v_k_242));
    V f_ = v_t_2416;
    args[0] = v_n_2415;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2eanf_2eappendRight_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2421 = heff_tr(heff_apply(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2422, v_k_242));
    V f_ = v_t_2424;
    args[0] = v_n_2423;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2eanf_2eappendRight_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2429 = heff_tr(heff_apply(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_n_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    V v_t_2432 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2430, v_k_242));
    V f_ = v_t_2432;
    args[0] = v_n_2431;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2eanf_2eappendRight_lam4(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_apply(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    heff_take_n(v_x2_2438, 3ULL, 2);
    V v_t_2441 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2439, v_k_242));
    V f_ = v_t_2441;
    args[0] = v_n_2440;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2eanf_2eappendRight_lam5(V self, V *args) {
  V v_n_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_apply(v_m_2443, 1, (V[]){v_n_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_n_2447 = heff_field(v_x2_2445, 1);
    heff_take_n(v_x2_2445, 3ULL, 2);
    V v_t_2448 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2446, v_k_242));
    V f_ = v_t_2448;
    args[0] = v_n_2447;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2eanf_2eappendRight_lam6(V self, V *args) {
  V v_n_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2453 = heff_tr(heff_apply(v_m_2451, 1, (V[]){v_n_2452}));
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_MkPair: {
    V v_x_2454 = heff_field(v_x2_2453, 0);
    V v_n_2455 = heff_field(v_x2_2453, 1);
    heff_take_n(v_x2_2453, 3ULL, 2);
    V v_t_2456 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2454, v_k_242));
    V f_ = v_t_2456;
    args[0] = v_n_2455;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_heff_2eanf_2eappendRight_lam7(V self, V *args) {
  V v_n_2460 = args[0];
  V v_m_2459 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2461 = heff_tr(heff_apply(v_m_2459, 1, (V[]){v_n_2460}));
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x2_2461, 0);
    V v_n_2463 = heff_field(v_x2_2461, 1);
    heff_take_n(v_x2_2461, 3ULL, 2);
    V v_t_2464 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2462, v_k_242));
    V f_ = v_t_2464;
    args[0] = v_n_2463;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2461);
  }
}
V g_heff_2eanf_2eappendRight_lam8(V self, V *args) {
  V v_n_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2469 = heff_tr(heff_apply(v_m_2467, 1, (V[]){v_n_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_x_2470 = heff_field(v_x2_2469, 0);
    V v_n_2471 = heff_field(v_x2_2469, 1);
    heff_take_n(v_x2_2469, 3ULL, 2);
    V v_t_2472 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2470, v_k_242));
    V f_ = v_t_2472;
    args[0] = v_n_2471;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2eanf_2eappendRight_lam9(V self, V *args) {
  V v_n_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2476 = heff_tr(heff_apply(v_m_2474, 1, (V[]){v_n_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_n_2478 = heff_field(v_x2_2476, 1);
    heff_take_n(v_x2_2476, 3ULL, 2);
    V v_t_2479 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2477, v_k_242));
    V f_ = v_t_2479;
    args[0] = v_n_2478;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2eanf_2eappendRight_lam10(V self, V *args) {
  V v_n_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2484 = heff_tr(heff_apply(v_m_2482, 1, (V[]){v_n_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    heff_take_n(v_x2_2484, 3ULL, 2);
    V v_t_2487 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2485, v_k_242));
    V f_ = v_t_2487;
    args[0] = v_n_2486;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2eanf_2eappendRight_lam11(V self, V *args) {
  V v_n_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2492 = heff_tr(heff_apply(v_m_2490, 1, (V[]){v_n_2491}));
  switch (heff_tag_of(v_x2_2492)) {
  case TAG_MkPair: {
    V v_x_2493 = heff_field(v_x2_2492, 0);
    V v_n_2494 = heff_field(v_x2_2492, 1);
    heff_take_n(v_x2_2492, 3ULL, 2);
    V v_t_2495 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2493, v_k_242));
    V f_ = v_t_2495;
    args[0] = v_n_2494;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2492);
  }
}
V g_heff_2eanf_2eappendRight_lam14(V self, V *args) {
  V v_b_27_24105 = args[0];
  V v_p_2480 = heff_env(self)[0];
  V v_a_27_24104 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24106 = heff_tag(TAG_Cons, 2, (V[]){v_b_27_24105, NTAG(TAG_Nil)});
  V v_t_24107 = heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2480, heff_tag(TAG_Cons, 2, (V[]){v_a_27_24104, v_t_24106})});
  V f_ = v_k_242;
  args[0] = v_t_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eanf_2eappendRight_lam13(V self, V *args) {
  V v_a_27_24104 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_b_2496 = heff_env(self)[1];
  V v_p_2480 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eanf_2eappendRight(v_go_240, v_b_2496, heff_clo(g_heff_2eanf_2eappendRight_lam14, 1, 3, (V[]){v_p_2480, v_a_27_24104, v_k_242})));
}
V g_heff_2eanf_2eappendRight_lam12(V self, V *args) {
  V v_n_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_b_2496 = heff_env(self)[2];
  V v_p_2480 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24101 = heff_tr(heff_apply(v_m_2499, 1, (V[]){v_n_24100}));
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    V v_n_24103 = heff_field(v_x2_24101, 1);
    heff_take_n(v_x2_24101, 3ULL, 2);
    V v_t_24108 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24102, heff_clo(g_heff_2eanf_2eappendRight_lam13, 1, 4, (V[]){v_go_240, v_b_2496, v_p_2480, v_k_242})));
    V f_ = v_t_24108;
    args[0] = v_n_24103;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2eanf_2eappendRight_lam15(V self, V *args) {
  V v_n_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24113 = heff_tr(heff_apply(v_m_24111, 1, (V[]){v_n_24112}));
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_MkPair: {
    V v_x_24114 = heff_field(v_x2_24113, 0);
    V v_n_24115 = heff_field(v_x2_24113, 1);
    heff_take_n(v_x2_24113, 3ULL, 2);
    V v_t_24116 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24114, v_k_242));
    V f_ = v_t_24116;
    args[0] = v_n_24115;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24113);
  }
}
V g_heff_2eanf_2eappendRight_lam16(V self, V *args) {
  V v_n_24120 = args[0];
  V v_m_24119 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24121 = heff_tr(heff_apply(v_m_24119, 1, (V[]){v_n_24120}));
  switch (heff_tag_of(v_x2_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_field(v_x2_24121, 0);
    V v_n_24123 = heff_field(v_x2_24121, 1);
    heff_take_n(v_x2_24121, 3ULL, 2);
    V v_t_24124 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24122, v_k_242));
    V f_ = v_t_24124;
    args[0] = v_n_24123;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24121);
  }
}
V g_heff_2eanf_2eappendRight_lam17(V self, V *args) {
  V v_bs_27_24127 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_g_24125 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag(TAG_ECall, 2, (V[]){v_g_24125, v_bs_27_24127});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eanf_2eappendRight_lam18(V self, V *args) {
  V v_n_24130 = args[0];
  V v_m_24129 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24131 = heff_tr(heff_apply(v_m_24129, 1, (V[]){v_n_24130}));
  switch (heff_tag_of(v_x2_24131)) {
  case TAG_MkPair: {
    V v_x_24132 = heff_field(v_x2_24131, 0);
    V v_n_24133 = heff_field(v_x2_24131, 1);
    heff_take_n(v_x2_24131, 3ULL, 2);
    V v_t_24134 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24132, v_k_242));
    V f_ = v_t_24134;
    args[0] = v_n_24133;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24131);
  }
}
V g_heff_2eanf_2eappendRight_lam19(V self, V *args) {
  V v_n_24137 = args[0];
  V v_m_24136 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24138 = heff_tr(heff_apply(v_m_24136, 1, (V[]){v_n_24137}));
  switch (heff_tag_of(v_x2_24138)) {
  case TAG_MkPair: {
    V v_x_24139 = heff_field(v_x2_24138, 0);
    V v_n_24140 = heff_field(v_x2_24138, 1);
    heff_take_n(v_x2_24138, 3ULL, 2);
    V v_t_24141 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24139, v_k_242));
    V f_ = v_t_24141;
    args[0] = v_n_24140;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24138);
  }
}
V g_heff_2eanf_2eappendRight_lam20(V self, V *args) {
  V v_n_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24145 = heff_tr(heff_apply(v_m_24143, 1, (V[]){v_n_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_n_24147 = heff_field(v_x2_24145, 1);
    heff_take_n(v_x2_24145, 3ULL, 2);
    V v_t_24148 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24146, v_k_242));
    V f_ = v_t_24148;
    args[0] = v_n_24147;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2eanf_2eappendRight_lam21(V self, V *args) {
  V v_n_24152 = args[0];
  V v_m_24151 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24153 = heff_tr(heff_apply(v_m_24151, 1, (V[]){v_n_24152}));
  switch (heff_tag_of(v_x2_24153)) {
  case TAG_MkPair: {
    V v_x_24154 = heff_field(v_x2_24153, 0);
    V v_n_24155 = heff_field(v_x2_24153, 1);
    heff_take_n(v_x2_24153, 3ULL, 2);
    V v_t_24156 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24154, v_k_242));
    V f_ = v_t_24156;
    args[0] = v_n_24155;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24153);
  }
}
V g_heff_2eanf_2eappendRight_lam22(V self, V *args) {
  V v_n_24159 = args[0];
  V v_m_24158 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24160 = heff_tr(heff_apply(v_m_24158, 1, (V[]){v_n_24159}));
  switch (heff_tag_of(v_x2_24160)) {
  case TAG_MkPair: {
    V v_x_24161 = heff_field(v_x2_24160, 0);
    V v_n_24162 = heff_field(v_x2_24160, 1);
    heff_take_n(v_x2_24160, 3ULL, 2);
    V v_t_24163 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24161, v_k_242));
    V f_ = v_t_24163;
    args[0] = v_n_24162;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24160);
  }
}
V g_heff_2eanf_2eappendRight_lam23(V self, V *args) {
  V v_n_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24166 = heff_tr(heff_apply(v_m_24164, 1, (V[]){v_n_24165}));
  switch (heff_tag_of(v_x2_24166)) {
  case TAG_MkPair: {
    V v_x_24167 = heff_field(v_x2_24166, 0);
    V v_n_24168 = heff_field(v_x2_24166, 1);
    heff_take_n(v_x2_24166, 3ULL, 2);
    V v_t_24169 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24167, v_k_242));
    V f_ = v_t_24169;
    args[0] = v_n_24168;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24166);
  }
}
V g_heff_2eanf_2eappendRight_lam24(V self, V *args) {
  V v_n_24173 = args[0];
  V v_m_24172 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24174 = heff_tr(heff_apply(v_m_24172, 1, (V[]){v_n_24173}));
  switch (heff_tag_of(v_x2_24174)) {
  case TAG_MkPair: {
    V v_x_24175 = heff_field(v_x2_24174, 0);
    V v_n_24176 = heff_field(v_x2_24174, 1);
    heff_take_n(v_x2_24174, 3ULL, 2);
    V v_t_24177 = heff_tr(g_heff_2eanf_2ebindAs(v_x_24175, v_k_242));
    V f_ = v_t_24177;
    args[0] = v_n_24176;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24174);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eanf_2eprimN_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
V g_heff_2eanf_2eprimN_lam0(V self, V *args);
V g_heff_2eanf_2eprimN_lam1(V self, V *args);
V g_heff_2eanf_2eprimN_lam4(V self, V *args);
V g_heff_2eanf_2eprimN_lam3(V self, V *args);
V g_heff_2eanf_2eprimN_lam2(V self, V *args);
V g_heff_2eanf_2eprimN_lam5(V self, V *args);
V g_heff_2eanf_2eprimN_lam6(V self, V *args);
Clo g_heff_2eanf_2eprimN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2eprimN_entry, 3, 0};

V g_heff_2eanf_2eprimN(V v_go_240, V v_p_241, V v_as_242) {
top: ;
  switch (heff_tag_of(v_as_242)) {
  case TAG_Nil: {
    HEFF_LAST return g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2eprimN_lam0, 2, 1, (V[]){v_p_241}));
  }
  case TAG_Cons: {
    V v_a_245 = heff_dup(heff_field(v_as_242, 0));
    V v_as2_246 = heff_dup(heff_field(v_as_242, 1));
    switch (heff_tag_of(v_as2_246)) {
    case TAG_Nil: {
      heff_drop(v_a_245);
      HEFF_LAST return g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2eprimN_lam1, 2, 1, (V[]){v_p_241}));
    }
    case TAG_Cons: {
      V v_b_249 = heff_field(v_as2_246, 0);
      V v_as22_2410 = heff_field(v_as2_246, 1);
      V v_ru_24as2_246_24Cons = heff_take_reuse_n(v_as2_246, 3ULL, 2);
      switch (heff_tag_of(v_as22_2410)) {
      case TAG_Nil: {
        heff_drop_tag(v_as_242, 2);
        if (heff_strEq_c(heff_dup(v_p_241), ((V)&g_heff_2eanf_2eprimN_str0))) {
          heff_drop_cell(v_ru_24as2_246_24Cons, 2);
          V v_m_2412 = heff_tr(heff_apply(heff_dup(v_go_240), 1, (V[]){v_a_245}));
          return heff_clo(g_heff_2eanf_2eprimN_lam2, 1, 4, (V[]){v_m_2412, v_go_240, v_b_249, v_p_241});
        } else {
          V v_t_2423 = heff_tag_at(v_ru_24as2_246_24Cons, TAG_Cons, 2, (V[]){v_b_249, NTAG(TAG_Nil)});
          HEFF_LAST return g_heff_2eanf_2eoperandsWith(v_go_240, heff_tag(TAG_Cons, 2, (V[]){v_a_245, v_t_2423}), heff_clo(g_heff_2eanf_2eprimN_lam5, 2, 1, (V[]){v_p_241}));
        }
      }
      case TAG_Cons: {
        heff_take_n(v_as22_2410, 0ULL, 2);
        heff_drop(v_a_245);
        heff_drop(v_b_249);
        heff_drop_cell(v_ru_24as2_246_24Cons, 2);
        HEFF_LAST return g_heff_2eanf_2eoperandsWith(v_go_240, v_as_242, heff_clo(g_heff_2eanf_2eprimN_lam6, 2, 1, (V[]){v_p_241}));
      }
      default: return heff_nomatch(v_as22_2410);
      }
    }
    default: return heff_nomatch(v_as2_246);
    }
  }
  default: return heff_nomatch(v_as_242);
  }
}
V g_heff_2eanf_2eprimN_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2eprimN(a[0], a[1], a[2]);
}
V g_heff_2eanf_2eprimN_lam0(V self, V *args) {
  V v_as_27_243 = args[0];
  V v_n_244 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_241, v_as_27_243}), v_n_244});
}
V g_heff_2eanf_2eprimN_lam1(V self, V *args) {
  V v_as_27_247 = args[0];
  V v_n_248 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_241, v_as_27_247}), v_n_248});
}
V g_heff_2eanf_2eprimN_lam4(V self, V *args) {
  V v_b_27_2418 = args[0];
  V v_n_2419 = args[1];
  V v_p_241 = heff_env(self)[0];
  V v_a_27_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_b_27_2418, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag(TAG_EPrimCall, 2, (V[]){v_p_241, heff_tag(TAG_Cons, 2, (V[]){v_a_27_2417, v_t_2420})});
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2421, v_n_2419});
}
V g_heff_2eanf_2eprimN_lam3(V self, V *args) {
  V v_a_27_2417 = args[0];
  V v_go_240 = heff_env(self)[0];
  V v_b_249 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eanf_2eappendRight(v_go_240, v_b_249, heff_clo(g_heff_2eanf_2eprimN_lam4, 2, 2, (V[]){v_p_241, v_a_27_2417})));
}
V g_heff_2eanf_2eprimN_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_b_249 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    V v_t_2422 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2415, heff_clo(g_heff_2eanf_2eprimN_lam3, 1, 3, (V[]){v_go_240, v_b_249, v_p_241})));
    V f_ = v_t_2422;
    args[0] = v_n_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2eanf_2eprimN_lam5(V self, V *args) {
  V v_as_27_2424 = args[0];
  V v_n_2425 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_241, v_as_27_2424}), v_n_2425});
}
V g_heff_2eanf_2eprimN_lam6(V self, V *args) {
  V v_as_27_2428 = args[0];
  V v_n_2429 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_241, v_as_27_2428}), v_n_2429});
}
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam0(V self, V *args); static Clo g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam0, 1, 0};
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam1(V self, V *args);
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam2(V self, V *args);
Clo g_heff_2eanf_2etraverseN_24s975503381x1824309035_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2etraverseN_24s975503381x1824309035_entry, 1, 0};

V g_heff_2eanf_2etraverseN_24s975503381x1824309035(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      V v_a_247 = heff_tr(g_heff_2eanf_2enorm(v_a_246));
      v_m_2412 = heff_clo(g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam1, 1, 3, (V[]){v_a_247, v_a_244, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    return heff_clo(g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam2, 1, 2, (V[]){v_m_2412, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2etraverseN_24s975503381x1824309035(a[0]);
}
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam1(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_a_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = heff_tr(heff_apply(v_a_247, 1, (V[]){v_a_248}));
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkPair: {
    V v_a_2410 = heff_field(v_a_249, 0);
    V v_a_2411 = heff_field(v_a_249, 1);
    V v_ru_24a_249_24MkPair = heff_take_reuse_n(v_a_249, 3ULL, 2);
    return heff_tag_at(v_ru_24a_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_MkArm, 3, (V[]){v_a_244, v_a_245, v_a_2410}), v_a_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_heff_2eanf_2etraverseN_24s975503381x1824309035_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_apply(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    V v_m_2417 = (g_heff_2eanf_2etraverseN_24s975503381x1824309035(v_xs_243));
    V v_x2_2418 = heff_tr(heff_apply(v_m_2417, 1, (V[]){v_n_2416}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2415, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2eanf_2enorm_lam0(V self, V *args);
V g_heff_2eanf_2enorm_lam1(V self, V *args);
V g_heff_2eanf_2enorm_lam2(V self, V *args);
V g_heff_2eanf_2enorm_lam5(V self, V *args);
V g_heff_2eanf_2enorm_lam4(V self, V *args);
V g_heff_2eanf_2enorm_lam3(V self, V *args);
V g_heff_2eanf_2enorm_lam6(V self, V *args);
V g_heff_2eanf_2enorm_lam8(V self, V *args);
V g_heff_2eanf_2enorm_lam7(V self, V *args);
V g_heff_2eanf_2enorm_lam10(V self, V *args);
V g_heff_2eanf_2enorm_lam9(V self, V *args);
V g_heff_2eanf_2enorm_lam13(V self, V *args);
V g_heff_2eanf_2enorm_lam12(V self, V *args);
V g_heff_2eanf_2enorm_lam11(V self, V *args);
V g_heff_2eanf_2enorm_lam14(V self, V *args);
V g_heff_2eanf_2enorm_lam15(V self, V *args);
V g_heff_2eanf_2enorm_lam16(V self, V *args);
V g_heff_2eanf_2enorm_lam17(V self, V *args);
V g_heff_2eanf_2enorm_lam18(V self, V *args);
V g_heff_2eanf_2enorm_lam19(V self, V *args);
V g_heff_2eanf_2enorm_lam20(V self, V *args);
V g_heff_2eanf_2enorm_lam21(V self, V *args);
V g_heff_2eanf_2enorm_lam22(V self, V *args);
Clo g_heff_2eanf_2enorm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2enorm_entry, 1, 0};

V g_heff_2eanf_2enorm(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_clo(g_heff_2eanf_2enorm_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    return heff_clo(g_heff_2eanf_2enorm_lam1, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_240, 0);
    V v_b_246 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2eanf_2enorm(v_b_246));
    return heff_clo(g_heff_2eanf_2enorm_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_240, 0);
    V v_as_2413 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_2414 = heff_tr(g_heff_2eanf_2enorm(v_f_2412));
    return heff_clo(g_heff_2eanf_2enorm_lam3, 1, 2, (V[]){v_m_2414, v_as_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_e_240, 0);
    V v_a_2424 = heff_field(v_e_240, 1);
    V v_b_2425 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_m_2426 = heff_tr(g_heff_2eanf_2enorm(v_a_2424));
    return heff_clo(g_heff_2eanf_2enorm_lam6, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V v_t_2437 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2436)));
    return (g_heff_2eanf_2eoperandsWith(((V)&g_heff_2eanf_2enorm_clo), v_t_2437, heff_clo(g_heff_2eanf_2enorm_lam7, 1, 1, (V[]){v_fs_2436})));
  }
  case TAG_EProj: {
    V v_e1_2441 = heff_field(v_e_240, 0);
    V v_l_2442 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_2443 = heff_tr(g_heff_2eanf_2enorm(v_e1_2441));
    return heff_clo(g_heff_2eanf_2enorm_lam9, 1, 2, (V[]){v_m_2443, v_l_2442});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_e_240, 0);
    V v_as_2452 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_t_2453 = (g_heff_2eanf_2elastOf(v_as_2452));
    return ({ V a_0 = ((V)&g_heff_2eanf_2enorm_clo); V a_1 = v_t_2451; V a_2 = v_as_2452; V a_3 = v_t_2453; V r_ = (g_heff_2eanf_2etagN(a_0, a_1, a_2, a_3)); heff_drop(v_t_2453); r_; });
  }
  case TAG_EMatch: {
    V v_s_2454 = heff_field(v_e_240, 0);
    V v_arms_2455 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_2456 = heff_tr(g_heff_2eanf_2enorm(v_s_2454));
    return heff_clo(g_heff_2eanf_2enorm_lam11, 1, 2, (V[]){v_m_2456, v_arms_2455});
  }
  case TAG_EPrim: {
    return heff_clo(g_heff_2eanf_2enorm_lam14, 1, 1, (V[]){v_e_240});
  }
  case TAG_EPrimCall: {
    V v_p_2470 = heff_field(v_e_240, 0);
    V v_as_2471 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    return (g_heff_2eanf_2eprimN(((V)&g_heff_2eanf_2enorm_clo), v_p_2470, v_as_2471));
  }
  case TAG_ECall: {
    V v_g_2472 = heff_field(v_e_240, 0);
    V v_as_2473 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    return (g_heff_2eanf_2eoperandsWith(((V)&g_heff_2eanf_2enorm_clo), v_as_2473, heff_clo(g_heff_2eanf_2enorm_lam15, 2, 1, (V[]){v_g_2472})));
  }
  case TAG_EInt: {
    return heff_clo(g_heff_2eanf_2enorm_lam16, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat: {
    return heff_clo(g_heff_2eanf_2enorm_lam17, 1, 1, (V[]){v_e_240});
  }
  case TAG_EStr: {
    return heff_clo(g_heff_2eanf_2enorm_lam18, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFixed: {
    return heff_clo(g_heff_2eanf_2enorm_lam19, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFloat32: {
    return heff_clo(g_heff_2eanf_2enorm_lam20, 1, 1, (V[]){v_e_240});
  }
  case TAG_EAbandon: {
    return heff_clo(g_heff_2eanf_2enorm_lam21, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFix: {
    return heff_clo(g_heff_2eanf_2enorm_lam22, 1, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eanf_2enorm_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2enorm(a[0]);
}
V g_heff_2eanf_2enorm_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_242});
}
V g_heff_2eanf_2enorm_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_244});
}
V g_heff_2eanf_2enorm_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eanf_2enorm_lam5(V self, V *args) {
  V v_as_27_2420 = args[0];
  V v_n_2421 = args[1];
  V v_f_27_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_27_2419, v_as_27_2420}), v_n_2421});
}
V g_heff_2eanf_2enorm_lam4(V self, V *args) {
  V v_f_27_2419 = args[0];
  V v_as_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eanf_2eoperandsWith(((V)&g_heff_2eanf_2enorm_clo), v_as_2413, heff_clo(g_heff_2eanf_2enorm_lam5, 2, 1, (V[]){v_f_27_2419})));
}
V g_heff_2eanf_2enorm_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_as_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    V v_t_2422 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2417, heff_clo(g_heff_2eanf_2enorm_lam4, 1, 1, (V[]){v_as_2413})));
    V f_ = v_t_2422;
    args[0] = v_n_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2eanf_2enorm_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_apply(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = heff_tr(g_heff_2eanf_2enorm(v_b_2425));
    V v_x2_2432 = heff_tr(heff_apply(v_m_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      V v_x_2435 = (g_heff_2eanf_2eflatLet(v_x_2423, v_x_2429, v_x_2433));
      return heff_tag_at(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2eanf_2enorm_lam8(V self, V *args) {
  V v_n_2440 = args[0];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_x_2439, v_n_2440});
}
V g_heff_2eanf_2enorm_lam7(V self, V *args) {
  V v_vs_2438 = args[0];
  V v_fs_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2439 = heff_tag(TAG_ERecord, 1, (V[]){(g_list_2ezipWith_24s1029292936x211450510(v_fs_2436, v_vs_2438))});
  return heff_clo(g_heff_2eanf_2enorm_lam8, 1, 1, (V[]){v_x_2439});
}
V g_heff_2eanf_2enorm_lam10(V self, V *args) {
  V v_e_27_2448 = args[0];
  V v_n_2449 = args[1];
  V v_l_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_27_2448, v_l_2442}), v_n_2449});
}
V g_heff_2eanf_2enorm_lam9(V self, V *args) {
  V v_n_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_apply(v_m_2443, 1, (V[]){v_n_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_n_2447 = heff_field(v_x2_2445, 1);
    heff_take_n(v_x2_2445, 3ULL, 2);
    V v_t_2450 = heff_tr(g_heff_2eanf_2ebindAs(v_x_2446, heff_clo(g_heff_2eanf_2enorm_lam10, 2, 1, (V[]){v_l_2442})));
    V f_ = v_t_2450;
    args[0] = v_n_2447;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2eanf_2enorm_lam13(V self, V *args) {
  V v_n_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  V v_s_27_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2464 = heff_tr(heff_apply(v_m_2462, 1, (V[]){v_n_2463}));
  switch (heff_tag_of(v_x2_2464)) {
  case TAG_MkPair: {
    V v_x_2465 = heff_field(v_x2_2464, 0);
    V v_n_2466 = heff_field(v_x2_2464, 1);
    V v_ru_24x2_2464_24MkPair = heff_take_reuse_n(v_x2_2464, 3ULL, 2);
    return heff_tag_at(v_ru_24x2_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_s_27_2461, v_x_2465}), v_n_2466});
  }
  default: return heff_nomatch(v_x2_2464);
  }
}
V g_heff_2eanf_2enorm_lam12(V self, V *args) {
  V v_s_27_2461 = args[0];
  V v_arms_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2462 = (g_heff_2eanf_2etraverseN_24s975503381x1824309035(v_arms_2455));
  return heff_clo(g_heff_2eanf_2enorm_lam13, 1, 2, (V[]){v_m_2462, v_s_27_2461});
}
V g_heff_2eanf_2enorm_lam11(V self, V *args) {
  V v_n_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_arms_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2458 = heff_tr(heff_apply(v_m_2456, 1, (V[]){v_n_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_n_2460 = heff_field(v_x2_2458, 1);
    heff_take_n(v_x2_2458, 3ULL, 2);
    V v_t_2467 = heff_tr(g_heff_2eanf_2ebindAtom(v_x_2459, heff_clo(g_heff_2eanf_2enorm_lam12, 1, 1, (V[]){v_arms_2455})));
    V f_ = v_t_2467;
    args[0] = v_n_2460;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2eanf_2enorm_lam14(V self, V *args) {
  V v_n_2469 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2469});
}
V g_heff_2eanf_2enorm_lam15(V self, V *args) {
  V v_as_27_2474 = args[0];
  V v_n_2475 = args[1];
  V v_g_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_g_2472, v_as_27_2474}), v_n_2475});
}
V g_heff_2eanf_2enorm_lam16(V self, V *args) {
  V v_n_2477 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2477});
}
V g_heff_2eanf_2enorm_lam17(V self, V *args) {
  V v_n_2479 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2479});
}
V g_heff_2eanf_2enorm_lam18(V self, V *args) {
  V v_n_2481 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2481});
}
V g_heff_2eanf_2enorm_lam19(V self, V *args) {
  V v_n_2484 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2484});
}
V g_heff_2eanf_2enorm_lam20(V self, V *args) {
  V v_n_2486 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2486});
}
V g_heff_2eanf_2enorm_lam21(V self, V *args) {
  V v_n_2487 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2487});
}
V g_heff_2eanf_2enorm_lam22(V self, V *args) {
  V v_n_2490 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_n_2490});
}
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam0(V self, V *args); static Clo g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam0, 1, 0};
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam1(V self, V *args);
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam2(V self, V *args);
Clo g_heff_2eanf_2etraverseN_24s370440749x1414765501_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eanf_2etraverseN_24s370440749x1414765501_entry, 1, 0};

V g_heff_2eanf_2etraverseN_24s370440749x1414765501(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2eanf_2enorm(heff_get(heff_dup(v_x_242), LBL_body)));
    V v_m_2410 = heff_clo(g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam1, 1, 2, (V[]){v_m_244, v_x_242});
    return heff_clo(g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam2, 1, 2, (V[]){v_m_2410, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_entry(V self, V *a) {
  (void)self;
  return g_heff_2eanf_2etraverseN_24s370440749x1414765501(a[0]);
}
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_rec(3, shape_key__name__body, (V[]){heff_get(heff_dup(v_x_242), LBL_key), heff_get(v_x_242, LBL_name), v_x_247});
    return heff_tag_at(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_n_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eanf_2etraverseN_24s370440749x1414765501_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_apply(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_m_2415 = (g_heff_2eanf_2etraverseN_24s370440749x1414765501(v_xs_243));
    V v_x2_2416 = heff_tr(heff_apply(v_m_2415, 1, (V[]){v_n_2414}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_n_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      return heff_tag_at(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x_2413, v_x_2417}), v_n_2418});
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}