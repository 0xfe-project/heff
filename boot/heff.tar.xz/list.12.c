// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayKeeps 39370
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CondBool 38021
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_RDup 30328
#define TAG_RPrimAt 2075
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SetField 47531
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_dir 308999
#define LBL_e 319
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_eqns 9616440
#define LBL_hidden 729654485
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_m 327
#define LBL_module 878357911
#define LBL_n 328
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_tags 10047712
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
V g_heff_2ebuild_2edocpages_2efirstParagraph(V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo;
V g_heff_2ebuild_2edocpages_2eheaderComment(V);
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo;
HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2erepr_2ementionedBy(V);
V g_heff_2ecompile_2erepr_2ementionedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ementionedBy_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2eunevenAt(V, V, V);
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunevenAt_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eany_24s1793712833x1452468429(V, V);
V g_list_2eany_24s1793712833x1452468429_entry(V self, V *a);
extern Clo g_list_2eany_24s1793712833x1452468429_clo;
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s775449825x1158002128_24cpr(V, V);
V g_list_2efoldl_24f1287822497x2111322144(V, V, V);
V g_list_2efoldl_24f1287822497x2111322144_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1287822497x2111322144_clo;
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24s1396019640x159929943(V, V, V);
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1396019640x159929943_clo;
V g_list_2efoldl_24s1513798766x1460159176(V, V);
V g_list_2efoldl_24s1513798766x1460159176_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513798766x1460159176_clo;
V g_list_2efoldl_24s1513798766x1460159176_24scalars(V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1513798766x1460159176_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1513798766x1460159176_24scalars_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s1923327646x248110754(V, V);
V g_list_2efoldl_24s1923327646x248110754_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923327646x248110754_clo;
V g_list_2efoldl_24s345718350x1678852400(V, V);
V g_list_2efoldl_24s345718350x1678852400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s345718350x1678852400_clo;
V g_list_2efoldl_24s510070423x219220408(V, V, V);
V g_list_2efoldl_24s510070423x219220408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s510070423x219220408_clo;
V g_list_2efoldl_24s585316429x898527369(V, V);
V g_list_2efoldl_24s585316429x898527369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s585316429x898527369_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s661788424x2062432904(V, V);
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a);
extern Clo g_list_2efoldl_24s661788424x2062432904_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
V g_list_2ekeepIf_24s2115931744x466898799_24dps(V, V, V);
V g_list_2ekeepIf_24s2115931744x466898799_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_24dps_clo;
V g_list_2ekeepIf_24s85961498x283047001(V);
V g_list_2ekeepIf_24s85961498x283047001_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s85961498x283047001_clo;
V g_list_2ekeepIf_24s85961498x283047001_24dps(V, V);
V g_list_2ekeepIf_24s85961498x283047001_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s85961498x283047001_24dps_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f1539731936x1117725130_24dps(V, V, V, V);
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_24dps_clo;
V g_list_2emap_24f669780424x1745768631(V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_clo;
V g_list_2emap_24f669780424x1745768631_24dps(V, V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_24dps_clo;
V g_list_2emap_24f889159142x1775976195_24dps(V, V, V, V, V);
V g_list_2emap_24f889159142x1775976195_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_24dps_clo;
V g_list_2emap_24f904804876x285797696(V, V, V);
V g_list_2emap_24f904804876x285797696_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_clo;
V g_list_2emap_24f904804876x285797696_24dps(V, V, V, V);
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_24dps_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1136209598x1881409718_24dps(V, V);
V g_list_2emap_24s1136209598x1881409718_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1136209598x1881409718_24dps_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1157931537x649184066_24dps(V, V, V);
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_24dps_clo;
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1386329375x1773300759_24dps(V, V);
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_24dps_clo;
V g_list_2emap_24s1415906091x1371825187_24dps(V, V);
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_24dps_clo;
V g_list_2emap_24s1517387949x485543551_24dps(V, V);
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_24dps_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1698496827x1884878103_24dps(V, V);
V g_list_2emap_24s1698496827x1884878103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_24dps_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24s2029356170x1054793697_24dps(V, V);
V g_list_2emap_24s2029356170x1054793697_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029356170x1054793697_24dps_clo;
V g_list_2emap_24s2081681776x559624592_24dps(V, V);
V g_list_2emap_24s2081681776x559624592_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_24dps_clo;
V g_list_2emap_24s2104774589x596860835_24dps(V, V);
V g_list_2emap_24s2104774589x596860835_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_24dps_clo;
V g_list_2emap_24s323105787x487030640(V, V, V, V, V, V, V);
V g_list_2emap_24s323105787x487030640_entry(V self, V *a);
extern Clo g_list_2emap_24s323105787x487030640_clo;
V g_list_2emap_24s323105787x487030640_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s323105787x487030640_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s323105787x487030640_24dps_clo;
V g_list_2emap_24s348263401x2104816219_24dps(V, V);
V g_list_2emap_24s348263401x2104816219_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_24dps_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s582709368x2113456071_24dps(V, V);
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_24dps_clo;
V g_list_2emap_24s631322900x900609068(V);
V g_list_2emap_24s631322900x900609068_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_clo;
V g_list_2emap_24s631322900x900609068_24dps(V, V);
V g_list_2emap_24s631322900x900609068_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_24dps_clo;
V g_list_2emap_24s674081137x339217813(V);
V g_list_2emap_24s674081137x339217813_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_clo;
V g_list_2emap_24s674081137x339217813_24dps(V, V);
V g_list_2emap_24s674081137x339217813_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_24dps_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24s89148281x951607804_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_24dps_clo;
V g_list_2emap_24s900318151x1569363206(V, V, V);
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_clo;
V g_list_2emap_24s900318151x1569363206_24dps(V, V, V, V);
V g_list_2emap_24s900318151x1569363206_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_24dps_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1029292936x211450510_24dps(V, V, V);
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo;
V g_list_2ezipWith_24s1893966264x617194987_24dps(V, V, V);
V g_list_2ezipWith_24s1893966264x617194987_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2ecli_2einteractive_2epartLabel(V);
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartLabel_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
Clo g_list_2emap_24s1415906091x1371825187_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_24dps_entry, 2, 0};

V g_list_2emap_24s1415906091x1371825187_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s2115931744x466898799_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2115931744x466898799_entry, 2, 0};

V g_list_2ekeepIf_24s2115931744x466898799(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2115931744x466898799_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s2115931744x466898799(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2efoldl_24s690313412x1307839513_str0, 1, "$");
Clo g_list_2efoldl_24s690313412x1307839513_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s690313412x1307839513_entry, 2, 0};

V g_list_2efoldl_24s690313412x1307839513(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_acc_244 = v_z_240;
    V v_n_245 = heff_take_field(v_acc_244, 1);
    V v_m_246 = heff_take_field(v_acc_244, 0);
    V v_xs_247 = heff_get_n(v_acc_244, 2, 3);
    V v_x_248 = v_x_242;
    V v_base_249 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_248), MK_INT(0LL)));
    V v_n_2410 = v_n_245;
    V v_x_27_2411 = heff_strAppend(heff_strAppend(v_base_249, ((V)&g_list_2efoldl_24s690313412x1307839513_str0)), heff_intShow(heff_dup(v_n_2410)));
    V v_t_2412 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_246, v_x_248, heff_dup(v_x_27_2411)));
    V v_t_2413 = heff_rec_n(3, shape_m__n__xs, (V[]){v_t_2412, heff_intAdd(v_n_2410, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_x_27_2411, v_xs_247})});
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s690313412x1307839513(a[0], a[1]);
}
Clo g_list_2emap_24s1044393341x1523302351_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_24dps_entry, 2, 0};

V g_list_2emap_24s1044393341x1523302351_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = ({ V a_0 = v_a_245; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_245); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s510070423x219220408_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s510070423x219220408_entry, 3, 0};

V g_list_2efoldl_24s510070423x219220408(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2413;
    if (heff_intLe_c_lent(v_t_247, v_lit_240, 1)) {
      V v_a_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_243, 0);
        v_a_2410 = heff_dup(v_a_248);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      switch (heff_tag_of(v_z_241)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_z_241, 0);
        V v_ru_24z_241_24Just = heff_take_reuse_n(v_z_241, 1ULL, 1);
        V v_t_2412;
        if (heff_intLt_c_lent(v_a_2411, v_a_2410, 0)) {
          heff_drop(v_a_2411);
          v_t_2412 = v_a_2410;
        } else {
          heff_drop(v_a_2410);
          v_t_2412 = v_a_2411;
        }
        v_t_2413 = heff_tag_at_n(v_ru_24z_241_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_z_241);
      }
    } else {
      v_t_2413 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2413;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s510070423x219220408_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s510070423x219220408(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1157931537x649184066_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1157931537x649184066_entry, 2, 0};

V g_list_2emap_24s1157931537x649184066(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2436;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_sp_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_ExplicitParam: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_xsp_249 = heff_field(v_x21_246, 1);
        V v_t_2410 = heff_field(v_x21_246, 2);
        V v_ru_24x21_246_24ExplicitParam = heff_take_reuse_n(v_x21_246, 7ULL, 3);
        V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_t_2410}));
        V v_t_2421;
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_IsInferable: {
          V v_i_2412 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24IsInferable = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
          V v_t_2415;
          switch (heff_tag_of(v_i_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_i_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_i_2412);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsInferable, TAG_TInf, 1, (V[]){v_i_2412}), v_t_2415});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2416 = heff_field(v_x1_2411, 0);
          V v_ru_24x1_2411_24IsCheckable = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
          V v_t_2419;
          switch (heff_tag_of(v_c_2416)) {
          case TAG_At: {
            V v_s_2418 = heff_dup(heff_field(v_c_2416, 1));
            v_t_2419 = v_s_2418;
            break;
          }
          default: heff_nomatch(v_c_2416);
          }
          v_t_2421 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2411_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2416}), v_t_2419});
          break;
        }
        case TAG_IsType: {
          V v_t_2420 = heff_field(v_x1_2411, 0);
          heff_take_n(v_x1_2411, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2421 = v_t_2420;
          break;
        }
        default: heff_nomatch(v_x1_2411);
        }
        v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_246_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_248, v_xsp_249, v_t_2421}), v_sp_247});
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2422 = heff_field(v_x21_246, 0);
        V v_xsp_2423 = heff_field(v_x21_246, 1);
        V v_t_2424 = heff_field(v_x21_246, 2);
        V v_ru_24x21_246_24ImplicitParam = heff_take_reuse_n(v_x21_246, 7ULL, 3);
        V v_x1_2425 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_t_2424}));
        V v_t_2435;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_IsInferable: {
          V v_i_2426 = heff_field(v_x1_2425, 0);
          V v_ru_24x1_2425_24IsInferable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_i_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_i_2426);
          }
          v_t_2435 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsInferable, TAG_TInf, 1, (V[]){v_i_2426}), v_t_2429});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2430 = heff_field(v_x1_2425, 0);
          V v_ru_24x1_2425_24IsCheckable = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
          V v_t_2433;
          switch (heff_tag_of(v_c_2430)) {
          case TAG_At: {
            V v_s_2432 = heff_dup(heff_field(v_c_2430, 1));
            v_t_2433 = v_s_2432;
            break;
          }
          default: heff_nomatch(v_c_2430);
          }
          v_t_2435 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2425_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2430}), v_t_2433});
          break;
        }
        case TAG_IsType: {
          V v_t_2434 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_245_24At, 2);
          v_t_2435 = v_t_2434;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_246_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2422, v_xsp_2423, v_t_2435}), v_sp_247});
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2437 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2436, heff_hole()});
    V v_u_2438 = (g_list_2emap_24s1157931537x649184066_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2437)));
    heff_drop(v_u_2438);
    return v_cell_2437;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1157931537x649184066(a[0], a[1]);
}
Clo g_list_2emap_24s348263401x2104816219_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s348263401x2104816219_24dps_entry, 2, 0};

V g_list_2emap_24s348263401x2104816219_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2esyntax_2esurface_2edeclNameOf(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s348263401x2104816219_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s348263401x2104816219_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2081681776x559624592_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081681776x559624592_24dps_entry, 2, 0};

V g_list_2emap_24s2081681776x559624592_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Left: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_d_245 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      V v_eqns_246 = heff_take_field(v_d_245, 3);
      V v_name_247 = heff_get_n(v_d_245, 0, 5);
      switch (heff_tag_of(v_eqns_246)) {
      case TAG_Nil: {
        heff_drop(v_name_247);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_it1_248 = heff_field(v_eqns_246, 0);
        V v_rest_249 = heff_field(v_eqns_246, 1);
        heff_take_n(v_eqns_246, 3ULL, 2);
        switch (heff_tag_of(v_it1_248)) {
        case TAG_At: {
          V v_it11_2410 = heff_field(v_it1_248, 0);
          heff_take_n(v_it1_248, 1ULL, 2);
          switch (heff_tag_of(v_it11_2410)) {
          case TAG_MkEquation: {
            V v_pats_2414 = heff_field(v_it11_2410, 2);
            heff_take_n(v_it11_2410, 4ULL, 4);
            V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_pats_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_pats_2414); r_; });
            v_t_2417 = ({ V a_0 = v_name_247; V a_1 = v_t_2416; V a_2 = v_rest_249; V r_ = (g_heff_2esyntax_2esurface_2eunevenAt(a_0, a_1, a_2)); heff_drop(v_rest_249); r_; });
            break;
          }
          default: heff_nomatch(v_it11_2410);
          }
          break;
        }
        default: heff_nomatch(v_it1_248);
        }
        break;
      }
      default: heff_nomatch(v_eqns_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081681776x559624592_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081681776x559624592_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1029292936x211450510_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_entry, 2, 0};

V g_list_2ezipWith_24s1029292936x211450510(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s1029292936x211450510_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510(a[0], a[1]);
}
Clo g_list_2efoldl_24s1923327646x248110754_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1923327646x248110754_entry, 2, 0};

V g_list_2efoldl_24s1923327646x248110754(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erepr_2ementionedBy(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1923327646x248110754_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1923327646x248110754(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1793712833x1452468429_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1793712833x1452468429_entry, 2, 0};

V g_list_2eany_24s1793712833x1452468429(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1793712833x1452468429_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1793712833x1452468429(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1793250635x935291087_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1793250635x935291087_entry, 1, 0};

V g_list_2eall_24s1793250635x935291087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_GivenU: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_LentVar: {
      V v_x12_247 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_x12_247)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x12_247);
      }
    }
    case TAG_LentValue: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1793250635x935291087(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s585316429x898527369_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s585316429x898527369_entry, 2, 0};

V g_list_2efoldl_24s585316429x898527369(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s345718350x1678852400(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s585316429x898527369_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s585316429x898527369(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1136209598x1881409718_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1136209598x1881409718_24dps_entry, 2, 0};

V g_list_2emap_24s1136209598x1881409718_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_b_244 = heff_field(v_x_242, 0);
      V v_r_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_RDup, 1, (V[]){v_b_244}), NTAG(TAG_Nil)});
      V v_t_247 = heff_tag_n(TAG_RPrimAt, 3, (V[]){NTAG(TAG_ArrayKeeps), v_r_245, v_t_246});
      v_t_248 = heff_tag_n(TAG_CondBool, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_xs_243;
    V t_1 = v_cell_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1136209598x1881409718_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1136209598x1881409718_24dps(a[0], a[1]);
}

HeffT2 g_list_2efind_24s775449825x1158002128_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eany_24s781693278x668067139_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s781693278x668067139_entry, 2, 0};

V g_list_2eany_24s781693278x668067139(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_lit_240, v_x_242, 0)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s781693278x668067139_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s781693278x668067139(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s868530262x539343671_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s868530262x539343671_entry, 2, 0};

V g_list_2efoldl_24s868530262x539343671(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_z_240, heff_dup(v_l_246), heff_dup(v_i_244)));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s868530262x539343671(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s323105787x487030640_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s323105787x487030640_entry, 7, 0};

V g_list_2emap_24s323105787x487030640(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_a_249; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_249); r_; });
      V v_t_2412 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2411), heff_dup(v_lit_243));
      V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2412), heff_dup(v_lit_244));
      V v_t_2414 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2415 = heff_strAppend(heff_strAppend(v_t_2413, v_t_2414), heff_dup(v_lit_245));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s323105787x487030640_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s323105787x487030640_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s323105787x487030640(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str0, 7, "Float64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str10, 1, "_");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str11, 1, "\?");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str12, 7, "Float64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str13, 4, "Int8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str14, 5, "Int16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str15, 5, "Int32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str16, 5, "Int64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str17, 5, "UInt8");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str18, 6, "UInt16");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str19, 6, "UInt32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str20, 6, "UInt64");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str21, 7, "Float32");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str22, 1, "_");
HEFF_LIT(g_list_2ezipWith_24s1893966264x617194987_24dps_str23, 1, "\?");
Clo g_list_2ezipWith_24s1893966264x617194987_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1893966264x617194987_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1893966264x617194987_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_a_247 = v_x_243;
      V v_b_248 = v_y_245;
      V v_t_2410;
      switch (heff_tag_of(v_a_247)) {
      case TAG_FtFloat: {
        v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str0);
        break;
      }
      case TAG_FtFixed: {
        V v_w_249 = heff_dup(heff_field(v_a_247, 0));
        switch (heff_tag_of(v_w_249)) {
        case TAG_I8: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str1);
          break;
        }
        case TAG_I16: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str2);
          break;
        }
        case TAG_I32: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str3);
          break;
        }
        case TAG_I64: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str4);
          break;
        }
        case TAG_U8: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str5);
          break;
        }
        case TAG_U16: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str6);
          break;
        }
        case TAG_U32: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str7);
          break;
        }
        case TAG_U64: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str8);
          break;
        }
        case TAG_F32: {
          v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str9);
          break;
        }
        default: heff_nomatch(v_w_249);
        }
        break;
      }
      case TAG_FtOther: {
        v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str10);
        break;
      }
      case TAG_FtAny: {
        v_t_2410 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str11);
        break;
      }
      default: heff_nomatch(v_a_247);
      }
      V v_t_2412;
      switch (heff_tag_of(v_b_248)) {
      case TAG_FtFloat: {
        v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str12);
        break;
      }
      case TAG_FtFixed: {
        V v_w_2411 = heff_field(v_b_248, 0);
        heff_take_n(v_b_248, 1ULL, 1);
        switch (heff_tag_of(v_w_2411)) {
        case TAG_I8: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str13);
          break;
        }
        case TAG_I16: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str14);
          break;
        }
        case TAG_I32: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str15);
          break;
        }
        case TAG_I64: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str16);
          break;
        }
        case TAG_U8: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str17);
          break;
        }
        case TAG_U16: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str18);
          break;
        }
        case TAG_U32: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str19);
          break;
        }
        case TAG_U64: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str20);
          break;
        }
        case TAG_F32: {
          v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str21);
          break;
        }
        default: heff_nomatch(v_w_2411);
        }
        break;
      }
      case TAG_FtOther: {
        v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str22);
        break;
      }
      case TAG_FtAny: {
        v_t_2412 = ((V)&g_list_2ezipWith_24s1893966264x617194987_24dps_str23);
        break;
      }
      default: heff_nomatch(v_b_248);
      }
      V v_t_2413;
      if (heff_strEq_c(v_t_2410, v_t_2412)) {
        v_t_2413 = v_a_247;
      } else {
        heff_drop(v_a_247);
        v_t_2413 = NTAG(TAG_FtOther);
      }
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2414));
      heff_drop(v_u_2415);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_2414;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1893966264x617194987_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1893966264x617194987_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s89148281x951607804_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s89148281x951607804_entry, 7, 0};

V g_list_2emap_24s89148281x951607804(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_lit_240; V a_2 = heff_dup(v_lit_241); V a_3 = heff_strFind_lent(v_lit_242, v_x_247, v_lit_243, 0); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
    V v_a_2410 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_a_2410)) {
    case TAG_Nil: {
      v_t_2413 = heff_dup(v_lit_244);
      break;
    }
    case TAG_Cons: {
      V v_a_2411 = heff_field(v_a_2410, 0);
      V v_a_2412 = heff_field(v_a_2410, 1);
      heff_take_n(v_a_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = heff_dup(v_lit_245); V a_1 = v_a_2411; V a_2 = v_a_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2412); r_; });
      break;
    }
    default: heff_nomatch(v_a_2410);
    }
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s89148281x951607804_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s89148281x951607804_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s89148281x951607804(a0, a[1], a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str0, 1, "V");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str1, 6, "double");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str2, 7, "int64_t");
Clo g_list_2emap_24s1386329375x1773300759_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386329375x1773300759_entry, 1, 0};

V g_list_2emap_24s1386329375x1773300759(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_244 = ({ V a_0 = v_w_243; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_243); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str1);
      break;
    }
    case TAG_RepInt: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str2);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1386329375x1773300759_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386329375x1773300759(a[0]);
}
Clo g_list_2efoldl_24s1513798766x1460159176_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1513798766x1460159176_entry, 2, 0};

V g_list_2efoldl_24s1513798766x1460159176(V v_z_240, V v_x3_241) {
top: ;
  V v_order_242 = heff_take_field(v_z_240, 0);
  V v_entries_243 = heff_take_field(v_z_240, 1);
  V v_aliases_244 = heff_take_field(v_z_240, 2);
  V v_broken_245 = heff_take_field(v_z_240, 3);
  V v_ambiguous_246 = heff_take_field(v_z_240, 4);
  V v_places_247 = heff_take_field(v_z_240, 5);
  V v_hidden_248 = heff_take_field(v_z_240, 6);
  V v_instances_249 = heff_get_n(v_z_240, 7, 8);
  return (g_list_2efoldl_24s1513798766x1460159176_24scalars(v_order_242, v_entries_243, v_aliases_244, v_broken_245, v_ambiguous_246, v_places_247, v_hidden_248, v_instances_249, v_x3_241));
}
V g_list_2efoldl_24s1513798766x1460159176_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1513798766x1460159176(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str10, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str11, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str12, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str13, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str14, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str15, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str16, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str17, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str18, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str19, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str20, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str21, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str22, 0, "");
HEFF_LIT(g_list_2emap_24s1517387949x485543551_24dps_str23, 0, "");
Clo g_list_2emap_24s1517387949x485543551_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1517387949x485543551_24dps_entry, 2, 0};

V g_list_2emap_24s1517387949x485543551_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_v_244 = v_x_242;
    V v_t_2418;
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_248 = heff_dup(heff_field(v_v_244, 1));
      v_t_2418 = v_vs_248;
      break;
    }
    case TAG_VInt: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_244);
    }
    HeffT3 v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2418; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2438;
    {
      V v_field_2421 = v_t_2419.f[1];
      V v_field_2422 = v_t_2419.f[2];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2421;
        V v_x12_2424 = v_field_2422;
        heff_drop(v_x12_2424);
        switch (heff_tag_of(v_x_2423)) {
        case TAG_VFun: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str0);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str1);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2423, 0ULL, 2);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str2);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str3);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str4);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str5);
          break;
        }
        case TAG_VStr: {
          V v_s_2432 = heff_field(v_x_2423, 0);
          heff_take_n(v_x_2423, 1ULL, 1);
          v_t_2438 = v_s_2432;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str6);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str7);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str8);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2423, 0ULL, 2);
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str9);
          break;
        }
        case TAG_VErased: {
          v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str10);
          break;
        }
        default: heff_nomatch(v_x_2423);
        }
      } else {
        heff_drop(v_field_2421);
        heff_drop(v_field_2422);
        v_t_2438 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str11);
      }
    }
    V v_t_2452;
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2442 = heff_field(v_v_244, 1);
      heff_take_n(v_v_244, 2ULL, 2);
      v_t_2452 = v_vs_2442;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_v_244, 0ULL, 2);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_244);
    }
    HeffT3 v_t_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2472;
    {
      V v_field_2455 = v_t_2453.f[1];
      V v_field_2456 = v_t_2453.f[2];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2457 = v_field_2455;
        V v_x12_2458 = v_field_2456;
        heff_drop(v_x12_2458);
        switch (heff_tag_of(v_x_2457)) {
        case TAG_VFun: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str12);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str13);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2457, 0ULL, 2);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str14);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str15);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str16);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str17);
          break;
        }
        case TAG_VStr: {
          V v_s_2466 = heff_field(v_x_2457, 0);
          heff_take_n(v_x_2457, 1ULL, 1);
          v_t_2472 = v_s_2466;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str18);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str19);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str20);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2457, 0ULL, 2);
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str21);
          break;
        }
        case TAG_VErased: {
          v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str22);
          break;
        }
        default: heff_nomatch(v_x_2457);
        }
      } else {
        heff_drop(v_field_2455);
        heff_drop(v_field_2456);
        v_t_2472 = ((V)&g_list_2emap_24s1517387949x485543551_24dps_str23);
      }
    }
    V v_cell_2473 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_t_2472}), heff_hole()});
    V v_u_2474 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2473));
    heff_drop(v_u_2474);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2473;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1517387949x485543551_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s900318151x1569363206_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s900318151x1569363206_entry, 3, 0};

V g_list_2emap_24s900318151x1569363206(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_tags_246 = heff_get_n(v_x_243, 1, 3);
    V v_t_247;
    if ((heff_dup(v_tags_246) == NTAG(TAG_True))) {
      heff_drop(v_tags_246);
      v_t_247 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_tags_246);
      v_t_247 = heff_dup(v_lit_241);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_name_245, v_t_247), heff_hole()});
    V v_u_249 = (g_list_2emap_24s900318151x1569363206_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s900318151x1569363206(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str0, 9, "{ name = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str1, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str2, 2, " }");
Clo g_list_2emap_24s404123879x745642248_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_24dps_entry, 2, 0};

V g_list_2emap_24s404123879x745642248_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_dir_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = ({ V a_0 = v_name_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_244); r_; });
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_24dps_str0), v_t_246), ((V)&g_list_2emap_24s404123879x745642248_24dps_str1));
    V v_t_248 = ({ V a_0 = v_dir_245; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_dir_245); r_; });
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_247, v_t_248), ((V)&g_list_2emap_24s404123879x745642248_24dps_str2));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_str1, 1, ".");
Clo g_list_2ekeepIf_24s85961498x283047001_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s85961498x283047001_entry, 1, 0};

V g_list_2ekeepIf_24s85961498x283047001(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_241, ((V)&g_list_2ekeepIf_24s85961498x283047001_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_241, ((V)&g_list_2ekeepIf_24s85961498x283047001_str1), 2))) {
      V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s85961498x283047001_24dps(v_xs_242, heff_dup(v_cell_243)));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s85961498x283047001_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s85961498x283047001(a[0]);
}
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_24dps_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_24dps_str1, 1, ".");
Clo g_list_2ekeepIf_24s85961498x283047001_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s85961498x283047001_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s85961498x283047001_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_242, ((V)&g_list_2ekeepIf_24s85961498x283047001_24dps_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_242, ((V)&g_list_2ekeepIf_24s85961498x283047001_24dps_str1), 2))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
      heff_drop(v_u_245);
      V t_0 = v_xs_243;
      V t_1 = v_cell_244;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s85961498x283047001_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s85961498x283047001_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s173442543x1801751270_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_entry, 1, 0};

V g_list_2emap_24s173442543x1801751270(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s173442543x1801751270_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270(a[0]);
}
Clo g_list_2efoldl_24s189033563x26633104_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s189033563x26633104_entry, 2, 0};

V g_list_2efoldl_24s189033563x26633104(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s189033563x26633104(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1698496827x1884878103_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1698496827x1884878103_entry, 1, 0};

V g_list_2emap_24s1698496827x1884878103(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 14), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1698496827x1884878103_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1698496827x1884878103(a[0]);
}
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str10, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str11, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str12, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str13, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str14, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str15, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str16, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str17, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str18, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str19, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str20, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str21, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str22, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str23, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str24, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str25, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str26, 0, "");
HEFF_LIT(g_list_2emap_24s2029356170x1054793697_24dps_str27, 0, "");
Clo g_list_2emap_24s2029356170x1054793697_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029356170x1054793697_24dps_entry, 2, 0};

V g_list_2emap_24s2029356170x1054793697_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_244 = v_x_242;
    V v_t_2429;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_JNull: {
      v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str0), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str1)});
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x1_244, 0ULL, 1);
      v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str2), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str3)});
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x1_244, 0ULL, 1);
      v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str4), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str5)});
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x1_244, 0ULL, 1);
      v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str6), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str7)});
      break;
    }
    case TAG_JString: {
      heff_take_n(v_x1_244, 0ULL, 1);
      v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str8), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str9)});
      break;
    }
    case TAG_JArray: {
      V v_x11_249 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      switch (heff_tag_of(v_x11_249)) {
      case TAG_Nil: {
        v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str10), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str11)});
        break;
      }
      case TAG_Cons: {
        V v_n_2410 = heff_field(v_x11_249, 0);
        V v_x112_2411 = heff_field(v_x11_249, 1);
        V v_ru_24x11_249_24Cons = heff_take_reuse_n(v_x11_249, 3ULL, 2);
        switch (heff_tag_of(v_x112_2411)) {
        case TAG_Nil: {
          heff_drop(v_n_2410);
          v_t_2429 = heff_tag_at_n(v_ru_24x11_249_24Cons, TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str12), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str13)});
          break;
        }
        case TAG_Cons: {
          V v_t_2412 = heff_field(v_x112_2411, 0);
          heff_take_n(v_x112_2411, 1ULL, 2);
          V v_t_2420;
          switch (heff_tag_of(v_n_2410)) {
          case TAG_JNull: {
            v_t_2420 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str14);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_n_2410, 0ULL, 1);
            v_t_2420 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str15);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_n_2410, 0ULL, 1);
            v_t_2420 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str16);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_n_2410, 0ULL, 1);
            v_t_2420 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str17);
            break;
          }
          case TAG_JString: {
            V v_t_2417 = heff_field(v_n_2410, 0);
            heff_take_n(v_n_2410, 1ULL, 1);
            v_t_2420 = v_t_2417;
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_n_2410, 0ULL, 1);
            v_t_2420 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str18);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_n_2410, 0ULL, 1);
            v_t_2420 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str19);
            break;
          }
          default: heff_nomatch(v_n_2410);
          }
          V v_t_2427;
          switch (heff_tag_of(v_t_2412)) {
          case TAG_JNull: {
            v_t_2427 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str20);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_t_2412, 0ULL, 1);
            v_t_2427 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str21);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_t_2412, 0ULL, 1);
            v_t_2427 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str22);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_t_2412, 0ULL, 1);
            v_t_2427 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str23);
            break;
          }
          case TAG_JString: {
            V v_t_2424 = heff_field(v_t_2412, 0);
            heff_take_n(v_t_2412, 1ULL, 1);
            v_t_2427 = v_t_2424;
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_t_2412, 0ULL, 1);
            v_t_2427 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str24);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_t_2412, 0ULL, 1);
            v_t_2427 = ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str25);
            break;
          }
          default: heff_nomatch(v_t_2412);
          }
          v_t_2429 = heff_tag_at_n(v_ru_24x11_249_24Cons, TAG_MkPair, 2, (V[]){v_t_2420, v_t_2427});
          break;
        }
        default: heff_nomatch(v_x112_2411);
        }
        break;
      }
      default: heff_nomatch(v_x11_249);
      }
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x1_244, 0ULL, 1);
      v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s2029356170x1054793697_24dps_str26), ((V)&g_list_2emap_24s2029356170x1054793697_24dps_str27)});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_cell_2430 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
    V v_u_2431 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2430));
    heff_drop(v_u_2431);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2430;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029356170x1054793697_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029356170x1054793697_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2104774589x596860835_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2104774589x596860835_24dps_entry, 2, 0};

V g_list_2emap_24s2104774589x596860835_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2104774589x596860835_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2104774589x596860835_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s674081137x339217813_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s674081137x339217813_entry, 1, 0};

V g_list_2emap_24s674081137x339217813(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if ((heff_runeLe_c(MK_INT(65LL), heff_dup(v_x_241)) && heff_runeLe_c(heff_dup(v_x_241), MK_INT(90LL)))) {
      V v_t_243 = heff_intAdd(heff_runeToInt(v_x_241), MK_INT(32LL));
      v_t_244 = heff_runeFromInt(v_t_243);
    } else {
      v_t_244 = v_x_241;
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s674081137x339217813_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s674081137x339217813_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s674081137x339217813(a[0]);
}
HEFF_LIT(g_list_2emap_24s631322900x900609068_str0, 4, "- [`");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str1, 3, "`](");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str2, 1, ".");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str3, 1, ".");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str4, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str5, 1, "/");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str6, 3, ".md");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str7, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str8, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str9, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str10, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str11, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str12, 1, " ");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str13, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str14, 1, "\012");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str15, 0, "");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str16, 1, " ");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str17, 2, ": ");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str18, 1, ")");
HEFF_LIT(g_list_2emap_24s631322900x900609068_str19, 1, "\012");
Clo g_list_2emap_24s631322900x900609068_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s631322900x900609068_entry, 1, 0};

V g_list_2emap_24s631322900x900609068(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_c_243 = v_x_241;
    V v_module_244 = heff_take_field(v_c_243, 0);
    V v_source_245 = heff_get_n(v_c_243, 3, 14);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s631322900x900609068_str0), heff_dup(v_module_244)), ((V)&g_list_2emap_24s631322900x900609068_str1));
    V v_m_247 = v_module_244;
    V v_x2_248 = ({ V a_0 = v_m_247; V b_1 = ((V)&g_list_2emap_24s631322900x900609068_str2); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s631322900x900609068_str3), v_m_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_m_247); heff_drop(b_1); r_; });
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_list_2emap_24s631322900x900609068_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_list_2emap_24s631322900x900609068_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(v_t_246, heff_strAppend(v_t_2411, ((V)&g_list_2emap_24s631322900x900609068_str6)));
    V v_t_2413 = (g_heff_2ebuild_2edocpages_2eheaderComment(v_source_245));
    V v_t_2430;
    if (heff_strEq_c(v_t_2413, ((V)&g_list_2emap_24s631322900x900609068_str7))) {
      heff_drop(v_source_245);
      v_t_2430 = ((V)&g_list_2emap_24s631322900x900609068_str8);
    } else {
      V v_header_2414 = ({ V a_0 = v_source_245; V r_ = (g_heff_2ebuild_2edocpages_2eheaderComment(a_0)); heff_drop(v_source_245); r_; });
      V v_t_2415 = ({ V a_0 = v_header_2414; V b_1 = ((V)&g_list_2emap_24s631322900x900609068_str9); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s631322900x900609068_str10), v_header_2414, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_x2_2416 = (g_heff_2ebuild_2edocpages_2efirstParagraph(v_t_2415));
      V v_s_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_s_2419 = ((V)&g_list_2emap_24s631322900x900609068_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_s_2419 = ({ V a_0 = ((V)&g_list_2emap_24s631322900x900609068_str12); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      V v_t_2420 = ({ V a_0 = v_header_2414; V b_1 = ((V)&g_list_2emap_24s631322900x900609068_str13); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_list_2emap_24s631322900x900609068_str14), v_header_2414, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_header_2414); heff_drop(b_1); r_; });
      V v_x2_2421 = (g_heff_2ebuild_2edocpages_2efirstParagraph(v_t_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_list_2emap_24s631322900x900609068_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_list_2emap_24s631322900x900609068_str16); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      HeffT2 v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
      V v_t_2429;
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_i_2428 = v_field_2427;
          v_t_2429 = heff_strSlice(v_s_2419, MK_INT(0LL), heff_intAdd(v_i_2428, MK_INT(1LL)));
        } else {
          heff_drop(v_field_2427);
          v_t_2429 = v_s_2419;
        }
      }
      v_t_2430 = heff_strAppend(((V)&g_list_2emap_24s631322900x900609068_str17), v_t_2429);
    }
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_list_2emap_24s631322900x900609068_str18)), v_t_2430);
    V v_cell_2432 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2431, ((V)&g_list_2emap_24s631322900x900609068_str19)), heff_hole()});
    V v_u_2433 = (g_list_2emap_24s631322900x900609068_24dps(v_xs_242, heff_dup(v_cell_2432)));
    heff_drop(v_u_2433);
    return v_cell_2432;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s631322900x900609068_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s631322900x900609068(a[0]);
}
Clo g_list_2efoldl_24s661788424x2062432904_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s661788424x2062432904_entry, 2, 0};

V g_list_2efoldl_24s661788424x2062432904(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = heff_get_n(v_t_246, 1, 2);
    V v_t_248;
    if (heff_intLe_c_lent(v_z_240, v_a_247, 0)) {
      heff_drop(v_z_240);
      v_t_248 = v_a_247;
    } else {
      heff_drop(v_a_247);
      v_t_248 = v_z_240;
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s661788424x2062432904(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s582709368x2113456071_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s582709368x2113456071_24dps_entry, 2, 0};

V g_list_2emap_24s582709368x2113456071_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s582709368x2113456071_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1396019640x159929943_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1396019640x159929943_entry, 3, 0};

V g_list_2efoldl_24s1396019640x159929943(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_a_245 = (g_std_2ecli_2einteractive_2epartLabel(heff_rfield(v_x_243, 0)));
    V v_a_246 = ({ V a_0 = heff_dup(v_lit_240); V b_1 = heff_strRunes(v_a_245); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_247;
    if (heff_intLe_c_lent(v_z_241, v_a_246, 0)) {
      heff_drop(v_z_241);
      v_t_247 = v_a_246;
    } else {
      heff_drop(v_a_246);
      v_t_247 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_247;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1396019640x159929943(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1287822497x2111322144_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1287822497x2111322144_entry, 3, 0};

V g_list_2efoldl_24f1287822497x2111322144(V v_z_240, V v_x1_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_242);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_241, 0);
    V v_ms_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      heff_drop(v_m_243);
      heff_drop(v_ms_244);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_242, 0);
      V v_argv_246 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      if ((heff_dup(v_m_243) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_a_245, v_z_240});
        V t_1 = v_ms_244;
        V t_2 = v_argv_246;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      } else {
        heff_drop(v_m_243);
        heff_drop_cell(v_ru_24x1_241_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_z_240;
        V t_1 = v_ms_244;
        V t_2 = v_argv_246;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1287822497x2111322144_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1287822497x2111322144(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f889159142x1775976195_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f889159142x1775976195_24dps_entry, 5, 0};

V g_list_2emap_24f889159142x1775976195_24dps(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243, V v_d_244) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245;
    if (heff_intEq_c_lent(v_a_242, v_lit_240, 0)) {
      v_t_245 = heff_dup(v_lit_241);
    } else {
      v_t_245 = NTAG(TAG_RepV);
    }
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
    V t_3 = v_b_243;
    V t_4 = v_cell_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_list_2emap_24f889159142x1775976195_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f889159142x1775976195_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24f1229912102x1467950109_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_entry, 2, 0};

V g_list_2emap_24f1229912102x1467950109(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      HEFF_LAST return g_list_2emap_24s2029035892x1571084362_24tok2(v_ru_24x2_241_24Cons, v_xs_243);
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_245 = (g_list_2emap_24f1229912102x1467950109_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109(a[0], a[1]);
}
Clo g_list_2emap_24f1539731936x1117725130_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1539731936x1117725130_24dps_entry, 4, 0};

V g_list_2emap_24f1539731936x1117725130_24dps(V v_lit_240, V v_i_241, V v_n_242, V v_d_243) {
top: ;
  if (heff_intLe_c_lent(v_n_242, v_i_241, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_n_242;
    V t_3 = v_cell_244;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1539731936x1117725130_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f669780424x1745768631_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f669780424x1745768631_entry, 5, 0};

V g_list_2emap_24f669780424x1745768631(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 2);
      v_x_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2410 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_t_2411 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_242), heff_strLength_lent(v_a_2410, 0));
    V v_t_2415;
    if (heff_strEq_c(v_t_2411, v_a_2410)) {
      V v_t_2412 = heff_strLength(heff_dup(heff_rfield(v_lit_240, 0)));
      V v_t_2413 = heff_strSlice(heff_dup(v_x_249), heff_box_word((heff_unbox_word(v_t_2412) + heff_peek_word(v_lit_243))), heff_strLength_lent(v_x_249, 0));
      V v_t_2414 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_2413, v_x_249, heff_dup(heff_rfield(v_lit_240, 0))});
      v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      heff_drop(v_x_249);
      v_t_2415 = NTAG(TAG_Nothing);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24f669780424x1745768631_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f669780424x1745768631_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24f669780424x1745768631(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f904804876x285797696_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f904804876x285797696_entry, 3, 0};

V g_list_2emap_24f904804876x285797696(V v_f_240, V v_box_24a_241, V v_b_242) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
top: ;
  if ((heff_peek_word(v_b_242) < v_a_241)) {
    heff_drop(v_f_240);
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_243 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_box_word(v_a_241)}));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24f904804876x285797696_24dps(v_f_240, heff_box_word((v_a_241 + ((int64_t)1ULL))), v_b_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f904804876x285797696_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f904804876x285797696(a[0], a[1], a[2]);
}