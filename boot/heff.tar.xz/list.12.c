// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_FtAny 18156
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_I64 19315
#define TAG_ImplicitParam 51130
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Many 40086
#define TAG_MkAlt 55173
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_Plain 3036
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Rest 61983
#define TAG_Right 62770
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SetField 47531
#define TAG_Some 35657
#define TAG_TagVariant 25174
#define LBL_arity 294440695
#define LBL_back 9511342
#define LBL_backend 2032133329
#define LBL_body 9524841
#define LBL_build 295453320
#define LBL_checked 974171621
#define LBL_code 9554612
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_front 299063875
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_meta 9843404
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_numbered 1006183371
#define LBL_ops 319788
#define LBL_owner 307523277
#define LBL_part 9928890
#define LBL_path 9928940
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_tags 10047712
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_text__style[] = {LBL_text, LBL_style};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsonGolden(V);
V g_heff_2ebuild_2ecommands_2ejsonGolden_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonGolden_clo;
V g_heff_2ebuild_2edocpages_2eindexLine(V);
V g_heff_2ebuild_2edocpages_2eindexLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eindexLine_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24tok2(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24tok2_clo;
V g_heff_2ebuild_2edriver_2eelabWith(V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabWith_clo;
V g_heff_2ebuild_2edriver_2egoldenOfV(V);
V g_heff_2ebuild_2edriver_2egoldenOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2egoldenOfV_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2efacts_2earityOne(V, V);
V g_heff_2ecompile_2efacts_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2earityOne_clo;
HeffT2 g_heff_2ecompile_2efuse_2eproducerOf_24cpr(V, V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_clo;
V g_heff_2ecompile_2eglue_2eglueOf(V, V, V);
V g_heff_2ecompile_2eglue_2eglueOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2eglueOf_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1(V, V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_24tok1_clo;
V g_heff_2ecompile_2eir_2efreshBindOne(V, V);
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshBindOne_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806(V, V);
V g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806_clo;
V g_heff_2ecompile_2eowned_2eownSt(V, V, V);
V g_heff_2ecompile_2eowned_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eownSt_clo;
V g_heff_2ecompile_2erepr_2ementionedBy(V);
V g_heff_2ecompile_2erepr_2ementionedBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ementionedBy_clo;
V g_heff_2ecompile_2escalars_2emergeTy(V, V);
V g_heff_2ecompile_2escalars_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2emergeTy_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2epresyntax_2earmStmts(V);
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2eunevenAt(V, V, V);
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunevenAt_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eall_24s262401054x194288545(V, V);
V g_list_2eall_24s262401054x194288545_entry(V self, V *a);
extern Clo g_list_2eall_24s262401054x194288545_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s105899861x584770213(V);
V g_list_2eany_24s105899861x584770213_entry(V self, V *a);
extern Clo g_list_2eany_24s105899861x584770213_clo;
V g_list_2eany_24s1338755034x1627180165(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1338755034x1627180165_entry(V self, V *a);
extern Clo g_list_2eany_24s1338755034x1627180165_clo;
V g_list_2eany_24s1672254115x651817494(V, V);
V g_list_2eany_24s1672254115x651817494_entry(V self, V *a);
extern Clo g_list_2eany_24s1672254115x651817494_clo;
V g_list_2eany_24s285809686x1684902122(V, V);
V g_list_2eany_24s285809686x1684902122_entry(V self, V *a);
extern Clo g_list_2eany_24s285809686x1684902122_clo;
V g_list_2eany_24s624430845x1248965393(V);
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a);
extern Clo g_list_2eany_24s624430845x1248965393_clo;
V g_list_2eany_24s781693278x668067139(V, V);
V g_list_2eany_24s781693278x668067139_entry(V self, V *a);
extern Clo g_list_2eany_24s781693278x668067139_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efind_24s1136367117x833793205(V, V);
V g_list_2efind_24s1136367117x833793205_entry(V self, V *a);
extern Clo g_list_2efind_24s1136367117x833793205_clo;
HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V, V);
HeffT2 g_list_2efind_24s775449825x1158002128_24cpr(V, V);
V g_list_2efoldl_24f1582053009x1594640150(V, V, V, V, V);
V g_list_2efoldl_24f1582053009x1594640150_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1582053009x1594640150_clo;
V g_list_2efoldl_24f1663632568x709545076(V, V, V, V);
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1663632568x709545076_clo;
V g_list_2efoldl_24f928374809x1955888331(V, V);
V g_list_2efoldl_24f928374809x1955888331_entry(V self, V *a);
extern Clo g_list_2efoldl_24f928374809x1955888331_clo;
V g_list_2efoldl_24f932140008x904662204(V, V, V);
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f932140008x904662204_clo;
V g_list_2efoldl_24s114050048x1903860601(V, V);
V g_list_2efoldl_24s114050048x1903860601_entry(V self, V *a);
extern Clo g_list_2efoldl_24s114050048x1903860601_clo;
V g_list_2efoldl_24s1232551929x416126852(V, V);
V g_list_2efoldl_24s1232551929x416126852_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1232551929x416126852_clo;
V g_list_2efoldl_24s1299324685x840794767(V, V);
V g_list_2efoldl_24s1299324685x840794767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1299324685x840794767_clo;
V g_list_2efoldl_24s1315672171x449285703(V, V);
V g_list_2efoldl_24s1315672171x449285703_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1315672171x449285703_clo;
V g_list_2efoldl_24s1396019640x159929943(V, V, V);
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1396019640x159929943_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s1923327646x248110754(V, V);
V g_list_2efoldl_24s1923327646x248110754_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923327646x248110754_clo;
V g_list_2efoldl_24s2062876492x2082655823(V, V);
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_clo;
V g_list_2efoldl_24s2062876492x2082655823_24scalars(V, V, V);
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo;
V g_list_2efoldl_24s345718350x1678852400(V, V);
V g_list_2efoldl_24s345718350x1678852400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s345718350x1678852400_clo;
V g_list_2efoldl_24s490001784x345683100(V, V);
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a);
extern Clo g_list_2efoldl_24s490001784x345683100_clo;
V g_list_2efoldl_24s510070423x219220408(V, V, V);
V g_list_2efoldl_24s510070423x219220408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s510070423x219220408_clo;
V g_list_2efoldl_24s585316429x898527369(V, V);
V g_list_2efoldl_24s585316429x898527369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s585316429x898527369_clo;
V g_list_2efoldl_24s586610394x1672960104(V, V);
V g_list_2efoldl_24s586610394x1672960104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s586610394x1672960104_clo;
V g_list_2efoldl_24s644818311x440862174(V, V, V);
V g_list_2efoldl_24s644818311x440862174_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644818311x440862174_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s661788424x2062432904(V, V);
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a);
extern Clo g_list_2efoldl_24s661788424x2062432904_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2efoldl_24s995130411x810552597(V, V);
V g_list_2efoldl_24s995130411x810552597_entry(V self, V *a);
extern Clo g_list_2efoldl_24s995130411x810552597_clo;
V g_list_2ekeepIf_24s122741325x871243494_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_24dps_clo;
V g_list_2ekeepIf_24s1441124185x871809048_24dps(V, V, V);
V g_list_2ekeepIf_24s1441124185x871809048_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1441124185x871809048_24dps_clo;
V g_list_2ekeepIf_24s1457049037x722637222(V);
V g_list_2ekeepIf_24s1457049037x722637222_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_clo;
V g_list_2ekeepIf_24s1457049037x722637222_24dps(V, V);
V g_list_2ekeepIf_24s1457049037x722637222_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_24dps_clo;
V g_list_2ekeepIf_24s1823913665x1128491553(V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_clo;
V g_list_2ekeepIf_24s1823913665x1128491553_24dps(V, V, V);
V g_list_2ekeepIf_24s1823913665x1128491553_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1823913665x1128491553_24dps_clo;
V g_list_2ekeepIf_24s185327080x101197346(V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_clo;
V g_list_2ekeepIf_24s185327080x101197346_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s185327080x101197346_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s185327080x101197346_24dps_clo;
V g_list_2ekeepIf_24s2053104128x1598844325(V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_clo;
V g_list_2ekeepIf_24s2053104128x1598844325_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s2053104128x1598844325_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2053104128x1598844325_24dps_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
V g_list_2ekeepIf_24s2115931744x466898799_24dps(V, V, V);
V g_list_2ekeepIf_24s2115931744x466898799_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_24dps_clo;
V g_list_2ekeepIf_24s257286374x378693326_24dps(V, V, V);
V g_list_2ekeepIf_24s257286374x378693326_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s257286374x378693326_24dps_clo;
V g_list_2ekeepIf_24s423901581x541836270(V, V);
V g_list_2ekeepIf_24s423901581x541836270_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_clo;
V g_list_2ekeepIf_24s423901581x541836270_24dps(V, V, V);
V g_list_2ekeepIf_24s423901581x541836270_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s423901581x541836270_24dps_clo;
V g_list_2ekeepIf_24s512765522x2052101617_24dps(V, V, V);
V g_list_2ekeepIf_24s512765522x2052101617_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_24dps_clo;
V g_list_2ekeepIf_24s636499273x1023552697(V, V);
V g_list_2ekeepIf_24s636499273x1023552697_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s636499273x1023552697_clo;
V g_list_2ekeepIf_24s636499273x1023552697_24dps(V, V, V);
V g_list_2ekeepIf_24s636499273x1023552697_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s636499273x1023552697_24dps_clo;
V g_list_2ekeepIf_24s708019417x1279437633_24dps(V, V, V);
V g_list_2ekeepIf_24s708019417x1279437633_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s708019417x1279437633_24dps_clo;
V g_list_2ekeepIf_24s738919255x1142813117(V, V, V, V);
V g_list_2ekeepIf_24s738919255x1142813117_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s738919255x1142813117_clo;
V g_list_2ekeepIf_24s738919255x1142813117_24dps(V, V, V, V, V);
V g_list_2ekeepIf_24s738919255x1142813117_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s738919255x1142813117_24dps_clo;
V g_list_2ekeepIf_24s742867582x682687968_24dps(V, V, V);
V g_list_2ekeepIf_24s742867582x682687968_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s742867582x682687968_24dps_clo;
V g_list_2ekeepIf_24s85961498x283047001(V);
V g_list_2ekeepIf_24s85961498x283047001_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s85961498x283047001_clo;
V g_list_2ekeepIf_24s85961498x283047001_24dps(V, V);
V g_list_2ekeepIf_24s85961498x283047001_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s85961498x283047001_24dps_clo;
V g_list_2emap_24f1016251237x587084191(V, V, V);
V g_list_2emap_24f1016251237x587084191_entry(V self, V *a);
extern Clo g_list_2emap_24f1016251237x587084191_clo;
V g_list_2emap_24f1016251237x587084191_24dps(V, V, V, V);
V g_list_2emap_24f1016251237x587084191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1016251237x587084191_24dps_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f1534051505x274343589_24dps(V, V, V, V, V);
V g_list_2emap_24f1534051505x274343589_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1534051505x274343589_24dps_clo;
V g_list_2emap_24f1539731936x1117725130_24dps(V, V, V, V);
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_24dps_clo;
V g_list_2emap_24f505181408x1813697659(V, V);
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_clo;
V g_list_2emap_24f505181408x1813697659_24dps(V, V, V);
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_24dps_clo;
V g_list_2emap_24f669780424x1745768631(V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_clo;
V g_list_2emap_24f669780424x1745768631_24dps(V, V, V, V, V, V);
V g_list_2emap_24f669780424x1745768631_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f669780424x1745768631_24dps_clo;
V g_list_2emap_24f889159142x1775976195_24dps(V, V, V, V, V);
V g_list_2emap_24f889159142x1775976195_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f889159142x1775976195_24dps_clo;
V g_list_2emap_24f904804876x285797696(V, V, V);
V g_list_2emap_24f904804876x285797696_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_clo;
V g_list_2emap_24f904804876x285797696_24dps(V, V, V, V);
V g_list_2emap_24f904804876x285797696_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_24dps_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1093229560x1486136516(V);
V g_list_2emap_24s1093229560x1486136516_entry(V self, V *a);
extern Clo g_list_2emap_24s1093229560x1486136516_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1157931537x649184066_24dps(V, V, V);
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_24dps_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s1382928954x1260344933(V, V, V);
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_clo;
V g_list_2emap_24s1382928954x1260344933_24dps(V, V, V, V);
V g_list_2emap_24s1382928954x1260344933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_24dps_clo;
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1386329375x1773300759_24dps(V, V);
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_24dps_clo;
V g_list_2emap_24s1415906091x1371825187_24dps(V, V);
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_24dps_clo;
V g_list_2emap_24s1460603830x671758883(V, V);
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_clo;
V g_list_2emap_24s1460603830x671758883_24dps(V, V, V);
V g_list_2emap_24s1460603830x671758883_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1460603830x671758883_24dps_clo;
V g_list_2emap_24s1478286876x830244177_24dps(V, V);
V g_list_2emap_24s1478286876x830244177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_24dps_clo;
V g_list_2emap_24s1517387949x485543551_24dps(V, V);
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1517387949x485543551_24dps_clo;
V g_list_2emap_24s1518131677x2038133191(V, V, V);
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_clo;
V g_list_2emap_24s1518131677x2038133191_24dps(V, V, V, V);
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_24dps_clo;
V g_list_2emap_24s164225955x66209884_24dps(V, V, V, V);
V g_list_2emap_24s164225955x66209884_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_24dps_clo;
V g_list_2emap_24s1688354384x1781591142(V, V, V);
V g_list_2emap_24s1688354384x1781591142_entry(V self, V *a);
extern Clo g_list_2emap_24s1688354384x1781591142_clo;
V g_list_2emap_24s1688354384x1781591142_24dps(V, V, V, V);
V g_list_2emap_24s1688354384x1781591142_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1688354384x1781591142_24dps_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s1698496827x1884878103_24dps(V, V);
V g_list_2emap_24s1698496827x1884878103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_24dps_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s1960706388x853997965_24dps(V, V);
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_24dps_clo;
V g_list_2emap_24s1985010810x1780722131_24dps(V, V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24s2029999044x514618413_24dps(V, V);
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_24dps_clo;
V g_list_2emap_24s2081681776x559624592_24dps(V, V);
V g_list_2emap_24s2081681776x559624592_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_24dps_clo;
V g_list_2emap_24s2104774589x596860835_24dps(V, V);
V g_list_2emap_24s2104774589x596860835_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2104774589x596860835_24dps_clo;
V g_list_2emap_24s241620538x329208622(V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_clo;
V g_list_2emap_24s241620538x329208622_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_24dps_clo;
V g_list_2emap_24s265594371x763318798(V);
V g_list_2emap_24s265594371x763318798_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s272223926x273382154(V);
V g_list_2emap_24s272223926x273382154_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_clo;
V g_list_2emap_24s272223926x273382154_24dps(V, V);
V g_list_2emap_24s272223926x273382154_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s272223926x273382154_24dps_clo;
V g_list_2emap_24s273193875x235978955_24dps(V, V, V, V, V);
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s273193875x235978955_24dps_clo;
V g_list_2emap_24s348263401x2104816219_24dps(V, V);
V g_list_2emap_24s348263401x2104816219_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_24dps_clo;
V g_list_2emap_24s3575633x347355318(V);
V g_list_2emap_24s3575633x347355318_entry(V self, V *a);
extern Clo g_list_2emap_24s3575633x347355318_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s582709368x2113456071_24dps(V, V);
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_24dps_clo;
V g_list_2emap_24s631322900x900609068(V);
V g_list_2emap_24s631322900x900609068_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_clo;
V g_list_2emap_24s631322900x900609068_24dps(V, V);
V g_list_2emap_24s631322900x900609068_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_24dps_clo;
V g_list_2emap_24s674081137x339217813(V);
V g_list_2emap_24s674081137x339217813_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_clo;
V g_list_2emap_24s674081137x339217813_24dps(V, V);
V g_list_2emap_24s674081137x339217813_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_24dps_clo;
V g_list_2emap_24s809490196x1189312632_24dps(V, V);
V g_list_2emap_24s809490196x1189312632_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s809490196x1189312632_24dps_clo;
V g_list_2emap_24s89567162x1162500052(V, V, V, V, V, V, V);
V g_list_2emap_24s89567162x1162500052_entry(V self, V *a);
extern Clo g_list_2emap_24s89567162x1162500052_clo;
V g_list_2emap_24s89567162x1162500052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s89567162x1162500052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s89567162x1162500052_24dps_clo;
V g_list_2emap_24s900318151x1569363206(V, V, V);
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_clo;
V g_list_2emap_24s900318151x1569363206_24dps(V, V, V, V);
V g_list_2emap_24s900318151x1569363206_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_24dps_clo;
V g_list_2emerge_24dps(V, V, V, V);
V g_list_2emerge_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24dps_clo;
V g_list_2emerge_24s132798885x1165759438(V, V);
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_clo;
V g_list_2emerge_24s132798885x1165759438_24tok2(V, V, V);
V g_list_2emerge_24s132798885x1165759438_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_24tok2_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emerge_24s1347843181x1368204458_24dps(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo;
V g_list_2emerge_24s275559350x890699445_24dps(V, V, V);
V g_list_2emerge_24s275559350x890699445_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s275559350x890699445_24dps_clo;
V g_list_2emerge_24tok2(V, V, V, V);
V g_list_2emerge_24tok2_entry(V self, V *a);
extern Clo g_list_2emerge_24tok2_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1029292936x211450510_24dps(V, V, V);
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo;
V g_list_2ezipWith_24s1893966264x617194987_24dps(V, V, V);
V g_list_2ezipWith_24s1893966264x617194987_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_24dps_clo;
V g_list_2ezipWith_24s29557946x653938035_24dps(V, V, V);
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2ecli_2einteractive_2epartLabel(V);
V g_std_2ecli_2einteractive_2epartLabel_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epartLabel_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_list_2emap_24s1415906091x1371825187_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_24dps_entry, 2, 0};

V g_list_2emap_24s1415906091x1371825187_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s2115931744x466898799_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2115931744x466898799_entry, 2, 0};

V g_list_2ekeepIf_24s2115931744x466898799(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s2115931744x466898799_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s2115931744x466898799(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s690313412x1307839513_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s690313412x1307839513_entry, 2, 0};

V g_list_2efoldl_24s690313412x1307839513(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2efreshBindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s690313412x1307839513(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1044393341x1523302351_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_24dps_entry, 2, 0};

V g_list_2emap_24s1044393341x1523302351_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = ({ V a_0 = v_a_245; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_245); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1029292936x211450510_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_entry, 2, 0};

V g_list_2ezipWith_24s1029292936x211450510(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s1029292936x211450510_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510(a[0], a[1]);
}
Clo g_list_2efoldl_24s510070423x219220408_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s510070423x219220408_entry, 3, 0};

V g_list_2efoldl_24s510070423x219220408(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      v_t_247 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2413;
    if (heff_intLe_c_lent(v_t_247, v_lit_240, 1)) {
      V v_a_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_243, 0);
        v_a_2410 = heff_dup(v_a_248);
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      switch (heff_tag_of(v_z_241)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_a_2410});
        break;
      }
      case TAG_Just: {
        V v_a_2411 = heff_field(v_z_241, 0);
        V v_ru_24z_241_24Just = heff_take_reuse_n(v_z_241, 1ULL, 1);
        V v_t_2412;
        if (heff_intLt_c_lent(v_a_2411, v_a_2410, 0)) {
          heff_drop(v_a_2411);
          v_t_2412 = v_a_2410;
        } else {
          heff_drop(v_a_2410);
          v_t_2412 = v_a_2411;
        }
        v_t_2413 = heff_tag_at_n(v_ru_24z_241_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_z_241);
      }
    } else {
      v_t_2413 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2413;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s510070423x219220408_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s510070423x219220408(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emerge_24s1347843181x1368204458_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_entry, 2, 0};

V g_list_2emerge_24s1347843181x1368204458(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_x3_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_243 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 7);
      heff_drop(v_xs_243);
      return v_x2_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_y_244, 2)))) {
        V v_cell_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_247 = (g_list_2emerge_24s1347843181x1368204458_24dps(v_xs_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys_245}), heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      } else {
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_249 = (g_list_2emerge_24s1347843181x1368204458_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs_243}), v_ys_245, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458(a[0], a[1]);
}
Clo g_list_2emap_24s272223926x273382154_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s272223926x273382154_entry, 1, 0};

V g_list_2emap_24s272223926x273382154(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_b_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 2);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2earmStmts(v_b_246));
        v_t_248 = heff_tag_at_n(v_ru_24x_241_24At, TAG_MkPair, 2, (V[]){v_p_245, v_t_247});
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s272223926x273382154_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s272223926x273382154_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s272223926x273382154(a[0]);
}
Clo g_list_2emap_24s1157931537x649184066_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1157931537x649184066_entry, 2, 0};

V g_list_2emap_24s1157931537x649184066(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eparamOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1157931537x649184066_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1157931537x649184066(a[0], a[1]);
}
Clo g_list_2emap_24s1844509821x2028168277_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_24dps_entry, 2, 0};

V g_list_2emap_24s1844509821x2028168277_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_242));
    V v_t_2416;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_246;
        v_t_2416 = v_a_247;
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_a_248 = v_field_246;
          V v_t_2411;
          switch (heff_tag_of(v_a_248)) {
          case TAG_At: {
            V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
            v_t_2411 = v_a_2410;
            break;
          }
          default: heff_nomatch(v_a_248);
          }
          v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_248}), v_t_2411});
        } else {
          V v_a_2412 = v_field_246;
          V v_t_2415;
          switch (heff_tag_of(v_a_2412)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_a_2412, 1));
            v_t_2415 = v_a_2414;
            break;
          }
          default: heff_nomatch(v_a_2412);
          }
          v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2412}), v_t_2415});
        }
      }
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2417;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s348263401x2104816219_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s348263401x2104816219_24dps_entry, 2, 0};

V g_list_2emap_24s348263401x2104816219_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s348263401x2104816219_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s348263401x2104816219_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1059370217x1267747283_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_entry, 1, 0};

V g_list_2emap_24s1059370217x1267747283(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1059370217x1267747283_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283(a[0]);
}
Clo g_list_2emap_24s2081681776x559624592_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081681776x559624592_24dps_entry, 2, 0};

V g_list_2emap_24s2081681776x559624592_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Left: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_d_245 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      V v_eqns_246 = heff_take_field(v_d_245, 3);
      V v_name_247 = heff_get_n(v_d_245, 0, 5);
      switch (heff_tag_of(v_eqns_246)) {
      case TAG_Nil: {
        heff_drop(v_name_247);
        v_t_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_it1_248 = heff_field(v_eqns_246, 0);
        V v_rest_249 = heff_field(v_eqns_246, 1);
        heff_take_n(v_eqns_246, 3ULL, 2);
        switch (heff_tag_of(v_it1_248)) {
        case TAG_At: {
          V v_it11_2410 = heff_field(v_it1_248, 0);
          heff_take_n(v_it1_248, 1ULL, 2);
          switch (heff_tag_of(v_it11_2410)) {
          case TAG_MkEquation: {
            V v_pats_2414 = heff_field(v_it11_2410, 2);
            heff_take_n(v_it11_2410, 4ULL, 4);
            V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_pats_2414; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_pats_2414); r_; });
            v_t_2417 = ({ V a_0 = v_name_247; V a_1 = v_t_2416; V a_2 = v_rest_249; V r_ = (g_heff_2esyntax_2esurface_2eunevenAt(a_0, a_1, a_2)); heff_drop(v_rest_249); r_; });
            break;
          }
          default: heff_nomatch(v_it11_2410);
          }
          break;
        }
        default: heff_nomatch(v_it1_248);
        }
        break;
      }
      default: heff_nomatch(v_eqns_246);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081681776x559624592_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081681776x559624592_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s2053104128x1598844325_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s2053104128x1598844325_entry, 4, 0};

V g_list_2ekeepIf_24s2053104128x1598844325(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_rfield(v_x_244, 1)));
    V v_a_247 = heff_bool(heff_intEq_c_lent(v_t_246, v_lit_242, 0));
    heff_drop(v_t_246);
    if (!(heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_249 = (g_list_2ekeepIf_24s2053104128x1598844325_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_a_247);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s2053104128x1598844325_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s2053104128x1598844325(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s423901581x541836270_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s423901581x541836270_entry, 2, 0};

V g_list_2ekeepIf_24s423901581x541836270(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_2443 = heff_bool(!heff_strEq_c_lent(v_lit_240, v_a_244, 0));
      heff_drop(v_a_244);
      break;
    }
    case TAG_EGlobal: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ELet: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ERecord: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EProj: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ETag: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EMatch: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrim: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ECall: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EInt: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBool: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_ESet: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EValues: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFix: {
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
      heff_drop(v_t_2443);
      V v_cell_2444 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2445 = (g_list_2ekeepIf_24s423901581x541836270_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2444)));
      heff_drop(v_u_2445);
      return v_cell_2444;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_2443);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s423901581x541836270_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s423901581x541836270(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1299324685x840794767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1299324685x840794767_entry, 2, 0};

V g_list_2efoldl_24s1299324685x840794767(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1299324685x840794767_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1299324685x840794767(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1923327646x248110754_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1923327646x248110754_entry, 2, 0};

V g_list_2efoldl_24s1923327646x248110754(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erepr_2ementionedBy(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1923327646x248110754_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1923327646x248110754(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1232551929x416126852_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1232551929x416126852_entry, 2, 0};

V g_list_2efoldl_24s1232551929x416126852(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2efacts_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1232551929x416126852_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1232551929x416126852(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1672254115x651817494_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1672254115x651817494_entry, 2, 0};

V g_list_2eany_24s1672254115x651817494(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_lit_240, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2446;
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_2446 = heff_bool(heff_strEq_c_lent(v_x_242, v_a_247, 0));
      heff_drop(v_a_247);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2446);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1672254115x651817494_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1672254115x651817494(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eall_24s1793250635x935291087_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1793250635x935291087_entry, 1, 0};

V g_list_2eall_24s1793250635x935291087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_GivenU: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_LentVar: {
      V v_x12_247 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_x12_247)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x12_247);
      }
    }
    case TAG_LentValue: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1793250635x935291087(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_24dps_entry, 3, 0};

V g_list_2ezipWith_24s870182194x1066240094_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      case TAG_RepF64: {
        v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      case TAG_RepInt: {
        v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_249;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s490001784x345683100_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s490001784x345683100_entry, 2, 0};

V g_list_2efoldl_24s490001784x345683100(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eowned_2edefsSt_24s1110569521x699855806(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s490001784x345683100_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s490001784x345683100(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s708019417x1279437633_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s708019417x1279437633_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s708019417x1279437633_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_lit_240, v_t_247, 2)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_248;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s708019417x1279437633_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s708019417x1279437633_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1688354384x1781591142_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688354384x1781591142_entry, 3, 0};

V g_list_2emap_24s1688354384x1781591142(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eowned_2eownSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1688354384x1781591142_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1688354384x1781591142_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688354384x1781591142(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1688354384x1781591142_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1688354384x1781591142_24dps_entry, 4, 0};

V g_list_2emap_24s1688354384x1781591142_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eowned_2eownSt(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1688354384x1781591142_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1688354384x1781591142_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s585316429x898527369_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s585316429x898527369_entry, 2, 0};

V g_list_2efoldl_24s585316429x898527369(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s345718350x1678852400(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s585316429x898527369_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s585316429x898527369(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s273193875x235978955_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s273193875x235978955_24dps_entry, 5, 0};

V g_list_2emap_24s273193875x235978955_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_245, 0));
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_x_245, 1);
      heff_take_n(v_x_245, 2ULL, 2);
      v_a_2412 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_numbered_2413 = heff_take_field(v_a_2412, 1);
    V v_kinds_2414 = heff_get_n(v_a_2412, 2, 7);
    V v_t_2416;
    if ((heff_dup(v_numbered_2413) == NTAG(TAG_True))) {
      heff_drop(v_numbered_2413);
      V v_t_2415 = heff_tag_n(TAG_RepFix, 1, (V[]){NTAG(TAG_I64)});
      v_t_2416 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_kinds_2414});
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_numbered_2413);
      v_t_2416 = v_kinds_2414;
    }
    V v_t_2417 = ({ V a_0 = heff_dup(v_lit_241); V a_1 = heff_dup(v_lit_242); V a_2 = v_t_2416; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_lit_240)), v_t_2417});
    V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2419;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s273193875x235978955_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s273193875x235978955_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1460603830x671758883_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1460603830x671758883_entry, 2, 0};

V g_list_2emap_24s1460603830x671758883(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1460603830x671758883_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1460603830x671758883_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1460603830x671758883(a[0], a[1]);
}
Clo g_list_2efoldl_24s644818311x440862174_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s644818311x440862174_entry, 3, 0};

V g_list_2efoldl_24s644818311x440862174(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_z_241, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2410;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_z_241, 1));
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2413;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_z_241, 0);
      heff_take_n(v_z_241, 1ULL, 2);
      v_t_2413 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2414 = (g_std_2emap_2einsert_24s93785294x875597928(v_t_2410, heff_get_n(v_x_243, 0, 3), v_t_2413));
    V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){heff_intAdd(v_t_247, heff_dup(v_lit_240)), v_t_2414});
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s644818311x440862174_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s644818311x440862174(a[0], a[1], a[2]);
}

HeffT2 g_list_2efind_24s775449825x1158002128_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_lit_240, 3);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 4);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2eany_24s781693278x668067139_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s781693278x668067139_entry, 2, 0};

V g_list_2eany_24s781693278x668067139(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_lit_240, v_x_242, 0)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s781693278x668067139_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s781693278x668067139(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s868530262x539343671_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s868530262x539343671_entry, 2, 0};

V g_list_2efoldl_24s868530262x539343671(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_std_2emap_2einsert_24s170109517x1206653089(v_z_240, heff_dup(v_l_246), heff_dup(v_i_244)));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s868530262x539343671(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s89567162x1162500052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s89567162x1162500052_entry, 7, 0};

V g_list_2emap_24s89567162x1162500052(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_a_249; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_249); r_; });
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2410); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
      v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, v_t_2414));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s89567162x1162500052_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s89567162x1162500052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s89567162x1162500052(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s241620538x329208622_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s241620538x329208622_entry, 7, 0};

V g_list_2emap_24s241620538x329208622(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_a_249; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_249); r_; });
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2410); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
      v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, v_t_2414));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s241620538x329208622_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s241620538x329208622_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s241620538x329208622(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1367173129x1257089258_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_24dps_entry, 2, 0};

V g_list_2emap_24s1367173129x1257089258_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1457049037x722637222_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1457049037x722637222_entry, 1, 0};

V g_list_2ekeepIf_24s1457049037x722637222(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2ekeepIf_24s1457049037x722637222_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1457049037x722637222_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1457049037x722637222(a[0]);
}
Clo g_list_2efoldl_24s586610394x1672960104_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s586610394x1672960104_entry, 2, 0};

V g_list_2efoldl_24s586610394x1672960104(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_key_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_body_245 = heff_dup(heff_rfield(v_x_242, 2));
    HeffT2 v_t_246 = (g_heff_2ecompile_2efuse_2eproducerOf_24cpr(v_key_244, v_body_245));
    V v_t_2410;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_248;
        v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_key_244, v_a_249));
      } else {
        heff_drop(v_key_244);
        heff_drop(v_field_248);
        v_t_2410 = v_z_240;
      }
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s586610394x1672960104_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s586610394x1672960104(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1478286876x830244177_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1478286876x830244177_24dps_entry, 2, 0};

V g_list_2emap_24s1478286876x830244177_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1478286876x830244177_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1478286876x830244177_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1893966264x617194987_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1893966264x617194987_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1893966264x617194987_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      heff_take_n(v_x3_241, 3ULL, 2);
      V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2escalars_2emergeTy(a_0, a_1)); heff_drop(v_y_245); r_; });
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1893966264x617194987_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1893966264x617194987_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eall_24s262401054x194288545_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s262401054x194288545_entry, 2, 0};

V g_list_2eall_24s262401054x194288545(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_x_242, v_lit_240, 0)) {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_lit_240);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s262401054x194288545_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s262401054x194288545(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s512765522x2052101617_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s512765522x2052101617_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s512765522x2052101617_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_intEq_c_lent(v_x_243, v_lit_240, 0)) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s512765522x2052101617_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s512765522x2052101617_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1985010810x1780722131_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1985010810x1780722131_24dps_entry, 5, 0};

V g_list_2emap_24s1985010810x1780722131_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2elower_2egroupOut(v_lit_240, heff_dup(v_lit_241), v_lit_242, v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1985010810x1780722131_24dps(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s122741325x871243494_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s122741325x871243494_24dps_entry, 5, 0};

V g_list_2ekeepIf_24s122741325x871243494_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (!heff_strEq_c(heff_strSlice_lent(v_x_245, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_248 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s122741325x871243494_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s122741325x871243494_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s185327080x101197346_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s185327080x101197346_entry, 4, 0};

V g_list_2ekeepIf_24s185327080x101197346(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_244, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s185327080x101197346_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s185327080x101197346_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s185327080x101197346(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2emap_24s164225955x66209884_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s164225955x66209884_24dps_entry, 4, 0};

V g_list_2emap_24s164225955x66209884_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2eglue_2eglueOf(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s164225955x66209884_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s164225955x66209884_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1382928954x1260344933_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1382928954x1260344933_entry, 3, 0};

V g_list_2emap_24s1382928954x1260344933(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_intShow(v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1382928954x1260344933_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1382928954x1260344933(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1518131677x2038133191_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1518131677x2038133191_entry, 3, 0};

V g_list_2emap_24s1518131677x2038133191(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_lit_241; V a_2 = v_x_243; V r_ = (g_heff_2ecompile_2eemitc_2efieldLine(a_0, a_1, a_2)); heff_drop(v_x_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1518131677x2038133191_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1518131677x2038133191(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1338755034x1627180165_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1338755034x1627180165_entry, 8, 0};

V g_list_2eany_24s1338755034x1627180165(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_245);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(v_x_248), heff_dup(v_lit_242)));
    V v_t_2413;
    switch (heff_tag_of(v_lit_244)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_lit_244, 0);
      v_t_2413 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_lit_244);
    }
    V v_t_2414 = heff_strAppend(heff_dup(v_lit_243), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
    if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_t_2410, v_t_2414, v_lit_246, 3))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_245);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2eany_24s1338755034x1627180165_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2eany_24s1338755034x1627180165(a[0], a[1], a[2], a[3], a4, a[5], a6, a7); heff_drop(a4); heff_drop(a6); heff_drop(a7); return r;
}
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str0, 1, "V");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str1, 6, "double");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str2, 7, "int64_t");
Clo g_list_2emap_24s1386329375x1773300759_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386329375x1773300759_entry, 1, 0};

V g_list_2emap_24s1386329375x1773300759(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_244 = ({ V a_0 = v_w_243; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_243); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str1);
      break;
    }
    case TAG_RepInt: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str2);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1386329375x1773300759_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386329375x1773300759(a[0]);
}
Clo g_list_2emap_24s1960706388x853997965_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1960706388x853997965_entry, 1, 0};

V g_list_2emap_24s1960706388x853997965(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1960706388x853997965_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1960706388x853997965(a[0]);
}
Clo g_list_2ekeepIf_24s636499273x1023552697_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s636499273x1023552697_entry, 2, 0};

V g_list_2ekeepIf_24s636499273x1023552697(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s636499273x1023552697_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop_rec(v_x_242, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s636499273x1023552697_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s636499273x1023552697(a[0], a[1]);
}
Clo g_list_2emap_24s265594371x763318798_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_entry, 1, 0};

V g_list_2emap_24s265594371x763318798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_243 = heff_take_field(v_x_241, 0);
    V v_key_244 = heff_get_n(v_x_241, 1, 4);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){v_name_243, heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_244})});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s265594371x763318798_24dps(v_xs_242, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798(a[0]);
}
Clo g_list_2efoldl_24s995130411x810552597_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s995130411x810552597_entry, 2, 0};

V g_list_2efoldl_24s995130411x810552597(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_x_242, 6)), heff_dup(heff_rfield(v_x_242, 4))));
    V v_t_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_x_242, 5), v_t_244));
    V v_t_246 = ({ V a_0 = heff_dup(v_z_240); V a_1 = v_x_242; V a_2 = v_t_245; V b_3 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2edriver_2eelabWith(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ebuild_2edriver_2eappendD(v_z_240, v_t_247));
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s995130411x810552597_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s995130411x810552597(a[0], a[1]);
}
Clo g_list_2efoldl_24s1315672171x449285703_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1315672171x449285703_entry, 2, 0};

V g_list_2efoldl_24s1315672171x449285703(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_242, 0);
      v_t_249 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_t_246, v_t_249));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1315672171x449285703_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1315672171x449285703(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s285809686x1684902122_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s285809686x1684902122_entry, 2, 0};

V g_list_2eany_24s285809686x1684902122(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s285809686x1684902122_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s285809686x1684902122(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1823913665x1128491553_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1823913665x1128491553_entry, 2, 0};

V g_list_2ekeepIf_24s1823913665x1128491553(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(v_x_242), heff_dup(heff_rfield(v_lit_240, 1)))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1823913665x1128491553_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1823913665x1128491553_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1823913665x1128491553(a[0], a[1]);
}
Clo g_list_2emap_24s1517387949x485543551_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1517387949x485543551_24dps_entry, 2, 0};

V g_list_2emap_24s1517387949x485543551_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2egoldenOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1517387949x485543551_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1517387949x485543551_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s900318151x1569363206_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s900318151x1569363206_entry, 3, 0};

V g_list_2emap_24s900318151x1569363206(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_245 = heff_take_field(v_x_243, 0);
    V v_tags_246 = heff_get_n(v_x_243, 1, 3);
    V v_t_247;
    if ((heff_dup(v_tags_246) == NTAG(TAG_True))) {
      heff_drop(v_tags_246);
      v_t_247 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_tags_246);
      v_t_247 = heff_dup(v_lit_241);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_name_245, v_t_247), heff_hole()});
    V v_u_249 = (g_list_2emap_24s900318151x1569363206_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s900318151x1569363206(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s173442543x1801751270_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_entry, 1, 0};

V g_list_2emap_24s173442543x1801751270(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s173442543x1801751270_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270(a[0]);
}
Clo g_list_2efoldl_24s189033563x26633104_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s189033563x26633104_entry, 2, 0};

V g_list_2efoldl_24s189033563x26633104(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s189033563x26633104(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s257286374x378693326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s257286374x378693326_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s257286374x378693326_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
    if ((heff_intLe_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_t_245)) && heff_intLe_c(heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2), heff_dup(heff_rfield(v_lit_240, 1))))) {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s257286374x378693326_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s257286374x378693326_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s631322900x900609068_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s631322900x900609068_entry, 1, 0};

V g_list_2emap_24s631322900x900609068(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2edocpages_2eindexLine(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s631322900x900609068_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s631322900x900609068_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s631322900x900609068(a[0]);
}
Clo g_list_2emerge_24s275559350x890699445_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s275559350x890699445_24dps_entry, 3, 0};

V g_list_2emerge_24s275559350x890699445_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 14);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_y_245, 0)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_247;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_249;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s275559350x890699445_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s275559350x890699445_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s29557946x653938035_24dps_entry, 3, 0};

V g_list_2ezipWith_24s29557946x653938035_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 1, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s29557946x653938035_24dps(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_24s492793466x2081132734_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s492793466x2081132734_entry, 1, 0};

V g_list_2esortBy_24s492793466x2081132734(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_xs_240)) {
      case TAG_Cons: {
        V v_x_243 = heff_field(v_xs_240, 0);
        V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 1ULL, 2);
        return heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_xs_240);
      }
    }
    case TAG_Cons: {
      V v_ru_24xs2_242_24Cons = heff_take_reuse_n(v_xs2_242, 0ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_248 = (g_list_2etake(heff_intDiv(v_t_247, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_249 = (g_list_2esortBy_24s492793466x2081132734(v_t_248));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2411 = ({ V a_0 = heff_intDiv(v_t_2410, MK_INT(2LL)); V a_1 = v_xs_240; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop_tag(v_xs_240, 2); r_; });
      V v_t_2412 = (g_list_2esortBy_24s492793466x2081132734(v_t_2411));
      return (g_list_2emerge_24s132798885x1165759438_24tok2(v_ru_24xs2_242_24Cons, v_t_249, v_t_2412));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s492793466x2081132734(a[0]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str0, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str2, 9, "{ name = ");
Clo g_list_2emap_24s404123879x745642248_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_24dps_entry, 2, 0};

V g_list_2emap_24s404123879x745642248_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_name_244 = heff_take_field(v_x_242, 0);
    V v_dir_245 = heff_get_n(v_x_242, 1, 2);
    V v_t_246 = ({ V a_0 = v_name_244; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_name_244); r_; });
    V v_t_247 = ({ V a_0 = v_dir_245; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_dir_245); r_; });
    V v_t_248 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_24dps_str0), heff_strAppend(v_t_247, ((V)&g_list_2emap_24s404123879x745642248_24dps_str1)));
    V v_t_249 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_24dps_str2), heff_strAppend(v_t_246, v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_str1, 1, ".");
Clo g_list_2ekeepIf_24s85961498x283047001_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s85961498x283047001_entry, 1, 0};

V g_list_2ekeepIf_24s85961498x283047001(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_241, ((V)&g_list_2ekeepIf_24s85961498x283047001_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_241, ((V)&g_list_2ekeepIf_24s85961498x283047001_str1), 2))) {
      V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s85961498x283047001_24dps(v_xs_242, heff_dup(v_cell_243)));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s85961498x283047001_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s85961498x283047001(a[0]);
}
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_24dps_str0, 0, "");
HEFF_LIT(g_list_2ekeepIf_24s85961498x283047001_24dps_str1, 1, ".");
Clo g_list_2ekeepIf_24s85961498x283047001_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s85961498x283047001_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s85961498x283047001_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if ((heff_strEq_c_lent(v_x_242, ((V)&g_list_2ekeepIf_24s85961498x283047001_24dps_str0), 2) ? 0 : !heff_strEq_c_lent(v_x_242, ((V)&g_list_2ekeepIf_24s85961498x283047001_24dps_str1), 2))) {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
      heff_drop(v_u_245);
      V t_0 = v_xs_243;
      V t_1 = v_cell_244;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s85961498x283047001_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s85961498x283047001_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2062876492x2082655823_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2062876492x2082655823_entry, 2, 0};

V g_list_2efoldl_24s2062876492x2082655823(V v_z_240, V v_x3_241) {
top: ;
  V v_front_242 = heff_take_field(v_z_240, 0);
  V v_back_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s2062876492x2082655823_24scalars(v_front_242, v_back_243, v_x3_241));
}
V g_list_2efoldl_24s2062876492x2082655823_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2062876492x2082655823(a[0], a[1]);
}
Clo g_list_2emap_24s1698496827x1884878103_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1698496827x1884878103_entry, 1, 0};

V g_list_2emap_24s1698496827x1884878103(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 14), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1698496827x1884878103_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1698496827x1884878103(a[0]);
}

HeffT2 g_list_2efind_24s595925281x993936542_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_lit_240, 6)), 0, 14);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), v_t_244)) {
      heff_drop_rec(v_lit_240, 7);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 8);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s809490196x1189312632_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s809490196x1189312632_24dps_entry, 2, 0};

V g_list_2emap_24s809490196x1189312632_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2ecommands_2ejsonGolden(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s809490196x1189312632_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s809490196x1189312632_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s742867582x682687968_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s742867582x682687968_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s742867582x682687968_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s742867582x682687968_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s742867582x682687968_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efind_24s1136367117x833793205_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1136367117x833793205_entry, 2, 0};

V g_list_2efind_24s1136367117x833793205(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_a_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_lit_240, 0)) - heff_unbox_word(heff_strLength_lent(v_a_246, 0)));
    V v_t_248 = heff_strSlice(heff_dup(v_lit_240), heff_box_word(v_t_247), heff_strLength_lent(v_lit_240, 0));
    if (heff_strEq_c(v_t_248, v_a_246)) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s1136367117x833793205_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2efind_24s1136367117x833793205(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2104774589x596860835_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2104774589x596860835_24dps_entry, 2, 0};

V g_list_2emap_24s2104774589x596860835_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2104774589x596860835_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2104774589x596860835_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2eany_24s105899861x584770213_str0, 4, "page");
Clo g_list_2eany_24s105899861x584770213_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s105899861x584770213_entry, 1, 0};

V g_list_2eany_24s105899861x584770213(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 1)), 0, 3);
    if (heff_strEq_c(v_t_243, ((V)&g_list_2eany_24s105899861x584770213_str0))) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s105899861x584770213_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s105899861x584770213(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s674081137x339217813_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s674081137x339217813_entry, 1, 0};

V g_list_2emap_24s674081137x339217813(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if ((heff_runeLe_c(MK_INT(65LL), heff_dup(v_x_241)) && heff_runeLe_c(heff_dup(v_x_241), MK_INT(90LL)))) {
      V v_t_243 = heff_intAdd(heff_runeToInt(v_x_241), MK_INT(32LL));
      v_t_244 = heff_runeFromInt(v_t_243);
    } else {
      v_t_244 = v_x_241;
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s674081137x339217813_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s674081137x339217813_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s674081137x339217813(a[0]);
}
Clo g_list_2efoldl_24s661788424x2062432904_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s661788424x2062432904_entry, 2, 0};

V g_list_2efoldl_24s661788424x2062432904(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = heff_get_n(v_t_246, 1, 2);
    V v_t_248;
    if (heff_intLe_c_lent(v_z_240, v_a_247, 0)) {
      heff_drop(v_z_240);
      v_t_248 = v_a_247;
    } else {
      heff_drop(v_a_247);
      v_t_248 = v_z_240;
    }
    V t_0 = v_t_248;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s661788424x2062432904_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s661788424x2062432904(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ekeepIf_24s1441124185x871809048_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1441124185x871809048_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1441124185x871809048_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 8);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (!heff_strEq_c(heff_dup(heff_rfield(v_x_243, 2)), heff_dup(heff_rfield(v_lit_240, 2)))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1441124185x871809048_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1441124185x871809048_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s582709368x2113456071_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s582709368x2113456071_24dps_entry, 2, 0};

V g_list_2emap_24s582709368x2113456071_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s582709368x2113456071_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s738919255x1142813117_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s738919255x1142813117_entry, 4, 0};

V g_list_2ekeepIf_24s738919255x1142813117(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_240), NTAG(TAG_Nil)});
    HeffT2 v_t_247 = (g_json_2eat_24cpr(v_t_246, heff_dup(v_x_244)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2417;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_a_2410 = v_field_249;
        switch (heff_tag_of(v_a_2410)) {
        case TAG_JNull: {
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_a_2410, 0ULL, 1);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_a_2410, 0ULL, 1);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_a_2410, 0ULL, 1);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          V v_a_2414 = heff_field(v_a_2410, 0);
          heff_take_n(v_a_2410, 1ULL, 1);
          v_t_2417 = heff_bool((heff_strEq_c_lent(v_a_2414, v_lit_241, 0) || heff_strEq_c_lent(v_a_2414, v_lit_242, 0)));
          heff_drop(v_a_2414);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_a_2410, 0ULL, 1);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_a_2410, 0ULL, 1);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_a_2410);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2417 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_t_2417);
        V v_cell_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_2419 = (g_list_2ekeepIf_24s738919255x1142813117_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2418)));
        heff_drop(v_u_2419);
        return v_cell_2418;
      } else {
        heff_drop(v_x_244);
        heff_drop(v_t_2417);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_xs_245;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_x2_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ekeepIf_24s738919255x1142813117_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2ekeepIf_24s738919255x1142813117(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_24dps_entry, 2, 0};

V g_list_2emap_24s2029999044x514618413_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_meta_244 = heff_take_field(v_x_242, 0);
    V v_arity_245 = heff_get_n(v_x_242, 1, 3);
    V v_m_246 = v_meta_244;
    V v_t_247;
    switch (heff_tag_of(v_arity_245)) {
    case TAG_One: {
      v_t_247 = v_m_246;
      break;
    }
    case TAG_Optional: {
      v_t_247 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str0), heff_strAppend(v_m_246, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str1)));
      break;
    }
    case TAG_Many: {
      v_t_247 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str2), heff_strAppend(v_m_246, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str3)));
      break;
    }
    case TAG_Some: {
      v_t_247 = heff_strAppend(v_m_246, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str4));
      break;
    }
    case TAG_Rest: {
      v_t_247 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str5), heff_strAppend(v_m_246, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str6)));
      break;
    }
    default: heff_nomatch(v_arity_245);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s624430845x1248965393_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s624430845x1248965393_entry, 1, 0};

V g_list_2eany_24s624430845x1248965393(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_One: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Optional: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Many: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Some: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Rest: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s624430845x1248965393_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s624430845x1248965393(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1396019640x159929943_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1396019640x159929943_entry, 3, 0};

V g_list_2efoldl_24s1396019640x159929943(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_a_245 = (g_std_2ecli_2einteractive_2epartLabel(heff_rfield(v_x_243, 0)));
    V v_a_246 = ({ V a_0 = heff_dup(v_lit_240); V b_1 = heff_strRunes(v_a_245); V r_ = (g_list_2efoldl_24f928374809x1955888331(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_247;
    if (heff_intLe_c_lent(v_z_241, v_a_246, 0)) {
      heff_drop(v_z_241);
      v_t_247 = v_a_246;
    } else {
      heff_drop(v_a_246);
      v_t_247 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_247;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1396019640x159929943_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1396019640x159929943(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24f1534051505x274343589_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1534051505x274343589_24dps_entry, 5, 0};

V g_list_2emap_24f1534051505x274343589_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_text_247 = heff_take_field(v_x_245, 1);
    V v_start_248 = heff_take_field(v_x_245, 2);
    V v_end_249 = heff_get_n(v_x_245, 3, 7);
    V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_247)}));
    V v_t_2411 = ({ V a_0 = v_t_2410; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_text_247, heff_dup(v_lit_242)));
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), v_t_2412, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249}), NTAG(TAG_Nothing)});
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2414));
      heff_drop(v_u_2415);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_2414;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_text_247);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_t_2411);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1534051505x274343589_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1534051505x274343589_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f1663632568x709545076_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1663632568x709545076_entry, 4, 0};

V g_list_2efoldl_24f1663632568x709545076(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_2431;
    switch (heff_tag_of(v_x_244)) {
    case TAG_PartVal: {
      V v_a_246 = heff_field(v_x_244, 0);
      switch (heff_tag_of(v_a_246)) {
      case TAG_SVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        v_t_2431 = heff_bool(heff_strEq_c_lent(v_lit_242, v_a_247, 0));
        break;
      }
      case TAG_SGlobal: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2431 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    case TAG_PartOp: {
      v_t_2431 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop(v_t_2431);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2431);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1663632568x709545076_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f1663632568x709545076(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24f889159142x1775976195_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f889159142x1775976195_24dps_entry, 5, 0};

V g_list_2emap_24f889159142x1775976195_24dps(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243, V v_d_244) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245;
    if (heff_intEq_c_lent(v_a_242, v_lit_240, 0)) {
      v_t_245 = heff_dup(v_lit_241);
    } else {
      v_t_245 = NTAG(TAG_RepV);
    }
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
    V t_3 = v_b_243;
    V t_4 = v_cell_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_list_2emap_24f889159142x1775976195_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f889159142x1775976195_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f1582053009x1594640150_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1582053009x1594640150_entry, 5, 0};

V g_list_2efoldl_24f1582053009x1594640150(V v_lit_240, V v_z_241, V v_lit_242, V v_n_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_n_243);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    if (heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_n_243);
      return v_z_241;
    } else {
      if (heff_strEq_c_lent(v_x_245, v_lit_242, 0)) {
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_lit_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_lit_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1582053009x1594640150_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_list_2efoldl_24f1582053009x1594640150(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
Clo g_list_2emap_24f1229912102x1467950109_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_entry, 2, 0};

V g_list_2emap_24f1229912102x1467950109(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      HEFF_LAST return g_list_2emap_24s2029035892x1571084362_24tok2(v_ru_24x2_241_24Cons, v_xs_243);
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_245 = (g_list_2emap_24f1229912102x1467950109_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109(a[0], a[1]);
}
Clo g_list_2emap_24f505181408x1813697659_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f505181408x1813697659_entry, 2, 0};

V g_list_2emap_24f505181408x1813697659(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      HEFF_LAST return g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24x2_241_24Cons, v_xs_243);
    } else {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
      V v_u_245 = (g_list_2emap_24f505181408x1813697659_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f505181408x1813697659(a[0], a[1]);
}
Clo g_list_2emap_24f1539731936x1117725130_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1539731936x1117725130_24dps_entry, 4, 0};

V g_list_2emap_24f1539731936x1117725130_24dps(V v_lit_240, V v_i_241, V v_n_242, V v_d_243) {
top: ;
  if (heff_intLe_c_lent(v_n_242, v_i_241, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_245 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_n_242;
    V t_3 = v_cell_244;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1539731936x1117725130_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f669780424x1745768631_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f669780424x1745768631_entry, 5, 0};

V g_list_2emap_24f669780424x1745768631(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_x_249;
    switch (heff_tag_of(v_x_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_245, 0);
      heff_take_n(v_x_245, 1ULL, 2);
      v_x_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    V v_a_2410 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(v_lit_241));
    V v_t_2411 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_242), heff_strLength_lent(v_a_2410, 0));
    V v_t_2415;
    if (heff_strEq_c(v_t_2411, v_a_2410)) {
      V v_t_2412 = heff_strLength(heff_dup(heff_rfield(v_lit_240, 0)));
      V v_t_2413 = heff_strSlice(heff_dup(v_x_249), heff_intAdd(v_t_2412, heff_dup(v_lit_243)), heff_strLength_lent(v_x_249, 0));
      V v_t_2414 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_2413, v_x_249, heff_dup(heff_rfield(v_lit_240, 0))});
      v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      heff_drop(v_x_249);
      v_t_2415 = NTAG(TAG_Nothing);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24f669780424x1745768631_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_xs_246, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f669780424x1745768631_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24f669780424x1745768631(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2emap_24f904804876x285797696_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f904804876x285797696_entry, 3, 0};

V g_list_2emap_24f904804876x285797696(V v_f_240, V v_box_24a_241, V v_b_242) {
  int64_t v_a_241 = heff_unbox_word(v_box_24a_241);
top: ;
  if ((heff_peek_word(v_b_242) < v_a_241)) {
    heff_drop(v_f_240);
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  } else {
    V v_t_243 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_box_word(v_a_241)}));
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24f904804876x285797696_24dps(v_f_240, heff_box_word((v_a_241 + ((int64_t)1ULL))), v_b_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
}
V g_list_2emap_24f904804876x285797696_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f904804876x285797696(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f932140008x904662204_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f932140008x904662204_entry, 3, 0};

V g_list_2efoldl_24f932140008x904662204(V v_z_240, V v_box_24n_241, V v_x2_242) {
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if ((v_n_241 <= ((int64_t)0ULL))) {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_z_240;
    } else {
      V t_0 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_z_240});
      int64_t t_1 = (v_n_241 - ((int64_t)1ULL));
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_n_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f932140008x904662204_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f932140008x904662204(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24f1016251237x587084191_str0, 0, "");
HEFF_LIT(g_list_2emap_24f1016251237x587084191_str1, 0, "");
HEFF_LIT(g_list_2emap_24f1016251237x587084191_str2, 1, " ");
Clo g_list_2emap_24f1016251237x587084191_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1016251237x587084191_entry, 3, 0};

V g_list_2emap_24f1016251237x587084191(V v_w_240, V v_line_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1016251237x587084191_str0), 2)) {
      heff_drop(v_line_241);
      return NTAG(TAG_Nil);
    } else {
      V v_t_243 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
      V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
      V v_t_245 = (g_list_2emap_24s1093229560x1486136516(NTAG(TAG_Nil)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_245});
    }
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_242, 0);
    V v_xs_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_line_241, ((V)&g_list_2emap_24f1016251237x587084191_str1), 2)) {
      heff_drop(v_line_241);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_w_240;
      V t_1 = v_x_246;
      V t_2 = v_xs_247;
      v_w_240 = t_0;
      v_line_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      V v_xs_248 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_line_241))));
      V v_t_249 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_248); r_; });
      V v_xs_2410 = (g_list_2emap_24s3575633x347355318(heff_strRunes(heff_dup(v_x_246))));
      V v_t_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2410; V r_ = (g_list_2efoldl_24s114050048x1903860601(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      V v_t_2412 = heff_intAdd(heff_intAdd(v_t_249, MK_INT(1LL)), v_t_2411);
      if (heff_intLe_c_lent(v_t_2412, v_w_240, 1)) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2413 = heff_strAppend(v_line_241, heff_strAppend(((V)&g_list_2emap_24f1016251237x587084191_str2), v_x_246));
        V t_0 = v_w_240;
        V t_1 = v_t_2413;
        V t_2 = v_xs_247;
        v_w_240 = t_0;
        v_line_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        V v_t_2414 = heff_rec_n(2, shape_text__style, (V[]){v_line_241, NTAG(TAG_Plain)});
        V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
        V v_cell_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
        V v_u_2417 = (g_list_2emap_24f1016251237x587084191_24dps(v_w_240, v_x_246, v_xs_247, heff_dup(v_cell_2416)));
        heff_drop(v_u_2417);
        return v_cell_2416;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2emap_24f1016251237x587084191_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1016251237x587084191(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_24tok2_entry, 2, 0};

V g_list_2emap_24s1937570095x2110149801_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1937570095x2110149801_24dps(v_xs_243, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1937570095x2110149801_24tok2(a[0], a[1]);
}
Clo g_list_2emerge_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24tok2_entry, 4, 0};

V g_list_2emerge_24tok2(V v_tok_240, V v_le_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_le_241);
    return v_x3_243;
  }
  case TAG_Cons: {
    V v_x_244 = heff_dup(heff_field(v_x2_242, 0));
    V v_xs_245 = heff_dup(heff_field(v_x2_242, 1));
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_tok_240, 2);
      heff_drop(v_le_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      return v_x2_242;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
      heff_drop_tag(v_x2_242, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_le_241), 2, (V[]){heff_dup(v_x_244), heff_dup(v_y_246)}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_cell_249 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24dps(v_le_241, v_xs_245, heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_247}), heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      } else {
        heff_drop(v_t_248);
        V v_cell_2411 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_y_246, heff_hole()});
        V v_u_2412 = (g_list_2emerge_24dps(v_le_241, heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_xs_245}), v_ys_247, heff_dup(v_cell_2411)));
        heff_drop(v_u_2412);
        return v_cell_2411;
      }
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emerge_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24tok2(a[0], a[1], a[2], a[3]);
}