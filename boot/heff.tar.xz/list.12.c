// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_FtAny 18156
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_Many 40086
#define TAG_MkDrop 35958
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_Rest 61983
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SetField 47531
#define TAG_Some 35657
#define TAG_TagVariant 25174
#define LBL_arity 294440695
#define LBL_binder 558177493
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_member 869372357
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_tighter 1059982480
#define LBL_watch 314261737
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemitc_2efieldLine(V, V, V);
V g_heff_2ecompile_2eemitc_2efieldLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efieldLine_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2eplainOperand(V);
V g_heff_2ecompile_2eemitc_2eplainOperand_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eplainOperand_clo;
V g_heff_2ecompile_2efacts_2earityOne(V, V);
V g_heff_2ecompile_2efacts_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2earityOne_clo;
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(V, V);
V g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720_clo;
V g_heff_2ecompile_2eir_2efreshBindOne(V, V);
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshBindOne_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2elower_2egroupOut(V, V, V, V);
V g_heff_2ecompile_2elower_2egroupOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2egroupOut_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eall_24s1909236649x7702533(V);
V g_list_2eall_24s1909236649x7702533_entry(V self, V *a);
extern Clo g_list_2eall_24s1909236649x7702533_clo;
V g_list_2eany_24s2062006893x520992087(V, V, V);
V g_list_2eany_24s2062006893x520992087_entry(V self, V *a);
extern Clo g_list_2eany_24s2062006893x520992087_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1022178817x2079624138_24dps(V, V);
V g_list_2efilter_24s1022178817x2079624138_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1022178817x2079624138_24dps_clo;
V g_list_2efilter_24s1200694983x1257685262_24dps(V, V, V);
V g_list_2efilter_24s1200694983x1257685262_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1200694983x1257685262_24dps_clo;
V g_list_2efilter_24s1564977489x772952072(V, V);
V g_list_2efilter_24s1564977489x772952072_entry(V self, V *a);
extern Clo g_list_2efilter_24s1564977489x772952072_clo;
V g_list_2efilter_24s1564977489x772952072_24dps(V, V, V);
V g_list_2efilter_24s1564977489x772952072_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1564977489x772952072_24dps_clo;
V g_list_2efilter_24s1771067298x678756798_24dps(V, V, V);
V g_list_2efilter_24s1771067298x678756798_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1771067298x678756798_24dps_clo;
V g_list_2efilter_24s179107915x1917665184(V);
V g_list_2efilter_24s179107915x1917665184_entry(V self, V *a);
extern Clo g_list_2efilter_24s179107915x1917665184_clo;
V g_list_2efilter_24s179107915x1917665184_24dps(V, V);
V g_list_2efilter_24s179107915x1917665184_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s179107915x1917665184_24dps_clo;
V g_list_2efilter_24s1828661527x837139534_24dps(V, V, V);
V g_list_2efilter_24s1828661527x837139534_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1828661527x837139534_24dps_clo;
V g_list_2efilter_24s313075719x1688564285(V);
V g_list_2efilter_24s313075719x1688564285_entry(V self, V *a);
extern Clo g_list_2efilter_24s313075719x1688564285_clo;
V g_list_2efilter_24s313075719x1688564285_24dps(V, V);
V g_list_2efilter_24s313075719x1688564285_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s313075719x1688564285_24dps_clo;
V g_list_2efilter_24s337063435x1366313299(V, V, V);
V g_list_2efilter_24s337063435x1366313299_entry(V self, V *a);
extern Clo g_list_2efilter_24s337063435x1366313299_clo;
V g_list_2efilter_24s337063435x1366313299_24dps(V, V, V, V);
V g_list_2efilter_24s337063435x1366313299_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s337063435x1366313299_24dps_clo;
V g_list_2efilter_24s504691860x650330878(V);
V g_list_2efilter_24s504691860x650330878_entry(V self, V *a);
extern Clo g_list_2efilter_24s504691860x650330878_clo;
V g_list_2efilter_24s504691860x650330878_24dps(V, V);
V g_list_2efilter_24s504691860x650330878_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s504691860x650330878_24dps_clo;
V g_list_2efind_24s1702704581x1717241719(V);
V g_list_2efind_24s1702704581x1717241719_entry(V self, V *a);
extern Clo g_list_2efind_24s1702704581x1717241719_clo;
V g_list_2efind_24s250366202x1057933814(V, V, V);
V g_list_2efind_24s250366202x1057933814_entry(V self, V *a);
extern Clo g_list_2efind_24s250366202x1057933814_clo;
V g_list_2efind_24s924148649x7864569(V, V);
V g_list_2efind_24s924148649x7864569_entry(V self, V *a);
extern Clo g_list_2efind_24s924148649x7864569_clo;
V g_list_2efoldl_24s1232551929x416126852(V, V);
V g_list_2efoldl_24s1232551929x416126852_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1232551929x416126852_clo;
V g_list_2efoldl_24s1299324685x840794767(V, V);
V g_list_2efoldl_24s1299324685x840794767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1299324685x840794767_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s2092573095x552609762(V, V);
V g_list_2efoldl_24s2092573095x552609762_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2092573095x552609762_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24f1229912102x1467950109_24dps(V, V, V);
V g_list_2emap_24f1229912102x1467950109_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_24dps_clo;
V g_list_2emap_24f134831722x1788320834_24dps(V, V, V, V);
V g_list_2emap_24f134831722x1788320834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f134831722x1788320834_24dps_clo;
V g_list_2emap_24f1539731936x1117725130_24dps(V, V, V, V);
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1539731936x1117725130_24dps_clo;
V g_list_2emap_24f1548644028x2098102081_24dps(V, V, V);
V g_list_2emap_24f1548644028x2098102081_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_24dps_clo;
V g_list_2emap_24f1881659548x1623692567(V, V);
V g_list_2emap_24f1881659548x1623692567_entry(V self, V *a);
extern Clo g_list_2emap_24f1881659548x1623692567_clo;
V g_list_2emap_24f1881659548x1623692567_24dps(V, V, V);
V g_list_2emap_24f1881659548x1623692567_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1881659548x1623692567_24dps_clo;
V g_list_2emap_24f505181408x1813697659(V, V);
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_clo;
V g_list_2emap_24f505181408x1813697659_24dps(V, V, V);
V g_list_2emap_24f505181408x1813697659_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f505181408x1813697659_24dps_clo;
V g_list_2emap_24f881582358x206177481_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f881582358x206177481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f881582358x206177481_24dps_clo;
V g_list_2emap_24s1044393341x1523302351_24dps(V, V);
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_24dps_clo;
V g_list_2emap_24s1049096277x601353451_24dps(V, V);
V g_list_2emap_24s1049096277x601353451_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1049096277x601353451_24dps_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s1059370217x1267747283_24dps(V, V);
V g_list_2emap_24s1059370217x1267747283_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_24dps_clo;
V g_list_2emap_24s1157931537x649184066(V, V);
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_clo;
V g_list_2emap_24s1157931537x649184066_24dps(V, V, V);
V g_list_2emap_24s1157931537x649184066_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1157931537x649184066_24dps_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s1382928954x1260344933(V, V, V);
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_clo;
V g_list_2emap_24s1382928954x1260344933_24dps(V, V, V, V);
V g_list_2emap_24s1382928954x1260344933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_24dps_clo;
V g_list_2emap_24s1386329375x1773300759(V);
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_clo;
V g_list_2emap_24s1386329375x1773300759_24dps(V, V);
V g_list_2emap_24s1386329375x1773300759_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1386329375x1773300759_24dps_clo;
V g_list_2emap_24s1415906091x1371825187_24dps(V, V);
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_24dps_clo;
V g_list_2emap_24s1518131677x2038133191(V, V, V);
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_clo;
V g_list_2emap_24s1518131677x2038133191_24dps(V, V, V, V);
V g_list_2emap_24s1518131677x2038133191_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1518131677x2038133191_24dps_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s1960706388x853997965_24dps(V, V);
V g_list_2emap_24s1960706388x853997965_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_24dps_clo;
V g_list_2emap_24s1985010810x1780722131_24dps(V, V, V, V, V);
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1985010810x1780722131_24dps_clo;
V g_list_2emap_24s2029035892x1571084362(V);
V g_list_2emap_24s2029035892x1571084362_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_clo;
V g_list_2emap_24s2029999044x514618413_24dps(V, V);
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_24dps_clo;
V g_list_2emap_24s241620538x329208622(V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_clo;
V g_list_2emap_24s241620538x329208622_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s241620538x329208622_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s241620538x329208622_24dps_clo;
V g_list_2emap_24s265594371x763318798(V);
V g_list_2emap_24s265594371x763318798_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_clo;
V g_list_2emap_24s265594371x763318798_24dps(V, V);
V g_list_2emap_24s265594371x763318798_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s265594371x763318798_24dps_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s582709368x2113456071_24dps(V, V);
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_24dps_clo;
V g_list_2emap_24s89567162x1162500052(V, V, V, V, V, V, V);
V g_list_2emap_24s89567162x1162500052_entry(V self, V *a);
extern Clo g_list_2emap_24s89567162x1162500052_clo;
V g_list_2emap_24s89567162x1162500052_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s89567162x1162500052_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s89567162x1162500052_24dps_clo;
V g_list_2emerge_24s132798885x1165759438(V, V);
V g_list_2emerge_24s132798885x1165759438_entry(V self, V *a);
extern Clo g_list_2emerge_24s132798885x1165759438_clo;
V g_list_2emerge_24s1347843181x1368204458(V, V);
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_clo;
V g_list_2emerge_24s1347843181x1368204458_24dps(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo;
V g_list_2emerge_24s1716485482x1012130009_24dps(V, V, V);
V g_list_2emerge_24s1716485482x1012130009_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1716485482x1012130009_24dps_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s1029292936x211450510_24dps(V, V, V);
V g_list_2ezipWith_24s1029292936x211450510_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_24dps_clo;
V g_list_2ezipWith_24s29557946x653938035_24dps(V, V, V);
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo;
V g_list_2ezipWith_24s870182194x1066240094_24dps(V, V, V);
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_list_2emap_24s1415906091x1371825187_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1415906091x1371825187_24dps_entry, 2, 0};

V g_list_2emap_24s1415906091x1371825187_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1415906091x1371825187_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1415906091x1371825187_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s690313412x1307839513_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s690313412x1307839513_entry, 2, 0};

V g_list_2efoldl_24s690313412x1307839513(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2efreshBindOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s690313412x1307839513(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1044393341x1523302351_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1044393341x1523302351_24dps_entry, 2, 0};

V g_list_2emap_24s1044393341x1523302351_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = ({ V a_0 = v_a_245; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_a_245); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1044393341x1523302351_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1044393341x1523302351_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1828661527x837139534_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1828661527x837139534_24dps_entry, 3, 0};

V g_list_2efilter_24s1828661527x837139534_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
      heff_drop_rec(v_x_243, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1828661527x837139534_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1828661527x837139534_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1564977489x772952072_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1564977489x772952072_entry, 2, 0};

V g_list_2efilter_24s1564977489x772952072(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_240), heff_strLength_lent(v_x_242, 0))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1564977489x772952072_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1564977489x772952072_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1564977489x772952072(a[0], a[1]);
}
Clo g_list_2emerge_24s1347843181x1368204458_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_entry, 2, 0};

V g_list_2emerge_24s1347843181x1368204458(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_243 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_242, 7);
      heff_drop(v_xs2_243);
      return v_xs_240;
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_242, 2)), heff_dup(heff_rfield(v_y_244, 2)))) {
        V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
        V v_u_248 = (g_list_2emerge_24s1347843181x1368204458_24dps(v_xs2_243, heff_tag_n(TAG_Cons, 2, (V[]){v_y_244, v_ys2_245}), heff_dup(v_cell_247)));
        heff_drop(v_u_248);
        return v_cell_247;
      } else {
        V v_cell_249 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_244, heff_hole()});
        V v_u_2410 = (g_list_2emerge_24s1347843181x1368204458_24dps(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_xs2_243}), v_ys2_245, heff_dup(v_cell_249)));
        heff_drop(v_u_2410);
        return v_cell_249;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1347843181x1368204458_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458(a[0], a[1]);
}
Clo g_list_2emap_24s1157931537x649184066_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1157931537x649184066_entry, 2, 0};

V g_list_2emap_24s1157931537x649184066(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eparamOf(heff_dup(v_lit_240), v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1157931537x649184066_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1157931537x649184066_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1157931537x649184066(a[0], a[1]);
}
Clo g_list_2emap_24s1844509821x2028168277_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_24dps_entry, 2, 0};

V g_list_2emap_24s1844509821x2028168277_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_242));
    V v_t_2414;
    switch (heff_tag_of(v_a_244)) {
    case TAG_IsInferable: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_ru_24a_244_24IsInferable = heff_take_reuse_n(v_a_244, 1ULL, 1);
      V v_t_248;
      switch (heff_tag_of(v_a_245)) {
      case TAG_At: {
        V v_a_247 = heff_dup(heff_field(v_a_245, 1));
        v_t_248 = v_a_247;
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24IsInferable, TAG_CInf, 1, (V[]){v_a_245}), v_t_248});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_249 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_2414 = v_a_249;
      break;
    }
    case TAG_IsType: {
      V v_a_2410 = heff_field(v_a_244, 0);
      V v_ru_24a_244_24IsType = heff_take_reuse_n(v_a_244, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_At: {
        V v_a_2412 = heff_dup(heff_field(v_a_2410, 1));
        v_t_2413 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a_244_24IsType, TAG_CType, 1, (V[]){v_a_2410}), v_t_2413});
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2415;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1059370217x1267747283_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1059370217x1267747283_entry, 1, 0};

V g_list_2emap_24s1059370217x1267747283(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_ExplicitParam: {
        V v_x_245 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_245;
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_248 = heff_field(v_x11_243, 0);
        heff_take_n(v_x11_243, 1ULL, 3);
        v_t_2411 = v_x_248;
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = (g_list_2emap_24s1059370217x1267747283_24dps(v_xs_242, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1059370217x1267747283(a[0]);
}
Clo g_list_2ezipWith_24s1029292936x211450510_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1029292936x211450510_entry, 2, 0};

V g_list_2ezipWith_24s1029292936x211450510(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_y_244}), heff_hole()});
      V v_u_2410 = (g_list_2ezipWith_24s1029292936x211450510_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1029292936x211450510(a[0], a[1]);
}
Clo g_list_2emap_24s1049096277x601353451_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1049096277x601353451_24dps_entry, 2, 0};

V g_list_2emap_24s1049096277x601353451_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2438;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2438 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2438 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2439 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2438, heff_hole()});
    V v_u_2440 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2439));
    heff_drop(v_u_2440);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2439;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1049096277x601353451_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1049096277x601353451_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s2040448920x1981923787_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2040448920x1981923787_entry, 2, 0};

V g_list_2efoldl_24s2040448920x1981923787(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      v_t_249 = heff_dup(v_a_248);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = (g_map_2einsert_24s1341440536x470972936(v_t_246, v_t_249, v_z_240));
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2040448920x1981923787(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s361191175x1417189158_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s361191175x1417189158_entry, 2, 0};

V g_list_2efoldl_24s361191175x1417189158(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_245;
    if (heff_intLe_c(heff_dup(v_z_240), heff_dup(v_x_242))) {
      v_t_245 = v_z_240;
    } else {
      heff_drop(v_z_240);
      v_t_245 = heff_dup(v_x_242);
    }
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s361191175x1417189158(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1299324685x840794767_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1299324685x840794767_entry, 2, 0};

V g_list_2efoldl_24s1299324685x840794767(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eimperative_2epartsVal_24s1900488799x288917720(heff_dup(v_x_242), v_z_240));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1299324685x840794767_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1299324685x840794767(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1232551929x416126852_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1232551929x416126852_entry, 2, 0};

V g_list_2efoldl_24s1232551929x416126852(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2efacts_2earityOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1232551929x416126852_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1232551929x416126852(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1022178817x2079624138_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1022178817x2079624138_24dps_entry, 2, 0};

V g_list_2efilter_24s1022178817x2079624138_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439;
    switch (heff_tag_of(v_x_242)) {
    case TAG_SLocal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SGlobal: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SCode: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SApp: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLam: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SCons: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SProj: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_STag: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SMatch: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SSpecialize: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SIs: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SOpaque: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SAbandon: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SRec: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SFix: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SImplicit: {
      v_t_2439 = NTAG(TAG_False);
      break;
    }
    case TAG_SPrim: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SMetaApp: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitInt: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitString: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitBytes: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitRune: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFixed: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    case TAG_SLitFloat32: {
      v_t_2439 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop(v_t_2439);
      V v_cell_2440 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2441 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2440));
      heff_drop(v_u_2441);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2440;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_2439);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1022178817x2079624138_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1022178817x2079624138_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s868530262x539343671_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s868530262x539343671_entry, 2, 0};

V g_list_2efoldl_24s868530262x539343671(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_i_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_PVar: {
        V v_l_246 = heff_field(v_x22_245, 0);
        v_t_247 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_l_246), heff_dup(v_i_244), v_z_240));
        break;
      }
      case TAG_PSelf: {
        v_t_247 = v_z_240;
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s868530262x539343671(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s89567162x1162500052_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s89567162x1162500052_entry, 7, 0};

V g_list_2emap_24s89567162x1162500052(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eelab_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2410); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
      v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, v_t_2414));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s89567162x1162500052_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s89567162x1162500052_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s89567162x1162500052(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s241620538x329208622_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s241620538x329208622_entry, 7, 0};

V g_list_2emap_24s241620538x329208622(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2eelab_2eprint_2eescFrom(v_a_249, heff_dup(v_lit_242)));
      V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_243)));
      V v_t_2413 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2410); r_; });
      V v_t_2414 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
      v_t_2415 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2412, v_t_2414));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s241620538x329208622_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s241620538x329208622_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s241620538x329208622(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1367173129x1257089258_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_24dps_entry, 2, 0};

V g_list_2emap_24s1367173129x1257089258_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 4), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s504691860x650330878_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s504691860x650330878_entry, 1, 0};

V g_list_2efilter_24s504691860x650330878(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s504691860x650330878_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s504691860x650330878_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s504691860x650330878(a[0]);
}
Clo g_list_2eall_24s1793250635x935291087_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1793250635x935291087_entry, 1, 0};

V g_list_2eall_24s1793250635x935291087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Given: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_GivenU: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_LentVar: {
      V v_x12_247 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_x12_247)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x12_247);
      }
    }
    case TAG_LentValue: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1793250635x935291087(a0); heff_drop(a0); return r;
}
Clo g_list_2ezipWith_24s870182194x1066240094_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s870182194x1066240094_24dps_entry, 3, 0};

V g_list_2ezipWith_24s870182194x1066240094_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_243)) {
      case TAG_RepV: {
        heff_drop_cell(v_ru_24ys_241_24Cons, 2);
        v_t_248 = v_y_245;
        break;
      }
      case TAG_RepFix: {
        v_t_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      case TAG_RepF64: {
        v_t_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_RWord, 2, (V[]){v_x_243, v_y_245});
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_249 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_249;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s870182194x1066240094_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s870182194x1066240094_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s179107915x1917665184_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s179107915x1917665184_entry, 1, 0};

V g_list_2efilter_24s179107915x1917665184(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_RepV: {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s179107915x1917665184_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_248, 0ULL, 1);
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s179107915x1917665184_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s179107915x1917665184(a[0]);
}
Clo g_list_2emap_24s1985010810x1780722131_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1985010810x1780722131_24dps_entry, 5, 0};

V g_list_2emap_24s1985010810x1780722131_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2elower_2egroupOut(v_lit_240, heff_dup(v_lit_241), v_lit_242, v_x_245));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1985010810x1780722131_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1985010810x1780722131_24dps(a0, a[1], a2, a[3], a[4]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2eall_24s1909236649x7702533_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1909236649x7702533_entry, 1, 0};

V g_list_2eall_24s1909236649x7702533(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eplainOperand(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1909236649x7702533_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1909236649x7702533(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1382928954x1260344933_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1382928954x1260344933_entry, 3, 0};

V g_list_2emap_24s1382928954x1260344933(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_intShow(v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1382928954x1260344933_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1382928954x1260344933_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1382928954x1260344933(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1518131677x2038133191_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1518131677x2038133191_entry, 3, 0};

V g_list_2emap_24s1518131677x2038133191(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = v_lit_241; V a_2 = v_x_243; V r_ = (g_heff_2ecompile_2eemitc_2efieldLine(a_0, a_1, a_2)); heff_drop(v_x_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s1518131677x2038133191_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1518131677x2038133191_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1518131677x2038133191(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str0, 1, "V");
HEFF_LIT(g_list_2emap_24s1386329375x1773300759_str1, 6, "double");
Clo g_list_2emap_24s1386329375x1773300759_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1386329375x1773300759_entry, 1, 0};

V g_list_2emap_24s1386329375x1773300759(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    switch (heff_tag_of(v_x_241)) {
    case TAG_RepV: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str0);
      break;
    }
    case TAG_RepFix: {
      V v_w_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      v_t_244 = ({ V a_0 = v_w_243; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_243); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_244 = ((V)&g_list_2emap_24s1386329375x1773300759_str1);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1386329375x1773300759_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1386329375x1773300759_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1386329375x1773300759(a[0]);
}
Clo g_list_2emap_24s1960706388x853997965_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1960706388x853997965_entry, 1, 0};

V g_list_2emap_24s1960706388x853997965(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1960706388x853997965_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1960706388x853997965(a[0]);
}
Clo g_list_2emap_24s265594371x763318798_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s265594371x763318798_entry, 1, 0};

V g_list_2emap_24s265594371x763318798(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_take_field(v_x_241, 1)});
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_241, 0, 4), v_t_243});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s265594371x763318798_24dps(v_xs_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s265594371x763318798_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s265594371x763318798(a[0]);
}
Clo g_list_2eany_24s2062006893x520992087_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2062006893x520992087_entry, 3, 0};

V g_list_2eany_24s2062006893x520992087(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_lit_240, 1)), 0, 2);
    if (heff_intLt_c(v_t_245, heff_dup(v_x_243))) {
      if (heff_intLt_c(heff_dup(v_x_243), heff_dup(v_lit_241))) {
        heff_drop_rec(v_lit_240, 2);
        heff_drop(v_lit_241);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s2062006893x520992087_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s2062006893x520992087(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ezipWith_24s29557946x653938035_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s29557946x653938035_24dps_entry, 3, 0};

V g_list_2ezipWith_24s29557946x653938035_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 1, 3), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_248;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s29557946x653938035_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s29557946x653938035_24dps(a[0], a[1], a[2]);
}
Clo g_list_2esortBy_24s492793466x2081132734_clo = {{0x80000000u, K_CLO, 0}, g_list_2esortBy_24s492793466x2081132734_entry, 1, 0};

V g_list_2esortBy_24s492793466x2081132734(V v_xs_240) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_242 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_xs2_242)) {
    case TAG_Nil: {
      heff_drop_tag(v_xs_240, 2);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_xs2_242, 0ULL, 2);
      heff_drop(v_x_241);
      V v_t_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_246 = (g_list_2etake(heff_intDiv(v_t_245, MK_INT(2LL)), heff_dup(v_xs_240)));
      V v_t_247 = (g_list_2esortBy_24s492793466x2081132734(v_t_246));
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_249 = (g_list_2edrop(heff_intDiv(v_t_248, MK_INT(2LL)), v_xs_240));
      V v_t_2410 = (g_list_2esortBy_24s492793466x2081132734(v_t_249));
      return (g_list_2emerge_24s132798885x1165759438(v_t_247, v_t_2410));
    }
    default: return heff_nomatch(v_xs2_242);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a) {
  (void)self;
  return g_list_2esortBy_24s492793466x2081132734(a[0]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str0, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s404123879x745642248_24dps_str2, 9, "{ name = ");
Clo g_list_2emap_24s404123879x745642248_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_24dps_entry, 2, 0};

V g_list_2emap_24s404123879x745642248_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_242, 0)));
    V v_t_245 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_242, 1, 2)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_24dps_str0), heff_strAppend(v_t_245, ((V)&g_list_2emap_24s404123879x745642248_24dps_str1)));
    V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_24dps_str2), heff_strAppend(v_t_244, v_t_246));
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1200694983x1257685262_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1200694983x1257685262_24dps_entry, 3, 0};

V g_list_2efilter_24s1200694983x1257685262_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_249;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1200694983x1257685262_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1200694983x1257685262_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1771067298x678756798_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1771067298x678756798_24dps_entry, 3, 0};

V g_list_2efilter_24s1771067298x678756798_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      heff_drop_rec(v_x_243, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1771067298x678756798_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1771067298x678756798_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s1716485482x1012130009_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1716485482x1012130009_24dps_entry, 3, 0};

V g_list_2emerge_24s1716485482x1012130009_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 2);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_strLt_c(heff_dup(heff_rfield(v_y_245, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_248;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_2410;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1716485482x1012130009_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1716485482x1012130009_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s173442543x1801751270_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_entry, 1, 0};

V g_list_2emap_24s173442543x1801751270(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_TagVariant: {
        V v_t_245 = heff_field(v_x11_243, 0);
        V v_tsp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 3);
        v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_245, v_tsp_246})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_249 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s173442543x1801751270_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270(a[0]);
}
Clo g_list_2efind_24s924148649x7864569_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s924148649x7864569_entry, 2, 0};

V g_list_2efind_24s924148649x7864569(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 1));
    if (heff_intEq_c(heff_dup(heff_rfield(v_a_244, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      if (heff_intEq_c(heff_get_n(v_a_244, 1, 2), heff_dup(heff_rfield(v_lit_240, 1)))) {
        heff_drop_rec(v_lit_240, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop_rec(v_a_244, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s924148649x7864569_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s924148649x7864569(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efind_24s1702704581x1717241719_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s1702704581x1717241719_entry, 1, 0};

V g_list_2efind_24s1702704581x1717241719(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 0)), 1, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_241)});
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efind_24s1702704581x1717241719_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efind_24s1702704581x1717241719(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s189033563x26633104_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s189033563x26633104_entry, 2, 0};

V g_list_2efoldl_24s189033563x26633104(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s189033563x26633104(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s337063435x1366313299_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s337063435x1366313299_entry, 3, 0};

V g_list_2efilter_24s337063435x1366313299(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_intSub(heff_strLength_lent(v_x_243, 0), heff_strLength_lent(v_lit_240, 0));
    V v_t_246 = heff_strSlice(heff_dup(v_x_243), v_t_245, heff_strLength_lent(v_x_243, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_241, 1)) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_249 = (g_list_2efilter_24s337063435x1366313299_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efilter_24s337063435x1366313299_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s337063435x1366313299(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s313075719x1688564285_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s313075719x1688564285_entry, 1, 0};

V g_list_2efilter_24s313075719x1688564285(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 2)), 6, 10);
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s313075719x1688564285_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s313075719x1688564285_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s313075719x1688564285(a[0]);
}
Clo g_list_2efoldl_24s2092573095x552609762_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2092573095x552609762_entry, 2, 0};

V g_list_2efoldl_24s2092573095x552609762(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = heff_get_n(v_t_246, 1, 2);
    V v_t_249;
    if (heff_intLe_c(heff_dup(v_z_240), heff_dup(v_a_247))) {
      heff_drop(v_z_240);
      v_t_249 = v_a_247;
    } else {
      heff_drop(v_a_247);
      v_t_249 = v_z_240;
    }
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2092573095x552609762_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2092573095x552609762(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s582709368x2113456071_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s582709368x2113456071_24dps_entry, 2, 0};

V g_list_2emap_24s582709368x2113456071_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 0, 2), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s582709368x2113456071_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s582709368x2113456071_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s250366202x1057933814_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s250366202x1057933814_entry, 3, 0};

V g_list_2efind_24s250366202x1057933814(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 4);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_240, 0)))) {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 0, 2);
      if (heff_intLe_c(v_t_246, heff_dup(v_lit_241))) {
        V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 1, 2);
        if (heff_intLe_c(heff_dup(v_lit_241), v_t_248)) {
          heff_drop_rec(v_lit_240, 4);
          heff_drop(v_lit_241);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_243)});
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_lit_241;
          V t_2 = v_xs_244;
          v_lit_240 = t_0;
          v_lit_241 = t_1;
          v_x2_242 = t_2;
          goto top;
        }
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_xs_244;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_x2_242 = t_2;
        goto top;
      }
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efind_24s250366202x1057933814_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efind_24s250366202x1057933814(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str0, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str1, 1, "]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str2, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str3, 4, "...]");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str4, 3, "...");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str5, 1, "[");
HEFF_LIT(g_list_2emap_24s2029999044x514618413_24dps_str6, 4, "...]");
Clo g_list_2emap_24s2029999044x514618413_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029999044x514618413_24dps_entry, 2, 0};

V g_list_2emap_24s2029999044x514618413_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_take_field(v_x_242, 0);
    V v_t_245 = heff_get_n(v_x_242, 1, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_One: {
      v_t_246 = v_m_244;
      break;
    }
    case TAG_Optional: {
      v_t_246 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str0), heff_strAppend(v_m_244, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str1)));
      break;
    }
    case TAG_Many: {
      v_t_246 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str2), heff_strAppend(v_m_244, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str3)));
      break;
    }
    case TAG_Some: {
      v_t_246 = heff_strAppend(v_m_244, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str4));
      break;
    }
    case TAG_Rest: {
      v_t_246 = heff_strAppend(((V)&g_list_2emap_24s2029999044x514618413_24dps_str5), heff_strAppend(v_m_244, ((V)&g_list_2emap_24s2029999044x514618413_24dps_str6)));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029999044x514618413_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029999044x514618413_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f1881659548x1623692567_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1881659548x1623692567_entry, 2, 0};

V g_list_2emap_24f1881659548x1623692567(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
      V v_u_246 = (g_list_2emap_24f1881659548x1623692567_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1881659548x1623692567_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1881659548x1623692567(a[0], a[1]);
}
Clo g_list_2emap_24f1229912102x1467950109_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1229912102x1467950109_entry, 2, 0};

V g_list_2emap_24f1229912102x1467950109(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return (g_list_2emap_24s2029035892x1571084362(v_xs_243));
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
      V v_u_246 = (g_list_2emap_24f1229912102x1467950109_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1229912102x1467950109(a[0], a[1]);
}
Clo g_list_2emap_24f505181408x1813697659_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f505181408x1813697659_entry, 2, 0};

V g_list_2emap_24f505181408x1813697659(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return (g_list_2emap_24s1809017761x1063871171(v_xs_243));
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_hole()});
      V v_u_246 = (g_list_2emap_24f505181408x1813697659_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f505181408x1813697659_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f505181408x1813697659(a[0], a[1]);
}
Clo g_list_2emap_24f1548644028x2098102081_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1548644028x2098102081_24dps_entry, 3, 0};

V g_list_2emap_24f1548644028x2098102081_24dps(V v_p_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_243, NTAG(TAG_Nothing)});
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1548644028x2098102081_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1548644028x2098102081_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f881582358x206177481_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f881582358x206177481_24dps_entry, 10, 0};

V g_list_2emap_24f881582358x206177481_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    return heff_setField(v_d_249, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_248, 0);
    V v_xs_2411 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_2410, v_lit_245, v_lit_246, 0), heff_dup(v_lit_247))) {
      heff_drop(v_x_2410);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2411;
      V t_9 = v_d_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_d_249 = t_9;
      goto top;
    } else {
      V v_t_2415;
      if (heff_strEq_c(heff_strSlice_lent(v_x_2410, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
        V v_t_2414 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_244), heff_strLength(v_x_2410));
        v_t_2415 = heff_strAppend(heff_dup(v_lit_243), v_t_2414);
      } else {
        v_t_2415 = v_x_2410;
      }
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2416));
      heff_drop(v_u_2417);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2411;
      V t_9 = v_cell_2416;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f881582358x206177481_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f881582358x206177481_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_list_2emap_24f1539731936x1117725130_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1539731936x1117725130_24dps_entry, 4, 0};

V g_list_2emap_24f1539731936x1117725130_24dps(V v_lit_240, V v_i_241, V v_n_242, V v_d_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_i_241))) {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){heff_dup(v_lit_240)}), heff_hole()});
    V v_u_246 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_n_242;
    V t_3 = v_cell_245;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f1539731936x1117725130_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1539731936x1117725130_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f134831722x1788320834_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f134831722x1788320834_24dps_entry, 4, 0};

V g_list_2emap_24f134831722x1788320834_24dps(V v_lit_240, V v_p_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_244, 0, 8));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f134831722x1788320834_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f134831722x1788320834_24dps(a[0], a[1], a[2], a[3]);
}