// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Start 63542
#define TAG_UseColor 15915
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_by 9918
#define LBL_copies 592412158
#define LBL_cwd 308458
#define LBL_diags 296935042
#define LBL_diff 9578700
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_effect 641056956
#define LBL_emits 297985818
#define LBL_end 310101
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_file 9638467
#define LBL_globals 352931696
#define LBL_got 312070
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_implicit 319715269
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_lib 316671
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_mod 317820
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_olds 9909235
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_outPath 1272254166
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_pages 307784670
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_prefix 967031229
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_seen 10021698
#define LBL_segments 1801007612
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_src 323678
#define LBL_status 1054660381
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_units 312791945
#define LBL_value 313331083
#define LBL_version 583465758
#define LBL_watch 314261737
#define LBL_watches 1357821955
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_groups__copies__emits[] = {LBL_groups, LBL_copies, LBL_emits};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_root__src__lib__mod__cwd__style[] = {LBL_root, LBL_src, LBL_lib, LBL_mod, LBL_cwd, LBL_style};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
static uint32_t shape_total__failed__ok__tests__testsFailed[] = {LBL_total, LBL_failed, LBL_ok, LBL_tests, LBL_testsFailed};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackD(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackD_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo;
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V, V);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ebuiltAt(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuiltAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuiltAt_clo;
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_clo;
V g_heff_2ebuild_2ecommands_2edefaultSeed_get(void);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_clo;
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_clo;
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo;
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_clo;
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get(void);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(V, V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo;
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_clo;
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo;
V g_heff_2ebuild_2ecommands_2eheffVersions(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eheffVersions_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffVersions_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo;
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V, V, V);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo;
V g_heff_2ebuild_2ecommands_2ekeptId(V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptId_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptId_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(V, V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeLine(V);
V g_heff_2ebuild_2ecommands_2eoutcomeLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeLine_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2epathOfModule(V, V);
V g_heff_2ebuild_2ecommands_2epathOfModule_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epathOfModule_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_clo;
V g_heff_2ebuild_2ecommands_2eprogramText(V);
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprogramText_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_clo;
V g_heff_2ebuild_2ecommands_2erequiring(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erequiring_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erequiring_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525(V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunPath(V, V);
V g_heff_2ebuild_2ecommands_2erunPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunPath_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_clo;
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_clo;
V g_heff_2ebuild_2ecommands_2eversionSaid(V, V);
V g_heff_2ebuild_2ecommands_2eversionSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_clo;
V g_heff_2ebuild_2edecoder_2erun(V, V);
V g_heff_2ebuild_2edecoder_2erun_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2erun_clo;
V g_heff_2ebuild_2edecoder_2ewhole(V, V, V);
V g_heff_2ebuild_2edecoder_2ewhole_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewhole_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
V g_heff_2ebuild_2edriver_2eeffectOfKey(V, V);
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo;
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
V g_heff_2ebuild_2edriver_2efindRunnable(V, V, V);
V g_heff_2ebuild_2edriver_2efindRunnable_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efindRunnable_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erunTests(V, V);
V g_heff_2ebuild_2edriver_2erunTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erunTests_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2efromCwd(V, V);
V g_heff_2ebuild_2eload_2efromCwd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2efromCwd_clo;
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(V, V);
V g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2eofLibrary(V, V);
V g_heff_2ebuild_2eload_2eofLibrary_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eofLibrary_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisName(V);
V g_heff_2ebuild_2eproject_2eisName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisName_clo;
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
V g_heff_2ebuild_2eproject_2emajorMismatch(V, V);
V g_heff_2ebuild_2eproject_2emajorMismatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2emajorMismatch_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2ereadBuild(V);
V g_heff_2ebuild_2eproject_2ereadBuild_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereadBuild_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2equery_2etypeAt(V, V);
V g_heff_2ebuild_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypeAt_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2ecompile_2eemit_2ecompileLowered(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileLowered_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eemitc_2ekeptParts(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptParts_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2elower_2eanfLowered(V, V);
V g_heff_2ecompile_2elower_2eanfLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2eanfLowered_clo;
V g_heff_2ecompile_2elower_2elowerProgram(V, V);
V g_heff_2ecompile_2elower_2elowerProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgram_clo;
V g_heff_2ecompile_2elower_2elowerProgramAnf(V, V);
V g_heff_2ecompile_2elower_2elowerProgramAnf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramAnf_clo;
V g_heff_2ecompile_2elower_2elowerProgramKept(V, V, V, V);
V g_heff_2ecompile_2elower_2elowerProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramKept_clo;
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2elsp_2erender_2efileDiag(V, V, V, V);
V g_heff_2elsp_2erender_2efileDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2efileDiag_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2eformat_2eformat(V);
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eformat_clo;
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eimport_2eimplicitModules_get(void);
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2eany_24s976871491x582277361(V);
V g_list_2eany_24s976871491x582277361_entry(V self, V *a);
extern Clo g_list_2eany_24s976871491x582277361_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1956506708x1796911658(V);
V g_list_2efilter_24s1956506708x1796911658_entry(V self, V *a);
extern Clo g_list_2efilter_24s1956506708x1796911658_clo;
V g_list_2efilter_24s1966237873x2134891024(V, V, V);
V g_list_2efilter_24s1966237873x2134891024_entry(V self, V *a);
extern Clo g_list_2efilter_24s1966237873x2134891024_clo;
V g_list_2efilter_24s34002769x154977349(V);
V g_list_2efilter_24s34002769x154977349_entry(V self, V *a);
extern Clo g_list_2efilter_24s34002769x154977349_clo;
V g_list_2efilter_24s413688307x112671032(V, V, V, V);
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a);
extern Clo g_list_2efilter_24s413688307x112671032_clo;
V g_list_2efilter_24s835571418x868029304(V);
V g_list_2efilter_24s835571418x868029304_entry(V self, V *a);
extern Clo g_list_2efilter_24s835571418x868029304_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1301054807x1042293437(V, V);
V g_list_2efoldl_24s1301054807x1042293437_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1301054807x1042293437_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1751327013x555271812(V, V);
V g_list_2efoldl_24s1751327013x555271812_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1751327013x555271812_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s230517345x1163337657(V, V);
V g_list_2efoldl_24s230517345x1163337657_entry(V self, V *a);
extern Clo g_list_2efoldl_24s230517345x1163337657_clo;
V g_list_2efoldl_24s310383131x1909826775(V, V);
V g_list_2efoldl_24s310383131x1909826775_entry(V self, V *a);
extern Clo g_list_2efoldl_24s310383131x1909826775_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s620173997x1959585086(V, V);
V g_list_2efoldl_24s620173997x1959585086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s620173997x1959585086_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s682444417x1397580212(V, V, V, V, V, V);
V g_list_2efoldl_24s682444417x1397580212_entry(V self, V *a);
extern Clo g_list_2efoldl_24s682444417x1397580212_clo;
V g_list_2efoldl_24s844754919x2100408598(V, V, V, V);
V g_list_2efoldl_24s844754919x2100408598_entry(V self, V *a);
extern Clo g_list_2efoldl_24s844754919x2100408598_clo;
V g_list_2efoldl_24s9956384x694087549(V, V);
V g_list_2efoldl_24s9956384x694087549_entry(V self, V *a);
extern Clo g_list_2efoldl_24s9956384x694087549_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1052938345x548264065(V, V, V, V, V);
V g_list_2emap_24s1052938345x548264065_entry(V self, V *a);
extern Clo g_list_2emap_24s1052938345x548264065_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1288527083x146849530(V);
V g_list_2emap_24s1288527083x146849530_entry(V self, V *a);
extern Clo g_list_2emap_24s1288527083x146849530_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1416288597x2006619516(V);
V g_list_2emap_24s1416288597x2006619516_entry(V self, V *a);
extern Clo g_list_2emap_24s1416288597x2006619516_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1431621018x139529971(V, V);
V g_list_2emap_24s1431621018x139529971_entry(V self, V *a);
extern Clo g_list_2emap_24s1431621018x139529971_clo;
V g_list_2emap_24s1665123230x1905625068(V, V, V, V, V, V);
V g_list_2emap_24s1665123230x1905625068_entry(V self, V *a);
extern Clo g_list_2emap_24s1665123230x1905625068_clo;
V g_list_2emap_24s467999193x422550880(V, V, V, V);
V g_list_2emap_24s467999193x422550880_entry(V self, V *a);
extern Clo g_list_2emap_24s467999193x422550880_clo;
V g_list_2emap_24s499977176x606563528(V, V, V);
V g_list_2emap_24s499977176x606563528_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_clo;
V g_list_2emap_24s570241860x1995261629(V);
V g_list_2emap_24s570241860x1995261629_entry(V self, V *a);
extern Clo g_list_2emap_24s570241860x1995261629_clo;
V g_list_2emap_24s634984521x2042558081(V);
V g_list_2emap_24s634984521x2042558081_entry(V self, V *a);
extern Clo g_list_2emap_24s634984521x2042558081_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_list_2esortBy_24s851943868x104872707(V);
V g_list_2esortBy_24s851943868x104872707_entry(V self, V *a);
extern Clo g_list_2esortBy_24s851943868x104872707_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  V v_p_242 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_242, 2)));
  V v_xs_244 = (g_list_2edrop(MK_INT(1LL), v_t_243));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_242, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_s_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_s_247));
  V v_xs_249 = heff_get_n(v_t_248, 2, 3);
  V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  V v_x2_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_x2_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_x2_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2437;
  if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    V v_p_2417 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2417, 2)));
    V v_xs_2419 = (g_list_2edrop(MK_INT(1LL), v_t_2418));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2422 = (g_std_2epath_2erender(v_st_240, v_t_2421));
    V v_p_2423 = (g_std_2epath_2eparse(v_st_240, v_s_2422));
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2423, 2)));
    V v_xs_2425 = (g_list_2edrop(MK_INT(1LL), v_t_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_n(v_p_2423, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2428 = (g_std_2epath_2erender(v_st_240, v_t_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_st_240, v_s_2428));
    V v_xs_2430 = heff_get_n(v_t_2429, 2, 3);
    V v_x1_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
    V v_x2_2434;
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nil: {
      v_x2_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x1_2431, 0);
      heff_take_n(v_x1_2431, 1ULL, 2);
      v_x2_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2432});
      break;
    }
    default: heff_nomatch(v_x1_2431);
    }
    V v_t_2436;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nothing: {
      v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      heff_take_n(v_x2_2434, 1ULL, 1);
      v_t_2436 = v_x_2435;
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    v_t_2437 = heff_strEq(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_2437 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    V v_p_2438 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2438, 2)));
    V v_xs_2440 = (g_list_2edrop(MK_INT(1LL), v_t_2439));
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2440));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_n(v_p_2438, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2443 = (g_std_2epath_2erender(v_st_240, v_t_2442));
    V v_p_2444 = (g_std_2epath_2eparse(v_st_240, v_s_2443));
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2444, 2)));
    V v_xs_2446 = (g_list_2edrop(MK_INT(1LL), v_t_2445));
    V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2446));
    V v_t_2448 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_n(v_p_2444, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2449 = (g_std_2epath_2erender(v_st_240, v_t_2448));
    V v_p_2450 = (g_std_2epath_2eparse(v_st_240, v_s_2449));
    V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2450, 2)));
    V v_xs_2452 = (g_list_2edrop(MK_INT(1LL), v_t_2451));
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
    V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_n(v_p_2450, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2454);
  }
  case TAG_False: {
    V v_p_2455 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2455, 2)));
    V v_xs_2457 = (g_list_2edrop(MK_INT(1LL), v_t_2456));
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2457));
    V v_t_2459 = ({ V rv_2 = v_t_2458; V rr_ = heff_rec_reuse_n(v_p_2455, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2460 = (g_std_2epath_2erender(v_st_240, v_t_2459));
    V v_p_2461 = (g_std_2epath_2eparse(v_st_240, v_s_2460));
    V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2461, 2)));
    V v_xs_2463 = (g_list_2edrop(MK_INT(1LL), v_t_2462));
    V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2463));
    V v_t_2465 = ({ V rv_2 = v_t_2464; V rr_ = heff_rec_reuse_n(v_p_2461, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2465);
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eownRoot(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaid_str0, 0, "");
Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2esourceSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_text_241 = heff_field(v_x1_240, 0);
    V v_t_242 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), MK_INT(0LL), MK_INT(1LL)));
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_text_241)), MK_INT(1LL));
    V v_t_244 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), v_t_243, MK_INT(-1LL)));
    V v_t_245 = heff_strSlice(heff_dup(v_text_241), v_t_242, heff_intAdd(v_t_244, MK_INT(1LL)));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2esourceSaid_str0))) {
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), MK_INT(0LL), MK_INT(1LL)));
      V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_text_241)), MK_INT(1LL));
      V v_t_249 = (g_prelude_2eskipSpaces(heff_dup(v_text_241), v_t_248, MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(heff_dup(v_text_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_str0, 23, "not known: there is no ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_str1, 11, "not known: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionSaid_str2, 5, "heff ");
Clo g_heff_2ebuild_2ecommands_2eversionSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionSaid_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionSaid(V v_path_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_str0), v_path_240)});
  }
  case TAG_Just: {
    V v_src_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_243 = (g_heff_2ebuild_2eproject_2epackageLit(heff_dup(v_src_242)));
    V v_x3_246;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_p_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      v_x3_246 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Left, 1, (V[]){v_p_244});
      break;
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      v_x3_246 = ({ V a_0 = v_x_245; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_245); r_; });
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Left: {
      V v_p_247 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Left = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_str1), (g_heff_2ebuild_2eload_2eproblemMsg(v_path_240, v_src_242, v_p_247)));
      return heff_tag_at_n(v_ru_24x3_246_24Left, TAG_Left, 1, (V[]){v_t_248});
    }
    case TAG_Right: {
      V v_p_249 = heff_field(v_x3_246, 0);
      V v_ru_24x3_246_24Right = heff_take_reuse_n(v_x3_246, 1ULL, 1);
      heff_drop(v_path_240);
      heff_drop(v_src_242);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionSaid_str2), heff_get_n(v_p_249, 1, 4));
      return heff_tag_at_n(v_ru_24x3_246_24Right, TAG_Right, 1, (V[]){v_t_2410});
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eversionSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionSaid(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str0, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str1, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str3, 13, " is for heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str4, 19, ", and this heff is ");
Clo g_heff_2ebuild_2ecommands_2eheffVersions_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffVersions_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eheffVersions(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      heff_drop(v_w_245);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_w_245; V a_1 = v_r_246; V r_ = (g_heff_2ebuild_2eproject_2ecompatible(a_0, a_1)); heff_drop(v_w_245); heff_drop(v_r_246); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V v_t_249;
        if (heff_strEq_c(heff_strSlice(heff_dup(v_wanted_241), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str0))) {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str1);
        } else {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str2);
        }
        V v_t_2410 = heff_strAppend(v_who_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str3), heff_strAppend(v_wanted_241, heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str4), v_running_242)))));
        return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_t_2410});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2eheffVersions_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffVersions(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_xs_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_xs_245 = v_deps_243;
    } else {
      v_xs_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
    }
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eheffErrors(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_who_2410;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 3)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
    v_who_2410 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
  } else {
    v_who_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), heff_dup(heff_rfield(v_x_248, 0)));
  }
  V v_wanted_2411 = heff_get_n(v_x_248, 5, 7);
  V v_t_2417;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop(v_who_2410);
    heff_drop(v_wanted_2411);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2412 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2413 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_wanted_2411)));
    V v_t_2414 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_running_2412)));
    V v_t_2415 = (g_heff_2ebuild_2ecommands_2eheffVersions(v_who_2410, v_wanted_2411, v_running_2412, v_t_2413, v_t_2414));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_why_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2416, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2417, v_acc_247));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2ebuild_2ecommands_2enubStrGo(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2epathOfModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epathOfModule_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epathOfModule(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_m_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_s_242, 1))});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2epathOfModule_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2epathOfModule(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5, 1, "$");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str3), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str4), heff_dup(heff_rfield(v_p_242, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_list_2emap_24s732475005x1616712052(v_t_2412));
      V v_t_2414 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2413));
      V v_t_2415 = (g_list_2efilter_24s413688307x112671032(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeaf_str5), v_t_2414));
      V v_t_2416 = ({ V a_0 = v_t_2411; V a_1 = v_t_2415; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        heff_drop(v_k_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2416);
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeaf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240) {
top: ;
  V v_st_241 = heff_take_field(v_paths_240, 5);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get_n(v_paths_240, 0, 6)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunPath_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunPath_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunPath_str2, 4, ".mjs");
Clo g_heff_2ebuild_2ecommands_2erunPath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunPath_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunPath(V v_paths_240, V v_file_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_240)));
  V v_p_243 = (g_std_2epath_2eparse(heff_rfield(v_paths_240, 5), v_file_241));
  V v_x2_244 = ({ V a_0 = heff_take_field(v_p_243, 1); V b_1 = heff_get_n(v_p_243, 2, 3); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2ecommands_2erunPath_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunPath_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  return (g_heff_2ebuild_2eload_2eunder(v_paths_240, v_t_242, heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2erunPath_str2))));
}
V g_heff_2ebuild_2ecommands_2erunPath_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunPath(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5, 23, "static V heff_provider_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6, 23, "static V heff_provider_");
Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str0), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_245 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), v_t_248)) {
      V v_t_2410 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str3), heff_dup(v_k_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2411 = ({ V a_0 = heff_dup(v_k_241); V a_1 = v_t_2410; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str4), heff_dup(heff_rfield(v_p_242, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2413 = (g_list_2emap_24s1665123230x1905625068(MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str5), ((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_str6), MK_INT(23LL), MK_INT(23LL), v_t_2412));
      V v_t_2414 = (g_heff_2ecompile_2eemitc_2ecatMaybesC(v_t_2413));
      V v_t_2415 = ({ V a_0 = v_t_2411; V a_1 = v_t_2414; V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2414); r_; });
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_k_241);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_2415);
      }
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprovidesLeafC(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  return (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_247, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
Clo g_heff_2ebuild_2ecommands_2ekeptId_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptId_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ekeptId(V v_b_240, V v_x2_241, V v_kept_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_b_240);
    heff_drop(v_kept_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_at_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_kept_242)), heff_dup(v_at_243));
    if (heff_intEq_c(heff_intSub(v_t_244, MK_INT(1LL)), heff_strLength(heff_dup(v_b_240)))) {
      V v_t_246 = heff_strSlice(heff_dup(v_kept_242), heff_intAdd(heff_dup(v_at_243), MK_INT(1LL)), heff_strLength(heff_dup(v_kept_242)));
      if (heff_strEq_c(v_t_246, v_b_240)) {
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_strSlice(v_kept_242, MK_INT(0LL), v_at_243)});
      } else {
        heff_drop(v_kept_242);
        heff_drop(v_at_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_b_240);
      heff_drop(v_kept_242);
      heff_drop(v_at_243);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ekeptId_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptId(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_n(v_p_244, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_b_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_root_241)));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_b_247));
  V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
  V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
  V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_n(v_p_2410, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2413 = (g_std_2epath_2erender(v_st_240, v_t_2412));
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuildTarget(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_246, 1)), heff_rfield(v_p_246, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_n(v_p_246, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_a_249 = (g_std_2epath_2erender(v_st_240, v_t_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, v_f_243));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2412, 1)), heff_rfield(v_p_2412, 2)));
  V v_t_2414 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_n(v_p_2412, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_p_2415 = (g_std_2epath_2erender(v_st_240, v_t_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, v_p_2415));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2418, 1)), heff_rfield(v_p_2418, 2)));
  V v_t_2420 = ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_n(v_p_2418, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_std_2epath_2erender(v_st_240, v_t_2420));
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappFile(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str1, 5, "build");
Clo g_heff_2ebuild_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str1)));
  V v_p_245 = (g_std_2epath_2ejoin_2eonto_240(v_t_243, v_t_244));
  V v_t_246 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_245, 1)), heff_rfield(v_p_245, 2)));
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_n(v_p_245, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_a_248 = (g_std_2epath_2erender(v_st_240, v_t_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_a_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_2411 = (g_std_2epath_2ejoin_2eonto_240(v_t_249, v_t_2410));
  V v_t_2412 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2411, 1)), heff_rfield(v_p_2411, 2)));
  V v_t_2413 = ({ V rv_2 = v_t_2412; V rr_ = heff_rec_reuse_n(v_p_2411, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_p_2414 = (g_std_2epath_2erender(v_st_240, v_t_2413));
  V v_t_2415 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, v_p_2414));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_std_2epath_2erender(v_st_240, v_t_2419));
}
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2epartsDir(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ecommands_2ebuiltAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuiltAt_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ebuiltAt(V v_st_240, V v_t_241, V v_x_242, V v_n_243) {
top: ;
  V v_a_244 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_240, v_t_241, v_x_242));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_a_244));
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, v_n_243));
  V v_p_247 = (g_std_2epath_2ejoin_2eonto_240(v_t_245, v_t_246));
  V v_t_248 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_247, 1)), heff_rfield(v_p_247, 2)));
  V v_t_249 = ({ V rv_2 = v_t_248; V rr_ = heff_rec_reuse_n(v_p_247, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_std_2epath_2erender(v_st_240, v_t_249));
}
V g_heff_2ebuild_2ecommands_2ebuiltAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuiltAt(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str2, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str3, 5, "FAIL ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str6, 12, "\012  expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str7, 12, "\012  but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLine_str8, 12, "\012  diff     ");
Clo g_heff_2ebuild_2ecommands_2efailLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLine_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efailLine(V v_f_240, V v_r_241, V v_m_242) {
top: ;
  V v_t_243 = heff_intShow(heff_take_field(v_r_241, 1));
  V v_t_244 = heff_take_field(v_r_241, 0);
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efailLine_str0);
    break;
  }
  case TAG_Just: {
    V v_n_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str1), heff_strAppend(v_n_245, ((V)&g_heff_2ebuild_2ecommands_2efailLine_str2)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_247 = heff_get_n(heff_get_n(v_r_241, 2, 3), 2, 10);
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str3), heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str4), heff_strAppend(v_t_243, heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str5), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str6), heff_strAppend(heff_dup(heff_rfield(v_m_242, 0)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str7), heff_strAppend(heff_dup(heff_rfield(v_m_242, 1)), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLine_str8), heff_get_n(v_m_242, 2, 3)))))))))))));
}
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efailLine(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str0, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str1, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str3, 1, "%");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str8, 5, " runs");
V g_heff_2ebuild_2ecommands_2estatistic_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_o_240, 3)));
  V v_t_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 4)))) {
    V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
    v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2estatistic_str1)));
  } else {
    v_t_244 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str2);
  }
  V v_x2_2416 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2estatistic_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), heff_get_n(v_o_240, 6, 10)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str7); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  return heff_strAppend(v_t_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str8), heff_strAppend(v_t_244, v_t_2419)));
}
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estatistic(a[0]);
}
V g_heff_2ebuild_2ecommands_2estatistic_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_n_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_y_247 = heff_dup(heff_field(v_p_245, 1));
    v_n_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_total_249 = heff_get_n(v_o_240, 3, 10);
  V v_t_2411;
  if (heff_intEq_c(heff_dup(v_total_249), MK_INT(0LL))) {
    heff_drop(v_n_248);
    heff_drop(v_total_249);
    v_t_2411 = MK_INT(0LL);
  } else {
    v_t_2411 = heff_intDiv(heff_intMul(v_n_248, MK_INT(100LL)), v_total_249);
  }
  V v_t_2412 = heff_strAppend(heff_intShow(v_t_2411), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str3));
  V v_t_2415;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str4), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str5), v_t_2415)));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str0, 8, "  ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str1, 8, "  FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str3, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str6, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str8, 10, "not shrunk");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str9, 11, "shrunk once");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str10, 7, "shrunk ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str11, 6, " times");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str12, 16, "  (failed after ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str13, 10, " runs held");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str14, 2, "; ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str15, 16, "; again: --seed ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeLine_str16, 1, ")");
Clo g_heff_2ebuild_2ecommands_2eoutcomeLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eoutcomeLine_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eoutcomeLine(V v_o_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str0);
    break;
  }
  case TAG_False: {
    v_t_242 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str1);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_243 = heff_dup(heff_rfield(v_o_240, 2));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_2416;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str2);
    break;
  }
  case TAG_False: {
    V v_t_245 = heff_dup(heff_rfield(v_o_240, 1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = (g_heff_2ebuild_2ecommands_2estatistic(heff_dup(v_o_240)));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str3), heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str4)));
      break;
    }
    case TAG_False: {
      V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_o_240, 3)));
      V v_t_2410;
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 4)))) {
        V v_t_249 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
        v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str5), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str6)));
      } else {
        v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str7);
      }
      V v_n_2411 = heff_dup(heff_rfield(v_o_240, 5));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(v_n_2411), MK_INT(0LL))) {
        heff_drop(v_n_2411);
        v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str8);
      } else {
        if (heff_intEq_c(heff_dup(v_n_2411), MK_INT(1LL))) {
          heff_drop(v_n_2411);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str9);
        } else {
          v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str10), heff_strAppend(heff_intShow(v_n_2411), ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str11)));
        }
      }
      V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_o_240, 9)));
      v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str12), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str13), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str14), heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str15), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eoutcomeLine_str16)))))))));
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_strAppend(v_t_242, heff_strAppend(heff_get_n(v_o_240, 0, 10), v_t_2416));
}
V g_heff_2ebuild_2ecommands_2eoutcomeLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eoutcomeLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str0, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str1, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str2, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str3, 17, "        diff     ");
Clo g_heff_2ebuild_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2elsp_2ereport_2emismatch(v_color_240, v_expected_243, v_got_244));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str1), heff_take_field(v_m_245, 0));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str2), heff_take_field(v_m_245, 1));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str3), heff_get_n(v_m_245, 2, 3));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efailLines(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 8, ", tests ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 1, "/");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_xs_244 = (g_list_2efilter_24s1956506708x1796911658(heff_dup(v_os_240)));
    V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_244; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    V v_t_246 = heff_intShow(heff_intSub(v_t_243, v_t_245));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_os_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop_tag(v_os_240, 2); r_; });
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2), heff_intShow(v_t_247))));
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestsSaid(a[0]);
}

static V g_heff_2ebuild_2ecommands_2edefaultSeed_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2edefaultSeed_st;
static V g_heff_2ebuild_2ecommands_2edefaultSeed_init(void) {
  return MK_INT(2026LL);
}
V g_heff_2ebuild_2ecommands_2edefaultSeed_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2edefaultSeed_st)) return g_heff_2ebuild_2ecommands_2edefaultSeed_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2edefaultSeed_val, &g_heff_2ebuild_2ecommands_2edefaultSeed_st, g_heff_2ebuild_2ecommands_2edefaultSeed_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectName_str3, 0, "");
Clo g_heff_2ebuild_2ecommands_2eprojectName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectName_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprojectName(V v_st_240, V v_dir_241, V v_x3_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_dir_241), ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str0))) {
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      V v_t_244 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
      V v_xs_245 = heff_get_n(v_t_244, 2, 3);
      V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
      V v_x2_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_x2_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_x2_249 = heff_tag_n(TAG_Just, 1, (V[]){v_x_247});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str1);
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        return v_x_2410;
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    case TAG_Just: {
      V v_pwd_2411 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      heff_drop(v_dir_241);
      V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_pwd_2411));
      V v_xs_2413 = heff_get_n(v_t_2412, 2, 3);
      V v_x1_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
      V v_x2_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        v_x2_2417 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 2);
        v_x2_2417 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str2);
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        heff_take_n(v_x2_2417, 1ULL, 1);
        return v_x_2418;
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  } else {
    heff_drop(v_x3_242);
    V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_dir_241));
    V v_xs_2420 = heff_get_n(v_t_2419, 2, 3);
    V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    V v_x2_2424;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_x2_2424 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_x2_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ebuild_2ecommands_2eprojectName_str3);
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      return v_x_2425;
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
}
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprojectName(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str0, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str1, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str2, 37, "-- without a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str3, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str4, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str5, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str7, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str8, 33, "main = program (io := here stdio)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str9, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str12, 50, "program : {{io : stdio <: stdio}} -> Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str13, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str15, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str16, 71, "-- build.hf says, and `heff install` into ~/.heff/bin/; run on Node.js,");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprogramText_str17, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprogramText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprogramText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eprogramText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str0), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str1)));
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str2), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str3)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprogramText_str4), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str5)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str6), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str8), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str10), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str12), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str13), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str15), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprogramText_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_249})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprogramText_str17); V a_1 = v_t_241; V a_2 = v_t_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2410, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2eprogramText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprogramText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 71, "-- Node.js program of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Node` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str0, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str1, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str2, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str4, 17, "package : Package");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str5, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str7, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str10, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str12, 6, ".heff/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str13, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str14, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str15, 18, "-- `heff test src/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str16, 14, "/greeting.hf`.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str18, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str19, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str20, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str21, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str23, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str24, 59, "-- checks them all, and this one's doc tests are checked by");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str25, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str26, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str27, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str28, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str29, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str30, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str31, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str32, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str33, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str34, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str35, 75, "  unit \"greeting\" (assertEqual showString (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str37, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str38, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str39, 66, "-- of type `Test` (lib/check.hf), after the watches and doc tests.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str40, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str41, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str42, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprojectFiles_str43, 69, "-- `heff test` runs the tests of every file of test/: the definitions");
Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprojectFiles_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprojectFiles(V v_name_240, V v_v_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str0), heff_strAppend(heff_dup(v_name_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str1), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str2)))));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str3), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_243})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str5), ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str6); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str7); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str8), v_t_244}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; })});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str9), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str10), ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str11); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str12); V a_2 = v_t_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_246, 2); r_; })});
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str13), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str14)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str15), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str16)));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str17), NTAG(TAG_Nil)});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str19), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str21), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str22), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str23), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str24), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str25); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str26); V a_2 = v_t_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2414, 2); r_; })});
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str27), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str28)));
  V v_t_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, (g_heff_2ebuild_2ecommands_2eprogramText(heff_dup(v_name_240)))});
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str29), heff_strAppend(heff_dup(v_name_240), ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str30)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str31), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str32)));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str33), NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str35), v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str36), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str37), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str40), v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str41), ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str42); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eprojectFiles_str43); V a_2 = v_t_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2424, 2); r_; })});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, heff_dup(g_heff_2ebuild_2ecommands_2ebuildText_get())}), v_t_2426});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2427})});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2428})});
}
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprojectFiles(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2erequiring_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erequiring_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erequiring_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erequiring_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erequiring(V v_pk_240, V v_name_241, V v_path_242, V v_v_243) {
top: ;
  V v_t_245 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2ecommands_2erequiring_lam0, 1, 1, (V[]){heff_dup(v_path_242)}), heff_rfield(v_pk_240, 2)));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_name_241);
    v_t_249 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2erequiring_lam1, 1, 2, (V[]){v_path_242, v_v_243}), heff_dup(heff_rfield(v_pk_240, 2))));
    break;
  }
  case TAG_False: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_241, v_path_242, v_v_243}), NTAG(TAG_Nil)});
    v_t_249 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_240, 2)), v_t_248));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return ({ V rv_2 = v_t_249; V rr_ = heff_rec_reuse_n(v_pk_240, 11ULL, 4, shape_module__heff__require__replace); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ebuild_2ecommands_2erequiring_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erequiring(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2erequiring_lam0(V self, V *args) {
  V v_r_244 = args[0];
  V v_path_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_244, 1, 3), v_path_242);
}
V g_heff_2ebuild_2ecommands_2erequiring_lam1(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_r_246, 1)), heff_dup(v_path_242))) {
    return ({ V rv_1 = v_path_242; V rv_2 = v_v_243; V rr_ = heff_rec_reuse_n(v_r_246, 1ULL, 3, shape_name__path__version); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  } else {
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    return v_r_246;
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2419 = (g_heff_2ebuild_2ecommands_2eownRoot(v_x_2413, v_x_2418));
  V v_t_2420 = (g_std_2epath_2eparse(v_x_2413, v_a_2419));
  V v_t_2421 = (g_std_2epath_2eparse(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str2)));
  V v_p_2422 = (g_std_2epath_2ejoin_2eonto_240(v_t_2420, v_t_2421));
  V v_t_2423 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2422, 1)), heff_rfield(v_p_2422, 2)));
  V v_t_2424 = ({ V rv_2 = v_t_2423; V rr_ = heff_rec_reuse_n(v_p_2422, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2425 = ({ V a_0 = v_x_2413; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2413); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_str1))) {
    v_x_2413 = NTAG(TAG_Windows);
  } else {
    v_x_2413 = NTAG(TAG_Posix);
  }
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam4_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam5, 1, 2, (V[]){v_x_2413, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam2_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2426 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2(V self, V *args) {
  V v_v_247 = args[0];
  return v_v_247;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2423;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str3))) {
    v_x_2423 = NTAG(TAG_Windows);
  } else {
    v_x_2423 = NTAG(TAG_Posix);
  }
  V v_x_2446;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_d_2425;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      v_d_2425 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str4);
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_x_2416, 0);
      heff_take_n(v_x_2416, 1ULL, 1);
      v_d_2425 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    V v_a_2427;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      v_a_2427 = v_d_2425;
      break;
    }
    case TAG_Just: {
      V v_x_2426 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop(v_d_2425);
      v_a_2427 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_2428 = (g_std_2epath_2eparse(v_x_2423, v_a_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_x_2423, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str5)));
    V v_p_2430 = (g_std_2epath_2ejoin_2eonto_240(v_t_2428, v_t_2429));
    V v_t_2431 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2430, 1)), heff_rfield(v_p_2430, 2)));
    V v_t_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_n(v_p_2430, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_a_2433 = (g_std_2epath_2erender(v_x_2423, v_t_2432));
    V v_t_2434 = (g_std_2epath_2eparse(v_x_2423, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str6)));
    V v_t_2435 = (g_std_2epath_2eparse(v_x_2423, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str7)));
    V v_p_2436 = (g_std_2epath_2ejoin_2eonto_240(v_t_2434, v_t_2435));
    V v_t_2437 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2436, 1)), heff_rfield(v_p_2436, 2)));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_n(v_p_2436, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_b_2439 = (g_std_2epath_2erender(v_x_2423, v_t_2438));
    V v_t_2440 = (g_std_2epath_2eparse(v_x_2423, v_a_2433));
    V v_t_2441 = (g_std_2epath_2eparse(v_x_2423, v_b_2439));
    V v_p_2442 = (g_std_2epath_2ejoin_2eonto_240(v_t_2440, v_t_2441));
    V v_t_2443 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2442, 1)), heff_rfield(v_p_2442, 2)));
    V v_t_2444 = ({ V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_n(v_p_2442, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_x_2446 = ({ V a_0 = v_x_2423; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2423); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2445 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_x_2416);
    heff_drop(v_x_2411);
    heff_drop(v_x_2423);
    v_x_2446 = v_d_2445;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V f_ = v_k_241;
  args[0] = v_x_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam6_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam7, 1, 4, (V[]){v_x_246, v_x_2416, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam4_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam5, 1, 4, (V[]){v_hd_240, v_x_246, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334_lam3, 1, 3, (V[]){v_hd_240, v_x_246, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2(V self, V *args) {
  V v_v_247 = args[0];
  return v_v_247;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2423;
  if (heff_strEq_c(v_x_2421, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str3))) {
    v_x_2423 = NTAG(TAG_Windows);
  } else {
    v_x_2423 = NTAG(TAG_Posix);
  }
  V v_x_2434;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    V v_d_2425;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      v_d_2425 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str4);
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_x_2416, 0);
      heff_take_n(v_x_2416, 1ULL, 1);
      v_d_2425 = v_x_2424;
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    V v_a_2427;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      v_a_2427 = v_d_2425;
      break;
    }
    case TAG_Just: {
      V v_x_2426 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop(v_d_2425);
      v_a_2427 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    V v_t_2428 = (g_std_2epath_2eparse(v_x_2423, v_a_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_x_2423, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str5)));
    V v_p_2430 = (g_std_2epath_2ejoin_2eonto_240(v_t_2428, v_t_2429));
    V v_t_2431 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2430, 1)), heff_rfield(v_p_2430, 2)));
    V v_t_2432 = ({ V rv_2 = v_t_2431; V rr_ = heff_rec_reuse_n(v_p_2430, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_x_2434 = ({ V a_0 = v_x_2423; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2423); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2433 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    heff_drop(v_x_2416);
    heff_drop(v_x_2411);
    heff_drop(v_x_2423);
    v_x_2434 = v_d_2433;
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V f_ = v_k_241;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam6_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam7, 1, 4, (V[]){v_x_246, v_x_2416, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam4_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam5, 1, 4, (V[]){v_hd_240, v_x_246, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_lam3, 1, 3, (V[]){v_hd_240, v_x_246, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11(V self, V *args) {
  V v_t_2440 = args[0];
  return v_t_2440;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam12(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2445 = (g_heff_2ebuild_2ecommands_2eownRoot(v_x_2415, v_x_2420));
  V v_t_2446 = ({ V a_0 = v_x_2433; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2433); r_; });
  V v_t_2447 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2444); r_; });
  V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, (g_prelude_2e_2b_2b(v_t_2446, v_t_2447))});
  V v_x_2449 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_248, v_x_2415, v_t_2448});
  V f_ = v_k_241;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam10(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_248 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2434 = (g_std_2epath_2eparse(v_x_2415, v_x_2421));
  V v_t_2435 = (g_std_2epath_2eparse(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str2)));
  V v_p_2436 = (g_std_2epath_2ejoin_2eonto_240(v_t_2434, v_t_2435));
  V v_t_2437 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2436, 1)), heff_rfield(v_p_2436, 2)));
  V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_n(v_p_2436, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2439 = (g_std_2epath_2erender(v_x_2415, v_t_2438));
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2439, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam11_clo)})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s954557541x749476273(v_t_2443, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam12, 1, 7, (V[]){v_x_2415, v_x_2420, v_x_2433, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2422 = (g_heff_2ebuild_2ecommands_2eownRoot(v_x_2415, heff_dup(v_x_2420)));
  V v_t_2423 = (g_std_2epath_2eparse(v_x_2415, v_home_2422));
  V v_t_2424 = (g_std_2epath_2eparse(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str1)));
  V v_p_2425 = (g_std_2epath_2ejoin_2eonto_240(v_t_2423, v_t_2424));
  V v_t_2426 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2425, 1)), heff_rfield(v_p_2425, 2)));
  V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_n(v_p_2425, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2428 = (g_std_2epath_2erender(v_x_2415, v_t_2427));
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2428, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam9_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s954557541x749476273(v_t_2432, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam10, 1, 8, (V[]){v_x_2415, v_x_2421, v_hd_240, v_x_2420, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam8, 1, 7, (V[]){v_x_2415, v_x_2420, v_hd_240, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2415;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_str0))) {
    v_x_2415 = NTAG(TAG_Windows);
  } else {
    v_x_2415 = NTAG(TAG_Posix);
  }
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam6_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam7, 1, 6, (V[]){v_hd_240, v_x_2415, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam4_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam5, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam2_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam3, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s229520698x1531964334(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = (g_heff_2ebuild_2ecommands_2eownRoot(v_x_248, v_x_2413));
  V v_t_2415 = (g_std_2epath_2eparse(v_x_248, v_a_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str1)));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2420 = ({ V a_0 = v_x_248; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248;
  if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str0))) {
    v_x_248 = NTAG(TAG_Windows);
  } else {
    v_x_248 = NTAG(TAG_Posix);
  }
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam3, 1, 2, (V[]){v_x_248, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_x1_2414 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_2413));
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Left: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Just, 1);
      v_x_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      V v_t_2417 = ({ V a_0 = v_x_2416; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2416); r_; });
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Left: {
        heff_take_n(v_t_2417, 0ULL, 1);
        heff_drop_cell(v_ru_24x_2412_24Just, 1);
        v_x_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Right: {
        V v_p_2419 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        v_x_2420 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2419, 1, 4)});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2421 = ({ V a_0 = v_x_2420; V a_1 = heff_dup(heff_rfield(v_x_246, 4)); V r_ = (g_heff_2ebuild_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2420); r_; });
  V v_x_2422 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_2421));
  V f_ = v_k_243;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_247, ((V)&g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam4_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam5, 1, 2, (V[]){v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam3, 1, 3, (V[]){v_hd_242, v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s697254742x1340380291(v_x_244, v_file_240));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str0), v_l_245));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_lam0, 1, 5, (V[]){v_m_240, v_rest_246, v_n_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2412);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(v_m_240, v_rest_246, heff_intAdd(v_n_242, MK_INT(1LL)), v_p_243, v_p_244));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str1, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1, 1, 4, (V[]){v_c_243, v_p_241, v_rest_244, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3(V self, V *args) {
  V v_d_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_x_248; V a_1 = heff_dup(heff_rfield(v_c_243, 1)); V a_2 = heff_get_n(v_c_243, 3, 13); V a_3 = v_d_2414; V r_ = (g_heff_2elsp_2erender_2efileDiag(a_0, a_1, a_2, a_3)); heff_drop(v_x_248); r_; });
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_dup(heff_rfield(v_c_243, 6));
  V v_c_2423;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nil: {
    heff_drop(v_x_248);
    heff_drop_rec(v_c_243, 13);
    v_c_2423 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam2_clo);
    break;
  }
  case TAG_Cons: {
    V v_ru_24t_249_24Cons = heff_take_reuse_n(v_t_249, 0ULL, 2);
    V v_x2_2415 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam3, 1, 2, (V[]){v_x_248, heff_dup(v_c_243)}), heff_get_n(v_c_243, 6, 13)));
    V v_str_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_str_2418 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_str_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_tag_at_n(v_ru_24t_249_24Cons, TAG_WriteErr, 2, (V[]){v_str_2418, NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    v_c_2423 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2422}));
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_p_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_lam4, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badLoad_240)})));
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2416);
  switch (heff_tag_of(v_badLoad_240)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, v_hd_242, v_k_243));
  }
  case TAG_False: {
    V v_t_2421 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s976871491x582277361(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      return (g_co_2eop_24s954557541x749476273(v_t_2425, v_hd_242, v_k_243));
    }
    case TAG_False: {
      heff_drop(v_hd_242);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_badLoad_240);
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badLoad_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badLoad_240);
    V v_t_246 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2410 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_str_2411 = (g_heff_2ebuild_2edriver_2einterface(v_c_2410));
    V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s786196944x2120953123_lam1, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})));
  }
  default: return heff_nomatch(v_t_245);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_2410;
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str0))) {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
    } else {
      v_t_2410 = v_path_245;
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_str1));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1, 2, 2, (V[]){v_path_2411, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_x_2420 = heff_tag_at_n(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2419})});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_lam3, 1, 2, (V[]){v_m_241, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(v_sources_240, v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_x_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(a_0, a_1)); heff_drop(v_sources_240); r_; });
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str0), v_e_243), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_str1));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_WriteErr, 2, (V[]){v_t_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(v_rest_244, v_p_241, v_p_242));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_True: {
    heff_drop(v_outPath_240);
    V f_ = v_done_241;
    heff_room[0] = v_hd_243;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    heff_drop(v_done_241);
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str1));
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_take_field(v_o_242, 1);
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    V v_t_2411 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_outPath_240), heff_get_n(v_o_242, 0, 2), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})));
  }
  case TAG_False: {
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_t_249);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str5, 1, ".");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(V v_host_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(heff_rfield(v_c_245, 7))));
  V v_t_2414 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2413));
  V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
  V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam1, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2416));
  V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; V r_ = (g_heff_2ebuild_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Left: {
    V v_why_2420 = heff_field(v_t_2419, 0);
    V v_ru_24t_2419_24Left = heff_take_reuse_n(v_t_2419, 1ULL, 1);
    heff_drop(v_host_240);
    heff_drop(v_outPath_243);
    heff_drop(v_done_244);
    heff_drop_rec(v_c_245, 13);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str0), heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str1), v_why_2420)));
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str2)), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_at_n(v_ru_24t_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s954557541x749476273(v_t_2425, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
  }
  case TAG_Right: {
    V v_r_2431 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    heff_drop(v_file_241);
    V v_key_2432 = heff_take_field(v_r_2431, 0);
    V v_eff_2433 = heff_get_n(v_r_2431, 1, 2);
    V v_t_2434 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2433));
    V v_xs_2435 = (g_list_2emap_24s1052938345x548264065(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str3), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str4), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_str5), v_t_2434));
    V v_t_2436 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_2435));
    V v_t_2437 = (g_heff_2ecompile_2eemit_2eprovsForGo(v_available_246, v_t_2436));
    V v_t_2438 = heff_get_n(heff_get_n(v_c_245, 5, 13), 0, 9);
    V v_t_2439 = (g_heff_2ecompile_2elower_2elowerProgram(v_t_2438, heff_dup(v_key_2432)));
    V v_t_2440 = ({ V a_0 = v_host_240; V a_1 = v_t_2437; V a_2 = v_eff_2433; V a_3 = v_key_2432; V a_4 = v_t_2439; V r_ = (g_heff_2ecompile_2eemit_2ecompileLowered(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_2432); r_; });
    return (g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(v_outPath_243, v_done_244, v_t_2440, v_z_247, v_z_248));
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam0(V self, V *args) {
  V v_o_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_245, heff_dup(heff_rfield(v_o_249, 1))));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_249, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2411 = heff_field(v_t_2410, 0);
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 1ULL, 1);
    V v_t_2412 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_249, 0), heff_get_n(v_o_249, 1, 2), v_eff_2411});
    return heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam1(V self, V *args) {
  V v_k_2417 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2417; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str0, 15, "no files given\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str4, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_246));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str0), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam0, 1, 2, (V[]){v_z_247, v_z_248})));
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam1, 1, 1, (V[]){heff_dup(v_c_2419)}), heff_dup(heff_rfield(v_c_2419, 7))));
    V v_t_2425 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2424));
    V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2426));
    V v_xs_2428 = (g_list_2emap_24s1052938345x548264065(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str3), v_t_2427));
    V v_t_2429 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2428));
    V v_c_2430 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(v_sources_240, v_t_2429));
    return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam2, 1, 8, (V[]){v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245, v_c_2419, v_z_247, v_z_248})});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(a0, a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a0); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam1(V self, V *args) {
  V v_o_2420 = args[0];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_2419, heff_dup(heff_rfield(v_o_2420, 1))));
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_2420, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2422 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    V v_t_2423 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2420, 0), heff_get_n(v_o_2420, 1, 2), v_eff_2422});
    return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam3(V self, V *args) {
  V v_p_2432 = args[0];
  V v_host_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_str4), heff_get_n(v_p_2432, 1, 2), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2434 = (g_list_2emap_24s649333309x1802289391(v_t_2433));
  V v_x1_2435 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2434));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Nil: {
    heff_drop(v_host_241);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 2);
    return heff_strEq(v_x_2436, v_host_241);
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_host_241 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_done_245 = heff_env(self)[4];
  V v_c_2419 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  V v_z_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2438 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634_lam3, 1, 1, (V[]){heff_dup(v_host_241)}), v_x_2431));
  return ({ V a_0 = v_host_241; V a_1 = v_file_242; V a_2 = v_name_243; V a_3 = v_outPath_244; V a_4 = v_done_245; V a_5 = v_c_2419; V a_6 = v_t_2438; V a_7 = v_z_247; V a_8 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileFound_24s742758975x1671711064(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2438); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(V v_sources_240, V v_host_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_badL_246, V v_cs_247, V v_hd_248, V v_k_249) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_247), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam0, 1, 10, (V[]){heff_dup(v_badL_246), v_hd_248, v_k_249, v_cs_247, heff_dup(v_sources_240), v_host_241, v_file_242, v_name_243, v_outPath_244, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(a0, a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a0); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_badL_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_cs_247 = heff_env(self)[3];
  V v_sources_240 = heff_env(self)[4];
  V v_host_241 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2410);
  switch (heff_tag_of(v_badL_246)) {
  case TAG_True: {
    heff_drop(v_cs_247);
    heff_drop(v_sources_240);
    heff_drop(v_host_241);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_248, v_k_249));
  }
  case TAG_False: {
    V v_t_2415 = (g_list_2eany_24s976871491x582277361(v_cs_247));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      heff_drop(v_cs_247);
      heff_drop(v_sources_240);
      heff_drop(v_host_241);
      heff_drop(v_file_242);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s954557541x749476273(v_t_2419, v_hd_248, v_k_249));
    }
    case TAG_False: {
      return ({ V a_0 = v_sources_240; V a_1 = v_host_241; V a_2 = v_file_242; V a_3 = v_name_243; V a_4 = v_outPath_244; V a_5 = v_done_245; V a_6 = v_cs_247; V a_7 = v_hd_248; V a_8 = v_k_249; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s1696255340x1570579634(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_sources_240); heff_drop(v_cs_247); r_; });
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_badL_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str1, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str2, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str3, 4, "main");
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525(V v_file_240, V v_progArgs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_progArgs_241});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam4(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2414);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2erunPath(heff_dup(heff_rfield(v_x_245, 2)), heff_dup(v_file_240)));
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2erunPath(heff_take_field(v_x_245, 2), heff_dup(v_file_240)));
  V v_as_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_progArgs_241});
  V v_t_2418 = heff_tag_n(TAG_Exec, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str1), v_as_2417, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2421}));
  return ({ V b_0 = heff_get_n(v_x_245, 0, 5); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str2); V a_2 = v_file_240; V a_3 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str3)}); V a_4 = v_t_2415; V a_5 = v_t_2422; V b_6 = heff_intLt(MK_INT(0LL), v_x_246); V a_7 = heff_get_n(v_x_248, 0, 2); V a_8 = v_hd_243; V a_9 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_249 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_245, 2))));
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_249, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam4_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam5, 1, 7, (V[]){v_x_245, v_file_240, v_progArgs_241, v_x_246, v_x_248, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_245)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam3, 1, 6, (V[]){v_x_245, v_hd_243, v_file_240, v_progArgs_241, v_x_246, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_file_240, v_progArgs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s203206330x903252525_lam1, 1, 4, (V[]){v_hd_243, v_file_240, v_progArgs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam1, 2, 4, (V[]){v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8(V self, V *args) {
  V v_n_2435 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = (g_std_2epath_2eparse(v_x_2422, v_p_248));
  V v_t_2437 = (g_std_2epath_2eparse(v_x_2422, v_n_2435));
  V v_p_2438 = (g_std_2epath_2ejoin_2eonto_240(v_t_2436, v_t_2437));
  V v_t_2439 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2438, 1)), heff_rfield(v_p_2438, 2)));
  V v_t_2440 = ({ V rv_2 = v_t_2439; V rr_ = heff_rec_reuse_n(v_p_2438, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), ({ V a_0 = v_x_2422; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2422); r_; })});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_ns_2428 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_True: {
    heff_drop(v_ns_2428);
    heff_drop(v_x_2422);
    heff_drop(v_p_248);
    V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_rest_246, v_acc_241));
    V f_ = v_t_2433;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_t_2434 = (g_list_2efilter_24s413688307x112671032(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str2), v_ns_2428));
    V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam8, 1, 2, (V[]){v_x_2422, v_p_248}), v_t_2434));
    V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2441, v_rest_246));
    V v_t_2443 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_t_2442, v_acc_241));
    V f_ = v_t_2443;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2422;
  if (heff_strEq_c(v_x_2420, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str0))) {
    v_x_2422 = NTAG(TAG_Windows);
  } else {
    v_x_2422 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    heff_drop(v_top_247);
    heff_drop(v_x_2422);
    V v_t_2423 = heff_intSub(heff_strLength(heff_dup(v_p_248)), MK_INT(3LL));
    V v_t_2424 = heff_strSlice(heff_dup(v_p_248), v_t_2423, heff_strLength(heff_dup(v_p_248)));
    if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_str1))) {
      V v_t_2426 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      V f_ = v_t_2426;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_248);
      V v_t_2427 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_rest_246, v_acc_241));
      V f_ = v_t_2427;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2428 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_c_2431;
    switch (heff_tag_of(v_top_247)) {
    case TAG_True: {
      v_c_2431 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam6_clo);
      break;
    }
    case TAG_False: {
      v_c_2431 = (g_heff_2ebuild_2eload_2eisRoot_24s872661079x4596019(v_x_2422, heff_dup(v_p_248)));
      break;
    }
    default: heff_nomatch(v_top_247);
    }
    V f_ = v_c_2431;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam7, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_ns_2428, v_x_2422, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam4_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam5, 1, 7, (V[]){v_x_2415, v_p_248, v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_top_247})));
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_top_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_p_248), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875_lam3, 1, 6, (V[]){v_hd_249, v_p_248, v_rest_246, v_acc_241, v_k_2410, v_top_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str0, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str1, 68, "heff test: no test/ here: test at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str2, 4, "test");
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0, 2, 0};
Clo g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2424 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_t_2424, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410(a[0]);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2417);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam4, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str1), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam3, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str2)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1834071921x1909708875(v_t_2420, NTAG(TAG_Nil)));
    V f_ = v_t_2421;
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_str0), ((V)&g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFiles_24s66007116x1217604410_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_list_2emap_24s1431621018x139529971(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_str0), heff_dup(heff_rfield(v_c_243, 6))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam1, 2, 3, (V[]){heff_dup(v_c_243), v_t_245, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2411 = (g_list_2efilter_24s835571418x868029304(heff_get_n(v_c_243, 6, 13)));
  V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2411; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
  V v_x_2413 = heff_intAdd(v_t_2412, v_x_2410);
  V f_ = v_k_247;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_c_249 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam3, 1, 2, (V[]){v_c_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(heff_dup(heff_rfield(v_c_243, 0)), v_t_245, MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam2, 1, 4, (V[]){v_rest_244, v_hd_246, v_c_243, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = (g_heff_2elsp_2ereport_2emismatch(v_color_241, v_t_249, v_t_2410));
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_color_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2419);
  V v_t_2420 = ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(a_0, a_1, a_2)); heff_drop(v_color_241); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420_lam2, 1, 5, (V[]){v_f_240, v_color_241, v_rest_246, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str1, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str4, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_str_246 = (g_heff_2ebuild_2ecommands_2eoutcomeLine(heff_dup(v_o_244)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam1, 2, 4, (V[]){v_str_246, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_t_2431 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(a_0, a_1)); heff_drop(v_color_240); r_; });
  V f_ = v_t_2431;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_take_field(v_o_244, 1);
  V v_c_2429;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop_rec(v_o_244, 10);
    v_c_2429 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3_clo);
    break;
  }
  case TAG_False: {
    V v_t_2417 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str1), heff_take_field(v_o_244, 7)));
    V v_t_2418 = heff_get_n(v_o_244, 8, 10);
    V v_t_2420;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2420 = (g_heff_2ebuild_2ecommands_2efailLines(v_color_240, v_f_2419));
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_x2_2421 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
    V v_str_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_str_2424 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_str_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2424, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str4)), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    v_c_2429 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2428}));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam4, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_str_246 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str0)), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam2, 1, 5, (V[]){v_o_244, v_color_240, v_hd_247, v_rest_245, v_k_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str1, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str2, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str4, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str5, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(V v_f_240, V v_bad_241, V v_ts_242, V v_os_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_UseColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam1, 1, 6, (V[]){v_ts_242, v_f_240, v_hd_244, v_os_243, v_bad_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_xs_2435 = (g_list_2efilter_24s34002769x154977349(v_ts_242));
  V v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2435; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
  V v_t_2437 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_os_243));
  V v_xs_2438 = (g_list_2efilter_24s1956506708x1796911658(v_os_243));
  V v_t_2439 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2438; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
  V v_x_2440 = heff_rec_n(5, shape_total__failed__ok__tests__testsFailed, (V[]){v_t_2434, v_t_2436, heff_intEq(v_bad_241, MK_INT(0LL)), v_t_2437, v_t_2439});
  V f_ = v_k_245;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_f_240 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  V v_x1_2415 = (g_list_2efilter_24s34002769x154977349(heff_dup(v_ts_242)));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nil: {
    V v_x1_2416 = (g_list_2efilter_24s1956506708x1796911658(heff_dup(v_os_243)));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_Nil: {
      if (heff_intEq_c(heff_dup(v_bad_241), MK_INT(0LL))) {
        v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str0);
      } else {
        v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str1);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2416, 0ULL, 2);
      v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str2);
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_2415, 0ULL, 2);
    v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str3);
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_xs_2424 = (g_list_2efilter_24s34002769x154977349(heff_dup(v_ts_242)));
  V v_t_2425 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2424; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
  V v_t_2426 = heff_intShow(heff_intSub(v_t_2423, v_t_2425));
  V v_t_2427 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ts_242));
  V v_str_2428 = heff_strAppend(v_t_2422, heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str4), heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str5), heff_strAppend(heff_intShow(v_t_2427), (g_heff_2ebuild_2ecommands_2etestsSaid(heff_dup(v_os_243)))))))));
  V v_t_2429 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2428, ((V)&g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_str6)), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s954557541x749476273(v_t_2432, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam4, 1, 4, (V[]){v_ts_242, v_os_243, v_bad_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_os_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_ts_242 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  V v_f_240 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_c_2413 = ({ V a_0 = v_x_249; V a_1 = heff_dup(v_os_243); V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam3, 1, 6, (V[]){v_ts_242, v_os_243, v_bad_241, v_f_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ts_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_os_243 = heff_env(self)[3];
  V v_bad_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2410 = (g_list_2efilter_24s34002769x154977349(heff_dup(v_ts_242)));
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eprintFails_24s1050584742x413922420(heff_dup(v_f_240), v_x_249, v_t_2410));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508_lam2, 1, 7, (V[]){v_x_249, v_os_243, v_hd_244, v_ts_242, v_bad_241, v_f_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str0, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str1, 5, "  0/0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V v_seed_240, V v_f_241, V v_bad0_242, V v_cs_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = (g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(v_cs_243));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0, 1, 6, (V[]){heff_dup(v_cs_243), v_f_241, v_z_244, v_z_245, v_bad0_242, v_seed_240})});
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_rec_n(5, shape_total__failed__ok__tests__testsFailed, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL)});
  V f_ = v_z_245;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2(V self, V *args) {
  V v_w_2419 = args[0];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2etestReportOf(v_c_2416, v_w_2419));
}
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_bad0_242 = heff_env(self)[4];
  V v_seed_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = ({ V a_0 = v_cs_243; V r_ = (g_heff_2ebuild_2edriver_2elastChecked(a_0)); heff_drop(v_cs_243); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_247);
    heff_drop(v_bad0_242);
    heff_drop(v_seed_240);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str0), heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str1)));
    V v_t_2410 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_str2)), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam1, 1, 1, (V[]){v_z_245})));
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_c_2416, 5)), 4, 9);
    V v_t_2418 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2416), v_t_2417));
    V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_lam2, 1, 1, (V[]){heff_dup(v_c_2416)}), v_t_2418));
    V v_t_2421 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2420));
    V v_t_2423;
    if (heff_intLt_c(MK_INT(0LL), heff_intAdd(heff_dup(v_bad0_242), heff_dup(v_x_247)))) {
      heff_drop(v_seed_240);
      heff_drop_rec(v_c_2416, 13);
      v_t_2423 = NTAG(TAG_Nil);
    } else {
      v_t_2423 = (g_heff_2ebuild_2edriver_2erunTests(v_seed_240, v_c_2416));
    }
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1798110817x311962508(v_f_241, heff_intAdd(v_bad0_242, v_x_247), v_t_2421, v_t_2423, v_z_244, v_z_245));
  }
  default: return heff_nomatch(v_t_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str3, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str5, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str7, 4, "heff");
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(V v_tk_240, V v_seed_241, V v_x3_242, V v_acc_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seed_241);
    V v_t_246 = heff_tag_n(TAG_End, 2, (V[]){v_tk_240, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_246}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam0, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})));
  }
  case TAG_Cons: {
    V v_f_2435 = heff_field(v_x3_242, 0);
    V v_rest_2436 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_tk_240), heff_dup(v_f_2435), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2438, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam3, 1, 7, (V[]){v_f_2435, v_p_244, v_seed_241, v_acc_243, v_tk_240, v_rest_2436, v_p_245})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_243, 1)))) {
    heff_drop_rec(v_acc_243, 5);
    V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s954557541x749476273(v_t_2424, v_p_244, v_p_245));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_243, 4)))) {
      heff_drop_rec(v_acc_243, 5);
      V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      return (g_co_2eop_24s954557541x749476273(v_t_2429, v_p_244, v_p_245));
    } else {
      V v_t_2430 = heff_get_n(v_acc_243, 2, 5);
      switch (heff_tag_of(v_t_2430)) {
      case TAG_True: {
        heff_drop(v_p_244);
        V f_ = v_p_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
        V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        return (g_co_2eop_24s954557541x749476273(v_t_2434, v_p_244, v_p_245));
      }
      default: return heff_nomatch(v_t_2430);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_247);
  V v_t_248 = heff_intSub(heff_dup(heff_rfield(v_acc_243, 0)), heff_dup(heff_rfield(v_acc_243, 1)));
  V v_t_249 = heff_intShow(heff_dup(heff_rfield(v_acc_243, 0)));
  V v_tests_2410 = heff_dup(heff_rfield(v_acc_243, 3));
  V v_t_2413;
  if (heff_intEq_c(heff_dup(v_tests_2410), MK_INT(0LL))) {
    heff_drop(v_tests_2410);
    v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str0);
  } else {
    V v_t_2412 = heff_intSub(heff_dup(v_tests_2410), heff_dup(heff_rfield(v_acc_243, 4)));
    v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str1), heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str2), heff_strAppend(heff_intShow(v_tests_2410), ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str3)))));
  }
  V v_str_2414 = heff_strAppend(heff_intShow(v_t_248), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str4), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str5), v_t_2413))));
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2414, ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str6)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2(V self, V *args) {
  V v_t_2437 = args[0];
  return v_t_2437;
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_x_2445 = heff_env(self)[1];
  V v_tk_240 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_rest_2436 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_intAdd(heff_take_field(v_acc_243, 0), heff_take_field(v_x_2445, 0));
  V v_t_2449 = heff_intAdd(heff_take_field(v_acc_243, 1), heff_take_field(v_x_2445, 1));
  V v_t_2450 = heff_take_field(v_acc_243, 2);
  V v_t_2451;
  switch (heff_tag_of(v_t_2450)) {
  case TAG_True: {
    v_t_2451 = heff_dup(heff_rfield(v_x_2445, 2));
    break;
  }
  case TAG_False: {
    v_t_2451 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2450);
  }
  V v_t_2452 = heff_intAdd(heff_take_field(v_acc_243, 3), heff_take_field(v_x_2445, 3));
  V v_t_2453 = heff_intAdd(heff_get_n(v_acc_243, 4, 5), heff_get_n(v_x_2445, 4, 5));
  return (g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(v_tk_240, v_seed_241, v_rest_2436, heff_rec_n(5, shape_total__failed__ok__tests__testsFailed, (V[]){v_t_2448, v_t_2449, v_t_2451, v_t_2452, v_t_2453}), v_p_244, v_p_245));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_tk_240 = heff_env(self)[3];
  V v_seed_241 = heff_env(self)[4];
  V v_rest_2436 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2446 = heff_tag_n(TAG_End, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2446}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam8, 1, 7, (V[]){v_acc_243, v_x_2445, v_tk_240, v_seed_241, v_rest_2436, v_p_244, v_p_245})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_f_2435 = heff_env(self)[1];
  V v_x_2442 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  V v_tk_240 = heff_env(self)[6];
  V v_rest_2436 = heff_env(self)[7];
  V v_p_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return ({ V a_0 = heff_dup(v_seed_241); V a_1 = v_f_2435; V a_2 = v_x_2442; V b_3 = heff_get_n(v_x_2444, 0, 2); V a_4 = heff_dup(v_p_244); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam7, 1, 7, (V[]){v_x_2439, v_p_244, v_acc_243, v_tk_240, v_seed_241, v_rest_2436, v_p_245}); V r_ = (g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_f_2435 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  V v_tk_240 = heff_env(self)[6];
  V v_rest_2436 = heff_env(self)[7];
  V v_p_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2443 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_2441));
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6, 1, 9, (V[]){v_seed_241, v_f_2435, v_x_2442, v_p_244, v_x_2439, v_acc_243, v_tk_240, v_rest_2436, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_seed_241 = heff_env(self)[1];
  V v_f_2435 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_tk_240 = heff_env(self)[5];
  V v_rest_2436 = heff_env(self)[6];
  V v_p_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str7), heff_dup(heff_rfield(v_x_2441, 1)), MK_INT(0LL), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam5, 1, 9, (V[]){v_x_2441, v_p_244, v_seed_241, v_f_2435, v_x_2439, v_acc_243, v_tk_240, v_rest_2436, v_p_245})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam3(V self, V *args) {
  V v_x_2439 = args[0];
  V v_f_2435 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_seed_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_tk_240 = heff_env(self)[4];
  V v_rest_2436 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2440 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_2435)));
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam4, 1, 8, (V[]){v_p_244, v_seed_241, v_f_2435, v_x_2439, v_acc_243, v_tk_240, v_rest_2436, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam0, 1, 5, (V[]){v_cs_242, v_hd_243, v_k_244, heff_dup(v_badL_241), v_file_240})));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_True: {
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s954557541x749476273(v_t_2429, v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_badL_241 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_242));
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_cs_242);
    heff_drop(v_badL_241);
    heff_drop(v_file_240);
    V v_t_247 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(v_t_2410, v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_c_2411 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_badL_241)) {
    case TAG_True: {
      heff_drop(v_cs_242);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2412 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s976871491x582277361(a_0)); heff_drop(v_cs_242); r_; });
      break;
    }
    default: heff_nomatch(v_badL_241);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_file_240);
      heff_drop_rec(v_c_2411, 13);
      V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_243, v_k_244));
    }
    case TAG_False: {
      V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_c_2411, 5)), 4, 9);
      V v_t_2418 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2411), v_t_2417));
      V v_t_2419 = (g_list_2esortBy_24s851943868x104872707(v_t_2418));
      V v_str_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str1); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_str2); V a_3 = MK_INT(0LL); V a_4 = heff_get_n(v_c_2411, 3, 13); V a_5 = v_t_2419; V r_ = (g_list_2efoldl_24s682444417x1397580212(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2419); r_; });
      V v_t_2422 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_file_240, v_str_2420, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam1_clo)})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509_lam2, 1, 2, (V[]){v_k_244, v_hd_243})));
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321(a[0]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_file_240; V b_1 = heff_intLt(MK_INT(0LL), v_x_245); V a_2 = heff_get_n(v_x_247, 0, 2); V a_3 = v_hd_242; V a_4 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s1850089850x1567480509(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam3, 1, 4, (V[]){v_file_240, v_x_245, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam2, 1, 4, (V[]){v_x_244, v_hd_242, v_file_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s89101876x1956214321_lam1, 1, 3, (V[]){v_hd_242, v_file_240, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(V v_host_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam0, 2, 6, (V[]){v_c_245, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_x_249 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return ({ V b_0 = heff_get_n(v_x_248, 0, 5); V a_1 = v_host_240; V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V b_6 = heff_intLt(MK_INT(0LL), v_x_249); V a_7 = heff_get_n(v_x_2411, 0, 2); V a_8 = v_hd_246; V a_9 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s1223219258x1561971207(b_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(b_0); heff_drop(b_6); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_248)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam3, 1, 9, (V[]){v_x_248, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_x_249, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_str0), heff_dup(heff_rfield(v_x_248, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam2, 1, 8, (V[]){v_x_248, v_hd_246, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409_lam1, 1, 7, (V[]){v_hd_246, v_host_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_dup(heff_rfield(v_o_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_o_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  switch (heff_tag_of(v_x_249)) {
  case TAG_True: {
    switch (heff_tag_of(v_bad_241)) {
    case TAG_True: {
      heff_drop_rec(v_o_242, 2);
      V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_243, v_k_244));
    }
    case TAG_False: {
      V v_t_2415 = heff_get_n(v_o_242, 1, 2);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2415_24Cons = heff_take_reuse_n(v_t_2415, 0ULL, 2);
        V v_t_2418 = heff_tag_at_n(v_ru_24t_2415_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        return (g_co_2eop_24s954557541x749476273(v_t_2421, v_hd_243, v_k_244));
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_bad_241);
    }
  }
  case TAG_False: {
    heff_drop(v_bad_241);
    heff_drop_rec(v_o_242, 2);
    V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s954557541x749476273(v_t_2425, v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam2, 1, 5, (V[]){v_x_249, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0, 1, 5, (V[]){v_cs_243, v_hd_244, v_k_245, heff_dup(v_badL_242), v_outPath_241})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(a0, a[1], a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_badL_242 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_243));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_cs_243);
    heff_drop(v_badL_242);
    heff_drop(v_outPath_241);
    V v_t_248 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_c_2412 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_badL_242)) {
    case TAG_True: {
      heff_drop(v_cs_243);
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2413 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s976871491x582277361(a_0)); heff_drop(v_cs_243); r_; });
      break;
    }
    default: heff_nomatch(v_badL_242);
    }
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_c_2412, 5)), 0, 9);
    V v_t_2415 = (g_list_2emap_24s1288527083x146849530(heff_get_n(v_c_2412, 7, 13)));
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ecompileJs(v_t_2414, v_t_2415));
    return ({ V a_0 = v_outPath_241; V a_1 = v_t_2413; V a_2 = v_t_2416; V a_3 = v_hd_244; V a_4 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); r_; });
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V v_file_240, V v_outPath_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0, 2, 3, (V[]){v_c_242, v_file_240, v_outPath_241});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_file_240; V a_1 = v_outPath_241; V b_2 = heff_intLt(MK_INT(0LL), v_x_246); V a_3 = heff_get_n(v_x_248, 0, 2); V a_4 = v_hd_243; V a_5 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s299407329x275243323(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_file_240); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam3, 1, 5, (V[]){v_file_240, v_outPath_241, v_x_246, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam2, 1, 5, (V[]){v_x_245, v_hd_243, v_file_240, v_outPath_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_lam1, 1, 4, (V[]){v_hd_243, v_file_240, v_outPath_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(V v_sources_240, V v_m_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule(v_sources_240, heff_dup(v_m_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0_clo);
  }
  case TAG_Just: {
    V v_path_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
    V v_t_247 = heff_strSlice(heff_dup(v_path_245), v_t_246, heff_strLength(heff_dup(v_path_245)));
    V v_t_2410;
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str0))) {
      V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_path_245)), MK_INT(3LL));
      v_t_2410 = heff_strSlice(v_path_245, MK_INT(0LL), v_t_249);
    } else {
      v_t_2410 = v_path_245;
    }
    V v_path_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_str1));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1, 2, 2, (V[]){v_path_2411, v_m_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_x_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Just = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_x_2420 = heff_tag_at_n(v_ru_24x_2418_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2419})});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672_lam3, 1, 2, (V[]){v_m_241, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderC_24s2043708151x1937400672(v_sources_240, v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_x_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_x_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(a_0, a_1)); heff_drop(v_sources_240); r_; });
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str1, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str2, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str3, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str5, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str7, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1855772458x1147357462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2449);
  V f_ = v_k_241;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str7);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s954557541x749476273(v_t_2448, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam6, 1, 1, (V[]){v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Nothing: {
    V v_t_2427 = (g_std_2epath_2eparse(v_x_249, v_x_242));
    V v_t_2428 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str3)));
    V v_p_2429 = (g_std_2epath_2ejoin_2eonto_240(v_t_2427, v_t_2428));
    V v_t_2430 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2429, 1)), heff_rfield(v_p_2429, 2)));
    V v_t_2431 = ({ V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_n(v_p_2429, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_a_2432 = (g_std_2epath_2erender(v_x_249, v_t_2431));
    V v_t_2433 = (g_std_2epath_2eparse(v_x_249, v_a_2432));
    V v_t_2434 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str4)));
    V v_p_2435 = (g_std_2epath_2ejoin_2eonto_240(v_t_2433, v_t_2434));
    V v_t_2436 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2435, 1)), heff_rfield(v_p_2435, 2)));
    V v_t_2437 = ({ V rv_2 = v_t_2436; V rr_ = heff_rec_reuse_n(v_p_2435, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2438 = ({ V a_0 = v_x_249; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_249); r_; });
    V v_str_2439 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str5), v_t_2438);
    V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2439, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str6)), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s954557541x749476273(v_t_2443, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam5, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_text_2450 = heff_field(v_x_2426, 0);
    heff_take_n(v_x_2426, 1ULL, 1);
    heff_drop(v_x_249);
    heff_drop(v_x_242);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_text_2450;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_249;
  if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str0))) {
    v_x_249 = NTAG(TAG_Windows);
  } else {
    v_x_249 = NTAG(TAG_Posix);
  }
  V v_t_2410 = (g_std_2epath_2eparse(v_x_249, heff_dup(v_x_242)));
  V v_t_2411 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str1)));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2412, 1)), heff_rfield(v_p_2412, 2)));
  V v_t_2414 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_n(v_p_2412, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_a_2415 = (g_std_2epath_2erender(v_x_249, v_t_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_249, v_a_2415));
  V v_t_2417 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_str2)));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2418, 1)), heff_rfield(v_p_2418, 2)));
  V v_t_2420 = ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_n(v_p_2418, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2421 = (g_std_2epath_2erender(v_x_249, v_t_2420));
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2421, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam3_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s954557541x749476273(v_t_2425, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam4, 1, 4, (V[]){v_x_249, v_x_242, v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_intShow(heff_strLength(heff_dup(v_text_241)));
  V v_t_245 = heff_strAppend(heff_dup(v_path_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str1))));
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_245, heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1, 1, 4, (V[]){v_text_241, v_path_240, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_text_241 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_True: {
    V v_t_2411 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2412 = heff_strAppend(heff_dup(v_path_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_str3))));
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Replace, 3, (V[]){v_t_2412, v_path_240, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_lam2_clo)})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_242, v_k_243));
  }
  case TAG_False: {
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(V v_ps_240, V v_b_241, V v_id_242) {
top: ;
  V v_path_243 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0, 2, 4, (V[]){v_path_243, v_ps_240, v_id_242, v_b_241});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V f_ = v_k_245;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_t_2412 = (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str0)));
  V v_t_2413 = heff_strAppend(heff_dup(v_id_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_str1), v_b_241));
  return (g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099(v_t_2412, v_t_2413, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam3, 1, 2, (V[]){v_k_245, v_id_242})));
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_b_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_243, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam1_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839_lam2, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_hd_244, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(V v_ps_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_243 = (g_heff_2ebuild_2ecache_2ehashGo(heff_dup(v_b_241), MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s866612971x110536839(v_ps_240, v_b_241, v_t_243);
  }
  case TAG_Just: {
    V v_kept_244 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_t_245 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_str0), heff_dup(v_kept_244), MK_INT(0LL)));
    V v_t_246 = (g_heff_2ebuild_2ecommands_2ekeptId(heff_dup(v_b_241), v_t_245, v_kept_244));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V t_0 = v_ps_240;
      V t_1 = v_b_241;
      V t_2 = NTAG(TAG_Nothing);
      v_ps_240 = t_0;
      v_b_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_id_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      heff_drop(v_ps_240);
      heff_drop(v_b_241);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_lam0, 2, 1, (V[]){v_id_247});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_id_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_id_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str1, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240}));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_b_2413 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = (g_heff_2ebuild_2ecommands_2eselfFrom_24s2041952257x1827153613(v_ps_240, v_b_2413, v_x_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_241;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    heff_drop(v_ps_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_b_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Just = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    V v_t_2414 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_path_2415 = (g_heff_2ebuild_2eload_2eunder(heff_dup(v_ps_240), v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_str1)));
    V v_t_2417 = heff_tag_at_n(v_ru_24x_2412_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam4_clo)})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam5, 1, 4, (V[]){v_ps_240, v_b_2413, v_hd_241, v_k_242})));
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_247, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam2_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010_lam3, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_str0, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_path_247 = (g_heff_2ebuild_2eload_2eunder(heff_dup(v_ps_240), v_t_246, heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_str0))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam1, 2, 4, (V[]){v_path_247, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2418;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    v_x_2418 = v_x_2416;
    break;
  }
  case TAG_Just: {
    V v_text_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    v_x_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_text_2417}), v_x_2416});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_249;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2415 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(v_ps_240, v_rest_245));
  V f_ = v_c_2415;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam4, 1, 3, (V[]){v_x_2414, v_m_244, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_path_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029_lam3, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_248, v_m_244, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2(V self, V *args) {
  V v_p_2414 = args[0];
  V v_n_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_p_2414, 0);
    heff_take_n(v_p_2414, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  return heff_strEq(v_t_2417, v_n_245);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2432);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_str0))) {
    v_x_2413 = NTAG(TAG_Windows);
  } else {
    v_x_2413 = NTAG(TAG_Posix);
  }
  V v_t_2418 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2, 1, 1, (V[]){heff_dup(v_n_245)}), v_parts_241));
  V v_c_2431;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop(v_n_245);
    heff_drop(v_x_2413);
    v_c_2431 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3_clo);
    break;
  }
  case TAG_False: {
    V v_t_2421 = (g_std_2epath_2eparse(v_x_2413, heff_dup(v_dir_240)));
    V v_t_2422 = (g_std_2epath_2eparse(v_x_2413, v_n_245));
    V v_p_2423 = (g_std_2epath_2ejoin_2eonto_240(v_t_2421, v_t_2422));
    V v_t_2424 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2423, 1)), heff_rfield(v_p_2423, 2)));
    V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_n(v_p_2423, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_path_2426 = ({ V a_0 = v_x_2413; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2413); r_; });
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_2426, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4_clo)})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    v_c_2431 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2430}));
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam5, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam1, 1, 6, (V[]){v_dir_240, v_name_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6(V self, V *args) {
  V v_ok_2440 = args[0];
  return v_ok_2440;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2445)) {
  case TAG_True: {
    return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2445);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
  V v_t_2427 = (g_std_2epath_2eparse(v_x_2414, v_name_246));
  V v_p_2428 = (g_std_2epath_2ejoin_2eonto_240(v_t_2426, v_t_2427));
  V v_t_2429 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2428, 1)), heff_rfield(v_p_2428, 2)));
  V v_t_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_n(v_p_2428, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2431 = ({ V a_0 = v_x_2414; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2414); r_; });
  V v_c_2444;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2431, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4_clo)})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    v_c_2444 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2435}));
    break;
  }
  case TAG_Just: {
    V v_was_2436 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Just = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    if (heff_strEq_c(v_was_2436, heff_dup(v_text_247))) {
      heff_drop(v_text_247);
      heff_drop(v_path_2431);
      heff_drop_cell(v_ru_24x_2425_24Just, 1);
      v_c_2444 = ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5_clo);
    } else {
      V v_t_2441 = heff_tag_at_n(v_ru_24x_2425_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2431, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6_clo)})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      v_c_2444 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2443}));
    }
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam7, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_str0))) {
    v_x_2414 = NTAG(TAG_Windows);
  } else {
    v_x_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_name_246)));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2420 = (g_std_2epath_2erender(v_x_2414, v_t_2419));
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2420, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam3, 1, 7, (V[]){v_x_2414, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3(V self, V *args) {
  V v_ns_2416 = args[0];
  return v_ns_2416;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s954557541x749476273(v_t_2434, v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_True: {
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    heff_drop(v_done_241);
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_str1));
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2425, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s954557541x749476273(v_t_2429, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam7, 1, 2, (V[]){v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam6, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    v_t_2422 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  return (g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(heff_dup(v_dir_240), v_parts_245, v_t_2422, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam5, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2415);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam3_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam4, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  V v_t_2410;
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_errors_246, 0ULL, 2);
    v_t_2410 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_errors_246);
  }
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam1_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s954557541x749476273(v_t_2438, v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_t_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V v_ps_240, V v_olds_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_text_248 = heff_field(v_x31_245, 1);
      V v_x2_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_m_247), v_olds_241));
      V v_t_2411;
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str0);
        break;
      }
      case TAG_Just: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2411 = v_x_2410;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      V v_c_2417;
      if (heff_strEq_c(heff_dup(v_text_248), v_t_2411)) {
        v_c_2417 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1_clo);
      } else {
        V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
        V v_t_2416 = (g_heff_2ebuild_2eload_2eunder(heff_dup(v_ps_240), v_t_2415, heff_strAppend(heff_dup(v_m_247), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_str1))));
        v_c_2417 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s897544564x1011643099_clo), 2, (V[]){v_t_2416, heff_dup(v_text_248)}));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2, 2, 4, (V[]){v_c_2417, v_ps_240, heff_dup(v_olds_241), heff_dup(v_rest_246)});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_olds_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2420);
  V v_t_2421 = ({ V a_0 = v_ps_240; V a_1 = v_olds_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a_0, a_1, a_2)); heff_drop(v_olds_241); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2418;
  heff_room[1] = v_k_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_olds_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_lam3, 1, 5, (V[]){v_ps_240, v_olds_241, v_rest_246, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(V v_bi_240, V v_dir_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2425;
  if (heff_strEq_c(heff_dup(v_id_242), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str0))) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    v_t_2425 = v_done_245;
  } else {
    V v_path_2410 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(heff_rfield(v_bi_240, 0))));
    v_t_2425 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam0, 2, 7, (V[]){v_path_2410, heff_dup(v_texts_243), v_bi_240, heff_dup(v_out_246), v_id_242, v_backs_244, v_done_245});
  }
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_out_246, 0), heff_get_n(v_out_246, 1, 5)});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(v_dir_241, v_t_2425, v_t_2426, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_246 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_backs_244 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2417);
  V v_t_2418 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str1), heff_take_field(v_bi_240, 2)});
  V v_t_2420 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop_tag(v_t_2419, 2); r_; });
  V v_t_2421 = heff_rec_n(3, shape_groups__copies__emits, (V[]){heff_take_field(v_out_246, 2), heff_take_field(v_out_246, 3), heff_get_n(v_out_246, 4, 5)});
  V v_t_2422 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2420, v_backs_244}), v_t_2421));
  V v_c_2423 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2418; V a_2 = v_t_2422; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a_0, a_1, a_2)); heff_drop(v_t_2418); heff_drop(v_t_2422); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam3, 1, 3, (V[]){v_done_245, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_2410 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_id_242 = heff_env(self)[4];
  V v_backs_244 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2410, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam2, 1, 8, (V[]){v_texts_243, v_bi_240, v_out_246, v_id_242, v_backs_244, v_hd_2411, v_done_245, v_k_2412})));
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(V v_bi_240, V v_dir_241, V v_runtime_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = (g_map_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2413 = (g_list_2emap_24s1173914895x100384474(v_t_2412));
  V v_t_2414 = (g_list_2efoldl_24s1301054807x1042293437(heff_dup(g_map_2eempty_get()), v_bs_2413));
  V v_t_2415 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2413; V r_ = (g_list_2efoldl_24s1751327013x555271812(a_0, a_1)); heff_drop(v_bs_2413); r_; });
  V v_ks_2416 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2414, v_t_2415});
  V v_t_2417 = (g_map_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2418 = (g_list_2emap_24s1173914895x100384474(v_t_2417));
  V v_kept_2419 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_2418; V r_ = (g_list_2efoldl_24s310383131x1909826775(a_0, a_1)); heff_drop(v_bs_2418); r_; });
  V v_t_2420 = heff_get_n(heff_get_n(v_c_244, 5, 13), 0, 9);
  V v_t_2421 = (g_heff_2ecompile_2elower_2elowerProgramKept(v_t_2420, heff_take_field(v_r_246, 0), heff_dup(heff_rfield(v_bi_240, 1)), v_ks_2416));
  V v_t_2422 = ({ V a_0 = v_runtime_242; V a_1 = v_available_245; V a_2 = heff_get_n(v_r_246, 1, 2); V a_3 = v_kept_2419; V a_4 = v_t_2421; V r_ = (g_heff_2ecompile_2eemitc_2ekeptParts(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_kept_2419); r_; });
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(v_bi_240, v_dir_241, v_id_247, v_texts_248, v_backs_249, v_done_243, v_t_2422, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(V v_bi_240, V v_dir_241, V v_runtime_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s792365048x1900389010(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_runtime_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_p_2417 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_dup(heff_field(v_p_2417, 0));
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_text_2423;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2422 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_text_2423 = v_y_2422;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2ebackD_clo), 1, (V[]){v_x_249}));
  V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edecoder_2ewhole_clo), 1, (V[]){v_t_2424}));
  V v_x2_2426 = (g_heff_2ebuild_2edecoder_2erun(v_t_2425, v_text_2423));
  V v_t_2428;
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Nothing: {
    v_t_2428 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    break;
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 1);
    v_t_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x2_2426);
  }
  return (g_map_2einsert_24s1341440536x470972936(v_t_2420, v_t_2428, v_m_2416));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_runtime_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2429 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam3, 2, 1, (V[]){heff_dup(v_x_249)}), heff_dup(g_map_2eempty_get()), v_x_2415));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_runtime_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2415; V a_9 = v_t_2429; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s646738927x964931100(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_runtime_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c(heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str0))) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1611067448x17497029(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_runtime_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str3, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_runtime_244, V v_done_245, V v_c_246, V v_available_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam0, 1, 1, (V[]){heff_dup(v_c_246)}), heff_dup(heff_rfield(v_c_246, 7))));
  V v_t_2415 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2414));
  V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2416));
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam1, 1, 1, (V[]){heff_dup(v_available_247)}), v_t_2417));
  V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = heff_dup(v_c_246); V a_2 = v_name_242; V r_ = (g_heff_2ebuild_2edriver_2efindRunnable(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  switch (heff_tag_of(v_t_2420)) {
  case TAG_Left: {
    V v_why_2421 = heff_field(v_t_2420, 0);
    V v_ru_24t_2420_24Left = heff_take_reuse_n(v_t_2420, 1ULL, 1);
    heff_drop(v_bi_240);
    heff_drop(v_outPath_243);
    heff_drop(v_runtime_244);
    heff_drop(v_done_245);
    heff_drop_rec(v_c_246, 13);
    heff_drop(v_available_247);
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str0), heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str1), v_why_2421)));
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str2)), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_at_n(v_ru_24t_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam2, 1, 2, (V[]){v_z_248, v_z_249})));
  }
  case TAG_Right: {
    V v_r_2432 = heff_field(v_t_2420, 0);
    heff_take_n(v_t_2420, 1ULL, 1);
    heff_drop(v_file_241);
    V v_t_2433 = heff_intSub(heff_strLength(heff_dup(v_outPath_243)), MK_INT(1LL));
    V v_t_2434 = heff_strSlice(heff_dup(v_outPath_243), v_t_2433, heff_strLength(heff_dup(v_outPath_243)));
    if (heff_strEq_c(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_str3))) {
      V v_t_2436 = heff_intSub(heff_strLength(heff_dup(v_outPath_243)), MK_INT(1LL));
      return (g_heff_2ebuild_2ecommands_2ekeptParts_24s778583095x549941644(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), v_t_2436), v_runtime_244, v_done_245, v_c_246, v_available_247, v_r_2432, v_z_248, v_z_249));
    } else {
      heff_drop(v_bi_240);
      V v_t_2437 = (g_list_2eany_24s762674996x1009180162(v_available_247));
      V v_t_2438;
      switch (heff_tag_of(v_t_2437)) {
      case TAG_True: {
        v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        v_t_2438 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){heff_take_field(v_r_2432, 1)}));
      V v_t_2440 = heff_get_n(heff_get_n(v_c_246, 5, 13), 0, 9);
      V v_t_2441 = (g_heff_2ecompile_2elower_2elowerProgramAnf(v_t_2440, heff_get_n(v_r_2432, 0, 2)));
      V v_t_2442 = (g_heff_2ecompile_2eemitc_2eoutputOf(v_runtime_244, v_available_247, heff_rec_n(2, shape_prefix__end, (V[]){v_t_2438, v_t_2439}), v_t_2441));
      return (g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(v_outPath_243, v_done_245, v_t_2442, v_z_248, v_z_249));
    }
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam0(V self, V *args) {
  V v_o_2410 = args[0];
  V v_c_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_246, heff_dup(heff_rfield(v_o_2410, 1))));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_2410, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2412 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    V v_t_2413 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2410, 0), heff_get_n(v_o_2410, 1, 2), v_eff_2412});
    return heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam1(V self, V *args) {
  V v_k_2418 = args[0];
  V v_available_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_247; V a_1 = v_k_2418; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_247); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str0, 15, "no files given\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str3, 1, ".");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_246));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_bi_240);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str0), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam0, 1, 2, (V[]){v_z_247, v_z_248})));
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam1, 1, 1, (V[]){heff_dup(v_c_2419)}), heff_dup(heff_rfield(v_c_2419, 7))));
    V v_t_2425 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2424));
    V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2426));
    V v_xs_2428 = (g_list_2emap_24s1052938345x548264065(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str2), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str3), v_t_2427));
    V v_t_2429 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2428));
    V v_c_2430 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(v_sources_241, v_t_2429));
    return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam2, 1, 8, (V[]){v_z_247, v_name_243, v_c_2419, v_outPath_244, v_z_248, v_bi_240, v_file_242, v_done_245})});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(a[0], a1, a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a1); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam1(V self, V *args) {
  V v_o_2420 = args[0];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_2419, heff_dup(heff_rfield(v_o_2420, 1))));
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_2420, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2422 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    V v_t_2423 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2420, 0), heff_get_n(v_o_2420, 1, 2), v_eff_2422});
    return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  V v_x_2431 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_bi_240);
    heff_drop(v_file_242);
    heff_drop(v_done_245);
    heff_drop(v_x_2431);
    V v_exports_2434 = (g_list_2emap_24s570241860x1995261629(heff_take_field(v_c_2419, 7)));
    V v_roots_2435 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2434)));
    V v_t_2436 = heff_get_n(heff_get_n(v_c_2419, 5, 13), 0, 9);
    V v_t_2437 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2436));
    V v_t_2438 = (g_heff_2ecompile_2elower_2eanfLowered(v_roots_2435, v_t_2437));
    V v_t_2439 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2433, v_exports_2434, v_t_2438));
    return ({ V a_0 = v_outPath_244; V b_1 = NTAG(TAG_False); V a_2 = v_t_2439; V a_3 = v_z_247; V a_4 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  case TAG_Just: {
    return (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(v_bi_240, v_file_242, v_name_243, v_outPath_244, v_x_2433, v_done_245, v_c_2419, v_x_2431, v_z_247, v_z_248));
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_c_2419 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2432 = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo);
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam3, 1, 9, (V[]){v_name_243, v_c_2419, v_outPath_244, v_z_247, v_z_248, v_bi_240, v_file_242, v_done_245, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam0, 2, 5, (V[]){v_c_244, v_file_242, v_name_240, v_outPath_241, v_done_243});
}
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_x_247 = heff_env(self)[4];
  V v_file_242 = heff_env(self)[5];
  V v_name_240 = heff_env(self)[6];
  V v_outPath_241 = heff_env(self)[7];
  V v_done_243 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2411);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop_rec(v_x_2410, 2);
    heff_drop_rec(v_x_247, 5);
    heff_drop(v_file_242);
    heff_drop(v_name_240);
    heff_drop(v_outPath_241);
    heff_drop(v_done_243);
    V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_245, v_k_246));
  } else {
    V v_t_2417 = (g_list_2eany_24s976871491x582277361(heff_rfield(v_x_2410, 0)));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop_rec(v_x_2410, 2);
      heff_drop_rec(v_x_247, 5);
      heff_drop(v_file_242);
      heff_drop(v_name_240);
      heff_drop(v_outPath_241);
      heff_drop(v_done_243);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s954557541x749476273(v_t_2421, v_hd_245, v_k_246));
    }
    case TAG_False: {
      V v_t_2422 = (g_list_2emap_24s1416288597x2006619516(heff_dup(heff_rfield(v_x_2410, 0))));
      V v_t_2423 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_247, 2), heff_take_field(v_x_2410, 1), v_t_2422});
      return ({ V a_0 = v_t_2423; V b_1 = heff_get_n(v_x_247, 0, 5); V a_2 = v_file_242; V a_3 = v_name_240; V a_4 = v_outPath_241; V a_5 = v_done_243; V b_6 = heff_get_n(v_x_2410, 0, 2); V a_7 = v_hd_245; V a_8 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(a_0, b_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8)); heff_drop(b_1); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_file_242 = heff_env(self)[4];
  V v_name_240 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(heff_rfield(v_x_2410, 0)), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam4, 1, 9, (V[]){v_x_248, v_hd_245, v_k_246, v_x_2410, v_x_247, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_name_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_247)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam3, 1, 8, (V[]){v_hd_245, v_x_248, v_k_246, v_x_247, v_file_242, v_name_240, v_outPath_241, v_done_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_str0), heff_dup(heff_rfield(v_x_247, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam2, 1, 7, (V[]){v_x_247, v_hd_245, v_k_246, v_file_242, v_name_240, v_outPath_241, v_done_243})));
}
V g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918_lam1, 1, 6, (V[]){v_hd_245, v_k_246, v_file_242, v_name_240, v_outPath_241, v_done_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str0, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str1, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str3, 18, "run it with `node ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str4, 9, " ARGS...`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str6, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str7, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str8, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str9, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str11, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str12, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str13, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str14, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str16, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str17, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str18, 28, ": build it with `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str19, 12, " -o PROGRAM`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str20, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str21, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str22, 22, ": esm, page, node or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(V v_o_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str0))) {
    V v_outPath_242 = heff_take_field(v_o_240, 1);
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str1), heff_strAppend(heff_dup(v_outPath_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str2), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str3), heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str4))))));
    V v_t_244 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str5)), NTAG(TAG_MkUnit)});
    V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_247}));
    return (g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str6), heff_dup(heff_rfield(v_o_240, 2)), v_outPath_242, heff_get_n(v_o_240, 0, 4), v_t_248));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str7))) {
      V v_outPath_2410 = heff_take_field(v_o_240, 1);
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str8), heff_strAppend(heff_dup(v_outPath_2410), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str9)));
      V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str10)), NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2415}));
      return (g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str11), heff_dup(heff_rfield(v_o_240, 2)), v_outPath_2410, heff_get_n(v_o_240, 0, 4), v_t_2416));
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str12))) {
        V v_t_2418 = heff_take_field(v_o_240, 2);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          return (g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(heff_dup(heff_rfield(v_o_240, 0)), heff_get_n(v_o_240, 1, 4)));
        }
        case TAG_Just: {
          heff_take_n(v_t_2418, 0ULL, 1);
          heff_drop_rec(v_o_240, 4);
          return ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0_clo);
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str14))) {
          V v_outPath_2432 = heff_take_field(v_o_240, 1);
          V v_t_2433 = heff_intSub(heff_strLength(heff_dup(v_outPath_2432)), MK_INT(1LL));
          V v_t_2434 = heff_strSlice(heff_dup(v_outPath_2432), v_t_2433, heff_strLength(heff_dup(v_outPath_2432)));
          V v_t_2436;
          if (heff_strEq_c(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str15))) {
            v_t_2436 = heff_strAppend(heff_dup(v_outPath_2432), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str16));
          } else {
            v_t_2436 = heff_dup(v_outPath_2432);
          }
          V v_str_2437 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str17), heff_strAppend(heff_dup(v_outPath_2432), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str18), heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str19)))));
          V v_t_2438 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2437, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str20)), NTAG(TAG_MkUnit)});
          V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
          V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
          V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
          V v_t_2442 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2441}));
          return (g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918(heff_dup(heff_rfield(v_o_240, 2)), v_outPath_2432, heff_get_n(v_o_240, 0, 4), v_t_2442));
        } else {
          return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam2, 2, 1, (V[]){v_o_240});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(a[0]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2420 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, v_hd_2420, v_k_2421));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str13), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s954557541x749476273(v_t_2425, heff_dup(v_hd_2420), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam1, 1, 2, (V[]){v_hd_2420, v_k_2421})));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam3(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2443 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s954557541x749476273(v_t_2454, v_hd_2443, v_k_2444));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam2(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str21), heff_strAppend(heff_get_n(v_o_240, 3, 4), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str22)));
  V v_t_2446 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str23)), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s954557541x749476273(v_t_2449, heff_dup(v_hd_2443), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam3, 1, 2, (V[]){v_hd_2443, v_k_2444})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_248, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_rest_244, v_p_241, v_p_242));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(V v_file_240) {
top: ;
  V v_c_241 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam0, 2, 1, (V[]){v_c_241});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513(a[0]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_cs_248 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V v_t_2410 = ({ V a_0 = v_cs_248; V r_ = (g_heff_2ebuild_2edriver_2elastChecked(a_0)); heff_drop(v_cs_248); r_; });
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2415 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    V v_t_2416 = (g_heff_2ebuild_2equery_2eexplain(v_c_2415));
    return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2416, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_cs_248 = heff_get_n(v_x_247, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_248), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam4, 1, 3, (V[]){v_cs_248, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_245);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam3, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam2, 1, 3, (V[]){v_x_244, v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s610768674x492270513_lam1, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str1, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(V v_file_240, V v_offs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam0, 2, 2, (V[]){v_c_242, v_offs_241});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam5(V self, V *args) {
  V v_off_2417 = args[0];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = (g_prelude_2eparseInt(v_off_2417));
  V v_x2_2420;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nothing: {
    heff_drop(v_c_2416);
    v_x2_2420 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_o_2419 = heff_field(v_t_2418, 0);
    heff_take_n(v_t_2418, 1ULL, 1);
    v_x2_2420 = (g_heff_2ebuild_2equery_2etypeAt(v_c_2416, v_o_2419));
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str1);
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    heff_take_n(v_x2_2420, 1ULL, 1);
    return v_x_2421;
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_offs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_cs_249; V r_ = (g_heff_2ebuild_2edriver_2elastChecked(a_0)); heff_drop(v_cs_249); r_; });
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    heff_drop(v_offs_241);
    V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_c_2416 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam5, 1, 1, (V[]){v_c_2416}), v_offs_241));
    return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2422, v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_249), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam4, 1, 4, (V[]){v_cs_249, v_hd_243, v_k_244, v_offs_241})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_offs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam3, 1, 3, (V[]){v_hd_243, v_k_244, v_offs_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_k_244, v_offs_241})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam1, 1, 3, (V[]){v_hd_243, v_k_244, v_offs_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str1, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(V v_checkOnly_240, V v_f_241, V v_src_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_fix_243, heff_dup(v_src_242)));
  V v_t_2413;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Left: {
    V v_why_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Left = heff_take_reuse_n(v_t_246, 1ULL, 1);
    v_t_2413 = heff_tag_at_n(v_ru_24t_246_24Left, TAG_Left, 1, (V[]){v_why_247});
    break;
  }
  case TAG_Right: {
    V v_out_248 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2410 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_249));
    V v_t_2411 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_248), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2412 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2411));
    v_t_2413 = (g_heff_2esyntax_2eformat_2esameMeaning(heff_dup(v_src_242), v_out_248, v_t_2410, v_t_2412));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Left: {
    V v_why_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Left = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    heff_drop(v_src_242);
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str0), heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str1), v_why_2414)));
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str2)), NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_at_n(v_ru_24t_2413_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s954557541x749476273(v_t_2419, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0, 1, 1, (V[]){v_z_245})));
  }
  case TAG_Right: {
    V v_out_2421 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Right = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_out_2421), v_src_242)) {
      heff_drop(v_f_241);
      heff_drop(v_z_244);
      heff_drop(v_out_2421);
      heff_drop_cell(v_ru_24t_2413_24Right, 1);
      return heff_tail(v_z_245, 1, (V[]){MK_INT(0LL)});
    } else {
      switch (heff_tag_of(v_checkOnly_240)) {
      case TAG_True: {
        heff_drop(v_out_2421);
        V v_t_2423 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_241, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_str3)), NTAG(TAG_MkUnit)});
        V v_t_2424 = heff_tag_at_n(v_ru_24t_2413_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        return (g_co_2eop_24s954557541x749476273(v_t_2426, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1, 1, 1, (V[]){v_z_245})));
      }
      case TAG_False: {
        V v_t_2429 = heff_tag_at_n(v_ru_24t_2413_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_f_241, v_out_2421, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2_clo)})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        return (g_co_2eop_24s954557541x749476273(v_t_2431, v_z_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3, 1, 1, (V[]){v_z_245})));
      }
      default: return heff_nomatch(v_checkOnly_240);
      }
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_z_245;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam2(V self, V *args) {
  V v_ok_2428 = args[0];
  return v_ok_2428;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  V f_ = v_z_245;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str0, 18, "heff: cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(V v_checkOnly_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(v_t_247, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam1, 1, 4, (V[]){v_f_241, v_hd_242, v_k_243, heff_dup(v_checkOnly_240)})));
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam0(V self, V *args) {
  V v_t_244 = args[0];
  return v_t_244;
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2414);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_src_2415 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2417, 0, 5)));
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_f_241; V a_2 = v_src_2415; V a_3 = v_t_2418; V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2efmtSrc_24s7788760x383278336(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_checkOnly_240); r_; });
}
V g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_checkOnly_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_checkOnly_240);
    V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str0), v_f_241), ((V)&g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_str1));
    V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_249, NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam2, 1, 1, (V[]){v_k_243})));
  }
  case TAG_Just: {
    V v_src_2415 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_c_2416 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_241)));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460_lam3, 1, 5, (V[]){v_checkOnly_240, v_f_241, v_src_2415, v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(V v_checkOnly_240, V v_x2_241, V v_bad_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ebuild_2ecommands_2efmtOne_24s206571160x415029460(v_checkOnly_240, heff_dup(v_f_245), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0, 1, 5, (V[]){heff_dup(v_checkOnly_240), heff_dup(v_rest_246), v_bad_242, v_p_243, v_p_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_checkOnly_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_checkOnly_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_247); V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2efmtAll_24s1391956328x1704458105(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_checkOnly_240); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2425, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2426});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam4, 1, 3, (V[]){v_x_2425, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_str0))) {
    v_x_2414 = NTAG(TAG_Windows);
  } else {
    v_x_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_f_246)));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2420 = ({ V a_0 = v_x_2414; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2414); r_; });
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2420, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam2_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4(V self, V *args) {
  V v_ok_2445 = args[0];
  return v_ok_2445;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2461);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2450;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_True: {
    v_t_2450 = v_x_2449;
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2449);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  switch (heff_tag_of(v_t_2450)) {
  case TAG_True: {
    heff_drop(v_x_2414);
    heff_drop(v_f_246);
    return (g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_False: {
    heff_drop(v_rest_245);
    V v_t_2451 = (g_std_2epath_2eparse(v_x_2414, v_dir_240));
    V v_t_2452 = (g_std_2epath_2eparse(v_x_2414, v_f_246));
    V v_p_2453 = (g_std_2epath_2ejoin_2eonto_240(v_t_2451, v_t_2452));
    V v_t_2454 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2453, 1)), heff_rfield(v_p_2453, 2)));
    V v_t_2455 = ({ V rv_2 = v_t_2454; V rr_ = heff_rec_reuse_n(v_p_2453, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_str_2456 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str2), ({ V a_0 = v_x_2414; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2414); r_; }));
    V v_t_2457 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2456, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str3)), NTAG(TAG_MkUnit)});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    return (g_co_2eop_24s954557541x749476273(v_t_2460, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam6, 1, 1, (V[]){v_p_243})));
  }
  default: return heff_nomatch(v_t_2450);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
  V v_t_2433 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_f_246)));
  V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
  V v_t_2435 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2434, 1)), heff_rfield(v_p_2434, 2)));
  V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_n(v_p_2434, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2437 = (g_std_2epath_2erender(v_x_2414, v_t_2436));
  V v_t_2438 = heff_intSub(heff_strLength(heff_dup(v_f_246)), MK_INT(3LL));
  V v_t_2439 = heff_strSlice(heff_dup(v_f_246), v_t_2438, heff_strLength(heff_dup(v_f_246)));
  V v_str_2444;
  if (heff_strEq_c(v_t_2439, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str1))) {
    V v_t_2441 = (g_heff_2esyntax_2eformat_2eformat(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Left: {
      heff_take_n(v_t_2441, 0ULL, 1);
      v_str_2444 = v_text_247;
      break;
    }
    case TAG_Right: {
      V v_out_2443 = heff_field(v_t_2441, 0);
      heff_take_n(v_t_2441, 1ULL, 1);
      heff_drop(v_text_247);
      v_str_2444 = v_out_2443;
      break;
    }
    default: heff_nomatch(v_t_2441);
    }
  } else {
    v_str_2444 = v_text_247;
  }
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2437, v_str_2444, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam4_clo)})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s954557541x749476273(v_t_2448, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam5, 1, 7, (V[]){v_x_2431, v_dir_240, v_rest_245, v_p_242, v_p_243, v_x_2414, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_str0))) {
    v_x_2414 = NTAG(TAG_Windows);
  } else {
    v_x_2414 = NTAG(TAG_Posix);
  }
  V v_t_2415 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_dir_240)));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_2414, heff_dup(v_f_246)));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_s_2420 = (g_std_2epath_2erender(v_x_2414, v_t_2419));
  V v_p_2421 = (g_std_2epath_2eparse(v_x_2414, v_s_2420));
  V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2421, 2)));
  V v_xs_2423 = (g_list_2edrop(MK_INT(1LL), v_t_2422));
  V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
  V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_n(v_p_2421, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2426 = (g_std_2epath_2erender(v_x_2414, v_t_2425));
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2426, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam2_clo)})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865_lam3, 1, 7, (V[]){v_x_2414, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str0, 3, "PWD");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str2, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str3, 7, "heff: `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str4, 73, "` cannot name a package: a lowercase letter, then letters, digits and `_`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str6, 63, "heff: `heff` is heff's own package: name the project otherwise\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str7, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str8, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str11, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str12, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str13, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str14, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str15, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str0), ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam8(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s954557541x749476273(v_t_2445, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam9(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s954557541x749476273(v_t_2455, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam10(V self, V *args) {
  V v_x_2456 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2456)) {
  case TAG_True: {
    V v_t_2457 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str7), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str8)));
    V v_t_2458 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2457, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str9)), NTAG(TAG_MkUnit)});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    return (g_co_2eop_24s954557541x749476273(v_t_2461, v_hd_241, v_k_242));
  }
  case TAG_False: {
    heff_drop(v_dir_240);
    V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    return (g_co_2eop_24s954557541x749476273(v_t_2465, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2456);
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam11(V self, V *args) {
  V v_x_2476 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  return (g_co_2eop_24s954557541x749476273(v_t_2480, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  V v_x_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2434 = (g_heff_2ebuild_2eproject_2eisName(heff_dup(v_x_2429)));
  V v_t_2435;
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_True: {
    v_t_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2435 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2434);
  }
  switch (heff_tag_of(v_t_2435)) {
  case TAG_True: {
    heff_drop(v_x_2433);
    heff_drop(v_dir_240);
    heff_drop(v_x_2432);
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str3), heff_strAppend(v_x_2429, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str4)));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str5)), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s954557541x749476273(v_t_2440, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam8, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_False: {
    if (heff_strEq_c(v_x_2429, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
      heff_drop(v_x_2433);
      heff_drop(v_dir_240);
      heff_drop(v_x_2432);
      V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str6), NTAG(TAG_MkUnit)});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      return (g_co_2eop_24s954557541x749476273(v_t_2450, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam9, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      switch (heff_tag_of(v_x_2433)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s711909795x136577865(heff_dup(v_dir_240), v_x_2432, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam10, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2432);
        V v_t_2470;
        switch (heff_tag_of(v_x_2433)) {
        case TAG_Nil: {
          v_t_2470 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2468 = heff_field(v_x_2433, 0);
          V v_xs_2469 = heff_field(v_x_2433, 1);
          heff_take_n(v_x_2433, 3ULL, 2);
          v_t_2470 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str11); V a_1 = v_x_2468; V a_2 = v_xs_2469; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2469); r_; });
          break;
        }
        default: heff_nomatch(v_x_2433);
        }
        V v_str_2471 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str12), heff_strAppend(v_dir_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str13), heff_strAppend(v_t_2470, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str14)))));
        V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2471, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str15)), NTAG(TAG_MkUnit)});
        V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
        V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
        V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
        return (g_co_2eop_24s954557541x749476273(v_t_2475, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam11, 1, 2, (V[]){v_hd_241, v_k_242})));
      }
      default: return heff_nomatch(v_x_2433);
      }
    }
  }
  default: return heff_nomatch(v_t_2435);
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2428;
  if (heff_strEq_c(v_x_2426, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str1))) {
    v_x_2428 = NTAG(TAG_Windows);
  } else {
    v_x_2428 = NTAG(TAG_Posix);
  }
  V v_x_2429 = ({ V a_0 = v_x_2428; V a_1 = heff_dup(v_dir_240); V a_2 = v_x_247; V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_x_2428); r_; });
  V v_t_2431;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2430 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_x_2432 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2429), v_t_2431));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s439468853x297889457(heff_dup(v_dir_240), heff_dup(v_x_2432), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam7, 1, 5, (V[]){v_x_2429, v_hd_241, v_k_242, v_dir_240, v_x_2432})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2421;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_x_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2414 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_x1_2415 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_2414));
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Left: {
      heff_take_n(v_x1_2415, 0ULL, 1);
      heff_drop_cell(v_ru_24x_2413_24Just, 1);
      v_x_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x1_2415, 0);
      heff_take_n(v_x1_2415, 1ULL, 1);
      V v_t_2418 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2417); r_; });
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Left: {
        heff_take_n(v_t_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x_2413_24Just, 1);
        v_x_2421 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Right: {
        V v_p_2420 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        v_x_2421 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2420, 1, 4)});
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam5_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam6, 1, 5, (V[]){v_dir_240, v_x_247, v_x_2421, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_248, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam3_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam4, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_247, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s1848891591x879709784_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_247, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str1, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str4, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str5, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str6, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str8, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str9, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str10, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str11, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str12, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str13, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str14, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str16, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str17, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str18, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str19, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str20, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str21, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str22, 2, "-C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str23, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str24, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str25, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str27, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str28, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str30, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str31, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str32, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str33, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str34, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str35, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str36, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str37, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str38, 4, " in ");
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam0, 2, 4, (V[]){v_x_243, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9(V self, V *args) {
  V v_r_2439 = args[0];
  return v_r_2439;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12(V self, V *args) {
  V v_ok_2448 = args[0];
  return v_ok_2448;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam13(V self, V *args) {
  V v_x_2452 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str13), (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_s_2454 = heff_get_n(v_x_2443, 2, 3);
  V v_t_2455 = (g_prelude_2eskipSpaces(heff_dup(v_s_2454), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2456 = heff_intSub(heff_strLength(heff_dup(v_s_2454)), MK_INT(1LL));
  V v_t_2457 = (g_prelude_2eskipSpaces(heff_dup(v_s_2454), v_t_2456, MK_INT(-1LL)));
  V v_t_2458 = heff_strSlice(v_s_2454, v_t_2455, heff_intAdd(v_t_2457, MK_INT(1LL)));
  V v_t_2459 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str14), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str15), heff_strAppend(heff_dup(v_v_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str16), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str17), heff_strAppend(v_t_2453, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str18), v_t_2458)))))))));
  V v_x_2460 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2459});
  V f_ = v_k_245;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14(V self, V *args) {
  V v_r_2463 = args[0];
  return v_r_2463;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16(V self, V *args) {
  V v_ok_2476 = args[0];
  return v_ok_2476;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18(V self, V *args) {
  V v_ok_2481 = args[0];
  return v_ok_2481;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20(V self, V *args) {
  V v_ok_2492 = args[0];
  return v_ok_2492;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam22(V self, V *args) {
  V v_x_24103 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2491 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24103);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2491});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam21(V self, V *args) {
  V v_x_2496 = args[0];
  V v_x_2468 = heff_env(self)[0];
  V v_x_2485 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_x_2491 = heff_env(self)[6];
  V v_x_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if (heff_intEq_c(heff_get_n(v_x_2468, 0, 3), MK_INT(0LL))) {
    switch (heff_tag_of(v_x_2485)) {
    case TAG_True: {
      switch (heff_tag_of(v_x_2496)) {
      case TAG_True: {
        heff_drop(v_x_243);
        V v_t_2498 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str27), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str28), v_v_242)));
        V v_t_2499 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2498, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str29)), NTAG(TAG_MkUnit)});
        V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
        V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
        V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
        return (g_co_2eop_24s954557541x749476273(v_t_24102, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam22, 1, 2, (V[]){v_k_245, v_x_2491})));
      }
      case TAG_False: {
        heff_drop(v_hd_244);
        heff_drop(v_x_2491);
        V v_t_24104 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str30), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str31), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str32), v_x_243)))));
        V f_ = v_k_245;
        args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_24104});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2496);
      }
    }
    case TAG_False: {
      heff_drop(v_x_2496);
      heff_drop(v_hd_244);
      heff_drop(v_x_2491);
      V v_t_24105 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str33), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str34), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str35), v_x_243)))));
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_24105});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2485);
    }
  } else {
    heff_drop(v_x_2496);
    heff_drop(v_x_2485);
    heff_drop(v_hd_244);
    heff_drop(v_x_2491);
    V v_t_24106 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str36), heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str37), heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str38), v_x_243)))));
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_24106});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam19(V self, V *args) {
  V v_x_2485 = args[0];
  V v_x_2468 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2486 = heff_dup(heff_rfield(v_x_2468, 1));
  V v_t_2487 = (g_prelude_2eskipSpaces(heff_dup(v_s_2486), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2488 = heff_intSub(heff_strLength(heff_dup(v_s_2486)), MK_INT(1LL));
  V v_t_2489 = (g_prelude_2eskipSpaces(heff_dup(v_s_2486), v_t_2488, MK_INT(-1LL)));
  V v_t_2490 = heff_strSlice(v_s_2486, v_t_2487, heff_intAdd(v_t_2489, MK_INT(1LL)));
  V v_x_2491 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str24), v_t_2490);
  V v_t_2493 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str25)), heff_strAppend(heff_dup(v_x_2491), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str26)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20_clo)});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam21, 1, 8, (V[]){v_x_2468, v_x_2485, v_path_241, v_v_242, v_hd_244, v_k_245, v_x_2491, v_x_243})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam17(V self, V *args) {
  V v_x_2480 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_2468 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2480);
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18_clo)})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  return (g_co_2eop_24s954557541x749476273(v_t_2484, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam19, 1, 6, (V[]){v_x_2468, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam15(V self, V *args) {
  V v_x_2468 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2469 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2470 = (g_std_2epath_2eparse(v_st_2469, heff_dup(v_x_243)));
  V v_t_2471 = (g_std_2epath_2eparse(v_st_2469, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str23)));
  V v_p_2472 = (g_std_2epath_2ejoin_2eonto_240(v_t_2470, v_t_2471));
  V v_t_2473 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2472, 1)), heff_rfield(v_p_2472, 2)));
  V v_t_2474 = ({ V rv_2 = v_t_2473; V rr_ = heff_rec_reuse_n(v_p_2472, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2475 = ({ V a_0 = v_st_2469; V a_1 = v_t_2474; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2469); r_; });
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_2475, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16_clo)})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  return (g_co_2eop_24s954557541x749476273(v_t_2479, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam17, 1, 6, (V[]){v_x_243, v_hd_244, v_x_2468, v_path_241, v_v_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam11(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2445);
  V v_t_2447;
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_2443, 0)), MK_INT(0LL))) {
    v_t_2447 = NTAG(TAG_False);
  } else {
    v_t_2447 = NTAG(TAG_True);
  }
  switch (heff_tag_of(v_t_2447)) {
  case TAG_True: {
    heff_drop_rec(v_ps_240, 6);
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_243, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12_clo)})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    return (g_co_2eop_24s954557541x749476273(v_t_2451, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam13, 1, 4, (V[]){v_path_241, v_x_2443, v_v_242, v_k_245})));
  }
  case TAG_False: {
    heff_drop_rec(v_x_2443, 3);
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str19), NTAG(TAG_Nil)});
    V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str20), v_t_2461})});
    V v_t_2464 = heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str22), v_t_2462}), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14_clo)});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    return (g_co_2eop_24s954557541x749476273(v_t_2467, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam15, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245})));
  }
  default: return heff_nomatch(v_t_2447);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2444 = heff_tag_n(TAG_End, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2444}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam11, 1, 7, (V[]){v_x_2443, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str3), (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241))));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str4), heff_dup(v_v_242)), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str6), v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str8), v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str10), v_t_2436})});
  V v_as_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str11), v_t_2437});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str12), v_as_2438, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9_clo)})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam10, 1, 7, (V[]){v_x_2431, v_hd_244, v_x_243, v_path_241, v_v_242, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str1), heff_strAppend(heff_dup(v_path_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str2), heff_dup(v_v_242))));
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2428, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam8, 1, 6, (V[]){v_path_241, v_x_243, v_v_242, v_hd_244, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  V v_st_2416 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_p_2417 = (g_std_2epath_2eparse(v_st_2416, heff_dup(v_x_243)));
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2417, 2)));
  V v_xs_2419 = (g_list_2edrop(MK_INT(1LL), v_t_2418));
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
  V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2422 = ({ V a_0 = v_st_2416; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); r_; });
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2422, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam6, 1, 6, (V[]){v_path_241, v_v_242, v_hd_244, v_x_243, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam4, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245})));
  }
  case TAG_Just: {
    V v_h_24107 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_243);
    heff_drop(v_hd_244);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_t_24108 = (g_prelude_2eskipSpaces(heff_dup(v_h_24107), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24109 = heff_intSub(heff_strLength(heff_dup(v_h_24107)), MK_INT(1LL));
    V v_t_24110 = (g_prelude_2eskipSpaces(heff_dup(v_h_24107), v_t_24109, MK_INT(-1LL)));
    V v_t_24111 = heff_strSlice(v_h_24107, v_t_24108, heff_intAdd(v_t_24110, MK_INT(1LL)));
    V v_x_24112 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Right, 1, (V[]){v_t_24111});
    V f_ = v_k_245;
    args[0] = v_x_24112;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str0)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam2, 1, 6, (V[]){v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str0, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str4, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str5, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str6, 24, ": its tag has been moved");
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_t_247 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam0, 1, 1, (V[]){heff_dup(v_path_244)}), heff_take_field(v_root_241, 2)));
  V v_t_2414;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam1, 1, 1, (V[]){v_r_248}), heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2412, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_c_2415 = (g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam2, 2, 6, (V[]){v_c_2415, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2435 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_st_2436 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2437 = (g_std_2epath_2eparse(v_st_2436, heff_dup(heff_rfield(v_ps_240, 0))));
    V v_t_2438 = (g_std_2epath_2eparse(v_st_2436, v_d_2435));
    V v_p_2439 = (g_std_2epath_2ejoin_2eonto_240(v_t_2437, v_t_2438));
    V v_t_2440 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2439, 1)), heff_rfield(v_p_2439, 2)));
    V v_t_2441 = ({ V rv_2 = v_t_2440; V rr_ = heff_rec_reuse_n(v_p_2439, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2442 = ({ V a_0 = v_st_2436; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2436); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2442, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam0(V self, V *args) {
  V v_r_246 = args[0];
  V v_path_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_246, 1, 3), v_path_244);
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam1(V self, V *args) {
  V v_p_2410 = args[0];
  V v_r_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_p_2410, 0, 2), heff_get_n(v_r_248, 0, 3));
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_s_2422, 0)), v_path_244)) {
    return heff_strEq(heff_get_n(v_s_2422, 1, 3), v_v_245);
  } else {
    heff_drop_rec(v_s_2422, 3);
    heff_drop(v_v_245);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2416);
    V v_t_2420 = heff_strAppend(v_by_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str0), heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str1), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str2), v_why_2419))))));
    V f_ = v_k_2417;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2420});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_drop(v_by_243);
    V v_t_2424 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam4, 1, 2, (V[]){heff_dup(v_path_244), heff_dup(v_v_245)}), v_sums_242));
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_s_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 2);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){heff_get_n(v_s_2425, 2, 3)});
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nothing: {
      heff_drop(v_h_2421);
      V v_t_2428 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2429 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2428, v_path_244));
      V f_ = v_t_2429;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_want_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_h_2421), heff_dup(v_want_2430))) {
        heff_drop(v_h_2421);
        heff_drop(v_want_2430);
        V v_t_2432 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2433 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1838823388x1124285887(v_ps_240, v_t_2432, v_path_244));
        V f_ = v_t_2433;
        heff_room[0] = v_hd_2416;
        heff_room[1] = v_k_2417;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_2416);
        V v_t_2434 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str3), heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str4), heff_strAppend(v_h_2421, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str5), heff_strAppend(v_want_2430, ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_str6))))))));
        V f_ = v_k_2417;
        args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2434});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020_lam3, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2417, v_sums_242, v_ps_240, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_str0, 5, ".hash");
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop_rec(v_root_241, 4);
    return ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam5(V self, V *args) {
  V v_r_2418 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_2418, 1, 3), heff_get_n(v_x_245, 0, 3));
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam6(V self, V *args) {
  V v_p_2428 = args[0];
  V v_r_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_p_2428, 0, 2), heff_get_n(v_r_2426, 0, 3));
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam5, 1, 1, (V[]){heff_dup(v_x_245)}), heff_take_field(v_root_241, 2)));
  V v_x_2438;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_245, 3);
      v_x_2438 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2420 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      V v_t_2421 = (g_prelude_2eskipSpaces(heff_dup(v_t_2420), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2422 = heff_intSub(heff_strLength(heff_dup(v_t_2420)), MK_INT(1LL));
      V v_t_2423 = (g_prelude_2eskipSpaces(heff_dup(v_t_2420), v_t_2422, MK_INT(-1LL)));
      V v_t_2424 = heff_strSlice(v_t_2420, v_t_2421, heff_intAdd(v_t_2423, MK_INT(1LL)));
      V v_t_2425 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2424});
      v_x_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2426 = heff_field(v_t_2419, 0);
    V v_ru_24t_2419_24Cons = heff_take_reuse_n(v_t_2419, 1ULL, 2);
    V v_t_2429 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam6, 1, 1, (V[]){v_r_2426}), heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x_2417)) {
      case TAG_Nothing: {
        heff_drop_rec(v_x_245, 3);
        heff_drop_cell(v_ru_24t_2419_24Cons, 2);
        v_x_2438 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2430 = heff_field(v_x_2417, 0);
        heff_take_n(v_x_2417, 1ULL, 1);
        V v_t_2431 = (g_prelude_2eskipSpaces(heff_dup(v_t_2430), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2432 = heff_intSub(heff_strLength(heff_dup(v_t_2430)), MK_INT(1LL));
        V v_t_2433 = (g_prelude_2eskipSpaces(heff_dup(v_t_2430), v_t_2432, MK_INT(-1LL)));
        V v_t_2434 = heff_strSlice(v_t_2430, v_t_2431, heff_intAdd(v_t_2433, MK_INT(1LL)));
        V v_t_2435 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2434});
        v_x_2438 = heff_tag_at_n(v_ru_24t_2419_24Cons, TAG_Cons, 2, (V[]){v_t_2435, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2429, 0ULL, 2);
      heff_drop(v_x_2417);
      heff_drop_rec(v_x_245, 3);
      heff_drop_cell(v_ru_24t_2419_24Cons, 2);
      v_x_2438 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  V f_ = v_k_249;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(heff_rfield(v_x_245, 0)), heff_dup(heff_rfield(v_x_245, 1))));
  V v_path_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_str0));
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2412, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_248, heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam4, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str7, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str8, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str14, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str19, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str20, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str21, 32, "heff get: cannot write heff.sum\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str22, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str23, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str24, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str25, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str26, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12, 2, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam0(V self, V *args);

static V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_st;
static V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_init(void) {
  V v_c_240 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam0, 2, 1, (V[]){v_c_240});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_st)) return g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_val, &g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_st, g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_init);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s954557541x749476273(v_t_2426, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam7(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s954557541x749476273(v_t_2440, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam8(V self, V *args) {
  V v_r_2444 = args[0];
  V v_by_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec_n(3, shape_by__path__version, (V[]){v_by_2443, heff_dup(heff_rfield(v_r_2444, 1)), heff_get_n(v_r_2444, 2, 3)});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam9(V self, V *args) {
  V v_by_2446 = args[0];
  V v_path_2447 = args[1];
  V v_v_2448 = args[2];
  V v_x_245 = heff_env(self)[0];
  V v_root_2427 = heff_env(self)[1];
  V v_sums_2441 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2efetchedPkg_24s1765772617x1628456020(v_x_245, v_root_2427, v_sums_2441, v_by_2446, v_path_2447, v_v_2448));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13(V self, V *args) {
  V v_ok_2469 = args[0];
  return v_ok_2469;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam16(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2489);
  V v_t_2490 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  return (g_co_2eop_24s954557541x749476273(v_t_2493, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam19(V self, V *args) {
  V v_x_24106 = args[0];
  V v_seen_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24106; V a_1 = v_seen_24104; V r_ = (g_list_2efoldl_24s9956384x694087549(a_0, a_1)); heff_drop(v_seen_24104); r_; });
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam18(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intLt_c(MK_INT(0LL), v_x_2496)) {
    heff_drop(v_x_2450);
    V v_t_2498 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    return (g_co_2eop_24s954557541x749476273(v_t_24101, v_hd_241, v_k_242));
  } else {
    V v_seen_24104;
    switch (heff_tag_of(v_x_2450)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x_2450, 0);
      heff_take_n(v_x_2450, 1ULL, 2);
      v_seen_24104 = v_x_24102;
      break;
    }
    default: heff_nomatch(v_x_2450);
    }
    V v_t_24105 = (g_list_2efoldl_24s230517345x1163337657(NTAG(TAG_Nil), heff_dup(v_seen_24104)));
    V v_xs_24107 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam19, 1, 1, (V[]){v_seen_24104}), v_t_24105));
    V v_t_24108 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24107; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_24107); r_; });
    V v_str_24109 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str24), heff_strAppend(heff_intShow(v_t_24108), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str25)));
    V v_t_24110 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24109, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str26)), NTAG(TAG_MkUnit)});
    V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
    V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
    return (g_co_2eop_24s954557541x749476273(v_t_24113, v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam17(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str23), heff_get_n(v_x_2495, 1, 5), MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam18, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2450})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam15(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2474 = heff_env(self)[2];
  V v_x_2450 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_intLt_c(MK_INT(0LL), v_x_2478)) {
    heff_drop(v_x_2474);
    heff_drop(v_x_2450);
    V v_t_2480 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    return (g_co_2eop_24s954557541x749476273(v_t_2483, v_hd_241, v_k_242));
  } else {
    V v_t_2484;
    switch (heff_tag_of(v_x_2474)) {
    case TAG_True: {
      v_t_2484 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2484 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_2474);
    }
    switch (heff_tag_of(v_t_2484)) {
    case TAG_True: {
      heff_drop(v_x_2450);
      V v_t_2485 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str21), NTAG(TAG_MkUnit)});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      return (g_co_2eop_24s954557541x749476273(v_t_2488, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam16, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_False: {
      V v_c_2494 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str22)));
      V f_ = v_c_2494;
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam17, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2450});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2484);
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam14(V self, V *args) {
  V v_x_2474 = args[0];
  V v_x_2450 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2477;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkPair: {
    V v_y_2476 = heff_dup(heff_field(v_x_2450, 1));
    v_t_2477 = v_y_2476;
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str20), v_t_2477, MK_INT(0LL), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam15, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2474, v_x_2450})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_2450 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2456 = (g_list_2esortBy_24s492793466x2081132734(heff_dup(v_x_2455)));
  V v_x2_2457 = (g_list_2emap_24s467999193x422550880(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str8), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str9), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str10), v_t_2456));
  V v_t_2460;
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_Nil: {
    v_t_2460 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str11);
    break;
  }
  case TAG_Cons: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_xs_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    v_t_2460 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str12); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2457);
  }
  V v_c_2473;
  if (heff_strEq_c(v_t_2460, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str13))) {
    heff_drop(v_x_2455);
    v_c_2473 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam12_clo);
  } else {
    V v_t_2464 = (g_list_2esortBy_24s492793466x2081132734(v_x_2455));
    V v_x2_2465 = (g_list_2emap_24s467999193x422550880(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str14), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str15), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str16), v_t_2464));
    V v_str_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_str_2468 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_str_2468 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str18); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str19), v_str_2468, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam13_clo)})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    v_c_2473 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2472}));
  }
  V f_ = v_c_2473;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam14, 1, 3, (V[]){v_x_2450, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam10(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_2427 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2453;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_dup(heff_field(v_x_2450, 0));
    v_t_2453 = v_x_2451;
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V v_c_2454 = (g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(v_x_245, v_root_2427, v_t_2453));
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam11, 1, 3, (V[]){v_hd_241, v_x_2450, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_root_2427 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_why_2430 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    heff_drop_rec(v_root_2427, 4);
    heff_drop(v_x_245);
    V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str4), v_why_2430), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str5));
    V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_at_n(v_ru_24x_2429_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s954557541x749476273(v_t_2435, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam7, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_sums_2441 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    V v_by_2443;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2427, 0)), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str6))) {
      v_by_2443 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str7);
    } else {
      v_by_2443 = heff_dup(heff_rfield(v_root_2427, 0));
    }
    V v_t_2445 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam8, 1, 1, (V[]){v_by_2443}), heff_dup(heff_rfield(v_root_2427, 2))));
    V v_c_2449 = (g_heff_2ebuild_2eload_2eversionsGo_24s76215502x597249347(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam9, 3, 3, (V[]){heff_dup(v_x_245), heff_dup(v_root_2427), v_sums_2441}), heff_dup(heff_rfield(v_root_2427, 0)), v_t_2445, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2449;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam10, 1, 4, (V[]){v_x_245, v_root_2427, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_2412;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_src_2412 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_src_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_x1_2413 = (g_heff_2ebuild_2eproject_2epackageLit(v_src_2412));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Left: {
    V v_p_2414 = heff_field(v_x1_2413, 0);
    V v_ru_24x1_2413_24Left = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
    v_t_2416 = heff_tag_at_n(v_ru_24x1_2413_24Left, TAG_Left, 1, (V[]){v_p_2414});
    break;
  }
  case TAG_Right: {
    V v_x_2415 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2416 = ({ V a_0 = v_x_2415; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2415); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Left: {
    V v_ru_24t_2416_24Left = heff_take_reuse_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_245);
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str3), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_at_n(v_ru_24t_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s954557541x749476273(v_t_2421, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_root_2427 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    V v_c_2428 = (g_heff_2ebuild_2eload_2ereadSumAt_24s922313238x1662635569(heff_dup(v_x_245)));
    V f_ = v_c_2428;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam6, 1, 4, (V[]){v_hd_241, v_k_242, v_root_2427, v_x_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str1), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam3_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_x_243, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_str0)));
  V f_ = v_c_244;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_240;
  args[0] = heff_dup(v_hd_241);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_lam1, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str5, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str7, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str10, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str11, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str13, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str14, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str15, 9, "that of /");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str16, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str17, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str18, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str19, 10, "no tag of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str20, 17, " is a version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str21, 20, " (vA.B.C, its major ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str22, 1, ")");
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str0), heff_dup(v_path_240)), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0_clo)});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_244}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam5(V self, V *args) {
  V v_best_2427 = args[0];
  V v_line_2428 = args[1];
  V v_path_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_2429 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str10), v_line_2428, MK_INT(0LL), NTAG(TAG_Nil)));
  switch (heff_tag_of(v_it_2429)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_2427;
  }
  case TAG_Cons: {
    V v_it2_2431 = heff_field(v_it_2429, 1);
    heff_take_n(v_it_2429, 2ULL, 2);
    switch (heff_tag_of(v_it2_2431)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      return v_best_2427;
    }
    case TAG_Cons: {
      V v_v_2432 = heff_field(v_it2_2431, 0);
      V v_it22_2433 = heff_field(v_it2_2431, 1);
      heff_take_n(v_it2_2431, 3ULL, 2);
      switch (heff_tag_of(v_it22_2433)) {
      case TAG_Nil: {
        V v_t_2434 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2435 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
        V v_t_2436 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2435, MK_INT(-1LL)));
        V v_t_2437 = heff_strSlice(heff_dup(v_v_2432), v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
        V v_t_2438 = (g_heff_2ebuild_2eproject_2eversion(v_t_2437));
        switch (heff_tag_of(v_t_2438)) {
        case TAG_Nothing: {
          heff_drop(v_path_240);
          heff_drop(v_v_2432);
          return v_best_2427;
        }
        case TAG_Just: {
          V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 0ULL, 1);
          V v_t_2440 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2441 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
          V v_t_2442 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2441, MK_INT(-1LL)));
          V v_t_2443 = heff_strSlice(heff_dup(v_v_2432), v_t_2440, heff_intAdd(v_t_2442, MK_INT(1LL)));
          V v_t_2444 = (g_heff_2ebuild_2eproject_2emajorMismatch(v_path_240, v_t_2443));
          switch (heff_tag_of(v_t_2444)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_best_2427)) {
            case TAG_Nothing: {
              V v_t_2445 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2446 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
              V v_t_2447 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2446, MK_INT(-1LL)));
              V v_t_2448 = heff_strSlice(v_v_2432, v_t_2445, heff_intAdd(v_t_2447, MK_INT(1LL)));
              return heff_tag_at_n(v_ru_24t_2438_24Just, TAG_Just, 1, (V[]){v_t_2448});
            }
            case TAG_Just: {
              V v_b_2449 = heff_dup(heff_field(v_best_2427, 0));
              V v_t_2450 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
              V v_t_2451 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
              V v_t_2452 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2451, MK_INT(-1LL)));
              V v_a_2453 = heff_strSlice(heff_dup(v_v_2432), v_t_2450, heff_intAdd(v_t_2452, MK_INT(1LL)));
              V v_x2_2454 = (g_heff_2ebuild_2eproject_2eversion(v_a_2453));
              V v_t_2456;
              switch (heff_tag_of(v_x2_2454)) {
              case TAG_Nothing: {
                v_t_2456 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2455 = heff_field(v_x2_2454, 0);
                heff_take_n(v_x2_2454, 1ULL, 1);
                v_t_2456 = v_x_2455;
                break;
              }
              default: heff_nomatch(v_x2_2454);
              }
              V v_x2_2457 = (g_heff_2ebuild_2eproject_2eversion(v_b_2449));
              V v_t_2459;
              switch (heff_tag_of(v_x2_2457)) {
              case TAG_Nothing: {
                v_t_2459 = NTAG(TAG_Nil);
                break;
              }
              case TAG_Just: {
                V v_x_2458 = heff_field(v_x2_2457, 0);
                heff_take_n(v_x2_2457, 1ULL, 1);
                v_t_2459 = v_x_2458;
                break;
              }
              default: heff_nomatch(v_x2_2457);
              }
              V v_t_2460 = ({ V a_0 = v_t_2456; V a_1 = v_t_2459; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2456); heff_drop(v_t_2459); r_; });
              switch (heff_tag_of(v_t_2460)) {
              case TAG_True: {
                heff_drop_tag(v_best_2427, 1);
                V v_t_2461 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), MK_INT(0LL), MK_INT(1LL)));
                V v_t_2462 = heff_intSub(heff_strLength(heff_dup(v_v_2432)), MK_INT(1LL));
                V v_t_2463 = (g_prelude_2eskipSpaces(heff_dup(v_v_2432), v_t_2462, MK_INT(-1LL)));
                V v_t_2464 = heff_strSlice(v_v_2432, v_t_2461, heff_intAdd(v_t_2463, MK_INT(1LL)));
                return heff_tag_at_n(v_ru_24t_2438_24Just, TAG_Just, 1, (V[]){v_t_2464});
              }
              case TAG_False: {
                heff_drop(v_v_2432);
                heff_drop_cell(v_ru_24t_2438_24Just, 1);
                return v_best_2427;
              }
              default: return heff_nomatch(v_t_2460);
              }
            }
            default: return heff_nomatch(v_best_2427);
            }
          }
          case TAG_Just: {
            heff_take_n(v_t_2444, 0ULL, 1);
            heff_drop(v_v_2432);
            heff_drop_cell(v_ru_24t_2438_24Just, 1);
            return v_best_2427;
          }
          default: return heff_nomatch(v_t_2444);
          }
        }
        default: return heff_nomatch(v_t_2438);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2433, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop(v_v_2432);
        return v_best_2427;
      }
      default: return heff_nomatch(v_it22_2433);
      }
    }
    default: return heff_nomatch(v_it2_2431);
    }
  }
  default: return heff_nomatch(v_it_2429);
  }
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2416);
  V v_t_2418;
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_2414, 0)), MK_INT(0LL))) {
    v_t_2418 = NTAG(TAG_False);
  } else {
    v_t_2418 = NTAG(TAG_True);
  }
  V v_x_2487;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str6), (g_heff_2ebuild_2eproject_2erepoOf(v_path_240)));
    V v_s_2420 = heff_get_n(v_x_2414, 2, 3);
    V v_t_2421 = (g_prelude_2eskipSpaces(heff_dup(v_s_2420), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2422 = heff_intSub(heff_strLength(heff_dup(v_s_2420)), MK_INT(1LL));
    V v_t_2423 = (g_prelude_2eskipSpaces(heff_dup(v_s_2420), v_t_2422, MK_INT(-1LL)));
    V v_t_2424 = heff_strSlice(v_s_2420, v_t_2421, heff_intAdd(v_t_2423, MK_INT(1LL)));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str7), heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str8), v_t_2424)));
    v_x_2487 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2425});
    break;
  }
  case TAG_False: {
    V v_t_2426 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str9), heff_get_n(v_x_2414, 1, 3), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2468 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam5, 2, 1, (V[]){heff_dup(v_path_240)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
    switch (heff_tag_of(v_t_2468)) {
    case TAG_Nothing: {
      V v_t_2469 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str11), (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240))));
      V v_xs_2470 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str12), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2470));
      V v_x_2474;
      switch (heff_tag_of(v_t_2471)) {
      case TAG_Nil: {
        v_x_2474 = heff_dup(v_path_240);
        break;
      }
      case TAG_Cons: {
        V v_x_2472 = heff_field(v_t_2471, 0);
        heff_take_n(v_t_2471, 1ULL, 2);
        v_x_2474 = v_x_2472;
        break;
      }
      default: heff_nomatch(v_t_2471);
      }
      V v_t_2484;
      if (heff_intLe_c(MK_INT(2LL), heff_strLength(heff_dup(v_x_2474)))) {
        if (heff_strEq_c(heff_strSlice(heff_dup(v_x_2474), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str13))) {
          V v_t_2477 = heff_strSlice(heff_dup(v_x_2474), MK_INT(1LL), heff_strLength(v_x_2474));
          V v_t_2478 = (g_heff_2ebuild_2eproject_2eisNumber(v_t_2477));
          switch (heff_tag_of(v_t_2478)) {
          case TAG_True: {
            V v_xs_2479 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str14), heff_dup(v_path_240), MK_INT(0LL), NTAG(TAG_Nil)));
            V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2479));
            V v_t_2483;
            switch (heff_tag_of(v_t_2480)) {
            case TAG_Nil: {
              v_t_2483 = heff_dup(v_path_240);
              break;
            }
            case TAG_Cons: {
              V v_x_2481 = heff_field(v_t_2480, 0);
              heff_take_n(v_t_2480, 1ULL, 2);
              v_t_2483 = v_x_2481;
              break;
            }
            default: heff_nomatch(v_t_2480);
            }
            v_t_2484 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str15), v_t_2483);
            break;
          }
          case TAG_False: {
            v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str16);
            break;
          }
          default: heff_nomatch(v_t_2478);
          }
        } else {
          heff_drop(v_x_2474);
          v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str17);
        }
      } else {
        heff_drop(v_x_2474);
        v_t_2484 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str18);
      }
      V v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str19), heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str20), heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str21), heff_strAppend(v_t_2484, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str22)))))));
      v_x_2487 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2485});
      break;
    }
    case TAG_Just: {
      V v_v_2486 = heff_field(v_t_2468, 0);
      V v_ru_24t_2468_24Just = heff_take_reuse_n(v_t_2468, 1ULL, 1);
      heff_drop(v_path_240);
      v_x_2487 = heff_tag_at_n(v_ru_24t_2468_24Just, TAG_Right, 1, (V[]){v_v_2486});
      break;
    }
    default: heff_nomatch(v_t_2468);
    }
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V f_ = v_k_242;
  args[0] = v_x_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_End, 2, (V[]){v_x_245, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2415}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam4, 1, 3, (V[]){v_x_2414, v_path_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str1), (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240))));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str3), v_t_247})});
  V v_as_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str4), v_t_248});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_str5), v_as_249, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_lam3, 1, 4, (V[]){v_x_245, v_hd_241, v_path_240, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str0, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str2, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str5, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str6, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str7, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str8, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str10, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str12, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str13, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str14, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str16, 34, "heff get: cannot write package.hf\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str17, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str18, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str19, 1, "\012");
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam16(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch(heff_dup(v_path_243), heff_dup(v_v_244)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_c_246 = (g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam0, 2, 6, (V[]){v_c_246, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  }
  case TAG_Just: {
    V v_why_2488 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_text_241);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_v_244);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam16, 2, 2, (V[]){v_path_243, v_why_2488});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam3, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2443);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s954557541x749476273(v_t_2442, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam6, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam7(V self, V *args) {
  V v_r_2445 = args[0];
  V v_path_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_2445, 1, 3), v_path_243);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam8(V self, V *args) {
  V v_r_2447 = args[0];
  V v_name_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_r_2447, 0, 3), v_name_2444);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2459);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2454);
  V v_t_2455 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s954557541x749476273(v_t_2458, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam10, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11(V self, V *args) {
  V v_ok_2467 = args[0];
  return v_ok_2467;
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam13(V self, V *args) {
  V v_x_2477 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2477);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam15(V self, V *args) {
  V v_x_2487 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2487);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam14(V self, V *args) {
  V v_x_2482 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  return (g_co_2eop_24s954557541x749476273(v_t_2486, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam15, 1, 1, (V[]){v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam12(V self, V *args) {
  V v_x_2471 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_v_244 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2471)) {
  case TAG_True: {
    V v_t_2472 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str13), heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str14), v_v_244)));
    V v_t_2473 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2472, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str15)), NTAG(TAG_MkUnit)});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    return (g_co_2eop_24s954557541x749476273(v_t_2476, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam13, 1, 1, (V[]){v_k_248})));
  }
  case TAG_False: {
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    V v_t_2478 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str16), NTAG(TAG_MkUnit)});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    return (g_co_2eop_24s954557541x749476273(v_t_2481, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam14, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2471);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_why_2432 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    heff_drop(v_path_243);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_v_244);
    heff_drop(v_text_241);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str3), v_why_2432), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str4));
    V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    return (g_co_2eop_24s954557541x749476273(v_t_2437, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam5, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  case TAG_Right: {
    V v_name_2444 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    V v_x1_2446 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam7, 1, 1, (V[]){heff_dup(v_path_243)}), heff_rfield(v_pk_242, 2)));
    V v_t_2448;
    switch (heff_tag_of(v_x1_2446)) {
    case TAG_True: {
      v_t_2448 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2448 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam8, 1, 1, (V[]){heff_dup(v_name_2444)}), heff_rfield(v_pk_242, 2)));
      break;
    }
    default: heff_nomatch(v_x1_2446);
    }
    switch (heff_tag_of(v_t_2448)) {
    case TAG_True: {
      heff_drop_rec(v_pk_242, 4);
      heff_drop(v_v_244);
      heff_drop(v_text_241);
      V v_t_2449 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str5), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str6), heff_strAppend(v_name_2444, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str7), heff_strAppend(v_path_243, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str8))))));
      V v_t_2450 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str9)), NTAG(TAG_MkUnit)});
      V v_t_2451 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      return (g_co_2eop_24s954557541x749476273(v_t_2453, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam9, 1, 2, (V[]){v_hd_247, v_k_248})));
    }
    case TAG_False: {
      V v_t_2460 = (g_heff_2ebuild_2ecommands_2erequiring(v_pk_242, v_name_2444, heff_dup(v_path_243), heff_dup(v_v_244)));
      V v_text_2461 = (g_heff_2ebuild_2eproject_2ewithPackage(v_text_241, v_t_2460));
      V v_str_2466;
      if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str10), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str11))) {
        V v_t_2463 = (g_heff_2esyntax_2eformat_2eformat(heff_dup(v_text_2461)));
        switch (heff_tag_of(v_t_2463)) {
        case TAG_Left: {
          heff_take_n(v_t_2463, 0ULL, 1);
          v_str_2466 = v_text_2461;
          break;
        }
        case TAG_Right: {
          V v_out_2465 = heff_field(v_t_2463, 0);
          heff_take_n(v_t_2463, 1ULL, 1);
          heff_drop(v_text_2461);
          v_str_2466 = v_out_2465;
          break;
        }
        default: heff_nomatch(v_t_2463);
        }
      } else {
        v_str_2466 = v_text_2461;
      }
      V v_t_2468 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str12), v_str_2466, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam11_clo)})});
      V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
      V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
      return (g_co_2eop_24s954557541x749476273(v_t_2470, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam12, 1, 4, (V[]){v_path_243, v_v_244, v_hd_247, v_k_248})));
    }
    default: return heff_nomatch(v_t_2448);
    }
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_text_241);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str0), v_why_2410), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str1));
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam2, 1, 2, (V[]){v_hd_247, v_k_248})));
  }
  case TAG_Right: {
    heff_take_n(v_x_249, 0ULL, 1);
    V v_st_2423 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_a_2424 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_t_2425 = (g_std_2epath_2eparse(v_st_2423, v_a_2424));
    V v_t_2426 = (g_std_2epath_2eparse(v_st_2423, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str2)));
    V v_p_2427 = (g_std_2epath_2ejoin_2eonto_240(v_t_2425, v_t_2426));
    V v_t_2428 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2427, 1)), heff_rfield(v_p_2427, 2)));
    V v_t_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_n(v_p_2427, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2430 = ({ V a_0 = v_st_2423; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2423); r_; });
    return (g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(v_ps_240, v_t_2430, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam4, 1, 6, (V[]){v_hd_247, v_k_248, v_path_243, v_pk_242, v_v_244, v_text_241})));
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam1, 1, 7, (V[]){v_hd_247, v_k_248, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam18(V self, V *args) {
  V v_x_24101 = args[0];
  V v_k_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24101);
  V f_ = v_k_2490;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam17(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_2489 = heff_env(self)[0];
  V v_k_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2496);
  V v_t_2497 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  return (g_co_2eop_24s954557541x749476273(v_t_24100, v_hd_2489, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam18, 1, 1, (V[]){v_k_2490})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam16(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_path_243 = heff_env(self)[0];
  V v_why_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2491 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str17), heff_strAppend(v_path_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str18), v_why_2488)));
  V v_t_2492 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2491, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_str19)), NTAG(TAG_MkUnit)});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s954557541x749476273(v_t_2495, heff_dup(v_hd_2489), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_lam17, 1, 2, (V[]){v_hd_2489, v_k_2490})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str3, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str7, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str8, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str9, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str11, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str12, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str13, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str15, 1, "@");
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(V v_spec_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str0), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_spec_240}));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam4(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s954557541x749476273(v_t_2455, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam7(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2483);
  V f_ = v_k_2484;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_2482});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam9(V self, V *args) {
  V v_x_2493 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2493);
  V v_t_2494 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  return (g_co_2eop_24s954557541x749476273(v_t_2497, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam10(V self, V *args) {
  V v_x_24105 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24105);
  V v_t_24106 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s954557541x749476273(v_t_24109, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam11(V self, V *args) {
  V v_x_24123 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_24123)) {
  case TAG_True: {
    V f_ = heff_dup(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get());
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_24123);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam8(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_s_2433 = heff_env(self)[2];
  V v_x_2459 = heff_env(self)[3];
  V v_t_2417 = heff_env(self)[4];
  V v_pk_2432 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Left: {
    V v_why_2487 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Left = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    heff_drop(v_s_2433);
    heff_drop(v_x_2459);
    heff_drop(v_t_2417);
    heff_drop(v_pk_2432);
    V v_t_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str9), v_why_2487), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str10));
    V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2488, NTAG(TAG_MkUnit)});
    V v_t_2490 = heff_tag_at_n(v_ru_24x_2486_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    return (g_co_2eop_24s954557541x749476273(v_t_2492, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam9, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_ver_2498 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Right = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    V v_t_2499 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_ver_2498)));
    switch (heff_tag_of(v_t_2499)) {
    case TAG_Nothing: {
      heff_drop(v_s_2433);
      heff_drop(v_x_2459);
      heff_drop(v_t_2417);
      heff_drop(v_pk_2432);
      V v_t_24100 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str11), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str12), heff_strAppend(v_ver_2498, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str13))));
      V v_t_24101 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24100, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str14)), NTAG(TAG_MkUnit)});
      V v_t_24102 = heff_tag_at_n(v_ru_24x_2486_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
      V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
      V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
      return (g_co_2eop_24s954557541x749476273(v_t_24104, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam10, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_Just: {
      heff_take_n(v_t_2499, 0ULL, 1);
      V v_it_24111 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str15), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_x1_24118;
      switch (heff_tag_of(v_it_24111)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2486_24Right, 1);
        v_x1_24118 = heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2433, NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_path_24112 = heff_field(v_it_24111, 0);
        V v_it2_24113 = heff_field(v_it_24111, 1);
        V v_ru_24it_24111_24Cons = heff_take_reuse_n(v_it_24111, 3ULL, 2);
        switch (heff_tag_of(v_it2_24113)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x_2486_24Right, 1);
          heff_drop(v_path_24112);
          v_x1_24118 = heff_tag_at_n(v_ru_24it_24111_24Cons, TAG_MkPair, 2, (V[]){v_s_2433, NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_v_24114 = heff_field(v_it2_24113, 0);
          V v_it22_24115 = heff_field(v_it2_24113, 1);
          heff_take_n(v_it2_24113, 3ULL, 2);
          switch (heff_tag_of(v_it22_24115)) {
          case TAG_Nil: {
            heff_drop(v_s_2433);
            v_x1_24118 = heff_tag_at_n(v_ru_24it_24111_24Cons, TAG_MkPair, 2, (V[]){v_path_24112, heff_tag_at_n(v_ru_24x_2486_24Right, TAG_Just, 1, (V[]){v_v_24114})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it22_24115, 0ULL, 2);
            heff_drop_cell(v_ru_24x_2486_24Right, 1);
            heff_drop(v_path_24112);
            heff_drop(v_v_24114);
            v_x1_24118 = heff_tag_at_n(v_ru_24it_24111_24Cons, TAG_MkPair, 2, (V[]){v_s_2433, NTAG(TAG_Nothing)});
            break;
          }
          default: heff_nomatch(v_it22_24115);
          }
          break;
        }
        default: heff_nomatch(v_it2_24113);
        }
        break;
      }
      default: heff_nomatch(v_it_24111);
      }
      V v_t_24121;
      switch (heff_tag_of(v_x1_24118)) {
      case TAG_MkPair: {
        V v_x_24119 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 2);
        v_t_24121 = v_x_24119;
        break;
      }
      default: heff_nomatch(v_x1_24118);
      }
      V v_c_24122 = (g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(v_x_2459, v_t_2417, v_pk_2432, v_t_24121, v_ver_2498));
      V f_ = v_c_24122;
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam11, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2499);
    }
  }
  default: return heff_nomatch(v_x_2486);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam6(V self, V *args) {
  V v_x_2459 = args[0];
  V v_s_2433 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_2417 = heff_env(self)[3];
  V v_pk_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2460 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str7), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2467;
  switch (heff_tag_of(v_it_2460)) {
  case TAG_Nil: {
    v_x1_2467 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
    break;
  }
  case TAG_Cons: {
    V v_path_2461 = heff_field(v_it_2460, 0);
    V v_it2_2462 = heff_field(v_it_2460, 1);
    V v_ru_24it_2460_24Cons = heff_take_reuse_n(v_it_2460, 3ULL, 2);
    switch (heff_tag_of(v_it2_2462)) {
    case TAG_Nil: {
      heff_drop(v_path_2461);
      v_x1_2467 = heff_tag_at_n(v_ru_24it_2460_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_v_2463 = heff_field(v_it2_2462, 0);
      V v_it22_2464 = heff_field(v_it2_2462, 1);
      heff_take_n(v_it2_2462, 3ULL, 2);
      switch (heff_tag_of(v_it22_2464)) {
      case TAG_Nil: {
        v_x1_2467 = heff_tag_at_n(v_ru_24it_2460_24Cons, TAG_MkPair, 2, (V[]){v_path_2461, heff_tag_n(TAG_Just, 1, (V[]){v_v_2463})});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2464, 0ULL, 2);
        heff_drop(v_path_2461);
        heff_drop(v_v_2463);
        v_x1_2467 = heff_tag_at_n(v_ru_24it_2460_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_it22_2464);
      }
      break;
    }
    default: heff_nomatch(v_it2_2462);
    }
    break;
  }
  default: heff_nomatch(v_it_2460);
  }
  V v_t_2470;
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_MkPair: {
    V v_y_2469 = heff_field(v_x1_2467, 1);
    heff_take_n(v_x1_2467, 2ULL, 2);
    v_t_2470 = v_y_2469;
    break;
  }
  default: heff_nomatch(v_x1_2467);
  }
  V v_c_2485;
  switch (heff_tag_of(v_t_2470)) {
  case TAG_Nothing: {
    V v_it_2471 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str8), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x1_2478;
    switch (heff_tag_of(v_it_2471)) {
    case TAG_Nil: {
      v_x1_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_path_2472 = heff_field(v_it_2471, 0);
      V v_it2_2473 = heff_field(v_it_2471, 1);
      V v_ru_24it_2471_24Cons = heff_take_reuse_n(v_it_2471, 3ULL, 2);
      switch (heff_tag_of(v_it2_2473)) {
      case TAG_Nil: {
        heff_drop(v_path_2472);
        v_x1_2478 = heff_tag_at_n(v_ru_24it_2471_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_v_2474 = heff_field(v_it2_2473, 0);
        V v_it22_2475 = heff_field(v_it2_2473, 1);
        heff_take_n(v_it2_2473, 3ULL, 2);
        switch (heff_tag_of(v_it22_2475)) {
        case TAG_Nil: {
          v_x1_2478 = heff_tag_at_n(v_ru_24it_2471_24Cons, TAG_MkPair, 2, (V[]){v_path_2472, heff_tag_n(TAG_Just, 1, (V[]){v_v_2474})});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2475, 0ULL, 2);
          heff_drop(v_path_2472);
          heff_drop(v_v_2474);
          v_x1_2478 = heff_tag_at_n(v_ru_24it_2471_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
          break;
        }
        default: heff_nomatch(v_it22_2475);
        }
        break;
      }
      default: heff_nomatch(v_it2_2473);
      }
      break;
    }
    default: heff_nomatch(v_it_2471);
    }
    V v_t_2481;
    switch (heff_tag_of(v_x1_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x1_2478, 0);
      heff_take_n(v_x1_2478, 1ULL, 2);
      v_t_2481 = v_x_2479;
      break;
    }
    default: heff_nomatch(v_x1_2478);
    }
    v_c_2485 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo), 1, (V[]){v_t_2481}));
    break;
  }
  case TAG_Just: {
    V v_v_2482 = heff_field(v_t_2470, 0);
    heff_take_n(v_t_2470, 1ULL, 1);
    v_c_2485 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam7, 2, 1, (V[]){v_v_2482});
    break;
  }
  default: heff_nomatch(v_t_2470);
  }
  V f_ = v_c_2485;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam8, 1, 6, (V[]){v_hd_241, v_k_242, v_s_2433, v_x_2459, v_t_2417, v_pk_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_s_2433 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_2417 = heff_env(self)[3];
  V v_pk_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2458 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_x_2457, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str6)));
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam6, 1, 5, (V[]){v_s_2433, v_hd_241, v_k_242, v_t_2417, v_pk_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_spec_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_spec_240);
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str1), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2417 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    V v_x1_2418 = (g_heff_2ebuild_2eproject_2epackageLit(heff_dup(v_t_2417)));
    V v_t_2421;
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Left: {
      V v_p_2419 = heff_field(v_x1_2418, 0);
      heff_take_n(v_x1_2418, 1ULL, 1);
      v_t_2421 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_Left, 1, (V[]){v_p_2419});
      break;
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x1_2418, 0);
      heff_take_n(v_x1_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x_247_24Just, 1);
      v_t_2421 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2418);
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Left: {
      V v_ru_24t_2421_24Left = heff_take_reuse_n(v_t_2421, 0ULL, 1);
      heff_drop(v_spec_240);
      heff_drop(v_t_2417);
      V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str2), NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_at_n(v_ru_24t_2421_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam3, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_Right: {
      V v_pk_2432 = heff_field(v_t_2421, 0);
      V v_ru_24t_2421_24Right = heff_take_reuse_n(v_t_2421, 1ULL, 1);
      switch (heff_tag_of(v_spec_240)) {
      case TAG_Nothing: {
        heff_drop(v_t_2417);
        heff_drop(v_pk_2432);
        heff_drop_cell(v_ru_24t_2421_24Right, 1);
        V f_ = heff_dup(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get());
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_s_2433 = heff_field(v_spec_240, 0);
        V v_ru_24spec_240_24Just = heff_take_reuse_n(v_spec_240, 1ULL, 1);
        V v_it_2434 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str3), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_x1_2441;
        switch (heff_tag_of(v_it_2434)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_2421_24Right, 1);
          v_x1_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_path_2435 = heff_field(v_it_2434, 0);
          V v_it2_2436 = heff_field(v_it_2434, 1);
          V v_ru_24it_2434_24Cons = heff_take_reuse_n(v_it_2434, 3ULL, 2);
          switch (heff_tag_of(v_it2_2436)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24t_2421_24Right, 1);
            heff_drop(v_path_2435);
            v_x1_2441 = heff_tag_at_n(v_ru_24it_2434_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
            break;
          }
          case TAG_Cons: {
            V v_v_2437 = heff_field(v_it2_2436, 0);
            V v_it22_2438 = heff_field(v_it2_2436, 1);
            heff_take_n(v_it2_2436, 3ULL, 2);
            switch (heff_tag_of(v_it22_2438)) {
            case TAG_Nil: {
              v_x1_2441 = heff_tag_at_n(v_ru_24it_2434_24Cons, TAG_MkPair, 2, (V[]){v_path_2435, heff_tag_at_n(v_ru_24t_2421_24Right, TAG_Just, 1, (V[]){v_v_2437})});
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_it22_2438, 0ULL, 2);
              heff_drop_cell(v_ru_24t_2421_24Right, 1);
              heff_drop(v_path_2435);
              heff_drop(v_v_2437);
              v_x1_2441 = heff_tag_at_n(v_ru_24it_2434_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
              break;
            }
            default: heff_nomatch(v_it22_2438);
            }
            break;
          }
          default: heff_nomatch(v_it2_2436);
          }
          break;
        }
        default: heff_nomatch(v_it_2434);
        }
        V v_t_2444;
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_MkPair: {
          V v_x_2442 = heff_field(v_x1_2441, 0);
          heff_take_n(v_x1_2441, 1ULL, 2);
          v_t_2444 = v_x_2442;
          break;
        }
        default: heff_nomatch(v_x1_2441);
        }
        if (heff_strEq_c(v_t_2444, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          heff_drop(v_t_2417);
          heff_drop(v_pk_2432);
          heff_drop(v_s_2433);
          V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str5));
          V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
          V v_t_2448 = heff_tag_at_n(v_ru_24spec_240_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
          V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
          V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
          return (g_co_2eop_24s954557541x749476273(v_t_2450, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam4, 1, 2, (V[]){v_hd_241, v_k_242})));
        } else {
          heff_drop_cell(v_ru_24spec_240_24Just, 1);
          V v_c_2456 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
          V f_ = v_c_2456;
          heff_room[0] = heff_dup(v_hd_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam5, 1, 5, (V[]){v_hd_241, v_s_2433, v_k_242, v_t_2417, v_pk_2432});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
      default: return heff_nomatch(v_spec_240);
      }
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam1, 2, 3, (V[]){v_p_245, v_rest_246, v_acc_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2(V self, V *args) {
  V v_ns_249 = args[0];
  return v_ns_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4(V self, V *args) {
  V v_s_2420 = args[0];
  return v_s_2420;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam6(V self, V *args) {
  V v_n_2428 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = (g_std_2epath_2eparse(v_x_2426, v_p_245));
  V v_t_2430 = (g_std_2epath_2eparse(v_x_2426, v_n_2428));
  V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
  V v_t_2432 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2431, 1)), heff_rfield(v_p_2431, 2)));
  V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_n(v_p_2431, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_x_2426; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_2426); r_; });
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ns_2419 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2426;
  if (heff_strEq_c(v_x_2424, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str1))) {
    v_x_2426 = NTAG(TAG_Windows);
  } else {
    v_x_2426 = NTAG(TAG_Posix);
  }
  V v_t_2427 = (g_list_2efilter_24s413688307x112671032(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str2), v_ns_2419));
  V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam6, 1, 2, (V[]){v_x_2426, v_p_245}), v_t_2427));
  V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2434, v_rest_246));
  V v_t_2436 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_2435, v_acc_241));
  V f_ = v_t_2436;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2414 = heff_intSub(heff_strLength(heff_dup(v_p_245)), MK_INT(3LL));
    V v_t_2415 = heff_strSlice(heff_dup(v_p_245), v_t_2414, heff_strLength(heff_dup(v_p_245)));
    if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_str0))) {
      V v_t_2417 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_245, v_acc_241})));
      V f_ = v_t_2417;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_245);
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_rest_246, v_acc_241));
      V f_ = v_t_2418;
      heff_room[0] = v_hd_247;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2419 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Just = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    V v_t_2421 = heff_tag_at_n(v_ru_24x_2413_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam4_clo)})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam5, 1, 6, (V[]){v_ns_2419, v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_p_245), ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_lam3, 1, 5, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_247, v_k_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str1, 1, ".");
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(V v_chk_240, V v_acc_241, V v_f_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam0, 2, 4, (V[]){v_c_243, v_f_242, v_acc_241, v_chk_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_245;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam9(V self, V *args) {
  V v_c_2422 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ps_2423 = heff_dup(heff_rfield(v_x_2418, 2));
  V v_d_2424 = heff_get_n(heff_get_n(v_x_2418, 2, 5), 1, 6);
  if (heff_strEq_c(heff_dup(v_d_2424), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str1))) {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop_rec(v_ps_2423, 6);
    heff_drop(v_d_2424);
    V v_x1_2426 = ({ V a_0 = heff_get_n(v_c_2422, 0, 13); V b_1 = heff_get_n(v_acc_241, 0, 2); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2426)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2426);
    }
  } else {
    V v_t_2427 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_2423), v_d_2424));
    V v_t_2428 = (g_heff_2ebuild_2eload_2efromCwd(heff_dup(v_ps_2423), heff_take_field(v_c_2422, 1)));
    V v_t_2429 = ({ V b_0 = heff_get_n(v_ps_2423, 5, 6); V a_1 = v_t_2427; V a_2 = v_t_2428; V r_ = (g_std_2epath_2eisUnder(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_2429)) {
    case TAG_True: {
      heff_drop(v_x_248);
      heff_drop(v_f_242);
      V v_x1_2430 = ({ V a_0 = heff_get_n(v_c_2422, 0, 13); V b_1 = heff_get_n(v_acc_241, 0, 2); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2430);
      }
    }
    case TAG_False: {
      V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(v_x_248, v_f_242));
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2422, 0)), v_t_2431)) {
        V v_x1_2433 = ({ V a_0 = heff_get_n(v_c_2422, 0, 13); V b_1 = heff_get_n(v_acc_241, 0, 2); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x1_2433)) {
        case TAG_True: {
          return NTAG(TAG_False);
        }
        case TAG_False: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x1_2433);
        }
      } else {
        heff_drop_rec(v_c_2422, 13);
        heff_drop_rec(v_acc_241, 2);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam11(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_list_2emap_24s1416288597x2006619516(heff_dup(v_x_2434)));
  V v_t_2439 = (g_prelude_2e_2b_2b(v_t_2438, heff_take_field(v_acc_241, 0)));
  V v_t_2440 = heff_intAdd(heff_get_n(v_acc_241, 1, 2), v_x_2419);
  V v_t_2441 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2434; V r_ = (g_list_2efoldl_24s844754919x2100408598(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); r_; });
  V v_x_2442 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2439, heff_intAdd(v_t_2440, v_t_2441)});
  V f_ = v_k_245;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2436}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam11, 1, 4, (V[]){v_x_2434, v_acc_241, v_x_2419, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2434 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam9, 1, 4, (V[]){v_x_2418, heff_dup(v_acc_241), v_x_248, v_f_242}), heff_get_n(v_x_2421, 0, 2)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_x_2434), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam10, 1, 6, (V[]){v_x_2416, v_hd_244, v_x_2434, v_acc_241, v_x_2419, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2420 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_2418)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam8, 1, 8, (V[]){v_x_2418, v_acc_241, v_x_248, v_f_242, v_hd_244, v_x_2416, v_x_2419, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str0), heff_dup(heff_rfield(v_x_2418, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam7, 1, 7, (V[]){v_x_2418, v_hd_244, v_acc_241, v_x_248, v_f_242, v_x_2416, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_242)));
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam6, 1, 6, (V[]){v_hd_244, v_acc_241, v_x_248, v_f_242, v_x_2416, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_chk_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
  V v_t_2410 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_t_249, heff_rfield(v_acc_241, 0)));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    V v_t_2411 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_240, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2411}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam3, 1, 2, (V[]){v_k_245, v_acc_241})));
  }
  case TAG_False: {
    V v_name_2413 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_240, v_name_2413, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam5, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_x_248, v_k_245})));
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_x_246, heff_dup(v_f_242)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam2, 1, 5, (V[]){v_f_242, v_acc_241, v_chk_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam1, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_chk_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V v_chk_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1, 2, 3, (V[]){v_c_247, v_chk_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_chk_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_chk_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_lam2, 1, 4, (V[]){v_chk_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(V v_path_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1, 1, 3, (V[]){v_path_240, v_hd_241, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam0(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2414;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_x_2414 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2412, 0ULL, 1);
    v_x_2414 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_242;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_240, ((V)&g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam2_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914_lam3, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_247, 0ULL, 1);
    heff_drop(v_path_240);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(V v_st_240, V v_t_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 0))));
    V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_249 = (g_std_2epath_2ejoin_2eonto_240(v_t_247, v_t_248));
    V v_t_2410 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_249, 1)), heff_rfield(v_p_249, 2)));
    V v_t_2411 = ({ V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_n(v_p_249, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2412 = (g_std_2epath_2erender(v_st_240, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam1, 2, 5, (V[]){v_t_2412, heff_dup(v_st_240), v_t_241, v_rest_246, v_n_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_n_245 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2418;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_True: {
    heff_drop(v_n_245);
    v_x_2418 = v_x_2417;
    break;
  }
  case TAG_False: {
    v_x_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_245, v_x_2417});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2414;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2416 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam3, 1, 3, (V[]){v_x_2415, v_n_245, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eisThere_24s2146172465x1457343914(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_lam2, 1, 6, (V[]){v_st_240, v_t_241, v_rest_246, v_hd_2413, v_n_245, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str5, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str6, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_z_246);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_n(v_acc_242, 2ULL, 2, shape_apps__bad); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_249});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str0)));
    V v_x2_2413 = (g_list_2emap_24s499977176x606563528(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str1), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str2), v_missing_245));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_str_2417 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str6))));
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2417, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_str7)), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s954557541x749476273(v_t_2421, v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_lam0, 1, 2, (V[]){v_acc_242, v_z_247})));
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2424 = ({ V rv_1 = v_t_2423; V rr_ = heff_rec_reuse_n(v_acc_242, 1ULL, 2, shape_apps__bad); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    heff_drop(v_x_243);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = (g_heff_2ebuild_2eproject_2ereadBuild(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2410 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str0)));
      V v_str_2411 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2410, v_text_247, v_p_249));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam1, 2, 2, (V[]){v_str_2411, v_acc_242});
    }
    case TAG_Right: {
      V v_a_2421 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_text_247);
      V v_c_2422 = (g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(v_st_240, heff_dup(v_t_241), heff_dup(heff_rfield(v_a_2421, 2))));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam3, 2, 6, (V[]){v_c_2422, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2421});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2420 = ({ V rv_1 = v_t_2419; V rr_ = heff_rec_reuse_n(v_acc_242, 1ULL, 2, shape_apps__bad); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2413;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_str_2411 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2411, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str1)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam2, 1, 2, (V[]){v_acc_242, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2421 = heff_env(self)[4];
  V v_hd_2423 = heff_env(self)[5];
  V v_k_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2421; V a_5 = v_x_2425; V a_6 = v_hd_2423; V a_7 = v_k_2424; V r_ = (g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam4, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2421, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(V v_st_240, V v_t_241, V v_rd_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_rd_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 0)));
    V v_x_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_n(v_acc_243, 2ULL, 2, shape_apps__bad); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x5_244, 0);
    V v_rest_2410 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_path_2411 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_str0)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam1, 2, 7, (V[]){v_path_2411, heff_dup(v_st_240), v_t_241, v_acc_243, v_x_249, v_rd_242, v_rest_2410});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rd_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2422);
  V v_t_2423 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rd_242; V a_3 = v_x_2420; V a_4 = v_rest_2410; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  V f_ = v_t_2423;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2421}), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam5, 1, 7, (V[]){v_st_240, v_t_241, v_rd_242, v_x_2420, v_rest_2410, v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2419 = (g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(v_st_240, heff_dup(v_t_241), v_acc_243, v_x_249, v_x_2418));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam4, 1, 6, (V[]){v_rd_242, v_hd_2412, v_st_240, v_t_241, v_rest_2410, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam3, 1, 8, (V[]){v_st_240, v_t_241, v_acc_243, v_x_249, v_hd_2412, v_rd_242, v_rest_2410, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str1, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str3, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str4, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str5, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str6, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str7, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str8, 37, "heff build: `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957(V v_st_240, V v_t_241, V v_p_242, V v_x_243, V v_next_244) {
top: ;
  V v_path_245 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam0, 2, 6, (V[]){v_path_245, heff_dup(v_st_240), v_t_241, v_x_243, v_p_242, v_next_244});
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam1(V self, V *args) {
  V v_ns_248 = args[0];
  return v_ns_248;
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2417 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_240, v_t_241, v_x_243));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, v_a_2417));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_n_2416));
  V v_p_2420 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2419));
  V v_t_2421 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2420, 1)), heff_rfield(v_p_2420, 2)));
  V v_t_2422 = ({ V rv_2 = v_t_2421; V rr_ = heff_rec_reuse_n(v_p_2420, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_st_240; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam4(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam6(V self, V *args) {
  V v_r_2436 = args[0];
  return v_r_2436;
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam10(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s954557541x749476273(v_t_2456, v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2446);
  V v_str_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str8), ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_243); V a_3 = v_x_243; V r_ = (g_heff_2ebuild_2ecommands_2ebuiltAt(a_0, a_1, a_2, a_3)); heff_drop(v_st_240); r_; }));
  V v_t_2448 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2447, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str9)), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s954557541x749476273(v_t_2451, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam10, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2438 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2440);
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_2438, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_x_2438, 3);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_243);
    V f_ = v_next_244;
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_244);
    V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2438, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    return (g_co_2eop_24s954557541x749476273(v_t_2445, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam9, 1, 5, (V[]){v_st_240, v_t_241, v_x_243, v_hd_246, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_next_244 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2439 = heff_tag_n(TAG_End, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2439}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam8, 1, 7, (V[]){v_x_2438, v_next_244, v_hd_246, v_k_247, v_st_240, v_t_241, v_x_243})));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str3), NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_t_241, 5)), v_t_2429});
  V v_t_2431 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), heff_dup(v_x_243)));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str4), NTAG(TAG_Nil)});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str5), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_t_2432})});
  V v_t_2434 = (g_prelude_2e_2b_2b(v_x_2423, v_t_2433));
  V v_as_2435 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str6), v_t_2430}), v_t_2434));
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2428), ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str7), v_as_2435, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam6_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2437, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam7, 1, 7, (V[]){v_x_2428, v_hd_246, v_next_244, v_k_247, v_st_240, v_t_241, v_x_243})));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    heff_take_n(v_x_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2415 = (g_list_2efilter_24s1966237873x2134891024(((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str0), ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str1), v_t_2414));
  V v_x_2423 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam3, 1, 3, (V[]){heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_243)}), v_t_2415));
  V v_t_2424 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_x_2423));
  V v_total_2425 = heff_intAdd(v_t_2424, MK_INT(1LL));
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_242, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_str2), v_total_2425, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam4_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2427, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam5, 1, 7, (V[]){v_t_241, v_st_240, v_x_243, v_x_2423, v_hd_246, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_path_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_245, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam1_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957_lam2, 1, 7, (V[]){v_st_240, v_t_241, v_x_243, v_p_242, v_hd_246, v_next_244, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str2, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str4, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str5, 21, "compiling for Node.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str6, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str7, 2, "+x");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str8, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str9, 5, "chmod");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str10, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str11, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str12, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str13, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str14, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str15, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str16, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam21(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam21, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam23(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam23, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam27(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam26(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam25(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam24(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam20(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam29(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam28(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(V v_st_240, V v_t_241, V v_bp_242, V v_x_243, V v_a_244, V v_next_245, V v_p_246, V v_p_247) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str0))) {
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam1, 1, 7, (V[]){v_p_246, v_a_244, heff_dup(v_st_240), v_t_241, v_x_243, v_next_245, v_p_247})));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_a_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str4))) {
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8_clo)})});
      return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9, 1, 7, (V[]){v_p_246, heff_dup(v_st_240), v_t_241, v_x_243, v_a_244, v_next_245, v_p_247})));
    } else {
      V v_t_2459 = heff_dup(heff_rfield(v_t_241, 3));
      switch (heff_tag_of(v_t_2459)) {
      case TAG_True: {
        V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19_clo)})});
        return (g_co_2eop_24s954557541x749476273(v_t_2461, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam20, 1, 7, (V[]){v_p_246, heff_dup(v_st_240), v_t_241, v_x_243, v_a_244, v_next_245, v_p_247})));
      }
      case TAG_False: {
        heff_drop_rec(v_t_241, 6);
        heff_drop_rec(v_a_244, 3);
        V v_t_2482 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str14), heff_strAppend(v_x_243, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str15)));
        V v_t_2483 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2482, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str16)), NTAG(TAG_MkUnit)});
        V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
        V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
        V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
        return (g_co_2eop_24s954557541x749476273(v_t_2486, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam28, 1, 4, (V[]){v_bp_242, v_p_246, v_next_245, v_p_247})));
      }
      default: return heff_nomatch(v_t_2459);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2418;
  heff_room[1] = v_k_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2420}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam5, 1, 3, (V[]){v_next_245, v_hd_2418, v_k_2419})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_next_2422 = heff_env(self)[0];
  V v_hd_2423 = heff_env(self)[1];
  V v_k_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V f_ = v_next_2422;
  heff_room[0] = v_hd_2423;
  heff_room[1] = v_k_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_2414 = heff_env(self)[0];
  V v_next_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2425}), heff_dup(v_hd_2423), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam7, 1, 3, (V[]){v_next_2422, v_hd_2423, v_k_2424})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_244, 1, 3)});
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str2)));
  V v_next_2422 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2411); V a_3 = v_x_243; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam4, 2, 2, (V[]){v_x_2411, v_next_245}); V r_ = (g_heff_2ebuild_2ecommands_2ezigCc_24s1132803476x666277957(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  V v_t_2427 = (g_heff_2ebuild_2ecommands_2ecThen_24s1969914607x1330353918(v_t_2415, heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str3)), v_t_2417, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam6, 2, 2, (V[]){v_x_2414, v_next_2422})));
  V f_ = v_t_2427;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2411), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam3, 1, 8, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2411, v_next_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10(V self, V *args) {
  V v_t_2432 = args[0];
  return v_t_2432;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12(V self, V *args) {
  V v_ok_2436 = args[0];
  return v_ok_2436;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16(V self, V *args) {
  V v_r_2451 = args[0];
  return v_r_2451;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam18(V self, V *args) {
  V v_x_2457 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_k_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2457);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2447;
  heff_room[1] = v_k_2448;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam17(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_End, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2456}), heff_dup(v_hd_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam18, 1, 3, (V[]){v_next_245, v_hd_2447, v_k_2448})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam15(V self, V *args) {
  V v_x_2450 = args[0];
  V v_as_2446 = heff_env(self)[0];
  V v_hd_2447 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  V v_next_245 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2450);
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str9), v_as_2446, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_hd_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam17, 1, 4, (V[]){v_x_2431, v_hd_2447, v_next_245, v_k_2448})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam14(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_x_2434 = heff_env(self)[0];
  V v_as_2446 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  V v_next_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = heff_tag_n(TAG_End, 2, (V[]){v_x_2434, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2449}), heff_dup(v_hd_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam15, 1, 5, (V[]){v_as_2446, v_hd_2447, v_x_2431, v_next_245, v_k_2448})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13(V self, V *args) {
  V v_x_2440 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_x_2431 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_244, 1, 3)});
  V v_t_2442 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), heff_dup(v_x_243)));
  V v_t_2443 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str6)));
  V v_t_2444 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_243); V a_3 = v_x_243; V r_ = (g_heff_2ebuild_2ecommands_2ebuiltAt(a_0, a_1, a_2, a_3)); heff_drop(v_st_240); r_; });
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
  V v_as_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str7), v_t_2445});
  V v_t_2458 = (g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str8), v_t_2441, v_t_2442, v_t_2443, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam14, 2, 4, (V[]){v_x_2434, v_as_2446, v_x_2431, v_next_245})));
  V f_ = v_t_2458;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_x_2431 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2435 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2435, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12_clo)})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s954557541x749476273(v_t_2439, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13, 1, 9, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2434, v_x_2431, v_next_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2431), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str5), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11, 1, 8, (V[]){v_st_240, v_t_241, v_x_243, v_p_246, v_a_244, v_x_2431, v_next_245, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19(V self, V *args) {
  V v_t_2460 = args[0];
  return v_t_2460;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam21(V self, V *args) {
  V v_t_2463 = args[0];
  return v_t_2463;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam23(V self, V *args) {
  V v_ok_2467 = args[0];
  return v_ok_2467;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam27(V self, V *args) {
  V v_x_2480 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2475 = heff_env(self)[1];
  V v_k_2476 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2480);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2475;
  heff_room[1] = v_k_2476;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam26(V self, V *args) {
  V v_x_2478 = args[0];
  V v_x_2462 = heff_env(self)[0];
  V v_hd_2475 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_k_2476 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2478);
  V v_t_2479 = heff_tag_n(TAG_End, 2, (V[]){v_x_2462, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2479}), heff_dup(v_hd_2475), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam27, 1, 3, (V[]){v_next_245, v_hd_2475, v_k_2476})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam25(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_x_2465 = heff_env(self)[0];
  V v_x_2462 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2477 = heff_tag_n(TAG_End, 2, (V[]){v_x_2465, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2477}), heff_dup(v_hd_2475), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam26, 1, 4, (V[]){v_x_2462, v_hd_2475, v_next_245, v_k_2476})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam24(V self, V *args) {
  V v_x_2471 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2465 = heff_env(self)[4];
  V v_x_2462 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2471);
  V v_t_2472 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_244, 1, 3)});
  V v_t_2473 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str11))));
  V v_t_2474 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_243; V a_3 = ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str12); V r_ = (g_heff_2ebuild_2ecommands_2eappFile(a_0, a_1, a_2, a_3)); heff_drop(v_st_240); r_; });
  V v_t_2481 = (g_heff_2ebuild_2ecommands_2ecompileThen_24s972834034x1971894409(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str13), v_t_2472, v_t_2473, v_t_2474, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam25, 2, 3, (V[]){v_x_2465, v_x_2462, v_next_245})));
  V f_ = v_t_2481;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam22(V self, V *args) {
  V v_x_2465 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_x_2462 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2466 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_240, heff_dup(v_t_241), heff_dup(v_x_243)));
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2466, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam23_clo)})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  return (g_co_2eop_24s954557541x749476273(v_t_2470, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam24, 1, 9, (V[]){v_a_244, v_st_240, v_t_241, v_x_243, v_x_2465, v_x_2462, v_next_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam20(V self, V *args) {
  V v_x_2462 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2462), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str10), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam21_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2464, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam22, 1, 8, (V[]){v_st_240, v_t_241, v_x_243, v_p_246, v_a_244, v_x_2462, v_next_245, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam29(V self, V *args) {
  V v_x_2489 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2489);
  V f_ = v_next_245;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam28(V self, V *args) {
  V v_x_2487 = args[0];
  V v_bp_242 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2487);
  V v_t_2488 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_242, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2488}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam29, 1, 3, (V[]){v_next_245, v_p_246, v_p_247})));
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(V v_st_240, V v_t_241, V v_bp_242, V v_done_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_bp_242);
    return v_done_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_bp_242), v_done_243, v_rest_246));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo), 6, (V[]){v_st_240, v_t_241, v_bp_242, heff_dup(heff_rfield(v_a_245, 0)), heff_dup(heff_rfield(v_a_245, 1)), v_t_247});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str3, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str4, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_True: {
    heff_drop(v_fresh_241);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_old_242, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_p_246, v_next_244, v_p_247})));
  }
  case TAG_False: {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_old_242, heff_dup(v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3_clo)})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    return (g_co_2eop_24s954557541x749476273(v_t_2422, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam4, 1, 4, (V[]){v_fresh_241, v_p_246, v_to_243, v_p_247})));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2418);
  V f_ = v_next_244;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2412);
  V v_t_2413 = heff_strAppend(heff_get_n(v_t_240, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str0), v_to_243));
  V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str1)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam2, 1, 3, (V[]){v_next_244, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam3(V self, V *args) {
  V v_ok_2419 = args[0];
  return v_ok_2419;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5(V self, V *args) {
  V v_ok_2424 = args[0];
  return v_ok_2424;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s954557541x749476273(v_t_2438, v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_p_246 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str2), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str3), heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str4), v_to_243))));
  V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_str5)), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam7, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_fresh_241), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam5_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s954557541x749476273(v_t_2427, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_p_246, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str4, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str5, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_n_245, v_hd_246, v_t_241, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4(V self, V *args) {
  V v_ok_2430 = args[0];
  return v_ok_2430;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6(V self, V *args) {
  V v_ok_2441 = args[0];
  return v_ok_2441;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8(V self, V *args) {
  V v_ok_2452 = args[0];
  return v_ok_2452;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10(V self, V *args) {
  V v_ok_2463 = args[0];
  return v_ok_2463;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13(V self, V *args) {
  V v_x_2477 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2474 = heff_env(self)[1];
  V v_k_2475 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2477);
  V f_ = v_next_244;
  heff_room[0] = v_hd_2474;
  heff_room[1] = v_k_2475;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_x_2410 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476 = heff_tag_n(TAG_End, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2476}), heff_dup(v_hd_2474), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam13, 1, 3, (V[]){v_next_244, v_hd_2474, v_k_2475})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11(V self, V *args) {
  V v_x_2467 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  V v_x_2410 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2468 = (g_std_2epath_2eparse(v_st_240, v_home_242));
  V v_t_2469 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_2470 = (g_std_2epath_2ejoin_2eonto_240(v_t_2468, v_t_2469));
  V v_t_2471 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2470, 1)), heff_rfield(v_p_2470, 2)));
  V v_t_2472 = ({ V rv_2 = v_t_2471; V rr_ = heff_rec_reuse_n(v_p_2470, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2473 = ({ V a_0 = v_st_240; V a_1 = v_t_2472; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  return ({ V a_0 = v_t_241; V a_1 = v_x_2417; V a_2 = v_x_2424; V a_3 = v_t_2473; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam12, 2, 2, (V[]){v_x_2410, v_next_244}); V a_5 = v_x_2467; V a_6 = v_hd_246; V a_7 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s498293488x2027461963(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2467); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2424 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2456);
  V v_t_2457 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2458 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2459 = (g_std_2epath_2ejoin_2eonto_240(v_t_2457, v_t_2458));
  V v_t_2460 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2459, 1)), heff_rfield(v_p_2459, 2)));
  V v_t_2461 = ({ V rv_2 = v_t_2460; V rr_ = heff_rec_reuse_n(v_p_2459, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_to_2462 = (g_std_2epath_2erender(v_st_240, v_t_2461));
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){heff_dup(v_x_2417), v_to_2462, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam10_clo)})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  return (g_co_2eop_24s954557541x749476273(v_t_2466, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam11, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_t_241, v_x_2417, v_x_2424, v_x_2410, v_next_244, v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14(V self, V *args) {
  V v_ok_2478 = args[0];
  return v_ok_2478;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16(V self, V *args) {
  V v_x_2495 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2496 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  return (g_co_2eop_24s954557541x749476273(v_t_2499, v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15(V self, V *args) {
  V v_x_2482 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2482);
  V v_t_2483 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2484 = (g_std_2epath_2eparse(v_st_240, v_n_245));
  V v_p_2485 = (g_std_2epath_2ejoin_2eonto_240(v_t_2483, v_t_2484));
  V v_t_2486 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2485, 1)), heff_rfield(v_p_2485, 2)));
  V v_t_2487 = ({ V rv_2 = v_t_2486; V rr_ = heff_rec_reuse_n(v_p_2485, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2488 = ({ V a_0 = v_st_240; V a_1 = v_t_2487; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  V v_why_2489 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str4), heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str5), v_x_2417)));
  V v_t_2490 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str6), v_why_2489), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str7));
  V v_t_2491 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2490, NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  return (g_co_2eop_24s954557541x749476273(v_t_2494, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam16, 1, 2, (V[]){v_hd_246, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_t_241 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2445)) {
  case TAG_True: {
    V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
    V v_t_2447 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
    V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
    V v_t_2449 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2448, 1)), heff_rfield(v_p_2448, 2)));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_n(v_p_2448, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_path_2451 = (g_std_2epath_2erender(v_st_240, v_t_2450));
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Move, 3, (V[]){v_path_2451, heff_dup(v_x_2424), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam8_clo)})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    return (g_co_2eop_24s954557541x749476273(v_t_2455, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam9, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2417, v_hd_246, v_t_241, v_x_2424, v_x_2410, v_next_244, v_k_247})));
  }
  case TAG_False: {
    heff_drop(v_home_242);
    heff_drop(v_x_2424);
    heff_drop(v_x_2410);
    heff_drop(v_next_244);
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2417), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam14_clo)})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    return (g_co_2eop_24s954557541x749476273(v_t_2481, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam15, 1, 6, (V[]){v_st_240, v_t_241, v_n_245, v_x_2417, v_hd_246, v_k_247})));
  }
  default: return heff_nomatch(v_x_2445);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_home_242 = heff_env(self)[5];
  V v_x_2424 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2434);
  V v_t_2435 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2436 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_245)));
  V v_p_2437 = (g_std_2epath_2ejoin_2eonto_240(v_t_2435, v_t_2436));
  V v_t_2438 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2437, 1)), heff_rfield(v_p_2437, 2)));
  V v_t_2439 = ({ V rv_2 = v_t_2438; V rr_ = heff_rec_reuse_n(v_p_2437, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2440 = (g_std_2epath_2erender(v_st_240, v_t_2439));
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2440, heff_dup(v_x_2417), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam6_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam7, 1, 10, (V[]){v_st_240, v_home_242, v_n_245, v_x_2424, v_hd_246, v_x_2417, v_t_241, v_x_2410, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_home_242 = heff_env(self)[6];
  V v_x_2410 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2429);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2424), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam4_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam5, 1, 10, (V[]){v_st_240, v_t_241, v_n_245, v_x_2417, v_hd_246, v_home_242, v_x_2424, v_x_2410, v_next_244, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str0), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str1)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, v_t_2412));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2413));
  V v_t_2415 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2414, 1)), heff_rfield(v_p_2414, 2)));
  V v_t_2416 = ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_n(v_p_2414, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str2), heff_strAppend(heff_dup(v_n_245), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_str3)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_240, v_t_2419));
  V v_p_2421 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2420));
  V v_t_2422 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2421, 1)), heff_rfield(v_p_2421, 2)));
  V v_t_2423 = ({ V rv_2 = v_t_2422; V rr_ = heff_rec_reuse_n(v_p_2421, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2424 = (g_std_2epath_2erender(v_st_240, v_t_2423));
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2417), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam2_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_lam3, 1, 10, (V[]){v_x_2424, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2417, v_home_242, v_x_2410, v_next_244, v_k_247})));
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_home_242);
    heff_drop(v_sh_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    V v_t_248 = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_home_242), heff_dup(v_sh_243), v_next_244, v_rest_247));
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s143298736x1152649191_clo), 6, (V[]){v_st_240, v_t_241, v_home_242, v_sh_243, v_t_248, heff_dup(v_n_246)});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(V v_st_240, V v_t_241, V v_progs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_242);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0_clo);
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_242)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s620173997x1959585086(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_xs_249 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_248));
    V v_total_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_249; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1, 2, 5, (V[]){v_home_246, v_total_2410, v_progs_242, v_st_240, v_t_241});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam0(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  heff_drop(v_a_244);
  V f_ = v_a_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2422);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2421}), v_hd_2419, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam5, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_246 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_242));
  V v_xs_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s620173997x1959585086(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
  V v_t_2423 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_246; V a_3 = heff_dup(v_x_2415); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam4, 2, 1, (V[]){v_x_2415}); V a_5 = v_t_2418; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2418); r_; });
  V f_ = v_t_2423;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_home_246 = heff_env(self)[0];
  V v_total_2410 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_str0), heff_dup(v_home_246)), v_total_2410, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam2_clo)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2414}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061_lam3, 1, 6, (V[]){v_progs_242, v_st_240, v_t_241, v_home_246, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str5, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_244);
    V v_t_248 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_242, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_248}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
  }
  case TAG_Just: {
    V v_n_2410 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2412 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_242, heff_dup(v_n_2410), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2, 1, 7, (V[]){heff_dup(v_st_240), v_t_241, v_n_2410, v_p_246, v_x_244, v_next_243, v_p_247})));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_249);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7(V self, V *args) {
  V v_ok_2438 = args[0];
  return v_ok_2438;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2459);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2458}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam11, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12(V self, V *args) {
  V v_ok_2460 = args[0];
  return v_ok_2460;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14(V self, V *args) {
  V v_x_2477 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  return (g_co_2eop_24s954557541x749476273(v_t_2481, v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13(V self, V *args) {
  V v_x_2464 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2464);
  V v_t_2465 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), v_x_244, heff_dup(v_n_2410)));
  V v_t_2466 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 1, 6)));
  V v_t_2467 = (g_std_2epath_2eparse(v_st_240, v_n_2410));
  V v_p_2468 = (g_std_2epath_2ejoin_2eonto_240(v_t_2466, v_t_2467));
  V v_t_2469 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2468, 1)), heff_rfield(v_p_2468, 2)));
  V v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_n(v_p_2468, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_why_2471 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str4), heff_strAppend(v_t_2465, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str5), ({ V a_0 = v_st_240; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; }))));
  V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str6), v_why_2471), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str7));
  V v_t_2473 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2472, NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  return (g_co_2eop_24s954557541x749476273(v_t_2476, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam14, 1, 2, (V[]){v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_x_2420 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2445)) {
  case TAG_True: {
    heff_drop(v_x_2420);
    heff_drop(v_x_244);
    V v_t_2446 = (g_std_2epath_2eparse(v_st_240, heff_take_field(v_t_241, 1)));
    V v_t_2447 = (g_std_2epath_2eparse(v_st_240, v_n_2410));
    V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
    V v_t_2449 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2448, 1)), heff_rfield(v_p_2448, 2)));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_n(v_p_2448, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_path_2451 = ({ V a_0 = v_st_240; V a_1 = v_t_2450; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
    V v_t_2452 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str2), v_path_2451));
    V v_t_2453 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str3)), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam10, 1, 4, (V[]){v_x_2413, v_p_246, v_next_243, v_p_247})));
  }
  case TAG_False: {
    heff_drop(v_x_2413);
    heff_drop(v_next_243);
    V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_2420, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam12_clo)})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    return (g_co_2eop_24s954557541x749476273(v_t_2463, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam13, 1, 6, (V[]){v_st_240, v_t_241, v_x_244, v_n_2410, v_p_246, v_p_247})));
  }
  default: return heff_nomatch(v_x_2445);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  V v_next_243 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2444;
  switch (heff_tag_of(v_x_2431)) {
  case TAG_True: {
    V v_t_2432 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 1))));
    V v_t_2433 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_n_2410)));
    V v_p_2434 = (g_std_2epath_2ejoin_2eonto_240(v_t_2432, v_t_2433));
    V v_t_2435 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2434, 1)), heff_rfield(v_p_2434, 2)));
    V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_n(v_p_2434, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_to_2437 = (g_std_2epath_2erender(v_st_240, v_t_2436));
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Replace, 3, (V[]){heff_dup(v_x_2420), v_to_2437, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam7_clo)})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    v_c_2444 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2441}));
    break;
  }
  case TAG_False: {
    v_c_2444 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam8_clo);
    break;
  }
  default: heff_nomatch(v_x_2431);
  }
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam9, 1, 9, (V[]){v_st_240, v_t_241, v_n_2410, v_p_246, v_x_2413, v_next_243, v_p_247, v_x_2420, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_next_243 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2425);
  V v_path_2426 = (g_heff_2ebuild_2ecommands_2ebuiltAt(v_st_240, heff_dup(v_t_241), heff_dup(v_x_244), heff_dup(v_n_2410)));
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Copy, 3, (V[]){v_path_2426, heff_dup(v_x_2420), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam5_clo)})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam6, 1, 9, (V[]){v_st_240, v_t_241, v_n_2410, v_x_2420, v_p_246, v_x_2413, v_next_243, v_p_247, v_x_244})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2410 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 1))));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str0), heff_strAppend(heff_dup(v_n_2410), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_str1)));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, v_t_2415));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2414, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_n(v_p_2417, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2420 = (g_std_2epath_2erender(v_st_240, v_t_2419));
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_2420), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam3_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_lam4, 1, 9, (V[]){v_st_240, v_t_241, v_x_244, v_n_2410, v_x_2420, v_p_246, v_x_2413, v_next_243, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str1, 4, "node");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str2, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_pl_242);
    return v_next_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_t_247 = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_pl_242), v_next_243, v_rest_246));
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_a_245, 1)), 0, 3);
    V v_t_2414;
    if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str0))) {
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_245, 0))});
    } else {
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_a_245, 1)), 0, 3);
      if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str1))) {
        v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_245, 0))});
      } else {
        V v_t_2412 = heff_dup(heff_rfield(v_t_241, 3));
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_a_245, 0)), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_str2));
          v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
          break;
        }
        case TAG_False: {
          v_t_2414 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
      }
    }
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1392088960x1890012238_clo), 6, (V[]){v_st_240, v_t_241, v_pl_242, v_t_247, heff_dup(heff_rfield(v_a_245, 0)), v_t_2414});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(V v_st_240, V v_t_241, V v_next_242, V v_progs_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_MkDir, 2, (V[]){heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1, 1, 6, (V[]){heff_dup(v_progs_243), v_t_241, v_hd_244, v_st_240, v_next_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_next_242 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V f_ = v_next_242;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_next_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2418}), heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam5, 1, 3, (V[]){v_next_242, v_hd_2416, v_k_2417})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_next_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2415); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam4, 2, 2, (V[]){v_x_2415, v_next_242}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1724763166x1297447000(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_244;
  heff_room[1] = v_k_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_next_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2410);
  V v_total_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_str0), heff_dup(heff_rfield(v_t_241, 1)));
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2412, v_total_2411, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_next_242, v_progs_243, v_hd_244, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(V v_st_240, V v_t_241, V v_progs_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str0)));
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str1)));
  V v_p_247 = (g_std_2epath_2ejoin_2eonto_240(v_t_245, v_t_246));
  V v_t_248 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_247, 1)), heff_rfield(v_p_247, 2)));
  V v_t_249 = ({ V rv_2 = v_t_248; V rr_ = heff_rec_reuse_n(v_p_247, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_p_2410 = (g_std_2epath_2erender(v_st_240, v_t_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, v_p_2410));
  V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
  V v_t_2414 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2413, 1)), heff_rfield(v_p_2413, 2)));
  V v_t_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_n(v_p_2413, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2416 = (g_std_2epath_2erender(v_st_240, v_t_2415));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2416, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam1, 1, 5, (V[]){v_progs_242, v_z_243, v_st_240, v_t_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam0(V self, V *args) {
  V v_ok_2417 = args[0];
  return v_ok_2417;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2(V self, V *args) {
  V v_t_2423 = args[0];
  return v_t_2423;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_t_2426 = heff_env(self)[2];
  V v_progs_242 = heff_env(self)[3];
  V v_hd_2427 = heff_env(self)[4];
  V v_k_2428 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2430);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_t_2426; V a_3 = v_progs_242; V a_4 = v_hd_2427; V a_5 = v_k_2428; V r_ = (g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_242); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2425 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_t_2426 = heff_env(self)[3];
  V v_progs_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429 = heff_tag_n(TAG_End, 2, (V[]){v_x_2425, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2429}), heff_dup(v_hd_2427), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam5, 1, 6, (V[]){v_st_240, v_t_241, v_t_2426, v_progs_242, v_hd_2427, v_k_2428})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = (g_heff_2ebuild_2ecommands_2eshipIn_24s538564638x273583061(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_progs_242), heff_dup(heff_rfield(v_t_241, 4))));
  V v_t_2431 = ({ V a_0 = heff_dup(v_st_240); V a_1 = heff_dup(v_t_241); V a_2 = heff_dup(v_x_2425); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam4, 2, 5, (V[]){v_x_2425, v_st_240, v_t_241, v_t_2426, heff_dup(v_progs_242)}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_242); r_; });
  V f_ = v_t_2431;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2421);
  V v_total_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_progs_242));
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_str2), v_total_2422, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_lam3, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_z_243, v_z_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str11, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str20, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str22, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(V v_st_240, V v_cmd_241, V v_t_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str0)));
  V v_p_247 = (g_std_2epath_2ejoin_2eonto_240(v_t_245, v_t_246));
  V v_t_248 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_247, 1)), heff_rfield(v_p_247, 2)));
  V v_t_249 = ({ V rv_2 = v_t_248; V rr_ = heff_rec_reuse_n(v_p_247, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2410 = (g_std_2epath_2erender(v_st_240, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_2411, NTAG(TAG_Nil)));
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam0, 1, 5, (V[]){v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s954557541x749476273(v_t_2437, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7(V self, V *args) {
  V v_ns_2453 = args[0];
  return v_ns_2453;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9(V self, V *args) {
  V v_t_2461 = args[0];
  return v_t_2461;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam13(V self, V *args) {
  V v_x_2481 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2481);
  V v_t_2482 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  return (g_co_2eop_24s954557541x749476273(v_t_2485, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam12(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2468 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2470);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2468, 1)))) {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_2472 = heff_get_n(v_x_2468, 1, 2);
    V v_t_2474;
    if (heff_intEq_c(heff_dup(v_n_2472), MK_INT(1LL))) {
      heff_drop(v_n_2472);
      v_t_2474 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str17);
    } else {
      v_t_2474 = heff_strAppend(heff_intShow(v_n_2472), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str18));
    }
    V v_what_2475 = heff_strAppend(v_t_2474, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str19));
    V v_t_2476 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str20), heff_strAppend(v_cmd_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str21), heff_strAppend(v_what_2475, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str22)))));
    V v_t_2477 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2476, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str23)), NTAG(TAG_MkUnit)});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    return (g_co_2eop_24s954557541x749476273(v_t_2480, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam13, 1, 2, (V[]){v_z_243, v_z_244})));
  } else {
    heff_drop(v_cmd_241);
    V v_t_2486 = heff_dup(heff_rfield(v_x_2468, 0));
    switch (heff_tag_of(v_t_2486)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2468, 2);
      heff_drop(v_z_243);
      heff_drop(v_st_240);
      heff_drop_rec(v_t_242, 6);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_2486, 0ULL, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(v_st_240, v_t_242, heff_get_n(v_x_2468, 0, 2), v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_t_2486);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_x_2463 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2469 = heff_tag_n(TAG_End, 2, (V[]){v_x_2463, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2469}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam12, 1, 6, (V[]){v_x_2468, v_cmd_241, v_z_243, v_z_244, v_st_240, v_t_242})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam10(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2457 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2464 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2466;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_Nothing: {
    v_t_2466 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2465 = heff_field(v_x_2457, 0);
    heff_take_n(v_x_2457, 1ULL, 1);
    v_t_2466 = v_x_2465;
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  V v_c_2467 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2463), v_t_2464, v_t_2466));
  V f_ = v_c_2467;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam11, 1, 6, (V[]){v_x_2463, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_xs_2459;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_Nothing: {
    v_xs_2459 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2458 = heff_dup(heff_field(v_x_2457, 0));
    v_xs_2459 = v_x_2458;
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  V v_total_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2459; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str16), v_total_2460, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2462, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam10, 1, 6, (V[]){v_x_2457, v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam6(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2446);
  V v_t_2447 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2448 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str15)));
  V v_p_2449 = (g_std_2epath_2ejoin_2eonto_240(v_t_2447, v_t_2448));
  V v_t_2450 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2449, 1)), heff_rfield(v_p_2449, 2)));
  V v_t_2451 = ({ V rv_2 = v_t_2450; V rr_ = heff_rec_reuse_n(v_p_2449, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2452 = (g_std_2epath_2erender(v_st_240, v_t_2451));
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_2452, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7_clo)})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam8, 1, 5, (V[]){v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2422);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2420, 1)))) {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_2424 = heff_get_n(v_x_2420, 1, 2);
    V v_t_2426;
    if (heff_intEq_c(heff_dup(v_n_2424), MK_INT(1LL))) {
      heff_drop(v_n_2424);
      v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str2);
    } else {
      v_t_2426 = heff_strAppend(heff_intShow(v_n_2424), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str3));
    }
    V v_what_2427 = heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str4));
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str5), heff_strAppend(v_cmd_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str6), heff_strAppend(v_what_2427, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str7)))));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str8)), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s954557541x749476273(v_t_2432, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam5, 1, 2, (V[]){v_z_243, v_z_244})));
  } else {
    V v_n_2438 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2420, 0, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2440;
    if (heff_intEq_c(heff_dup(v_n_2438), MK_INT(1LL))) {
      heff_drop(v_n_2438);
      v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str9);
    } else {
      v_t_2440 = heff_strAppend(heff_intShow(v_n_2438), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str10));
    }
    V v_str_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str11), heff_strAppend(heff_dup(v_cmd_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str12), heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str13)))));
    V v_t_2442 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2441, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str14)), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    return (g_co_2eop_24s954557541x749476273(v_t_2445, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam6, 1, 5, (V[]){v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2421}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam4, 1, 6, (V[]){v_x_2420, v_cmd_241, v_z_243, v_z_244, v_st_240, v_t_242})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2418 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2419 = ({ V a_0 = heff_dup(v_x_2417); V a_1 = v_t_2418; V a_2 = v_x_2413; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam3, 1, 6, (V[]){v_x_2417, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_total_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_x_2413));
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str1), v_total_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam2, 1, 6, (V[]){v_x_2413, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str2, 60, "heff build: no package.hf here: build at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str4, 5, "build");
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(v_t_245, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s954557541x749476273(v_t_2422, v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2413;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str1))) {
    v_x_2413 = NTAG(TAG_Windows);
  } else {
    v_x_2413 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_x_2413);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str2), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam4, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    heff_take_n(v_x_246, 0ULL, 1);
    V v_t_2424 = (g_heff_2ebuild_2ecommands_2ebuildTarget(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str3)));
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_str4), v_t_2424, v_hd_240, v_k_241));
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildCmd_24s1170024128x1362712900_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_243);
    return v_done_242;
  }
  case TAG_Just: {
    V v_home_245 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s620173997x1959585086(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_xs_248 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_247));
    V v_total_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam0, 2, 6, (V[]){v_home_245, v_total_249, v_progs_243, v_st_240, v_t_241, v_done_242});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V f_ = v_done_242;
  heff_room[0] = v_hd_2418;
  heff_room[1] = v_k_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2414 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2420}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam4, 1, 3, (V[]){v_done_242, v_hd_2418, v_k_2419})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_245 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s620173997x1959585086(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
  V v_t_2422 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_245; V a_3 = heff_dup(v_x_2414); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam3, 2, 2, (V[]){v_x_2414, v_done_242}); V a_5 = v_t_2417; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_home_245 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_str0), heff_dup(v_home_245)), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1_clo)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2413}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam2, 1, 7, (V[]){v_progs_243, v_st_240, v_t_241, v_home_245, v_done_242, v_hd_2410, v_k_2411})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str0)));
  V v_t_247 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str1)));
  V v_p_248 = (g_std_2epath_2ejoin_2eonto_240(v_t_246, v_t_247));
  V v_t_249 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_248, 1)), heff_rfield(v_p_248, 2)));
  V v_t_2410 = ({ V rv_2 = v_t_249; V rr_ = heff_rec_reuse_n(v_p_248, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_p_2411 = (g_std_2epath_2erender(v_st_240, v_t_2410));
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, v_p_2411));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
  V v_t_2415 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2414, 1)), heff_rfield(v_p_2414, 2)));
  V v_t_2416 = ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_n(v_p_2414, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2417, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s954557541x749476273(v_t_2421, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam1, 1, 6, (V[]){v_progs_243, v_z_244, v_st_240, v_t_241, v_done_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam0(V self, V *args) {
  V v_ok_2418 = args[0];
  return v_ok_2418;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_t_2427 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_hd_2428 = heff_env(self)[4];
  V v_k_2429 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2431);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_t_2427; V a_3 = v_progs_243; V a_4 = v_hd_2428; V a_5 = v_k_2429; V r_ = (g_heff_2ebuild_2ecommands_2eplaceIn_24s328973101x1254933269(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam4(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2426 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_t_2427 = heff_env(self)[3];
  V v_progs_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2430 = heff_tag_n(TAG_End, 2, (V[]){v_x_2426, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2430}), heff_dup(v_hd_2428), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam5, 1, 6, (V[]){v_st_240, v_t_241, v_t_2427, v_progs_243, v_hd_2428, v_k_2429})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(heff_dup(v_st_240), heff_dup(v_t_241), v_done_242, heff_dup(v_progs_243), heff_dup(heff_rfield(v_t_241, 4))));
  V v_t_2432 = ({ V a_0 = heff_dup(v_st_240); V a_1 = heff_dup(v_t_241); V a_2 = heff_dup(v_x_2426); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam4, 2, 5, (V[]){v_x_2426, v_st_240, v_t_241, v_t_2427, heff_dup(v_progs_243)}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s731279913x1966537114(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2432;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2422);
  V v_total_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_str2), v_total_2423, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2425, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_lam3, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_z_244, v_z_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str5, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str7, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str11, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str13, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str20, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str21, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str22, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(V v_st_240, V v_cmd_241, V v_t_242, V v_none_243, V v_done_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str0)));
  V v_p_249 = (g_std_2epath_2ejoin_2eonto_240(v_t_247, v_t_248));
  V v_t_2410 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_249, 1)), heff_rfield(v_p_249, 2)));
  V v_t_2411 = ({ V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_n(v_p_249, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2412 = (g_std_2epath_2erender(v_st_240, v_t_2411));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  V v_c_2414 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_2413, NTAG(TAG_Nil)));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam0, 1, 7, (V[]){v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s954557541x749476273(v_t_2439, v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7(V self, V *args) {
  V v_ns_2455 = args[0];
  return v_ns_2455;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9(V self, V *args) {
  V v_t_2463 = args[0];
  return v_t_2463;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam13(V self, V *args) {
  V v_x_2483 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2483);
  V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  return (g_co_2eop_24s954557541x749476273(v_t_2487, v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam12(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2472);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2470, 1)))) {
    heff_drop(v_none_243);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_done_244);
    V v_n_2474 = heff_get_n(v_x_2470, 1, 2);
    V v_t_2476;
    if (heff_intEq_c(heff_dup(v_n_2474), MK_INT(1LL))) {
      heff_drop(v_n_2474);
      v_t_2476 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str17);
    } else {
      v_t_2476 = heff_strAppend(heff_intShow(v_n_2474), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str18));
    }
    V v_what_2477 = heff_strAppend(v_t_2476, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str19));
    V v_t_2478 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str20), heff_strAppend(v_cmd_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str21), heff_strAppend(v_what_2477, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str22)))));
    V v_t_2479 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2478, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str23)), NTAG(TAG_MkUnit)});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    return (g_co_2eop_24s954557541x749476273(v_t_2482, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam13, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    heff_drop(v_cmd_241);
    V v_t_2488 = heff_dup(heff_rfield(v_x_2470, 0));
    switch (heff_tag_of(v_t_2488)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2470, 2);
      heff_drop(v_st_240);
      heff_drop_rec(v_t_242, 6);
      heff_drop(v_done_244);
      V f_ = v_none_243;
      heff_room[0] = v_z_245;
      heff_room[1] = v_z_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2488, 0ULL, 2);
      heff_drop(v_none_243);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(v_st_240, v_t_242, v_done_244, heff_get_n(v_x_2470, 0, 2), v_z_245, v_z_246));
    }
    default: return heff_nomatch(v_t_2488);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2471 = heff_tag_n(TAG_End, 2, (V[]){v_x_2465, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2471}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam12, 1, 8, (V[]){v_x_2470, v_cmd_241, v_z_245, v_z_246, v_none_243, v_st_240, v_t_242, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2466 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2468;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_t_2468 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2467 = heff_field(v_x_2459, 0);
    heff_take_n(v_x_2459, 1ULL, 1);
    v_t_2468 = v_x_2467;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_c_2469 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2465), v_t_2466, v_t_2468));
  V f_ = v_c_2469;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam11, 1, 8, (V[]){v_x_2465, v_z_245, v_cmd_241, v_z_246, v_none_243, v_st_240, v_t_242, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_xs_2461;
  switch (heff_tag_of(v_x_2459)) {
  case TAG_Nothing: {
    v_xs_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2460 = heff_dup(heff_field(v_x_2459, 0));
    v_xs_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x_2459);
  }
  V v_total_2462 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2461; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str16), v_total_2462, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2464, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam10, 1, 8, (V[]){v_x_2459, v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2448);
  V v_t_2449 = (g_std_2epath_2eparse(v_st_240, heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2450 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str15)));
  V v_p_2451 = (g_std_2epath_2ejoin_2eonto_240(v_t_2449, v_t_2450));
  V v_t_2452 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2451, 1)), heff_rfield(v_p_2451, 2)));
  V v_t_2453 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_n(v_p_2451, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2454 = (g_std_2epath_2erender(v_st_240, v_t_2453));
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_2454, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7_clo)})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s954557541x749476273(v_t_2458, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam8, 1, 7, (V[]){v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2424);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2422, 1)))) {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_none_243);
    heff_drop(v_done_244);
    V v_n_2426 = heff_get_n(v_x_2422, 1, 2);
    V v_t_2428;
    if (heff_intEq_c(heff_dup(v_n_2426), MK_INT(1LL))) {
      heff_drop(v_n_2426);
      v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str2);
    } else {
      v_t_2428 = heff_strAppend(heff_intShow(v_n_2426), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str3));
    }
    V v_what_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str4));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str5), heff_strAppend(v_cmd_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str6), heff_strAppend(v_what_2429, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str7)))));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str8)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s954557541x749476273(v_t_2434, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam5, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    V v_n_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2422, 0, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2442;
    if (heff_intEq_c(heff_dup(v_n_2440), MK_INT(1LL))) {
      heff_drop(v_n_2440);
      v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str9);
    } else {
      v_t_2442 = heff_strAppend(heff_intShow(v_n_2440), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str10));
    }
    V v_str_2443 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str11), heff_strAppend(heff_dup(v_cmd_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str12), heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str13)))));
    V v_t_2444 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2443, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str14)), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s954557541x749476273(v_t_2447, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam6, 1, 7, (V[]){v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2423}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam4, 1, 8, (V[]){v_x_2422, v_cmd_241, v_z_245, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2420 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2421 = ({ V a_0 = heff_dup(v_x_2419); V a_1 = v_t_2420; V a_2 = v_x_2415; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam3, 1, 8, (V[]){v_x_2419, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2416 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_x_2415));
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str1), v_total_2416, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam2, 1, 8, (V[]){v_x_2415, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam1, 1, 4, (V[]){v_hd_242, heff_dup(v_st_240), v_bin_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2(V self, V *args) {
  V v_v_249 = args[0];
  return v_v_249;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam4(V self, V *args) {
  V v_d_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = (g_std_2epath_2eparse(v_st_240, v_d_2420));
  V v_t_2422 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str5)));
  V v_p_2423 = (g_std_2epath_2ejoin_2eonto_240(v_t_2421, v_t_2422));
  V v_t_2424 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2423, 1)), heff_rfield(v_p_2423, 2)));
  V v_t_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_n(v_p_2423, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2426 = (g_std_2epath_2erender(v_st_240, v_t_2425));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_240, v_bin_241));
  V v_t_2428 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str6)));
  V v_p_2429 = (g_std_2epath_2ejoin_2eonto_240(v_t_2427, v_t_2428));
  V v_t_2430 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2429, 1)), heff_rfield(v_p_2429, 2)));
  V v_t_2431 = ({ V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_n(v_p_2429, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2432 = ({ V a_0 = v_st_240; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
  return heff_strEq(v_t_2426, v_t_2432);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_path_2415 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_path_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_sep_2417;
  if (heff_strEq_c(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str2))) {
    v_sep_2417 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str3);
  } else {
    v_sep_2417 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str4);
  }
  V v_t_2419;
  if (heff_intEq_c(heff_strLength(heff_dup(v_sep_2417)), MK_INT(0LL))) {
    heff_drop(v_sep_2417);
    v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2415, NTAG(TAG_Nil)});
  } else {
    v_t_2419 = (g_prelude_2esplitFrom(v_sep_2417, v_path_2415, MK_INT(0LL), NTAG(TAG_Nil)));
  }
  V v_t_2433 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2419; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2419); r_; });
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str8)));
    V v_t_2435 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str9)), NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s954557541x749476273(v_t_2438, v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_t_2433);
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_lam3, 1, 5, (V[]){v_x_248, v_st_240, v_bin_241, v_k_243, v_hd_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str5, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str6, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str7, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_dir_243, v_hd_245, v_t_241, v_next_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2(V self, V *args) {
  V v_ok_2429 = args[0];
  return v_ok_2429;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2445);
  V f_ = v_next_244;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s954557541x749476273(v_t_2461, v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_next_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_True: {
    V v_t_2434 = (g_std_2epath_2eparse(v_st_240, v_home_242));
    V v_t_2435 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str2)));
    V v_p_2436 = (g_std_2epath_2ejoin_2eonto_240(v_t_2434, v_t_2435));
    V v_t_2437 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2436, 1)), heff_rfield(v_p_2436, 2)));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_n(v_p_2436, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_path_2439 = ({ V a_0 = v_st_240; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; });
    V v_t_2440 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str3), v_path_2439));
    V v_t_2441 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str4)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam4, 1, 3, (V[]){v_next_244, v_hd_245, v_k_246})));
  }
  case TAG_False: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_244);
    V v_t_2446 = (g_std_2epath_2eparse(v_st_240, v_home_242));
    V v_t_2447 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str5)));
    V v_p_2448 = (g_std_2epath_2ejoin_2eonto_240(v_t_2446, v_t_2447));
    V v_t_2449 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2448, 1)), heff_rfield(v_p_2448, 2)));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_n(v_p_2448, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_why_2451 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str6), ({ V a_0 = v_st_240; V a_1 = v_t_2450; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); r_; }));
    V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str7), v_why_2451), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str8));
    V v_t_2453 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2452, NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam5, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_home_242)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str0)));
  V v_p_2414 = (g_std_2epath_2ejoin_2eonto_240(v_t_2412, v_t_2413));
  V v_t_2415 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2414, 1)), heff_rfield(v_p_2414, 2)));
  V v_t_2416 = ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_n(v_p_2414, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2417 = (g_std_2epath_2erender(v_st_240, v_t_2416));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_240, v_x_2411));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_240, v_dir_243));
  V v_p_2420 = (g_std_2epath_2ejoin_2eonto_240(v_t_2418, v_t_2419));
  V v_t_2421 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2420, 1)), heff_rfield(v_p_2420, 2)));
  V v_t_2422 = ({ V rv_2 = v_t_2421; V rr_ = heff_rec_reuse_n(v_p_2420, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_s_2423 = (g_std_2epath_2erender(v_st_240, v_t_2422));
  V v_p_2424 = (g_std_2epath_2eparse(v_st_240, v_s_2423));
  V v_t_2425 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2424, 1)), heff_rfield(v_p_2424, 2)));
  V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_n(v_p_2424, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2427 = (g_std_2epath_2erender(v_st_240, v_t_2426));
  V v_str_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_str1));
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2417, v_str_2428, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam2_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s954557541x749476273(v_t_2432, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_lam3, 1, 6, (V[]){v_st_240, v_home_242, v_t_241, v_hd_245, v_next_244, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s954557541x749476273(v_t_2438, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam7(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  return (g_co_2eop_24s954557541x749476273(v_t_2461, v_hd_2450, v_k_2451));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam6(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_dir_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str8), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str9)));
  V v_t_2453 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str10)), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_hd_2450), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam7, 1, 2, (V[]){v_hd_2450, v_k_2451})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = (g_std_2epath_2eparse(v_x_249, heff_dup(v_x_2410)));
  V v_t_2423 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str2)));
  V v_p_2424 = (g_std_2epath_2ejoin_2eonto_240(v_t_2422, v_t_2423));
  V v_t_2425 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2424, 1)), heff_rfield(v_p_2424, 2)));
  V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_n(v_p_2424, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2427 = (g_std_2epath_2erender(v_x_249, v_t_2426));
  V v_x_2428 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_240), v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2410)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str4)});
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_x_249);
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_2428, 6);
    V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str5), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str6));
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    return (g_co_2eop_24s954557541x749476273(v_t_2433, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2449;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Nothing: {
      heff_drop(v_x_2410);
      v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_x_249), heff_dup(heff_rfield(v_x_2428, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2440 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24Just = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      V v_x1_2441 = (g_heff_2ebuild_2eproject_2epackageLit(v_text_2440));
      V v_x1_2444;
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_Left: {
        V v_p_2442 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        v_x1_2444 = heff_tag_at_n(v_ru_24x_2421_24Just, TAG_Left, 1, (V[]){v_p_2442});
        break;
      }
      case TAG_Right: {
        V v_x_2443 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        heff_drop_cell(v_ru_24x_2421_24Just, 1);
        v_x1_2444 = ({ V a_0 = v_x_2443; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2443); r_; });
        break;
      }
      default: heff_nomatch(v_x1_2441);
      }
      switch (heff_tag_of(v_x1_2444)) {
      case TAG_Left: {
        heff_take_n(v_x1_2444, 0ULL, 1);
        heff_drop(v_x_2410);
        v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_x_249), heff_dup(heff_rfield(v_x_2428, 1))}));
        break;
      }
      case TAG_Right: {
        V v_pk_2446 = heff_field(v_x1_2444, 0);
        heff_take_n(v_x1_2444, 1ULL, 1);
        if (heff_strEq_c(heff_get_n(v_pk_2446, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_x_249), heff_dup(heff_rfield(v_x_2428, 1))}));
          v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo), 5, (V[]){heff_dup(v_x_249), heff_dup(v_x_2428), v_x_2410, heff_dup(v_dir_240), v_t_2448}));
        } else {
          heff_drop(v_x_2410);
          v_t_2449 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_x_249), heff_dup(heff_rfield(v_x_2428, 1))}));
        }
        break;
      }
      default: heff_nomatch(v_x1_2444);
      }
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str7), v_x_2428, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam6, 2, 1, (V[]){v_dir_240}), v_t_2449, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = (g_std_2epath_2eparse(v_x_249, heff_dup(v_dir_240)));
  V v_t_2412 = (g_std_2epath_2eparse(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str1)));
  V v_p_2413 = (g_std_2epath_2ejoin_2eonto_240(v_t_2411, v_t_2412));
  V v_t_2414 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2413, 1)), heff_rfield(v_p_2413, 2)));
  V v_t_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_n(v_p_2413, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2416 = (g_std_2epath_2erender(v_x_249, v_t_2415));
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2416, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam4, 1, 5, (V[]){v_x_249, v_x_2410, v_dir_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_249;
  if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str0))) {
    v_x_249 = NTAG(TAG_Windows);
  } else {
    v_x_249 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam2, 1, 4, (V[]){v_x_249, v_dir_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam1, 2, 4, (V[]){v_c_246, heff_dup(v_f_244), v_acc_241, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_intAdd(heff_take_field(v_acc_241, 0), heff_take_field(v_x_2413, 0));
  V v_t_2415 = heff_intAdd(heff_take_field(v_acc_241, 1), heff_take_field(v_x_2413, 1));
  V v_t_2416 = heff_take_field(v_acc_241, 2);
  V v_t_2417;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    v_t_2417 = heff_dup(heff_rfield(v_x_2413, 2));
    break;
  }
  case TAG_False: {
    v_t_2417 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_t_2418 = heff_intAdd(heff_take_field(v_acc_241, 3), heff_take_field(v_x_2413, 3));
  V v_t_2419 = heff_intAdd(heff_get_n(v_acc_241, 4, 5), heff_get_n(v_x_2413, 4, 5));
  V v_t_2420 = ({ V a_0 = v_rest_245; V a_1 = heff_rec_n(5, shape_total__failed__ok__tests__testsFailed, (V[]){v_t_2414, v_t_2415, v_t_2417, v_t_2418, v_t_2419}); V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = heff_dup(g_heff_2ebuild_2ecommands_2edefaultSeed_get()); V a_1 = v_f_244; V a_2 = v_x_2410; V b_3 = heff_get_n(v_x_2412, 0, 2); V a_4 = heff_dup(v_hd_247); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam5, 1, 4, (V[]){v_acc_241, v_rest_245, v_hd_247, v_k_248}); V r_ = (g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2411 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_249));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam4, 1, 6, (V[]){v_f_244, v_x_2410, v_hd_247, v_acc_241, v_rest_245, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_str0), heff_dup(heff_rfield(v_x_249, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam3, 1, 6, (V[]){v_x_249, v_hd_247, v_f_244, v_acc_241, v_rest_245, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_lam2, 1, 5, (V[]){v_hd_247, v_f_244, v_acc_241, v_rest_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str3, 6, ": git ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str4, 2, ": ");
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(V v_what_240, V v_as_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str0), heff_dup(v_as_241), ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_247}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam1, 1, 3, (V[]){v_as_241, v_what_240, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam0(V self, V *args) {
  V v_r_244 = args[0];
  return v_r_244;
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_as_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2419;
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_248, 0)), MK_INT(0LL))) {
    heff_drop_rec(v_x_248, 3);
    heff_drop(v_as_241);
    heff_drop(v_what_240);
    v_x_2419 = NTAG(TAG_Nothing);
  } else {
    V v_t_2412;
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_as_241, 0);
      V v_xs_2411 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str2); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_as_241);
    }
    V v_s_2413 = heff_get_n(v_x_248, 2, 3);
    V v_t_2414 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2415 = heff_intSub(heff_strLength(heff_dup(v_s_2413)), MK_INT(1LL));
    V v_t_2416 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), v_t_2415, MK_INT(-1LL)));
    V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
    V v_t_2418 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str3), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607_str4), v_t_2417))));
    v_x_2419 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
  }
  V f_ = v_k_243;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str12, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s954557541x749476273(v_t_2426, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_pk_241 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str10), heff_strAppend(heff_get_n(v_pk_241, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str11), heff_strAppend(heff_dup(v_v_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str12), v_v_240)))));
    V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str13)), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_why_2416 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop_rec(v_pk_241, 4);
    heff_drop(v_v_240);
    V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str14), v_why_2416), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str15));
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s954557541x749476273(v_t_2421, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam2, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s954557541x749476273(v_t_2437, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str8), v_t_248})});
    return (g_heff_2ebuild_2ecommands_2egitOk_24s1526698644x1488670607(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam1, 1, 4, (V[]){v_pk_241, v_v_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2427 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str16), v_why_2427), ((V)&g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_str17));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s954557541x749476273(v_t_2432, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_lam3, 1, 2, (V[]){v_hd_242, v_k_243})));
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str0, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str1, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str2, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str4, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(V v_v_240, V v_pk_241, V v_r_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_248;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 1)))) {
    v_t_248 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 4)))) {
      v_t_248 = NTAG(TAG_True);
    } else {
      V v_t_247 = heff_dup(heff_rfield(v_r_242, 2));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_248 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
    }
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    V v_t_249 = heff_intShow(heff_take_field(v_r_242, 1));
    V v_t_2410 = heff_intShow(heff_take_field(v_r_242, 0));
    V v_t_2411 = heff_intShow(heff_take_field(v_r_242, 4));
    V v_t_2412 = heff_intShow(heff_get_n(v_r_242, 3, 5));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str0), heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str1), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str2), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str4)))))))));
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str5)), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_lam0, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_False: {
    heff_drop_rec(v_r_242, 5);
    return (g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(v_v_240, v_pk_241, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s954557541x749476273(v_t_2422, v_z_243, v_z_244));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str0, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str1, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str2, 6, "status");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str8, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str12, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str13, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str15, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str16, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str2), v_t_245}), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam1, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241})));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s954557541x749476273(v_t_2437, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2449);
  V v_t_2450 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s954557541x749476273(v_t_2453, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam6(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2460);
  V v_t_2461 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s954557541x749476273(v_t_2464, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam8(V self, V *args) {
  V v_x_2470 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(v_v_240, v_pk_241, v_x_2470, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam7(V self, V *args) {
  V v_x_2467 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2468 = heff_rec_n(5, shape_total__failed__ok__tests__testsFailed, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(0LL), MK_INT(0LL)});
  V v_c_2469 = ({ V a_0 = v_x_2467; V a_1 = v_t_2468; V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(a_0, a_1)); heff_drop(v_x_2467); r_; });
  V f_ = v_c_2469;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam8, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_src_242 = heff_env(self)[4];
  V v_pk_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421;
  if (heff_intEq_c(heff_dup(heff_rfield(v_x_2411, 0)), MK_INT(0LL))) {
    v_t_2421 = NTAG(TAG_False);
  } else {
    v_t_2421 = NTAG(TAG_True);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    heff_drop_rec(v_x_2419, 3);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    V v_s_2422 = heff_get_n(v_x_2411, 2, 3);
    V v_t_2423 = (g_prelude_2eskipSpaces(heff_dup(v_s_2422), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2424 = heff_intSub(heff_strLength(heff_dup(v_s_2422)), MK_INT(1LL));
    V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_s_2422), v_t_2424, MK_INT(-1LL)));
    V v_t_2426 = heff_strSlice(v_s_2422, v_t_2423, heff_intAdd(v_t_2425, MK_INT(1LL)));
    V v_why_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str8), v_t_2426);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str9), v_why_2427), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str10));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s954557541x749476273(v_t_2432, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam4, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  case TAG_False: {
    V v_s_2438 = heff_get_n(v_x_2411, 1, 3);
    V v_t_2439 = (g_prelude_2eskipSpaces(heff_dup(v_s_2438), MK_INT(0LL), MK_INT(1LL)));
    V v_t_2440 = heff_intSub(heff_strLength(heff_dup(v_s_2438)), MK_INT(1LL));
    V v_t_2441 = (g_prelude_2eskipSpaces(heff_dup(v_s_2438), v_t_2440, MK_INT(-1LL)));
    V v_t_2442 = heff_strSlice(v_s_2438, v_t_2439, heff_intAdd(v_t_2441, MK_INT(1LL)));
    V v_t_2444;
    if (heff_strEq_c(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str11))) {
      v_t_2444 = NTAG(TAG_False);
    } else {
      v_t_2444 = NTAG(TAG_True);
    }
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop_rec(v_x_2419, 3);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str12), NTAG(TAG_MkUnit)});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      return (g_co_2eop_24s954557541x749476273(v_t_2448, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam5, 1, 2, (V[]){v_hd_243, v_k_244})));
    }
    case TAG_False: {
      if (heff_intEq_c(heff_get_n(v_x_2419, 0, 3), MK_INT(0LL))) {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        V v_t_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str13), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str14), heff_strAppend(v_v_240, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str15))));
        V v_t_2456 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str16)), NTAG(TAG_MkUnit)});
        V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
        V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
        V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
        return (g_co_2eop_24s954557541x749476273(v_t_2459, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam6, 1, 2, (V[]){v_hd_243, v_k_244})));
      } else {
        V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2466 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_2465, NTAG(TAG_Nil)));
        V f_ = v_c_2466;
        heff_room[0] = heff_dup(v_hd_243);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam7, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str5), v_t_2412})});
  V v_t_2415 = heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str7), v_t_2413}), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam3, 1, 6, (V[]){v_x_2411, v_hd_243, v_k_244, v_v_240, v_src_242, v_pk_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(V v_v_240, V v_l_241, V v_pk_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch(heff_dup(heff_rfield(v_pk_242, 0)), heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_st_246 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 0, 6);
    V v_t_248 = (g_std_2epath_2eparse(v_st_246, v_t_247));
    V v_t_249 = (g_std_2epath_2eparse(v_st_246, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str0)));
    V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
    V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
    V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_n(v_p_2410, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2413 = ({ V a_0 = v_st_246; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); r_; });
    return (g_heff_2ebuild_2eload_2eownDir_24s1100129958x1274923408(heff_dup(heff_rfield(v_l_241, 2)), v_t_2413, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0, 1, 5, (V[]){v_z_243, v_z_244, v_l_241, v_v_240, v_pk_242})));
  }
  case TAG_Just: {
    V v_why_2435 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_l_241, 5);
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str4), heff_strAppend(heff_get_n(v_pk_242, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str5), v_why_2435)));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str6)), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s954557541x749476273(v_t_2440, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s954557541x749476273(v_t_2425, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_why_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str1), v_why_2415), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str2));
    V v_t_2417 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam1, 1, 2, (V[]){v_z_243, v_z_244})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_st_2427 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_2428 = heff_get_n(heff_get_n(v_l_241, 2, 5), 0, 6);
    V v_t_2429 = (g_std_2epath_2eparse(v_st_2427, v_t_2428));
    V v_t_2430 = (g_std_2epath_2eparse(v_st_2427, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_str3)));
    V v_p_2431 = (g_std_2epath_2ejoin_2eonto_240(v_t_2429, v_t_2430));
    V v_t_2432 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2431, 1)), heff_rfield(v_p_2431, 2)));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_n(v_p_2431, 3ULL, 3, shape_drive__absolute__segments); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2434 = ({ V a_0 = v_st_2427; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); r_; });
    return (g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(v_v_240, v_pk_242, v_t_2434, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085_lam2(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  return (g_co_2eop_24s954557541x749476273(v_t_2445, v_z_243, v_z_244));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str0, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str2, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str4, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str5, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str7, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str8, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str9, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str10, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(V v_v_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_v_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam0, 2, 1, (V[]){v_v_240});
  }
  case TAG_Just: {
    heff_take_n(v_t_241, 0ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam2, 2, 1, (V[]){v_v_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115(a[0]);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2410 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, v_hd_242, v_k_243));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str0), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str1), heff_strAppend(v_v_240, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str2))));
  V v_t_245 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str3)), NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s954557541x749476273(v_t_248, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam1, 1, 2, (V[]){v_hd_242, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s954557541x749476273(v_t_2430, v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s954557541x749476273(v_t_2448, v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s954557541x749476273(v_t_2459, v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam12(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2465);
  V v_t_2466 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  return (g_co_2eop_24s954557541x749476273(v_t_2469, v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_cs_2437 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_dup(heff_rfield(v_x_2433, 3));
  switch (heff_tag_of(v_t_2439)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2433, 5);
    heff_drop(v_x_2434);
    heff_drop(v_cs_2437);
    heff_drop(v_v_240);
    V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str8), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s954557541x749476273(v_t_2443, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam10, 1, 2, (V[]){v_hd_2415, v_k_2416})));
  }
  case TAG_Just: {
    V v_pk_2449 = heff_field(v_t_2439, 0);
    V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2434)) {
      heff_drop_rec(v_x_2433, 5);
      heff_drop(v_cs_2437);
      heff_drop(v_v_240);
      heff_drop(v_pk_2449);
      V v_t_2451 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str9), NTAG(TAG_MkUnit)});
      V v_t_2452 = heff_tag_at_n(v_ru_24t_2439_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      return (g_co_2eop_24s954557541x749476273(v_t_2454, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam11, 1, 2, (V[]){v_hd_2415, v_k_2416})));
    } else {
      V v_t_2460 = ({ V a_0 = v_cs_2437; V r_ = (g_list_2eany_24s976871491x582277361(a_0)); heff_drop(v_cs_2437); r_; });
      switch (heff_tag_of(v_t_2460)) {
      case TAG_True: {
        heff_drop_rec(v_x_2433, 5);
        heff_drop(v_v_240);
        heff_drop(v_pk_2449);
        V v_t_2461 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str10), NTAG(TAG_MkUnit)});
        V v_t_2462 = heff_tag_at_n(v_ru_24t_2439_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
        V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
        return (g_co_2eop_24s954557541x749476273(v_t_2464, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam12, 1, 2, (V[]){v_hd_2415, v_k_2416})));
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24t_2439_24Just, 1);
        return (g_heff_2ebuild_2ecommands_2epublishChecked_24s1314041827x496249085(v_v_240, v_x_2433, v_pk_2449, v_hd_2415, v_k_2416));
      }
      default: return heff_nomatch(v_t_2460);
      }
    }
  }
  default: return heff_nomatch(v_t_2439);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_v_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_cs_2437 = heff_get_n(v_x_2436, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_2437), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam9, 1, 6, (V[]){v_x_2433, v_hd_2415, v_k_2416, v_x_2434, v_cs_2437, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2435 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_2433)));
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam8, 1, 5, (V[]){v_hd_2415, v_x_2433, v_k_2416, v_x_2434, v_v_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str7), heff_dup(heff_rfield(v_x_2433, 1)), MK_INT(0LL), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam7, 1, 4, (V[]){v_x_2433, v_hd_2415, v_k_2416, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_v_240);
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str5), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s954557541x749476273(v_t_2425, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam5, 1, 2, (V[]){v_hd_2415, v_k_2416})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2421, 0ULL, 1);
    V v_c_2432 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str6)));
    V f_ = v_c_2432;
    heff_room[0] = heff_dup(v_hd_2415);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam6, 1, 3, (V[]){v_hd_2415, v_k_2416, v_v_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_str4), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam3_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s1357516507x2040027115_lam4, 1, 3, (V[]){v_hd_2415, v_k_2416, v_v_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str0, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eversionSaid(v_x_242, v_x_247));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Left: {
    V v_why_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Left = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str0), v_why_249), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str1));
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_at_n(v_ru_24t_248_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_line_2420 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Right = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2421 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2420, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str2)), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24t_248_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s954557541x749476273(v_t_2424, v_hd_240, v_k_241));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_x_242), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str0, 12, "cannot read ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str4, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str5, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str9, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str10, 3, "lib");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str13, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str14, 3, "src");
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(V v_before_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_before_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_path_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){heff_dup(v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam1, 1, 5, (V[]){v_path_244, v_p_242, v_p_243, v_before_240, v_rest_245})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam0(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2421);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s954557541x749476273(v_t_2420, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam3, 1, 1, (V[]){v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  return v_s_2423;
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam8(V self, V *args) {
  V v_i_2438 = args[0];
  V v_before_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_i_2438}));
  return ({ V a_0 = v_t_2439; V a_1 = v_before_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_before_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_src_2422 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_m_2435 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str8), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str9), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str10), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str11), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str12), v_x_2429}), heff_dup(v_path_244)));
  V v_t_2436 = heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str13), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str14), heff_take_field(v_x_2431, 0), heff_take_field(v_x_2431, 1), heff_take_field(v_x_2431, 2), heff_get_n(v_x_2431, 3, 5)});
  V v_library_2437 = (g_heff_2ebuild_2eload_2eofLibrary(v_t_2436, heff_dup(v_path_244)));
  V v_t_2440 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam8, 1, 1, (V[]){v_before_240}), heff_dup(g_heff_2esyntax_2eimport_2eimplicitModules_get())));
  V v_t_2441 = heff_rec_n(7, shape_module__path__shown__source__renames__implicit__library, (V[]){v_m_2435, heff_dup(v_path_244), v_path_244, v_src_2422, NTAG(TAG_Nil), v_t_2440, v_library_2437});
  V v_x_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_x_2434});
  V f_ = v_p_243;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_src_2422 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432 = (g_heff_2ebuild_2eload_2emoduleOf(heff_rec_n(6, shape_root__src__lib__mod__cwd__style, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str3), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str4), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str5), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str6), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str7), heff_dup(v_x_2429)}), heff_dup(v_path_244)));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_dup(v_before_240)});
  return (g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889(v_t_2433, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam7, 1, 6, (V[]){v_x_2429, v_path_244, v_x_2431, v_before_240, v_src_2422, v_p_243})));
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_src_2422 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2429;
  if (heff_strEq_c(v_x_2427, ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str2))) {
    v_x_2429 = NTAG(TAG_Windows);
  } else {
    v_x_2429 = NTAG(TAG_Posix);
  }
  V v_c_2430 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam6, 1, 7, (V[]){v_x_2429, v_path_244, v_before_240, v_rest_245, v_p_242, v_src_2422, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_before_240 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    heff_drop(v_before_240);
    heff_drop(v_rest_245);
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str0), v_path_244), ((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_str1));
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam2, 1, 2, (V[]){v_p_242, v_p_243})));
  }
  case TAG_Just: {
    V v_src_2422 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam4_clo)})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadAll_24s196306610x299710889_lam5, 1, 6, (V[]){v_p_242, v_path_244, v_before_240, v_rest_245, v_src_2422, v_p_243})));
  }
  default: return heff_nomatch(v_x_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str0, 5, "=def ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str2, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str3, 6, "=body ");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 13);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str0), heff_strAppend(heff_dup(v_k_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str1), (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), heff_dup(v_k_244))))));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str2), (g_heff_2eelab_2etoplevel_2etyDump(heff_dup(heff_rfield(v_c_240, 5)), heff_dup(v_k_244))));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_str3), (g_heff_2eelab_2etoplevel_2ebodyDump(heff_dup(heff_rfield(v_c_240, 5)), v_k_244)));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam1, 2, 3, (V[]){v_t_2410, v_c_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2413);
  V v_t_2414 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(v_c_240, v_rest_245));
  V f_ = v_t_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2410, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_list_2emap_24s634984521x2042558081(heff_dup(heff_rfield(v_c_244, 7))));
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s1431621018x139529971(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_str0), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(heff_get_n(v_c_244, 0, 13), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_take_field(v_d_243, 0), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str0), heff_get_n(v_d_243, 1, 2)));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str1)), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_249, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam0, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(V v_badL_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, v_k_243, heff_dup(v_badL_240)})));
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_badL_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2412);
  switch (heff_tag_of(v_badL_240)) {
  case TAG_True: {
    heff_drop(v_cs_241);
    V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_242, v_k_243));
  }
  case TAG_False: {
    V v_t_2417 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s976871491x582277361(a_0)); heff_drop(v_cs_241); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s954557541x749476273(v_t_2421, v_hd_242, v_k_243));
    }
    case TAG_False: {
      heff_drop(v_hd_242);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_badL_240);
  }
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_badL_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  V v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_241));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_cs_241);
    heff_drop(v_badL_240);
    V v_t_246 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s954557541x749476273(v_t_249, v_hd_242, v_k_243));
  }
  case TAG_Just: {
    V v_c_2410 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2411 = (g_heff_2ebuild_2edriver_2eevaluate(v_c_2410));
    return (g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(v_t_2411, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1929119733x1756238537_lam1, 1, 4, (V[]){v_badL_240, v_hd_242, v_k_243, v_cs_241})));
  }
  default: return heff_nomatch(v_t_245);
  }
}