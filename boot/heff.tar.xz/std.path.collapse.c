// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2ecollapse_2estep_240_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2ecollapse_2estep_240_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2ecollapse_2estep_240_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2epath_2ecollapse_2estep_240_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {46, 46}};
Clo g_std_2epath_2ecollapse_2estep_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ecollapse_2estep_240_entry, 3, 0};

V g_std_2epath_2ecollapse_2estep_240(V v_absolute_240, V v_acc_241, V v_x_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_x_242), ((V)&g_std_2epath_2ecollapse_2estep_240_str0));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_x_242);
    switch (heff_tag_of(v_acc_241)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_absolute_240)) {
      case TAG_True: {
        return NTAG(TAG_Nil);
      }
      case TAG_False: {
        return heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2epath_2ecollapse_2estep_240_str1), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_absolute_240);
      }
    }
    case TAG_Cons: {
      V v_it1_244 = heff_dup(heff_field(v_acc_241, 0));
      V v_it2_245 = heff_dup(heff_field(v_acc_241, 1));
      V v_t_246 = heff_strEq(v_it1_244, ((V)&g_std_2epath_2ecollapse_2estep_240_str2));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop(v_it2_245);
        return heff_tag(TAG_Cons, 2, (V[]){((V)&g_std_2epath_2ecollapse_2estep_240_str3), v_acc_241});
      }
      case TAG_False: {
        heff_drop_tag(v_acc_241, 2);
        return v_it2_245;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_acc_241);
    }
  }
  case TAG_False: {
    return heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_std_2epath_2ecollapse_2estep_240_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2ecollapse_2estep_240(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}