// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2epath_2ecollapse_2estep_241(V, V, V);
V g_std_2epath_2ecollapse_2estep_241_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_2estep_241_clo;
HEFF_STRA(g_std_2epath_2ecollapse_2estep_241_str0, 2, (46, 46));
HEFF_STRA(g_std_2epath_2ecollapse_2estep_241_str1, 2, (46, 46));
HEFF_STRA(g_std_2epath_2ecollapse_2estep_241_str2, 2, (46, 46));
HEFF_STRA(g_std_2epath_2ecollapse_2estep_241_str3, 2, (46, 46));
Clo g_std_2epath_2ecollapse_2estep_241_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2ecollapse_2estep_241_entry, 3, 0};

V g_std_2epath_2ecollapse_2estep_241(V v_absolute_240, V v_acc_241, V v_x_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_x_242), ((V)&g_std_2epath_2ecollapse_2estep_241_str0))) {
    heff_drop(v_x_242);
    switch (heff_tag_of(v_acc_241)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_absolute_240)) {
      case TAG_True: {
        return NTAG(TAG_Nil);
      }
      case TAG_False: {
        return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2epath_2ecollapse_2estep_241_str1), NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_absolute_240);
      }
    }
    case TAG_Cons: {
      V v_acc1_244 = heff_dup(heff_field(v_acc_241, 0));
      V v_acc2_245 = heff_dup(heff_field(v_acc_241, 1));
      if (heff_strEq_c(v_acc1_244, ((V)&g_std_2epath_2ecollapse_2estep_241_str2))) {
        heff_drop(v_acc2_245);
        return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2epath_2ecollapse_2estep_241_str3), v_acc_241});
      } else {
        heff_drop_tag(v_acc_241, 2);
        return v_acc2_245;
      }
    }
    default: return heff_nomatch(v_acc_241);
    }
  } else {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
  }
}
V g_std_2epath_2ecollapse_2estep_241_entry(V self, V *a) {
  (void)self;
  V r = g_std_2epath_2ecollapse_2estep_241(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}