// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define LBL_body 9524841
#define LBL_k 325
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_name 9869138
#define LBL_out 319944
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__out__k[] = {LBL_keys, LBL_out, LBL_k};
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2elift_2efreeGo(V, V, V);
V g_heff_2ecompile_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elift_2efreeGo_clo;
V g_heff_2ecompile_2erecords_2eglobalOf(V, V, V);
V g_heff_2ecompile_2erecords_2eglobalOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erecords_2eglobalOf_clo;
V g_heff_2ecompile_2erecords_2ego(V, V, V);
V g_heff_2ecompile_2erecords_2ego_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erecords_2ego_clo;
V g_heff_2ecompile_2erecords_2enodeOf(V, V, V, V);
V g_heff_2ecompile_2erecords_2enodeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erecords_2enodeOf_clo;
V g_heff_2ecompile_2erecords_2enodeOf_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2erecords_2enodeOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erecords_2enodeOf_24tok2_clo;
V g_heff_2ecompile_2erecords_2estaticPart(V);
V g_heff_2ecompile_2erecords_2estaticPart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erecords_2estaticPart_clo;
V g_list_2eall_24s1600565035x458011442(V);
V g_list_2eall_24s1600565035x458011442_entry(V self, V *a);
extern Clo g_list_2eall_24s1600565035x458011442_clo;
V g_list_2eall_24s298666026x1868300012(V);
V g_list_2eall_24s298666026x1868300012_entry(V self, V *a);
extern Clo g_list_2eall_24s298666026x1868300012_clo;
V g_list_2eany_24s1685012089x57712328(V);
V g_list_2eany_24s1685012089x57712328_entry(V self, V *a);
extern Clo g_list_2eany_24s1685012089x57712328_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2erecords_2estaticPart_str0, 6, "MkLazy");
Clo g_heff_2ecompile_2erecords_2estaticPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erecords_2estaticPart_entry, 1, 0};

V g_heff_2ecompile_2erecords_2estaticPart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_xs_245 = heff_tr(g_heff_2ecompile_2elift_2efreeGo(heff_dup(v_xs_243), heff_dup(v_b_244), NTAG(TAG_Nil)));
    V v_x1_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      heff_take_n(v_x1_246, 0ULL, 2);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2420 = heff_field(v_x1_240, 0);
    V v_args_2421 = heff_field(v_x1_240, 1);
    if (!heff_strEq_c_lent(v_t_2420, ((V)&g_heff_2ecompile_2erecords_2estaticPart_str0), 2)) {
      HEFF_LAST return g_list_2eall_24s1600565035x458011442(v_args_2421);
    } else {
      return NTAG(TAG_False);
    }
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erecords_2estaticPart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erecords_2estaticPart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str1, 1, " ");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str4, 4, "$rec");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str5, 4, "$rec");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str6, 4, "$rec");
HEFF_LIT(g_heff_2ecompile_2erecords_2eglobalOf_str7, 4, "$rec");
Clo g_heff_2ecompile_2erecords_2eglobalOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erecords_2eglobalOf_entry, 3, 0};

V g_heff_2ecompile_2erecords_2eglobalOf(V v_owner_240, V v_e_241, V v_s_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), heff_dup(v_e_241)));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_x_246 = v_field_244;
    V v_y_247 = v_field_245;
    heff_drop(v_y_247);
    V v_t_248 = v_x_246;
    V v_x2_249 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_t_248, NTAG(TAG_Nil)));
    V v_t_2412;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_xs_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str1); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    HeffT2 v_t_2413 = ({ V a_0 = heff_rfield(v_s_242, 0); V a_1 = v_t_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_owner_240);
        heff_drop(v_e_241);
        V v_g_2416 = v_field_2415;
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2416}), v_s_242});
      } else {
        heff_drop(v_field_2415);
        V v_owner_2417 = v_owner_240;
        HeffT2 v_t_2418 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), MK_INT(0LL), heff_dup(v_e_241)));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_x_2421 = v_field_2419;
          V v_y_2422 = v_field_2420;
          heff_drop(v_y_2422);
          V v_t_2423 = v_x_2421;
          V v_x2_2424 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_t_2423, NTAG(TAG_Nil)));
          V v_t_2427;
          switch (heff_tag_of(v_x2_2424)) {
          case TAG_Nil: {
            v_t_2427 = ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str2);
            break;
          }
          case TAG_Cons: {
            V v_x_2425 = heff_field(v_x2_2424, 0);
            V v_xs_2426 = heff_field(v_x2_2424, 1);
            heff_take_n(v_x2_2424, 3ULL, 2);
            v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str3); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2424);
          }
          V v_e_2428 = v_e_241;
          V v_s_2429 = v_s_242;
          V v_keys_2430 = heff_take_field(v_s_2429, 0);
          V v_k_2431 = heff_take_field(v_s_2429, 2);
          V v_out_2432 = heff_take_field(v_s_2429, 1);
          V v_t_2433 = heff_strAppend(heff_strAppend(heff_dup(v_owner_2417), ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str4)), heff_intShow(heff_dup(v_k_2431)));
          V v_t_2434 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_keys_2430, v_t_2427, v_t_2433));
          V v_t_2435 = heff_strAppend(heff_strAppend(heff_dup(v_owner_2417), ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str5)), heff_intShow(heff_dup(v_k_2431)));
          V v_t_2436 = heff_strAppend(heff_strAppend(heff_dup(v_owner_2417), ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str6)), heff_intShow(heff_dup(v_k_2431)));
          V v_t_2437 = heff_rec_n(3, shape_key__name__body, (V[]){v_t_2436, heff_strAppend(v_owner_2417, ((V)&g_heff_2ecompile_2erecords_2eglobalOf_str7)), v_e_2428});
          V v_t_2438 = ({ V rv_0 = v_t_2434; V rv_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_out_2432}); V rv_2 = heff_intAdd(v_k_2431, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_s_2429, 0ULL, 3, shape_keys__out__k, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_t_2435}), v_t_2438});
        }
      }
    }
  }
}
V g_heff_2ecompile_2erecords_2eglobalOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erecords_2eglobalOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erecords_2enodeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erecords_2enodeOf_entry, 4, 0};

V g_heff_2ecompile_2erecords_2enodeOf(V v_owner_240, V v_inFun_241, V v_e_242, V v_z_243) {
top: ;
  if ((heff_dup(v_inFun_241) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_e_242)) {
    case TAG_ERecord: {
      V v_fs_244 = heff_field(v_e_242, 0);
      V v_ts_245 = heff_field(v_e_242, 1);
      V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
      V v_t_246 = (g_list_2eall_24s298666026x1868300012(v_fs_244));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247 = (g_list_2eany_24s1685012089x57712328(v_fs_244));
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_t_247);
          return (g_heff_2ecompile_2erecords_2eglobalOf(v_owner_240, heff_tag_re_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, 3ULL, (V[]){v_fs_244, v_ts_245}), v_z_243));
        } else {
          heff_drop(v_owner_240);
          heff_drop(v_t_247);
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, 3ULL, (V[]){v_fs_244, v_ts_245}), v_z_243});
        }
      } else {
        heff_drop(v_owner_240);
        heff_drop(v_t_246);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, 3ULL, (V[]){v_fs_244, v_ts_245}), v_z_243});
      }
    }
    default: {
      heff_drop(v_owner_240);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_z_243});
    }
    }
  } else {
    heff_drop(v_owner_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_z_243});
  }
}
V g_heff_2ecompile_2erecords_2enodeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erecords_2enodeOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erecords_2ego_lam0(V self, V *args);
V g_heff_2ecompile_2erecords_2ego_lam1(V self, V *args);
V g_heff_2ecompile_2erecords_2ego_lam2(V self, V *args);
V g_heff_2ecompile_2erecords_2ego_lam3(V self, V *args);
Clo g_heff_2ecompile_2erecords_2ego_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erecords_2ego_entry, 3, 0};

V g_heff_2ecompile_2erecords_2ego(V v_owner_240, V v_inFun_241, V v_e_242) {
top: ;
  V v_go_245 = heff_clo_n(g_heff_2ecompile_2erecords_2ego_lam0, 2, 1, (V[]){heff_dup(v_owner_240)});
  V v_inFun_246 = heff_dup(v_inFun_241);
  V v_e_247 = v_e_242;
  V v_m_2417;
  switch (heff_tag_of(v_e_247)) {
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_247, 0);
    V v_b_249 = heff_field(v_e_247, 1);
    heff_take_n(v_e_247, 3ULL, 2);
    heff_drop(v_inFun_246);
    V v_m_2410 = heff_tr(heff_call(v_go_245, 2, (V[]){NTAG(TAG_True), v_b_249}));
    v_m_2417 = heff_clo_n(g_heff_2ecompile_2erecords_2ego_lam1, 1, 2, (V[]){v_m_2410, v_xs_248});
    break;
  }
  default: {
    v_m_2417 = (g_heff_2ecompile_2eir_2etraversePartsM_24s1977652923x439439906(heff_clo_n(g_heff_2ecompile_2erecords_2ego_lam2, 2, 2, (V[]){v_go_245, v_inFun_246}), v_e_247));
    break;
  }
  }
  return heff_clo_n(g_heff_2ecompile_2erecords_2ego_lam3, 1, 3, (V[]){v_m_2417, v_owner_240, v_inFun_241});
}
V g_heff_2ecompile_2erecords_2ego_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erecords_2ego(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erecords_2ego_lam0(V self, V *args) {
  V v_b_243 = args[0];
  V v_p_244 = args[1];
  V v_owner_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2erecords_2ego(v_owner_240, v_b_243, v_p_244));
}
V g_heff_2ecompile_2erecords_2ego_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_248, v_x_2413}), v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2erecords_2ego_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_2416 = args[1];
  V v_go_245 = heff_env(self)[0];
  V v_inFun_246 = heff_env(self)[1];
  heff_drop(v_x_2415);
  heff_clo_take(self, 2);
  V f_ = v_go_245;
  args[0] = v_inFun_246;
  args[1] = v_p_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ecompile_2erecords_2ego_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_owner_240 = heff_env(self)[1];
  V v_inFun_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return ({ V a_0 = v_ru_24x2_2419_24MkPair; V a_1 = v_owner_240; V a_2 = v_inFun_241; V a_3 = v_x_2420; V a_4 = v_s_2421; V r_ = (g_heff_2ecompile_2erecords_2enodeOf_24tok2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_inFun_241); r_; });
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
Clo g_heff_2ecompile_2erecords_2enodeOf_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erecords_2enodeOf_24tok2_entry, 5, 0};

V g_heff_2ecompile_2erecords_2enodeOf_24tok2(V v_tok_240, V v_owner_241, V v_inFun_242, V v_e_243, V v_z_244) {
top: ;
  if ((heff_dup(v_inFun_242) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_e_243)) {
    case TAG_ERecord: {
      V v_fs_245 = heff_field(v_e_243, 0);
      V v_ts_246 = heff_field(v_e_243, 1);
      V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
      V v_t_247 = (g_list_2eall_24s298666026x1868300012(v_fs_245));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = (g_list_2eany_24s1685012089x57712328(v_fs_245));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24e_243_24ERecord, 2);
          heff_drop(v_t_248);
          return (g_heff_2ecompile_2erecords_2eglobalOf(v_owner_241, heff_tag_at_n(v_tok_240, TAG_ERecord, 2, (V[]){v_fs_245, v_ts_246}), v_z_244));
        } else {
          heff_drop(v_owner_241);
          heff_drop(v_t_248);
          return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_243_24ERecord, TAG_ERecord, 2, 3ULL, (V[]){v_fs_245, v_ts_246}), v_z_244});
        }
      } else {
        heff_drop(v_owner_241);
        heff_drop(v_t_247);
        return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24e_243_24ERecord, TAG_ERecord, 2, 3ULL, (V[]){v_fs_245, v_ts_246}), v_z_244});
      }
    }
    default: {
      heff_drop(v_owner_241);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_e_243, v_z_244});
    }
    }
  } else {
    heff_drop(v_owner_241);
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_e_243, v_z_244});
  }
}
V g_heff_2ecompile_2erecords_2enodeOf_24tok2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erecords_2enodeOf_24tok2(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}